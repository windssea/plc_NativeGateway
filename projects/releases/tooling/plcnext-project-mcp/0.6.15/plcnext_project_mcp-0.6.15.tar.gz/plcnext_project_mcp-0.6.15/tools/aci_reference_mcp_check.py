"""Exercise only static/disabled tools of the optional ACI reference over stdio."""
import asyncio
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    root = Path(__file__).resolve().parents[1]
    environment = dict(os.environ)
    environment.pop('PLCNEXT_ACI_REFERENCE_ENABLE', None)
    parameters = StdioServerParameters(command=sys.executable,
        args=['-I', str(root / 'examples/aci_mcp/reference_server.py')], env=environment)
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as client:
            initialized = await client.initialize()
            tools = await client.list_tools()
            async def call(name, args):
                response = await client.call_tool(name, args)
                assert not response.isError
                return response.structuredContent or json.loads(response.content[0].text)
            info = await call('aci_reference_info', {})
            enum = await call('aci_api_catalog', {'type_name': 'Ade.ApplicationControl.Iec.DownloadTypes'})
            disabled = await client.call_tool('aci_offline_roundtrip', {'source_path': 'not-opened.pcwex'})
            assert disabled.isError
            assert not info['execution_enabled'] and not info['controller_access']
            assert enum['types'][0]['values']['OnlyChanges'] == 2
            result = {'status': 'passed', 'transport': 'MCP stdio',
                      'server': initialized.serverInfo.model_dump(),
                      'tools': [tool.name for tool in tools.tools],
                      'info': info, 'catalog_enum': enum, 'disabled_call_rejected': disabled.isError,
                      'vendor_assemblies_executed': False, 'engineer_started': False,
                      'plc_connected': False, 'plc_downloaded': False,
                      'scope': 'MCP discovery/catalog and disabled execution gate only; not live ACI roundtrip'}
            output = root / 'artifacts/aci-analysis/reference-mcp-check.json'
            output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps({'status': 'passed', 'tool_count': len(tools.tools), 'aci_used': False}))


if __name__ == '__main__':
    asyncio.run(main())
