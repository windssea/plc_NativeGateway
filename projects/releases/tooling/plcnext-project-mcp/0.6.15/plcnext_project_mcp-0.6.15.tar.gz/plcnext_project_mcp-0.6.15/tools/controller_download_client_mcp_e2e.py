"""Fresh NativeGateway copy -> real localhost TCP/TLS tests -> review only.

The sole external operation is explicitly authorized state reading at
192.168.0.8. No operator approval is created; real download is tested as denied.
"""
import asyncio
from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import sys
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

SOURCE = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex')
PIN = '3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863'


async def main():
    root = Path(__file__).resolve().parents[1]
    output = root / 'artifacts/controller-download-client-mcp' / uuid.uuid4().hex
    output.mkdir(parents=True, exist_ok=False)
    foreign = output / 'foreign-cwd'
    foreign.mkdir()
    # Use the existing global workspace so the exact review is accessible from
    # other projects through the already registered MCP launch command.
    workspace = Path('D:/PLCnext-MCP-Workspace')
    source_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    summary = {'status': 'running', 'source': str(SOURCE), 'source_sha256': source_hash,
               'transport': 'MCP stdio', 'workspace': str(workspace),
               'aci_used': False, 'engineer_started': False, 'computer_use_used': False,
               'real_controller_downloaded': False, 'operator_approval_created': False}
    params = StdioServerParameters(command=sys.executable, args=['-I', '-m', 'plcnext_mcp.server'],
        env=dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(workspace)), cwd=str(foreign))

    async def call(client, tool, args, label):
        response = await client.call_tool(tool, args)
        if response.isError:
            raise RuntimeError(str(response.content))
        value = response.structuredContent or json.loads(response.content[0].text)
        (output / f'{label}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return value

    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(params, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=180)) as client:
                    await client.initialize()
                    tools = await client.list_tools()
                    names = {tool.name for tool in tools.tools}
                    assert len(names) >= 34
                    copied = await call(client, 'project_import_copy', {'source_path': str(SOURCE)}, '01-copy')
                    args = {'project_id': copied['project_id'], 'expected_project_sha256': copied['project_sha256']}
                    cold = await call(client, 'project_compile', args, '02-cold')
                    assert cold['compiled'] and not cold['ast_seed_used'] and cold['host']['pous_reparsed'] == 61
                    package = await call(client, 'project_generate_pcwe', args | {'build_job_id': cold['job_id']}, '03-package')
                    assert package['package_complete'] and package['file_count'] == 48
                    package_args = args | {'package_job_id': package['package_job_id']}
                    tests = {}
                    for fault in ('none', 'write_reply_lost', 'readback_corrupt', 'load_reply_lost',
                                  'initial_running', 'rpc_error', 'load_timeout'):
                        result = await call(client, 'project_test_controller_download',
                            package_args | {'fault': fault}, '04-client-' + fault)
                        assert result['peer_thread_stopped'] and result['connection_closed']
                        assert not result['controller_downloaded']
                        if fault == 'none':
                            assert result['status'] == 'loopback_download_passed'
                            assert result['files_verified'] == 48 and result['peer_files_match_package']
                            assert result['load_state_verified'] and result['receipt_persisted']
                        else:
                            assert result['status'] == 'transfer_failed'
                            if fault in ('write_reply_lost', 'readback_corrupt', 'initial_running', 'rpc_error'):
                                assert result['peer_load_calls'] == 0
                        tests[fault] = {key: result.get(key) for key in ('status', 'failure_code', 'outcome_unknown',
                            'files_verified', 'peer_load_calls', 'load_state_verified', 'report_path')}
                    state = await call(client, 'controller_read_state', {'address': '192.168.0.8',
                        'expected_certificate_sha256': PIN, 'timeout_seconds': 10}, '05-device-readonly')
                    # A temporarily unavailable PLC must not invalidate local
                    # transport tests, but its observed result is never hidden.
                    review = await call(client, 'project_prepare_download_review', package_args | {
                        'address': '192.168.0.8', 'expected_certificate_sha256': PIN}, '06-version-impact-review')
                    assert not review['write_authorized'] and review['authorization_status'] == 'awaiting_user_confirmation'
                    reviewed = await call(client, 'project_inspect_download_review', {
                        'project_id': copied['project_id'], 'review_id': review['review_id'],
                        'expected_review_sha256': review['review_sha256']}, '07-revalidated-review')
                    assert reviewed['revalidated_against_current_package']
                    denied = await client.call_tool('project_execute_controller_download', {
                        'project_id': copied['project_id'], 'review_id': review['review_id'],
                        'expected_review_sha256': review['review_sha256']})
                    assert denied.isError and 'operator approval' in str(denied.content)
                    (output / '08-unapproved-execution-denied.json').write_text(json.dumps({
                        'is_error': True, 'message': str(denied.content), 'operator_approval_created': False}, indent=2), encoding='utf-8')
                    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_hash
                    summary.update(status='passed', tools=len(names), project_id=copied['project_id'],
                        project_sha256=copied['project_sha256'], package_job_id=package['package_job_id'],
                        build_job_id=cold['job_id'], pcwe_path=package['pcwe_path'],
                        inventory_sha256=package['inventory_sha256'],
                        review_id=review['review_id'], review_sha256=review['review_sha256'],
                        review_path=review['review_path'], tests=tests,
                        source_untouched=True, source_modified_for_test=False,
                        device_read_status=state['status'], device_state=state.get('plc_base_state'),
                        unapproved_real_execution_rejected=True)
    except BaseException as exc:
        summary.update(status='failed', error=str(exc))
        raise
    finally:
        (output / 'result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'report': str(output / 'result.json'), **{key: value for key, value in summary.items()
              if key != 'tests'}}, ensure_ascii=False))


if __name__ == '__main__':
    asyncio.run(main())
