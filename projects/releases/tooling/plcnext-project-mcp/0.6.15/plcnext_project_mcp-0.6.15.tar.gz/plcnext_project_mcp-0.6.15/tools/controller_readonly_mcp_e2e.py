"""Explicit operator-selected read-only device check through real MCP stdio.

No default target or certificate trust is supplied. No file/service/control
method can be selected by this script or the MCP tool it invokes.
"""
import argparse
import asyncio
import json
import os
from pathlib import Path
import sys
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main(args):
    root = Path(__file__).resolve().parents[1]
    output = root / 'artifacts/controller-readonly-mcp' / uuid.uuid4().hex
    output.mkdir(parents=True, exist_ok=False)
    environment = dict(os.environ)
    environment['PLCNEXT_MCP_WORKSPACE'] = str(output / 'workspace')
    parameters = StdioServerParameters(command=sys.executable,
        args=['-I', '-m', 'plcnext_mcp.server'], env=environment)
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as client:
            await client.initialize()
            tools = await client.list_tools()
            response = await client.call_tool('controller_read_state', {
                'address': args.address, 'port': args.port,
                'expected_certificate_sha256': args.certificate_sha256, 'timeout_seconds': 10})
            if response.isError:
                raise RuntimeError(str(response.content))
            result = response.structuredContent or json.loads(response.content[0].text)
            report = {'transport': 'MCP stdio', 'tools': [tool.name for tool in tools.tools],
                      'controller_read': result, 'engineer_started': False,
                      'aci_used': False, 'computer_use_used': False, 'downloaded': False}
            (output / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps({'report': str(output / 'result.json'), 'status': result['status'],
                              'state': result.get('plc_base_state'), 'commands': result['commands_sent'],
                              'downloaded': False}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--address', required=True)
    parser.add_argument('--certificate-sha256', required=True)
    parser.add_argument('--port', type=int, default=41100)
    asyncio.run(main(parser.parse_args()))
