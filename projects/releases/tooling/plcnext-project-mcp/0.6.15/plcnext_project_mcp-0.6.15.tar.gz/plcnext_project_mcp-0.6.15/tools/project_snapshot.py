"""Offline, read-only PLCnext Engineer PCWEX snapshots (Python standard library).

Usage:
  py tools/project_snapshot.py snapshot project.pcwex snapshot.json --fb NG_ReadAck
  py tools/project_snapshot.py compare before.json after.json result.json

No project extraction, Engineer process, network, or PLC operation is performed.
Hashes cover every archive member; reported variable declarations omit initial
values. A passing comparison establishes saved project structure preservation,
not executable behavior, online values, or a successful Engineer compilation.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile


def digest(data: bytes | str) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def text(data: bytes) -> str:
    return data.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")


def json_hash(value) -> str:
    return digest(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")))


def xml_tree(element):
    """Ignore formatting whitespace, retain element order and all actual values."""
    return [element.tag, sorted(element.attrib.items()), (element.text or "").strip(),
            [xml_tree(child) for child in element]]


def canonical_xml_hash(data: bytes) -> str | None:
    try:
        return json_hash(xml_tree(ET.fromstring(data)))
    except (ET.ParseError, ValueError):
        return None


def strip_comments(source: str) -> str:
    # ST block comments can nest. Preserve quoted strings while removing comments.
    result = []
    i = depth = 0
    while i < len(source):
        if source.startswith("(*", i):
            depth += 1
            i += 2
        elif depth and source.startswith("*)", i):
            depth -= 1
            i += 2
        elif depth:
            result.append("\n" if source[i] == "\n" else " ")
            i += 1
        elif source.startswith("//", i):
            end = source.find("\n", i)
            i = len(source) if end < 0 else end
        elif source[i] in "'\"":
            quote = source[i]
            start = i
            i += 1
            while i < len(source):
                if source[i] == "$":
                    i += 2
                elif source[i] == quote:
                    i += 1
                    if i < len(source) and source[i] == quote:
                        i += 1
                    else:
                        break
                else:
                    i += 1
            result.append(source[start:i])
        else:
            result.append(source[i])
            i += 1
    return "".join(result)


def st_tokens(source: str) -> list[str]:
    """Ignore formatting between tokens, preserve quoted contents exactly."""
    return re.findall(r"'(?:\$[\s\S]|''|[^'])*'|\"(?:\$[\s\S]|\"\"|[^\"])*\"|\w+|:=|=>|<>|<=|>=|\.\.|\*\*|[^\s]", source)


def separate_pragmas(source: str) -> tuple[str, list[str]]:
    tokens = st_tokens(source)
    plain, pragmas = [], []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token != '{':
            plain.append(token)
            index += 1
            continue
        start, depth = index, 1
        index += 1
        while index < len(tokens) and depth:
            depth += (tokens[index] == '{') - (tokens[index] == '}')
            index += 1
        if depth:
            raise ValueError('Unclosed pragma')
        pragmas.append(' '.join(tokens[start:index]))
    return ' '.join(plain), pragmas


def declarations(source: str) -> list[dict]:
    clean = strip_comments(source)
    rows = []
    for section, body in re.findall(r"\b(VAR(?:_\w+)?(?:\s+(?:RETAIN|NON_RETAIN|CONSTANT))*)\b(.*?)\bEND_VAR\b",
                                    clean, flags=re.I | re.S):
        for statement in body.split(";"):
            match = re.fullmatch(r"\s*([\w,\s]+?)(?:\s+AT\s+([^:]+))?\s*:\s*(.*)", statement, re.S)
            if not match:
                if statement.strip():
                    raise ValueError('Unparsed variable declaration; refusing an incomplete snapshot')
                continue
            names, address, type_and_init = match.groups()
            # Engineer may assign {Id('...')} pragmas on import and reserialize
            # all variable worksheets. Keep these IDs separately; they are not
            # part of a variable's IEC data type. Retain every other pragma.
            semantic, pragmas = separate_pragmas(type_and_init)
            meaningful_pragmas = [p for p in pragmas if not re.fullmatch(
                r"\{\s*Id\s*\(\s*'[0-9a-fA-F-]+'\s*\)\s*\}", p)]
            type_parts = semantic.split(":=", 1)
            type_name = re.sub(r"\s+", " ", type_parts[0].strip())
            initializer = type_parts[1].strip() if len(type_parts) > 1 else ''
            ids = [match.group(1) for p in pragmas for match in
                   [re.fullmatch(r"\{\s*Id\s*\(\s*'([0-9a-fA-F-]+)'\s*\)\s*\}", p)] if match]
            for name in names.split(","):
                rows.append({"section": section.upper(), "name": name.strip(), "type": type_name,
                             "address": (address or "").strip(),
                             "initializer_sha256": json_hash(st_tokens(initializer)),
                             "pragmas_sha256": json_hash(meaningful_pragmas),
                             "explicit_id": ids[0] if ids else None})
    return sorted(rows, key=lambda row: (row['section'], row['name']))


def semantic_declarations(rows: list[dict]) -> list[dict]:
    return [{key: value for key, value in row.items() if key != 'explicit_id'} for row in rows]


def calls_for(source: str, instance: str) -> list[dict]:
    clean = strip_comments(source)
    result = []
    for match in re.finditer(r"\b" + re.escape(instance) + r"\s*\(", clean, flags=re.I):
        start = match.end()
        level = 1
        i = start
        quote = None
        while i < len(clean) and level:
            ch = clean[i]
            if quote:
                if ch == "$":
                    i += 2
                    continue
                if ch == quote:
                    quote = None
            elif ch in "'\"":
                quote = ch
            elif ch == "(":
                level += 1
            elif ch == ")":
                level -= 1
            i += 1
        arguments = re.sub(r"\s+", " ", clean[start:i - 1].strip())
        # Avoid disclosing string values if this is reused with another FB.
        safe = re.sub(r"'(?:\$.)*[^']*'|\"[^\"]*\"",
                      lambda m: "<literal-sha256:" + digest(m.group()) + ">", arguments)
        result.append({"arguments_sha256": digest(arguments), "arguments": safe})
    return result


def snapshot(project: Path, selected_fb: str) -> dict:
    # Bind the digest and all parsed members to the same bytes, even if another
    # application replaces a live source file during the investigation.
    project_bytes = project.read_bytes()
    with zipfile.ZipFile(io.BytesIO(project_bytes)) as archive:
        members = {info.filename: archive.read(info) for info in archive.infolist() if not info.is_dir()}
    files = {name: {"bytes": len(data), "sha256": digest(data),
                    "xml_semantic_sha256": canonical_xml_hash(data)}
             for name, data in sorted(members.items())}
    pous = {}
    for name, data in members.items():
        if not name.endswith(".pou/Metadata.meta"):
            continue
        root = ET.fromstring(data)
        prefix = name.removesuffix("Metadata.meta")
        pou = prefix.rstrip("/").rsplit("/", 1)[-1].removesuffix(".pou")
        variables = members.get(prefix + "Variables.var", b"")
        code = members.get(prefix + "Code.st", b"")
        pous[pou] = {"path": prefix, "id": root.findtext("Id"), "kind": root.findtext("Kind"),
                     "metadata_semantic_sha256": canonical_xml_hash(data),
                     "declarations": declarations(text(variables)),
                     "variables_normalized_sha256": digest(text(variables)),
                     "code_normalized_sha256": digest(text(code))}
    if selected_fb not in pous or pous[selected_fb]["kind"] != "FunctionBlock":
        raise ValueError(f"Selected FunctionBlock absent: {selected_fb}")
    references = []
    for caller, details in sorted(pous.items()):
        code = text(members.get(details["path"] + "Code.st", b""))
        for decl in details["declarations"]:
            if decl["type"].casefold() == selected_fb.casefold():
                references.append({"caller": caller, "instance": decl["name"],
                                   "declaration": decl, "calls": calls_for(code, decl["name"])})
    tasks = {}
    datalists = {}
    for name, data in members.items():
        if name.endswith("EsmConfiguration.esmc"):
            root = ET.fromstring(data)
            tasks[name] = {"semantic_sha256": canonical_xml_hash(data),
                           "esms": [dict(e.attrib) for e in root.findall("./Esms/Esm")],
                           "tasks": [{"attributes": dict(t.attrib),
                                      "program_instances": [dict(p.attrib) for p in t.findall("./ProgramInstances/ProgramInstance")]}
                                     for t in root.findall("./Tasks/Task")]}
        if name.endswith("DataList.dl"):
            root = ET.fromstring(data)
            datalists[name] = {
                "semantic_sha256": canonical_xml_hash(data),
                "tag_counts": dict(sorted(Counter(e.tag for e in root.iter()).items())),
                "role_types": dict(sorted(Counter(e.get("TypeName") for e in root.iter("Role")).items())),
                "datum": [{"uuid": d.get("Uuid"), "semantic_sha256": json_hash(xml_tree(d)),
                           "roles": [{"attributes": dict(r.attrib),
                                      "fields": {k: r.findtext(k) for k in ("Name", "DataType", "Usage", "Address", "RoleDatumUuid", "Program", "ProgramInstance", "ComponentInstance") if r.find(k) is not None}}
                                     for r in d.findall("Role")]}
                          for d in root.findall("./DataList/Datum")]}
    # Data content is represented only as hashes, never configuration values.
    protected_files = {name: files[name]["xml_semantic_sha256"] or digest(text(data))
                       for name, data in members.items()
                       if name.endswith(("GlobalVariables.var", "IOConfiguration.ioc", ".ds", ".plmc", ".dlr4var", ".dlr4hmi", ".hmivar", ".dt"))}
    return {"schema": 2, "created_utc": datetime.now(timezone.utc).isoformat(),
            "source_path": str(project.resolve()), "archive_sha256": digest(project_bytes),
            "selected_fb": selected_fb, "files": files, "pous": dict(sorted(pous.items())),
            "selected_references": references, "tasks": tasks, "datalists": datalists,
            "protected_files": dict(sorted(protected_files.items())),
            "limitations": ["Saved structure only; successful compile must be established independently via Engineer.",
                            "ST declaration and call parsing is a bounded parser, not a complete IEC compiler.",
                            "No online state or PLC behavior is observed."]}


def compare(before: dict, after: dict) -> dict:
    if before['schema'] != 2 or after['schema'] != 2:
        raise ValueError('Regenerate both snapshots with schema 2 before comparing')
    selected = before["selected_fb"]
    checks = {"same_selected_fb": selected == after["selected_fb"],
              "same_pou_set": set(before["pous"]) == set(after["pous"]),
              "selected_instances_and_call_arguments_preserved": [
                  {**ref, 'declaration': semantic_declarations([ref['declaration']])[0]}
                  for ref in before['selected_references']] == [
                  {**ref, 'declaration': semantic_declarations([ref['declaration']])[0]}
                  for ref in after['selected_references']],
              "tasks_and_program_instances_preserved": before["tasks"] == after["tasks"],
              "datalist_variable_and_port_mappings_preserved": before["datalists"] == after["datalists"],
              "global_variables_io_hmi_types_devices_preserved": before["protected_files"] == after["protected_files"]}
    pou_changes = {}
    for name in sorted(set(before["pous"]) | set(after["pous"])):
        old, new = before["pous"].get(name), after["pous"].get(name)
        if old is None or new is None:
            pou_changes[name] = {"added_or_removed": True}
            continue
        fields = [k for k in old if old[k] != new.get(k)]
        if fields:
            pou_changes[name] = {"changed_fields": fields}
        checks[f"pou:{name}:identity_and_declarations_preserved"] = (
            all(old[k] == new[k] for k in ('id', 'kind')) and
            semantic_declarations(old['declarations']) == semantic_declarations(new['declarations']))
        old_ids = {(row['section'], row['name']): row['explicit_id']
                   for row in old['declarations'] if row['explicit_id']}
        new_ids = {(row['section'], row['name']): row['explicit_id']
                   for row in new['declarations'] if row['explicit_id']}
        checks[f"pou:{name}:existing_explicit_variable_ids_preserved"] = all(
            new_ids.get(key) == value for key, value in old_ids.items())
        if name != selected:
            checks[f"pou:{name}:code_preserved"] = old["code_normalized_sha256"] == new["code_normalized_sha256"]
    expected_code_changed = (before["pous"][selected]["code_normalized_sha256"] !=
                             after["pous"].get(selected, {}).get("code_normalized_sha256"))
    file_changes = []
    for name in sorted(set(before["files"]) | set(after["files"])):
        old, new = before["files"].get(name), after["files"].get(name)
        if old != new:
            file_changes.append({"path": name, "change": "added" if old is None else "removed" if new is None else "modified",
                                 "xml_semantically_equal": bool(old and new and old.get("xml_semantic_sha256") and old["xml_semantic_sha256"] == new["xml_semantic_sha256"])})
    return {"schema": 2, "before_archive_sha256": before["archive_sha256"],
            "after_archive_sha256": after["archive_sha256"], "selected_fb": selected,
            "all_preservation_checks_passed": all(checks.values()),
            "selected_fb_code_changed": expected_code_changed,
            "checks": checks, "pou_changes": pou_changes, "file_changes": file_changes,
            "limitations": before["limitations"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    snap = commands.add_parser("snapshot")
    snap.add_argument("project", type=Path)
    snap.add_argument("output", type=Path)
    snap.add_argument("--fb", default="NG_ReadAck")
    diff = commands.add_parser("compare")
    diff.add_argument("before", type=Path)
    diff.add_argument("after", type=Path)
    diff.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.command == "snapshot":
        result = snapshot(args.project, args.fb)
    else:
        result = compare(json.loads(args.before.read_text(encoding="utf-8")),
                         json.loads(args.after.read_text(encoding="utf-8")))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if args.command == "snapshot":
        print(json.dumps({"output": str(args.output.resolve()), "archive_sha256": result["archive_sha256"],
                          "pou_count": len(result["pous"]), "selected_fb": args.fb,
                          "selected_references": result["selected_references"]}, ensure_ascii=False))
    else:
        print(json.dumps({"output": str(args.output.resolve()), "all_preservation_checks_passed": result["all_preservation_checks_passed"],
                          "selected_fb_code_changed": result["selected_fb_code_changed"],
                          "changed_file_count": len(result["file_changes"])}))
        return 0 if result["all_preservation_checks_passed"] else 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
