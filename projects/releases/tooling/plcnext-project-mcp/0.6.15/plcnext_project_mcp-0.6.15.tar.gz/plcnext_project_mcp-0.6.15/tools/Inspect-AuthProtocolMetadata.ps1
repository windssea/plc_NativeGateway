param([string]$Install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0',[string]$Output='D:\work\code\PLCnext-Engineer-mcp\artifacts\plc-download-research\auth\protocol-metadata.json')
$ErrorActionPreference='Stop'
[void][Reflection.Assembly]::LoadFrom((Join-Path $Install 'Mono.Cecil.dll'))
$results=@()
foreach($name in @('Ade.CommonRemoting.Commons.dll','Arp.Base.Rsc.Commons.dll','Arp.System.Rsc.Services.dll','Ade.Online.CommonRemoting.dll')) {
 $path=Join-Path $Install $name
 $module=[Mono.Cecil.ModuleDefinition]::ReadModule($path)
 try {
 $types=@($module.Types | Where-Object {$_.Name -match 'AuthenticationError|SecurityToken|CommandHeader|CommandType|RemotingVersion|Compability|PasswordAuthentication|SecurityProtocol'})
 $results+=@{name=$name;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();mvid=$module.Mvid.ToString();types=@($types|ForEach-Object{@{name=$_.FullName;token=('0x{0:x8}' -f $_.MetadataToken.ToUInt32());is_value_type=$_.IsValueType;packing_size=$_.PackingSize;class_size=$_.ClassSize;fields=@($_.Fields|ForEach-Object{@{name=$_.Name;type=$_.FieldType.FullName;offset=$_.Offset;constant=$(if($_.HasConstant){$_.Constant}else{$null})}});attributes=@($_.CustomAttributes|ForEach-Object{@{type=$_.AttributeType.FullName;arguments=@($_.ConstructorArguments|ForEach-Object{[string]$_.Value})}})}})}
 } finally {$module.Dispose()}
}
$results|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $Output -Encoding utf8
