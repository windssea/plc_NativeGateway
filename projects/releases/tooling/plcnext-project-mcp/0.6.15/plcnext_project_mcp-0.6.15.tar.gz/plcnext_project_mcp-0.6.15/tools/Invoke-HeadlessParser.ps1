# Compatibility entry for the research command; the packaged MCP host is canonical.
& (Join-Path $PSScriptRoot '..\src\plcnext_mcp\parser_host\Invoke-HeadlessParser.ps1') @args
exit $LASTEXITCODE
