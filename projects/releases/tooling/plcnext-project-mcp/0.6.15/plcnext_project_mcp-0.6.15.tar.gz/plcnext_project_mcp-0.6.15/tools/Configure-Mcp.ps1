#requires -Version 7.0
<#
.SYNOPSIS
Print a portable MCP stdio configuration, optionally saving a new JSON file.
.DESCRIPTION
Uses an installed package and an absolute Python executable. Python isolated mode
prevents the caller's working directory or PYTHONPATH from selecting another module.
No global client configuration is changed; existing output files are never replaced.
#>
[CmdletBinding()]
param(
    [string]$PythonPath,
    [string]$Workspace,
    [string]$EngineerDirectory,
    [string]$OutputPath
)

$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (-not $PythonPath) { $PythonPath = Join-Path $repository '.venv\Scripts\python.exe' }
$python = [IO.Path]::GetFullPath($PythonPath)
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw "Python executable not found: $python. Install the package in a Python 3.11+ environment and pass -PythonPath."
}
if ($OutputPath) {
    $output = [IO.Path]::GetFullPath($OutputPath)
    if (Test-Path -LiteralPath $output) { throw "Refusing to replace existing configuration: $output" }
    if (-not (Test-Path -LiteralPath ([IO.Path]::GetDirectoryName($output)) -PathType Container)) {
        throw "Output directory does not exist: $([IO.Path]::GetDirectoryName($output))"
    }
}

# A bounded import probe is enough to catch a missing package/dependency. It does
# not start the MCP service, Engineer, compilation or controller access.
$probe = [Diagnostics.ProcessStartInfo]::new()
$probe.FileName = $python
$probe.ArgumentList.Add('-I')
$probe.ArgumentList.Add('-c')
$probe.ArgumentList.Add('import json, plcnext_mcp.server as s; from plcnext_mcp.headless import DEFAULT_INSTALL; print(json.dumps({"server": s.__file__, "default_install": DEFAULT_INSTALL}))')
$probe.WorkingDirectory = [IO.Path]::GetTempPath()
$probe.CreateNoWindow = $true
$probe.UseShellExecute = $false
$probe.RedirectStandardOutput = $true
$probe.RedirectStandardError = $true
$process = [Diagnostics.Process]::Start($probe)
try {
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit(15000)) {
        $process.Kill($true)
        throw 'Python package import check exceeded 15 seconds.'
    }
    if ($process.ExitCode -ne 0) {
        throw "Cannot import installed plcnext_mcp.server with $python. Install this project into that environment first.`n$($stderr.Result)"
    }
    $installed = $stdout.Result | ConvertFrom-Json
} finally { $process.Dispose() }

if (-not $Workspace) {
    $Workspace = if ($env:PLCNEXT_MCP_WORKSPACE) { $env:PLCNEXT_MCP_WORKSPACE }
                 else { Join-Path ([Environment]::GetFolderPath('UserProfile')) 'PLCnext-MCP-Workspace' }
}
if (-not $EngineerDirectory) {
    $EngineerDirectory = if ($env:PLCNEXT_ENGINEER_DIRECTORY) { $env:PLCNEXT_ENGINEER_DIRECTORY }
                         else { $installed.default_install }
}
$configuration = [ordered]@{
    mcpServers = [ordered]@{
        'plcnext-project' = [ordered]@{
            command = $python
            args = @('-I', '-m', 'plcnext_mcp.server')
            env = [ordered]@{
                PLCNEXT_MCP_WORKSPACE = [IO.Path]::GetFullPath($Workspace)
                PLCNEXT_ENGINEER_DIRECTORY = [IO.Path]::GetFullPath($EngineerDirectory)
            }
        }
    }
}
$json = $configuration | ConvertTo-Json -Depth 6
if ($OutputPath) {
    # CreateNew also protects against another process creating the file after the
    # earlier existence check. UTF-8 without BOM works with JSON client readers.
    $stream = [IO.File]::Open($output, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes($json + [Environment]::NewLine)
        $stream.Write($bytes, 0, $bytes.Length)
    } finally { $stream.Dispose() }
    Write-Verbose "Created $output"
}
Write-Verbose "Verified installed module: $($installed.server)"
$json
