"""Archive exactly the prepared synchronous observation lease; PLC reads only, no device control."""
import asyncio,json,os,sys,tempfile
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
async def main():
    root=Path(__file__).resolve().parents[1];folder=root/'artifacts/sync-observation-research'
    prepared=json.loads((folder/'public-result.json').read_bytes())
    assert prepared['plan']['execution_id']=='6a0c9cb6865146a189538b80e2508bbe'
    assert prepared['plan']['plan_sha256']=='99a8c44a2c2718b9329cfc92e9fa64a209b5d8f0e2919fe15b9d01b77a2bde31'
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']='D:/PLCnext-MCP-Workspace'
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    async with stdio_client(params) as (r,w):
        async with ClientSession(r,w) as session:
            await session.initialize()
            async def call(name,args):
                v=await session.call_tool(name,args)
                if v.isError:raise RuntimeError(str(v.content))
                return v.structuredContent or json.loads(''.join(x.text for x in v.content if x.type=='text'))
            checked=await call('project_inspect_lease_reconciliation',prepared['inspect_arguments'])
            if checked['status']!='reconciled':
                issued=await call('project_authorize_controller_operation',prepared['authorize_arguments'])
                (folder/'authorization-result.json').write_text(json.dumps(issued,ensure_ascii=False,indent=2),encoding='utf-8')
            result=await call('project_execute_lease_reconciliation',prepared['execute_arguments'])
            assert result['status']=='reconciled' and result['controller_mutations'] is False
            (folder/'execution-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':asyncio.run(main())
