#requires -Version 7.0
<#
.SYNOPSIS
Inspect, or interactively approve, the frozen original-project recovery plan.
.DESCRIPTION
Run manually in the operator's terminal. Without -Issue this only inspects.
Even -Issue never contacts PLCs: it displays the exact plan and requires the
human's typed hash, confirmation reference and impact acceptance. No --yes mode.
#>
[CmdletBinding()]
param([switch]$Issue)
$ErrorActionPreference='Stop'
$taskOperatorCommand=if ($Issue) { 'issue' } else { 'inspect' }
& (Join-Path $PSScriptRoot 'Operator-Approval.ps1') `
  -Command $taskOperatorCommand -Kind recovery `
  -ProjectId '17ae4361baa846868b14775bf1de15ea' `
  -ReviewId 'b5394f7a512c4c94b2a5836f9abc7671' `
  -ReviewSha256 '0b977fedac3979549b95f9686de48809a8eb82398a29471c62368ec6e19dc3bc' `
  -Workspace 'D:\PLCnext-MCP-Workspace' -LifetimeSeconds 900
