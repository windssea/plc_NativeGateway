"""Final offline MCP package/ABI/simulation proof and withdrawal of incomplete drafts."""
import argparse,asyncio,hashlib,json,os,pathlib,sys
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def run(args):
    args.output.mkdir(parents=True,exist_ok=True)
    env={**os.environ,'PLCNEXT_MCP_WORKSPACE':str(args.workspace),'PLCNEXT_MCP_RELEASE_ROOT':str(args.releases)}
    records=[]; checks=[]
    async with stdio_client(StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env)) as (reader,writer):
      async with ClientSession(reader,writer) as session:
        await session.initialize()
        async def call(name,values):
            reply=await session.call_tool(name,values)
            if reply.isError:raise RuntimeError(str(reply.content))
            data=json.loads(next(c.text for c in reply.content if c.type=='text'))
            path=args.output/(f'{len(records):02d}-'+name+'.json')
            path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            records.append({'tool':name,'path':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
            print(name,data.get('status','recorded'),flush=True);return data
        await call('server_capabilities',{})
        for number in (4,5):
            await call('project_release_block',{'target':'AXCF1252','version':f'native-0.8.2-dev.{number}.3c4e8564a1d6e649',
                'reason':'Withdrawn offline development candidate: HMI under Services/Ehmi was incorrectly omitted. No device download occurred. Corrected complete package uses dev.6; retain all original artifacts and receipts.'})
        for target,directory in [('1252',args.accepted1252),('2152',args.accepted2152)]:
            project=json.loads((directory/'project_release_prepare_dev.json').read_text(encoding='utf-8'))['managed_project']
            package=json.loads((directory/'project_generate_pcwe.json').read_text(encoding='utf-8'))
            build=json.loads((directory/'project_compile.json').read_text(encoding='utf-8'))
            values={'project_id':project['project_id'],'expected_project_sha256':project['project_sha256'],'package_job_id':package['package_job_id']}
            header=await call('deployment_inspect_native_image',{'image_path':build['image_path'],'expected_sha256':build['image_sha256']})
            await call('project_download_plan',values)
            simulation=await call('project_simulate_download',{**values,'protocol_profile':'v4_tagged'})
            assert simulation['status']=='simulation_passed' and not simulation['controller_downloaded']
            checks.append({'target':target,'image_processor':header['processor_type'],'program_model':header['program_model'],
                'simulated_configuration_loaded':simulation['simulated_configuration_loaded'],'controller_downloaded':False})
        inventory=await call('project_release_inventory',{})
        assert all(not r['deployment_attempts'] for r in inventory['releases'])
    old=args.engineer/'projects/variants/native-0.8.1-axcf1252/PCWE'
    package=json.loads((args.accepted1252/'project_generate_pcwe.json').read_text(encoding='utf-8'))
    new=pathlib.Path(package['pcwe_path'])
    paths=lambda root:{p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    missing=sorted(paths(old)-paths(new));extra=sorted(paths(new)-paths(old))
    assert not missing and extra==['dlc.bin'],(missing,extra)
    configuration='Services/Ehmi/ehmi/webserver.configuration.json'
    assert json.loads((old/configuration).read_text(encoding='utf-8-sig'))==json.loads((new/configuration).read_text(encoding='utf-8-sig'))
    assert json.loads((new/configuration).read_text())['WebServer']['AuthenticationProtocol']==2
    (args.output/'summary.json').write_text(json.dumps({'passed':True,'calls':records,'device_chains':checks,
        'missing_1252_files':missing,'additional_1252_files':extra,'hmi_authentication_protocol_preserved':2,
        'controller_access':False,'computer_use':False},indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('workspace','releases','engineer','accepted1252','accepted2152','output'):p.add_argument('--'+name,type=pathlib.Path,required=True)
    asyncio.run(run(p.parse_args()))
