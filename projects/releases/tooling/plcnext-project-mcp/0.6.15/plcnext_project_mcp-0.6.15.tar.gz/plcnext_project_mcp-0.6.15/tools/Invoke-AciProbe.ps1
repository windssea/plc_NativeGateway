param(
    [string]$InstallDirectory = 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0',
    [int]$Port = 31172,
    [string]$OutputPath = (Join-Path $PSScriptRoot '..\artifacts\aci-poc\aci-status.json')
)
$ErrorActionPreference = 'Stop'
$aciResult = [ordered]@{
    timestamp = [DateTimeOffset]::Now.ToString('o')
    operation = 'offline_aci_availability'
    install_directory = $InstallDirectory
    port = $Port
    host_runtime = [System.Runtime.InteropServices.RuntimeInformation]::FrameworkDescription
    status = 'not_started'
    plc_operations = @()
}
$aciResolver = [System.ResolveEventHandler]{
    param($sender, $eventArgs)
    $assemblyFile = Join-Path $InstallDirectory (([System.Reflection.AssemblyName]::new($eventArgs.Name)).Name + '.dll')
    if (Test-Path -LiteralPath $assemblyFile) {
        return [System.Reflection.Assembly]::LoadFrom($assemblyFile)
    }
    return $null
}
[AppDomain]::CurrentDomain.add_AssemblyResolve($aciResolver)
$aciClient = $null
try {
    $aciContractPath = Join-Path $InstallDirectory 'Ade.ApplicationControl.dll'
    $aciClientPath = Join-Path $InstallDirectory 'Ade.ApplicationControl.ClientImpl.dll'
    [void][System.Reflection.Assembly]::LoadFrom($aciContractPath)
    [void][System.Reflection.Assembly]::LoadFrom($aciClientPath)
    Add-Type -Path (Join-Path $PSScriptRoot 'AciOfflineProbe.cs') -ReferencedAssemblies @($aciContractPath, $aciClientPath) -CompilerOptions '/nowarn:1701'
    $aciClient = [AciOfflineProbe]::new($Port)
    $aciResult.response = $aciClient.ReadStatus()
    $aciResult.available = $aciResult.response.StartsWith('Available=True;')
    $aciResult.state_flags = @((($aciResult.response -split '; States=', 2)[1] -split ', '))
    $aciResult.status = if ($aciResult.available) { 'available' } else { 'unavailable' }
}
catch {
    $aciResult.status = 'failed'
    $aciResult.errors = @()
    $aciError = $_.Exception
    while ($null -ne $aciError) {
        $aciResult.errors += [ordered]@{ type = $aciError.GetType().FullName; message = $aciError.Message }
        $aciError = $aciError.InnerException
    }
}
finally {
    if ($null -ne $aciClient) { $aciClient.Dispose() }
    [AppDomain]::CurrentDomain.remove_AssemblyResolve($aciResolver)
    $aciOutputAbsolute = [IO.Path]::GetFullPath($OutputPath)
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($aciOutputAbsolute))
    $aciResult | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $aciOutputAbsolute -Encoding utf8
    $aciResult | ConvertTo-Json -Depth 8
}
if ($aciResult.status -eq 'failed') { exit 1 }
if ($aciResult.status -eq 'unavailable') { exit 2 }
