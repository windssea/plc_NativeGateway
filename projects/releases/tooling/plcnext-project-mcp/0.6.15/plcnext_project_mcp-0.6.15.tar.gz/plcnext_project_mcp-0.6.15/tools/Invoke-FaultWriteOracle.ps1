param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputDirectory){throw 'Fresh oracle output directory required.'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
foreach($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Arp.System.Rsc.Services')){[void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name+'.dll')))}
$flags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
function T($name){foreach($a in [AppDomain]::CurrentDomain.GetAssemblies()){$type=$a.GetType($name,$false);if($null -ne $type){return $type}};throw "Missing type $name"}
function N($type,$constructArgs){[Activator]::CreateInstance($type,$flags,$null,[object[]]$constructArgs,$null)}
$formatter=T 'Ade.CommonRemoting.Internal.RemotingFormatter';$formatter4=T 'Ade.CommonRemoting.Internal.RemotingFormatter4'
$marshalType=T 'Ade.CommonRemoting.AdeMarshalType';$version=[Enum]::ToObject((T 'Ade.CommonRemoting.RemotingVersion'),4)
$streamType=T 'Ade.CommonRemoting.Internal.RemotingStream';$headerType=T 'Ade.CommonRemoting.CommandHeader'
$script:vectors=@()
function Stream($memory){$s=N $streamType @($memory,[object]::new(),$false);$streamType.GetProperty('RemotingVersion',$flags).SetValue($s,$version);$streamType.GetProperty('HasDataTagging',$flags).SetValue($s,$true);return $s}
function Call($method,$arguments){
 $properties=[Collections.Hashtable]::new();$inputs=[Collections.Generic.List[object]]::new();$outputs=[Collections.Generic.List[object]]::new()
 foreach($parameter in $method.GetParameters()){$attributes=[object[]]$parameter.GetCustomAttributes($false);$marshal=$formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attributes));if($parameter.IsOut){$outputs.Add($marshal)}else{$inputs.Add($marshal)}}
 if($method.ReturnType -ne [void]){$attributes=[object[]]$method.ReturnParameter.GetCustomAttributes($false);$outputs.Add($formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attributes)))}
 $properties['AdeInMarshalling']=[Array]::CreateInstance($marshalType,$inputs.Count);$properties['AdeOutMarshalling']=[Array]::CreateInstance($marshalType,$outputs.Count)
 for($i=0;$i -lt $inputs.Count;$i++){$properties['AdeInMarshalling'].SetValue($inputs[$i],$i)}
 for($i=0;$i -lt $outputs.Count;$i++){$properties['AdeOutMarshalling'].SetValue($outputs[$i],$i)}
 N (T 'Ade.CommonRemoting.Internal.CallMessage') @($method,[object[]]$arguments,$properties)
}
function Save($name,$raw,$details){$file=Join-Path $OutputDirectory ($name+'.bin');[IO.File]::WriteAllBytes($file,$raw);$script:vectors+=@{name=$name;hex=[Convert]::ToHexString($raw).ToLowerInvariant();bytes=$raw.Length;sha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant();details=$details}}
function Emit($name,$methodName,$arguments,$returnValue){
 $method=$data.GetMethod($methodName);$id=($method.GetCustomAttributesData()|Where-Object {$_.AttributeType.Name -eq 'RscMethodAttribute'}).ConstructorArguments[0].Value
 $call=Call $method $arguments;$memory=[IO.MemoryStream]::new()
 [void]$formatter4.GetMethod('SerializeMessage',$flags).Invoke($null,[object[]]@([int16]$id,[int16]41,[int16]5,$call,(Stream $memory),$version))
 Save ($name+'-request') $memory.ToArray() @{method=$methodName;method_id=$id;original_serialize_message=$true}
 $header=[Activator]::CreateInstance($headerType)
 foreach($entry in @{Version=[byte]4;Flags=[byte]64;CommandType=[Enum]::ToObject((T 'Ade.CommonRemoting.CommandType'),3);ServiceHandle=[int16]41;MethodHandle=[int16]$id;ServiceProviderHandle=[int16]5}.GetEnumerator()){$headerType.GetProperty($entry.Key).SetValue($header,$entry.Value)}
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory)
 $write=$headerType.GetMethods($flags)|Where-Object {$_.Name -eq 'Write' -and $_.GetParameters()[2].ParameterType -eq [bool]};[void]$write.Invoke($null,[object[]]@($header,$writer,$true))
 $tag=$call.GetType().GetProperty('ReturnTag',$flags).GetValue($call)
 [void]$formatter.GetMethod('SerializeValue',$flags).Invoke($null,[object[]]@($tag,$returnValue,$writer,$version,$true,$false))
 $writer.Write([byte]255);$writer.Flush();$raw=$memory.ToArray();$memory.Position=0
 [void]$formatter4.GetMethod('DeserializeMessage',$flags).Invoke($null,[object[]]@((Stream $memory),$call,$version))
 if($memory.Position-ne$memory.Length){throw 'Original response reader left bytes'}
 Save ($name+'-response') $raw @{method=$methodName;method_id=$id;original_reader_consumed_all=$true}
}
$data=T 'Arp.Plc.Gds.Services.IDataAccessService';$itemType=T 'Arp.Plc.Gds.Services.WriteItem';$errorType=T 'Arp.Plc.Gds.Services.DataAccessError'
function Item($name,$value){$item=[Activator]::CreateInstance($itemType);$itemType.GetField('PortName').SetValue($item,'Arp.Plc.Eclr/MainInstance.McpFault.'+$name);$itemType.GetField('Value').SetValue($item,$value);return $item}
$cases=@(@('RequestBootId','PUBLIC-boot'),@('RequestKind',[uint16]2),@('RequestTtlMs',[uint32]300000),@('RequestDeadlineMs',[uint64]1234567890123),@('RequestId',[uint32]17),@('CommitId',[uint32]17),@('CancelId',[uint32]17))
foreach($case in $cases){Emit $case[0] 'WriteSingle' ([object[]]@((Item $case[0] $case[1]))) ([Enum]::ToObject($errorType,0))}
$items=[Array]::CreateInstance($itemType,2);$items.SetValue((Item 'RequestKind' ([uint16]2)),0);$items.SetValue((Item 'RequestTtlMs' ([uint32]300000)),1)
$errors=[Array]::CreateInstance($errorType,2);$errors.SetValue([Enum]::ToObject($errorType,0),0);$errors.SetValue([Enum]::ToObject($errorType,3),1)
Emit 'write-two' 'Write' ([object[]]@(,$items)) $errors
@{schema='plcnext-fault-write-original-oracle/v1';scope='Original tagged WriteItem/variant request and error reply MemoryStream only; no services invoked';network_operations=0;aci_calls=0;engineer_started=$false;vectors=$script:vectors;assemblies=@('Arp.Base.Rsc.Commons.dll','Ade.CommonRemoting.Commons.dll','Arp.System.Rsc.Services.dll')|ForEach-Object{@{name=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $install $_)).Hash.ToLowerInvariant()}}}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8NoBOM
