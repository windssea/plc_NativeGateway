"""Fresh MCP local preparation against the reported stopped failure. No PLC calls or authorization."""
import asyncio,json,os,sys,tempfile
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    root=Path(__file__).resolve().parents[1];out=root/'artifacts/stopped-recovery-research';out.mkdir(exist_ok=True)
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']='D:/PLCnext-MCP-Workspace'
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    async with stdio_client(params) as (r,w):
        async with ClientSession(r,w) as session:
            await session.initialize()
            async def call(name,args):
                v=await session.call_tool(name,args)
                assert not v.isError,v.content
                return v.structuredContent or json.loads(''.join(x.text for x in v.content if x.type=='text'))
            tools=await session.list_tools();caps=await call('server_capabilities',{})
            assert caps['version']=='0.6.12' and len(tools.tools)==88
            args={'project_id':'8266573fcadd4e118cb2b86995335dc6','execution_id':'0e3b27da8b504c4bb0dce005d38149d0',
                'expected_review_sha256':'92d4b2b254e1ca380861122f07d78f22ec8d8f428f111ff396a223ab69db6330',
                'expected_certificate_sha256':'3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863',
                'restore_project_id':'17ae4361baa846868b14775bf1de15ea',
                'restore_project_sha256':'7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154',
                'restore_package_job_id':'f7fc619d55ba42c091f4ca0efed23e73',
                'expected_configuration':{'version':19,'device_count':50,'point_count':250,'enabled':True},
                'volatile_data_policy':'record_unknown_loss'}
            p=await call('project_prepare_stopped_recovery',args)
            inspect_args=dict(project_id=p['project_id'],plan_id=p['plan_id'],expected_plan_sha256=p['review_sha256'])
            check=await call('project_inspect_stopped_recovery',inspect_args)
            assert check['handoff_evidence_verified'] and not check['controller_connected']
            report={'version':caps['version'],'tool_count':len(tools.tools),'plan':p,
                'prepare_arguments':args,'inspect_arguments':inspect_args,
                'authorize_arguments':dict(project_id=p['project_id'],review_id=p['plan_id'],expected_review_sha256=p['review_sha256'],kind='recovery',reason='Explicit native-0.5.0 recovery after confirmed Stop and zero transfer; RAM loss unknown'),
                'execute_arguments':inspect_args,'controller_connected':False,'authorization_issued':False,'device_commands_sent':False}
            (out/'public-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps({k:v for k,v in report.items() if k not in ('plan','prepare_arguments','authorize_arguments','execute_arguments')}))

if __name__=='__main__':asyncio.run(main())
