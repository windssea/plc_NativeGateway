param([Parameter(Mandatory)][string]$InputVectors,[Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputDirectory){throw 'New output directory required'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
foreach($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Arp.System.Rsc.Services')){[void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name+'.dll')))}
function T($name){foreach($a in [AppDomain]::CurrentDomain.GetAssemblies()){$t=$a.GetType($name,$false);if($null -ne $t){return $t}};throw "Missing type $name"}
function IoT($name){T ('Arp.System.Commons.Services.Io.'+$name)}
function D($type,$fields){$dto=[Activator]::CreateInstance($type);foreach($key in $fields.Keys){$type.GetField($key).SetValue($dto,$fields[$key])};return ,$dto}
function Traits($items){$a=[Array]::CreateInstance((IoT 'TraitItem'),$items.Count);for($i=0;$i -lt $items.Count;$i++){$item=$items[$i];$value=D (IoT 'TraitItem') @{Trait=[Enum]::ToObject((IoT 'Traits'),[int]$item.trait);Value=[Enum]::ToObject((IoT 'Permissions'),[int]$item.value)};$a.SetValue($value,$i)};return ,$a}
function ResetStreams($value){
 if($value -is [IO.Stream]){$buffer=[IO.MemoryStream]::new();$value.CopyTo($buffer);return ,[IO.MemoryStream]::new($buffer.ToArray())}
 if($value -is [Array]){for($i=0;$i -lt $value.Length;$i++){$value.SetValue((ResetStreams ($value.GetValue($i))),$i)};return ,$value}
 if($null -ne $value -and $value.GetType().Namespace -eq 'Arp.System.Commons.Services.Io' -and -not $value.GetType().IsEnum){foreach($field in $value.GetType().GetFields()){$field.SetValue($value,(ResetStreams ($field.GetValue($value))))}}
 return ,$value
}
$flags=[Reflection.BindingFlags]'Public,NonPublic,Instance,Static'
$marshalType=T 'Ade.CommonRemoting.AdeMarshalType';$versionType=T 'Ade.CommonRemoting.RemotingVersion';$tagType=T 'Ade.CommonRemoting.Internal.TagInfo';$formatter=T 'Ade.CommonRemoting.Internal.RemotingFormatter'
$serialize=$formatter.GetMethod('SerializeValue',$flags);$deserialize=$formatter.GetMethod('DeserializeValue',$flags)
$marshalArgs=[object[]]::new(1);$marshalArgs[0]=[object[]]@()
$defaultMarshal=$formatter.GetMethod('GetMarshalType',$flags).Invoke($null,$marshalArgs)
$results=@();$cases=Get-Content -Raw -LiteralPath $InputVectors|ConvertFrom-Json
foreach($case in $cases){
 foreach($version in @(4)){
  $segments=@();$v=$case.value
  switch($case.kind){
   'read_request'{$type=IoT 'ReadFileInfo';$a=[Array]::CreateInstance($type,$v.Count);for($i=0;$i -lt $v.Count;$i++){$a.SetValue((D $type @{FilePath=[string]$v[$i].path;FileTraits=[Enum]::ToObject((IoT 'Traits'),[int]$v[$i].traits)}),$i)};$segments+=@{type=$a.GetType();value=$a}}
   'read_response'{$type=IoT 'ReadFileData';$a=[Array]::CreateInstance($type,$v.Count);for($i=0;$i -lt $v.Count;$i++){$a.SetValue((D $type @{Result=[Enum]::ToObject((IoT 'FileSystemError'),[int]$v[$i].result);TraitItems=(Traits $v[$i].traits);Data=[IO.MemoryStream]::new([Convert]::FromBase64String($v[$i].data_base64))}),$i)};$segments+=@{type=$a.GetType();value=$a}}
   'errors'{$type=IoT 'FileSystemError';$a=[Array]::CreateInstance($type,$v.Count);for($i=0;$i -lt $v.Count;$i++){$a.SetValue([Enum]::ToObject($type,[int]$v[$i]),$i)};$segments+=@{type=$a.GetType();value=$a}}
   'supported_traits'{$segments+=@{type=(IoT 'Traits');value=[Enum]::ToObject((IoT 'Traits'),[int]$v)}}
   'traits_request'{$segments+=@{type=(IoT 'Traits');value=[Enum]::ToObject((IoT 'Traits'),[int]$v.traits)};$segments+=@{type=[string];value=[string]$v.path}}
   'traits_response'{$type=IoT 'FileSystemTraitsEntry';$entry=D $type @{Path=[string]$v.entry.path;IsFile=[bool]$v.entry.is_file;IsDirectory=[bool]$v.entry.is_directory;Traits=(Traits $v.entry.traits)};$segments+=@{type=$type;value=$entry};$segments+=@{type=(IoT 'FileSystemError');value=[Enum]::ToObject((IoT 'FileSystemError'),[int]$v.result)}}
   'space_request'{$segments+=@{type=[string];value=[string]$v}}
   'space_response'{$type=IoT 'SpaceInfo';$space=D $type @{Capacity=[uint64]$v.space.capacity;Free=[uint64]$v.space.free;Available=[uint64]$v.space.available};$segments+=@{type=$type;value=$space};$segments+=@{type=(IoT 'FileSystemError');value=[Enum]::ToObject((IoT 'FileSystemError'),[int]$v.result)}}
   default{throw "Unknown kind $($case.kind)"}
  }
  $output=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($output)
  foreach($segment in $segments){$tag=[Activator]::CreateInstance($tagType,$flags,$null,[object[]]@($segment.type,$defaultMarshal),$null);$segment.tag=$tag;[void]$serialize.Invoke($null,[object[]]@($tag,$segment.value,$writer,[Enum]::ToObject($versionType,$version),$true,$false))}
  $writer.Flush();$bytes=$output.ToArray();$name=$case.name+'-v'+$version+'.bin';$path=Join-Path $OutputDirectory $name;[IO.File]::WriteAllBytes($path,$bytes)
  $output.Position=0;$reader=[IO.BinaryReader]::new($output);$again=[IO.MemoryStream]::new();$againWriter=[IO.BinaryWriter]::new($again)
  foreach($segment in $segments){$decoded=$deserialize.Invoke($null,[object[]]@($segment.tag,$reader,[Enum]::ToObject($versionType,$version),$true,$false));$decoded=ResetStreams $decoded;[void]$serialize.Invoke($null,[object[]]@($segment.tag,$decoded,$againWriter,[Enum]::ToObject($versionType,$version),$true,$false))}
  $againWriter.Flush()
  if([Convert]::ToHexString($again.ToArray()) -cne [Convert]::ToHexString($bytes)){throw "Roundtrip mismatch $($case.name)"}
  if($output.Position -ne $output.Length){throw 'Unconsumed output'}
  $results += [ordered]@{case=$case.name;kind=$case.kind;version=$version;tagging=$true;file=$name;bytes=$bytes.Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();typed_roundtrip_passed=$true;all_bytes_consumed=$true}
 }
}
[ordered]@{scope='Tagged v4 raw original DTO values and out-then-return sequence; no network/header/handle/handshake';network_operations_performed=0;controller_connected=$false;marshal_value=[int]$defaultMarshal;marshal_name=[string]$defaultMarshal;marshal_rule='RemotingFormatter.GetMarshalType(empty attributes), as RemotingProxy.Init does for parameters without AdeMarshalAs';vectors_sha256=(Get-FileHash -LiteralPath $InputVectors).Hash.ToLowerInvariant();serializer_sha256=(Get-FileHash -LiteralPath (Join-Path $install 'Ade.CommonRemoting.Commons.dll')).Hash.ToLowerInvariant();results=$results}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8
Write-Output "Passed $($results.Count) service value roundtrips"
