"""Actual MCP -> ST/semantic/CIL/native tests on isolated NativeGateway revisions."""
import asyncio
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    root = Path(__file__).resolve().parents[1]
    output = root / 'artifacts/cached-compile-mcp-e2e'
    output.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(output / 'workspace'))
    parameters = StdioServerParameters(command=sys.executable, args=['-m', 'plcnext_mcp.server'], env=environment)
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as client:
            await client.initialize()

            async def call(name, args):
                response = await client.call_tool(name, args)
                if response.isError:
                    raise RuntimeError(str(response.content))
                return response.structuredContent or json.loads(response.content[0].text)

            capabilities = await call('server_capabilities', {})
            assert capabilities['cache_assisted_compile']['available'], capabilities
            imported = await call('project_import_copy', {'source_path': str(root / 'artifacts/aci-poc/NativeGateway.frozen.pcwex')})
            args = {'project_id': imported['project_id'], 'pou_name': 'NG_ReadAck'}

            async def compile_current():
                pou = await call('project_read_pou', args)
                report = await call('project_compile_cached', {'project_id': args['project_id'],
                                                              'expected_project_sha256': pou['project_sha256']})
                print(json.dumps({'revision': report['revision'], 'status': report['status'],
                                  'compiled': report['compiled']}), flush=True)
                return report

            async def replace(old, new):
                pou = await call('project_read_pou', args)
                return await call('project_patch_st', args | {'expected_project_sha256': pou['project_sha256'],
                    'expected_code_sha256': pou['code_sha256'], 'old_text': old, 'new_text': new})

            baseline = await compile_current()
            assert baseline['compiled'] and baseline['backend_exit_code'] == 0, baseline
            old = 'IF NOT Stored AND (count=0) THEN RETURN; END_IF;'
            new = 'IF NOT Stored AND (count=1) THEN RETURN; END_IF;'
            await replace(old, new)
            modified = await compile_current()
            assert modified['compiled'] and modified['backend_exit_code'] == 0, modified
            assert modified['image_sha256'] != baseline['image_sha256']
            await replace(new, new + '\nMcpUndefinedSymbol12345 := 1;')
            invalid_symbol = await compile_current()
            assert not invalid_symbol['compiled'] and invalid_symbol['status'] == 'semantic_failed'
            assert any(m['type_id'] == 'SEM1036' for m in invalid_symbol['host']['semantic']['messages'])
            assert not list(Path(invalid_symbol['job_directory']).rglob('*.img'))
            await replace(new, new + '\nIF THEN END_IF;')
            invalid_syntax = await compile_current()
            assert not invalid_syntax['compiled'] and invalid_syntax['status'] == 'syntax_failed'
            assert not list(Path(invalid_syntax['job_directory']).rglob('*.img'))
            stale = await client.call_tool('project_compile_cached', {'project_id': args['project_id'],
                'expected_project_sha256': modified['project_sha256']})
            assert stale.isError
            # End with the valid count=1 managed code, leaving negative results only in prior revisions.
            current = await call('project_read_pou', args)
            restored = await replace(current['code'], current['code'].replace('\nIF THEN END_IF;', '').replace('\nMcpUndefinedSymbol12345 := 1;', ''))
            validation = await call('project_validate', {'project_id': args['project_id']})
            assert validation['preservation_passed']
            result = {'status': 'passed', 'transport': 'MCP stdio', 'capabilities': capabilities,
                      'baseline': baseline, 'modified_count_one': modified,
                      'undefined_symbol_rejected': invalid_symbol, 'invalid_syntax_rejected': invalid_syntax,
                      'stale_hash_rejected': stale.isError, 'restored_valid_revision': restored,
                      'preservation': validation, 'aci_used': False, 'computer_use_used': False,
                      'plc_connected': False, 'plc_downloaded': False,
                      'scope': 'cache_assisted_NativeGateway_NG_ReadAck_body_only', 'deployable': False}
            (output / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps({'status': 'passed', 'image': modified['image_path'],
                              'stale_rejected': True, 'syntax_rejected': True, 'semantic_rejected': True}), flush=True)


if __name__ == '__main__':
    asyncio.run(main())
