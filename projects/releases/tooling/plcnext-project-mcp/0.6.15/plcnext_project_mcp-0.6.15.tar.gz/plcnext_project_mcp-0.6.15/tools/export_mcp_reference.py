"""Export actual FastMCP tool schemas and a reproducible Chinese reference.

No controller calls, approval issuance, source/project edits or vendor compiler
execution occur. Run with the same installed Python used by the MCP client.
Unknown future tools remain visible with their actual descriptions/parameters;
they are flagged for a human Chinese-scope review rather than silently omitted.
"""
from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path
import sys

from plcnext_mcp import __version__
from plcnext_mcp.server import mcp


NOTES = {
    'project_prepare_sync_observation_reconciliation':('同步启动观察失败核销','传真实execution_id及显式当前源/读计划/boot/配置/外部证据；接受经计划、只读状态和闭合日志证明的skip-Stop。仅新鲜读取准备，不发控制，独立授权后归档精确租约。'),
    'project_prepare_stopped_recovery':('准备停止零写入恢复交接','本地核验旧Stop成功、零传输失败和已消费授权；必须显式选择恢复源/包/配置/RAM策略。返回普通recovery计划，独立授权后原子交接租约并完整恢复。'),
    'project_inspect_stopped_recovery':('检查停止恢复交接','本地重验旧终态、闭合日志、授权和租约字节及新恢复包；不连接PLC。'),
    'project_preflight_recovery_download':('完整下载只读预检','传children.download的review；与实际传输共用路径、旧文件及原生库策略，允许稳定Running或Stop，差异有条数/字节限额。不授权写入。'),
    'project_prepare_reboot':('准备整机重启','绑定源/包/读计划/当前boot/配置及停机影响，纯本地准备；使用reboot授权。'),
    'project_inspect_reboot':('检查整机重启计划','本地核验计划与执行状态，不连接设备。'),
    'project_execute_reboot':('整机重启并确认自动运行','固定RestartDevice只发送一次；有界重连，新boot及连续两次Running/配置/GOOD通过才成功。resume_read_only只读续查，不重发、不补Start。'),
    'project_reboot_status':('查询重启进度','读取本地状态和证据，不连接设备。'),
    'project_cancel_reboot_wait':('取消重启等待','停止后续等待，不撤销已发重启，不补发控制；结果未知保留租约。'),
    'project_prepare_observation_reconciliation':('启动观测失败租约交接','仅控制明确完成的观测失败；绑定当前源、读计划、boot/配置摘要与外部证据，纯只读核对后精确归档。'),
    'project_prepare_parent_audit_reconciliation':('父恢复审计失败核销','仅已结束且控制结果明确的父审计失败；核验fsync文件并只读回查ACK不超出持久化游标。不伪造审计完整、不自动恢复。'),
    'project_prepare_audit_export':('准备独立审计导出','仅完整审计候选；绑定源/包/目标/boot/固定白名单/限额及托管输出目录，不连接PLC。'),
    'project_inspect_audit_export':('检查审计导出计划','本地重验类型、包、输出及限额，不授权。'),
    'project_execute_audit_export':('执行有界审计导出','kind=audit_export授权后，只读原始环并先fsync再确认四个ACK字段；无业务FIFO/控制/下载。保持会话到终态。'),
    'project_audit_export_status':('审计导出状态','本地查看结果；宿主退出报unknown，不自动重启。'),
    'project_cancel_audit_export':('取消审计导出','本地请求在下次I/O边界停止；不撤销已发ACK、不重放。'),
    'project_prepare_sync_lease_reconciliation':('准备同步恢复核销','传 execution_id，不伪造 operation_id；核验已消费授权、完成隔离终态及闭合日志，后续复用核销检查/授权/执行。'),
    'project_prepare_lease_reconciliation':('准备旧租约核销','只接受已结束且结果明确的后台恢复执行；核对旧记录并只读验证 Running、配置和全部 GOOD，不控制设备。'),
    'project_inspect_lease_reconciliation':('检查核销计划','本地重验目标、旧租约/日志/结果哈希及终态；不授权。'),
    'project_execute_lease_reconciliation':('执行受控核销','使用 lease_reconciliation 精确授权；重新只读核验后归档旧租约。可完成中断核销，不重放设备动作。'),
    'server_capabilities':('实际能力和环境','按实现、离线/本机证据、真机证据分别判断；工具存在不表示设备验收通过。'),
    'aci_replacement_status':('ACI 替代状态','只读本地替代账本，不执行 ACI。201 个声明方法不等于全部已替代。'),
    'aci_replacement_methods':('ACI 方法分页','过滤值取自 status 的当前分类；include_details 提供证据/验收缺口。'),
    'project_import_copy':('导入 PCWEX 副本','source_path 是现有文件绝对路径；不覆盖原件，返回新 project_id 和 SHA。'),
    'project_create':('新建独立工程','默认受支持 AXC F 2152 空模板，创建 ST Main 和新身份；不是任意设备模板。'),
    'project_inspect':('查看工程身份和 POU','返回当前修订、POU/工作表 ID 和已知映射成员；不编译。'),
    'project_read_pou':('读取代码、变量及哈希','code/variables 为完整文本；修改前读取 code_sha256、variables_sha256 和工程 SHA。'),
    'project_find_references':('查找 ST 实例/调用','有限源搜索，不是完整编译器符号表或任意外部配置引用证明。'),
    'project_patch_st':('唯一片段替换','old_text 恰好一次，工程/代码双 SHA；只改正文，生成新修订。'),
    'project_update_pous':('原子修改代码/变量接口','每项有 pou_name、两个工作表 SHA，至少 code/variables 之一；完整文本，可同步调用方。'),
    'project_change_fbs':('原子增删 FB 及调用方','add_fbs 为名称和可选完整代码/变量，delete_fbs 为名称数组；最终仍引用时拒绝删除。'),
    'project_add_fb':('新增标准 ST FB','新对象/工作表 ID；不会自动添加调用方实例。'),
    'project_delete_fb':('删除未引用 ST FB','有引用拒绝；同步移除调用/实例请使用 change_fbs。'),
    'project_validate':('结构与成员保留检查','不证明语法、类型、签名、运行映射或功能正确。'),
    'project_diff':('代码差异','对冻结原件的有界 ST diff；max_chars 可能截断。'),
    'project_diff_pou':('代码和变量差异','分别检查完整代码/声明差异，结合 validate 和冷编译。'),
    'project_inspect_tasks':('源任务与实例映射','纳秒时序；不是设备实测。支持查看既有任务，编辑范围以实际 profile 为准。'),
    'project_update_cyclic_task':('修改指定周期任务','可从多任务中按精确 ID 选择，改纳秒周期/看门狗/优先级，保持其他任务和实例。'),
    'project_clone_program':('创建独立 Program','标准 Program 克隆/可选完整代码和变量，新 ID；不自动挂接任务。'),
    'project_change_cyclic_tasks':('周期任务增删','单 eCLR、1..16 周期任务、资源内实例唯一；共享数据保守拒绝或要求明确独占合同。'),
    'project_declare_task_ownership':('重新声明任务所有权','源码/闭包改变后重新检查精确合同；不是任意指针形式化安全证明或共享 FIFO 实现。'),
    'project_build_plan':('冷编译能力预检','支持时返回准确 compile 参数，否则给出具体 unsupported_reason。'),
    'project_check_st':('单工作表语法检查','依赖厂商解析库；不做全工程语义和镜像生成。'),
    'project_compile':('源驱动 IEC 冷编译','支持范围内重建 POU/类型/库/任务，无项目 AST 种子；依赖厂商编译组件。不是完整 PCWE。'),
    'project_compile_cached':('历史缓存实验','固定 NG_ReadAck/样例/种子限制；日常验收使用 project_compile。'),
    'project_compile_nativegateway':('旧构建名称兼容','默认 cold；cached 保留固定样例和种子限制，不用于通用冷编译声明。'),
    'project_deployment_plan':('构建与包缺口分析','build_job_id 使用 compile 返回的 job_id；不生成设备授权。'),
    'project_generate_pcwe':('完整本地 PCWE 候选','限定 NativeGateway 硬件/HMI profile；download_memento_policy 必须明确理解，完整包不等于真机验收。'),
    'deployment_inspect_pcwe':('本地 PCWE 完整性','检查清单/文件 SHA-512；不是设备内存身份或签名兼容证明。'),
    'deployment_stage_pcwe':('本地冻结快照','按 inventory SHA 新建本地快照，不上传；不能冒充当前工程生成包 ID。'),
    'project_download_plan':('下载包计划检查','复核源/布局/清单；本地计划不授予真实写权限。'),
    'project_simulate_download':('内存 TLS 模拟','无 socket；临时测试认证和 tagged/untagged 流程，不证明真实设备权限。'),
    'project_test_controller_download':('本机生产客户端传输测试','只创建 127.0.0.1 随机 TLS 测试端；真实本地文件、SHA-512、Reset/Load；不接受真实地址。'),
    'controller_read_state':('真实设备只读状态','明确字面 IP/端口/证书 pin；仅固定状态服务，没有变量写或启停。'),
    'project_prepare_download_review':('下载版本和影响审阅','精确源/包/目标/策略，不连设备、不发行收据；下载固定动作不包含 Stop/Start。'),
    'project_inspect_download_review':('重验下载审阅','默认重新检查当前源与包，不能通过关闭 revalidate 参数获得权限。'),
    'project_preflight_controller_download':('真实目标只读预检与显式包冻结','默认只读状态/根/空间及两份元数据。verify_package_files=true才按不可变review路径做SHA-512和前后manifest/状态守卫；capture_package_files=true还要求verify并保存新本地窗口一致磁盘快照。响应预算默认32MiB、范围1..64MiB。不会扩展到远端manifest额外路径，不写/控制PLC，不证明内存loaded或可执行回滚。'),
    'project_execute_controller_download':('经确认的真实全包下载','需有效人工或MCP一次性收据、初始 Stop、文件集合策略、回读、Reset/Load；无自动启停/删旧文件/回滚/不确定重试。'),
    'project_inspect_runtime_symbols':('解析源符号/类型','不连接 PLC；源中存在不证明当前已加载版本相同。'),
    'project_prepare_runtime_read':('冻结有限变量读计划','源/类型/目标绑定，最多2048符号、64项分块、1MiB响应、至少5秒间隔；未知字段保持 unsupported。'),
    'project_read_runtime':('真实设备有界只读变量','固定计划、严格数量/类型/错误和前后身份守卫；窗口观察不冒充原子快照/内存镜像认证。'),
    'project_test_runtime_read':('本机在线读取测试','127.0.0.1 测试端；缺项、坏质量、类型错、部分返回和跨boot/config变化按实际 fault 校验。'),
    'project_prepare_controller_control':('独立 Stop/Start 审阅','绑定精确前态、终态、包和启动模式；不同于下载收据，不连设备。'),
    'project_inspect_controller_control':('重验控制审阅','只读本地精确动作/源/包/目标；不批准。'),
    'project_execute_controller_control':('经确认的一次 Stop/Start','人工或MCP控制收据；请求与完成分开，无自动逆动作/重发。独立 Start 缺已加载身份时拒绝。'),
    'project_test_controller_control':('本机控制状态机','生产控制 codec/client 与本机 TLS；覆盖前态、延迟、错误、丢回复和身份。'),
    'project_inspect_operator_approval':('授权生命周期检查','检查四类操作的人工或MCP授权收据，不连接设备。'),
    'project_authorize_controller_operation':('MCP自主授权','MCP自行决定并签发精确限时一次性授权；kind支持download/control/recovery/instrumented_fault，无需人工终端。'),
    'project_prepare_recovery':('显式原工程恢复计划','独立版本化 Stop/下载/回读/Reset/Load/Start/变量核验计划；绑定RAM政策和配置期望，不是自动回滚。'),
    'project_inspect_recovery':('重验恢复及子审阅','重新检查所有源/包/控制/读计划身份；不批准或操作设备。'),
    'project_execute_recovery':('经确认的完整恢复执行','连续端点租约、人工或MCP recovery 收据；严格区分包加载、运行窗口与外部 DATA/STORED/采样验收。'),
    'project_test_recovery':('本机完整恢复验证','仅本机测试端或夹具；每阶段副作用、不确定结果、日志和恢复状态分别记录，不证明真实恢复。'),
    'project_prepare_fault_control':('受限故障审阅','boot/包/TTL绑定；原32POU未提供独立硬截止后端时返回 unsupported，不能借私有写入绕过。'),
    'project_execute_fault_control':('故障执行安全门禁','当前普通原归档缺验证过的独立TTL后端，必须拒绝且不消费收据/不操作目标。'),
    'project_test_fault_supervision':('独立监督进程本机测试','127.0.0.1 子进程监督，含客户端真实退出；本地解除不等于真实 PLC 自TTL已验。'),
    'project_runtime_timing_evidence':('既有收据/探针取证','聚合精确运行读取报告与明确探针合同，不把RPC耗时当任务执行时间，不启动P06或虚称≤1ms/≥90。'),
    'project_start_recovery_job':('启动后台受控恢复作业','复用精确恢复计划与一次性消费门禁，返回operation_id；不是立即完成或批准。连续租约和不确定结果纪律不变。'),
    'project_start_controller_control_job':('启动后台受控控制作业','仅运行既有精确Stop/Start消费者；不接受任意回调、原始RPC或自动重启。'),
    'project_controller_operation_status':('读取本地作业进度','精确operation/review绑定，只读本地状态与可选结果，不访问设备；宿主失效保留outcome_unknown。'),
    'project_cancel_controller_operation':('请求协作取消作业','持久化取消标记，在执行器检查边界生效；不是设备回滚、已发送动作撤销或自动逆控制。'),
    'project_create_fault_profile':('创建独立自TTL故障测试副本','仅精确支持的原归档生成独立插桩Program/profile；不改32POU恢复源，不自动部署或启用场景。'),
    'project_prepare_instrumented_fault':('审阅独立自TTL故障','仅显式profile/source/package/boot绑定和绝对期限；原归档无后端仍拒绝，不与恢复包混用。'),
    'project_inspect_instrumented_fault':('重验自TTL故障审阅','本地检查精确插桩profile、源、包、目标、boot与动作；不批准、不激活。'),
    'project_execute_instrumented_fault':('经确认的自TTL故障执行','独立instrumented_fault收据，窄字段/值与TTL/绝对到期，staging前实读核钟推进，读回激活/解除；仅新版GET_MICROSECONDS(TRUE)/1000核内CLOCK_MONOTONIC profile，旧TON profile拒绝。真实故障需单独授权，真机期限未验。'),
    'project_start_instrumented_fault_job':('启动后台自TTL故障作业','仅独立profile/boot/包/动作审阅及收据的固定消费者；可用作业状态/协作取消，PLC自截止独立于宿主存活。'),
    'project_test_instrumented_fault':('本机自TTL故障验证','独立本机扫描/双端测试，包括Commit后客户端退出和晚启动过期拒绝；不证明真实PLC扫描期限。'),
    'project_prepare_esm_read':('固定ESM系统变量读计划','按当前设备模板/源ESM任务建立白名单和类型，限定ESM[1..2]/TASK[1..16]，不修改原程序、不连接设备。'),
    'project_read_esm':('有界读取ESM时序系统变量','固定类型/范围/目标计划；保持boot/计数重置/窗口和缺字段状态。系统LAST/MAX含抢占，不等于新增业务CPU耗时或P06通过。'),
    'project_test_esm_read':('本机ESM系统变量测试','仅工具自建127.0.0.1；类型、计数、boot、缺项和异常按实际fixture验证，不冒充真实PLC量测。'),
}


def _type(schema):
    if 'anyOf' in schema:
        return ' / '.join(_type(item) for item in schema['anyOf'])
    if 'oneOf' in schema:
        return ' / '.join(_type(item) for item in schema['oneOf'])
    if '$ref' in schema:
        return schema['$ref']
    kind=schema.get('type','object')
    return 'array['+_type(schema.get('items',{}))+']' if kind=='array' else str(kind)


def _cell(value):
    return str(value).replace('|','&#124;').replace('\n','<br>')


def _group(name):
    if name in ('server_capabilities','aci_replacement_status','aci_replacement_methods'):
        return '能力与替代账本'
    if 'operation' in name or 'control_job' in name or 'recovery' in name or 'operator_approval' in name:
        return '操作者审批与显式恢复'
    if 'fault' in name:
        return '有界故障控制与监督'
    if 'runtime' in name or 'timing' in name or 'esm_read' in name or name=='project_read_esm':
        return '运行符号、只读窗口与时序证据'
    if 'controller_control' in name:
        return '受控 Stop / Start'
    if 'download' in name or name=='controller_read_state':
        return '下载、预检和状态'
    if any(word in name for word in ('pcwe','deployment')):
        return 'PCWE 生成与本地快照'
    if any(word in name for word in ('task','clone_program')):
        return '任务与独立 Program'
    if any(word in name for word in ('compile','build_plan','check_st')):
        return '语法、构建和诊断'
    return '工程、POU、代码和接口'


def render_reference(tools,version):
    names={tool['name'] for tool in tools}
    unknown=sorted(names-set(NOTES))
    lines=[f'# PLCnext MCP {version} 全部工具参考','',
        f'本文件由 `tools/export_mcp_reference.py` 从实际 FastMCP `list_tools()` 生成，共 **{len(tools)} 个工具**。参数、默认值与枚举均取自实际 `inputSchema`，不硬编码工具数量。运行时校验可能比 Schema 更严格。','',
        '[使用与测试手册](mcp-user-guide.md) · [M01～M10 联调指南](joint-implementation-user-guide.md) · [机器可读 Schema](mcp-tool-schema.json)','',
        '## 共同约定','',
        '- 本文工具存在、代码已实现、本机通过、真机通过是不同状态。实际交付证据见联调指南和报告。',
        '- 每次编辑使用返回的新 `project_sha256`。POU 批量接口编辑还需各自 `code_sha256` 与 `variables_sha256`。',
        '- `project_compile` 返回 `job_id`，下一步参数叫 `build_job_id`；生成包返回独立 `package_job_id`。',
        '- `review_id/review_sha256` 与运行读取/恢复的 `plan_id/plan_sha256` 都是选择器，不是授权收据。',
        '- 真实写入、控制与恢复需操作者精确确认。普通 MCP 没有批准工具；只读查询和本机测试不能代签。',
        '- `isError=true` 与工具正常返回的失败 `status` 都要检查。结构通过、语法通过、编译通过、包完整、加载/运行及业务通过分别验收。',
        '- 工具注解是客户端提示，不能代替实现中的身份、范围与审批检查。本地只读查询也可能保存报告。','']
    if unknown:
        lines+=['> 本次新增工具尚无独立中文范围批注：'+ '、'.join('`'+name+'`' for name in unknown)+'。以下仍完整列出其实际参数和实现描述；验收状态请按最新报告核对。','']
    groups={}
    for tool in tools:
        groups.setdefault(_group(tool['name']),[]).append(tool)
    for group,items in groups.items():
        lines+=['## '+group,'']
        for tool in items:
            name=tool['name']; purpose,note=NOTES.get(name,('新增工具（实现描述见下文）','中文范围尚待核对，不能据此推断真机通过。'))
            lines+=['### `'+name+'`','',purpose+'。','',note,'']
            schema=tool['inputSchema'];required=schema.get('required',[]);properties=schema.get('properties',{})
            if properties:
                lines+=['| 参数 | 类型 | 必填 | 默认值 |','|---|---|---|---|']
                for key,value in properties.items():
                    default='—' if key in required else '`'+_cell(json.dumps(value.get('default'),ensure_ascii=False))+'`'
                    lines+=['| `'+key+'` | '+_cell(_type(value))+' | '+('是' if key in required else '否')+' | '+default+' |']
                lines+=['']
                for key,value in properties.items():
                    if 'enum' in value:
                        lines+=['`'+key+'` 枚举：'+'、'.join('`'+str(item)+'`' for item in value['enum'])+'。','']
            else:
                lines+=['无参数，传 `{}`。','']
            description=tool.get('description','').strip()
            if description:
                lines+=['实现描述（原始工具说明）：','']
                lines += ['> '+line for line in description.splitlines()]
                lines+=['']
    lines+=['## 嵌套结构与返回值','',
        '`project_update_pous.updates[]` / `project_change_fbs.updates[]` 每项要求 `pou_name`、`expected_code_sha256`、`expected_variables_sha256`，至少提供完整 `code` 或 `variables`。省略的文本保持。','',
        '`add_fbs[]` 为 `pou_name` 和可选 `code/variables`；`delete_fbs[]` 为名称。`add_tasks[]` 及 ownership 请求见 [多任务说明](independent-multitask.md)。','',
        '读取/恢复/时序的嵌套计划和观测身份见 [联调指南](joint-implementation-user-guide.md)，不要猜测字段或把旧报告当新鲜状态。','',
        '没有统一强类型 outputSchema 时，按当前工具返回的 status/诊断、已发送动作、不确定标记及 report_path 检查；不要要求所有工具返回同名 success。','']
    return '\n'.join(lines)+'\n',unknown


async def export(output_directory: Path,check: bool):
    actual=await mcp.list_tools()
    tools=[tool.model_dump(mode='json',exclude_none=True) for tool in actual]
    payload={'schema':'plcnext-mcp-tool-reference/v1','package':'plcnext-project-mcp',
             'version':__version__,'tool_count':len(tools),'generated_from':'FastMCP.list_tools',
             'controller_connected':False,'approval_issued':False,'tools':tools}
    reference,unknown=render_reference(tools,__version__)
    outputs={'mcp-tool-schema.json':json.dumps(payload,ensure_ascii=False,indent=2)+'\n',
             'mcp-tool-reference.md':reference}
    matches={}
    for name,text in outputs.items():
        path=output_directory/name
        matches[name]=path.is_file() and path.read_text(encoding='utf-8')==text
        if not check:
            output_directory.mkdir(parents=True,exist_ok=True)
            path.write_text(text,encoding='utf-8')
    report={'status':'in_sync' if all(matches.values()) else 'out_of_sync' if check else 'generated',
            'version':__version__,'tool_count':len(tools),'outputs':{key:str(output_directory/key) for key in outputs},
            'matched_before_run':matches,'chinese_scope_notes_pending':unknown,
            'controller_connected':False,'approval_issued':False}
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 1 if check and not all(matches.values()) else 0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true',help='Compare only; do not write documentation.')
    parser.add_argument('--output-directory',type=Path,default=Path(__file__).resolve().parents[1]/'docs')
    args=parser.parse_args()
    return asyncio.run(export(args.output_directory.resolve(),args.check))


if __name__=='__main__':
    raise SystemExit(main())
