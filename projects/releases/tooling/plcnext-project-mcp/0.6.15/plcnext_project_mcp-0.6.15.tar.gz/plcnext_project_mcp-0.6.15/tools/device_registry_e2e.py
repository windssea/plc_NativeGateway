"""Synthetic future-profile registration through MCP; never compiles or contacts a PLC."""
import argparse,asyncio,hashlib,json,os,pathlib,sys,zipfile
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def run(args):
    args.output.mkdir(parents=True,exist_ok=True)
    env={**os.environ,'PLCNEXT_MCP_WORKSPACE':str(args.output/'workspace'),
         'PLCNEXT_MCP_RELEASE_ROOT':str(args.output/'release-fixture'),
         'PLCNEXT_MCP_DEVICE_PROFILES_DIRECTORY':str(args.output/'profile-fixture')}
    records=[]
    async with stdio_client(StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env)) as (reader,writer):
      async with ClientSession(reader,writer) as session:
        await session.initialize()
        async def call(name,values,expect_error=False):
            reply=await session.call_tool(name,values)
            assert bool(reply.isError)==expect_error,(name,reply.content)
            value={'expected_rejection':True,'message':str(reply.content)} if expect_error else json.loads(next(x.text for x in reply.content if x.type=='text'))
            path=args.output/(f'{len(records):02d}-'+name+'.json')
            path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            records.append({'tool':name,'path':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'expected_rejection':expect_error})
            print(name,'rejected as expected' if expect_error else value.get('status','recorded'),flush=True)
            return value
        catalog=await call('project_device_profiles',{})
        profile={k:v for k,v in catalog['profiles'][0].items() if k not in ('backend_installed','template_installed')}
        profile.update(profile_id='PUBLIC-FUTURE-2026-v1',device_name='PUBLIC FUTURE PLC',device_type='PUBLIC_FUTURE',template='PUBLIC-FUTURE.pxctx')
        candidate=args.output/'PUBLIC-FUTURE.pcwex'
        with zipfile.ZipFile(args.source) as source,zipfile.ZipFile(candidate,'x') as archive:
            archive.comment=source.comment
            for info in source.infolist():
                data=source.read(info)
                if info.filename=='PROJECT/PROJECT.proj':data=data.replace(b'AXC F 2152',b'PUBLIC FUTURE PLC')
                if info.filename.endswith('/Main.pou/Code.st'):data=data.replace(b'NG-HUB-2152-01',b'PUBLIC-FUTURE-GATEWAY')
                archive.writestr(info,data)
        project=await call('project_import_copy',{'source_path':str(candidate)})
        plan=await call('project_build_plan',{'project_id':project['project_id']})
        assert plan['status']=='unsupported_cold_build'
        registered=await call('project_register_device_profile',{'specification':profile})
        assert registered['requires_independent_compile_package_and_hardware_acceptance']
        plan=await call('project_build_plan',{'project_id':project['project_id']})
        assert plan['capability']['profile_id']==profile['profile_id']
        await call('project_release_register_target',{'device_type':'PUBLIC_FUTURE','address':'192.0.2.30','gateway_id':'PUBLIC-FUTURE-GATEWAY'})
        await call('project_release_prepare_dev',{'project_id':project['project_id'],'expected_project_sha256':project['project_sha256'],
                                                 'base_version':'0.8.2','change_note':'PUBLIC synthetic registration proof; not a real supported hardware device.'})
        await call('project_register_device_profile',{'specification':profile},expect_error=True)
        await call('project_release_register_target',{'device_type':'PUBLIC_FUTURE','address':'192.168.0.8','gateway_id':'PUBLIC-INVALID-GATEWAY'},expect_error=True)
        await call('project_register_device_profile',{'specification':{**profile,'profile_id':'PUBLIC-INVALID','compile_family':'arbitrary_shell'}},expect_error=True)
    (args.output/'summary.json').write_text(json.dumps({'passed':True,'steps':records,'controller_access':False,
        'compiled_synthetic_device':False,'synthetic_device_hardware_support_claimed':False},indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True)
    asyncio.run(run(p.parse_args()))
