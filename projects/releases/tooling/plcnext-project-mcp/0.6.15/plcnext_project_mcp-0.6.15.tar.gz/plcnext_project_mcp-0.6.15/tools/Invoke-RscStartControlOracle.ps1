param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Fresh oracle directory required.' }
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install = 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
# Original formatter and DTO execution only: no services/providers/ACI/network.
foreach ($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Arp.System.Rsc.Services')) {
    [void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name + '.dll')))
}
$flags = [Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
function T($name) {
    foreach ($assembly in [AppDomain]::CurrentDomain.GetAssemblies()) {
        $type = $assembly.GetType($name,$false)
        if ($null -ne $type) { return $type }
    }
    throw "Missing type $name"
}
function N($type,$arguments) { [Activator]::CreateInstance($type,$flags,$null,[object[]]$arguments,$null) }
$formatter = T 'Ade.CommonRemoting.Internal.RemotingFormatter'
$formatter4 = T 'Ade.CommonRemoting.Internal.RemotingFormatter4'
$streamType = T 'Ade.CommonRemoting.Internal.RemotingStream'
$marshalType = T 'Ade.CommonRemoting.AdeMarshalType'
$version = [Enum]::ToObject((T 'Ade.CommonRemoting.RemotingVersion'),4)
$plc = T 'Arp.Plc.Domain.Services.IPlcManagerService'
$kindType = T 'Arp.Plc.Domain.Services.PlcStartKind'
$method = $plc.GetMethod('Start')
$methodId = ($method.GetCustomAttributesData() | Where-Object {$_.AttributeType.Name -eq 'RscMethodAttribute'}).ConstructorArguments[0].Value
if ($methodId -ne 2 -or [Enum]::GetUnderlyingType($kindType) -ne [byte] -or
    $method.ReturnType -ne [void] -or $method.GetParameters().Count -ne 2 -or
    $method.GetParameters()[0].ParameterType -ne $kindType -or $method.GetParameters()[1].ParameterType -ne [bool]) {
    throw 'Unexpected original Start contract.'
}
function Stream($memory) {
    $stream = N $streamType @($memory,[object]::new(),$false)
    $streamType.GetProperty('RemotingVersion',$flags).SetValue($stream,$version)
    $streamType.GetProperty('HasDataTagging',$flags).SetValue($stream,$true)
    return $stream
}
function Call($arguments) {
    $properties = [Collections.Hashtable]::new()
    $inputs = [Array]::CreateInstance($marshalType,2)
    for ($i=0;$i -lt 2;$i++) {
        $attributes = [object[]]$method.GetParameters()[$i].GetCustomAttributes($false)
        $inputs.SetValue($formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attributes)),$i)
    }
    $properties['AdeInMarshalling']=$inputs
    $properties['AdeOutMarshalling']=[Array]::CreateInstance($marshalType,0)
    N (T 'Ade.CommonRemoting.Internal.CallMessage') @($method,[object[]]$arguments,$properties)
}
$vectors=@()
$enumValues=@{}
foreach ($name in [Enum]::GetNames($kindType)) { $enumValues[$name]=[byte][Enum]::Parse($kindType,$name) }
foreach ($name in @('Cold','Warm','Hot','RestoreWarm')) {
    foreach ($async in @($false,$true)) {
        $call=Call @([Enum]::Parse($kindType,$name),$async)
        $memory=[IO.MemoryStream]::new()
        [void]$formatter4.GetMethod('SerializeMessage',$flags).Invoke($null,[object[]]@([int16]2,[int16]41,[int16]5,$call,(Stream $memory),$version))
        $raw=$memory.ToArray()
        $file=Join-Path $OutputDirectory ('start-'+$name.ToLowerInvariant()+'-'+$async.ToString().ToLowerInvariant()+'.bin')
        [IO.File]::WriteAllBytes($file,$raw)
        $vectors+=@{name=$name;start_kind=[byte][Enum]::Parse($kindType,$name);async=$async;hex=[Convert]::ToHexString($raw).ToLowerInvariant();bytes=$raw.Length;sha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant();original_serialize_message=$true}
    }
}
@{schema='plcnext-rsc-start-original-oracle/v1';network_operations=0;aci_calls=0;engineer_started=$false;remoting_version=4;data_tagging=$true;method_id=$methodId;method_token=('0x{0:x8}' -f $method.MetadataToken);enum_underlying_type='System.Byte';enum_values=$enumValues;vectors=$vectors;assemblies=@('Arp.Base.Rsc.Commons.dll','Ade.CommonRemoting.Commons.dll','Arp.System.Rsc.Services.dll')|ForEach-Object {
    $path=Join-Path $install $_
    $assembly=[AppDomain]::CurrentDomain.GetAssemblies()|Where-Object Location -eq $path
    @{name=$_;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();mvid=$assembly.ManifestModule.ModuleVersionId.ToString()}
}} | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8NoBOM
