"""Actual MCP copy/task edit/cold build/PCWE/tagged simulation, no device writes."""
import asyncio
from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import sys
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

SOURCE = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex')


async def main():
    root = Path(__file__).resolve().parents[1]
    output = root / 'artifacts/independent-aci-mcp' / uuid.uuid4().hex
    output.mkdir(parents=True, exist_ok=False)
    foreign = output / 'foreign-cwd'
    foreign.mkdir()
    source_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    summary = {'status': 'running', 'transport': 'MCP stdio', 'source': str(SOURCE),
               'source_sha256': source_hash, 'aci_used': False, 'engineer_started': False,
               'computer_use_used': False, 'controller_connected': False, 'controller_downloaded': False}
    parameters = StdioServerParameters(command=sys.executable, args=['-I', '-m', 'plcnext_mcp.server'],
        env=dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(output / 'workspace')), cwd=str(foreign))

    async def call(client, name, arguments, label):
        response = await client.call_tool(name, arguments)
        if response.isError:
            raise RuntimeError(f'{name}: {response.content}')
        value = response.structuredContent or json.loads(response.content[0].text)
        (output / f'{label}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return value

    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(parameters, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=180)) as client:
                    await client.initialize()
                    tools = await client.list_tools()
                    names = {tool.name for tool in tools.tools}
                    assert {'controller_read_state', 'aci_replacement_status', 'aci_replacement_methods',
                            'project_inspect_tasks', 'project_update_cyclic_task'} <= names
                    caps = await call(client, 'server_capabilities', {}, '01-capabilities')
                    assert not caps['aci_dependency'] and not caps['controller_write_access']
                    parity = await call(client, 'aci_replacement_status', {}, '02-coverage')
                    assert parity['declared_methods'] == 201 and not parity['full_aci_replacement']
                    await call(client, 'aci_replacement_methods', {'domain': 'tasks', 'include_details': True}, '03-task-methods')
                    imported = await call(client, 'project_import_copy', {'source_path': str(SOURCE)}, '04-import')
                    project = imported['project_id']
                    tasks = await call(client, 'project_inspect_tasks', {'project_id': project}, '05-before-tasks')
                    task = tasks['tasks'][0]
                    edited = await call(client, 'project_update_cyclic_task', {
                        'project_id': project, 'expected_project_sha256': imported['project_sha256'],
                        'task_id': task['id'], 'updates': {'interval_ns': 25000000, 'watchdog_ns': 750000000, 'priority': 2}}, '06-edit')
                    after = await call(client, 'project_inspect_tasks', {'project_id': project}, '07-after-tasks')
                    assert after['tasks'][0]['id'] == task['id']
                    assert after['tasks'][0]['program_instances'] == task['program_instances']
                    assert after['tasks'][0]['interval_ns'] == 25000000
                    validation = await call(client, 'project_validate', {'project_id': project}, '08-validate')
                    assert validation['preservation_passed'] and validation['changed_members'] == [tasks['esm_member']]
                    stale = await client.call_tool('project_update_cyclic_task', {
                        'project_id': project, 'expected_project_sha256': imported['project_sha256'],
                        'task_id': task['id'], 'updates': {'priority': 1}})
                    assert stale.isError
                    arguments = {'project_id': project, 'expected_project_sha256': edited['project_sha256']}
                    cold = await call(client, 'project_compile', arguments, '09-cold')
                    assert cold['compiled'] and not cold['ast_seed_used'] and cold['host']['pous_reparsed'] == 61
                    package = await call(client, 'project_generate_pcwe', arguments | {'build_job_id': cold['job_id']}, '10-pcwe')
                    assert package['package_complete'] and package['file_count'] == 48
                    package_args = arguments | {'package_job_id': package['package_job_id']}
                    plan = await call(client, 'project_download_plan', package_args, '11-download-plan')
                    assert 'v4_tagged' in plan['available_protocol_profiles']
                    sim = await call(client, 'project_simulate_download', package_args | {'protocol_profile': 'v4_tagged'}, '12-tagged-simulation')
                    assert sim['status'] == 'simulation_passed' and sim['protocol_profile'] == 'v4_tagged'
                    assert sim['files_verified'] == 48 and sim['tagged_invocations'] > 0
                    assert sim['rpc_close_session_confirmed'] and not sim['controller_downloaded']
                    failed = await call(client, 'project_simulate_download', package_args | {
                        'protocol_profile': 'v4_tagged', 'fault': 'readback_corrupt'}, '13-tagged-readback-rejected')
                    assert failed['status'] == 'simulation_failed' and not failed['simulated_configuration_loaded']
                    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_hash
                    summary.update(status='passed', tools=len(names), project_id=project,
                        project_sha256=edited['project_sha256'], build_job_id=cold['job_id'],
                        package_job_id=package['package_job_id'], pcwe_path=package['pcwe_path'],
                        task_program_mapping_preserved=True, native_pous=61, pcwe_files=48,
                        inventory_sha256=package['inventory_sha256'], source_untouched=True,
                        tagged_rpc_exchanges=sim['rpc_exchanges_completed'],
                        tagged_invocations=sim['tagged_invocations'],
                        tagged_discoveries=sim['tagged_discoveries'],
                        stale_update_rejected=True, readback_corruption_prevents_load=True)
    except BaseException as exc:
        summary.update(status='failed', error=str(exc))
        raise
    finally:
        (output / 'result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'report': str(output / 'result.json'), **summary}, ensure_ascii=False))


if __name__ == '__main__':
    asyncio.run(main())
