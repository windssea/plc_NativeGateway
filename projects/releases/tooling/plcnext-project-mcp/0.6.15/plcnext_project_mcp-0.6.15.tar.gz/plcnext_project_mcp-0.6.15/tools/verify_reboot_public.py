"""Fresh installed MCP discovery and local-only reboot preparation. No authorization or PLC I/O."""
import asyncio,json,os,sys,tempfile
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    root=Path(__file__).resolve().parents[1]
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']='D:/PLCnext-MCP-Workspace'
    pid='17ae4361baa846868b14775bf1de15ea'
    read=json.loads((Path(env['PLCNEXT_MCP_WORKSPACE'])/pid/'runtime-read-plans/1d480ec59dbb44bbb20c63996b8098a9/plan.json').read_bytes())
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    async with stdio_client(params) as (r,w):
        async with ClientSession(r,w) as session:
            await session.initialize()
            async def call(name,args):
                response=await session.call_tool(name,args)
                assert not response.isError,response.content
                return response.structuredContent or json.loads(''.join(x.text for x in response.content if x.type=='text'))
            tools=await session.list_tools();caps=await call('server_capabilities',{})
            assert caps['version']=='0.6.11' and len(tools.tools)==85
            names={t.name for t in tools.tools}
            assert {'project_prepare_reboot','project_execute_reboot','project_inspect_reboot','project_reboot_status','project_cancel_reboot_wait'}<=names
            auth=next(t for t in tools.tools if t.name=='project_authorize_controller_operation')
            assert 'reboot' in auth.inputSchema['properties']['kind']['enum']
            plan=await call('project_prepare_reboot',dict(project_id=pid,expected_project_sha256=read['project_sha256'],
                package_job_id='f7fc619d55ba42c091f4ca0efed23e73',**read['target'],read_plan_id=read['plan_id'],
                read_plan_sha256=read['plan_sha256'],expected_boot_id='ng-d4f61b3085b97c5e3831983b-77',
                expected_configuration={'version':15,'device_count':50,'point_count':250,'enabled':True},
                configuration_sha256='a4456dea3320316db07f4eb2148b086ee477c12ddf10af7a549172b39cb90e9f'))
            args=dict(project_id=pid,plan_id=plan['plan_id'],expected_plan_sha256=plan['plan_sha256'])
            inspected=await call('project_inspect_reboot',args)
            assert not inspected['started'] and not inspected['controller_connected']
            state=await call('project_reboot_status',args);assert state['result'] is None
            report=dict(version=caps['version'],tool_count=len(tools.tools),plan=plan,
                controller_connected=False,approval_issued=False,real_reboot_sent=False,
                baseline_is_historical_not_fresh=True)
            (root/'artifacts/reboot-research/public-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps({k:v for k,v in report.items() if k!='plan'}))

if __name__=='__main__':asyncio.run(main())
