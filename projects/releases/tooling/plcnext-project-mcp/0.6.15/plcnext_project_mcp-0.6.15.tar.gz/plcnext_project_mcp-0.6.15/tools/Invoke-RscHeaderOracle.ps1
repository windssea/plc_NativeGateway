param(
 [string]$InstallDirectory='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0',
 [string]$OutputPath='D:\work\code\PLCnext-Engineer-mcp\artifacts\plc-download-research\auth\header-oracle.json'
)
$ErrorActionPreference='Stop'
# Pure value-type serialization only. No communication provider is constructed.
$tokenAssembly=[Reflection.Assembly]::LoadFrom((Join-Path $InstallDirectory 'Arp.Base.Rsc.Commons.dll'))
$assembly=[Reflection.Assembly]::LoadFrom((Join-Path $InstallDirectory 'Ade.CommonRemoting.Commons.dll'))
$headerType=$assembly.GetType('Ade.CommonRemoting.CommandHeader',$true)
$tokenType=$tokenAssembly.GetType('Arp.Base.Rsc.Commons.Security.SecurityToken',$true)
$methods=@($headerType.GetMethods([Reflection.BindingFlags]'Public,NonPublic,Static')|Where-Object Name -eq Write)
$tokenWriter=$methods|Where-Object {$_.GetParameters()[2].ParameterType -eq $tokenType}
$plainWriter=$methods|Where-Object {$_.GetParameters()[2].ParameterType -eq [bool]}
$vectors=@()
$cases=@(
 @{name='plain';flags=0;command=2;length=99;service=12;method=3;provider=9;token=$null;checksum=$true},
 @{name='token-zero';flags=0;command=2;length=99;service=12;method=3;provider=9;token=[uint32]0;checksum=$true},
 @{name='token-one';flags=0;command=2;length=99;service=12;method=3;provider=9;token=[uint32]1;checksum=$true},
 @{name='token-max';flags=192;command=2;length=32767;service=32767;method=32767;provider=32767;token=[uint32]4294967295;checksum=$true},
 @{name='plain-negative-handles';flags=0;command=7;length=0;service=-1;method=-32768;provider=-1;token=$null;checksum=$true},
 @{name='plain-without-checksum';flags=0;command=2;length=1;service=0;method=0;provider=0;token=$null;checksum=$false}
)
foreach($case in $cases){
 $header=[Activator]::CreateInstance($headerType)
 foreach($entry in @{Version=[byte]4;Flags=[byte]$case.flags;CommandType=[Enum]::ToObject($assembly.GetType('Ade.CommonRemoting.CommandType'),[int16]$case.command);DataLength=[int16]$case.length;ServiceHandle=[int16]$case.service;MethodHandle=[int16]$case.method;ServiceProviderHandle=[int16]$case.provider}.GetEnumerator()){
  $headerType.GetProperty($entry.Key).SetValue($header,$entry.Value)
 }
 $stream=[IO.MemoryStream]::new()
 $writer=[IO.BinaryWriter]::new($stream)
 try {
  if($null -ne $case.token){
   $token=[Activator]::CreateInstance($tokenType,[object[]]@([uint32]$case.token))
   [void]$tokenWriter.Invoke($null,[object[]]@($header,$writer,$token))
  } else {[void]$plainWriter.Invoke($null,[object[]]@($header,$writer,[bool]$case.checksum))}
  $vectors+=@{case=$case;header_hex=[Convert]::ToHexString($stream.ToArray()).ToLowerInvariant()}
 } finally {$writer.Dispose();$stream.Dispose()}
}
@{oracle='Actual CommandHeader.Write into MemoryStream';communication_provider_created=$false;socket_created=$false;vectors=$vectors;
 assemblies=@('Ade.CommonRemoting.Commons.dll','Arp.Base.Rsc.Commons.dll')|ForEach-Object{@{name=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $InstallDirectory $_)).Hash.ToLowerInvariant()}}}|
 ConvertTo-Json -Depth 10|Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Output ('Saved {0} pure serialization vectors' -f $vectors.Count)
