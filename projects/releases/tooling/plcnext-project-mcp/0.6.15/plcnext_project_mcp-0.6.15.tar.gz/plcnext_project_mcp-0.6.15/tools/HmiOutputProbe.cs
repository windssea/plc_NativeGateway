using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Xml.Linq;
using System.Runtime.ExceptionServices;

public class HmiStrictProxy : DispatchProxy {
    public Func<MethodInfo,object[],object> Handler;
    protected override object Invoke(MethodInfo method, object[] arguments) { return Handler(method,arguments); }
}

// A bounded offline research host. Unknown service calls fail rather than fabricate success.
public static class HmiOutputProbe {
    static string install,desktop;
    static readonly List<string> calls=new List<string>();
    static readonly List<string> unsupported=new List<string>();
    static readonly List<string> firstChance=new List<string>();
    static bool observing;
    static void ObserveException(object sender,FirstChanceExceptionEventArgs args){
        if(!observing||firstChance.Count>=15)return;
        var text=args.Exception.ToString()+"\nAt first chance: "+Environment.StackTrace;
        if(!firstChance.Contains(text))firstChance.Add(text);
    }
    static readonly Dictionary<string,Assembly> loaded=new Dictionary<string,Assembly>();
    static readonly Dictionary<Guid,object> pageNodes=new Dictionary<Guid,object>();
    static readonly Dictionary<Guid,object> contentNodes=new Dictionary<Guid,object>();
    static Guid solutionId;
    static object solution;
    static object compilerProject;
    static object compilerState;
    static object navigation;
    static readonly Dictionary<string,object> services=new Dictionary<string,object>();
    sealed class Tag { public Guid Id; public string Name,DataType,InitValue,RuntimePath; public bool ReadOnly,IsSystem; public int Scope=1; }
    static readonly Dictionary<string,Tag> tags=new Dictionary<string,Tag>(StringComparer.OrdinalIgnoreCase);
    static Tag TagFor(object identifier){
        var named=identifier.GetType().GetProperty("Name");
        if(named!=null){Tag found;if(tags.TryGetValue((string)named.GetValue(identifier),out found))return found;}
        var id=(Guid)Get(identifier,"VariableId");
        return tags.Values.Single(t=>t.Id==id);
    }
    static object TagRole(Tag tag){return Proxy(T("Ade.Hmi.DataList.IHmiTagRole","Ade.Hmi"),(m,a)=>{
        if(m.Name=="get_Datum")return Proxy(m.ReturnType,(dm,da)=>{
            if(dm.Name=="get_Roles"){
                var roleType=T("Ade.DataList.Roles.IRole","Ade.DataList");
                var list=(IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(roleType));
                list.Add(Proxy(roleType,(rm,ra)=>{if(rm.Name=="get_TypeName")return "Variable";if(rm.Name=="get_Name")return rm.ReturnType==typeof(string)?(object)tag.Name:Call(rm.ReturnType,"op_Implicit",tag.Name);throw new NotSupportedException("Source Variable role "+rm.Name);}));
                return list;
            }
            throw new NotSupportedException("Source HMI datum "+dm.Name);
        });
        if(m.Name=="get_IsReadOnly")return tag.ReadOnly;
        if(m.Name=="get_DisplayName"||m.Name=="get_Name")return tag.Name;
        if(m.Name=="get_DataType")return tag.DataType;
        if(m.Name=="get_ObjectId"||m.Name=="get_Id")return New(m.ReturnType,tag.Id);
        throw new NotSupportedException("Tag role "+m.Name);
    });}
    static object ClientTag(Tag tag){return Proxy(T("Ade.Domain.Hmi.ValueObjects.IHmiVariable","Ade.Domain.Hmi"),(m,a)=>{
        if(m.Name=="get_Name")return tag.Name;if(m.Name=="get_DataType")return tag.DataType;if(m.Name=="get_InitValue"||m.Name=="get_InitValueText")return tag.InitValue;
        if(m.Name=="get_IsReadOnly")return tag.ReadOnly;if(m.Name=="get_Id")return tag.Id;
        if(m.Name=="get_IsSystemVariable")return tag.IsSystem;
        throw new NotSupportedException("Source client tag "+m.Name);
    });}
    static object TagModel(Tag tag){return tag.Scope==1?TagRole(tag):ClientTag(tag);}
    static Assembly Resolve(object sender,ResolveEventArgs args){
        var name=new AssemblyName(args.Name).Name;
        if(name.IndexOf("ApplicationControl",StringComparison.OrdinalIgnoreCase)>=0 ||
           name.IndexOf("Online",StringComparison.OrdinalIgnoreCase)>=0 ||
           name.IndexOf("CodeMeter",StringComparison.OrdinalIgnoreCase)>=0 ||
           name.IndexOf("License",StringComparison.OrdinalIgnoreCase)>=0 ||
           name.IndexOf("Wibu",StringComparison.OrdinalIgnoreCase)>=0)
            throw new InvalidOperationException("Out-of-scope assembly: "+name);
        foreach(var root in new[]{install,desktop}){
            var path=Path.Combine(root,name+".dll");
            if(File.Exists(path))return Assembly.LoadFrom(path);
        }
        return null;
    }
    static Type T(string name,string assembly="Ade.Hmi.CompilerImpl"){
        Assembly a;
        if(!loaded.TryGetValue(assembly,out a)){a=Assembly.LoadFrom(Path.Combine(install,assembly+".dll"));loaded[assembly]=a;}
        return a.GetType(name,true);
    }
    static object New(Type t,params object[] args){return Activator.CreateInstance(t,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance,null,args,null);}
    static object Get(object o,string name){var p=o.GetType().GetProperty(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance);return p!=null?p.GetValue(o):o.GetType().GetField(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance).GetValue(o);}
    static void Set(object o,string name,object value){o.GetType().GetProperty(name,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance).SetValue(o,value);}
    static object Call(object o,string name,params object[] args){
        var t=o as Type ?? o.GetType();
        var method=t.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static).Single(m=>m.Name==name && m.GetParameters().Length==args.Length);
        return method.Invoke(o is Type ? null:o,args);
    }
    public static Lazy<TValue> LazyValue<TValue>(object value){return new Lazy<TValue>(()=>(TValue)value);}
    static object Lazy(Type type,object value){return typeof(HmiOutputProbe).GetMethod("LazyValue").MakeGenericMethod(type.GetGenericArguments()[0]).Invoke(null,new[]{value});}
    static object Proxy(Type type,Func<MethodInfo,object[],object> handler){
        var result=DispatchProxy.Create(type,typeof(HmiStrictProxy));((HmiStrictProxy)result).Handler=handler;return result;
    }
    static object Strict(Type type){return Proxy(type,(m,args)=>{
        calls.Add(type.FullName+"."+m.Name);
        if(type.FullName=="Ade.Hmi.IHmiPageInfoService" && m.Name=="GetHmiPageContentNodes"){
            var values=Array.CreateInstance(T("Ade.Project.Content.ContentNode","Ade.Project"),pageNodes.Count);
            int n=0;foreach(var node in pageNodes.Values)values.SetValue(node,n++);return values;
        }
        if(type.FullName=="Ade.Hmi.IPageNavigationService" && m.Name=="GetNavigationDestinations")return Call(navigation,"FindPositionInNetwork",Get(args[0],"ContentNodeId"));
        if(type.FullName=="Ade.Hmi.Compiler.IPageCheckResultCacheService" && m.Name=="CreatePageInfo")return New(T("Ade.Hmi.Compiler.PageCacheItem"),args[0]);
        if(type.FullName=="Ade.Project.ISolutionManager" && m.Name=="get_ActiveSolution")return solution;
        if(type.FullName=="Ade.Compiler.ICompilerProjectManager" && m.Name=="get_CurrentCompilerProject")return compilerProject;
        if(type.FullName=="Ade.Compiler.ICompilerProjectManager" && m.Name=="FindIecType")return Call(compilerState,"FindIecType",args[0]);
        if(type.FullName=="Ade.Build.IBuildContext" && m.Name=="get_Items"){
            var bi=T("Ade.Build.BuildItem","Ade.Build");var item=New(bi,"CompilerProject","NativeGateway");Set(item,"Data",compilerProject);
            var listType=typeof(List<>).MakeGenericType(bi);var list=(IList)Activator.CreateInstance(listType);list.Add(item);
            var dict=(IDictionary)Activator.CreateInstance(typeof(Dictionary<,>).MakeGenericType(typeof(string),typeof(IList<>).MakeGenericType(bi)));dict.Add("CompilerProject",list);return dict;
        }
        if(type.FullName=="Ade.Components.ICommonResourceService" && m.Name=="GetString")return args[0];
        if(type.FullName=="Ade.Hmi.ICompilerSettingsService" && m.Name=="get_AllowExtendedIdentifiers")return false;
        if(type.FullName=="Ade.Hmi.Compiler.IHmiTagResolver"){
            if(m.Name=="get_TagDataService")return ServiceValue(m.ReturnType);
            if(m.Name=="get_UsingGDS")return true;
            if(m.Name=="ResolveTagReference"){
                var tag=TagFor(args[0]);args[2]=null;
                return New(T("Ade.Hmi.Compiler.RuntimeVariableInfo"),args[0],New(T("Ade.Hmi.Compiler.TagInfoForRuntime"),tag.RuntimePath,tag.DataType,tag.InitValue,tag.ReadOnly));
            }
        }
        if(type.FullName=="Ade.Hmi.DataList.IHmiTagDataService" && m.Name=="CreateTagsForPageService")return ServiceValue(m.ReturnType);
        if(type.FullName=="Ade.Hmi.DataList.IHmiTagsForPageDataService"){
            if(m.Name=="FindVariable"){
                var tag=TagFor(args[0]);args[1]=New(T("Ade.Hmi.FullDataType","Ade.Hmi"),tag.DataType);args[2]=tag.Name;args[3]=TagModel(tag);args[4]=null;args[5]=false;return true;
            }
            if(m.Name=="ResolveVariableName"){
                var identifier=Get(args[0],"Identifier");
                Call(T("Ade.Hmi.VariableHelpers","Ade.Hmi"),"AddIdentifier",args[2],identifier);
                var tag=TagFor(identifier);
                var resolved=New(T("Ade.Hmi.HmiVariableIdentifier","Ade.Hmi"),tag.Id,Enum.ToObject(T("Ade.Hmi.VariableScope","Ade.Hmi"),tag.Scope));
                args[1]=Call(T("Ade.Hmi.MultipleElementVariable","Ade.Hmi"),"Create",resolved,Get(args[0],"Suffix"));return null;
            }
            if(m.Name=="GetVariableType"){
                var tag=TagFor(Get(args[0],"Identifier"));var suffix=(string)Get(args[0],"Suffix");
                var datatype=String.IsNullOrWhiteSpace(suffix)?tag.DataType:(string)Call(ServiceValue(T("Ade.Hmi.Model.Scripting.IScriptAnalyzer","Ade.Hmi")),"EvaluateSuffix",tag.DataType,suffix,null,null,null,null,null,false);
                if(String.IsNullOrWhiteSpace(datatype))throw new InvalidDataException("Cannot resolve suffix type: "+tag.Name+suffix);
                return New(T("Ade.Hmi.FullDataType","Ade.Hmi"),datatype);
            }
            if(m.Name=="IsVariable"){
                Tag tag;if(!tags.TryGetValue((string)args[0],out tag))throw new NotSupportedException("Unknown HMI variable: "+args[0]);
                args[1]=New(T("Ade.Hmi.HmiVariableIdentifier","Ade.Hmi"),tag.Id,Enum.ToObject(T("Ade.Hmi.VariableScope","Ade.Hmi"),tag.Scope));
                args[2]=New(T("Ade.Hmi.FullDataType","Ade.Hmi"),tag.DataType);args[3]=tag.Name;args[4]=TagModel(tag);args[5]=false;return true;
            }
            if(m.Name=="get_IsPlcNext")return (bool?)true;
            if(m.Name=="GetVariableBaseType")return New(T("Ade.Hmi.FullDataType","Ade.Hmi"),TagFor(args[0]).DataType);
            if(m.Name=="GetVariableName"){var tag=TagFor(args[0]);args[1]=tag.Name;args[2]=tag.Name;return true;}
            if(m.Name=="GetHmiTagIsReadOnly")return (bool?)TagFor(args[0]).ReadOnly;
            if(m.Name=="GetHmiTagRole"){var tag=TagFor(args[0]);if(tag.Scope!=1)throw new InvalidDataException("Not a controller HMI tag");args[1]=null;return TagRole(tag);}
            if(m.Name=="GetClientSideTag"){var tag=TagFor(args[0]);if(tag.Scope!=2 && tag.Scope!=3)throw new InvalidDataException("Not a client tag");args[1]=null;args[2]=false;return ClientTag(tag);}
            if(m.Name=="GetIecDataType")return Call(ServiceValue(T("Ade.Hmi.DataList.IHmiPageDataTypeService","Ade.Hmi")),"GetIecDataType",args[0],null);
        }
        if(type.FullName=="Ade.Project.ISolution"){
            if(m.Name=="get_Id")return solutionId;
            if(m.Name=="get_DomainId")return Guid.Empty;
            if(m.Name=="get_IsActiveSolution")return true;
        }
        if((type.FullName=="Ade.Project.ISolutionManager" || type.FullName=="Ade.Project.ISolution") && m.Name=="ResolveReference"){
            var id=(Guid)Get(args[0],"ContentNodeId");object node;
            if(contentNodes.TryGetValue(id,out node))return node;
            throw new InvalidDataException("Unknown content reference: "+id);
        }
        unsupported.Add(type.FullName+"."+m.Name+"\n"+Environment.StackTrace);
        throw new NotSupportedException("Unimplemented HMI service: "+type.FullName+"."+m.Name);
    });}
    static object LazyStrict(Type type){return Lazy(type,Strict(type.GetGenericArguments()[0]));}
    static object LiteralParser(){
        var t=T("Ade.Compiler.LiteralParser","Ade.CompilerImpl");
        var obj=New(t,New(T("Ade.Compiler.IdentifierHelper","Ade.CompilerImpl")));
        return obj;
    }
    static object ServiceValue(Type type){
        object value;if(services.TryGetValue(type.FullName,out value))return value;
        switch(type.FullName){
            case "Ade.Compiler.ILiteralParser":value=LiteralParser();break;
            case "Ade.Compiler.IIecScannerFactory":value=New(T("Ade.Compiler.IecScannerFactory","Ade.CompilerImpl"));break;
            case "Ade.Hmi.Model.Scripting.IScriptAnalyzer":value=New(T("Ade.Hmi.Compiler.ScriptAnalyzer"));break;
            case "Ade.Hmi.IHmiJumpService":value=New(T("Ade.Hmi.HmiJumpServiceComponent","Ade.HmiImpl"));break;
            case "Ade.Hmi.DataList.IHmiPageDataTypeService":value=New(T("Ade.Hmi.DataList.HmiPageDataTypeService"));break;
            case "Ade.Compiler.IStructuredTextParser":value=New(T("Ade.Compiler.Parsing.StructuredTextParser","Ade.Compiler.ParsingImpl"));break;
            default:value=Strict(type);break;
        }
        services[type.FullName]=value;
        if(!(value is HmiStrictProxy)){
            foreach(var p in value.GetType().GetProperties(BindingFlags.Public|BindingFlags.Instance).Where(p=>p.CanWrite && p.PropertyType.IsGenericType && p.PropertyType.GetGenericTypeDefinition()==typeof(Lazy<>)))
                p.SetValue(value,Lazy(p.PropertyType,ServiceValue(p.PropertyType.GetGenericArguments()[0])));
        }
        return value;
    }
    static object ServiceProxy(Type type){
        return Proxy(type,(m,args)=>{
            calls.Add(type.FullName+"."+m.Name);
            if(m.Name.StartsWith("get_") && m.ReturnType.IsGenericType && m.ReturnType.GetGenericTypeDefinition()==typeof(Lazy<>))return Lazy(m.ReturnType,ServiceValue(m.ReturnType.GetGenericArguments()[0]));
            unsupported.Add(type.FullName+"."+m.Name+"\n"+Environment.StackTrace);
            throw new NotSupportedException("Unimplemented HMI service: "+type.FullName+"."+m.Name);
        });
    }
    static int Count(object enumerable){return ((IEnumerable)enumerable).Cast<object>().Count();}
    static string DescribeMessage(object value){return String.Join("; ",value.GetType().GetProperties().Where(p=>p.CanRead && p.GetIndexParameters().Length==0).Select(p=>{var v=p.GetValue(value);return p.Name+"="+(v is IEnumerable && !(v is string)?String.Join(",",((IEnumerable)v).Cast<object>()):v);}));}
    static string Hash(string path){using(var s=File.OpenRead(path))return Convert.ToHexString(SHA256.HashData(s)).ToLowerInvariant();}
    static object LocalResources(object page,string source,string name,object node){
        var serializer=New(T("Ade.Project.Localization.Services.ResourcesDocumentSerializationService","Ade.Project.LocalizationImpl"));
        object document;using(var stream=File.OpenRead(source+".locres"))document=Call(serializer,"ReadFromStream",stream);
        if(document==null)throw new InvalidDataException("Cannot load page resource document: "+name);
        var factoryType=T("Ade.Hmi.Localize.HmiLocalizerFactory","Ade.HmiImpl");
        var factory=New(factoryType,factoryType.GetConstructors().Single().GetParameters().Select(p=>ServiceValue(p.ParameterType)).ToArray());
        var localizer=Call(factory,"CreateHmiLocalizer",page);
        var updater=T("Ade.Hmi.Localize.LocalizerDocumentUpdater","Ade.Project.HmiImpl");
        var update=updater.GetMethod("UpdateResourcesDocumentForPageOrSymbol",BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance);
        var lazyJumpType=update.GetParameters()[4].ParameterType;
        update.Invoke(update.IsStatic?null:New(updater),new[]{(object)name,document,page,localizer,Lazy(lazyJumpType,ServiceValue(lazyJumpType.GetGenericArguments()[0]))});
        var info=New(T("Ade.Project.Localization.Json.LocalResourcesBuildInfo","Ade.Project.Localization"),name,node,name+".",null);Set(info,"Document",document);return info;
    }
    public static Dictionary<string,object> Run(string job,string output,string directory,string desktopDirectory){
        install=directory;desktop=desktopDirectory;observing=false;calls.Clear();unsupported.Clear();firstChance.Clear();loaded.Clear();pageNodes.Clear();contentNodes.Clear();services.Clear();tags.Clear();
        var result=new Dictionary<string,object>{{"status","failed"},{"aci_used",false},{"computer_use_used",false},{"controller_connected",false},{"deployable",false}};
        ResolveEventHandler resolver=Resolve;AppDomain.CurrentDomain.AssemblyResolve+=resolver;
        AppDomain.CurrentDomain.FirstChanceException+=ObserveException;
        try{
            var astPath=Path.Combine(job,"analyzed.LastBuild.ast");
            var ast=Call(T("Ade.Compiler.Model.ArchiveSerialization.ArchiveReader","Ade.Compiler"),"ReadFile",astPath,false);
            compilerProject=Get(ast,"Item1");
            compilerState=New(T("Ade.Internal.Compiler.CompilerProjectManagerState","Ade.CompilerImpl"),compilerProject,null,LiteralParser(),Strict(T("Ade.Compiler.IValueInformationProvider","Ade.Compiler")));
            result["analyzed_ast_sha256"]=Hash(astPath);
            result["allow_extended_identifiers"]=false;
            var dataPath=Directory.GetFiles(Path.Combine(job,"project/PROJECT/Hardware"),"DataList.dl",SearchOption.AllDirectories).Single();
            var data=XDocument.Load(dataPath);
            foreach(var datum in data.Descendants("Datum")){
                var tagRole=datum.Elements("Role").SingleOrDefault(r=>(string)r.Attribute("TypeName")=="HmiTag");
                if(tagRole==null)continue;
                var variable=datum.Elements("Role").Single(r=>(string)r.Attribute("TypeName")=="Variable");
                var port=data.Descendants("Role").FirstOrDefault(r=>(string)r.Attribute("TypeName")=="OutPort" && (string)r.Attribute("ObjectId")== (string)variable.Attribute("ObjectId"));
                if(port==null)throw new InvalidDataException("HMI tag lacks a source-bound GDS out-port: "+tagRole.Element("Name").Value);
                var tag=new Tag{Id=Guid.Parse(tagRole.Attribute("ObjectId").Value),Name=tagRole.Element("Name").Value,DataType=variable.Element("DataType").Value,InitValue=variable.Element("InitValue").Value,ReadOnly=bool.Parse(tagRole.Element("IsReadOnly").Value),RuntimePath=port.Element("ComponentInstance").Value+"/"+port.Element("Name").Value};
                tags.Add(tag.Name,tag);
            }
            result["hmi_tag_count"]=tags.Count;
            foreach(var variablesPath in Directory.GetFiles(Path.Combine(job,"project"),"Variables.hmivar",SearchOption.AllDirectories)){
                var variables=XDocument.Load(variablesPath);
                foreach(var v in variables.Descendants("Variable")){
                    var tag=new Tag{Id=Guid.Parse((string)v.Attribute("Id")),Name=(string)v.Attribute("Name"),DataType=(string)v.Attribute("DataType"),InitValue=(string)v.Attribute("InitValue"),ReadOnly=bool.Parse((string)v.Attribute("IsReadOnly")),Scope=Path.GetDirectoryName(variablesPath).EndsWith(".hmi",StringComparison.OrdinalIgnoreCase)?2:3};
                    tag.IsSystem=v.Parent.Name.LocalName=="System";tags.Add(tag.Name,tag);
                }
            }
            var navPath=Directory.GetFiles(Path.Combine(job,"project"),"*.hminav",SearchOption.AllDirectories).Single();
            using(var stream=File.OpenRead(navPath))navigation=Call(New(T("Ade.Hmi.Navigation.NavigationDocumentSerializer","Ade.Hmi.NavigationImpl")),"Read",stream);
            if(navigation==null)throw new InvalidDataException("Navigation model failed to load");
            var pageFiles=Directory.GetFiles(Path.Combine(job,"project"),"Definition.hmipagedef",SearchOption.AllDirectories);
            if(pageFiles.Length!=2)throw new NotSupportedException("This validated HMI profile requires exactly Gateway and Login pages");
            var source=pageFiles.Single(p=>p.Replace('\\','/').EndsWith("/Gateway.hmi/Definition.hmipagedef",StringComparison.OrdinalIgnoreCase));
            result["source_path"]=source;result["source_sha256"]=Hash(source);
            result["stage"]="deserialize_page";
            var persistence=New(T("Ade.Hmi.Persistence.PersistHmiPageDefinition","Ade.HmiImpl"));
            object page;using(var stream=File.OpenRead(source))page=Call(persistence,"Load",stream);
            result["page_name"]=Get(page,"Name");result["page_objects"]=Count(Get(page,"ObjectsFromAllLayers"));
            observing=true;
            var document=XDocument.Load(Path.Combine(job,"project/PROJECT/PROJECT.proj"));
            solutionId=Guid.Parse(document.Descendants().Single(e=>e.Name.LocalName=="ProjectId").Value);
            solution=Strict(T("Ade.Project.ISolution","Ade.Project"));
            Guid pageId=Guid.Empty;
            foreach(var item in document.Descendants().Where(e=>e.Name.LocalName=="HmiPage" || e.Name.LocalName=="Image")){
                var id=Guid.Parse(item.Elements().Single(e=>e.Name.LocalName=="Id").Value);
                var name=item.Elements().Single(e=>e.Name.LocalName=="DisplayName").Value;
                var node=New(T("Ade.Project.Content.ContentNode","Ade.Project"));
                Set(node,"Id",id);Set(node,"Name",Path.GetFileName(item.Attribute("Include").Value));Set(node,"DisplayName",name);Set(node,"NodeType",item.Name.LocalName);Set(node,"Solution",solution);
                contentNodes[id]=node;
                if(item.Name.LocalName=="HmiPage"){pageNodes[id]=node;if(name=="Gateway")pageId=id;}
            }
            var pageReference=New(T("Ade.Project.Content.ContentNodeReference","Ade.Project"),Guid.Empty,solutionId,pageId);
            var pageUri=new Uri("adeprojectref:///"+pageReference.ToString());
            Call(page,"SetContentNodeReference",pageReference,pageUri,new Uri(source));
            result["stage"]="construct_serialization_context";
            var settings=New(T("Ade.Hmi.Compiler.HmiClientApplicationSettings"));
            if(Directory.GetFiles(Path.Combine(job,"project"),"*.authsettings",SearchOption.AllDirectories).Length!=0)throw new NotSupportedException("Explicit authentication settings need a source-bound loader");
            var deviceSettingsPath=Directory.GetFiles(Path.Combine(job,"project"),"*.ds",SearchOption.AllDirectories).Single();
            var deviceSettings=XDocument.Load(deviceSettingsPath);
            var accessRights=deviceSettings.Descendants("InstVal").Single(e=>((string)e.Attribute("xPath")??"").Contains("type='HMI:AccessRights'"));
            if(accessRights.Value!="0")throw new NotSupportedException("Only source HMI AccessRights=0 is validated");
            var httpPort=deviceSettings.Descendants("InstVal").Single(e=>((string)e.Attribute("xPath")??"").Contains("type='HMI:HttpPort'"));
            Set(settings,"HttpPort",UInt16.Parse(httpPort.Value));
            result["authentication_protocol"]=Convert.ToInt32(Get(settings,"AuthenticationProtocol"));
            result["authentication_source"]="No authsettings payload; vendor HmiClientApplicationSettings zero-initialized protocol";
            result["source_hmi_access_rights"]=0;result["source_hmi_http_port"]=UInt16.Parse(httpPort.Value);result["device_settings_sha256"]=Hash(deviceSettingsPath);
            var resourceType=T("Ade.Hmi.Compiler.HmiApplicationCompilerResources");
            var resourceArgs=resourceType.GetConstructors(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance).Single().GetParameters().Select(p=>p.ParameterType.IsGenericType?LazyStrict(p.ParameterType):p.ParameterType.Name=="HmiClientApplicationSettings"?settings:Strict(p.ParameterType)).ToArray();
            var resources=New(resourceType,resourceArgs);
            var commonType=T("Ade.Hmi.Compiler.CommonBuildContext");
            var messageType=T("Ade.Hmi.Compiler.MessageLogBuilder");
            var messageSinkType=T("Ade.Components.IMessageSink","Ade.Components");
            var messages=new List<string>();
            var messageSink=Proxy(messageSinkType,(m,args)=>{calls.Add(m.Name);if(m.Name=="GetMessageFromId")return args[0];if(m.Name=="AddMessage"){messages.Add(DescribeMessage(args[0]));return null;}if(m.Name=="AddMessages"){foreach(var a in (IEnumerable)args[0])messages.Add(DescribeMessage(a));return null;}throw new NotSupportedException(m.Name);});
            result["messages"]=messages;
            var messageLog=New(messageType,messageSink);
            var paths=New(T("Ade.Hmi.Compiler.OutputPaths"),new DirectoryInfo(output),Guid.Empty,solutionId,false);
            var outputPath=Call(paths,"CreateOutputPathForPage",page,pageUri,messageLog);
            var commonArgs=commonType.GetConstructors().Single().GetParameters().Select(p=>p.ParameterType==resourceType?resources:p.ParameterType==messageType?messageLog:p.ParameterType.Name=="OutputPaths"?paths:p.ParameterType==typeof(bool)?(object)false:p.ParameterType.Name=="IServicesForSemanticAnalysis"?ServiceProxy(p.ParameterType):Strict(p.ParameterType)).ToArray();
            var common=New(commonType,commonArgs);
            var context=New(T("Ade.Hmi.Compiler.HmiJsonSerializer.HmiBuildContext"),common,new Uri(source),"Gateway",pageId,page,New(T("Ade.Hmi.Compiler.PreparedOutputs")),New(T("Ade.Hmi.Compiler.PageDependenciesBuilder")),false,null);
            result["stage"]="serialize_root";
            var root=Call(T("Ade.Hmi.Compiler.HmiJsonSerializer.JsonHmiWriter"),"SerializeRoot",context,page,"Gateway");
            result["serialized_root_type"]=root==null?null:root.GetType().FullName;
            if(root==null)throw new InvalidDataException("HMI serialization returned null.");
            result["stage"]="create_page_output";
            var pageOutput=Call(Get(context,"OutputBuilder"),"CreatePageOutput",ServiceValue(T("Ade.Hmi.DataList.IHmiPageDataTypeService","Ade.Hmi")),ServiceValue(T("Ade.Hmi.Model.Scripting.IScriptAnalyzer","Ade.Hmi")),pageUri,"Gateway",outputPath,root);
            result["script_length"]=((string)Get(pageOutput,"ScriptText")).Length;
            result["stage"]="write_page_output";
            Call(T("Ade.Hmi.Compiler.HmiJsonSerializer.HmiJsonSerializer"),"OutputHmiPage",root,Get(pageOutput,"PageAndSymbolVariables"),Get(pageOutput,"TrendViews"),Get(pageOutput,"ScriptText"),pageUri,outputPath,"Gateway",messageLog,Strict(T("Ade.DataTypes.IDataValueParser","Ade.DataTypes")),Strict(T("Ade.Hmi.Compiler.JsonSerializer.IInitValueConverter")),paths);
            result["gateway_complete"]=true;
            var loginSource=pageFiles.Single(p=>p.Replace('\\','/').EndsWith("/Login.hmi/Definition.hmipagedef",StringComparison.OrdinalIgnoreCase));
            result["login_source_sha256"]=Hash(loginSource);
            object login;using(var stream=File.OpenRead(loginSource))login=Call(persistence,"Load",stream);
            result["login_page_objects"]=Count(Get(login,"ObjectsFromAllLayers"));
            var loginId=pageNodes.Single(p=>String.Equals((string)Get(p.Value,"DisplayName"),"Login",StringComparison.OrdinalIgnoreCase)).Key;
            var loginReference=New(T("Ade.Project.Content.ContentNodeReference","Ade.Project"),Guid.Empty,solutionId,loginId);
            var loginUri=new Uri("adeprojectref:///"+loginReference.ToString());
            Call(login,"SetContentNodeReference",loginReference,loginUri,new Uri(loginSource));
            var loginPath=Call(paths,"CreateOutputPathForPage",login,loginUri,messageLog);
            var loginContext=New(T("Ade.Hmi.Compiler.HmiJsonSerializer.HmiBuildContext"),common,new Uri(loginSource),"Login",loginId,login,New(T("Ade.Hmi.Compiler.PreparedOutputs")),New(T("Ade.Hmi.Compiler.PageDependenciesBuilder")),false,null);
            result["stage"]="serialize_login";
            var loginRoot=Call(T("Ade.Hmi.Compiler.HmiJsonSerializer.JsonHmiWriter"),"SerializeRoot",loginContext,login,"Login");
            if(loginRoot==null)throw new InvalidDataException("Login serialization returned null");
            var loginOutput=Call(Get(loginContext,"OutputBuilder"),"CreatePageOutput",ServiceValue(T("Ade.Hmi.DataList.IHmiPageDataTypeService","Ade.Hmi")),ServiceValue(T("Ade.Hmi.Model.Scripting.IScriptAnalyzer","Ade.Hmi")),loginUri,"Login",loginPath,loginRoot);
            Call(T("Ade.Hmi.Compiler.HmiJsonSerializer.HmiJsonSerializer"),"OutputHmiPage",loginRoot,Get(loginOutput,"PageAndSymbolVariables"),Get(loginOutput,"TrendViews"),Get(loginOutput,"ScriptText"),loginUri,loginPath,"Login",messageLog,Strict(T("Ade.DataTypes.IDataValueParser","Ade.DataTypes")),Strict(T("Ade.Hmi.Compiler.JsonSerializer.IInitValueConverter")),paths);
            result["login_complete"]=true;
            result["stage"]="generate_static_languages";
            var infoType=T("Ade.Project.Localization.Json.LocalResourcesBuildInfo","Ade.Project.Localization");
            var localized=(IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(infoType));
            localized.Add(LocalResources(page,source,"Gateway",pageNodes[pageId]));
            localized.Add(LocalResources(login,loginSource,"Login",pageNodes[loginId]));
            var defaultLanguages=new[]{source,loginSource}.Select(p=>XDocument.Load(p+".locres").Descendants("Languages").Single(e=>(string)e.Attribute("ID")=="0").Attribute("Name").Value).Distinct().ToArray();
            if(defaultLanguages.Length!=1)throw new InvalidDataException("Page default languages differ");
            result["default_language"]=defaultLanguages[0];
            var languageWriter=New(T("Ade.Hmi.Compiler.HmiJsonSerializer.HmiBuildLocalResources"),localized,defaultLanguages[0]);
            if(!(bool)Call(languageWriter,"WriteLocalResources",Path.Combine(output,"languages-static.dictionary.json"),null,null))throw new InvalidDataException("Static languages output failed");
            if(messages.Any(m=>m.Contains("MessageType=Error")))throw new InvalidDataException("HMI compiler emitted an error diagnostic");
            if(unsupported.Count>0)throw new InvalidDataException("HMI serializer encountered unsupported services");
            result["status"]="pages_generated";result["stage"]="complete";
            var expected=new[]{"gateway.json","gateway.variables.json","gatewayModule.js","login.json","login.variables.json","loginModule.js","languages-static.dictionary.json"};
            result["page_files"]=expected.Select(name=>{var file=Path.Combine(output,name);if(!File.Exists(file)||new FileInfo(file).Length==0)throw new InvalidDataException("Missing page output "+name);return new {path=name,sha256=Hash(file),size=new FileInfo(file).Length};}).ToArray();
            var sourceRoot=Path.Combine(job,"project");
            result["source_files"]=Directory.GetFiles(sourceRoot,"*",SearchOption.AllDirectories).Where(p=>p.EndsWith(".proj",StringComparison.OrdinalIgnoreCase)||p.EndsWith(".ds",StringComparison.OrdinalIgnoreCase)||p.EndsWith("DataList.dl",StringComparison.OrdinalIgnoreCase)||p.Contains("HMI_Server")).OrderBy(p=>p).Select(p=>new {path=Path.GetRelativePath(sourceRoot,p).Replace('\\','/'),sha256=Hash(p)}).ToArray();
            result["controller_tags"]=tags.Values.Where(t=>t.Scope==1).Select(t=>new{name=t.Name,data_type=t.DataType,runtime_path=t.RuntimePath,read_only=t.ReadOnly}).ToArray();
            result["source_sha256_after"]=Hash(source);
        }catch(Exception ex){
            var errors=new List<object>();
            for(var e=ex;e!=null;e=e.InnerException)errors.Add(new{type=e.GetType().FullName,message=e.Message,stack=e.StackTrace});
            result["errors"]=errors;
        }finally{
            result["service_calls"]=calls.Distinct().ToArray();result["service_call_count"]=calls.Count;result["unsupported"]=unsupported;
            result["first_chance"]=firstChance;
            result["loaded_assemblies"]=AppDomain.CurrentDomain.GetAssemblies().Select(a=>a.GetName().Name).Where(n=>n.StartsWith("Ade.")).OrderBy(n=>n).ToArray();
            result["online_dependency_note"]="Ade.Online can be loaded by the CLR to resolve DataList interface metadata. This host does not instantiate online services or invoke controller communication.";
            result["vendor_assemblies"]=AppDomain.CurrentDomain.GetAssemblies().Select(a=>a.GetName().Name).Where(n=>n.StartsWith("Ade.") && File.Exists(Path.Combine(install,n+".dll"))).OrderBy(n=>n).Select(n=>new{name=n,sha256=Hash(Path.Combine(install,n+".dll"))}).ToArray();
            AppDomain.CurrentDomain.AssemblyResolve-=resolver;
            AppDomain.CurrentDomain.FirstChanceException-=ObserveException;
        }
        return result;
    }
}
