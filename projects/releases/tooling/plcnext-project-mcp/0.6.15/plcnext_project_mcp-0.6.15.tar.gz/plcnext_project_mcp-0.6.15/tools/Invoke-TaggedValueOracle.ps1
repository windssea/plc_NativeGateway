param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputDirectory){throw 'Fresh oracle output directory required.'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
# Pure local DTO/value formatters only. No provider, socket, Engineer or ACI.
foreach($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Arp.System.Rsc.Services')){[void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name+'.dll')))}
$flags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
function T($name){foreach($a in [AppDomain]::CurrentDomain.GetAssemblies()){$type=$a.GetType($name,$false);if($null -ne $type){return $type}};throw "Missing type $name"}
$tagType=T 'Ade.CommonRemoting.Internal.TagInfo';$formatter=T 'Ade.CommonRemoting.Internal.RemotingFormatter'
$marshalType=T 'Ade.CommonRemoting.AdeMarshalType';$version=[Enum]::ToObject((T 'Ade.CommonRemoting.RemotingVersion'),4)
$script:vectors=@()
function Emit($name,$type,$value,$marshal=0,$expected=$null){
 $tag=[Activator]::CreateInstance($tagType,$flags,$null,[object[]]@($type,[Enum]::ToObject($marshalType,$marshal)),$null)
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory)
 [void]$formatter.GetMethod('SerializeValue',$flags).Invoke($null,[object[]]@($tag,$value,$writer,$version,$true,$false));$writer.Flush()
 $bytes=$memory.ToArray();$memory.Position=0;$reader=[IO.BinaryReader]::new($memory)
 $decoded=$formatter.GetMethod('DeserializeValue',$flags).Invoke($null,[object[]]@($tag,$reader,$version,$true,$false))
 if($memory.Position -ne $memory.Length){throw "Original reader left bytes: $name"}
 $file=Join-Path $OutputDirectory ($name+'.bin');[IO.File]::WriteAllBytes($file,$bytes)
 $script:vectors+=@{name=$name;type=$type.FullName;marshal=$marshal;input=$expected;bytes=$bytes.Length;hex=[Convert]::ToHexString($bytes).ToLowerInvariant();sha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant();original_reader_consumed_all=$true}
}
Emit 'bool-false' ([bool]) $false 0 $false
Emit 'bool-true' ([bool]) $true 0 $true
Emit 'byte-255' ([byte]) ([byte]255) 0 255
Emit 'sbyte-minus128' ([sbyte]) ([sbyte]-128) 0 ([sbyte]-128)
Emit 'int16-min' ([int16]) ([int16]::MinValue) 0 ([int16]::MinValue)
Emit 'uint16-max' ([uint16]) ([uint16]::MaxValue) 0 ([uint16]::MaxValue)
Emit 'int32-min' ([int32]) ([int32]::MinValue) 0 ([int32]::MinValue)
Emit 'int32-max' ([int32]) ([int32]::MaxValue) 0 ([int32]::MaxValue)
Emit 'uint32-zero' ([uint32]) ([uint32]0) 0 0
Emit 'uint32-max' ([uint32]) ([uint32]::MaxValue) 0 ([uint32]::MaxValue)
Emit 'int64-min' ([int64]) ([int64]::MinValue) 0 ([int64]::MinValue)
Emit 'uint64-max' ([uint64]) ([uint64]::MaxValue) 0 ([uint64]::MaxValue)
Emit 'single' ([single]) ([single]1.5) 0 1.5
Emit 'double' ([double]) ([double]-123.25) 0 ([double]-123.25)
Emit 'utf8-empty' ([string]) '' 2 ''
Emit 'utf8-ascii' ([string]) 'abc' 2 'abc'
Emit 'utf8-chinese' ([string]) '测试PLC' 2 '测试PLC'
Emit 'utf16-chinese' ([string]) '测试PLC' 1 '测试PLC'
Emit 'bytes-empty' ([byte[]]) ([byte[]]@()) 0 @()
Emit 'bytes-binary' ([byte[]]) ([byte[]]@(0,255,1,128)) 0 @(0,255,1,128)
Emit 'int32-array' ([int32[]]) ([int32[]]@(-1,0,42)) 0 @(-1,0,42)
Emit 'bool-array' ([bool[]]) ([bool[]]@($false,$true)) 0 @($false,$true)
Emit 'utf8-array' ([string[]]) ([string[]]@('abc','测试')) 2 @('abc','测试')
$tokenType=T 'Arp.Base.Rsc.Commons.Security.SecurityToken'
$token=[Activator]::CreateInstance($tokenType,$flags,$null,[object[]]@([uint32]1234567),$null)
Emit 'security-token' $tokenType $token 0 1234567
$dtoType=T 'Arp.System.Commons.Services.Io.WriteFileData';$traitType=T 'Arp.System.Commons.Services.Io.TraitItem';$traitsType=T 'Arp.System.Commons.Services.Io.Traits';$permissionsType=T 'Arp.System.Commons.Services.Io.Permissions'
$dto=[Activator]::CreateInstance($dtoType)
$dtoType.GetField('FilePath').SetValue($dto,'$ARP_PROJECTS_DIR$/PCWE/Plc/Eclr/eCLR.img')
$dtoType.GetField('Overwrite').SetValue($dto,$true)
$trait=[Activator]::CreateInstance($traitType);$traitType.GetField('Trait').SetValue($trait,[Enum]::ToObject($traitsType,1));$traitType.GetField('Value').SetValue($trait,[Enum]::ToObject($permissionsType,420))
$traits=[Array]::CreateInstance($traitType,1);$traits.SetValue($trait,0)
$dtoType.GetField('TraitItems').SetValue($dto,$traits)
$dtoType.GetField('Data').SetValue($dto,[IO.MemoryStream]::new([byte[]]@(0,1,255,128,65,66,0)))
$files=[Array]::CreateInstance($dtoType,1);$files.SetValue($dto,0)
Emit 'write-file-array' ($files.GetType()) $files
$dtoType.GetField('Data').GetValue($dto).Position=0
Emit 'write-file-struct' $dtoType $dto
@{scope='Pure tagged v4 SerializeValue/DeserializeValue on synthetic in-memory values; no service/provider/transport';network_operations=0;aci_calls=0;engineer_started=$false;tagging=$true;version=4;vectors=$script:vectors;assemblies=@('Arp.Base.Rsc.Commons.dll','Ade.CommonRemoting.Commons.dll','Arp.System.Rsc.Services.dll')|ForEach-Object{@{name=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $install $_)).Hash.ToLowerInvariant()}}}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8
Write-Output ('Verified {0} tagged value vectors' -f $script:vectors.Count)
