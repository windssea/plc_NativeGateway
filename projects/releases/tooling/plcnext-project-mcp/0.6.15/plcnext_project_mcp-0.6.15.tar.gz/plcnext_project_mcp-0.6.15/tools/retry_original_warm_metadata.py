"""User-requested retrial after reported manual hardware recovery.

Uses MCP-managed authorization. Reconciles only the known Stop-only failure
39f9e... using its journal and a fresh pinned state read. Never retries a
transfer, reuses a claim, changes a source, or removes an unknown lease.
"""
from __future__ import annotations
import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]
PROJECT = '17ae4361baa846868b14775bf1de15ea'
SOURCE_SHA = '7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154'
PACKAGE = 'f7fc619d55ba42c091f4ca0efed23e73'
PIN = '3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863'
PRIOR_PLAN_SHA = '57b4782926a986e0d2d04fe49066622975487e5bec2f8aede9712ad3d79ea652'
PRIOR_OPERATION = '27f7d8d94c3441198495fb3e0cefae05'
PRIOR_JOB = Path(r'D:\PLCnext-MCP-Workspace\17ae4361baa846868b14775bf1de15ea\controller-recoveries\1a6cb85ea258484688b0fad032478324')


async def main():
    source = Path('D:/PLCnext-MCP-Workspace/17ae4361baa846868b14775bf1de15ea/revision-0000.pcwex')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_SHA
    folder = ROOT / 'artifacts/original-recovery-hardware' / uuid.uuid4().hex
    folder.mkdir(parents=True)
    report = {'schema':'plcnext-original-recovery-hardware-test/v2',
        'created_utc':datetime.now(timezone.utc).isoformat(), 'project_id':PROJECT,
        'status':'preparing', 'authorization_channel':'mcp_managed', 'calls':[]}
    def save():
        (folder/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    save()
    print(json.dumps({'report_path':str(folder/'result.json')}),flush=True)
    environment = os.environ.copy()
    environment.update(PLCNEXT_MCP_WORKSPACE=r'D:\PLCnext-MCP-Workspace',
        PLCNEXT_ENGINEER_DIRECTORY=r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],
        env=environment,cwd=tempfile.gettempdir())
    try:
        async with stdio_client(params) as (read,write):
            async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=360)) as session:
                await session.initialize()
                async def call(name,args):
                    response=await session.call_tool(name,args)
                    value=response.structuredContent
                    if value is None:value=json.loads('\n'.join(x.text for x in response.content if x.type=='text'))
                    path=folder/f'{len(report["calls"]):03d}-{name}.json'
                    path.write_text(json.dumps({'tool':name,'arguments':args,'is_error':response.isError,
                        'result':value},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                    report['calls'].append({'tool':name,'is_error':response.isError,'report_path':str(path)})
                    save()
                    if response.isError:raise RuntimeError(name+' refused: '+str(value))
                    return value
                capabilities=await call('server_capabilities',{})
                assert capabilities['version']=='0.6.1'
                state=await call('controller_read_state',{'address':'192.168.0.8',
                    'expected_certificate_sha256':PIN,'timeout_seconds':5})
                raw=state.get('plc_state_raw')
                if raw != 0x100002:raise RuntimeError('Expected independently verified loaded Stop+Warm; no new hardware action.')
                prior=await call('project_controller_operation_status',{'project_id':PROJECT,
                    'operation_id':PRIOR_OPERATION,'expected_review_sha256':PRIOR_PLAN_SHA,'include_result':True})
                assert prior['status']=='needs_attention' and prior['phase']=='finished'
                old=json.loads((PRIOR_JOB/'result.json').read_text('utf-8'))
                events=[json.loads(line) for line in (PRIOR_JOB/'journal.jsonl').read_text('utf-8').splitlines()]
                sent=[e for e in events if e.get('mutating') and e.get('send_attempted')]
                assert old['stage']=='transferring' and not old['original_package_loaded']
                assert old['steps'][1]['files_verified']==49 and old['steps'][1]['load_ack_received']
                assert old['steps'][1]['last_state_raw']==0x100002
                assert old['steps'][1]['unacknowledged_mutation_requests'] == 0
                assert old['steps'][1]['configuration_reset_confirmed'] is True
                assert old['steps'][0]['terminal_state_verified'] is True
                lease=Path(old['endpoint_lease_path'])
                lease_bytes=lease.read_bytes()
                owner=json.loads(lease_bytes)
                assert owner['job_directory']==str(PRIOR_JOB)
                assert owner['review_sha256']==old['steps'][0]['review_sha256']
                assert owner['target']==old['target'] and owner['target']['expected_certificate_sha256']==PIN
                resolution={'schema':'plcnext-user-manual-recovery-reconciliation/v1',
                    'observed_utc':datetime.now(timezone.utc).isoformat(),
                    'prior_execution_id':old['execution_id'],'prior_review_sha256':PRIOR_PLAN_SHA,
                    'fresh_read':state,'prior_stop_completed_verified':True,
                    'user_statement':'我重新刷入了。你继续重试刷入',
                    'prior_outcome_record_preserved':True,
                    'reason':'Prior 49-file readback, Reset completion and Load ACK are recorded. Original enum identifies 0x100000 as Warm, not an error; fresh pinned read confirms Stop+Warm. New explicit complete trial uses the corrected state parser; old uncertainty record is preserved.',
                    'prior_receipts_claims_and_journal_retained':True,
                    'lease_sha256':hashlib.sha256(lease_bytes).hexdigest(),
                    'mcp_autonomous_authorization_user_instruction':'移除这个限制，mcp可以自行决定'}
                resolution_path=folder/'stop-only-reconciliation.json'
                resolution_path.write_text(json.dumps(resolution,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                if lease.read_bytes()!=lease_bytes:raise RuntimeError('Lease owner changed; no reconciliation.')
                archived=lease.with_name(lease.stem+'.reconciled-'+uuid.uuid4().hex+'.json')
                lease.rename(archived)
                report['prior_stop_reconciliation']={'report_path':str(resolution_path),'archived_lease_path':str(archived)}
                save()
                print(json.dumps({'status':'loaded_stop_warm_metadata_reconciled','plc_state_raw':raw}),flush=True)
                plan=await call('project_prepare_recovery',{'project_id':PROJECT,'expected_project_sha256':SOURCE_SHA,
                    'package_job_id':PACKAGE,'address':'192.168.0.8','expected_certificate_sha256':PIN,
                    'expected_initial_state':raw,'volatile_data_policy':'record_unknown_loss','start_kind':'cold',
                    'expected_configuration':{'version':13,'device_count':50,'point_count':250,'enabled':True}})
                report['plan']={k:plan[k] for k in ('plan_id','plan_sha256')}
                approval=await call('project_authorize_controller_operation',{'project_id':PROJECT,
                    'review_id':plan['plan_id'],'expected_review_sha256':plan['plan_sha256'],'kind':'recovery',
                    'reason':'User manually reflashed the device and explicitly requests another flash. Loaded Stop+Warm observed, confirmed as normal metadata by original enum. New exact plan preserves optional Src backups and uses SHA512 comparison to avoid rewriting unchanged mapped native libraries.',
                    'lifetime_seconds':900})
                assert approval['status']=='ready' and approval['confirmed_by']=='mcp_policy'
                report['authorization']=approval
                operation=await call('project_start_recovery_job',{'project_id':PROJECT,
                    'plan_id':plan['plan_id'],'expected_plan_sha256':plan['plan_sha256']})
                report['operation_id']=operation['operation_id'];save()
                previous=None
                while True:
                    summary={k:operation.get(k) for k in ('operation_id','status','phase','execution_result_status',
                        'outcome_unknown','controller_changed','driver_report_path')}
                    if summary!=previous:print(json.dumps(summary),flush=True);previous=summary
                    if operation['status'] in ('completed','failed','needs_attention','worker_outcome_unknown'):
                        report.update(status=operation['status'],operation=operation);save();break
                    await asyncio.sleep(2)
                    operation=await call('project_controller_operation_status',{'project_id':PROJECT,
                        'operation_id':operation['operation_id'],'expected_review_sha256':plan['plan_sha256'],
                        'include_result':True})
    except BaseException as exc:
        report.update(status='client_error_requires_inspection',error_class=type(exc).__name__,error=str(exc),automatic_retry=False)
        save()
        raise
    finally:
        report.update(finished_utc=datetime.now(timezone.utc).isoformat(),
            frozen_source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==SOURCE_SHA)
        save()
        print(json.dumps({'status':report['status'],'report_path':str(folder/'result.json')}),flush=True)


if __name__=='__main__':asyncio.run(main())
