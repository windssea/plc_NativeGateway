"""Real stdio MCP integration test against a copied NativeGateway project."""
import asyncio
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    root = Path(__file__).resolve().parents[1]
    output = root / 'artifacts' / 'native-mcp-e2e'
    output.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ)
    environment['PLCNEXT_MCP_WORKSPACE'] = str(output / 'workspace')
    parameters = StdioServerParameters(command=sys.executable,
                                       args=['-m', 'plcnext_mcp.server'], env=environment)
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as client:
            await client.initialize()
            tools = await client.list_tools()

            async def call(name, arguments):
                response = await client.call_tool(name, arguments)
                if response.isError:
                    raise RuntimeError(str(response.content))
                return response.structuredContent or json.loads(response.content[0].text)

            capabilities = await call('server_capabilities', {})
            original = root / 'artifacts' / 'aci-poc' / 'NativeGateway.frozen.pcwex'
            imported = await call('project_import_copy', {'source_path': str(original)})
            pid = imported['project_id']
            pou = await call('project_read_pou', {'project_id': pid, 'pou_name': 'NG_ReadAck'})
            before_refs = await call('project_find_references', {'project_id': pid, 'pou_name': 'NG_ReadAck'})
            old = 'IF NOT Stored AND (count=0) THEN RETURN; END_IF;'
            patch_args = {
                'project_id': pid, 'pou_name': 'NG_ReadAck',
                'expected_project_sha256': pou['project_sha256'],
                'expected_code_sha256': pou['code_sha256'], 'old_text': old,
                'new_text': '(* Native MCP: independent file edit; no ACI calls. *)\nIF (NOT Stored) AND (count=0) THEN RETURN; END_IF;',
            }
            patched = await call('project_patch_st', patch_args)
            validation = await call('project_validate', {'project_id': pid})
            after_refs = await call('project_find_references', {'project_id': pid, 'pou_name': 'NG_ReadAck'})
            stale = await client.call_tool('project_patch_st', patch_args)
            build = await call('project_build_plan', {'project_id': pid})
            difference = await call('project_diff', {'project_id': pid, 'pou_name': 'NG_ReadAck'})
            assert stale.isError, 'Stale edit was not rejected'
            assert validation['preservation_passed']
            assert validation['changed_members'] == ['PROJECT/Logical%20Elements/NG_ReadAck.pou/Code.st']
            assert before_refs == after_refs
            assert capabilities['aci_dependency'] is False
            assert capabilities['full_project_headless_compile'] is False
            assert build['compiled'] is False
            report = {
                'transport': 'MCP stdio', 'status': 'passed', 'aci_used': False,
                'tools': [tool.name for tool in tools.tools], 'capabilities': capabilities,
                'original_copy': imported, 'patched': patched, 'validation': validation,
                'references_before': before_refs, 'references_after': after_refs,
                'stale_patch_rejected': stale.isError, 'build': build, 'diff': difference,
                'plc_connected': False, 'plc_downloaded': False,
            }
            (output / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps({'status': report['status'], 'tools': len(tools.tools),
                              'project_path': patched['project_path'],
                              'only_target_code_changed': True, 'compiled': False}))


if __name__ == '__main__':
    asyncio.run(main())
