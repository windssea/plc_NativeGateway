"""Clean wheel: actual MCP/local TCP transfer and denied unapproved device route."""
import argparse
import asyncio
from datetime import timedelta
import importlib.metadata
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import plcnext_mcp

PROJECT = 'a2512e4f551645e4acd00fae07f003cd'
HASH = 'e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0'
PACKAGE = '345799d58da449ef86866865021a3806'
REVIEW = '29a6e79b0b984dc399f7b595d8216daa'
REVIEW_HASH = '69af4f624198c2c1a4b2cf408576ec158495059f9eb13f402d42408f24773244'


async def main(output):
    output.mkdir(parents=True, exist_ok=True)
    module = Path(plcnext_mcp.__file__).resolve()
    assert importlib.metadata.version('plcnext-project-mcp') == '0.5.0'
    assert 'site-packages' in str(module) and not module.is_relative_to(Path(__file__).resolve().parents[1] / 'src')
    for item in ('controller_transport.py', 'controller_transfer.py', 'controller_download_plan.py',
                 'controller_test_peer.py', 'rsc_error_codec.py', 'rsc_plc_control.py',
                 'simulation_tls/server.pem', 'simulation_tls/server-public-test-key.pem',
                 'aci_contract/aci_2026_0_4.json'):
        assert (module.parent / item).is_file(), item
    foreign = output / 'foreign-cwd'
    foreign.mkdir(exist_ok=True)
    params = StdioServerParameters(command=sys.executable, args=['-I', '-m', 'plcnext_mcp.server'],
        cwd=str(foreign), env=dict(os.environ, PLCNEXT_MCP_WORKSPACE='D:/PLCnext-MCP-Workspace'))
    summary = {'status': 'running', 'version': '0.5.0', 'package_module': str(module),
               'source_imports': False, 'aci_used': False, 'engineer_started': False,
               'real_controller_connected': False, 'real_controller_downloaded': False,
               'operator_approval_created': False}
    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(params, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=180)) as client:
                    await client.initialize()
                    assert len((await client.list_tools()).tools) == 35
                    async def call(name, args, label):
                        result = await client.call_tool(name, args)
                        assert not result.isError, result.content
                        value = result.structuredContent or json.loads(result.content[0].text)
                        (output / (label + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
                        return value
                    await call('aci_replacement_status', {}, '01-capability-coverage')
                    review = await call('project_inspect_download_review', {'project_id': PROJECT,
                        'review_id': REVIEW, 'expected_review_sha256': REVIEW_HASH}, '02-review')
                    assert not review['write_authorized'] and review['revalidated_against_current_package']
                    result = await call('project_test_controller_download', {'project_id': PROJECT,
                        'expected_project_sha256': HASH, 'package_job_id': PACKAGE,
                        'fault': 'chunked_readback'}, '03-local-socket-transfer')
                    assert result['status'] == 'loopback_download_passed' and result['files_verified'] == 48
                    assert result['peer_files_match_package'] and result['load_state_verified']
                    assert result['peer_thread_stopped'] and result['receipt_persisted']
                    assert result['socket_transport_used'] and not result['memory_bio_used']
                    denied = await client.call_tool('project_execute_controller_download', {'project_id': PROJECT,
                        'review_id': REVIEW, 'expected_review_sha256': REVIEW_HASH})
                    assert denied.isError and 'operator approval' in str(denied.content)
                    summary.update(status='passed', tools=35, transferred_files=48,
                        transferred_bytes=result['bytes_verified'], sha512_readback=True,
                        local_reset_load_verified=True, unapproved_real_execution_rejected=True,
                        test_report=result['report_path'])
    except BaseException as exc:
        summary.update(status='failed', error=str(exc))
        raise
    finally:
        (output / 'result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'report': str(output / 'result.json'), **summary}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    asyncio.run(main(parser.parse_args().output.resolve()))
