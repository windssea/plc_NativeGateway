"""Registered MCP download flow: current copy and a memory-only PLC double."""
import asyncio
from datetime import timedelta
import json
from pathlib import Path
import shutil
import subprocess
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]
PROJECT = 'a431bdc32f2a4aa1812c94683db38395'
PACKAGE = '5e4a155de2d8486ba6df5f0a019380a1'


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


async def main():
    run = uuid.uuid4().hex
    output = ROOT / 'artifacts/download-simulation-mcp-e2e' / run
    output.mkdir(parents=True)
    registration = json.loads(subprocess.check_output(
        [shutil.which('codex'), 'mcp', 'get', 'plcnext-project', '--json'], text=True, encoding='utf-8'))
    transport = registration['transport']
    assert registration['enabled'] and transport['type'] == 'stdio'
    cwd = Path(transport['env']['PLCNEXT_MCP_WORKSPACE']) / 'client-probes' / run
    cwd.mkdir(parents=True)
    assert not cwd.resolve().is_relative_to(ROOT.resolve())
    parameters = StdioServerParameters(command=transport['command'], args=transport['args'],
        env=transport['env'], cwd=str(cwd))
    summary = {'status': 'running', 'registered_transport_used_unchanged': True,
        'client_directory': str(cwd), 'controller_connected': False, 'controller_downloaded': False,
        'program_started': False, 'deployable': False, 'simulation_runs': []}
    save(output / 'result.json', summary)

    async def call(client, name, args, reject=False):
        response = await client.call_tool(name, args)
        if reject:
            assert response.isError, name + ' was expected to reject invalid input'
            return {'rejected': True, 'message': '\n'.join(x.text for x in response.content if hasattr(x, 'text'))}
        assert not response.isError, (name, response.content)
        return response.structuredContent or json.loads(response.content[0].text)

    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(parameters, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=120)) as client:
                    await client.initialize()
                    tools = sorted(t.name for t in (await client.list_tools()).tools)
                    assert {'project_download_plan', 'project_simulate_download'} <= set(tools)
                    save(output / 'tools.json', tools)
                    summary['tool_count'] = len(tools)
                    capabilities = await call(client, 'server_capabilities', {})
                    assert capabilities['download_simulation']['available']
                    assert not capabilities['controller_write_access']
                    assert not capabilities['deployment_preparation']['controller_transport']
                    save(output / 'capabilities.json', capabilities)
                    before = await call(client, 'project_inspect', {'project_id': PROJECT})
                    args = {'project_id': PROJECT, 'expected_project_sha256': before['project_sha256'],
                            'package_job_id': PACKAGE}
                    plan = await call(client, 'project_download_plan', args)
                    save(output / 'plan.json', plan)
                    assert plan['file_count'] == 48 and plan['total_bytes'] == 9370814
                    assert plan['variable_count'] == 77 and plan['fb_instance_count'] == 109
                    assert plan['hmi_mapping_count'] == 10 and not plan['real_transport_available']
                    for name, bad in [('stale-source', {'expected_project_sha256': '0' * 64}),
                                      ('path-escape', {'package_job_id': '../outside'})]:
                        save(output / (name + '-rejected.json'),
                             await call(client, 'project_simulate_download', args | bad, True))
                    for fault in plan['available_faults']:
                        result = await call(client, 'project_simulate_download', args | {'fault': fault})
                        save(output / (fault + '.json'), result)
                        assert result['source_and_package_unchanged']
                        assert result['simulated_session_disposed'] and result['no_automatic_retries']
                        assert not result['controller_connected'] and not result['controller_downloaded']
                        assert not result['program_started'] and not result['deployable']
                        assert result['network_operations_performed'] == 0
                        assert result['status'] == ('simulation_passed' if fault == 'none' else 'simulation_failed')
                        trace = json.loads(Path(result['trace_path']).read_bytes())
                        ops = [item['operation'] for item in trace]
                        assert not any(op.endswith(('Start', 'Change', 'Restart')) for op in ops)
                        if fault == 'none':
                            assert result['files_verified'] == 48 and result['bytes_verified'] == 9370814
                            assert result['simulated_configuration_loaded'] and result['final_device_state'] == 7
                            assert result['binary_rpc_loopback_used'] and result['rpc_close_session_confirmed']
                            assert result['rpc_exchanges_completed'] == result['memory_tls']['exchange_count']
                            assert result['memory_tls']['tls_version'] == 'TLSv1.2'
                            assert result['memory_tls']['application_data_roundtrip']
                            assert ops.count('Simulator.RscConnect') == 1 and ops.count('Simulator.RscGetServiceHandles') == 4
                            assert len({t['service'] for t in trace if t['operation'] == 'Simulator.RscInvoke'}) == 4
                            assert ops.index('IFileService2.ReadMany') < ops.index('IPlcManagerService.Reset') < ops.index('IPlcManagerService.Load')
                        else:
                            assert not result['simulated_configuration_loaded']
                            if fault not in ('reset_timeout', 'load_timeout', 'load_error'):
                                assert 'IPlcManagerService.Reset' not in ops and 'IPlcManagerService.Load' not in ops
                        secret_keys = {'username', 'password', 'token', 'security_token', 'private_key'}
                        assert all(not (set(item) & secret_keys) for item in trace)
                        summary['simulation_runs'].append({'fault': fault, 'status': result['status'],
                            'failure_code': result.get('failure_code'), 'simulation_id': result['simulation_id']})
                    after = await call(client, 'project_inspect', {'project_id': PROJECT})
                    again = await call(client, 'project_download_plan', args)
                    assert after['project_sha256'] == before['project_sha256']
                    assert again['inventory_sha256'] == plan['inventory_sha256']
                    summary.update(status='passed', source_sha256=after['project_sha256'],
                        source_and_package_unchanged=True, file_count=48,
                        verified_simulation_count=len(summary['simulation_runs']),
                        bounded_binary_rpc_tls_flow_verified=True,
                        real_network_used_by_download_flow=False)
    except BaseException as exc:
        summary.update(status='failed', error=str(exc))
        raise
    finally:
        save(output / 'result.json', summary)
        print(json.dumps({'report': str(output / 'result.json'), **summary}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())
