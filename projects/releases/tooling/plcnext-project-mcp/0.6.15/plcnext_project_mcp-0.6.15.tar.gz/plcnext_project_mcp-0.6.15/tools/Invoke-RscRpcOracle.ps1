param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputDirectory){throw 'RPC oracle output must be a new directory.'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
foreach($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Ade.CommonRemoting','Arp.System.Rsc.Services')){[void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name+'.dll')))}
$flags=[Reflection.BindingFlags]'Public,NonPublic,Instance,Static'
function T($name){foreach($a in [AppDomain]::CurrentDomain.GetAssemblies()){$t=$a.GetType($name,$false);if($null -ne $t){return $t}};throw "Missing type $name"}
function N($type,$arguments){return [Activator]::CreateInstance($type,$flags,$null,[object[]]$arguments,$null)}
$headerType=T 'Ade.CommonRemoting.CommandHeader';$tokenType=T 'Arp.Base.Rsc.Commons.Security.SecurityToken'
$marshalType=T 'Ade.CommonRemoting.AdeMarshalType';$versionType=T 'Ade.CommonRemoting.RemotingVersion'
$tagType=T 'Ade.CommonRemoting.Internal.TagInfo';$formatter=T 'Ade.CommonRemoting.Internal.RemotingFormatter'
$callType=T 'Ade.CommonRemoting.Internal.CallMessage';$streamType=T 'Ade.CommonRemoting.Internal.RemotingStream'
$formatter4=T 'Ade.CommonRemoting.Internal.RemotingFormatter4';$auth=T 'Arp.System.Security.Services.IPasswordAuthenticationService'
$errorType=T 'Arp.System.Security.Services.AuthenticationError'
$version=[Enum]::ToObject($versionType,4)
function Tag($type){return N $tagType @($type,[Enum]::ToObject($marshalType,0))}
function Stream($memory){$s=N $streamType @($memory,[object]::new(),$false);$streamType.GetProperty('RemotingVersion',$flags).SetValue($s,$version);return $s}
function Header($command,$service=0,$method=0,$provider=0){
 $h=[Activator]::CreateInstance($headerType)
 foreach($entry in @{Version=[byte]4;CommandType=[Enum]::ToObject((T 'Ade.CommonRemoting.CommandType'),[int16]$command);ServiceHandle=[int16]$service;MethodHandle=[int16]$method;ServiceProviderHandle=[int16]$provider}.GetEnumerator()){$headerType.GetProperty($entry.Key).SetValue($h,$entry.Value)}
 return $h
}
function WriteHeader($h,$writer){$m=$headerType.GetMethods($flags)|Where-Object {$_.Name -eq 'Write' -and $_.GetParameters()[2].ParameterType -eq [bool]};[void]$m.Invoke($null,[object[]]@($h,$writer,$true))}
$script:results=@()
function Save($name,$data,$metadata=@{}){
 $file=Join-Path $OutputDirectory ($name+'.bin');[IO.File]::WriteAllBytes($file,$data)
 $script:results+=@{name=$name;file=($name+'.bin');bytes=$data.Length;sha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant();metadata=$metadata}
}
function Call($method,$arguments){
 $props=[Collections.Hashtable]::new()
 $ins=@($method.GetParameters()|Where-Object {-not $_.IsOut}).Count
 $outs=@($method.GetParameters()|Where-Object IsOut).Count
 if($method.ReturnType -ne [void]){$outs++}
 # This follows RemotingProxy.Init: marshal each real parameter/return through
 # the original GetMarshalType(attrs), rather than guessing default enum zero.
 $inValues=[Collections.Generic.List[object]]::new();$outValues=[Collections.Generic.List[object]]::new()
 foreach($parameter in $method.GetParameters()){
  $attrs=[object[]]$parameter.GetCustomAttributes($false)
  $marshal=$formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attrs))
  if($parameter.IsOut){$outValues.Add($marshal)}else{$inValues.Add($marshal)}
 }
 if($method.ReturnType -ne [void]){
  $attrs=[object[]]$method.ReturnParameter.GetCustomAttributes($false)
  $outValues.Add($formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attrs)))
 }
 $props['AdeInMarshalling']=[Array]::CreateInstance($marshalType,$inValues.Count)
 $props['AdeOutMarshalling']=[Array]::CreateInstance($marshalType,$outValues.Count)
 for($i=0;$i -lt $inValues.Count;$i++){$props['AdeInMarshalling'].SetValue($inValues[$i],$i)}
 for($i=0;$i -lt $outValues.Count;$i++){$props['AdeOutMarshalling'].SetValue($outValues[$i],$i)}
 return N $callType @($method,[object[]]$arguments,$props)
}
function InvokeBytes($call,$method,$withToken){
 $memory=[IO.MemoryStream]::new();$stream=Stream $memory
 if($withToken){$token=N $tokenType @([uint32]0);$streamType.GetProperty('AuthenticationToken',$flags).SetValue($stream,$token)}
 [void]$formatter4.GetMethod('SerializeMessage',$flags).Invoke($null,[object[]]@([int16]$method,[int16]41,[int16]5,$call,$stream,$version))
 return ,$memory.ToArray()
}
function ValueBytes($types,$values){
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory)
 for($i=0;$i -lt $types.Length;$i++){[void]$formatter.GetMethod('SerializeValue',$flags).Invoke($null,[object[]]@((Tag $types[$i]),$values[$i],$writer,$version,$false,$false))}
 return ,$memory.ToArray()
}
# Protected SendRequest methods only write into a MemoryStream; no Execute/network.
foreach($kind in @('connect','getservice')){
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory);$h=Header 0
 if($kind -eq 'connect'){$type=T 'Ade.CommonRemoting.Internal.Commands.ConnectCommand';$command=N $type @([Enum]::ToObject((T 'Ade.CommonRemoting.RemotingCompabilityModes'),15))}
 else {$type=T 'Ade.CommonRemoting.Internal.Commands.GetServiceHandlesCommand';$command=N $type @('Arp','Arp.System.Security.Services.IPasswordAuthenticationService')}
 $args=[object[]]@($writer,$h);[void]$type.GetMethod('SendRequest',$flags).Invoke($command,$args)
 Save $kind $memory.ToArray()
}
$password=[Security.SecureString]::new();foreach($c in 'offline-fixture-only'.ToCharArray()){$password.AppendChar($c)};$password.MakeReadOnly()
try {
 $create=Call ($auth.GetMethod('CreateSession')) @('offline-user',$password,$null,0)
 Save 'create-session-request' (InvokeBytes $create 1 $false)
 $token=N $tokenType @([uint32]0)
 $close=Call ($auth.GetMethod('CloseSession')) @($token)
 Save 'close-session-request' (InvokeBytes $close 2 $true)
 foreach($case in @(@{name='success';token=[uint32]0;penalty=0;error=0},@{name='invalid-credentials';token=[uint32]0;penalty=250;error=-1},@{name='penalty-active';token=[uint32]0;penalty=500;error=-2})){
  if($null -eq $case.token){$token=[Activator]::CreateInstance($tokenType)}else{$token=N $tokenType @($case.token)}
  $body=ValueBytes @($tokenType,[int32],$errorType) @($token,[int32]$case.penalty,[Enum]::ToObject($errorType,[int]$case.error))
  $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory)
  WriteHeader (Header 3 41 1 5) $writer;$writer.Write($body)
  $raw=$memory.ToArray();Save ('create-session-response-'+$case.name) $raw
  # Verify the concatenated OUT then RETURN body with the actual original reader.
  $readMemory=[IO.MemoryStream]::new($raw);$readStream=Stream $readMemory
  $response=$formatter4.GetMethod('DeserializeMessage',$flags).Invoke($null,[object[]]@($readStream,$create,$version))
  if($readMemory.Position -ne $readMemory.Length){throw 'Original reader left return bytes unconsumed.'}
 }
 # Void response is a header with no typed values.
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory);WriteHeader (Header 3 41 2 5) $writer
 Save 'close-session-response' $memory.ToArray()
 # Error body uses UInt32, String, Object[]; validate with original ReadError2.
 $body=ValueBytes @([uint32],[string],[object[]]) @([uint32]65537,'offline error',[object[]]@())
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory);WriteHeader (Header 4 41 1 5) $writer;$writer.Write($body)
 $raw=$memory.ToArray();Save 'server-error-response' $raw
 $reader=Stream ([IO.MemoryStream]::new($raw));$response=$formatter4.GetMethod('DeserializeMessage',$flags).Invoke($null,[object[]]@($reader,$create,$version))
 foreach($kind in @('connect-confirmation','getservice-confirmation')){
  $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory)
  if($kind -eq 'connect-confirmation'){$h=Header 8;$type=T 'Ade.CommonRemoting.Internal.Commands.ConnectCommand';$command=N $type @([Enum]::ToObject((T 'Ade.CommonRemoting.RemotingCompabilityModes'),15))}
  else {$h=Header 16 41 0 5;$type=T 'Ade.CommonRemoting.Internal.Commands.GetServiceHandlesCommand';$command=N $type @('Arp','Arp.System.Security.Services.IPasswordAuthenticationService')}
  WriteHeader $h $writer;$raw=$memory.ToArray();Save $kind $raw
  $reader=Stream ([IO.MemoryStream]::new($raw));$accepted=$type.GetMethod('ReceiveReponse',$flags).Invoke($command,[object[]]@($reader))
  if(-not $accepted){throw 'Original negotiation reader rejected confirmation.'}
 }
} finally {$password.Dispose()}
$methods=@($auth.GetMethods()|ForEach-Object {@{name=$_.Name;attributes=@($_.GetCustomAttributesData()|ForEach-Object{$_.ToString()});parameters=@($_.GetParameters()|ForEach-Object{@{name=$_.Name;type=$_.ParameterType.FullName;attributes=@($_.GetCustomAttributesData()|ForEach-Object{$_.ToString()})}})}})
$providerType=T 'Ade.CommonRemoting.CommonRemotingProvider'
$discovery=@()
foreach($serviceName in @('Arp.System.Security.Services.IPasswordAuthenticationService','Arp.System.Commons.Services.Io.IFileService2','Arp.System.Commons.Services.Io.IFileSystemInfoService','Arp.Plc.Domain.Services.IPlcManagerService')){
 $serviceType=T $serviceName
 $names=$providerType.GetMethod('GetServiceTypeNames',$flags).Invoke($null,[object[]]@($serviceType))
 $providerName=$providerType.GetMethod('GetServiceProviderName',$flags).Invoke($null,[object[]]@($serviceType))
 $discovery+=@{interface=$serviceName;wire_names=@($names);provider=$providerName}
}
@{scope='Pure original command/formatter to MemoryStream and static naming metadata; v4 untagged no datagrams; no provider instances/sockets';network_operations=0;methods=$methods;service_discovery=$discovery;vectors=$results}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8
Write-Output ('Saved {0} complete RPC vectors' -f $results.Count)
