"""Exact current-site M11 acceptance via public MCP only; no device writes."""
import asyncio
from datetime import timedelta
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    root=Path(__file__).resolve().parents[1]
    folder=root/'artifacts/lease-reconciliation'/uuid.uuid4().hex;folder.mkdir(parents=True)
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']=r'D:\PLCnext-MCP-Workspace'
    env['PLCNEXT_ENGINEER_DIRECTORY']=r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    calls=[]
    async with stdio_client(params) as (read,write):
        async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=180)) as session:
            await session.initialize()
            async def call(name,args):
                answer=await session.call_tool(name,args)
                value=answer.structuredContent
                if value is None:value=json.loads('\n'.join(x.text for x in answer.content if x.type=='text'))
                record={'tool':name,'arguments':args,'is_error':answer.isError,'result':value}
                (folder/(str(len(calls)).zfill(2)+'-'+name+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
                calls.append(name)
                if answer.isError:raise RuntimeError(str(value))
                return value
            cap=await call('server_capabilities',{});assert cap['version']=='0.6.10'
            inventory=await session.list_tools();assert len(inventory.tools)==80
            frozen=root/'docs/evidence/lease-observation-20261027'
            import hashlib
            external=frozen/'stable-after-engineer-read.json'
            saved=json.loads(external.read_text(encoding='utf-8'))['result']
            boot=next(x['value'] for x in saved['guards_after'] if x['symbol']=='MainInstance.BootId')
            plan=await call('project_prepare_observation_reconciliation',{
                'project_id':'f40a214f31ea4ec28b5d9fd39c77c5ee','operation_id':'8dddb048dc9a49e7aa22d36c3322229c',
                'expected_review_sha256':'411eaf240ef00ab0242d36222bf6388fb242b0f7b8e7a2407b9a6041ea01332f',
                'expected_certificate_sha256':'3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863',
                'current_project_id':saved['project_id'],'current_project_sha256':saved['source_project_sha256'],
                'current_read_plan_id':saved['plan_id'],'current_read_plan_sha256':saved['plan_sha256'],
                'expected_boot_id':boot,'expected_configuration':{'version':15,'device_count':50,'point_count':250,'enabled':True},
                'expected_configuration_sha256':saved['configuration_digest']['sha256'],
                'external_evidence_path':str(external.resolve()),'external_evidence_sha256':hashlib.sha256(external.read_bytes()).hexdigest(),
                'description':'Engineer external recovery record: stable native-0.5.0, explicit v15; old failed candidate execution is preserved. Current identity checked by fresh read only; no memory image attestation.'})
            args={'project_id':plan['project_id'],'plan_id':plan['plan_id'],'expected_plan_sha256':plan['plan_sha256']}
            await call('project_inspect_lease_reconciliation',args)
            if '--execute' not in sys.argv:
                print(json.dumps({'status':'prepared','plan':args,'report_directory':str(folder)},ensure_ascii=False));return
            await call('project_authorize_controller_operation',{'project_id':plan['project_id'],
                'review_id':plan['plan_id'],'expected_review_sha256':plan['plan_sha256'],
                'kind':'lease_reconciliation','reason':'User requests observation failure / external recovery handoff acceptance A7. Preserve old failure, consumed authorization and frozen evidence. Exact current stable source, boot77, v15 and configuration digest rechecked. Archive this old local lease only; no PLC writes or automatic recovery.'})
            result=await call('project_execute_lease_reconciliation',args)
            assert result['status']=='reconciled' and result['controller_changed'] is False
            await call('project_inspect_lease_reconciliation',args)
            old_result=Path(env['PLCNEXT_MCP_WORKSPACE'])/plan['project_id']/'controller-recoveries/711127a1cad745db9bc76804c5e1dbc8/result.json'
            assert hashlib.sha256(old_result.read_bytes()).hexdigest()==result['evidence']['driver_result_sha256']
            summary={'status':'reconciled','version':cap['version'],'tool_count':len(inventory.tools),'plan':args,
                'archive_path':result['archive_path'],'old_evidence':result['evidence'],'result_sha256':hashlib.sha256((Path(env['PLCNEXT_MCP_WORKSPACE'])/plan['project_id']/'lease-reconciliations'/plan['plan_id']/'result.json').read_bytes()).hexdigest(),
                'observation':result['observation'],'controller_changed':False,'calls':calls}
            (folder/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps({'status':'reconciled','report_path':str(folder/'result.json')},ensure_ascii=False))

if __name__=='__main__':asyncio.run(main())
