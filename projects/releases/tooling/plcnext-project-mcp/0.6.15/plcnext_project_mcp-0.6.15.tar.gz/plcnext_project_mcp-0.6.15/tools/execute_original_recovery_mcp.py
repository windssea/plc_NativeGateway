"""Execute only the frozen, separately approved original recovery plan via MCP.

Never issues approvals. Keeps the MCP host alive until its fixed recovery worker
has a terminal receipt. Does not retry or reverse any controller action.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from plcnext_mcp.operator_approval import load_approval_contract, inspect_operator_approval
from plcnext_mcp.project import ProjectStore

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = Path(r'D:\PLCnext-MCP-Workspace')
PROJECT = '17ae4361baa846868b14775bf1de15ea'
PLAN = 'b5394f7a512c4c94b2a5836f9abc7671'
DIGEST = '0b977fedac3979549b95f9686de48809a8eb82398a29471c62368ec6e19dc3bc'
SOURCE = Path(r'D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex')
SOURCE_DIGEST = '7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154'


async def main():
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_DIGEST:
        raise RuntimeError('Original source changed; no operation started.')
    store = ProjectStore(WORKSPACE)
    contract = load_approval_contract(store, 'recovery', PROJECT, PLAN, DIGEST)
    approval = inspect_operator_approval(WORKSPACE, contract)
    print(json.dumps({k: approval.get(k) for k in ('status', 'receipt_path', 'expires_utc')}), flush=True)
    if approval['status'] != 'ready':
        raise RuntimeError('Exact operator receipt is not ready; no PLC connection made.')
    output = ROOT / 'artifacts' / 'original-recovery-hardware' / uuid.uuid4().hex
    output.mkdir(parents=True)
    record = {'schema': 'plcnext-original-recovery-hardware-test/v1',
        'created_utc': datetime.now(timezone.utc).isoformat(), 'project_id': PROJECT,
        'plan_id': PLAN, 'plan_sha256': DIGEST, 'approval_inspection': approval,
        'source_sha256': SOURCE_DIGEST, 'status': 'starting', 'calls': []}

    def save():
        (output / 'result.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    save()
    print(json.dumps({'report_path': str(output / 'result.json')}), flush=True)
    environment = os.environ.copy()
    environment.update(PLCNEXT_MCP_WORKSPACE=str(WORKSPACE),
        PLCNEXT_ENGINEER_DIRECTORY=r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')
    parameters = StdioServerParameters(command=sys.executable,
        args=['-I', '-m', 'plcnext_mcp.server'], env=environment, cwd=tempfile.gettempdir())
    try:
        async with stdio_client(parameters) as (read, write):
            async with ClientSession(read, write, read_timeout_seconds=timedelta(seconds=360)) as session:
                await session.initialize()

                async def call(name, arguments):
                    response = await session.call_tool(name, arguments)
                    value = response.structuredContent
                    if value is None:
                        value = json.loads('\n'.join(item.text for item in response.content if item.type == 'text'))
                    path = output / f'{len(record["calls"]):03d}-{name}.json'
                    path.write_text(json.dumps({'tool': name, 'arguments': arguments,
                        'is_error': response.isError, 'result': value}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
                    record['calls'].append({'tool': name, 'report_path': str(path), 'is_error': response.isError})
                    save()
                    if response.isError:
                        raise RuntimeError(f'{name} refused: {value}')
                    return value

                operation = await call('project_start_recovery_job', {
                    'project_id': PROJECT, 'plan_id': PLAN, 'expected_plan_sha256': DIGEST})
                record['operation_id'] = operation['operation_id']
                record['status'] = 'running'
                save()
                previous = None
                while True:
                    state = (operation.get('status'), operation.get('phase'))
                    if state != previous:
                        print(json.dumps({k: operation.get(k) for k in (
                            'operation_id', 'status', 'phase', 'execution_result_status',
                            'outcome_unknown', 'controller_changed', 'driver_report_path')}), flush=True)
                        previous = state
                    if operation['status'] in ('completed', 'failed', 'needs_attention', 'worker_outcome_unknown'):
                        record.update(status=operation['status'], operation=operation,
                            finished_utc=datetime.now(timezone.utc).isoformat())
                        save()
                        break
                    await asyncio.sleep(2)
                    operation = await call('project_controller_operation_status', {
                        'project_id': PROJECT, 'operation_id': operation['operation_id'],
                        'expected_review_sha256': DIGEST, 'include_result': True})
    except BaseException as error:
        record.update(status='client_error_requires_receipt_inspection', error_class=type(error).__name__, error=str(error),
            automatic_retry=False, finished_utc=datetime.now(timezone.utc).isoformat())
        save()
        raise
    finally:
        record['original_source_unchanged'] = hashlib.sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_DIGEST
        save()
        print(json.dumps({'status': record['status'], 'report_path': str(output / 'result.json')}), flush=True)


if __name__ == '__main__':
    asyncio.run(main())
