"""Prepare a single-FB test import from an actual ACI IEC 61131-10 export."""
from pathlib import Path
import argparse
import copy
import json
import xml.etree.ElementTree as ET

NS = 'www.iec.ch/public/TC65SC65BWG7TF10'
MARKER = '(* ACI offline round-trip probe: preserve interface, instances and mappings. *)'
ET.register_namespace('', NS)
ET.register_namespace('xsi', 'http://www.w3.org/2001/XMLSchema-instance')


def prepare(source: Path, output: Path, fb_name: str):
    root = ET.parse(source).getroot()
    selected = root.find(f".//{{{NS}}}FunctionBlock[@name='{fb_name}']")
    if selected is None:
        raise ValueError(f'Export does not contain FunctionBlock {fb_name}')
    selected = copy.deepcopy(selected)
    namespace = root.find(f'{{{NS}}}Types/{{{NS}}}GlobalNamespace')
    namespace.clear()
    namespace.append(selected)
    instances = root.find(f'{{{NS}}}Instances')
    if instances is not None:
        instances.clear()
    code = selected.find(f'{{{NS}}}MainBody/{{{NS}}}BodyContent/{{{NS}}}ST')
    if code is None or not code.text:
        raise ValueError('Expected one non-empty ST main body')
    if MARKER in code.text:
        raise ValueError('Marker already present; refusing repeated modification')
    output.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(output / f'{fb_name}.original.iec.xml', encoding='utf-8', xml_declaration=True)
    code.text = MARKER + '\n' + code.text
    ET.ElementTree(root).write(output / f'{fb_name}.modified.iec.xml', encoding='utf-8', xml_declaration=True)
    record = {'source': str(source.resolve()), 'fb': fb_name, 'kind': 'comment_only',
              'instances_in_import': 0, 'unrelated_types_in_import': 0,
              'metadata_preserved': True, 'marker': MARKER}
    (output / 'prepared-import.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--fb', default='NG_ReadAck')
    args = parser.parse_args()
    prepare(args.source, args.output, args.fb)
