"""Run under a clean 0.4.0 wheel environment; no source imports or device calls."""
import argparse
import asyncio
import importlib.metadata
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import plcnext_mcp
from plcnext_mcp.binary_download_tagged import TaggedBinaryLoopbackController
from plcnext_mcp.download_simulation import execute_download


async def main(output):
    output.mkdir(parents=True, exist_ok=True)
    source_root = Path(__file__).resolve().parents[1]
    package = Path(plcnext_mcp.__file__).resolve().parent
    version = importlib.metadata.version('plcnext-project-mcp')
    assert version == '0.4.0' and not package.is_relative_to(source_root / 'src')
    for item in ['aci_contract/aci_2026_0_4.json', 'rsc_tagged_codec.py', 'controller_readonly.py',
                 'task_configuration.py', 'binary_download_tagged.py', 'compile_host/ColdProjectBuilder.cs',
                 'simulation_tls/root-ca.pem', 'simulation_tls/server-public-test-key.pem']:
        assert (package / item).is_file(), item
    foreign = output / 'foreign-cwd'
    foreign.mkdir(exist_ok=True)
    params = StdioServerParameters(command=sys.executable, args=['-I', '-m', 'plcnext_mcp.server'],
        cwd=str(foreign), env=dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(output / 'workspace')))
    report = {'status': 'running', 'version': version, 'package_path': str(package),
              'source_imports': False, 'controller_connected': False, 'controller_downloaded': False,
              'aci_used': False, 'engineer_started': False}
    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(params, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer) as client:
                    await client.initialize()
                    tools = await client.list_tools()
                    assert len(tools.tools) == 30
                    async def call(name, args):
                        value = await client.call_tool(name, args)
                        assert not value.isError, (name, value.content)
                        return value.structuredContent or json.loads(value.content[0].text)
                    coverage = await call('aci_replacement_status', {})
                    assert coverage['declared_methods'] == 201 and not coverage['full_aci_replacement']
                    page = await call('aci_replacement_methods', {'domain': 'tasks'})
                    assert page['methods']
                    imported = await call('project_import_copy', {'source_path':
                        'D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex'})
                    task = (await call('project_inspect_tasks', {'project_id': imported['project_id']}))['tasks'][0]
                    edited = await call('project_update_cyclic_task', {
                        'project_id': imported['project_id'], 'expected_project_sha256': imported['project_sha256'],
                        'task_id': task['id'], 'updates': {'priority': (task['priority'] + 1) % 100}})
                    checked = await call('project_validate', {'project_id': imported['project_id']})
                    assert checked['preservation_passed'] and len(edited['changed_members']) == 1
                    assert checked['project_sha256'] == edited['project_sha256']
        simulated = execute_download({'Plc/public-wheel-fixture.txt': b'PUBLIC inert wheel fixture'},
                                     TaggedBinaryLoopbackController(token_value=0))
        assert simulated['status'] == 'simulation_passed' and simulated['rpc_close_session_confirmed']
        report.update(status='passed', tools=30, aci_methods=201,
                      packaged_task_edit_and_preservation=True, tagged_memory_tls_passed=True,
                      tagged_rpc_exchanges=simulated['rpc_exchanges_completed'])
    except BaseException as exc:
        report.update(status='failed', error=str(exc))
        raise
    finally:
        (output / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'report': str(output / 'result.json'), **report}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    asyncio.run(main(parser.parse_args().output.resolve()))
