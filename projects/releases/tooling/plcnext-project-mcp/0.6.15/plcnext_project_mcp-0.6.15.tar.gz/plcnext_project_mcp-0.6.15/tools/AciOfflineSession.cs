using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Ade.ApplicationControl;
using Ade.ApplicationControl.Grpc.Client;

public sealed class AciMessageRecord
{
    public string Type { get; set; }
    public string Text { get; set; }
    public string TypeId { get; set; }
    public string Id { get; set; }
}

public sealed class AciCompileRecord
{
    public string Result { get; set; }
    public AciMessageRecord[] Messages { get; set; }
}

// Offline-only adapter. Deliberately contains no PLC online-channel operations.
public sealed class AciOfflineSession : AttachToLocalServerClient
{
    public AciOfflineSession(int port) : base(port) { }

    public void Initialize(int expectedProcessId)
    {
        Init();
        if (!ApplicationControlManager.IsAvailable)
            throw new InvalidOperationException("ACI unavailable: " + ApplicationControlManager.States);
        if (ApplicationControlManager.ApplicationInfo.ProcessId != expectedProcessId)
            throw new InvalidOperationException("ACI backend PID does not match the explicitly selected test process.");
    }

    public string Version => ApplicationControlManager.ApplicationInfo.ProductVersion;
    public string Build => ApplicationControlManager.ApplicationInfo.ProductBuild;
    public bool IsProjectOpen => ApplicationControlManager.Application.IsProjectOpen;
    public string BuildPath => ApplicationControlManager.Application.BuildPath;

    private IProject Project => IsProjectOpen ? ApplicationControlManager.Application.Project
        : throw new InvalidOperationException("No test project is open.");

    public void Open(string path, int timeoutSeconds)
    {
        if (IsProjectOpen) throw new InvalidOperationException("Refusing to replace an already-open project.");
        var operation = ApplicationControlManager.Application.OpenProjectAsync(path);
        if (!operation.Wait(TimeSpan.FromSeconds(timeoutSeconds)))
            throw new TimeoutException("ACI OpenProject completion event timed out.");
        operation.GetAwaiter().GetResult();
    }

    public AciCompileRecord Compile(int timeoutSeconds)
    {
        var messages = new List<IMessage>();
        var operation = Project.CompileAsync(CompileType.Rebuild, messages);
        if (!operation.Wait(TimeSpan.FromSeconds(timeoutSeconds)))
            throw new TimeoutException("ACI CompileFinished event timed out.");
        return new AciCompileRecord {
            Result = operation.GetAwaiter().GetResult().ToString(), Messages = ConvertMessages(messages)
        };
    }

    private static AciMessageRecord[] ConvertMessages(IEnumerable<IMessage> messages) =>
        messages.Select(message => new AciMessageRecord {
            Type = message.MessageType.ToString(), Text = message.Text,
            TypeId = message.TypeId, Id = message.Id.ToString()
        }).ToArray();

    public AciMessageRecord[] Export(string path) => ConvertMessages(Project.ExportIec61131_10(path));
    public AciMessageRecord[] Import(string path) => ConvertMessages(Project.ImportIec61131_10(path));
    public void Save() => Project.Save();
    public void Close() => Project.Close();
    public void Shutdown()
    {
        if (IsProjectOpen) throw new InvalidOperationException("Close the test project before shutdown.");
        ApplicationControlManager.Application.Shutdown();
    }
}
