"""Generate and inspect current NativeGateway PCWE through registered MCP stdio."""
import asyncio
from datetime import timedelta
import json
from pathlib import Path
import shutil
import subprocess
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]
PROJECT = 'a431bdc32f2a4aa1812c94683db38395'
JOB = '54599b7ed9254ac6a61293152ce4ae08'


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


async def main():
    run = uuid.uuid4().hex
    output = ROOT / 'artifacts/pcwe-build-mcp-e2e' / run
    output.mkdir(parents=True)
    registration = json.loads(subprocess.check_output(
        [shutil.which('codex'), 'mcp', 'get', 'plcnext-project', '--json'], text=True, encoding='utf-8'))
    transport = registration['transport']
    assert registration['enabled'] and transport['type'] == 'stdio'
    workspace = Path(transport['env']['PLCNEXT_MCP_WORKSPACE'])
    cwd = workspace / 'client-probes' / run
    cwd.mkdir(parents=True)
    assert not cwd.resolve().is_relative_to(ROOT.resolve())
    params = StdioServerParameters(command=transport['command'], args=transport['args'],
                                   env=transport['env'], cwd=str(cwd))
    summary = {'status': 'running', 'registered_transport_used_unchanged': True,
        'client_directory': str(cwd), 'controller_connected': False, 'controller_downloaded': False,
        'aci_used': False, 'computer_use_used': False, 'checks': {}}
    save(output / 'result.json', summary)

    async def call(client, name, arguments, error=False):
        response = await client.call_tool(name, arguments)
        if error:
            assert response.isError, name + ' should reject'
            return {'rejected': True, 'message': '\n'.join(c.text for c in response.content if hasattr(c, 'text'))}
        assert not response.isError, (name, response.content)
        return response.structuredContent or json.loads(response.content[0].text)

    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(params, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=180)) as client:
                    await client.initialize()
                    names = sorted(t.name for t in (await client.list_tools()).tools)
                    assert 'project_generate_pcwe' in names
                    save(output / 'tools.json', names)
                    summary['tool_count'] = len(names)
                    caps = await call(client, 'server_capabilities', {})
                    assert caps['deployment_preparation']['cold_pcwe_generation'] and not caps['controller_write_access']
                    save(output / 'capabilities.json', caps)
                    before = await call(client, 'project_inspect', {'project_id': PROJECT})
                    args = {'project_id': PROJECT, 'expected_project_sha256': before['project_sha256'], 'build_job_id': JOB}
                    negative = await call(client, 'project_generate_pcwe', args | {'expected_project_sha256': '0' * 64}, True)
                    save(output / 'stale-source-rejected.json', negative)
                    negative = await call(client, 'project_generate_pcwe', args | {'build_job_id': '21ecd6da142147329a4053e1363a6adb'}, True)
                    save(output / 'unbound-old-model-rejected.json', negative)
                    built = await call(client, 'project_generate_pcwe', args)
                    save(output / 'package.json', built)
                    assert built['package_complete'] and built['status'] == 'pcwe_generated_offline'
                    assert built['pou_count'] == 61 and built['global_variable_count'] == 77
                    assert built['fb_instance_count'] == 109 and built['hmi_mapping_count'] == 10
                    assert built['hmi_page_binding_count'] == 81 and built['hmi_page_objects'] == 494
                    assert not built['deployable'] and built['managed_revision_unchanged']
                    inspected = await call(client, 'deployment_inspect_pcwe', {'source_path': built['pcwe_path']})
                    save(output / 'inspection.json', inspected)
                    assert inspected['overall_hash_status'] == 'verified' and inspected['file_hashes_verified']
                    assert inspected['inventory_sha256'] == built['inventory_sha256']
                    assert inspected['file_count'] == 48 and inspected['listed_file_count'] == 47
                    after = await call(client, 'project_inspect', {'project_id': PROJECT})
                    assert after['project_sha256'] == before['project_sha256']
                    summary.update(status='passed', pcwe_path=built['pcwe_path'], package_report=str(output / 'package.json'),
                        file_count=inspected['file_count'], source_sha256=after['project_sha256'], checks={
                        'fresh_61_pou_pcwe_generated': True, 'runtime_and_hmi_bindings_verified': True,
                        'all_47_manifest_files_and_overall_hash_verified': True, 'managed_copy_unchanged': True,
                        'stale_source_rejected': True, 'old_unbound_model_rejected': True})
    except BaseException as exc:
        summary.update(status='failed', error=str(exc))
        raise
    finally:
        save(output / 'result.json', summary)
        print(json.dumps({'report': str(output / 'result.json'), **summary}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())
