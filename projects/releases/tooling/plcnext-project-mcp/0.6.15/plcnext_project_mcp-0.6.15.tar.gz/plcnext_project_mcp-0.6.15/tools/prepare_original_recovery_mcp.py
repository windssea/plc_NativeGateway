"""Freeze a version/impact review using ONLY real-target read-only MCP calls.

Never issues approval, Stop/Start, writes, Reset/Load or recovery execution.
The explicit review remains awaiting the independent human operator terminal.
"""
from __future__ import annotations

import asyncio
from datetime import datetime,timedelta,timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid

from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT=Path(__file__).resolve().parents[1]
ADDRESS='192.168.0.8'
PIN='3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863'


async def main():
    state_path=ROOT/'artifacts/joint-implementation/current.json'
    state=json.loads(state_path.read_text(encoding='utf-8'))
    candidate=state['release_candidate']
    assert hashlib.sha256(Path(candidate['source_path']).read_bytes()).hexdigest()==candidate['project_sha256']
    out=ROOT/'artifacts/original-recovery-review'/uuid.uuid4().hex
    out.mkdir(parents=True)
    result={'schema':'plcnext-original-recovery-preparation/v1','created_utc':datetime.now(timezone.utc).isoformat(),
        'candidate':candidate,'status':'preparing','real_device_read_only':True,
        'actual_operator_approval_issued':False,'stop_start_write_reset_load_sent':False,
        'target':{'address':ADDRESS,'port':41100,'expected_certificate_sha256':PIN},'calls':[]}
    env=os.environ.copy();env.update(PLCNEXT_MCP_WORKSPACE=r'D:\PLCnext-MCP-Workspace',
        PLCNEXT_ENGINEER_DIRECTORY=r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],
        env=env,cwd=tempfile.gettempdir())
    async with stdio_client(params) as (read,write):
        async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=180)) as session:
            await session.initialize()
            async def call(name,arguments):
                response=await session.call_tool(name,arguments)
                value=response.structuredContent
                if value is None:
                    content='\n'.join(x.text for x in response.content if x.type=='text')
                    try:value=json.loads(content)
                    except ValueError:value={'error':content}
                path=out/f'{len(result["calls"]):02d}-{name}.json'
                path.write_text(json.dumps({'tool':name,'arguments':arguments,'is_error':response.isError,
                    'result':value},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                result['calls'].append({'tool':name,'report_path':str(path),'is_error':response.isError})
                print(json.dumps({'tool':name,'status':value.get('status'),'is_error':response.isError}),flush=True)
                if response.isError:raise RuntimeError(name+' rejected: '+str(value.get('error')))
                return value
            project={'project_id':candidate['project_id'],'expected_project_sha256':candidate['project_sha256']}
            package=project|{'package_job_id':candidate['package_job_id']}
            target={'address':ADDRESS,'expected_certificate_sha256':PIN}
            try:
                cap=await call('server_capabilities',{});assert cap['version']=='0.6.0'
                reviewed=await call('project_prepare_download_review',package|target)
                result['download_review']={k:reviewed[k] for k in ('review_id','review_sha256')}
                reference={'project_id':candidate['project_id'],'review_id':reviewed['review_id'],
                    'expected_review_sha256':reviewed['review_sha256']}
                preflight=await call('project_preflight_controller_download',reference|{
                    'verify_package_files':True,'capture_package_files':True,'maximum_package_read_bytes':33554432})
                result['preflight']=preflight
                assert preflight['file_writes_attempted'] is False and preflight['configuration_commands_sent'] is False
                assert not any(row.get('mutating') for row in preflight.get('remote_package_audit',{}).get('trace',[]))
                monitor=await call('project_prepare_runtime_read',project|target|{'include_configuration':True})
                runtime=await call('project_read_runtime',{'project_id':candidate['project_id'],
                    'plan_id':monitor['plan_id'],'expected_plan_sha256':monitor['plan_sha256']})
                result['runtime_observation']=runtime
                # ESM uses the same endpoint-wide read-rate budget as ordinary
                # variables. Respect that bound rather than retrying on rejection.
                await asyncio.sleep(5.2)
                esm_plan=await call('project_prepare_esm_read',project|target|{'esm_indices':[1],'task_indices':[1]})
                result['esm_observation']=await call('project_read_esm',{'project_id':candidate['project_id'],
                    'plan_id':esm_plan['plan_id'],'expected_plan_sha256':esm_plan['plan_sha256']})
                raw=preflight.get('plc_state_raw')
                if raw not in (2,3):raise RuntimeError('Exact current state is neither Stop nor Running; no executable recovery review prepared.')
                plan=await call('project_prepare_recovery',package|target|{
                    'volatile_data_policy':'record_unknown_loss','start_kind':'cold','expected_initial_state':raw,
                    'expected_configuration':{'version':13,'device_count':50,'point_count':250,'enabled':True}})
                result['recovery_plan']=plan
                result['operator_approval_status']=await call('project_inspect_operator_approval',{
                    'project_id':candidate['project_id'],'review_id':plan['plan_id'],
                    'expected_review_sha256':plan['plan_sha256'],'kind':'recovery'})
                assert result['operator_approval_status']['status']=='unconfirmed'
                result['status']='awaiting_exact_operator_confirmation'
            except Exception as exc:
                result.update(status='preparation_incomplete',error_class=type(exc).__name__,error=str(exc))
            finally:
                result['source_unchanged']=hashlib.sha256(Path(candidate['source_path']).read_bytes()).hexdigest()==candidate['project_sha256']
                result['report_path']=str(out/'result.json')
                (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                state['final_readonly_preparation']=str(out/'result.json')
                state_path.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                print(json.dumps({k:result.get(k) for k in ('status','source_unchanged','report_path','error')},ensure_ascii=False),flush=True)
    return 0 if result['status']=='awaiting_exact_operator_confirmation' else 1


if __name__=='__main__':raise SystemExit(asyncio.run(main()))
