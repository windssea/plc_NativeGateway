"""Reproducible M01..M10 MCP integration: copies, cold build and owned loopback only.

No real controller address is accepted. The sole non-loopback target is RFC5737
192.0.2.8 for a local prepare/unapproved-execution rejection; it must never connect.
No actual operator approval is issued. Fixture approval is private to owned peers.
"""
from __future__ import annotations

import argparse
import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT=Path(__file__).resolve().parents[1]


async def run(args):
    output=ROOT/'artifacts'/'joint-mcp-e2e'/uuid.uuid4().hex
    output.mkdir(parents=True)
    source=Path(args.source).resolve(strict=True)
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    report={'schema':'plcnext-joint-mcp-e2e/v1','started_utc':datetime.now(timezone.utc).isoformat(),
        'source_path':str(source),'source_sha256':before,'status':'running',
        'real_plc_contacted':False,'actual_operator_approval_issued':False,'calls':[]}
    env=os.environ.copy()
    env.update(PLCNEXT_MCP_WORKSPACE=str(Path(args.workspace).resolve()),
        PLCNEXT_ENGINEER_DIRECTORY=args.engineer_directory)
    parameters=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],
        env=env,cwd=tempfile.gettempdir())
    async with stdio_client(parameters) as (read,write):
        async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=300)) as session:
            await session.initialize()
            tools=await session.list_tools();names={t.name for t in tools.tools}
            report['tool_count']=len(names)
            (output/'tool-schema.json').write_text(json.dumps([t.model_dump(mode='json',exclude_none=True)
                for t in tools.tools],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            async def call(name,arguments):
                index=len(report['calls'])
                response=await session.call_tool(name,arguments)
                record={'tool':name,'arguments':arguments,'is_error':response.isError}
                if response.structuredContent is not None:data=response.structuredContent
                else:
                    text='\n'.join(c.text for c in response.content if c.type=='text')
                    try:data=json.loads(text)
                    except ValueError:data={'error':text}
                record['result']=data
                path=output/f'{index:02d}-{name}.json'
                path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                report['calls'].append({'tool':name,'report_path':str(path),'is_error':response.isError})
                print(json.dumps({'call':name,'status':data.get('status'),
                    'test_passed':data.get('test_passed'),'error':response.isError}),flush=True)
                if response.isError:raise RuntimeError(f'{name} failed: {data.get("error","see receipt")}')
                return data
            try:
                capabilities=await call('server_capabilities',{})
                assert capabilities['version']=='0.6.0'
                imported=await call('project_import_copy',{'source_path':str(source)})
                project={'project_id':imported['project_id'],'expected_project_sha256':imported['project_sha256']}
                assert imported['project_sha256']==before
                report.update(project_id=imported['project_id'],project_sha256=before)
                await call('project_inspect',{'project_id':project['project_id']})
                await call('project_inspect_tasks',{'project_id':project['project_id']})
                await call('project_inspect_runtime_symbols',project)
                await call('project_build_plan',{'project_id':project['project_id']})
                compiled=await call('project_compile',project)
                assert compiled['compiled'] and not compiled['ast_seed_used']
                report['build_job_id']=compiled['job_id']
                package=await call('project_generate_pcwe',project|{'build_job_id':compiled['job_id'],
                    'download_memento_policy':'empty_capability_v1'})
                assert package['package_complete'] and package['download_memento']['history_entries']==0
                package_args=project|{'package_job_id':package['package_job_id']}
                report.update(package_job_id=package['package_job_id'],inventory_sha256=package['inventory_sha256'],
                    pcwe_path=package['pcwe_path'],file_count=package['file_count'])
                await call('deployment_inspect_pcwe',{'source_path':package['pcwe_path']})
                runtime=await call('project_test_runtime_read',project)
                assert runtime['test_passed']
                for action in ('stop','start'):
                    result=await call('project_test_controller_control',package_args|{'action':action})
                    assert result.get('terminal_state_verified') or result.get('test_passed'),result
                recovery=await call('project_test_recovery',package_args)
                assert recovery.get('test_passed'),recovery
                supervisor=await call('project_test_fault_supervision',package_args|{'fault':'client_exit'})
                assert supervisor['client_exit_injection_executed'] and supervisor['final']['release_verified']
                # No human confirmation exists for this unrouteable test review.
                target={'address':'192.0.2.8','expected_certificate_sha256':'0'*64}
                plan=await call('project_prepare_recovery',package_args|target)
                plan_args={'project_id':project['project_id'],'plan_id':plan['plan_id'],
                    'expected_plan_sha256':plan['plan_sha256']}
                await call('project_inspect_recovery',plan_args)
                await call('project_inspect_operator_approval',{'project_id':project['project_id'],
                    'review_id':plan['plan_id'],'expected_review_sha256':plan['plan_sha256'],'kind':'recovery'})
                rejected=await call('project_execute_recovery',plan_args)
                assert rejected['failure_code']=='user_confirmation_required'
                assert not rejected['controller_changed']
                # New, independent empty-template engineering only.
                created=await call('project_create',{'name':'JointMcpOffline-'+output.name[:8]})
                test_project={'project_id':created['project_id'],'expected_project_sha256':created['project_sha256']}
                cloned=await call('project_clone_program',test_project|{'source_pou_name':'Main',
                    'new_pou_name':'IndependentProbe','variables':'VAR\n Counter : UDINT;\nEND_VAR\n',
                    'code':'Counter := Counter + 1;\n'})
                test_project['expected_project_sha256']=cloned['project_sha256']
                tasks=await call('project_change_cyclic_tasks',test_project|{'add_tasks':[{
                    'name':'IndependentTask','program_type':'IndependentProbe','instance_name':'IndependentInstance',
                    'interval_ns':100000000,'watchdog_ns':1000000000,'priority':30}]})
                test_project['expected_project_sha256']=tasks['project_sha256']
                built=await call('project_compile',test_project)
                assert built['compiled'] and not built['ast_seed_used']
                report['independent_multitask_project_id']=test_project['project_id']
                report['status']='passed'
            except Exception as exc:
                report.update(status='failed',error_class=type(exc).__name__,error=str(exc))
            finally:
                report['source_sha256_after']=hashlib.sha256(source.read_bytes()).hexdigest()
                report['source_unchanged']=report['source_sha256_after']==before
                report['completed_utc']=datetime.now(timezone.utc).isoformat()
                report['report_path']=str(output/'result.json')
                (output/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                print(json.dumps({k:report.get(k) for k in ('status','tool_count','project_id','package_job_id',
                    'inventory_sha256','source_unchanged','report_path','error')},ensure_ascii=False),flush=True)
    return 0 if report['status']=='passed' else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',default=r'D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex')
    parser.add_argument('--workspace',default=r'D:\PLCnext-MCP-Workspace')
    parser.add_argument('--engineer-directory',default=r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')
    raise SystemExit(asyncio.run(run(parser.parse_args())))
