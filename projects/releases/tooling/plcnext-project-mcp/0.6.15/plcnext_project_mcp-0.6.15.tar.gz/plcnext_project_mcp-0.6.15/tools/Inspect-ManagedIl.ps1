param(
    [Parameter(Mandatory=$true)][string]$AssemblyPath,
    [string]$TypePattern = '.*',
    [string]$MethodPattern = '.*',
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [string]$EngineerDirectory = 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
)
$ErrorActionPreference = 'Stop'
# Only Mono.Cecil is loaded. The inspected vendor assembly is parsed as data.
[void][Reflection.Assembly]::LoadFrom((Join-Path $EngineerDirectory 'Mono.Cecil.dll'))
$module = [Mono.Cecil.ModuleDefinition]::ReadModule($AssemblyPath)
function Enumerate-Types($items) {
    foreach ($item in $items) { $item; Enumerate-Types $item.NestedTypes }
}
try {
    $types = @(Enumerate-Types $module.Types | Where-Object { $_.FullName -match $TypePattern })
    $methods = @($types | ForEach-Object {
        $type = $_
        $_.Methods | Where-Object { $_.Name -match $MethodPattern } | ForEach-Object {
            $method = $_
            [ordered]@{
                token = ('0x{0:x8}' -f $method.MetadataToken.ToUInt32())
                type = $type.FullName
                signature = $method.FullName
                instructions = @($(if ($method.HasBody) { $method.Body.Instructions }) | ForEach-Object {
                    [ordered]@{ offset = $_.Offset; opcode = $_.OpCode.Name; operand = [string]$_.Operand }
                })
            }
        }
    })
    [ordered]@{
        path = (Resolve-Path -LiteralPath $AssemblyPath).Path
        sha256 = (Get-FileHash -LiteralPath $AssemblyPath -Algorithm SHA256).Hash.ToLowerInvariant()
        mvid = $module.Mvid.ToString()
        inspected_target_executed = $false
        type_filter = $TypePattern
        method_filter = $MethodPattern
        methods = $methods
    } | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $OutputPath -Encoding utf8
    Write-Output ('Saved {0} methods to {1}' -f $methods.Count, $OutputPath)
} finally { $module.Dispose() }
