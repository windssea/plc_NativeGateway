param(
    [Parameter(Mandatory)][ValidateSet('Inspect','Open','Compile','Export','Import','Save','Close','Shutdown')][string]$Action,
    [Parameter(Mandatory)][int]$ExpectedProcessId,
    [string]$FilePath,
    [string]$OutputPath,
    [int]$TimeoutSeconds = 180,
    [int]$Port = 31172,
    [string]$InstallDirectory = 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
)
$ErrorActionPreference = 'Stop'
$aciWorkRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\artifacts\aci-poc'))
if (-not $OutputPath) { $OutputPath = Join-Path $aciWorkRoot ("aci-" + $Action.ToLowerInvariant() + '.json') }
$aciOutput = [IO.Path]::GetFullPath($OutputPath)
foreach ($aciPath in @($aciOutput, $FilePath)) {
    if ($aciPath -and -not [IO.Path]::GetFullPath($aciPath).StartsWith($aciWorkRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'All test input/output paths must stay inside artifacts\aci-poc.'
    }
}
if ($Action -in @('Open','Export','Import') -and -not $FilePath) { throw 'FilePath is required for this action.' }
if ($Action -eq 'Open' -and ([IO.Path]::GetExtension($FilePath) -ne '.pcwex')) { throw 'Only a PCWEX test copy may be opened.' }
if ($Action -eq 'Export' -and (Test-Path -LiteralPath $FilePath)) { throw 'Refusing to overwrite an existing export.' }

# AssemblyResolve may execute on gRPC/event threads. Use a C# handler, never a
# PowerShell callback that depends on the main PowerShell runspace.
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Reflection;
public static class AciOfflineAssemblyResolver {
    public static string DirectoryPath;
    public static Assembly Resolve(object sender, ResolveEventArgs args) {
        var path = Path.Combine(DirectoryPath, new AssemblyName(args.Name).Name + ".dll");
        return File.Exists(path) ? Assembly.LoadFrom(path) : null;
    }
}
'@
[AciOfflineAssemblyResolver]::DirectoryPath = $InstallDirectory
$aciResolver = [ResolveEventHandler][AciOfflineAssemblyResolver]::Resolve
[AppDomain]::CurrentDomain.add_AssemblyResolve($aciResolver)
$aciClient = $null
$aciResult = [ordered]@{
    timestamp = [DateTimeOffset]::Now.ToString('o')
    action = $Action
    expected_backend_pid = $ExpectedProcessId
    status = 'started'
    plc_operations = @()
}
try {
    $aciContract = Join-Path $InstallDirectory 'Ade.ApplicationControl.dll'
    $aciClientAssembly = Join-Path $InstallDirectory 'Ade.ApplicationControl.ClientImpl.dll'
    [void][Reflection.Assembly]::LoadFrom($aciContract)
    [void][Reflection.Assembly]::LoadFrom($aciClientAssembly)
    $aciReferences = @($aciContract, $aciClientAssembly, 'System.Linq.dll', 'System.Collections.dll', 'System.Threading.Tasks.dll')
    Add-Type -Path (Join-Path $PSScriptRoot 'AciOfflineSession.cs') -ReferencedAssemblies $aciReferences -CompilerOptions '/nowarn:1701'
    $aciClient = [AciOfflineSession]::new($Port)
    $aciClient.Initialize($ExpectedProcessId)
    $aciResult.engineer_version = $aciClient.Version
    $aciResult.engineer_build = $aciClient.Build
    switch ($Action) {
        'Inspect' { $aciResult.project_open = $aciClient.IsProjectOpen; $aciResult.build_path = $aciClient.BuildPath }
        'Open' { $aciClient.Open([IO.Path]::GetFullPath($FilePath), $TimeoutSeconds); $aciResult.project_open = $aciClient.IsProjectOpen }
        'Compile' { $aciResult.compile = $aciClient.Compile($TimeoutSeconds) }
        'Export' { $aciResult.messages = @($aciClient.Export([IO.Path]::GetFullPath($FilePath))); $aciResult.export_exists = Test-Path -LiteralPath $FilePath }
        'Import' { $aciResult.messages = @($aciClient.Import([IO.Path]::GetFullPath($FilePath))) }
        'Save' { $aciClient.Save() }
        'Close' { $aciClient.Close() }
        'Shutdown' { $aciClient.Shutdown() }
    }
    $aciResult.status = 'completed'
}
catch {
    $aciResult.status = 'failed'
    $aciResult.errors = @()
    $aciFailure = $_.Exception
    while ($null -ne $aciFailure) {
        $aciResult.errors += @{ type = $aciFailure.GetType().FullName; message = $aciFailure.Message }
        $aciFailure = $aciFailure.InnerException
    }
}
finally {
    if ($null -ne $aciClient) { $aciClient.Dispose() }
    [AppDomain]::CurrentDomain.remove_AssemblyResolve($aciResolver)
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($aciOutput))
    $aciResult | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $aciOutput -Encoding utf8
    $aciResult | ConvertTo-Json -Depth 12
}
if ($aciResult.status -eq 'failed') { exit 1 }
if ($Action -eq 'Compile' -and $aciResult.compile.Result -ne 'Succeeded') { exit 2 }
