using System;
using Ade.ApplicationControl;
using Ade.ApplicationControl.Grpc.Client;

// Use the installed vendor client and its normal authentication handshake.
// This probe exposes no PLC connection, download, start, or variable-write action.
public sealed class AciOfflineProbe : AttachToLocalServerClient
{
    public AciOfflineProbe(int port) : base(port) { }

    public string ReadStatus()
    {
        Init();
        var manager = ApplicationControlManager;
        return "Available=" + manager.IsAvailable + "; States=" + manager.States;
    }
}
