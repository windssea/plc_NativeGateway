"""One explicit original-package hardware test through the public MCP tools.

Uses MCP-managed authorization. Reconciles only the known Stop-only failure
39f9e... using its journal and a fresh pinned state read. Never retries a
transfer, reuses a claim, changes a source, or removes an unknown lease.
"""
from __future__ import annotations
import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]
PROJECT = '17ae4361baa846868b14775bf1de15ea'
SOURCE_SHA = '7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154'
PACKAGE = 'f7fc619d55ba42c091f4ca0efed23e73'
PIN = '3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863'
PRIOR_PLAN_SHA = '0b977fedac3979549b95f9686de48809a8eb82398a29471c62368ec6e19dc3bc'
PRIOR_OPERATION = 'b09cbe4960ea4316901a05daf8a817bb'
PRIOR_JOB = Path(r'D:\PLCnext-MCP-Workspace\17ae4361baa846868b14775bf1de15ea\controller-recoveries\39f9e069c1154855a35f5ebac88fbacf')


async def main():
    source = Path(r'D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_SHA
    folder = ROOT / 'artifacts/original-recovery-hardware' / uuid.uuid4().hex
    folder.mkdir(parents=True)
    report = {'schema':'plcnext-original-recovery-hardware-test/v2',
        'created_utc':datetime.now(timezone.utc).isoformat(), 'project_id':PROJECT,
        'status':'preparing', 'authorization_channel':'mcp_managed', 'calls':[]}
    def save():
        (folder/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    save()
    print(json.dumps({'report_path':str(folder/'result.json')}),flush=True)
    environment = os.environ.copy()
    environment.update(PLCNEXT_MCP_WORKSPACE=r'D:\PLCnext-MCP-Workspace',
        PLCNEXT_ENGINEER_DIRECTORY=r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],
        env=environment,cwd=tempfile.gettempdir())
    try:
        async with stdio_client(params) as (read,write):
            async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=360)) as session:
                await session.initialize()
                async def call(name,args):
                    response=await session.call_tool(name,args)
                    value=response.structuredContent
                    if value is None:value=json.loads('\n'.join(x.text for x in response.content if x.type=='text'))
                    path=folder/f'{len(report["calls"]):03d}-{name}.json'
                    path.write_text(json.dumps({'tool':name,'arguments':args,'is_error':response.isError,
                        'result':value},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                    report['calls'].append({'tool':name,'is_error':response.isError,'report_path':str(path)})
                    save()
                    if response.isError:raise RuntimeError(name+' refused: '+str(value))
                    return value
                capabilities=await call('server_capabilities',{})
                assert capabilities['version']=='0.6.1'
                state=await call('controller_read_state',{'address':'192.168.0.8',
                    'expected_certificate_sha256':PIN,'timeout_seconds':5})
                raw=state.get('plc_state_raw')
                if raw not in (2,0x20002):raise RuntimeError('Fresh state is not stable Stop; no new hardware action.')
                prior=await call('project_controller_operation_status',{'project_id':PROJECT,
                    'operation_id':PRIOR_OPERATION,'expected_review_sha256':PRIOR_PLAN_SHA,'include_result':True})
                assert prior['status']=='needs_attention' and prior['phase']=='finished'
                old=json.loads((PRIOR_JOB/'result.json').read_text('utf-8'))
                events=[json.loads(line) for line in (PRIOR_JOB/'journal.jsonl').read_text('utf-8').splitlines()]
                sent=[e for e in events if e.get('mutating') and e.get('send_attempted')]
                assert old['stage']=='stopping' and not old['original_package_loaded']
                assert len(sent)==1 and sent[0]['service']=='Arp.Plc.Domain.Services.IPlcManagerService'
                assert sent[0]['method']==3 and sent[0]['response_received'] is True
                assert old['steps'][0]['last_state_raw']==0x20002
                lease=Path(old['endpoint_lease_path'])
                lease_bytes=lease.read_bytes()
                owner=json.loads(lease_bytes)
                assert owner['job_directory']==str(PRIOR_JOB)
                assert owner['review_sha256']==old['steps'][0]['review_sha256']
                assert owner['target']==old['target'] and owner['target']['expected_certificate_sha256']==PIN
                resolution={'schema':'plcnext-stop-only-reconciliation/v1',
                    'observed_utc':datetime.now(timezone.utc).isoformat(),
                    'prior_execution_id':old['execution_id'],'prior_review_sha256':PRIOR_PLAN_SHA,
                    'fresh_read':state,'stop_completed_verified':True,
                    'file_write_reset_load_start_requests_sent':False,
                    'reason':'Original enum Hot=0x20000 metadata was misclassified as an error; base state Stop=2 is independently read.',
                    'prior_receipts_claims_and_journal_retained':True,
                    'lease_sha256':hashlib.sha256(lease_bytes).hexdigest(),
                    'mcp_autonomous_authorization_user_instruction':'移除这个限制，mcp可以自行决定'}
                resolution_path=folder/'stop-only-reconciliation.json'
                resolution_path.write_text(json.dumps(resolution,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                if lease.read_bytes()!=lease_bytes:raise RuntimeError('Lease owner changed; no reconciliation.')
                archived=lease.with_name(lease.stem+'.reconciled-'+uuid.uuid4().hex+'.json')
                lease.rename(archived)
                report['prior_stop_reconciliation']={'report_path':str(resolution_path),'archived_lease_path':str(archived)}
                save()
                print(json.dumps({'status':'prior_stop_verified_no_file_mutation','plc_state_raw':raw}),flush=True)
                plan=await call('project_prepare_recovery',{'project_id':PROJECT,'expected_project_sha256':SOURCE_SHA,
                    'package_job_id':PACKAGE,'address':'192.168.0.8','expected_certificate_sha256':PIN,
                    'expected_initial_state':raw,'volatile_data_policy':'record_unknown_loss','start_kind':'cold',
                    'expected_configuration':{'version':13,'device_count':50,'point_count':250,'enabled':True}})
                report['plan']={k:plan[k] for k in ('plan_id','plan_sha256')}
                approval=await call('project_authorize_controller_operation',{'project_id':PROJECT,
                    'review_id':plan['plan_id'],'expected_review_sha256':plan['plan_sha256'],'kind':'recovery',
                    'reason':'User requested hardware download test of the exact original package and explicitly removed independent human-signature requirement; prior Stop-only failure reconciled by pinned read and journal.',
                    'lifetime_seconds':900})
                assert approval['status']=='ready' and approval['confirmed_by']=='mcp_policy'
                report['authorization']=approval
                operation=await call('project_start_recovery_job',{'project_id':PROJECT,
                    'plan_id':plan['plan_id'],'expected_plan_sha256':plan['plan_sha256']})
                report['operation_id']=operation['operation_id'];save()
                previous=None
                while True:
                    summary={k:operation.get(k) for k in ('operation_id','status','phase','execution_result_status',
                        'outcome_unknown','controller_changed','driver_report_path')}
                    if summary!=previous:print(json.dumps(summary),flush=True);previous=summary
                    if operation['status'] in ('completed','failed','needs_attention','worker_outcome_unknown'):
                        report.update(status=operation['status'],operation=operation);save();break
                    await asyncio.sleep(2)
                    operation=await call('project_controller_operation_status',{'project_id':PROJECT,
                        'operation_id':operation['operation_id'],'expected_review_sha256':plan['plan_sha256'],
                        'include_result':True})
    except BaseException as exc:
        report.update(status='client_error_requires_inspection',error_class=type(exc).__name__,error=str(exc),automatic_retry=False)
        save()
        raise
    finally:
        report.update(finished_utc=datetime.now(timezone.utc).isoformat(),
            original_source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==SOURCE_SHA)
        save()
        print(json.dumps({'status':report['status'],'report_path':str(folder/'result.json')}),flush=True)


if __name__=='__main__':asyncio.run(main())
