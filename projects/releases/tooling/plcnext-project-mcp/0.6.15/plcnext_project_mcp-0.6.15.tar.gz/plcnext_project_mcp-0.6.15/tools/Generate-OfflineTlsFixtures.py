"""Generate PUBLIC TEST-ONLY TLS fixtures; never use these keys on a device.

cryptography is only required when regenerating fixtures. Runtime probes use ssl.
"""
from datetime import datetime, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

ROOT = Path(__file__).resolve().parents[1] / 'src/plcnext_mcp/simulation_tls'
START = datetime(2020, 1, 1, tzinfo=timezone.utc)
END = datetime(2100, 1, 1, tzinfo=timezone.utc)


def name(common_name):
    return x509.Name([x509.NameAttribute(NameOID.ORGANIZATION_NAME, 'PUBLIC OFFLINE TEST FIXTURE'),
                      x509.NameAttribute(NameOID.COMMON_NAME, common_name)])


def authority(common_name):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = name(common_name)
    cert = x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key()) \
        .serial_number(x509.random_serial_number()).not_valid_before(START).not_valid_after(END) \
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True) \
        .add_extension(x509.KeyUsage(False, False, False, False, False, True, True, False, False), critical=True) \
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False) \
        .sign(key, hashes.SHA256())
    return key, cert


def server_certificate(host, key, ca_key, ca_cert):
    return x509.CertificateBuilder().subject_name(name(host)).issuer_name(ca_cert.subject) \
        .public_key(key.public_key()).serial_number(x509.random_serial_number()) \
        .not_valid_before(START).not_valid_after(END) \
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True) \
        .add_extension(x509.SubjectAlternativeName([x509.DNSName(host)]), critical=False) \
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False) \
        .add_extension(x509.KeyUsage(True, False, True, False, False, False, False, False, False), critical=True) \
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False) \
        .sign(ca_key, hashes.SHA256())


def main():
    ROOT.mkdir(exist_ok=True)
    outputs = ('root-ca.pem', 'untrusted-ca.pem', 'server.pem', 'wrong-host-server.pem', 'server-public-test-key.pem')
    if any((ROOT / p).exists() for p in outputs):
        raise RuntimeError('Refusing to overwrite existing TLS test fixtures.')
    ca_key, ca_cert = authority('PLCnext MCP OFFLINE TEST Root')
    _, unrelated = authority('UNRELATED OFFLINE TEST Root')
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    cert = server_certificate('offline-plc.invalid', key, ca_key, ca_cert)
    wrong = server_certificate('wrong-host.offline.invalid', key, ca_key, ca_cert)
    for filename, value in [('root-ca.pem', ca_cert), ('untrusted-ca.pem', unrelated),
                            ('server.pem', cert), ('wrong-host-server.pem', wrong)]:
        (ROOT / filename).write_bytes(value.public_bytes(serialization.Encoding.PEM))
    (ROOT / 'server-public-test-key.pem').write_bytes(key.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))


if __name__ == '__main__':
    main()
