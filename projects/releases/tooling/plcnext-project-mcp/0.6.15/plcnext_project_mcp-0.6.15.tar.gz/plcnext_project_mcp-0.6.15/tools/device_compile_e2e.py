"""Fresh stdio MCP acceptance for ONE isolated device chain. No controller tools."""
import argparse,asyncio,json,os,pathlib,sys,hashlib
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def run(args):
    args.output.mkdir(parents=True,exist_ok=True)
    env={**os.environ,'PLCNEXT_MCP_WORKSPACE':str(args.workspace),
         'PLCNEXT_MCP_RELEASE_ROOT':str(args.releases),
         'PLCNEXT_LIBRARIES_DIRECTORY':str(args.libraries)}
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env)
    async with stdio_client(params) as (reader,writer):
      async with ClientSession(reader,writer) as session:
        await session.initialize()
        async def call(name,**values):
            reply=await session.call_tool(name,values)
            data=json.loads(next(x.text for x in reply.content if x.type=='text')) if not reply.isError else {'error':str(reply.content)}
            (args.output/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            if reply.isError:raise RuntimeError(name+': '+str(reply.content)[:1500])
            print(name,data.get('status',data.get('version','recorded')),flush=True)
            return data
        await call('server_capabilities')
        await call('project_device_profiles')
        if args.inspect_image:
            await call('deployment_inspect_native_image',image_path=str(args.inspect_image),expected_sha256=hashlib.sha256(args.inspect_image.read_bytes()).hexdigest())
            return
        if args.resume:
            dev=json.loads((args.resume/'project_release_prepare_dev.json').read_text(encoding='utf-8'))
            build=json.loads((args.resume/'project_compile.json').read_text(encoding='utf-8'))
        else:
            project=await call('project_import_copy',source_path=str(args.source))
            dev=await call('project_release_prepare_dev',project_id=project['project_id'],
                expected_project_sha256=project['project_sha256'],base_version='0.8.2',build_number=args.build_number,
                change_note='Independent device toolchain acceptance; version-stamped offline build, no controller access.')
            managed=dev['managed_project']
            await call('project_build_plan',project_id=managed['project_id'])
            build=await call('project_compile',project_id=managed['project_id'],expected_project_sha256=managed['project_sha256'])
            assert build['compiled'],build.get('status')
        managed=dev['managed_project']
        if not args.compile_only:
            package=await call('project_generate_pcwe',project_id=managed['project_id'],expected_project_sha256=managed['project_sha256'],
                build_job_id=build['job_id'],download_memento_policy='empty_capability_v1')
            assert package['package_complete']
            await call('project_release_bind_package',project_id=managed['project_id'],expected_project_sha256=managed['project_sha256'],package_job_id=package['package_job_id'])

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('workspace','releases','libraries','source','output'):p.add_argument('--'+name,type=pathlib.Path,required=True)
    p.add_argument('--build-number',type=int,default=1);p.add_argument('--compile-only',action='store_true');p.add_argument('--resume',type=pathlib.Path)
    p.add_argument('--inspect-image',type=pathlib.Path)
    asyncio.run(run(p.parse_args()))
