"""Check every supported ST worksheet in the frozen NativeGateway copy through MCP."""
import asyncio
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    root = Path(__file__).resolve().parents[1]
    output = root / 'artifacts/headless-project-syntax'
    output.mkdir(parents=True, exist_ok=True)
    params = StdioServerParameters(command=sys.executable, args=['-m', 'plcnext_mcp.server'],
                                   env=dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(output / 'workspace')))
    async with stdio_client(params) as (reader, writer):
        async with ClientSession(reader, writer) as client:
            await client.initialize()

            async def call(name, arguments):
                response = await client.call_tool(name, arguments)
                if response.isError:
                    raise RuntimeError(str(response.content))
                return response.structuredContent or json.loads(response.content[0].text)

            imported = await call('project_import_copy', {'source_path': str(root / 'artifacts/aci-poc/NativeGateway.frozen.pcwex')})
            pid = imported['project_id']
            inspected = await call('project_inspect', {'project_id': pid})
            reports = []
            for pou in inspected['pous']:
                report = await call('project_check_st', {'project_id': pid, 'pou_name': pou['name']})
                reports.append(report)
                print(json.dumps({'pou': pou['name'], 'syntax_errors': report['errors']}), flush=True)
            result = {'status': 'passed' if all(r['syntax_passed'] for r in reports) else 'syntax_errors',
                      'project': imported, 'checked_st_worksheets': len(reports), 'reports': reports,
                      'whole_project_compiled': False, 'aci_used': False, 'computer_use_used': False,
                      'plc_connected': False, 'plc_downloaded': False}
            (output / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            assert result['status'] == 'passed'


if __name__ == '__main__':
    asyncio.run(main())
