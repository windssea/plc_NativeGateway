"""Derive bounded RPC->server coverage from saved, execution-free ACI evidence."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'artifacts/aci-analysis'


def read(name):
    return json.loads((BASE / name).read_text(encoding='utf-8-sig'))


def main():
    api = read('public-client-api-map.json')
    wire = read('public-client-protobuf-descriptors.json')
    server = read('server-project-il.json')
    handlers = [method for method in server['methods']
                if 'Grpc.Core.ServerCallContext' in method['signature']]
    records = []
    for rpc in wire['rpcs']:
        service = rpc['service'].rsplit('.', 1)[-1]
        # Singular wire service / plural implementation alias is established by
        # its generated DeviceSettingServiceBase constructor call below.
        implementation = {'DeviceSettingService': 'DeviceSettingsService'}.get(service, service)
        candidates = [method for method in handlers
                      if method['type'].rsplit('.', 1)[-1] == implementation
                      and f"::{rpc['name']}(" in method['signature']]
        record = dict(rpc)
        record['resolution'] = 'one_static_handler' if len(candidates) == 1 else 'unresolved'
        record['server_handlers'] = [{
            'token': method['token'], 'type': method['type'], 'signature': method['signature'],
            'direct_call_anchors': [instruction for instruction in method['instructions']
                                    if instruction['opcode'] in ('call', 'callvirt', 'newobj', 'ldftn')],
        } for method in candidates]
        records.append(record)
    aliases = [method for method in server['methods']
               if method['type'].endswith('.DeviceSettingsService') and '::.ctor(' in method['signature']]
    assert any('DeviceSettingServiceBase::.ctor' in instruction['operand']
               for method in aliases for instruction in method['instructions'])
    bound = [record['server_handlers'][0]['token'] for record in records
             if record['resolution'] == 'one_static_handler']
    assert len(bound) == len(set(bound)) == len(handlers) == 193
    identity = dict(api['identity'])
    identity['Ade.ApplicationControl.ServerImpl'] = {
        'sha256': server['sha256'], 'mvid': server['mvid']}
    result = {
        'schema': 'aci-implementation-coverage/v1', 'target_executed': False,
        'evidence_type': 'derived_from_saved_metadata_cil_and_embedded_descriptors',
        'identity': identity, 'public_api_counts': api['counts'],
        'server_methods_inventoried': len(server['methods']),
        'rpc_handler_count': len(handlers), 'rpc_handlers_uniquely_bound': len(bound),
        'rpc_counts_by_service': dict(sorted(Counter(record['service'] for record in records).items())),
        'device_setting_alias_constructor_anchors': aliases,
        'rpcs': records,
        'limitations': [
            'Binding a handler is not execution coverage or proof of feature success.',
            'Direct call anchors do not resolve virtual dispatch or prove all downstream behavior.',
            'Generated protobuf serializer methods are inventoried, not individually semantically audited.',
            'Engineer services beyond the four ACI assemblies are traced only at selected feature boundaries.',
            'Canonical REA member signature coverage is partial/unavailable in places; see report.',
        ],
        'inputs': {name: hashlib.sha256((BASE / name).read_bytes()).hexdigest() for name in (
            'public-client-api-map.json', 'public-client-protobuf-descriptors.json', 'server-project-il.json')},
    }
    (BASE / 'implementation-coverage.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    rows = ['# ACI 全部 RPC 的服务端绑定', '',
            '静态 descriptor → ServerImpl handler 覆盖 **193/193**。每行对应唯一方法；'
            '仅证明实现入口存在，不代表其功能有效或已实测。完整签名和直接调用锚点保留在 '
            '[JSON](../../artifacts/aci-analysis/implementation-coverage.json)。', '',
            '| gRPC 路径 | ServerImpl 类型 | Token |', '| --- | --- | --- |']
    for record in records:
        method = record['server_handlers'][0]
        rows.append(f"| `{record['path']}` | `{method['type']}` | `{method['token']}` |")
    (ROOT / 'docs/aci-analysis/server-rpc-coverage.md').write_text('\n'.join(rows) + '\n', encoding='utf-8')
    print(json.dumps({'rpcs': len(records), 'handlers_bound': len(bound),
                      'server_methods': len(server['methods']), 'target_executed': False}))


if __name__ == '__main__':
    main()
