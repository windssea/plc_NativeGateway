"""Freeze the one measured NativeGateway compilation seed; never overwrite it."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from plcnext_mcp.cached_compile import (  # noqa: E402
    BACKEND, DEFAULT_SEED, GUI_PROJECT_SHA256, LIMITATIONS, LOADER, RESOURCE_NAME,
    SEED_AST_SHA256, SOURCE_PROJECT_SHA256, TARGET_MEMBER, TARGET_POU, _application_file,
)
from plcnext_mcp.headless import DEFAULT_INSTALL  # noqa: E402
from plcnext_mcp.project import ProjectError, read_archive, sha  # noqa: E402


def prepare(destination: Path, source: Path, gui_project: Path, cache: Path, install: Path) -> dict:
    destination, install = destination.resolve(), install.resolve()
    if destination.exists():
        raise ProjectError('Seed destination already exists; use a new directory, never overwrite a seed.')
    original_raw, original, _, _ = read_archive(source)
    gui_raw, gui, _, _ = read_archive(gui_project)
    if sha(original_raw) != SOURCE_PROJECT_SHA256 or sha(gui_raw) != GUI_PROJECT_SHA256:
        raise ProjectError('Source/GUI project does not match the fixed B78/B581 seed identities.')
    if set(original) != set(gui) or any(original[p] != gui[p] for p in original if p != TARGET_MEMBER):
        raise ProjectError('GUI seed differs outside the supported NG_ReadAck ST body.')
    ast = cache / 'LastBuild.ast'
    if sha(ast.read_bytes()) != SEED_AST_SHA256:
        raise ProjectError('Cached AST does not match the measured GUI seed.')
    resource = cache / RESOURCE_NAME
    references = [p for p in resource.iterdir() if p.is_file() and p.suffix.lower() == '.dll'
                  and not _application_file(p.name)]
    if len(references) < 20 or not (resource / 'cilc.opt').is_file():
        raise ProjectError('Missing the measured external runtime references or native options.')
    vendor_files = {p.name: sha(p.read_bytes()) for p in sorted(install.glob('*.dll'))}
    for relative in (LOADER, BACKEND, 'CIL-Compiler/CilCompilerLoader.dll',
                     'CIL-Compiler/CilCompilerLoader.runtimeconfig.json'):
        path = install / relative
        vendor_files[relative] = sha(path.read_bytes())
    if not all(name in vendor_files for name in ('Ade.Compiler.dll', 'Ade.CompilerImpl.dll',
                                                'Ade.Compiler.EclrImpl.dll', 'Ade.Compiler.ParsingImpl.dll')):
        raise ProjectError('Required installed compiler assemblies are missing.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = destination.parent / ('.seed-staging-' + uuid.uuid4().hex)
    staging.mkdir()
    (staging / 'input').mkdir()
    (staging / 'references').mkdir()
    shutil.copyfile(ast, staging / 'input' / 'LastBuild.ast')
    shutil.copyfile(resource / 'cilc.opt', staging / 'cilc.opt')
    for reference in sorted(references):
        shutil.copyfile(reference, staging / 'references' / reference.name)
    files = {p.relative_to(staging).as_posix(): {'length': p.stat().st_size, 'sha256': sha(p.read_bytes())}
             for p in sorted(staging.rglob('*')) if p.is_file()}
    manifest = {'schema': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
                'source_project_sha256': SOURCE_PROJECT_SHA256, 'gui_project_sha256': GUI_PROJECT_SHA256,
                'ast_sha256': SEED_AST_SHA256, 'target_pou': TARGET_POU, 'target_member': TARGET_MEMBER,
                'resource_name': RESOURCE_NAME, 'files': files, 'vendor_files': vendor_files,
                'device_profile': {'name': 'AXCF2152', 'version': '2026.0.0', 'namespaces_supported': True},
                'scope': 'existing_NG_ReadAck_ST_body_only', 'limitations': LIMITATIONS.copy(),
                'install_directory_at_creation': str(install),
                'source_member_sha256': {p: sha(data) for p, data in sorted(original.items())},
                'old_application_cil_included': False, 'old_native_images_included': False,
                'cache_assisted': True, 'deployable': False}
    (staging / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    os.rename(staging, destination)
    return {'seed_directory': str(destination), 'reference_count': len(references),
            'vendor_hash_count': len(vendor_files), 'ast_sha256': SEED_AST_SHA256,
            'old_application_cil_included': False, 'old_native_images_included': False}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, default=DEFAULT_SEED)
    parser.add_argument('--source', type=Path, default=ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex')
    parser.add_argument('--gui-project', type=Path, default=ROOT / 'artifacts/native-mcp-e2e/workspace/61bd8dfe984c41aba50b35b06c4c3551/revision-0001.pcwex')
    parser.add_argument('--cache-root', type=Path, default=Path(r'C:\Users\windssea\Documents\PLCnext Engineer\Binaries\revision-0001@binary'))
    parser.add_argument('--install-directory', type=Path, default=Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', DEFAULT_INSTALL)))
    args = parser.parse_args()
    print(json.dumps(prepare(args.destination, args.source, args.gui_project, args.cache_root, args.install_directory), indent=2))


if __name__ == '__main__':
    main()
