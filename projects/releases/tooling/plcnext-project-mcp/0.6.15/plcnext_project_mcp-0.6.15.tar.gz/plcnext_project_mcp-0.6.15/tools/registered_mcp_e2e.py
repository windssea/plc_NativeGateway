"""Exercise the user-level Codex registration through real MCP stdio sessions.

Reads (never rewrites) `codex mcp get`. Uses its command, args and environment
unchanged, with two unrelated client directories to check cross-project use.
All edits/builds target a newly created managed copy of an installed template.
"""
from __future__ import annotations

import asyncio
from datetime import timedelta
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
import traceback
import uuid
import zipfile

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def members(path):
    with zipfile.ZipFile(path) as archive:
        return {item.filename: archive.read(item) for item in archive.infolist()}


async def main():
    run_id = uuid.uuid4().hex
    output = ROOT / 'artifacts/codex-registration' / run_id
    output.mkdir(parents=True)
    registration = json.loads(subprocess.check_output(
        [shutil.which('codex'), 'mcp', 'get', 'plcnext-project', '--json'],
        text=True, encoding='utf-8'))
    save(output / 'registration.json', registration)
    transport = registration['transport']
    assert registration['enabled'] and transport['type'] == 'stdio'
    assert not transport.get('cwd'), 'This probe tests registration without a fixed cwd.'
    assert not transport.get('env_vars'), 'Add inherited-variable support before testing this registration.'
    workspace = Path(transport['env']['PLCNEXT_MCP_WORKSPACE']).resolve()
    template = Path(transport['env']['PLCNEXT_ENGINEER_DIRECTORY']) / 'Templates/AXCF215200260.pxctx'
    template_sha = digest(template)
    client_dirs = [workspace / 'client-probes' / run_id / name for name in ('project-a', 'project-b')]
    for directory in client_dirs:
        directory.mkdir(parents=True)
        assert not directory.is_relative_to(ROOT)
    result = {'status': 'running', 'server_name': registration['name'], 'transport': 'MCP stdio',
              'registered_command_args_env_used_unchanged': True,
              'client_directories': [str(path) for path in client_dirs],
              'workspace': str(workspace), 'aci_used': False, 'computer_use_used': False,
              'controller_connected': False, 'controller_downloaded': False,
              'deployable': False, 'checks': {}}
    save(output / 'progress.json', result)
    print(json.dumps({'run_directory': str(output)}), flush=True)

    def parameters(cwd):
        return StdioServerParameters(command=transport['command'], args=transport['args'],
                                     env=transport['env'], cwd=str(cwd))

    async def call(client, name, arguments):
        response = await client.call_tool(name, arguments)
        assert not response.isError, (name, response.content)
        return response.structuredContent or json.loads(response.content[0].text)

    async def compile_now(client, pid, label, expected_count):
        current = await call(client, 'project_inspect', {'project_id': pid})
        start = time.monotonic()
        report = await call(client, 'project_compile', {'project_id': pid,
            'expected_project_sha256': current['project_sha256']})
        save(output / (label + '.json'), report)
        assert report['compiled'] and report['backend_exit_code'] == 0, report['status']
        assert report['build_mode'] == 'cold' and report['iec_model_rebuilt_from_sources']
        assert not report['ast_seed_used'] and not report['cache_assisted']
        assert not any(report[key] for key in ('aci_used', 'computer_use_used', 'controller_connected',
                                             'controller_downloaded', 'deployable'))
        assert report['host']['pous_reparsed'] == expected_count == len(current['pous'])
        assert not (Path(report['job_directory']) / 'input/LastBuild.ast').exists()
        assert digest(report['image_path']) == report['image_sha256']
        result['checks'][label] = {'passed': True, 'pou_count': expected_count,
            'seconds': round(time.monotonic() - start, 2), 'image_path': report['image_path'],
            'report_path': str(output / (label + '.json'))}
        save(output / 'progress.json', result)
        print(json.dumps({'test': label, **result['checks'][label]}), flush=True)
        return report

    try:
        with (output / 'server-project-a.log').open('w', encoding='utf-8') as log:
            async with stdio_client(parameters(client_dirs[0]), errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=60)) as client:
                    await client.initialize()
                    names = sorted(tool.name for tool in (await client.list_tools()).tools)
                    assert {'project_create', 'project_add_fb', 'project_delete_fb', 'project_compile'} <= set(names)
                    save(output / 'tools.json', names)
                    capabilities = await call(client, 'server_capabilities', {})
                    save(output / 'capabilities.json', capabilities)
                    assert Path(capabilities['workspace']).resolve() == workspace
                    result['checks']['tool_discovery'] = {'passed': True, 'tool_count': len(names)}

                    created = await call(client, 'project_create', {'name': 'CodexProbe_' + run_id[:8]})
                    save(output / '01-created.json', created)
                    pid = created['project_id']
                    assert Path(created['project_path']).resolve().is_relative_to(workspace)
                    original = members(created['project_path'])
                    main_before = await call(client, 'project_read_pou', {'project_id': pid, 'pou_name': 'Main'})
                    await compile_now(client, pid, '02-baseline-cold-build', 1)

                    added = await call(client, 'project_add_fb', {'project_id': pid,
                        'expected_project_sha256': created['project_sha256'], 'pou_name': 'RegistrationProbeFB',
                        'code': 'IF Enable THEN Value := UINT#24680; ELSE Value := UINT#0; END_IF;\n',
                        'variables': 'VAR_INPUT\n Enable : BOOL;\nEND_VAR\nVAR_OUTPUT\n Value : UINT;\nEND_VAR\n'})
                    save(output / '03-added-fb.json', added)
                    main_now = await call(client, 'project_read_pou', {'project_id': pid, 'pou_name': 'Main'})
                    declaration = ' probe : RegistrationProbeFB;\n'
                    variables = re.sub(r'(^VAR[ \t]*\r?\n)', lambda m: m[0] + declaration,
                                       main_now['variables'], count=1, flags=re.M)
                    assert variables != main_now['variables']
                    updated = await call(client, 'project_update_pous', {'project_id': pid,
                        'expected_project_sha256': added['project_sha256'], 'updates': [{'pou_name': 'Main',
                        'expected_code_sha256': main_now['code_sha256'],
                        'expected_variables_sha256': main_now['variables_sha256'],
                        'code': main_now['code'] + '\nprobe(Enable := TRUE);\n', 'variables': variables}]})
                    save(output / '04-caller-updated.json', updated)
                    compiled = await compile_now(client, pid, '05-added-fb-cold-build', 2)
                    assert 'RegistrationProbeFB.dll' in {item['name'] for item in compiled['generated_files']}
                    shutil.copyfile(updated['project_path'], output / 'CodexProbe.with-fb.pcwex')
                    denied = await client.call_tool('project_delete_fb', {'project_id': pid,
                        'expected_project_sha256': updated['project_sha256'], 'pou_name': 'RegistrationProbeFB'})
                    assert denied.isError
                    now = await call(client, 'project_inspect', {'project_id': pid})
                    assert now['project_sha256'] == updated['project_sha256']
                    result['checks']['referenced_fb_delete_rejected_without_mutation'] = {
                        'passed': True, 'messages': [item.text for item in denied.content if item.type == 'text']}
                    current = members(updated['project_path'])
                    protected = [name for name in original if name.endswith(
                        ('DataList.dl', 'EsmConfiguration.esmc', 'IOConfiguration.ioc', 'Metadata.meta'))]
                    assert protected and all(current[name] == original[name] for name in protected)
                    validation = await call(client, 'project_validate', {'project_id': pid})
                    assert validation['preservation_passed']
                    save(output / '06-preservation.json', validation)
                    result['checks']['ids_and_mappings_preserved'] = {'passed': True, 'members_checked': len(protected)}

                    main_now = await call(client, 'project_read_pou', {'project_id': pid, 'pou_name': 'Main'})
                    restored = await call(client, 'project_update_pous', {'project_id': pid,
                        'expected_project_sha256': main_now['project_sha256'], 'updates': [{'pou_name': 'Main',
                        'expected_code_sha256': main_now['code_sha256'],
                        'expected_variables_sha256': main_now['variables_sha256'],
                        'code': main_before['code'], 'variables': main_before['variables']}]})
                    deleted = await call(client, 'project_delete_fb', {'project_id': pid,
                        'expected_project_sha256': restored['project_sha256'], 'pou_name': 'RegistrationProbeFB'})
                    save(output / '07-deleted-fb.json', deleted)
                    compiled = await compile_now(client, pid, '08-after-delete-cold-build', 1)
                    assert 'RegistrationProbeFB.dll' not in {item['name'] for item in compiled['generated_files']}
                    final = members(deleted['project_path'])
                    assert set(original) == set(final)
                    allowed = {'PROJECT/PROJECT.proj', '[Content_Types].xml'}
                    assert all(final[name] == original[name] for name in original if name not in allowed)
                    assert (await call(client, 'project_validate', {'project_id': pid}))['preservation_passed']
                    shutil.copyfile(deleted['project_path'], output / 'CodexProbe.after-delete.pcwex')
                    result['project_id'] = pid
                    result['final_project_path'] = deleted['project_path']

        with (output / 'server-project-b.log').open('w', encoding='utf-8') as log:
            async with stdio_client(parameters(client_dirs[1]), errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=60)) as client:
                    await client.initialize()
                    inspected = await call(client, 'project_inspect', {'project_id': pid})
                    assert inspected['project_sha256'] == deleted['project_sha256']
                    assert [pou['name'] for pou in inspected['pous']] == ['Main']
                    result['checks']['second_client_directory_reopened_managed_project'] = {'passed': True}
        assert digest(template) == template_sha
        result['template'] = {'path': str(template), 'sha256': template_sha, 'unchanged': True}
        result['status'] = 'passed'
        save(output / 'result.json', result)
        save(output / 'progress.json', result)
        save(output.parent / 'latest-result.json', {'status': 'passed', 'result_path': str(output / 'result.json')})
        print(json.dumps({'status': 'passed', 'result_path': str(output / 'result.json')}), flush=True)
    except BaseException:
        result.update(status='failed', traceback=traceback.format_exc())
        save(output / 'progress.json', result)
        raise


if __name__ == '__main__':
    asyncio.run(main())
