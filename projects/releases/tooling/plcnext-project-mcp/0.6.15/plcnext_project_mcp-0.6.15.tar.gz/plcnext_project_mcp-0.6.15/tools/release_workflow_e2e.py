"""Offline release acceptance through an actual stdio MCP client. Never calls PLC tools."""
import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def run(args):
    args.output.mkdir(parents=True, exist_ok=True)
    environment = {**os.environ, 'PLCNEXT_MCP_WORKSPACE': str(args.workspace),
                   'PLCNEXT_MCP_RELEASE_ROOT': str(args.releases)}
    parameters = StdioServerParameters(command=sys.executable, args=['-I', '-m', 'plcnext_mcp.server'], env=environment)
    records = []
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as session:
            await session.initialize()
            async def call(name, values):
                reply = await session.call_tool(name, values)
                if reply.isError:
                    raise RuntimeError(name + ': ' + str(reply.content))
                text = next(item.text for item in reply.content if item.type == 'text')
                value = json.loads(text)
                index = len(records)
                path = args.output / f'{index:02d}-{name}.json'
                path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
                records.append({'tool': name, 'report': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
                print(name, value.get('status', value.get('version', 'recorded')), flush=True)
                return value
            capabilities = await call('server_capabilities', {})
            assert capabilities['release_management']['real_download_and_recovery_guarded']
            if args.resume_from:
                dev = json.loads((args.resume_from / '04-project_release_prepare_dev.json').read_text(encoding='utf-8'))
                package = json.loads((args.resume_from / '07-project_generate_pcwe.json').read_text(encoding='utf-8'))
                managed = dev['managed_project']
                await call('project_release_bind_package', {'project_id': managed['project_id'],
                    'expected_project_sha256': managed['project_sha256'], 'package_job_id': package['package_job_id']})
                await call('project_release_inventory', {})
                (args.output / 'mcp-evidence-index.json').write_text(json.dumps({
                    'tools': records, 'controller_calls': 0, 'computer_use': False,
                    'server_version': capabilities['version'], 'previous_offline_workflow': str(args.resume_from)}, indent=2), encoding='utf-8')
                return
            baseline = {
                'AXCF2152': args.engineer / 'projects/candidates/native-0.8.1/NativeGateway.pcwex',
                'AXCF1252': args.engineer / 'projects/variants/native-0.8.1-axcf1252/NativeGateway1252Candidate.pcwex'}
            for target, path in baseline.items():
                await call('project_release_archive_historical', {
                    'source_path': str(path), 'expected_project_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'provenance_note': 'Historical exact-byte archive. Existing verification documents remain authoritative; no new device operation or acceptance is claimed.'})
            for target, candidate in [('AXCF2152', args.candidate2152), ('AXCF1252', args.candidate1252)]:
                imported = await call('project_import_copy', {'source_path': str(candidate)})
                dev = await call('project_release_prepare_dev', {
                    'project_id': imported['project_id'], 'expected_project_sha256': imported['project_sha256'],
                    'base_version': '0.8.2', 'change_note': 'NG_Modbus scale candidate; target-isolated dev identity, not downloaded or hardware accepted.'})
                managed = dev['managed_project']
                values = {'project_id': managed['project_id'], 'expected_project_sha256': managed['project_sha256']}
                plan = await call('project_build_plan', {'project_id': managed['project_id']})
                if args.compile and target == 'AXCF2152':
                    build = await call('project_compile', values)
                    assert build['compiled'], build.get('status')
                    package = await call('project_generate_pcwe', {**values, 'build_job_id': build['job_id'],
                                                                   'download_memento_policy': 'empty_capability_v1'})
                    assert package['package_complete']
                    await call('project_release_bind_package', {**values, 'package_job_id': package['package_job_id']})
            inventory = await call('project_release_inventory', {})
            assert all(not item['deployment_attempts'] for item in inventory['releases'])
    (args.output / 'mcp-evidence-index.json').write_text(json.dumps({
        'tools': records, 'controller_calls': 0, 'computer_use': False,
        'release_count': len(inventory['releases']), 'server_version': capabilities['version']}, indent=2), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('workspace', 'releases', 'engineer', 'candidate2152', 'candidate1252', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--resume-from', type=Path)
    asyncio.run(run(parser.parse_args()))
