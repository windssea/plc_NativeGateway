"""M12 public discovery and original-profile refusal. No PLC I/O."""
import asyncio,json,os,sys,tempfile
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    root=Path(__file__).resolve().parents[1];folder=root/'artifacts/audit-export-research';folder.mkdir(exist_ok=True)
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']=r'D:\PLCnext-MCP-Workspace'
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    async with stdio_client(params) as (r,w):
        async with ClientSession(r,w) as session:
            await session.initialize();tools=await session.list_tools()
            caps=await session.call_tool('server_capabilities',{})
            value=caps.structuredContent
            if value is None:value=json.loads('\n'.join(x.text for x in caps.content if x.type=='text'))
            assert value['version']=='0.6.4' and len(tools.tools)==78
            expected={'project_prepare_audit_export','project_inspect_audit_export','project_execute_audit_export','project_audit_export_status','project_cancel_audit_export'}
            assert expected<={t.name for t in tools.tools}
            response=await session.call_tool('project_prepare_audit_export',{'project_id':'17ae4361baa846868b14775bf1de15ea',
                'expected_project_sha256':'7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154',
                'package_job_id':'f7fc619d55ba42c091f4ca0efed23e73','address':'192.168.0.8',
                'expected_certificate_sha256':'3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863',
                'expected_boot_id':'offline-validation-no-PLC-I-O'})
            message='\n'.join(x.text for x in response.content if x.type=='text')
            assert response.isError and 'audit_profile_unsupported' in message
            report={'version':value['version'],'tool_count':len(tools.tools),'new_tools':sorted(expected),
                'original_profile_refused':True,'error':message,'controller_connected':False,'authorization_issued':False}
            (folder/'public-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':asyncio.run(main())
