param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputDirectory){throw 'Fresh oracle output directory required.'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
foreach($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Arp.System.Rsc.Services')){[void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name+'.dll')))}
$flags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
function T($name){foreach($a in [AppDomain]::CurrentDomain.GetAssemblies()){$type=$a.GetType($name,$false);if($null -ne $type){return $type}};throw "Missing type $name"}
function N($type,$constructArgs){[Activator]::CreateInstance($type,$flags,$null,[object[]]$constructArgs,$null)}
$tagType=T 'Ade.CommonRemoting.Internal.TagInfo';$formatter=T 'Ade.CommonRemoting.Internal.RemotingFormatter';$formatter4=T 'Ade.CommonRemoting.Internal.RemotingFormatter4'
$marshalType=T 'Ade.CommonRemoting.AdeMarshalType';$version=[Enum]::ToObject((T 'Ade.CommonRemoting.RemotingVersion'),4)
$streamType=T 'Ade.CommonRemoting.Internal.RemotingStream';$headerType=T 'Ade.CommonRemoting.CommandHeader'
$script:vectors=@()
function Stream($memory){$s=N $streamType @($memory,[object]::new(),$false);$streamType.GetProperty('RemotingVersion',$flags).SetValue($s,$version);$streamType.GetProperty('HasDataTagging',$flags).SetValue($s,$true);return $s}
function Call($method,$arguments){
 $properties=[Collections.Hashtable]::new();$inputs=[Collections.Generic.List[object]]::new();$outputs=[Collections.Generic.List[object]]::new()
 foreach($parameter in $method.GetParameters()){
  $attributes=[object[]]$parameter.GetCustomAttributes($false)
  $marshal=$formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attributes))
  if($parameter.IsOut){$outputs.Add($marshal)}else{$inputs.Add($marshal)}
 }
 if($method.ReturnType -ne [void]){$attributes=[object[]]$method.ReturnParameter.GetCustomAttributes($false);$outputs.Add($formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attributes)))}
 $properties['AdeInMarshalling']=[Array]::CreateInstance($marshalType,$inputs.Count);$properties['AdeOutMarshalling']=[Array]::CreateInstance($marshalType,$outputs.Count)
 for($i=0;$i -lt $inputs.Count;$i++){$properties['AdeInMarshalling'].SetValue($inputs[$i],$i)}
 for($i=0;$i -lt $outputs.Count;$i++){$properties['AdeOutMarshalling'].SetValue($outputs[$i],$i)}
 N (T 'Ade.CommonRemoting.Internal.CallMessage') @($method,[object[]]$arguments,$properties)
}
function Save($name,$raw,$details){
 $file=Join-Path $OutputDirectory ($name+'.bin');[IO.File]::WriteAllBytes($file,$raw)
 $script:vectors+=@{name=$name;hex=[Convert]::ToHexString($raw).ToLowerInvariant();bytes=$raw.Length;sha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant();details=$details}
}
function EmitCall($name,$interface,$methodName,$arguments,$returnValue,$outValues=@()){
 $method=$interface.GetMethod($methodName)
 $methodId=($method.GetCustomAttributesData()|Where-Object {$_.AttributeType.Name -eq 'RscMethodAttribute'}).ConstructorArguments[0].Value
 $call=Call $method $arguments
 $memory=[IO.MemoryStream]::new();$stream=Stream $memory
 [void]$formatter4.GetMethod('SerializeMessage',$flags).Invoke($null,[object[]]@([int16]$methodId,[int16]41,[int16]5,$call,$stream,$version))
 Save ($name+'-request') $memory.ToArray() @{method=$methodName;interface=$interface.FullName;method_id=$methodId;actual_original_serialize_message=$true;handles_synthetic=$true}
 $header=[Activator]::CreateInstance($headerType)
 foreach($entry in @{Version=[byte]4;Flags=[byte]64;CommandType=[Enum]::ToObject((T 'Ade.CommonRemoting.CommandType'),3);ServiceHandle=[int16]41;MethodHandle=[int16]$methodId;ServiceProviderHandle=[int16]5}.GetEnumerator()){$headerType.GetProperty($entry.Key).SetValue($header,$entry.Value)}
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory)
 $writeHeader=$headerType.GetMethods($flags)|Where-Object {$_.Name -eq 'Write' -and $_.GetParameters()[2].ParameterType -eq [bool]}
 [void]$writeHeader.Invoke($null,[object[]]@($header,$writer,$true))
 $index=0
 foreach($tag in $call.GetType().GetProperty('ArgTags',$flags).GetValue($call)){
  if($tag.GetType().GetProperty('IsOut',$flags).GetValue($tag)){[void]$formatter.GetMethod('SerializeValue',$flags).Invoke($null,[object[]]@($tag,$outValues[$index],$writer,$version,$true,$false));$index++}
 }
 if($method.ReturnType -ne [void]){$tag=$call.GetType().GetProperty('ReturnTag',$flags).GetValue($call);[void]$formatter.GetMethod('SerializeValue',$flags).Invoke($null,[object[]]@($tag,$returnValue,$writer,$version,$true,$false))}
 $writer.Write([byte]255);$writer.Flush();$raw=$memory.ToArray();$memory.Position=0;$stream=Stream $memory
 [void]$formatter4.GetMethod('DeserializeMessage',$flags).Invoke($null,[object[]]@($stream,$call,$version))
 if($memory.Position -ne $memory.Length){throw "Original response reader left bytes for $name"}
 Save ($name+'-response') $raw @{method=$methodName;method_id=$methodId;original_reader_consumed_all=$true;handles_synthetic=$true}
}
$plc=T 'Arp.Plc.Domain.Services.IPlcManagerService';$state=T 'Arp.Plc.Domain.Services.PlcState'
foreach($method in @('Reset','Load')){foreach($value in @($false,$true)){EmitCall ($method.ToLowerInvariant()+'-'+$value.ToString().ToLowerInvariant()) $plc $method ([object[]]@([bool]$value)) $null}}
foreach($value in @([uint32]0,[uint32]3,[uint32]::MaxValue)){EmitCall ('state-'+$value) $plc 'GetPlcState' ([object[]]@()) ([Enum]::ToObject($state,$value))}
$auth=T 'Arp.System.Security.Services.IPasswordAuthenticationService';$tokenType=T 'Arp.Base.Rsc.Commons.Security.SecurityToken';$authErrorType=T 'Arp.System.Security.Services.AuthenticationError'
$password=[Security.SecureString]::new();foreach($char in 'offline-fixture-only'.ToCharArray()){$password.AppendChar($char)};$password.MakeReadOnly()
try{
 $token=N $tokenType @([uint32]1234567)
 EmitCall 'create-session' $auth 'CreateSession' ([object[]]@('offline-user',$password,$null,0)) ([Enum]::ToObject($authErrorType,0)) ([object[]]@($token,[int32]0))
 EmitCall 'close-session' $auth 'CloseSession' ([object[]]@($token)) $null
}finally{$password.Dispose()}
@{scope='Original tagged v4 SerializeMessage and synthetic response DeserializeMessage in MemoryStream only; no provider/network/ACI/Engineer';network_operations=0;aci_calls=0;engineer_started=$false;version=4;tagging=$true;vectors=$script:vectors;assemblies=@('Arp.Base.Rsc.Commons.dll','Ade.CommonRemoting.Commons.dll','Arp.System.Rsc.Services.dll')|ForEach-Object{@{name=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $install $_)).Hash.ToLowerInvariant()}}}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8
Write-Output ('Verified {0} tagged request/response vectors' -f $script:vectors.Count)
