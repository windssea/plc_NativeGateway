#requires -Version 7.0
<#
.SYNOPSIS
Open the independent operator terminal approval flow. Never connects to a PLC.
.DESCRIPTION
Issue and Withdraw require an interactive terminal and precise typed review hash.
There is no automatic Yes switch. Run this manually in the operator's terminal;
do not use it from an AI tool to impersonate the operator.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('inspect', 'issue', 'withdraw')][string]$Command,
    [ValidateSet('download', 'control', 'recovery', 'instrumented_fault')][string]$Kind = 'download',
    [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{32}$')][string]$ProjectId,
    [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{32}$')][string]$ReviewId,
    [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{64}$')][string]$ReviewSha256,
    [string]$Workspace = 'D:\PLCnext-MCP-Workspace',
    [string]$PythonPath,
    [ValidateRange(1, 3600)][int]$LifetimeSeconds = 900
)

$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (-not $PythonPath) { $PythonPath = Join-Path $repository '.venv\Scripts\python.exe' }
$python = [IO.Path]::GetFullPath($PythonPath)
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw "Python executable not found: $python"
}
$workspacePath = [IO.Path]::GetFullPath($Workspace)
& $python -I -m plcnext_mcp.operator_approval $Command `
    --kind $Kind --workspace $workspacePath `
    --project-id $ProjectId --review-id $ReviewId --review-sha256 $ReviewSha256 `
    --lifetime-seconds $LifetimeSeconds
if ($LASTEXITCODE -ne 0) { throw "Operator approval command refused or failed (exit $LASTEXITCODE). No PLC connection is made by this command." }
