"""Real MCP checks for all NativeGateway POU code, variables and FB interfaces.

Only an imported B78 project copy is edited. No generated application is run,
and no IDE, ACI, PLC connection or download operation is used.
"""
from __future__ import annotations

import asyncio
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback
import uuid
import zipfile

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'
FROZEN_SHA = 'b78ba0efd0f8f79558143d58f3eb141512876690b2eda2a641e96ba3a3cbaddf'
INSTALL = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def insert_variable(text: str, block: str, declaration: str) -> str:
    pattern = re.compile(r'^[ \t]*' + re.escape(block) + r'[ \t]*(?:\r?\n|\r)', re.MULTILINE)
    match = pattern.search(text)
    if match:
        return text[:match.end()] + '    ' + declaration + '\n' + text[match.end():]
    if block != 'VAR':
        raise AssertionError('Expected existing variable section: ' + block)
    return text + '\nVAR\n    ' + declaration + '\nEND_VAR\n'


CECIL_READER = r'''
param([string]$InstallDirectory,[string]$Generated,[string]$Output)
$ErrorActionPreference='Stop'
$parser=Join-Path $InstallDirectory 'Mono.Cecil.dll'
[void][Reflection.Assembly]::LoadFrom($parser)
function ExpandTypes($types) {
    foreach($t in $types) { $t; if($t.HasNestedTypes) { ExpandTypes $t.NestedTypes } }
}
$entries=@()
foreach($file in @(Get-ChildItem -LiteralPath $Generated -File -Filter '*.dll' | Where-Object {$_.Name -eq 'Main.dll' -or $_.Name -like 'NG_*.dll'})) {
    $parameters=[Mono.Cecil.ReaderParameters]::new()
    $parameters.ReadSymbols=$false
    $parameters.ReadingMode=[Mono.Cecil.ReadingMode]::Deferred
    $module=[Mono.Cecil.ModuleDefinition]::ReadModule($file.FullName,$parameters)
    try {
        $types=@(ExpandTypes $module.Types)
        $fields=@($types | ForEach-Object {$type=$_; $_.Fields | ForEach-Object {
            [ordered]@{declaring_type=$type.FullName;name=$_.Name;type=$_.FieldType.FullName}
        }})
        $methods=@($types | ForEach-Object {$type=$_; $_.Methods | Where-Object HasBody | ForEach-Object {
            $m=$_
            $constants=@($m.Body.Instructions | Where-Object {$_.OpCode.Code.ToString() -eq 'Ldc_I4'} | ForEach-Object {[int]$_.Operand})
            [ordered]@{declaring_type=$type.FullName;name=$m.Name;signature=$m.FullName;
                locals=@($m.Body.Variables | ForEach-Object {$_.VariableType.FullName});
                integer_constants=$constants;instruction_count=$m.Body.Instructions.Count;
                first_instructions=@($m.Body.Instructions | Select-Object -First 128 | ForEach-Object {$_.ToString()})}
        }})
        $entries+= [ordered]@{file=$file.Name;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant();fields=$fields;methods=$methods}
    } finally {$module.Dispose()}
}
[ordered]@{operation='read_only_generated_cil_metadata';target_code_executed=$false;
    parser=$parser;parser_sha256=(Get-FileHash -LiteralPath $parser).Hash.ToLowerInvariant();assemblies=$entries} |
    ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $Output -Encoding utf8
'''


def inspect_generated_cil(report: dict, original_pous: list[dict], constants: dict[str, int], output: Path) -> dict:
    script = output / 'inspect-generated-cil.ps1'
    script.write_text(CECIL_READER, encoding='utf-8')
    evidence_path = output / 'generated-cil-evidence.json'
    shell = shutil.which('pwsh')
    assert shell, 'PowerShell 7 is required for read-only generated CIL verification.'
    command = [shell, '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(script),
               '-InstallDirectory', str(INSTALL), '-Generated', str(Path(report['job_directory']) / 'generated'),
               '-Output', str(evidence_path)]
    completed = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, timeout=30,
                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    (output / 'cil-inspection-stdout.log').write_bytes(completed.stdout)
    (output / 'cil-inspection-stderr.log').write_bytes(completed.stderr)
    assert completed.returncode == 0, 'Read-only Cecil inspection failed: ' + str(evidence_path)
    evidence = json.loads(evidence_path.read_text(encoding='utf-8-sig'))
    assemblies = {a['file'].removesuffix('.dll'): a for a in evidence['assemblies']}
    checked = []
    for pou in original_pous:
        name, kind = pou['name'], pou['kind']
        assembly = assemblies[name]
        probe_fields = [f for f in assembly['fields'] if f['name'].casefold() == 'mcpprobe']
        values = [v for m in assembly['methods'] for v in m['integer_constants']]
        item = {'pou': name, 'kind': kind, 'distinct_constant': constants[name], 'constant_present': constants[name] in values}
        if kind == 'Function':
            # Functions use method-local CIL variables, rather than persistent FB fields.
            local_types = [t for m in assembly['methods'] for t in m['locals']]
            item['uint16_local_present'] = 'System.UInt16' in local_types
            assert item['uint16_local_present'] and item['constant_present'], item
        else:
            item['probe_field_present'] = any(f['type'] == 'System.UInt16' for f in probe_fields)
            assert item['probe_field_present'] and item['constant_present'], item
        if name == 'NG_ReadAck':
            item['gate_field_present'] = any(f['name'].casefold() == 'mcpgate' and f['type'] == 'System.Boolean'
                                              for f in assembly['fields'])
            assert item['gate_field_present'], item
        checked.append(item)
    result = {'status': 'passed', 'checked': checked, 'checked_pous': len(checked),
              'target_code_executed': False, 'evidence_path': str(evidence_path)}
    save(output / 'cil-verification.json', result)
    return result


def preserved(original: Path, current: Path, expected_members: set[str]) -> dict:
    with zipfile.ZipFile(original) as archive:
        before = {i.filename: archive.read(i) for i in archive.infolist()}
    with zipfile.ZipFile(current) as archive:
        after = {i.filename: archive.read(i) for i in archive.infolist()}
    assert set(before) == set(after)
    changed = {name for name in before if before[name] != after[name]}
    assert changed == expected_members, (sorted(changed), sorted(expected_members))
    protected = [name for name in before if name.endswith(('Metadata.meta', 'DataList.dl', 'EsmConfiguration.esmc', 'IOConfiguration.ioc'))]
    assert all(before[name] == after[name] for name in protected)
    assert all(before[name] == after[name] for name in before if name not in expected_members)
    return {'status': 'passed', 'member_set_unchanged': True, 'changed_members': sorted(changed),
            'all_other_member_payloads_byte_identical': True, 'protected_metadata_mapping_members': len(protected),
            'metadata_datalist_esm_io_payloads_byte_identical': True}


async def main(mode: str = 'cached') -> None:
    assert digest(FROZEN) == FROZEN_SHA
    base = ROOT / ('artifacts/expanded-compile-mcp-e2e' if mode == 'cached' else 'artifacts/cold-compile-mcp-e2e')
    output = base / uuid.uuid4().hex
    output.mkdir(parents=True)
    print(json.dumps({'run_directory': str(output), 'status': 'starting'}), flush=True)
    progress = {'status': 'running', 'transport': 'MCP stdio', 'run_directory': str(output)}
    save(output / 'progress.json', progress)
    environment = dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(output / 'workspace'))
    if mode == 'cold':
        # Deliberately unavailable: successful cold builds cannot depend on the project seed.
        environment['PLCNEXT_NATIVEGATEWAY_SEED'] = str(output / 'no-project-seed-exists')
    parameters = StdioServerParameters(command=sys.executable, args=['-m', 'plcnext_mcp.server'], env=environment)
    try:
        async with stdio_client(parameters) as (reader, writer):
            async with ClientSession(reader, writer) as client:
                await client.initialize()

                async def call(name, arguments):
                    response = await client.call_tool(name, arguments)
                    if response.isError:
                        raise RuntimeError(f'{name}: {response.content}')
                    return response.structuredContent or json.loads(response.content[0].text)

                capabilities = await call('server_capabilities', {})
                save(output / 'capabilities.json', capabilities)
                key = 'nativegateway_source_compile' if mode == 'cached' else 'nativegateway_cold_compile'
                assert capabilities[key]['available'], capabilities
                if mode == 'cold':
                    assert not capabilities['cache_assisted_compile']['available']
                    assert not capabilities['nativegateway_source_compile']['available']
                imported = await call('project_import_copy', {'source_path': str(FROZEN)})
                project_id = imported['project_id']
                initial = await call('project_inspect', {'project_id': project_id})
                kinds = dict(Counter(p['kind'] for p in initial['pous']))
                assert kinds == {'Function': 16, 'FunctionBlock': 14, 'Program': 1}, kinds

                async def read(name):
                    return await call('project_read_pou', {'project_id': project_id, 'pou_name': name})

                async def compile_current(label):
                    current = await read('NG_ReadAck')
                    result = await call('project_compile_nativegateway', {'project_id': project_id,
                        'expected_project_sha256': current['project_sha256'], 'mode': mode})
                    save(output / (label + '.json'), result)
                    progress['last_compile'] = label
                    progress['last_compile_report'] = str(output / (label + '.json'))
                    save(output / 'progress.json', progress)
                    print(json.dumps({'test': label, 'revision': result.get('revision'),
                                      'status': result.get('status'), 'compiled': result.get('compiled'),
                                      'report_path': result.get('report_path')}), flush=True)
                    return result

                def success(report):
                    assert report['compiled'] and report.get('backend_exit_code') == 0, report
                    assert report['host']['pous_reparsed'] == 31 and report['host']['interfaces_reparsed'] == 31
                    assert report['deployable'] is False and report['aci_used'] is False
                    if mode == 'cold':
                        assert report['ast_seed_used'] is False and report['cache_assisted'] is False
                        assert not (Path(report['job_directory']) / 'input/LastBuild.ast').exists()

                def failure(report, status):
                    assert report['compiled'] is False and report['status'] == status, report
                    job = Path(report['job_directory'])
                    assert 'backend_exit_code' not in report, report
                    assert not (job / 'backend-stdout.log').exists()
                    assert not list(job.rglob('*.img'))

                baseline = await compile_current('01-baseline')
                success(baseline)
                valid = {}
                constants = {}
                updates = []
                for number, pou in enumerate(sorted(initial['pous'], key=lambda p: p['name']), start=1):
                    name = pou['name']
                    current = await read(name)
                    assert 'McpProbe' not in current['variables'] and 'McpGate' not in current['variables']
                    constants[name] = 40000 + number
                    variables = insert_variable(current['variables'], 'VAR', 'McpProbe : UINT;')
                    code = f'McpProbe := UINT#{constants[name]};\n' + current['code']
                    if name == 'NG_ReadAck':
                        variables = insert_variable(variables, 'VAR_INPUT', 'McpGate : BOOL;')
                        code = f'McpProbe := UINT#{constants[name]};\nIF McpGate THEN McpProbe := UINT#99; END_IF;\n' + current['code']
                    if name == 'Main':
                        code, count = re.subn(r'\bAckReader\s*\(', lambda m: m.group(0) + 'McpGate:=TRUE, ', code)
                        assert count == 1, 'Expected exactly one existing AckReader call.'
                    valid[name] = {'code': code, 'variables': variables}
                    updates.append({'pou_name': name, 'expected_code_sha256': current['code_sha256'],
                                    'expected_variables_sha256': current['variables_sha256'],
                                    'code': code, 'variables': variables})
                updated = await call('project_update_pous', {'project_id': project_id,
                    'expected_project_sha256': imported['project_sha256'], 'updates': updates})
                save(output / '02-atomic-update.json', updated)
                assert updated['revision'] == 1 and len(updated['updates']) == 31 and len(updated['changed_members']) == 62
                validation = await call('project_validate', {'project_id': project_id})
                save(output / '03-validation.json', validation)
                assert validation['preservation_passed']
                modified = await compile_current('04-all-pous-and-interface')
                success(modified)
                cil = inspect_generated_cil(modified, initial['pous'], constants, output)
                exact = preserved(FROZEN, Path(updated['project_path']), set(updated['changed_members']))
                save(output / '05-preservation-bytes.json', exact)

                stale_update = await client.call_tool('project_update_pous', {'project_id': project_id,
                    'expected_project_sha256': imported['project_sha256'], 'updates': updates})
                stale_compile = await client.call_tool('project_compile_nativegateway', {'project_id': project_id,
                    'expected_project_sha256': imported['project_sha256']})
                assert stale_update.isError and stale_compile.isError
                stale = {'old_update_hash_rejected': stale_update.isError, 'old_compile_hash_rejected': stale_compile.isError}
                save(output / '06-stale-hashes.json', stale)

                async def apply(desired):
                    batch = []
                    expected = None
                    for name, texts in desired.items():
                        current = await read(name)
                        expected = current['project_sha256']
                        if all(current[key].replace('\r\n', '\n') == value.replace('\r\n', '\n') for key, value in texts.items()):
                            continue
                        batch.append({'pou_name': name, 'expected_code_sha256': current['code_sha256'],
                                      'expected_variables_sha256': current['variables_sha256'], **texts})
                    assert batch, 'Expected at least one source change.'
                    return await call('project_update_pous', {'project_id': project_id,
                        'expected_project_sha256': expected, 'updates': batch})

                assert valid['Main']['code'].count('McpGate:=TRUE') == 1
                await apply({'Main': {'code': valid['Main']['code'].replace('McpGate:=TRUE', 'McpGate:=Doc')}})
                wrong_type = await compile_current('07-type-error')
                failure(wrong_type, 'semantic_failed')
                assert any(m['type_id'] == 'SEM1117' for m in wrong_type['host']['semantic']['messages'])

                renamed_variables, count = re.subn(r'\bMcpGate\b', 'McpGateRenamed', valid['NG_ReadAck']['variables'])
                assert count == 1
                renamed_code = re.sub(r'\bMcpGate\b', 'McpGateRenamed', valid['NG_ReadAck']['code'])
                await apply({'Main': {'code': valid['Main']['code']},
                             'NG_ReadAck': {'code': renamed_code, 'variables': renamed_variables}})
                wrong_parameter = await compile_current('08-parameter-error')
                failure(wrong_parameter, 'semantic_failed')
                assert any(m['type_id'] == 'SEM1115' for m in wrong_parameter['host']['semantic']['messages'])

                broken_variables = valid['NG_ReadAck']['variables'].replace('McpProbe : UINT;', 'McpProbe UINT;', 1)
                assert broken_variables != valid['NG_ReadAck']['variables']
                await apply({'NG_ReadAck': {'code': valid['NG_ReadAck']['code'], 'variables': broken_variables}})
                invalid_declaration = await compile_current('09-variable-syntax-error')
                failure(invalid_declaration, 'syntax_failed')
                assert any(m['type_id'] == 'VAR0007' for m in invalid_declaration['host']['syntax']['messages'])

                restored = await apply(valid)
                save(output / '10-restored-valid.json', restored)
                restored_compile = await compile_current('11-restored-compile')
                success(restored_compile)
                final_validation = await call('project_validate', {'project_id': project_id})
                assert final_validation['preservation_passed']
                final_bytes = preserved(FROZEN, Path(restored['project_path']), set(updated['changed_members']))
                assert digest(FROZEN) == FROZEN_SHA
                result = {'status': 'passed', 'transport': 'MCP stdio', 'run_directory': str(output),
                    'project_id': project_id, 'mode': mode, 'pou_kinds': kinds, 'baseline': baseline,
                    'all_31_pous_and_interface': modified, 'generated_cil_verification': cil,
                    'type_error_rejected': wrong_type, 'renamed_parameter_rejected': wrong_parameter,
                    'invalid_variable_declaration_rejected': invalid_declaration, 'stale_hashes': stale,
                    'final_revision': restored, 'final_compile': restored_compile,
                    'final_preservation': final_validation, 'final_preservation_bytes': final_bytes,
                    'original_unchanged': True, 'aci_used': False, 'computer_use_used': False,
                    'plc_connected': False, 'plc_downloaded': False, 'deployable': False}
                save(output / 'result.json', result)
                progress.update(status='passed', result_path=str(output / 'result.json'))
                save(output / 'progress.json', progress)
                save(base / 'latest-result.json', {'status': 'passed', 'result_path': str(output / 'result.json')})
                print(json.dumps({'status': 'passed', 'pous': 31, 'fb_interfaces': True,
                                  'negative_cases': 3, 'result_path': str(output / 'result.json')}), flush=True)
    except BaseException:
        progress.update(status='failed', traceback=traceback.format_exc())
        save(output / 'progress.json', progress)
        save(base / 'latest-result.json', {'status': 'failed', 'progress_path': str(output / 'progress.json')})
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('cached', 'cold'), default='cached')
    asyncio.run(main(parser.parse_args().mode))
