param([Parameter(Mandatory)][string]$OutputDirectory,[switch]$Untagged)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputDirectory){throw 'Fresh oracle output directory required.'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
# Pure formatter/DTO metadata and MemoryStream only. No provider or online client.
foreach($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Arp.System.Rsc.Services')){[void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name+'.dll')))}
$flags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
function T($name){foreach($a in [AppDomain]::CurrentDomain.GetAssemblies()){$t=$a.GetType($name,$false);if($null -ne $t){return $t}};throw "Missing type $name"}
function N($type,$arguments){[Activator]::CreateInstance($type,$flags,$null,[object[]]$arguments,$null)}
$formatter=T 'Ade.CommonRemoting.Internal.RemotingFormatter'
$formatter4=T 'Ade.CommonRemoting.Internal.RemotingFormatter4'
$tagType=T 'Ade.CommonRemoting.Internal.TagInfo'
$marshalType=T 'Ade.CommonRemoting.AdeMarshalType'
$version=[Enum]::ToObject((T 'Ade.CommonRemoting.RemotingVersion'),4)
$streamType=T 'Ade.CommonRemoting.Internal.RemotingStream'
$headerType=T 'Ade.CommonRemoting.CommandHeader'
$script:vectors=@()
$tagging=-not [bool]$Untagged
$wireFlags=if($tagging){[byte]64}else{[byte]0}
function Stream($memory){$s=N $streamType @($memory,[object]::new(),$false);$streamType.GetProperty('RemotingVersion',$flags).SetValue($s,$version);$streamType.GetProperty('HasDataTagging',$flags).SetValue($s,$tagging);return $s}
function Call($method,$arguments){
 $properties=[Collections.Hashtable]::new();$inputs=[Collections.Generic.List[object]]::new();$outputs=[Collections.Generic.List[object]]::new()
 foreach($parameter in $method.GetParameters()){$attributes=[object[]]$parameter.GetCustomAttributes($false);$marshal=$formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attributes));if($parameter.IsOut){$outputs.Add($marshal)}else{$inputs.Add($marshal)}}
 if($method.ReturnType -ne [void]){$attributes=[object[]]$method.ReturnParameter.GetCustomAttributes($false);$outputs.Add($formatter.GetMethod('GetMarshalType',$flags).Invoke($null,[object[]]@(,$attributes)))}
 $properties['AdeInMarshalling']=[Array]::CreateInstance($marshalType,$inputs.Count);$properties['AdeOutMarshalling']=[Array]::CreateInstance($marshalType,$outputs.Count)
 for($i=0;$i -lt $inputs.Count;$i++){$properties['AdeInMarshalling'].SetValue($inputs[$i],$i)}
 for($i=0;$i -lt $outputs.Count;$i++){$properties['AdeOutMarshalling'].SetValue($outputs[$i],$i)}
 N (T 'Ade.CommonRemoting.Internal.CallMessage') @($method,[object[]]$arguments,$properties)
}
function Header($writer,$command){
 $header=[Activator]::CreateInstance($headerType)
 foreach($entry in @{Version=[byte]4;Flags=$wireFlags;CommandType=[Enum]::ToObject((T 'Ade.CommonRemoting.CommandType'),$command);ServiceHandle=[int16]41;MethodHandle=[int16]3;ServiceProviderHandle=[int16]5}.GetEnumerator()){$headerType.GetProperty($entry.Key).SetValue($header,$entry.Value)}
 $write=$headerType.GetMethods($flags)|Where-Object {$_.Name -eq 'Write' -and $_.GetParameters()[2].ParameterType -eq [bool]}
 [void]$write.Invoke($null,[object[]]@($header,$writer,$true))
}
function Value($writer,$type,$value,$marshal){$tag=N $tagType @($type,[Enum]::ToObject($marshalType,$marshal));[void]$formatter.GetMethod('SerializeValue',$flags).Invoke($null,[object[]]@($tag,$value,$writer,$version,$tagging,$false))}
function Save($name,$raw,$details){$file=Join-Path $OutputDirectory ($name+'.bin');[IO.File]::WriteAllBytes($file,$raw);$script:vectors+=@{name=$name;hex=[Convert]::ToHexString($raw).ToLowerInvariant();bytes=$raw.Length;sha256=(Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant();details=$details}}
$plc=T 'Arp.Plc.Domain.Services.IPlcManagerService';$method=$plc.GetMethod('Stop')
$id=($method.GetCustomAttributesData()|Where-Object {$_.AttributeType.Name -eq 'RscMethodAttribute'}).ConstructorArguments[0].Value
if($id -ne 3 -or $method.ReturnType -ne [void] -or $method.GetParameters().Count -ne 1 -or $method.GetParameters()[0].ParameterType -ne [bool]){throw 'Unexpected Stop contract'}
foreach($async in @($false,$true)){
 $call=Call $method @([bool]$async);$memory=[IO.MemoryStream]::new();$stream=Stream $memory
 [void]$formatter4.GetMethod('SerializeMessage',$flags).Invoke($null,[object[]]@([int16]$id,[int16]41,[int16]5,$call,$stream,$version))
 Save ('stop-'+$async.ToString().ToLowerInvariant()+'-request') $memory.ToArray() @{method='Stop';method_id=3;async=$async;actual_original_serialize_message=$true;method_token=('0x{0:x8}' -f $method.MetadataToken)}
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory);Header $writer 3;if($tagging){$writer.Write([byte]255)};$writer.Flush();$raw=$memory.ToArray();$memory.Position=0
 [void]$formatter4.GetMethod('DeserializeMessage',$flags).Invoke($null,[object[]]@((Stream $memory),$call,$version))
 if($memory.Position -ne $memory.Length){throw 'Stop reader left bytes'}
 Save ('stop-'+$async.ToString().ToLowerInvariant()+'-response') $raw @{method='Stop';method_id=3;original_reader_consumed_all=$true}
}
$cases=@(
 @{name='normal-empty';code=[uint32]5;message='';args=[object[]]@()},
 @{name='normal-ascii';code=[uint32]536870921;message='PUBLIC permission denied';args=[object[]]@()},
 @{name='normal-unicode';code=[uint32]2147483647;message=('PUBLIC '+[char]0x6d4b+[char]0x8bd5+' PLC');args=[object[]]@()},
 @{name='normal-string-argument';code=[uint32]5;message='PUBLIC {0}';args=[object[]]@('fixture')},
 @{name='normal-scalar-arguments';code=[uint32]5;message='PUBLIC {0}/{1}/{2}/{3}';args=[object[]]@([int32]-1,[uint32]::MaxValue,$true,[int64]::MinValue)},
 @{name='fatal-high-bit';code=[uint32]2147483648;message=$null;args=$null},
 @{name='fatal-max';code=[uint32]::MaxValue;message=$null;args=$null}
)
foreach($case in $cases){
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory);Header $writer 4
 Value $writer ([uint32]) $case.code 0
 $fatal=($case.code -band [uint32]2147483648) -ne 0
 if(-not $fatal){Value $writer ([string]) $case.message 1;Value $writer ([object[]]) $case.args 1;if($tagging){$writer.Write([byte]255)}}
 $writer.Flush();$raw=$memory.ToArray();$memory.Position=0;$call=Call $method @($true)
 $response=$formatter4.GetMethod('DeserializeMessage',$flags).Invoke($null,[object[]]@((Stream $memory),$call,$version))
 if($memory.Position -ne $memory.Length){throw "Error reader left bytes: $($case.name)"}
 Save ('error-'+$case.name) $raw @{code=$case.code;message=$case.message;arguments=$case.args;fatal=$fatal;original_reader_consumed_all=$true;actual_original_serialize_values=$true}
}
$metadata=@()
foreach($name in @('Arp.System.Commons.Services.Io.IFileService','Arp.System.Commons.Services.Io.IFileService2','Arp.System.Commons.Services.Io.IFileSystemInfoService')){
 $type=T $name
 foreach($m in $type.GetMethods()){$metadata+=@{type=$name;token=('0x{0:x8}' -f $m.MetadataToken);name=$m.Name;return_type=$m.ReturnType.FullName;parameters=@($m.GetParameters()|ForEach-Object{@{name=$_.Name;type=$_.ParameterType.FullName;is_out=$_.IsOut}});attributes=@($m.GetCustomAttributesData()|ForEach-Object{@{type=$_.AttributeType.FullName;values=@($_.ConstructorArguments|ForEach-Object{$_.Value})}})}}
}
@{scope='Pure original v4 values/SerializeMessage/DeserializeMessage on synthetic MemoryStream errors and Stop; no services invoked; see tagging field for selected profile';network_operations=0;aci_calls=0;engineer_started=$false;version=4;tagging=$tagging;vectors=$script:vectors;file_service_metadata=$metadata;assemblies=@('Arp.Base.Rsc.Commons.dll','Ade.CommonRemoting.Commons.dll','Arp.System.Rsc.Services.dll')|ForEach-Object{$assembly=[AppDomain]::CurrentDomain.GetAssemblies()|Where-Object Location -eq (Join-Path $install $_);@{name=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $install $_)).Hash.ToLowerInvariant();mvid=$assembly.ManifestModule.ModuleVersionId.ToString()}}}|ConvertTo-Json -Depth 16|Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8
Write-Output ('Verified {0} error/control vectors' -f $script:vectors.Count)
