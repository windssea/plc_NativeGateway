"""Build the explicit independent-ACI coverage snapshot from saved evidence.

No vendor assembly is loaded, and no code, network or compiler is invoked.
The decisions below are reviewed scope mappings, not implementation inference
from matching method names. Keep this generator and its produced data together.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'artifacts/aci-analysis/public-client-api-map.json'
STUBS = ROOT / 'artifacts/aci-analysis/server-project-stubs.json'
OUT = ROOT / 'src/plcnext_mcp/aci_contract/aci_2026_0_4.json'

FINAL = 'artifacts/final-audit-e2e/54086508fc07409f8571c1ee24540fcf/result.json'
CREATE = 'artifacts/codex-registration/1448b81b96bf4709a2f28178984c03e1/result.json'
VARIABLES = 'artifacts/cold-compile-mcp-e2e/1bd4056b36054ce2b13394d2fb622515/result.json'
DEVICE = 'artifacts/plc-connection-test/0f6663384a824799a35ef91255445cdf/result.json'
DEVICE_MCP = 'artifacts/controller-download-client-mcp/eb338eaa013b4a9aa7c69f64c9284144/05-device-readonly.json'
SOCKET_DOWNLOAD = 'artifacts/controller-download-client-mcp/eb338eaa013b4a9aa7c69f64c9284144/result.json'
TASKS = 'artifacts/task-configuration/result.json'
TAGGED = 'artifacts/independent-aci-mcp/88aca674c55b444cad806d12a69583d8/result.json'


def profile(status, domain, tools, scope, gap, acceptance, priority='P2', sources=(), evidence=()):
    return {'status': status, 'domain': domain, 'related_mcp_tools': list(tools),
            'scope': scope, 'gap': gap, 'acceptance_checks': list(acceptance),
            'priority': priority, 'independent_source': list(sources),
            'independent_evidence': list(evidence)}


MISSING = profile('missing', 'unclassified', (), 'No independent callable replacement declared.',
                  'The saved ACI contract is known; an independent implementation and validation are missing.',
                  ('Implement equivalent behavior without ACI.', 'Exercise success and meaningful failure cases using project copies.'))


def classify(interface, method):
    short = interface.rsplit('.', 1)[-1]
    name = method['name']
    if short in ('IApplicationControlManager', 'IApplicationInfo'):
        return profile('contract_only', 'application_metadata', ('server_capabilities',),
            'Independent backend reports its own capabilities and compiler environment; it does not create an ACI manager.',
            'ACI process, version and license-state identities have no exact native-backend counterparts.',
            ('Define independent session/capability metadata and explicit compatibility translations.',
             'Never report an ACI PID, license or IsAvailable value inferred from native functionality.'),
            sources=('src/plcnext_mcp/server.py',), evidence=(FINAL,))
    if short == 'IApplication':
        if name == 'NewProject':
            return profile('independent_verified_supported_scope', 'project_lifecycle', ('project_create',),
                'Create a new independent AXC F 2152/2026 standard-ST project from an installed template.',
                'ACI uses Empty template and can later configure other controllers; the verified independent profile is narrower.',
                ('Keep unique project/POU identities.', 'Reopen and cold-compile a new project from another MCP client.',
                 'Add alternate device/template profiles before claiming general template parity.'), 'P1',
                ('src/plcnext_mcp/lifecycle.py',), (CREATE,))
        if name in ('get_Project', 'get_IsProjectOpen', 'OpenProject'):
            return profile('partial', 'project_lifecycle', ('project_import_copy', 'project_inspect'),
                'Managed PCWEX copies are imported and selected by project_id, without an active Engineer document.',
                'No exact ACI active-project singleton or application-open lifecycle; supported project schema is bounded.',
                ('Exercise supported project import and corruption failures.', 'Define native project-session semantics for unsupported formats.'),
                'P1', ('src/plcnext_mcp/project.py',), (FINAL, CREATE))
        if name == 'get_BuildPath':
            return profile('partial', 'project_lifecycle', ('project_compile',),
                'Completed cold builds return an immutable job_directory and hashes.',
                'No global application BuildPath or Build/Prepare cache behavior compatibility.',
                ('Return paths bound to an exact source revision.', 'Do not expose stale artifacts as the current build.'),
                'P1', ('src/plcnext_mcp/expanded_compile.py',), (FINAL,))
        if name == 'get_CompilerOptions':
            return profile('missing', 'compiler_options', (),
                'Source cold build uses an explicitly limited profile; no generic compiler-options API is exposed.',
                'The three ACI application configuration options need independent project-level semantics.',
                ('Expose effective options and validated edits without changing global Engineer configuration.',), 'P2')
        return profile('contract_only', 'application_lifecycle', (),
            'Native MCP has no Engineer application to shut down or ProjectOpened event subscription to manage.',
            'An independent job/session lifecycle replaces these ACI-specific process operations; it is not API-identical.',
            ('Specify cancellation, progress, job completion and session-close behavior for the independent server.',), 'P2')
    if short == 'IApplicationCompilerOptions':
        return profile('missing', 'compiler_options', (),
            'Independent compiler profile has no callable equivalents for these application-wide option properties.',
            'AllowExtendedIdentifier, AllowWritingVarInputInFunction and UseDynamicSfcInfoArrays are not a complete compiler option model.',
            ('Verify each option through positive/negative source examples.', 'Bind effective options to build-input hashes.'), 'P2')
    if short == 'IProject':
        if name == 'Compile':
            return profile('partial', 'compilation', ('project_compile', 'project_check_st', 'project_generate_pcwe'),
                'Source cold IEC build for the checked AXC F 2152 single-resource/single-cyclic-task standard-ST profile; NativeGateway-only full PCWE generation.',
                'General Build/Prepare behavior, graphical/safety/multiple-resource devices and general hardware/HMI packaging are not equivalent.',
                ('Cold build without a project AST seed.', 'Retain diagnostics and reject unsupported source/hardware.',
                 'Verify complete target package and controller acceptance separately.'), 'P0',
                ('src/plcnext_mcp/expanded_compile.py', 'src/plcnext_mcp/pcwe_build.py'), (FINAL, VARIABLES))
        if name == 'Save':
            return profile('partial', 'project_lifecycle', ('project_patch_st', 'project_update_pous', 'project_change_fbs'),
                'Each accepted native edit atomically writes a new revision without overwriting the source.',
                'There is no shared unsaved Engineer state to flush; no ACI editor save semantics.',
                ('Reject stale hashes.', 'Preserve unrelated payloads and recover after failed writes.'), 'P1',
                ('src/plcnext_mcp/project.py', 'src/plcnext_mcp/lifecycle.py'), (FINAL, VARIABLES))
        if name == 'SaveAs':
            return profile('partial', 'project_lifecycle', ('project_import_copy',),
                'PCWEX copying into managed revisions is supported.',
                'No general SaveAs destination/overwrite flag or uncompressed PCWEF format conversion tool.',
                ('Support explicit format conversion with archive/payload integrity checks.', 'Refuse unintended destination overwrite.'), 'P1',
                ('src/plcnext_mcp/project.py',), (FINAL,))
        if name == 'get_Libraries':
            return profile('partial', 'libraries', ('project_compile',),
                'The compiler snapshots and resolves declared package references against the original project directory.',
                'No public native library-object list/load-state API; snapshot success is not ACI library acceptance/signature status.',
                ('Expose declared and resolved references separately.', 'Validate missing, conflicting and changed package snapshots.'), 'P1',
                ('src/plcnext_mcp/expanded_compile.py',), (FINAL,))
        if name in ('get_Controllers', 'get_ComponentCategories'):
            return profile('research_only', 'engineering_object_model', ('project_build_plan',),
                'Cold-build capability checks and package generation parse selected device and IEC identities.',
                'No general controller/component object model or complete hardware/safety tree exposed to MCP.',
                ('Expose stable source-bound identities.', 'Handle multiple controller/component kinds or reject them explicitly.'), 'P1',
                ('src/plcnext_mcp/expanded_compile.py', 'src/plcnext_mcp/runtime_configuration.py'), (FINAL,))
        if name == 'ImportProgramOrganizationUnits':
            return profile('partial', 'source_exchange', ('project_update_pous', 'project_change_fbs'),
                'The functional ST FB/body/interface edit use case works through native PCWEX editing.',
                'No PLCopen XML file/name-list import compatibility or generic POU kind import.',
                ('Implement format-aware selected POU import.', 'Validate names, identities, references and unsupported worksheet types.'), 'P1',
                ('src/plcnext_mcp/project.py', 'src/plcnext_mcp/lifecycle.py'), (FINAL, VARIABLES))
        if name in ('ImportDataTypeWorksheets', 'ImportIec61131_10', 'ExportIec61131_10', 'ImportAutomationML', 'ExportAutomationML'):
            return profile('missing', 'source_exchange', (),
                'Independent native PCWEX editing does not implement these interchange file formats.',
                'The historical official ACI roundtrip and optional ACI example still depend on licensed ACI and are not replacements.',
                ('Implement and version the relevant schemas.', 'Roundtrip identities, types, variables, instances and mappings.',
                 'Test conflict and partial-import failures on copies.'), 'P1')
        if name == 'Close':
            return profile('contract_only', 'project_lifecycle', (),
                'Native project records persist on disk without an active Engineer document.',
                'ACI Close/Closed semantics need a deliberate independent session translation, not an Engineer call.',
                ('Release only owned jobs/locks and preserve managed revisions.',), 'P2')
        return profile('missing', 'job_notifications', ('project_compile',),
            'Native compile returns a bounded job result after its subprocess completes.',
            'No general subscription API equivalent to ACI Closed/CompileFinished add/remove.',
            ('Provide correlated job events or polling receipts.', 'Separate accepted, completed, failed and outcome-unknown states.'), 'P1',
            ('src/plcnext_mcp/expanded_compile.py',), (FINAL,))
    if short in ('IIecType', 'IIecComponentCategory'):
        return profile('independent_verified_supported_scope', 'pou_model', ('project_inspect', 'project_read_pou'),
            'Read supported standard POU names/kinds and enumerate their registered identities from PCWEX.',
            'Library/device/safety/graphical POU categories and ACI object-handle semantics are outside this profile.',
            ('Check PROJECT.proj registration and POU metadata agree.', 'Do not hide orphan/duplicate POU identities.'), 'P1',
            ('src/plcnext_mcp/project.py',), (FINAL,))
    if short == 'IProgramOrganizationUnit':
        return profile('independent_verified_supported_scope', 'pou_model', ('project_delete_fb', 'project_change_fbs'),
            'Delete a standard ST FB with bounded reference protection and optional coordinated caller updates.',
            'Function/program/graphical/safety POU deletion and arbitrary symbolic references are not supported.',
            ('Reject deletion while bounded references remain.', 'Cold-compile the surviving project and compare unrelated payloads.'), 'P1',
            ('src/plcnext_mcp/lifecycle.py', 'src/plcnext_mcp/project.py'), (FINAL,))
    if short in ('IVariable', 'IVariableCollection', 'IVariableGroup'):
        if name == 'MoveToGroup' or short in ('IVariableCollection', 'IVariableGroup'):
            return profile('missing', 'variables', (),
                'No native named variable-group model or MoveToGroup command is exposed.',
                'Raw worksheet editing is not proof of ACI group/instance semantics.',
                ('Implement stable group membership and scope constraints.', 'Preserve initialization, pragmas and references.'), 'P1')
        return profile('partial', 'variables', ('project_read_pou', 'project_update_pous', 'project_find_references'),
            'Read and atomically edit source POU declaration worksheets and callers; verified locals and FB input changes.',
            'No dedicated per-instance variable object/setter model; retain/system/OPC/Proficloud/redundancy flags and global cross-reference edits are not fully verified.',
            ('Parse per-variable properties and scope.', 'Prove rename/type/default/flag changes by compile and mapping comparison.',
             'Reject stale source and update all affected references.'), 'P1',
            ('src/plcnext_mcp/project.py', 'src/plcnext_mcp/expanded_compile.py'), (VARIABLES, FINAL))
    if short in ('IInstance', 'IFunctionBlockInstance', 'IProgramInstance'):
        return profile('partial', 'instances_and_mappings', ('project_find_references', 'project_generate_pcwe'),
            'Bounded ST instance reference search and checked NativeGateway runtime-layout/mapping generation.',
            'No complete interactive task→program→nested-FB instance tree API; library and other device instance layouts remain bounded.',
            ('Expose source-bound instance paths and variable parents.', 'Validate full tree against compiler output and preserve maps after edits.'), 'P1',
            ('src/plcnext_mcp/project.py', 'src/plcnext_mcp/runtime_configuration.py', 'src/plcnext_mcp/runtime_layout.py'), (FINAL,))
    if short == 'ITask':
        if name == 'Delete':
            return profile('partial', 'tasks', ('project_inspect_tasks', 'project_change_cyclic_tasks'),
                'Source-bound 1..16 cyclic tasks can be added/deleted with unique program ownership, fresh IDs and runtime-map validation; two-task cold build/package/socket proof exists.',
                'General event/safety task models, arbitrary reassignment and actual target scheduling remain unverified or incomplete.',
                ('Implement instance/reference-aware removal and nonempty resource rules.',
                 'Cold-compile and compare the complete generated runtime schedule.'), 'P1',
                ('src/plcnext_mcp/task_configuration.py',), ('artifacts/multitask-native-e2e/f95519debbc04016b43c23c3500cd7b9/verification.json',))
        if name == 'get_EventName':
            return profile('research_only', 'tasks', ('project_inspect_tasks',),
                'The supported cyclic-task profile has no independently validated event-name semantics.',
                'Event tasks and their event mapping remain unsupported; raw source_attributes are not a typed replacement.',
                ('Define and validate event-task source, compiler and runtime configuration.',), 'P2',
                ('src/plcnext_mcp/task_configuration.py',), (TASKS,))
        return {**profile('partial' if name == 'get_Comment' else 'independent_verified_supported_scope',
            'tasks', ('project_inspect_tasks', 'project_update_cyclic_task'),
            'Read ESM v2 task name/type/program mapping and cyclic interval_ns/watchdog_ns/priority; actual 61-POU copy timing update, cold build and runtime ESM checks passed.',
            'No general safety/event/multiple-task model or physical scheduling proof. Native timing units are explicit nanoseconds; task comments are source attributes, not runtime values.',
            ('Preserve task/program identities and unrelated member payloads.',
             'Validate the source→compiler milliseconds→runtime nanoseconds unit conversions.',
             'Reject unsupported task types and stale revisions.'), 'P1',
            ('src/plcnext_mcp/task_configuration.py', 'src/plcnext_mcp/runtime_configuration.py'), (TASKS,)),
            'independent_improves_official_stub': name in ('get_Interval', 'get_Priority', 'get_Watchdog', 'get_Comment')}
    if short == 'IIecControllerPart':
        if name == 'get_Tasks':
            return profile('partial', 'tasks', ('project_inspect_tasks',),
                'Enumerate ESM v2 source tasks and their assigned program instances.',
                'No ACI online object handles or general safety/resource task model; editing is bounded to independently owned cyclic tasks.',
                ('Preserve source task/ESM identities.', 'Reject ambiguous or malformed source structures.'), 'P1',
                ('src/plcnext_mcp/task_configuration.py',), (TASKS,))
        return profile('research_only', 'engineering_object_model', ('project_compile', 'project_generate_pcwe'),
            'The supported compiler/resource profile rejects unsupported safety/resource models.',
            'No general IEC controller-part object model, variable collection, task collection or online-channel object API.',
            ('Expose actual source resource type and safety flags.', 'Keep source/online identities separate.'), 'P1',
            ('src/plcnext_mcp/expanded_compile.py',), (FINAL,))
    if short == 'IController':
        if name in ('ImportDataList', 'ExportDataList'):
            return profile('missing', 'instances_and_mappings', ('project_generate_pcwe',),
                'Existing DataList payload is preserved; checked NativeGateway maps are consumed by offline generation.',
                'Preservation and consumption do not implement the ACI CSV import/export views.',
                ('Implement versioned CSV views and conflict handling.', 'Verify physical/safety ports and HMI mappings separately.'), 'P1',
                ('src/plcnext_mcp/runtime_configuration.py',), (FINAL,))
        if name == 'Replace':
            return profile('missing', 'device_topology', (),
                'Independent editing/compilation validates one supported device profile.',
                'Replacing controller type requires compatible topology, libraries, execution target and mappings.',
                ('Validate replacement compatibility before editing.', 'Rebuild every affected configuration and image.'), 'P2')
        return profile('research_only', 'engineering_object_model', ('project_build_plan',),
            'Capability checks parse selected device identity and reject unknown profiles.',
            'No general controller/part enumeration API equivalent to the ACI object tree.',
            ('Expose controller identity from source, independent of compile success.', 'Handle absent/multiple controllers explicitly.'), 'P1',
            ('src/plcnext_mcp/expanded_compile.py',), (FINAL,))
    if short in ('ILibrary', 'ILibraryCollection'):
        if name in ('get_Name', 'get_Path'):
            return profile('partial', 'libraries', ('project_compile',),
                'Compiler job snapshots declared library names/paths and hashes for supported source compilation.',
                'No native library-object listing tool or full system/user/status compatibility.',
                ('Expose declared path and resolved package separately.', 'Detect package replacement after validation.'), 'P1',
                ('src/plcnext_mcp/expanded_compile.py',), (FINAL,))
        return profile('missing', 'libraries', (),
            'Existing package resolution does not implement ACI library management commands.',
            'Add/Accept/Remove/Replace and full load/signature/version-state behavior need independent implementation.',
            ('Preserve package identity/signature policy.', 'Reject removing referenced types and test version replacement conflicts.'), 'P1')
    if short == 'IMessage':
        return profile('partial', 'diagnostics', ('project_check_st', 'project_compile'),
            'Native parser/compiler reports syntax/semantic stages and diagnostics from actual compiler output.',
            'No exact ACI IMessage type/Guid identity or replay of all Engineer message-service warnings.',
            ('Expose severity, code, text and source location consistently.', 'Keep compiler error distinct from transport/host failure.'), 'P1',
            ('src/plcnext_mcp/headless.py', 'src/plcnext_mcp/expanded_compile.py'), (FINAL, VARIABLES))
    if short == 'IOnlineChannel':
        if name in ('Connect', 'Disconnect', 'GetControllerState'):
            return profile('partial', 'controller_readonly', ('controller_read_state',),
                'A real MCP invocation connects using pinned TLS/RSC, discovers service handles, reads PLC state and closes the bounded connection; verified at 192.168.0.8.',
                'No persistent ACI-style channel or credentials overload; simulation endpoints, other controller profiles and general endpoint behavior are unverified.',
                ('Keep bounded one-shot connect/read/disconnect and explicit profile validation.', 'Pin/verify target identity, negotiate flags and discover handles dynamically.',
                 'Guarantee the read-only request whitelist rejects file/configuration/control operations.'), 'P0',
                ('src/plcnext_mcp/controller_readonly.py',), (DEVICE_MCP, DEVICE))
        if name == 'Download':
            return profile('partial', 'controller_download', ('project_prepare_download_review',
                'project_test_controller_download', 'project_execute_controller_download'),
                'Independent pinned TCP/TLS client implements source-bound file writes, SHA-512 readback and Reset/Load; full 48-file flow verified against a local socket peer. The same client read the real PLC state. Separate human approval gates actual writes.',
                'Real PLC write permission, firmware/package acceptance, unlisted remote files and Full/OnlyChanges/IncludeSources parity remain unverified or incomplete.',
                ('Require exact version/target/effect confirmation before real writes.',
                 'Verify actual device transfer/load/failure behavior with no blind retries.',
                 'Retain exact package/endpoint binding, side-effect receipts and quarantine after uncertainty.'),
                'P0', ('src/plcnext_mcp/controller_transport.py', 'src/plcnext_mcp/controller_transfer.py',
                       'src/plcnext_mcp/controller_download_plan.py'), (SOCKET_DOWNLOAD,))
        if name in ('add_DownloadFinished', 'remove_DownloadFinished'):
            return profile('research_only', 'controller_download', ('project_download_plan', 'project_simulate_download'),
                'Offline memory-TLS binary simulation covers bounded untagged and tagged full-file transfer, readback, Reset and Load; the tagged profile was exercised through MCP with a fresh 61-POU build and 48-file package.',
                'No production real-controller transport or actual acceptance/run proof; OnlyChanges and IncludeSources are not independently equivalent.',
                ('Verify the bounded tagged write/error/stream schemas against actual controller behavior.', 'Verify target identity, permissions, exact package and per-file readback.',
                 'Confirm configuration-load completion and state; never promote an ACK or simulation to device success.'), 'P0',
                ('src/plcnext_mcp/binary_download.py', 'src/plcnext_mcp/binary_download_tagged.py',
                 'src/plcnext_mcp/rsc_tagged_codec.py', 'src/plcnext_mcp/download_simulation.py'), (FINAL, TAGGED))
        if name == 'Stop':
            return profile('partial', 'controller_control', ('project_prepare_controller_control', 'project_execute_controller_control', 'project_test_controller_control'),
                'Separate exact action review, independent one-use operator receipt, precise Stop-state polling and local TLS tests are implemented.',
                'Real output/hold behavior and complete ACI channel/session semantics remain unverified or incomplete.',
                ('Define explicit stop impact/approval and verify final state on the selected target.',),
                'P0', ('src/plcnext_mcp/controller_control.py',),
                ('artifacts/controller-control/verification.json',))
        if name == 'Start':
            return profile('partial', 'controller_control', ('project_prepare_controller_control', 'project_test_controller_control', 'project_prepare_recovery', 'project_execute_recovery'),
                'Exact original byte Start kinds and state polling; approved recovery uses its own continuously leased, verified Load evidence before Start.',
                'Device-loaded module hashes and complete ACI mode/session parity remain unverified or incomplete.',
                ('Reject a project name or manifest alone as loaded identity.', 'Keep ACK separate from terminal state and retain uncertain effects.'),
                'P0', ('src/plcnext_mcp/controller_control.py', 'src/plcnext_mcp/rsc_start_control.py'), ('artifacts/controller-control/verification.json',))
        if name == 'Restart':
            return profile('missing', 'controller_control', (),
                'No executable native MCP start/stop/restart entry exists.',
                'Static service method IDs are not wire codecs or device-effect validation.',
                ('Implement exact start modes/state transitions.', 'Use target-bound authorization and bounded state verification.',
                 'Report outcome unknown after interrupted mutations; do not blindly retry.'), 'P0')
        if name == 'Reset':
            return profile('partial', 'controller_control', ('project_simulate_download', 'project_execute_controller_download', 'project_execute_recovery'),
                'Reset is part of the guarded real TCP full-load client and verified local socket fixture, not a standalone device-control tool.',
                'No actual device-reset effect or standalone MCP Reset compatibility is verified.',
                ('Verify reset flags and completion states against actual service semantics.', 'Separate reset from load and restart.'), 'P0',
                ('src/plcnext_mcp/controller_transfer.py', 'src/plcnext_mcp/controller_transport.py'), (SOCKET_DOWNLOAD,))
        if name == 'ReadVariable':
            return profile('partial', 'controller_variables', ('project_inspect_runtime_symbols', 'project_prepare_runtime_read', 'project_read_runtime', 'project_test_runtime_read'),
                'Source/type-bounded scalar reads with per-item errors and boot/config guarded windows; 250-point local TLS proof.',
                'Arbitrary ACI types/session semantics, atomic snapshots and target runtime compatibility remain unverified or incomplete.',
                ('Resolve addresses from source-bound runtime metadata.', 'Handle IEC type width, arrays, structures, strings and stale builds.',
                 'Keep reads separate from writes and Force.'), 'P1',
                ('src/plcnext_mcp/runtime_monitor.py', 'src/plcnext_mcp/rsc_runtime_codec.py'), ('artifacts/runtime-monitor-research/verification.json',))
        if name == 'WriteVariable':
            return profile('partial', 'controller_variables', ('project_prepare_instrumented_fault', 'project_execute_instrumented_fault'),
                'Only fixed, boot/profile/source-bound lease fields of the explicit instrumented fault profile may be staged/read back and committed once, under separate approval.',
                'General variable writes, Force, arbitrary addresses/types and original restore-profile writes remain unsupported; real fault effects are unverified or incomplete.',
                ('Refuse fields outside the immutable profile whitelist.', 'Prove hard deadline/boot release independently of host survival; no blind commit retry.'), 'P1',
                ('src/plcnext_mcp/instrumented_fault.py', 'src/plcnext_mcp/rsc_fault_write_codec.py'), ('artifacts/fault-write-research/oracle-01/report.json', 'tests/test_instrumented_fault.py'))
        if name in ('GetDeviceInfoAttribute', 'GetDeviceStatusAttribute'):
            return profile('missing', 'controller_readonly', (),
                'The existing read-only probe obtains PLC state only.',
                'No independent generic Info/Status attribute service implementation.',
                ('Enumerate supported device attributes without guessing.', 'Preserve data types and distinguish unknown/unavailable from empty values.'), 'P1')
        return profile('research_only', 'connection_configuration', (),
            'Saved TCP/IP resource settings and the observed single-controller profile have been inspected.',
            'No native endpoint collection/selection/simulation model or safe project communication-setting editor.',
            ('Read/write the correct source topology properties.', 'Keep project endpoint edits separate from changing the live PLC network.'), 'P1',
            ('tools/plc_readonly_connection_probe.py',), (DEVICE,))
    if short in ('IConnectionEndpoint', 'ITcpIPConnectionEndpoint'):
        return profile('research_only', 'connection_configuration', (),
            'Saved communication settings are parsed by the fixed read-only diagnostic.',
            'No general endpoint API or IP/mask/gateway setter; altering saved properties is not live network configuration.',
            ('Validate addresses, endpoint kinds and redundant-controller topology.', 'Preserve unrelated project properties.'), 'P1',
            ('tools/plc_readonly_connection_probe.py',), (DEVICE,))
    if short in ('IHmiTag', 'IProcessDatum'):
        return profile('contract_only', 'hmi_and_process_data', ('project_generate_pcwe',),
            'The native package builder checks selected NativeGateway HMI/global bindings.',
            'These hidden ACI interfaces have no implementation in the inspected ClientImpl; generic physical-I/O/HMI editing remains unsupported.',
            ('Define independent HMI/process-data models and validate actual mappings.', 'Do not infer a working public ACI editor from these interface declarations.'), 'P2',
            ('src/plcnext_mcp/runtime_configuration.py', 'src/plcnext_mcp/hmi_output.py'), (FINAL,))
    if short in ('IProperty', 'IPropertyDictionary'):
        return profile('missing', 'device_properties', (),
            'Native payload preservation is not an arbitrary topology property dictionary.',
            'Typed property lookup/add/remove/clear and read-only/option constraints are not independently implemented.',
            ('Use schema-aware types and read-only metadata.', 'Validate property changes before writing and then read back.'), 'P2')
    if short.startswith('ISelectableDevice') or short in ('IDeviceParameter', 'IDeviceSetting'):
        return profile('missing', 'device_properties', (),
            'No native generic device parameter/setting/options/help API.',
            'Reconstructing labels, options and conversions needs matching device metadata; string patching is not equivalent.',
            ('Implement typed values, options and read-only checks.', 'Reject failed conversions instead of silently reporting success.'), 'P2')
    if short in ('IDeviceInstance', 'IDeviceInstanceCollection', 'IDeviceType', 'INetworkComponentCategory', 'INetworkControllerPart'):
        return profile('missing', 'device_topology', (),
            'Current package generation validates a fixed hardware/service profile but does not edit general device topology.',
            'Device-type discovery, compatible slot selection, create/insert/delete and protocol-specific configuration are absent.',
            ('Model parent/slot/type constraints.', 'Rebuild affected I/O/Profinet/service configuration.',
             'Prove edits against copies with meaningful rejection cases.'), 'P2')
    if short in ('IControllerType', 'IControllerPart', 'ICommonComponentCategory', 'IComponentCategory'):
        return profile('missing', 'engineering_object_model', (),
            'The independent backend does not expose the general installed controller/component metadata catalog.',
            'Article/vendor/product/revision/category/part metadata needs schema-aware catalog support.',
            ('Bind installed metadata to exact package identities.', 'Distinguish available catalog types from actual project instances.'), 'P2')
    return MISSING


def build():
    source = json.loads(SOURCE.read_text(encoding='utf-8-sig'))
    stubs = json.loads(STUBS.read_text(encoding='utf-8-sig'))
    direct = {item['signature'].split('::')[0].rsplit('.', 1)[-1] + '::' + item['signature'].split('::')[1].split('(')[0]: item
              for item in stubs['stubs'] if item['classification'] == 'unconditional_throw'}
    methods = []
    interfaces = []
    for item in source['types']:
        if not item['is_interface']:
            continue
        interfaces.append({'name': item['name'], 'token': item['token'],
                           'declared_method_count': len(item['methods']), 'inherits': item['interfaces']})
        for method in item['methods']:
            decision = dict(classify(item['name'], method))
            key = item['name'].rsplit('.', 1)[-1].removeprefix('I') + '::' + method['name']
            official = {'kind': 'declared_and_not_runtime_exercised_here'}
            if key in direct:
                stub = direct[key]
                official = {'kind': 'unconditional_NotImplementedException', 'server_token': stub['token']}
                if not decision.get('independent_improves_official_stub'):
                    decision.update(status='official_stub', related_mcp_tools=[],
                        scope='This property unconditionally throws in the inspected official ServerImpl.',
                        gap='There is no working official behavior to imitate; a useful independent value may still be implemented from source.',
                        acceptance_checks=['Return an explicit unsupported value until independent source semantics are validated.',
                                           'Do not include this getter in an all-or-nothing snapshot RPC.'])
            if item['name'].endswith('.IDeviceInstanceCollection') and method['name'] == 'GetNextFreePosition':
                official = {'kind': 'constant_placeholder', 'constant': 0, 'server_token': '0x06000190'}
                decision.update(status='official_stub', scope='Official implementation always returns 0.',
                    gap='A real free-slot search needs an independent topology model; copying the constant is not functional parity.')
            rpc_calls = []
            for client in method.get('client_implementations', []):
                for rpc in client['rpc_calls']:
                    simple = {'service': rpc['service'], 'method': rpc['method']}
                    if simple not in rpc_calls:
                        rpc_calls.append(simple)
            methods.append({'method_id': 'aci:' + method['token'], 'token': method['token'],
                            'interface': item['name'], 'method': method['name'], 'signature': method['signature'],
                            'official_behavior': official, 'official_rpc_anchors': rpc_calls,
                            'contract_evidence': {'path': str(SOURCE.relative_to(ROOT)).replace('\\', '/'),
                                                  'token': method['token']}, **decision})
    assert len(methods) == 201 and len(interfaces) == 56
    assert len({item['method_id'] for item in methods}) == 201
    result = {
        'schema': 'plcnext-aci-independent-coverage/v1', 'snapshot_date': '2026-10-26', 'implementation_version': '0.6.0',
        'contract_build': 'PLCnext Engineer 2026.0.4 / 9.0.373.0',
        'declared_method_count': 201, 'contract_identity': source['identity'],
        'contract_source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'status_definitions': {
            'independent_verified_supported_scope': 'Independent callable behavior has executed evidence in its explicit supported scope; broader ACI parity is not implied.',
            'partial': 'Related independent code/tools exist, but data model, behavior, format, device or profile coverage differs.',
            'research_only': 'Static/oracle/simulation/standalone probe evidence exists; no production-equivalent MCP behavior is verified.',
            'missing': 'No independent replacement for this behavior is implemented in this snapshot.',
            'official_stub': 'The inspected official method throws unconditionally or is a constant placeholder; not counted as implemented by copying the stub.',
            'contract_only': 'ACI-specific or hidden contract whose semantics require deliberate independent modeling; no exact native compatibility asserted.',
        },
        'dependency_boundary': {
            'native_editing_calls_aci': False, 'native_compilation_calls_aci': False,
            'installed_vendor_compiler_and_referenced_packages_required_for_build': True,
            'aci_reference_example_is_independent_replacement': False,
            'known_profile': 'AXC F 2152 / 2026, one standard-ST IEC resource and 1..16 independently owned cyclic tasks; full PCWE profile remains NativeGateway-specific',
        },
        'priorities': [
            {'priority': 'P0', 'scope': 'Source-bound complete build/package plus negotiated real-controller transport, target identity, authorization, verified load and operation outcomes.'},
            {'priority': 'P1', 'scope': 'General project/source interchange, task/instance/variable/mapping models, library lifecycle, diagnostics and online variable access.'},
            {'priority': 'P2', 'scope': 'Controller catalogs, topology/protocol/device property expansion, compiler options, HMI/process-data and lifecycle compatibility.'},
        ],
        'limitations': [
            'This snapshot inventories all 201 explicitly declared methods of 56 public interfaces; inherited .NET collection methods remain attached to interface inheritance, not inflated into new ACI methods.',
            'Method/status counts are workload categories, not an implementation completion percentage.',
            'The official gRPC schema has 193 RPCs; that count is not one-to-one with declared interface methods.',
            'No ACI execution, license modification, computer use or network access is performed by the coverage tools.',
            'Device probe and simulator evidence must not be described as production real-controller download validation.',
            'Statuses are a dated reviewed snapshot and must be updated alongside new independent code and verification receipts.',
        ], 'interfaces': interfaces, 'methods': methods,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'path': str(OUT), 'methods': len(methods), 'interfaces': len(interfaces),
                      'status_counts': Counter(item['status'] for item in methods)}))


if __name__ == '__main__':
    build()
