"""M12 public discovery and original-profile refusal. No PLC I/O."""
import asyncio,json,os,sys,tempfile
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    root=Path(__file__).resolve().parents[1];folder=root/'artifacts/audit-export-research';folder.mkdir(exist_ok=True)
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']=r'D:\PLCnext-MCP-Workspace'
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    async with stdio_client(params) as (r,w):
        async with ClientSession(r,w) as session:
            await session.initialize();tools=await session.list_tools()
            caps=await session.call_tool('server_capabilities',{})
            value=caps.structuredContent
            if value is None:value=json.loads('\n'.join(x.text for x in caps.content if x.type=='text'))
            assert value['version']=='0.6.5' and len(tools.tools)==79
            expected={'project_prepare_audit_export','project_inspect_audit_export','project_execute_audit_export','project_audit_export_status','project_cancel_audit_export'}
            assert expected<={t.name for t in tools.tools}
            args={'project_id':'f40a214f31ea4ec28b5d9fd39c77c5ee',
                'expected_project_sha256':'b585662abf3d86a1d0445d59e9ed4354723edebafd1f0fcb4b81647a7fe80d41',
                'package_job_id':'d8ffa5d9a23c46cba17ee31be144c889','address':'192.168.0.8',
                'expected_certificate_sha256':'3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863',
                'volatile_data_policy':'record_unknown_loss','audit_duration_seconds':10}
            response=await session.call_tool('project_prepare_recovery',args)
            if response.isError:raise RuntimeError(str(response.content))
            plan=response.structuredContent
            if plan is None:plan=json.loads('\n'.join(x.text for x in response.content if x.type=='text'))
            parent_check=await session.call_tool('project_inspect_recovery',{'project_id':args['project_id'],'plan_id':plan['plan_id'],'expected_plan_sha256':plan['plan_sha256']})
            assert not parent_check.isError
            child=plan['children']['audit']
            inspected=await session.call_tool('project_inspect_audit_export',{'project_id':args['project_id'],
                'plan_id':child['plan_id'],'expected_plan_sha256':child['plan_sha256']})
            assert not inspected.isError
            audit=inspected.structuredContent
            if audit is None:audit=json.loads('\n'.join(x.text for x in inspected.content if x.type=='text'))
            assert audit['policy']['parent_recovery_plan_id']==plan['plan_id']
            assert audit['policy']['boot_binding']=='observe_same_parent_start'
            report={'version':value['version'],'tool_count':len(tools.tools),
                'parent_plan':plan,'audit_plan':audit,'controller_connected':False,'authorization_issued':False}
            (folder/'public-start-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps({'version':value['version'],'tool_count':len(tools.tools),'parent_plan_id':plan['plan_id'],
                'child_plan_id':child['plan_id'],'parent_child_binding_verified':True,'controller_connected':False}))


if __name__=='__main__':asyncio.run(main())
