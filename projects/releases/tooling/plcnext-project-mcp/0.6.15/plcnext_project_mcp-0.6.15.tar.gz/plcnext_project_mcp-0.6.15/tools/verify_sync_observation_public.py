"""Prepare/inspect synchronous observation reconciliation with fresh READ ONLY PLC evidence. No archive/authorization."""
import asyncio,json,os,sys,tempfile,hashlib
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
async def main():
    root=Path(__file__).resolve().parents[1];folder=root/'artifacts/sync-observation-research';folder.mkdir(exist_ok=True)
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']='D:/PLCnext-MCP-Workspace'
    external=Path('D:/work/code/PLCnext-Engineer/output/mainline-accept-20261028/stable-current-runtime.json')
    args=dict(project_id='17ae4361baa846868b14775bf1de15ea',execution_id='6a0c9cb6865146a189538b80e2508bbe',
        expected_review_sha256='dc43ec1746a63e0a0e3abd62672cb9f2481fd3b36b9d5fb7ff5b638f4762fddb',
        expected_certificate_sha256='3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863',
        current_project_id='17ae4361baa846868b14775bf1de15ea',current_project_sha256='7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154',
        current_read_plan_id='1d480ec59dbb44bbb20c63996b8098a9',current_read_plan_sha256='a21ac2ca95fb704ce39315b9ed6658e54bbb4f7462707d3d6d7ec8fe2135a8dd',
        expected_boot_id='ng-d4f61b3085b97c5e3831983b-82',expected_configuration=dict(version=19,device_count=50,point_count=250,enabled=True),
        expected_configuration_sha256='bf6f827b4a321061bc7dc2f9275ff32bacc1b2db9d320a059136cdf75cd94c3b',
        external_evidence_path=str(external),external_evidence_sha256=hashlib.sha256(external.read_bytes()).hexdigest(),
        description='Historical public runtime receipt after synchronous startup observation failure; business ingestion acceptance remains external. Fresh read required.')
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    async with stdio_client(params) as (reader,writer):
        async with ClientSession(reader,writer) as session:
            await session.initialize()
            async def call(name,args):
                v=await session.call_tool(name,args)
                if v.isError:raise RuntimeError(str(v.content))
                return v.structuredContent or json.loads(''.join(x.text for x in v.content if x.type=='text'))
            tools=await session.list_tools();caps=await call('server_capabilities',{})
            assert caps['version']=='0.6.13' and len(tools.tools)==89
            schema=next(t.inputSchema for t in tools.tools if t.name=='project_prepare_stopped_recovery')
            assert schema['properties']['maximum_runtime_observations']['default']==12
            p=await call('project_prepare_sync_observation_reconciliation',args)
            checkargs=dict(project_id=args['project_id'],plan_id=p['plan_id'],expected_plan_sha256=p['plan_sha256'])
            checked=await call('project_inspect_lease_reconciliation',checkargs);assert checked['status']=='prepared'
            report=dict(version=caps['version'],tool_count=len(tools.tools),prepare_arguments=args,plan=p,inspect_arguments=checkargs,
                authorize_arguments=dict(project_id=args['project_id'],review_id=p['plan_id'],expected_review_sha256=p['plan_sha256'],kind='lease_reconciliation',reason='Archive exact synchronous observation failure lease after fresh boot82 Running configuration19 and all250 GOOD'),
                execute_arguments=checkargs,controller_mutations=False,authorization_issued=False,lease_archived=False)
            (folder/'public-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps(dict(version=caps['version'],tools=len(tools.tools),inspect_arguments=checkargs,observation=p['observation'],controller_mutations=False,lease_archived=False)))
if __name__=='__main__':asyncio.run(main())
