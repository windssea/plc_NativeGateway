param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $OutputDirectory){throw 'Fresh output directory required'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$install='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
foreach($name in @('Arp.Base.Rsc.Commons','Ade.CommonRemoting.Commons','Arp.System.Rsc.Services')){[void][Reflection.Assembly]::LoadFrom((Join-Path $install ($name+'.dll')))}
Add-Type -TypeDefinition @'
using System;
using System.IO;
public sealed class RscReadOracleNonSeekable : Stream {
 private readonly MemoryStream inner;
 private readonly int maxRead;
 public RscReadOracleNonSeekable(byte[] data, int maxRead) { inner = new MemoryStream(data); this.maxRead=maxRead; }
 public override bool CanRead => true;
 public override bool CanSeek => false;
 public override bool CanWrite => false;
 public override long Length => throw new NotSupportedException("PUBLIC synthetic nonseekable stream");
 public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
 public override int Read(byte[] b, int o, int c) => inner.Read(b,o,Math.Min(c,maxRead));
 public override void Flush() { }
 public override long Seek(long o, SeekOrigin s) => throw new NotSupportedException();
 public override void SetLength(long v) => throw new NotSupportedException();
 public override void Write(byte[] b, int o, int c) => throw new NotSupportedException();
 protected override void Dispose(bool d) { if(d)inner.Dispose();base.Dispose(d); }
}
'@
$flags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
function T($name){foreach($a in [AppDomain]::CurrentDomain.GetAssemblies()){$t=$a.GetType($name,$false);if($null -ne $t){return $t}};throw "Missing $name"}
function Tag($type){[Activator]::CreateInstance((T 'Ade.CommonRemoting.Internal.TagInfo'),$flags,$null,[object[]]@($type,[Enum]::ToObject((T 'Ade.CommonRemoting.AdeMarshalType'),2)),$null)}
$formatter=T 'Ade.CommonRemoting.Internal.RemotingFormatter';$version=[Enum]::ToObject((T 'Ade.CommonRemoting.RemotingVersion'),4)
$dtoType=T 'Arp.System.Commons.Services.Io.ReadFileData';$traitType=T 'Arp.System.Commons.Services.Io.TraitItem';$resultType=T 'Arp.System.Commons.Services.Io.FileSystemError'
$arrayType=$dtoType.MakeArrayType();$tag=Tag $arrayType
$script:results=@()
function Run($name,$value,$details,$valueTag=$tag){
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory)
 $record=@{name=$name;details=$details;serialize_succeeded=$false;deserialize_succeeded=$false}
 try{
  [void]$formatter.GetMethod('SerializeValue',$flags).Invoke($null,[object[]]@($valueTag,$value,$writer,$version,$true,$false));$writer.Flush();$raw=$memory.ToArray()
  $record.serialize_succeeded=$true;$record.hex=[Convert]::ToHexString($raw).ToLowerInvariant();$record.bytes=$raw.Length
  $path=Join-Path $OutputDirectory ($name+'.bin');[IO.File]::WriteAllBytes($path,$raw);$record.sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()
  $memory.Position=0;$reader=[IO.BinaryReader]::new($memory)
  $decoded=$formatter.GetMethod('DeserializeValue',$flags).Invoke($null,[object[]]@($valueTag,$reader,$version,$true,$false))
  $record.deserialize_succeeded=$true;$record.original_reader_consumed_all=($memory.Position -eq $memory.Length);$record.decoded_null=($null -eq $decoded)
  if($decoded -is [IO.Stream]){$buffer=[IO.MemoryStream]::new();$decoded.CopyTo($buffer);$record.decoded_data_bytes=$buffer.Length;$record.decoded_data_sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($buffer.ToArray())).ToLowerInvariant()}
  elseif($null -ne $decoded){
   $record.decoded_items=@($decoded|ForEach-Object{
    $row=$_;$traits=$dtoType.GetField('TraitItems').GetValue($row);$data=$dtoType.GetField('Data').GetValue($row)
    $item=@{result=[int]$dtoType.GetField('Result').GetValue($row);traits_null=($null -eq $traits);traits_count=if($null -eq $traits){$null}else{$traits.Length};data_null=($null -eq $data)}
    if($null -ne $data){$b=[IO.MemoryStream]::new();$data.CopyTo($b);$item.data_bytes=$b.Length;$item.data_sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($b.ToArray())).ToLowerInvariant()}
    $item
   })
  }
 }catch{
  $errorItem=$_.Exception;$chain=@();while($null -ne $errorItem){$chain+=@{type=$errorItem.GetType().FullName;message=$errorItem.Message};$errorItem=$errorItem.InnerException}
  $record.exception_chain=$chain
 }
 $script:results+=$record
}
function ReadRaw($name,$hint,$chunks,$truncate=0){
 $memory=[IO.MemoryStream]::new();$writer=[IO.BinaryWriter]::new($memory);$writer.Write([byte]34);$writer.Write([int]$hint)
 foreach($chunk in $chunks){$writer.Write([int]$chunk.Length);$writer.Write([byte[]]$chunk)}
 $writer.Write([int]-1);$writer.Flush();$raw=$memory.ToArray()
 if($truncate){$raw=$raw[0..($raw.Length-$truncate-1)]}
 $path=Join-Path $OutputDirectory ($name+'.bin');[IO.File]::WriteAllBytes($path,$raw)
 $record=@{name=$name;producer='Analyst-selected stream hint/chunks, consumed by original DeserializeValue; not claimed original writer output';details=@{hint=$hint;chunk_lengths=@($chunks|ForEach-Object{$_.Length});truncated_bytes=$truncate};hex=[Convert]::ToHexString($raw).ToLowerInvariant();bytes=$raw.Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();deserialize_succeeded=$false}
 try{
  $memory=[IO.MemoryStream]::new([byte[]]$raw);$reader=[IO.BinaryReader]::new($memory)
  $decoded=$formatter.GetMethod('DeserializeValue',$flags).Invoke($null,[object[]]@((Tag ([IO.Stream])),$reader,$version,$true,$false))
  $buffer=[IO.MemoryStream]::new();$decoded.CopyTo($buffer)
  $record.deserialize_succeeded=$true;$record.original_reader_consumed_all=($memory.Position -eq $memory.Length);$record.decoded_data_bytes=$buffer.Length;$record.decoded_data_sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($buffer.ToArray())).ToLowerInvariant()
 }catch{$errorItem=$_.Exception;$chain=@();while($null -ne $errorItem){$chain+=@{type=$errorItem.GetType().FullName;message=$errorItem.Message};$errorItem=$errorItem.InnerException};$record.exception_chain=$chain}
 $script:results+=$record
}
foreach($code in @(0,3,5)){
 foreach($traitsMode in @('null','empty')){
  foreach($dataMode in @('null','stream-null','empty-memory')){
   $dto=[Activator]::CreateInstance($dtoType);$dtoType.GetField('Result').SetValue($dto,[Enum]::ToObject($resultType,$code))
   $traits=if($traitsMode -eq 'null'){$null}else{,[Array]::CreateInstance($traitType,0)};$dtoType.GetField('TraitItems').SetValue($dto,$traits)
   $data=switch($dataMode){'null'{$null};'stream-null'{[IO.Stream]::Null};'empty-memory'{[IO.MemoryStream]::new()}}
   $dtoType.GetField('Data').SetValue($dto,$data);$array=[Array]::CreateInstance($dtoType,1);$array.SetValue($dto,0)
   Run ('read-'+$code+'-traits-'+$traitsMode+'-data-'+$dataMode) $array @{result=$code;traits=$traitsMode;data=$dataMode}
  }
 }
}
Run 'read-array-null' $null @{array='null'}
Run 'read-array-empty' ([Array]::CreateInstance($dtoType,0)) @{array='empty'}
$payload=[byte[]]::new(131089);for($i=0;$i -lt $payload.Length;$i++){$payload[$i]=[byte]($i%256)}
foreach($size in @(0,7,131089)){
 foreach($fragment in @(7,65536)){
  $data=[RscReadOracleNonSeekable]::new($payload[0..([Math]::Max(0,$size-1))],$fragment)
  if($size -eq 0){$data=[RscReadOracleNonSeekable]::new([byte[]]@(),$fragment)}
  Run ('nonseek-'+$size+'-fragment-'+$fragment) $data @{length=$size;max_read=$fragment;can_seek=$false} (Tag ([IO.Stream]))
 }
}
foreach($hint in @([int]0,[int]1,[int]7,[int]65536,[int]::MaxValue,[int]-1,[int]::MinValue)){
 ReadRaw ('reader-hint-'+$hint+'-chunk7') $hint @(,[byte[]]@(0,1,255,2,3,4,5))
}
ReadRaw 'reader-hint7-chunks2-3-2' 7 @([byte[]]@(0,1),[byte[]]@(255,2,3),[byte[]]@(4,5))
ReadRaw 'reader-hint65536-one-chunk131089' 65536 @(,$payload)
ReadRaw 'reader-hint0-zero-and-chunk7' 0 @([byte[]]@(),[byte[]]@(0,1,255,2,3,4,5))
ReadRaw 'reader-missing-end-marker' 7 @(,[byte[]]@(0,1,255,2,3,4,5)) 4
ReadRaw 'reader-truncated-chunk' 7 @(,[byte[]]@(0,1,255,2,3,4,5)) 8
@{schema='rsc-read-null-and-stream-oracle/v1';scope='Pure original SerializeValue/DeserializeValue with synthetic ReadFileData[] and nonseekable Memory-backed Stream; no service/network';network_operations=0;aci_calls=0;engineer_started=$false;version=4;tagging=$true;dto_is_value_type=$dtoType.IsValueType;results=$script:results;assemblies=@('Arp.Base.Rsc.Commons.dll','Ade.CommonRemoting.Commons.dll','Arp.System.Rsc.Services.dll')|ForEach-Object{$a=[AppDomain]::CurrentDomain.GetAssemblies()|Where-Object Location -eq (Join-Path $install $_);@{name=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $install $_)).Hash.ToLowerInvariant();mvid=$a.ManifestModule.ModuleVersionId.ToString()}}}|ConvertTo-Json -Depth 16|Set-Content -LiteralPath (Join-Path $OutputDirectory 'report.json') -Encoding utf8
Write-Output ('Recorded {0} null/stream cases' -f $script:results.Count)
