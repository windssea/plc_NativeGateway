"""Exercise offline deployment tools using the existing user-level Codex registration."""
import asyncio
from datetime import timedelta
import json
from pathlib import Path
import shutil
import subprocess
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]
PROJECT_ID = 'a431bdc32f2a4aa1812c94683db38395'
JOB_ID = '21ecd6da142147329a4053e1363a6adb'
SAMPLE = ROOT / 'artifacts/headless-research/cil-frontend/input/RES_23CA7F267545404C9FED5DC977A6399F/Configuration/Projects/PCWE'


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


async def main():
    run_id = uuid.uuid4().hex
    output = ROOT / 'artifacts/deployment-mcp-e2e' / run_id
    output.mkdir(parents=True)
    registration = json.loads(subprocess.check_output(
        [shutil.which('codex'), 'mcp', 'get', 'plcnext-project', '--json'], text=True, encoding='utf-8'))
    transport = registration['transport']
    assert registration['enabled'] and transport['type'] == 'stdio'
    workspace = Path(transport['env']['PLCNEXT_MCP_WORKSPACE'])
    client_directory = workspace / 'client-probes' / run_id
    client_directory.mkdir(parents=True)
    assert not client_directory.resolve().is_relative_to(ROOT.resolve())
    parameters = StdioServerParameters(command=transport['command'], args=transport['args'],
        env=transport['env'], cwd=str(client_directory))
    result = {'status': 'running', 'transport': 'MCP stdio', 'client_directory': str(client_directory),
        'registered_command_args_env_used_unchanged': True, 'controller_connected': False,
        'controller_downloaded': False, 'aci_used': False, 'computer_use_used': False,
        'deployable': False, 'checks': {}}

    async def call(client, name, arguments, *, error=False):
        response = await client.call_tool(name, arguments)
        if error:
            assert response.isError, name + ' should have failed'
            return {'rejected': True, 'message': '\n'.join(c.text for c in response.content if hasattr(c, 'text'))}
        assert not response.isError, (name, response.content)
        return response.structuredContent or json.loads(response.content[0].text)

    with (output / 'server.log').open('w', encoding='utf-8') as log:
        async with stdio_client(parameters, errlog=log) as (reader, writer):
            async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=60)) as client:
                await client.initialize()
                names = sorted(t.name for t in (await client.list_tools()).tools)
                assert {'project_deployment_plan', 'deployment_inspect_pcwe', 'deployment_stage_pcwe'} <= set(names)
                save(output / 'tools.json', names)
                capabilities = await call(client, 'server_capabilities', {})
                assert not capabilities['controller_write_access']
                save(output / 'capabilities.json', capabilities)
                current = await call(client, 'project_inspect', {'project_id': PROJECT_ID})
                plan = await call(client, 'project_deployment_plan', {'project_id': PROJECT_ID,
                    'expected_project_sha256': current['project_sha256'], 'build_job_id': JOB_ID})
                assert plan['pou_count'] == 61 and plan['compiled'] and not plan['deployable']
                assert plan['source_and_generated_hashes_verified'] and len(plan['missing_pcwe_files']) == 7
                assert len(plan['native_libraries'][0]['native_candidates']) == 2
                save(output / '61-pou-plan.json', plan)
                result['checks']['exact_61_pou_build_inspected'] = True
                inspected = await call(client, 'deployment_inspect_pcwe', {'source_path': str(SAMPLE)})
                assert inspected['listed_file_count'] == 47 and inspected['file_count'] == 48
                assert inspected['file_hashes_verified'] and inspected['overall_hash_status'] == 'unknown_order'
                save(output / 'pcwe-inspection.json', inspected)
                staged = await call(client, 'deployment_stage_pcwe', {'source_path': str(SAMPLE),
                    'expected_inventory_sha256': inspected['inventory_sha256']})
                assert staged['all_bytes_preserved'] and not staged['deployable']
                target = Path(staged['pcwe_path'])
                assert target.resolve().is_relative_to((workspace / 'deployment-staging').resolve())
                assert target.resolve() != SAMPLE.resolve()
                staged_check = await call(client, 'deployment_inspect_pcwe', {'source_path': str(target)})
                assert staged_check['inventory_sha256'] == inspected['inventory_sha256']
                save(output / 'pcwe-stage.json', staged)
                result['checks']['complete_pcwe_48_files_preserved'] = True
                raw_directory = workspace / PROJECT_ID / 'builds' / JOB_ID / 'generated'
                negative = await call(client, 'deployment_inspect_pcwe', {'source_path': str(raw_directory)}, error=True)
                save(output / 'raw-image-directory-rejected.json', negative)
                result['checks']['raw_cold_outputs_rejected_as_package'] = True
                negative = await call(client, 'deployment_stage_pcwe', {'source_path': str(SAMPLE),
                    'expected_inventory_sha256': '0' * 64}, error=True)
                save(output / 'stale-inventory-rejected.json', negative)
                result['checks']['stale_inventory_rejected'] = True
                again = await call(client, 'deployment_inspect_pcwe', {'source_path': str(SAMPLE)})
                assert again['inventory_sha256'] == inspected['inventory_sha256']
                result['checks']['baseline_unchanged'] = True
                result['tool_count'] = len(names)
                result['staged_pcwe_path'] = str(target)
    result['status'] = 'passed'
    save(output / 'result.json', result)
    print(json.dumps({'report': str(output / 'result.json'), **result}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())
