"""Exact current-site M11 acceptance via public MCP only; no device writes."""
import asyncio
from datetime import timedelta
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    root=Path(__file__).resolve().parents[1]
    folder=root/'artifacts/lease-reconciliation'/uuid.uuid4().hex;folder.mkdir(parents=True)
    env=os.environ.copy();env['PLCNEXT_MCP_WORKSPACE']=r'D:\PLCnext-MCP-Workspace'
    env['PLCNEXT_ENGINEER_DIRECTORY']=r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
    params=StdioServerParameters(command=sys.executable,args=['-I','-m','plcnext_mcp.server'],env=env,cwd=tempfile.gettempdir())
    calls=[]
    async with stdio_client(params) as (read,write):
        async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=180)) as session:
            await session.initialize()
            async def call(name,args):
                answer=await session.call_tool(name,args)
                value=answer.structuredContent
                if value is None:value=json.loads('\n'.join(x.text for x in answer.content if x.type=='text'))
                record={'tool':name,'arguments':args,'is_error':answer.isError,'result':value}
                (folder/(str(len(calls)).zfill(2)+'-'+name+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
                calls.append(name)
                if answer.isError:raise RuntimeError(str(value))
                return value
            cap=await call('server_capabilities',{});assert cap['version']=='0.6.2'
            inventory=await session.list_tools();assert len(inventory.tools)==72
            plan=await call('project_prepare_lease_reconciliation',{
                'project_id':'17ae4361baa846868b14775bf1de15ea',
                'operation_id':'bef5c48bfd8f4a3a8cfb1cbc4cdb3eec',
                'expected_review_sha256':'14d19c91be2b65f036b276293c017e7636fbf1bebee41c25b10f87dee7df9f61',
                'expected_certificate_sha256':'3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863'})
            args={'project_id':plan['project_id'],'plan_id':plan['plan_id'],'expected_plan_sha256':plan['plan_sha256']}
            await call('project_inspect_lease_reconciliation',args)
            await call('project_authorize_controller_operation',{'project_id':plan['project_id'],
                'review_id':plan['plan_id'],'expected_review_sha256':plan['plan_sha256'],
                'kind':'lease_reconciliation','reason':'User requests M11 implementation and controlled reconciliation of completed recovery. Exact old owner, journal and result verified; fresh Running/configuration/GOOD observation required. No PLC writes.'})
            result=await call('project_execute_lease_reconciliation',args)
            assert result['status']=='reconciled' and result['controller_changed'] is False
            await call('project_inspect_lease_reconciliation',args)
            summary={'status':'reconciled','version':cap['version'],'tool_count':len(inventory.tools),'plan':args,
                'archive_path':result['archive_path'],'old_evidence':result['evidence'],
                'observation':result['observation'],'controller_changed':False,'calls':calls}
            (folder/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps({'status':'reconciled','report_path':str(folder/'result.json')},ensure_ascii=False))

if __name__=='__main__':asyncio.run(main())
