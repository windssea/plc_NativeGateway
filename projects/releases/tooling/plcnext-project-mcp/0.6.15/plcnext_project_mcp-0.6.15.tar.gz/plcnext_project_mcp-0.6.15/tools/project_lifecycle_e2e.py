"""Real stdio MCP lifecycle regression. Offline files/compilation only; no PLC API."""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback
import uuid
import zipfile

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def members(path):
    with zipfile.ZipFile(path) as archive:
        return {i.filename: archive.read(i) for i in archive.infolist()}


def add_var(text, declaration):
    match = re.search(r'^VAR[ \t]*(?:\r?\n|\r)', text, re.M)
    if match:
        return text[:match.end()] + declaration + '\n' + text[match.end():]
    return text + '\nVAR\n' + declaration + '\nEND_VAR\n'


def inspect_fb_cil(report, output, pou_name, constant):
    """Read generated metadata/IL only; never load or run the PLC assembly."""
    install = os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')
    script = output / 'inspect-fb-cil.ps1'
    script.write_text(r'''
param([string]$Install,[string]$Assembly,[string]$Output)
$ErrorActionPreference='Stop'
[void][Reflection.Assembly]::LoadFrom((Join-Path $Install 'Mono.Cecil.dll'))
$module=[Mono.Cecil.ModuleDefinition]::ReadModule($Assembly)
try {
 $fields=@($module.Types | ForEach-Object {$_.Fields | ForEach-Object {
  [ordered]@{name=$_.Name;type=$_.FieldType.FullName}
 }})
 $constants=@($module.Types | ForEach-Object {$_.Methods | Where-Object HasBody | ForEach-Object {
  $_.Body.Instructions | Where-Object {$_.OpCode.Code.ToString() -eq 'Ldc_I4'} | ForEach-Object {[int]$_.Operand}
 }})
 [ordered]@{target_code_executed=$false;fields=$fields;integer_constants=$constants} |
  ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Output -Encoding utf8
} finally {$module.Dispose()}
''', encoding='utf-8')
    target = Path(report['job_directory']) / 'generated' / (pou_name + '.dll')
    result_path = output / (pou_name + '-cil.json')
    run = subprocess.run([shutil.which('pwsh'), '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(script),
        '-Install', install, '-Assembly', str(target), '-Output', str(result_path)],
        capture_output=True, timeout=30, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    assert run.returncode == 0, run.stderr.decode(errors='replace')
    result = json.loads(result_path.read_text(encoding='utf-8-sig'))
    assert constant in result['integer_constants'], result
    assert any(f['name'].casefold() == 'value' and f['type'] == 'System.UInt16' for f in result['fields']), result
    assert any(f['name'].casefold() == 'enable' and f['type'] == 'System.Boolean' for f in result['fields']), result
    return {'passed': True, 'target_code_executed': False, 'constant': constant, 'evidence_path': str(result_path)}


async def main():
    output = ROOT / 'artifacts/project-lifecycle-e2e' / uuid.uuid4().hex
    output.mkdir(parents=True)
    source_sha = digest(FROZEN)
    results = {'status': 'running', 'transport': 'MCP stdio', 'run_directory': str(output),
               'aci_used': False, 'computer_use_used': False, 'plc_connected': False,
               'plc_downloaded': False, 'deployable': False, 'checks': {}}
    save(output / 'progress.json', results)
    print(json.dumps({'run_directory': str(output)}), flush=True)
    env = dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(output / 'workspace'),
               PLCNEXT_NATIVEGATEWAY_SEED=str(output / 'no-seed-exists'))
    parameters = StdioServerParameters(command=sys.executable, args=['-I', '-m', 'plcnext_mcp.server'], env=env)
    try:
        async with stdio_client(parameters) as (reader, writer):
            async with ClientSession(reader, writer) as client:
                await client.initialize()

                async def call(name, arguments):
                    response = await client.call_tool(name, arguments)
                    if response.isError:
                        raise AssertionError(f'{name}: {response.content}')
                    return response.structuredContent or json.loads(response.content[0].text)

                async def rejected(label, name, arguments):
                    response = await client.call_tool(name, arguments)
                    assert response.isError, (label, response)
                    value = {'rejected': True, 'message': [c.text for c in response.content if c.type == 'text']}
                    results['checks'][label] = value
                    return value

                async def read(pid, name='Main'):
                    return await call('project_read_pou', {'project_id': pid, 'pou_name': name})

                async def compile_now(pid, label):
                    current = await call('project_inspect', {'project_id': pid})
                    report = await call('project_compile', {'project_id': pid,
                        'expected_project_sha256': current['project_sha256']})
                    save(output / (label + '.json'), report)
                    assert report['compiled'], {'status': report['status'], 'report_path': report['report_path'],
                                                'errors': report.get('host', {}).get('errors', [])}
                    assert report['backend_exit_code'] == 0
                    assert not report['ast_seed_used'] and not report['cache_assisted']
                    assert not report['deployable'] and not report['controller_connected']
                    job = Path(report['job_directory'])
                    assert not (job / 'input/LastBuild.ast').exists()
                    assert report['host']['pous_reparsed'] == len(current['pous'])
                    results['checks'][label] = {'status': report['status'], 'project_id': pid,
                        'pou_count': len(current['pous']), 'resource_name': report['host']['resource_name'],
                        'image_sha256': report['image_sha256'], 'report_path': str(output / (label + '.json'))}
                    save(output / 'progress.json', results)
                    print(json.dumps({'test': label, **results['checks'][label]}), flush=True)
                    return report

                tools = {t.name for t in (await client.list_tools()).tools}
                assert {'project_create', 'project_add_fb', 'project_delete_fb', 'project_change_fbs', 'project_compile'} <= tools
                save(output / 'capabilities.json', await call('server_capabilities', {}))

                created = await call('project_create', {'name': 'OfflinePlantAlpha'})
                save(output / '01-created.json', created)
                pid = created['project_id']
                before = members(created['project_path'])
                original_main = await read(pid)
                assert original_main['kind'] == 'Program'
                first = await compile_now(pid, '02-new-project-baseline')

                added = await call('project_add_fb', {'project_id': pid,
                    'expected_project_sha256': created['project_sha256'], 'pou_name': 'PumpGate',
                    'code': 'IF Enable THEN Value := UINT#12345; ELSE Value := UINT#0; END_IF;\n',
                    'variables': 'VAR_INPUT\n Enable : BOOL;\nEND_VAR\nVAR_OUTPUT\n Value : UINT;\nEND_VAR\n'})
                save(output / '03-added-fb.json', added)
                pump = await read(pid, 'PumpGate')
                assert pump['id'] != original_main['id']
                assert not (set(pump['worksheet_ids'].values()) & set(original_main['worksheet_ids'].values()))
                await rejected('duplicate_casefold', 'project_add_fb', {'project_id': pid,
                    'expected_project_sha256': added['project_sha256'], 'pou_name': 'pumpgate'})

                current_main = await read(pid)
                caller_vars = add_var(current_main['variables'], ' gate : PumpGate;')
                caller_code = current_main['code'] + '\ngate(Enable := TRUE);\n'
                updated = await call('project_change_fbs', {'project_id': pid,
                    'expected_project_sha256': added['project_sha256'],
                    'add_fbs': [{'pou_name': 'UnusedBlock', 'code': '', 'variables': 'VAR\nEND_VAR\n'}],
                    'updates': [{'pou_name': 'Main', 'expected_code_sha256': current_main['code_sha256'],
                        'expected_variables_sha256': current_main['variables_sha256'],
                        'code': caller_code, 'variables': caller_vars}]})
                save(output / '04-atomic-add-caller.json', updated)
                second = await compile_now(pid, '05-added-fbs-with-caller')
                results['checks']['new_fb_fields_and_code_in_cil'] = inspect_fb_cil(second, output, 'PumpGate', 12345)
                assert Path(second['image_path']).name != 'RES_23CA7F267545404C9FED5DC977A6399F.img'
                assert 'PumpGate.dll' in {p['name'] for p in second['generated_files']}
                assert 'UnusedBlock.dll' not in {p['name'] for p in second['generated_files']}
                assert any(m['type_id'] == 'SEM2005' and 'UnusedBlock' in m['format_parameters']
                           for m in second['host']['semantic']['messages'])
                results['checks']['unused_fb_diagnosed_and_not_emitted'] = True
                main_for_error = await read(pid)
                bad = await call('project_patch_st', {'project_id': pid, 'pou_name': 'Main',
                    'expected_project_sha256': main_for_error['project_sha256'],
                    'expected_code_sha256': main_for_error['code_sha256'],
                    'old_text': 'Enable := TRUE', 'new_text': 'Enable := UINT#42'})
                negative = await call('project_compile', {'project_id': pid,
                    'expected_project_sha256': bad['project_sha256']})
                save(output / '05-new-fb-type-error.json', negative)
                assert not negative['compiled'] and negative['status'] == 'semantic_failed', negative
                assert 'backend_exit_code' not in negative
                assert not list(Path(negative['job_directory']).rglob('*.img'))
                assert any(m['type_id'] == 'SEM1117' for m in negative['host']['semantic']['messages'])
                results['checks']['new_fb_type_error_stops_before_native_backend'] = True
                main_for_restore = await read(pid)
                updated = await call('project_patch_st', {'project_id': pid, 'pou_name': 'Main',
                    'expected_project_sha256': main_for_restore['project_sha256'],
                    'expected_code_sha256': main_for_restore['code_sha256'],
                    'old_text': 'Enable := UINT#42', 'new_text': 'Enable := TRUE'})
                await rejected('delete_referenced_fb', 'project_delete_fb', {'project_id': pid,
                    'expected_project_sha256': updated['project_sha256'], 'pou_name': 'PumpGate'})
                assert (await read(pid))['project_sha256'] == updated['project_sha256']
                await rejected('stale_structure_hash', 'project_delete_fb', {'project_id': pid,
                    'expected_project_sha256': created['project_sha256'], 'pou_name': 'UnusedBlock'})
                validation = await call('project_validate', {'project_id': pid})
                assert validation['preservation_passed'], validation
                save(output / '06-validation-added.json', validation)
                current = members(updated['project_path'])
                protected = [n for n in before if n.endswith(('DataList.dl', 'EsmConfiguration.esmc', 'IOConfiguration.ioc', 'Metadata.meta'))]
                assert all(current[n] == before[n] for n in protected)
                results['checks']['existing_ids_and_mappings_preserved'] = {'members_checked': len(protected), 'passed': True}

                main_now = await read(pid)
                deleted = await call('project_change_fbs', {'project_id': pid,
                    'expected_project_sha256': main_now['project_sha256'], 'delete_fbs': ['PumpGate', 'UnusedBlock'],
                    'updates': [{'pou_name': 'Main', 'expected_code_sha256': main_now['code_sha256'],
                        'expected_variables_sha256': main_now['variables_sha256'],
                        'code': original_main['code'], 'variables': original_main['variables']}]})
                save(output / '07-atomic-delete-caller.json', deleted)
                third = await compile_now(pid, '08-after-delete')
                assert not {'PumpGate.dll', 'UnusedBlock.dll'} & {p['name'] for p in third['generated_files']}
                assert (await call('project_validate', {'project_id': pid}))['preservation_passed']
                reimported = await call('project_import_copy', {'source_path': deleted['project_path']})
                assert reimported['project_id'] != pid
                await compile_now(reimported['project_id'], '09-independent-reimport')

                created_b = await call('project_create', {'name': 'OfflinePlantBeta'})
                save(output / '10-second-project.json', created_b)
                fourth = await compile_now(created_b['project_id'], '11-second-new-project')
                assert first['host']['resource_name'] != fourth['host']['resource_name'], 'New projects should receive independent resource IDs.'

                imported = await call('project_import_copy', {'source_path': str(FROZEN)})
                npid = imported['project_id']
                original = members(imported['project_path'])
                ng_added = await call('project_add_fb', {'project_id': npid,
                    'expected_project_sha256': imported['project_sha256'], 'pou_name': 'IndependentCounter',
                    'code': 'Count := UINT#23456;\n', 'variables': 'VAR_OUTPUT\n Count : UINT;\nEND_VAR\n'})
                await compile_now(npid, '12-nativegateway-added-32-pous')
                ng_deleted = await call('project_delete_fb', {'project_id': npid,
                    'expected_project_sha256': ng_added['project_sha256'], 'pou_name': 'IndependentCounter'})
                await compile_now(npid, '13-nativegateway-deleted-31-pous')
                final = members(ng_deleted['project_path'])
                assert set(final) == set(original)
                structural = {'PROJECT/PROJECT.proj', '[Content_Types].xml'}
                assert all(final[n] == original[n] for n in original if n not in structural)
                results['checks']['nativegateway_structural_members_changed'] = [n for n in sorted(structural)
                    if final[n] != original[n]]
                results['checks']['nativegateway_unrelated_payloads_preserved'] = True
                assert (await call('project_validate', {'project_id': npid}))['preservation_passed']
                assert digest(FROZEN) == source_sha
                results.update(status='passed', original_nativegateway_sha256=source_sha,
                    original_unchanged=True, project_ids=[pid, reimported['project_id'], created_b['project_id'], npid])
                save(output / 'result.json', results)
                save(output / 'progress.json', results)
                save(output.parent / 'latest-result.json', {'status': 'passed', 'result_path': str(output / 'result.json')})
                print(json.dumps({'status': 'passed', 'result_path': str(output / 'result.json')}), flush=True)
    except BaseException:
        results.update(status='failed', traceback=traceback.format_exc())
        save(output / 'progress.json', results)
        raise


if __name__ == '__main__':
    asyncio.run(main())
