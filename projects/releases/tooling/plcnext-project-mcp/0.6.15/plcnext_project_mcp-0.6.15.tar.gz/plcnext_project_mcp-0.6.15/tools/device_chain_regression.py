"""Relevant offline/owned-loopback regressions; no real PLC targets."""
import argparse,json,pathlib,time,unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
PATTERNS=['test_device_profiles.py','test_expanded_compile.py','test_pcwe_build.py','test_pcwe_native.py',
          'test_pcwe_auxiliary.py','test_runtime_configuration.py','test_runtime_layout.py',
          'test_hmi_support.py','test_hmi_output.py','test_task_configuration.py',
          'test_releases.py','test_download_simulation.py','test_controller_download_plan.py','test_controller_recovery.py']

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=pathlib.Path,required=True)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True);rows=[]
    for pattern in PATTERNS:
        suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern=pattern)
        started=time.monotonic()
        with (args.output/(pattern.removesuffix('.py')+'.log')).open('w',encoding='utf-8') as stream:
            result=unittest.TextTestRunner(stream=stream,verbosity=1).run(suite)
        row={'pattern':pattern,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
             'skipped':len(result.skipped),'passed':result.wasSuccessful() and result.testsRun>0,'seconds':round(time.monotonic()-started,3)}
        rows.append(row);print(json.dumps(row),flush=True)
    passed=all(r['passed'] for r in rows)
    (args.output/'summary.json').write_text(json.dumps({'passed':passed,'suites':rows,
        'total_tests':sum(r['tests'] for r in rows),'controller_access':False},indent=2)+'\n',encoding='utf-8')
    raise SystemExit(0 if passed else 1)
