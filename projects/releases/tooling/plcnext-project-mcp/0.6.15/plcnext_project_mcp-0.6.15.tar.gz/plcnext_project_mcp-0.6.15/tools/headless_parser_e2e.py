"""Real MCP tests: installed ST parser accepts source and rejects a new syntax error."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    root = Path(__file__).resolve().parents[1]
    output = root / 'artifacts' / 'headless-mcp-e2e'
    output.mkdir(parents=True, exist_ok=True)
    source = root / 'artifacts' / 'aci-poc' / 'NativeGateway.frozen.pcwex'
    original_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    environment = dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(output / 'workspace'))
    parameters = StdioServerParameters(command=sys.executable,
                                       args=['-m', 'plcnext_mcp.server'], env=environment)
    async with stdio_client(parameters) as (reader, writer):
        async with ClientSession(reader, writer) as client:
            await client.initialize()

            async def call(name, arguments):
                result = await client.call_tool(name, arguments)
                if result.isError:
                    raise RuntimeError(str(result.content))
                return result.structuredContent or json.loads(result.content[0].text)

            capabilities = await call('server_capabilities', {})
            assert capabilities['headless_st_syntax_check']['available']
            imported = await call('project_import_copy', {'source_path': str(source)})
            args = {'project_id': imported['project_id'], 'pou_name': 'NG_ReadAck'}
            valid = await call('project_check_st', args)
            assert valid['syntax_passed'] and valid['errors'] == 0
            pou = await call('project_read_pou', args)
            original_code = pou['code']
            await call('project_patch_st', args | {
                'expected_project_sha256': pou['project_sha256'], 'expected_code_sha256': pou['code_sha256'],
                'old_text': original_code, 'new_text': original_code + '\nIF THEN END_IF;\n'})
            invalid = await call('project_check_st', args)
            assert not invalid['syntax_passed'] and invalid['errors'] > 0 and invalid['messages']
            pou = await call('project_read_pou', args)
            await call('project_patch_st', args | {
                'expected_project_sha256': pou['project_sha256'], 'expected_code_sha256': pou['code_sha256'],
                'old_text': pou['code'], 'new_text': original_code + '\nUndefinedSyntaxProbeVariable := TRUE;\n'})
            undefined = await call('project_check_st', args)
            assert undefined['syntax_passed'], 'This syntax-only parser unexpectedly resolved symbols'
            assert valid['project_sha256'] != invalid['project_sha256'] != undefined['project_sha256']
            assert all(not r['compiled'] and not r['aci_used'] and not r['computer_use_used']
                       for r in (valid, invalid, undefined))
            assert hashlib.sha256(source.read_bytes()).hexdigest() == original_hash
            # Restore the final managed revision to the valid source after negative checks.
            pou = await call('project_read_pou', args)
            restored = await call('project_patch_st', args | {
                'expected_project_sha256': pou['project_sha256'], 'expected_code_sha256': pou['code_sha256'],
                'old_text': pou['code'], 'new_text': original_code})
            result = {'status': 'passed', 'transport': 'MCP stdio',
                      'tool': 'project_check_st', 'original_source_sha256': original_hash,
                      'valid': valid, 'invalid_syntax': invalid, 'undefined_symbol': undefined,
                      'restored_valid_revision': restored,
                      'whole_project_compiled': False, 'plc_connected': False, 'plc_downloaded': False}
            (output / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(json.dumps({'status': 'passed', 'valid_errors': valid['errors'],
                              'invalid_syntax_errors': invalid['errors'],
                              'undefined_symbol_syntax_passed': undefined['syntax_passed'],
                              'whole_project_compiled': False}))


if __name__ == '__main__':
    asyncio.run(main())
