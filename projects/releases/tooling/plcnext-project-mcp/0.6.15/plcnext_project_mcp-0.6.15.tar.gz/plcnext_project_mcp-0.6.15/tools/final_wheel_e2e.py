"""Run with the freshly installed wheel interpreter and no source-tree imports."""
import asyncio
from datetime import timedelta
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import plcnext_mcp

ROOT = Path(__file__).resolve().parents[1]
SOURCE = 'D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex'


async def main():
    output = ROOT / 'artifacts/final-audit-wheel' / uuid.uuid4().hex
    output.mkdir(parents=True)
    workspace = output / 'workspace'
    foreign = output / 'foreign-cwd'
    foreign.mkdir()
    module = Path(plcnext_mcp.__file__).resolve()
    assert not module.is_relative_to(ROOT / 'src') and 'site-packages' in str(module)
    assert importlib.metadata.version('plcnext-project-mcp') == '0.3.0'
    package = module.parent
    for relative in ('compile_host/ColdProjectBuilder.cs', 'compile_host/Invoke-FinalizeRuntime.ps1',
                     'parser_host/HeadlessParserProbe.cs', 'hmi_host/HmiOutputProbe.cs',
                     'simulation_tls/root-ca.pem', 'simulation_tls/server-public-test-key.pem'):
        assert (package / relative).is_file(), relative
    params = StdioServerParameters(command=sys.executable, args=['-I', '-m', 'plcnext_mcp.server'],
        env=dict(os.environ, PLCNEXT_MCP_WORKSPACE=str(workspace)), cwd=str(foreign))
    summary = {'status': 'running', 'installed_version': '0.3.0', 'package_module': str(module),
        'source_tree_import_used': False, 'controller_connected': False, 'controller_downloaded': False}

    async def call(client, name, args, label):
        response = await client.call_tool(name, args)
        assert not response.isError, (name, response.content)
        value = response.structuredContent or json.loads(response.content[0].text)
        (output / (label + '.json')).write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
        return value

    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(params, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=180)) as client:
                    await client.initialize()
                    assert len((await client.list_tools()).tools) == 25
                    copied = await call(client, 'project_import_copy', {'source_path': SOURCE}, '01-import')
                    args = {'project_id': copied['project_id'], 'expected_project_sha256': copied['project_sha256']}
                    syntax = await call(client, 'project_check_st', {'project_id': copied['project_id'], 'pou_name': 'NG_ReadAck'}, '02-syntax')
                    assert syntax['syntax_passed']
                    cold = await call(client, 'project_compile', args, '03-cold')
                    assert cold['compiled'] and cold['host']['pous_reparsed'] == 61 and not cold['ast_seed_used']
                    pcwe = await call(client, 'project_generate_pcwe', args | {'build_job_id': cold['job_id']}, '04-pcwe')
                    assert pcwe['package_complete'] and pcwe['file_count'] == 48
                    sim = await call(client, 'project_simulate_download', args | {'package_job_id': pcwe['package_job_id']}, '05-simulation')
                    assert sim['status'] == 'simulation_passed' and sim['binary_rpc_loopback_used']
                    assert sim['files_verified'] == 48 and sim['rpc_close_session_confirmed']
                    summary.update(status='passed', tools=25, native_pous=61, pcwe_files=48,
                        full_packaged_resources_executed=True, binary_tls_simulation_passed=True,
                        project_id=copied['project_id'], pcwe_path=pcwe['pcwe_path'])
    except BaseException as exc:
        summary.update(status='failed', error=str(exc))
        raise
    finally:
        (output / 'result.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
        print(json.dumps({'report': str(output / 'result.json'), **summary}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())
