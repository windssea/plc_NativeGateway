"""Check recorded ACI results and saved project bytes; never contact a PLC."""
from pathlib import Path
import json
import zipfile
import xml.etree.ElementTree as ET
from project_snapshot import digest, text
from prepare_fb_roundtrip import MARKER

root = Path(__file__).resolve().parents[1] / 'artifacts' / 'aci-poc'
before = json.loads((root / 'frozen-snapshot-v2.json').read_text(encoding='utf-8'))
after = json.loads((root / 'modified-snapshot-v2.json').read_text(encoding='utf-8'))
comparison = json.loads((root / 'roundtrip-comparison-v2.json').read_text(encoding='utf-8'))
compile_files = ['baseline-compile.json', 'modified-compile.json', 'reopened-compile.json']
compile_results = {name: json.loads((root / name).read_text(encoding='utf-8-sig')) for name in compile_files}
assert all(result['status'] == 'completed' and result['compile']['Result'] == 'Succeeded'
           for result in compile_results.values())
assert comparison['all_preservation_checks_passed']
assert comparison['selected_fb_code_changed']

fb = 'NG_ReadAck'
prefix = before['pous'][fb]['path']
with zipfile.ZipFile(root / 'NativeGateway.frozen.pcwex') as original, \
        zipfile.ZipFile(root / 'NativeGateway.aci-test.pcwex') as modified:
    old_code = text(original.read(prefix + 'Code.st'))
    new_code = text(modified.read(prefix + 'Code.st'))
    assert new_code == MARKER + '\n' + old_code, 'Unexpected target code changes'
    mapping_paths = [path for path in original.namelist()
                     if path.endswith(('DataList.dl', 'EsmConfiguration.esmc'))]
    mapping_bytes_unchanged = all(original.read(path) == modified.read(path) for path in mapping_paths)
    assert mapping_bytes_unchanged
    old_meta = ET.fromstring(original.read(prefix + 'Metadata.meta'))
    new_meta = ET.fromstring(modified.read(prefix + 'Metadata.meta'))
    worksheet_ids = {
        key: {'before': old_meta.findtext(f'ItemGroup/{key}/Id'),
              'after': new_meta.findtext(f'ItemGroup/{key}/Id')}
        for key in ['VariableWorksheet', 'CodeWorksheet']
    }

assert digest((root / 'NativeGateway.aci-test.pcwex').read_bytes()) == after['archive_sha256']
variables_before = sum(len(pou['declarations']) for pou in before['pous'].values())
variables_after = sum(len(pou['declarations']) for pou in after['pous'].values())
result = {
    'result': 'passed_offline_roundtrip',
    'engineer_version': '2026.0.4', 'engineer_build': '9.0.373.0',
    'aci_trial': {'activated_with_vendor_tool': True, 'usage_period_days': 14,
                  'activated_utc': '2026-10-23T07:21:18Z'},
    'interface_enabled': True,
    'project_copy': str(root / 'NativeGateway.aci-test.pcwex'),
    'frozen_sha256': before['archive_sha256'], 'modified_sha256': after['archive_sha256'],
    'selected_fb': fb, 'selected_fb_object_id_preserved': before['pous'][fb]['id'] == after['pous'][fb]['id'],
    'pou_count_before': len(before['pous']), 'pou_count_after': len(after['pous']),
    'variable_count_before': variables_before, 'variable_count_after': variables_after,
    'selected_instance': 'Main.AckReader',
    'stages': {'aci_open': 'completed', 'baseline_compile': 'Succeeded',
               'aci_export': 'completed', 'modify_exported_single_fb': 'completed',
               'aci_import': 'completed', 'modified_compile': 'Succeeded',
               'save_close_reopen': 'completed', 'reopened_compile': 'Succeeded',
               'mapping_comparison': 'passed', 'backend_shutdown': 'completed',
               'plc_connect': 'not_run', 'plc_download': 'not_run'},
    'compile_messages': {name: result['compile']['Messages'] for name, result in compile_results.items()},
    'only_expected_comment_added': True, 'all_preservation_checks_passed': True,
    'tasks_and_datalist_byte_identical': mapping_bytes_unchanged,
    'checks_count': len(comparison['checks']),
    'worksheet_ids': worksheet_ids,
    'limitations': [
        'Comment-only ST edit, not a functional or online behavior test.',
        'Target POU object ID is preserved, but its code/variable worksheet IDs are regenerated.',
        'Engineer serialized generated variable IDs and formatting into other variable worksheets.',
        'No pre-existing physical I/O connection is available in this sample.',
        'No guarantee for other Engineer versions, editing interfaces, HMI or safety code.'
    ]
}
output = root / 'result.json'
old_result = json.loads(output.read_text(encoding='utf-8'))
if old_result.get('result') == 'blocked_before_roundtrip':
    (root / 'result-before-activation.json').write_text(json.dumps(old_result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in ['result', 'pou_count_after', 'variable_count_after',
                                             'checks_count', 'tasks_and_datalist_byte_identical']}))
