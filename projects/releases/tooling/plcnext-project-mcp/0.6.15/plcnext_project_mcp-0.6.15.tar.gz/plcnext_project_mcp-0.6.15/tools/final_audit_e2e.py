"""Fresh NativeGateway copy: edits -> FB lifecycle -> cold build -> PCWE -> binary simulation."""
import asyncio
from datetime import timedelta
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import uuid
import zipfile

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex')


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def archive(path):
    with zipfile.ZipFile(path) as z:
        return {i.filename: z.read(i) for i in z.infolist()}


async def main():
    run = uuid.uuid4().hex
    output = ROOT / 'artifacts/final-audit-e2e' / run
    output.mkdir(parents=True)
    registration = json.loads(subprocess.check_output(
        [shutil.which('codex'), 'mcp', 'get', 'plcnext-project', '--json'], text=True, encoding='utf-8'))
    transport = registration['transport']
    assert registration['enabled'] and transport['type'] == 'stdio'
    cwd = Path(transport['env']['PLCNEXT_MCP_WORKSPACE']) / 'client-probes' / run
    cwd.mkdir(parents=True)
    assert not cwd.resolve().is_relative_to(ROOT.resolve())
    source_hash, original = digest(SOURCE), archive(SOURCE)
    parameters = StdioServerParameters(command=transport['command'], args=transport['args'],
        env=transport['env'], cwd=str(cwd))
    result = {'status': 'running', 'report_directory': str(output), 'checks': {},
        'registered_command_args_env_used_unchanged': True, 'client_directory': str(cwd),
        'controller_connected': False, 'controller_downloaded': False, 'program_started': False,
        'aci_used': False, 'computer_use_used': False, 'deployable': False}
    called = set()

    async def call(client, name, args, label=None, rejected=False):
        called.add(name)
        response = await client.call_tool(name, args)
        if rejected:
            assert response.isError, name + ' should reject'
            value = {'rejected': True, 'message': '\n'.join(c.text for c in response.content if hasattr(c, 'text'))}
        else:
            assert not response.isError, (name, response.content)
            value = response.structuredContent or json.loads(response.content[0].text)
        if label:
            save(output / (label + '.json'), value)
        return value

    try:
        with (output / 'server.log').open('w', encoding='utf-8') as log:
            async with stdio_client(parameters, errlog=log) as (reader, writer):
                async with ClientSession(reader, writer, read_timeout_seconds=timedelta(seconds=180)) as client:
                    await client.initialize()
                    names = sorted(t.name for t in (await client.list_tools()).tools)
                    assert len(names) == 25
                    save(output / 'tools.json', names)
                    caps = await call(client, 'server_capabilities', {}, 'capabilities')
                    assert not caps['controller_write_access'] and caps['download_simulation']['bounded_binary_rpc_loopback']
                    imported = await call(client, 'project_import_copy', {'source_path': str(SOURCE)}, '01-imported')
                    pid = imported['project_id']
                    inspected = await call(client, 'project_inspect', {'project_id': pid}, '02-inspected')
                    assert len(inspected['pous']) == 61
                    await call(client, 'project_build_plan', {'project_id': pid}, '03-build-plan')
                    pou = await call(client, 'project_read_pou', {'project_id': pid, 'pou_name': 'NG_ReadAck'}, '04-pou')
                    patch = {'project_id': pid, 'pou_name': 'NG_ReadAck',
                        'expected_project_sha256': pou['project_sha256'], 'expected_code_sha256': pou['code_sha256'],
                        'old_text': pou['code'], 'new_text': pou['code'] + '\n(* Final independent audit comment *)\n'}
                    changed = await call(client, 'project_patch_st', patch, '05-patched')
                    await call(client, 'project_patch_st', patch, '06-stale-rejected', True)
                    await call(client, 'project_diff', {'project_id': pid, 'pou_name': 'NG_ReadAck'}, '07-code-diff')
                    await call(client, 'project_diff_pou', {'project_id': pid, 'pou_name': 'NG_ReadAck'}, '08-pou-diff')
                    syntax = await call(client, 'project_check_st', {'project_id': pid, 'pou_name': 'NG_ReadAck'}, '09-syntax')
                    assert syntax['syntax_passed']
                    current_pou = await call(client, 'project_read_pou', {'project_id': pid, 'pou_name': 'NG_ReadAck'})
                    restored = await call(client, 'project_update_pous', {'project_id': pid,
                        'expected_project_sha256': changed['project_sha256'], 'updates': [{
                        'pou_name': 'NG_ReadAck', 'expected_code_sha256': current_pou['code_sha256'],
                        'expected_variables_sha256': current_pou['variables_sha256'], 'code': pou['code']}]}, '10-restored-code')
                    main = await call(client, 'project_read_pou', {'project_id': pid, 'pou_name': 'Main'})
                    added = await call(client, 'project_change_fbs', {'project_id': pid,
                        'expected_project_sha256': restored['project_sha256'],
                        'add_fbs': [{'pou_name': 'FinalAuditFB', 'code': 'Value := Value + UDINT#1;\n',
                            'variables': 'VAR_OUTPUT\nValue : UDINT;\nEND_VAR\n'}],
                        'updates': [{'pou_name': 'Main', 'expected_code_sha256': main['code_sha256'],
                            'expected_variables_sha256': main['variables_sha256'],
                            'variables': main['variables'] + '\nVAR\nauditA, auditB : FinalAuditFB;\nEND_VAR\n',
                            'code': main['code'] + '\nauditA();\nauditB();\n'}]}, '11-added-fb-and-callers')
                    refs = await call(client, 'project_find_references', {'project_id': pid, 'pou_name': 'FinalAuditFB'}, '12-references')
                    assert {r['instance'] for r in refs['instances']} == {'auditA', 'auditB'}
                    await call(client, 'project_delete_fb', {'project_id': pid,
                        'expected_project_sha256': added['project_sha256'], 'pou_name': 'FinalAuditFB'}, '13-referenced-delete-rejected', True)
                    with_fb = await call(client, 'project_compile', {'project_id': pid,
                        'expected_project_sha256': added['project_sha256']}, '14-cold-62-pous')
                    assert with_fb['compiled'] and with_fb['host']['pous_reparsed'] == 62
                    now_main = await call(client, 'project_read_pou', {'project_id': pid, 'pou_name': 'Main'})
                    removed = await call(client, 'project_change_fbs', {'project_id': pid,
                        'expected_project_sha256': added['project_sha256'], 'delete_fbs': ['FinalAuditFB'],
                        'updates': [{'pou_name': 'Main', 'expected_code_sha256': now_main['code_sha256'],
                            'expected_variables_sha256': now_main['variables_sha256'],
                            'code': main['code'], 'variables': main['variables']}]}, '15-deleted-and-restored-callers')
                    validation = await call(client, 'project_validate', {'project_id': pid}, '16-preservation')
                    assert validation['preservation_passed']
                    final_members = archive(removed['project_path'])
                    protected = [p for p in original if p.endswith(('DataList.dl', 'EsmConfiguration.esmc',
                        'IOConfiguration.ioc', 'Metadata.meta', 'Definition.hmipagedef', 'DataList.dlr4hmi'))]
                    assert protected and all(original[p] == final_members[p] for p in protected)
                    cold = await call(client, 'project_compile_nativegateway', {'project_id': pid,
                        'expected_project_sha256': removed['project_sha256'], 'mode': 'cold'}, '17-fresh-cold-61-pous')
                    assert cold['compiled'] and not cold['ast_seed_used'] and cold['host']['pous_reparsed'] == 61
                    build_args = {'project_id': pid, 'expected_project_sha256': removed['project_sha256'],
                                  'build_job_id': cold['job_id']}
                    await call(client, 'project_deployment_plan', build_args, '18-deployment-plan')
                    package = await call(client, 'project_generate_pcwe', build_args, '19-fresh-pcwe')
                    assert package['package_complete'] and package['file_count'] == 48
                    assert package['global_variable_count'] == 77 and package['hmi_mapping_count'] == 10
                    assert package['fb_instance_count'] == 109 and package['hmi_page_binding_count'] == 81
                    checked = await call(client, 'deployment_inspect_pcwe', {'source_path': package['pcwe_path']}, '20-package-inspection')
                    assert checked['overall_hash_status'] == 'verified'
                    staged = await call(client, 'deployment_stage_pcwe', {'source_path': package['pcwe_path'],
                        'expected_inventory_sha256': checked['inventory_sha256']}, '21-package-stage')
                    assert staged['all_bytes_preserved']
                    sim_args = {'project_id': pid, 'expected_project_sha256': removed['project_sha256'],
                                'package_job_id': package['package_job_id']}
                    plan = await call(client, 'project_download_plan', sim_args, '22-download-plan')
                    for fault in plan['available_faults']:
                        simulation = await call(client, 'project_simulate_download', sim_args | {'fault': fault}, '23-sim-' + fault)
                        assert simulation['status'] == ('simulation_passed' if fault == 'none' else 'simulation_failed')
                        assert simulation['source_and_package_unchanged'] and simulation['simulated_session_disposed']
                        if fault == 'none':
                            assert simulation['binary_rpc_loopback_used'] and simulation['rpc_close_session_confirmed']
                    assert digest(SOURCE) == source_hash
                    final = await call(client, 'project_inspect', {'project_id': pid})
                    assert final['project_sha256'] == removed['project_sha256'] and len(final['pous']) == 61
                    result.update(status='passed', source_snapshot_sha256=source_hash, source_snapshot_unchanged=True,
                        final_project_id=pid, final_project_path=removed['project_path'], pcwe_path=package['pcwe_path'],
                        package_job_id=package['package_job_id'], tools_exercised=sorted(called), checks={
                        'patch_diff_syntax_restore': True, 'stale_patch_rejected': True,
                        'coordinated_fb_lifecycle_61_62_61': True, 'comma_instance_references_complete': True,
                        'referenced_delete_rejected': True, 'fresh_cold_compile_62_and_61': True,
                        'metadata_and_runtime_mapping_payloads_preserved': True, 'complete_pcwe_48_files': True,
                        'package_stage_bytes_preserved': True, 'binary_download_16_scenarios': True})
    except BaseException as exc:
        result.update(status='failed', error=str(exc))
        raise
    finally:
        save(output / 'result.json', result)
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    asyncio.run(main())
