"""One authorized PLC: TLS/RSC Connect, PLC service discovery and GetPlcState.

Only 192.168.0.8:41100 is admitted. The observed certificate fingerprint is
pinned for this diagnostic, not enrolled as a trusted CA or device identity.
No credentials, file service, Reset/Load/Start/Stop or persistent changes.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import socket
import ssl
import struct
import uuid

from plcnext_mcp.rsc_codec import CommandHeader, decode_header, encode_header
from plcnext_mcp.rsc_rpc_codec import encode_connect_request, encode_get_service

HOST, PORT = '192.168.0.8', 41100
OBSERVED_PIN = '3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863'
SERVICE = 'Arp.Plc.Domain.Services.IPlcManagerService'
ROOT = Path(__file__).resolve().parents[1]


def service_request():
    raw = encode_get_service('Arp', SERVICE)
    header, _ = decode_header(raw[:16], require_checksum=True)
    return encode_header(CommandHeader(version=4, flags=0x40, command_type=15,
        data_length=header.data_length)) + raw[16:]


def send_readonly(channel, packet, handles=None):
    header, token = decode_header(packet[:16], require_checksum=True)
    if token is not None:
        raise ValueError('This probe does not send authentication tokens.')
    allowed = packet == encode_connect_request() or packet == service_request()
    if handles is not None:
        service, provider = handles
        allowed |= (header.version == 4 and header.command_type == 2 and header.flags == 0x40
            and header.data_length == 0 and header.method_handle == 5
            and header.service_handle == service and header.service_provider_handle == provider
            and packet[16:] == b'\xff')
    if not allowed:
        raise ValueError('Only Connect, fixed PLC service discovery and GetPlcState are allowed.')
    channel.sendall(packet)


def receive_exact(channel, count):
    result = bytearray()
    while len(result) < count:
        block = channel.recv(count - len(result))
        if not block:
            raise ConnectionError('PLC closed the connection before the expected response completed.')
        result.extend(block)
    return bytes(result)


def receive_header(channel):
    raw = receive_exact(channel, 16)
    header, token = decode_header(raw)
    if token is not None or header.flags != 0x40 or header.version != 4:
        raise ValueError('Unsupported response profile for this narrowly scoped probe.')
    return header, raw


def main():
    output = ROOT / 'artifacts/plc-connection-test' / uuid.uuid4().hex
    output.mkdir(parents=True)
    report = {'status': 'running', 'target': HOST, 'port': PORT,
        'observed_utc': datetime.now(timezone.utc).isoformat(),
        'credentials_sent': False, 'authentication_attempted': False,
        'file_methods_sent': False, 'configuration_commands_sent': False,
        'program_started_or_stopped': False, 'commands_sent': [],
        'trust_mode': 'Exact fingerprint observed during this diagnostic; PKI chain and hostname not trusted'}
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((HOST, PORT), timeout=3) as tcp:
            tcp.settimeout(3)
            with context.wrap_socket(tcp, server_hostname=HOST) as tls:
                fingerprint = hashlib.sha256(tls.getpeercert(binary_form=True)).hexdigest()
                if fingerprint != OBSERVED_PIN:
                    raise ValueError('The PLC certificate changed since the authorized observation; no RSC request sent.')
                report.update(tls_version=tls.version(), cipher=tls.cipher()[0], peer_certificate_sha256=fingerprint)
                send_readonly(tls, encode_connect_request())
                report['commands_sent'].append('Connect')
                header, raw = receive_header(tls)
                report['connect_confirmation_hex'] = raw.hex()
                if header.command_type != 8 or any((header.data_length, header.method_handle,
                                                    header.service_handle, header.service_provider_handle)):
                    raise ValueError('Unexpected Connect confirmation.')
                report.update(rsc_connected=True, rsc_version=4, data_tagging=True, datagramming=False)
                send_readonly(tls, service_request())
                report['commands_sent'].append('GetServiceHandles(IPlcManagerService)')
                header, raw = receive_header(tls)
                report['service_confirmation_hex'] = raw.hex()
                if (header.command_type != 16 or header.data_length or header.method_handle
                        or header.service_handle <= 0 or header.service_provider_handle <= 0):
                    raise ValueError('PLC service lookup failed or returned an unsupported response.')
                handles = (header.service_handle, header.service_provider_handle)
                report.update(service_handle=handles[0], provider_handle=handles[1])
                request = encode_header(CommandHeader(version=4, flags=0x40, command_type=2,
                    service_handle=handles[0], method_handle=5, service_provider_handle=handles[1])) + b'\xff'
                send_readonly(tls, request, handles)
                report['commands_sent'].append('GetPlcState(method=5)')
                header, raw = receive_header(tls)
                report['state_response_header_hex'] = raw.hex()
                if header.command_type == 4:
                    report.update(status='connected_state_query_rejected', anonymous_state_read_succeeded=False)
                else:
                    if (header.command_type != 3 or header.data_length or header.service_handle != handles[0]
                            or header.method_handle != 5 or header.service_provider_handle != handles[1]):
                        raise ValueError('Unexpected GetPlcState response handles or command.')
                    body = receive_exact(tls, 6)
                    report['state_response_value_hex'] = body.hex()
                    if body[0] != 9 or body[-1] != 255:
                        raise ValueError('GetPlcState response differs from the original tagged UInt32 oracle.')
                    state = struct.unpack('<I', body[1:5])[0]
                    report.update(status='connected_and_state_read', anonymous_state_read_succeeded=True,
                        plc_state_raw=state, plc_base_state={0:'None',1:'Ready',2:'Stop',3:'Running',4:'Halt'}.get(state&63,'Unknown'),
                        plc_state_flags=state & ~63)
    except (OSError, ValueError) as exc:
        report.update(status='probe_failed', error=str(exc))
    (output / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'report': str(output / 'result.json'), **report}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
