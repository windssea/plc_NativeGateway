"""Actual consumed package bytes must match their independently checked receipt.

The changed read snapshots below never touch the original managed copy or the
recorded HMI outputs. Vendor helpers are mocked for the orchestration guard.
"""
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from plcnext_mcp.hmi_output import validate_page_receipt
from plcnext_mcp.pcwe_build import build_pcwe
from plcnext_mcp.project import ProjectError, ProjectStore, sha

ROOT = Path(__file__).resolve().parents[1]
PAGES = ROOT / 'artifacts/pcwe-aux-research/probe-36'
BUILD = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/builds/54599b7ed9254ac6a61293152ce4ae08')


class ConsumedPackageBytesTests(unittest.TestCase):
    @unittest.skipUnless((PAGES / 'result.json').is_file() and (BUILD / 'result.json').is_file(),
                         'Recorded source-bound HMI receipt is unavailable')
    def test_hmi_same_length_read_snapshot_must_match_receipt_hash(self):
        report = json.loads((PAGES / 'result.json').read_text(encoding='utf-8-sig'))
        build = json.loads((BUILD / 'result.json').read_bytes())
        target = PAGES / 'gateway.json'
        before = target.read_bytes()
        changed = before.replace(b'Gateway', b'Gatewax', 1)
        self.assertNotEqual(before, changed)
        self.assertEqual(len(before), len(changed))
        original_read = Path.read_bytes

        def read_snapshot(path):
            return changed if path == target else original_read(path)

        # _verify opens the unchanged disk file and succeeds. The snapshot read
        # must itself be checked, rather than assuming both I/O operations agree.
        with mock.patch.object(Path, 'read_bytes', read_snapshot):
            with self.assertRaises(ProjectError):
                validate_page_receipt(PAGES, report, BUILD, build,
                    report['runtime_types_sha256'], report['host_source_sha256'])
        self.assertEqual(target.read_bytes(), before)

    def test_image_read_snapshot_is_checked_before_hmi_or_package_assembly(self):
        with tempfile.TemporaryDirectory() as temporary:
            store = ProjectStore(Path(temporary) / 'workspace')
            project = store.import_copy(str(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'))
            project_id, project_hash = project['project_id'], project['project_sha256']
            job_id = 'e' * 32
            job = store.root / project_id / 'builds' / job_id
            (job / 'generated').mkdir(parents=True)
            resource = 'RES_' + 'E' * 32
            image = job / 'generated' / (resource + '.img')
            original_image = b'RLCE-original-offline-guard-fixture'
            changed_image = b'RLCE-tampered-offline-guard-fixture'
            self.assertEqual(len(original_image), len(changed_image))
            image.write_bytes(original_image)
            model = job / 'analyzed.LastBuild.ast'
            model.write_bytes(b'offline guard; never execute')
            build = {'project_id': project_id, 'project_sha256': project_hash, 'job_id': job_id,
                'resource_name': resource, 'image_sha256': sha(original_image), 'input_hashes': {},
                'generated_files': [{'name': image.name, 'sha256': sha(original_image)}],
                'analyzed_compiler_model': {'name': model.name, 'sha256': sha(model.read_bytes()),
                                            'rebuilt_from_current_sources': True}}
            (job / 'result.json').write_text(json.dumps(build), encoding='utf-8')
            plan = {'image_path': str(image), 'image_sha256': sha(original_image), 'pou_count': 31,
                    'build_receipt_sha256': sha((job / 'result.json').read_bytes())}

            def finalize(_image, _types, output, _install, _hashes):
                output.mkdir()
                for name in ('TypeInformation.json', 'runtime-types-report.json'):
                    (output / name).write_bytes(b'{}')
                return {'type_information_sha256': sha(b'{}'), 'report_sha256': sha(b'{}')}

            original_read = Path.read_bytes
            def read_snapshot(path):
                return changed_image if path == image else original_read(path)

            with ExitStack() as stack:
                stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.deployment_plan', return_value=plan))
                stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.finalize_runtime_types', side_effect=finalize))
                stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.validate_runtime_layout', return_value={}))
                stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.generate_native_payloads', return_value=({}, {})))
                stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.generate_auxiliary_payloads', return_value=({}, {})))
                hmi = stack.enter_context(mock.patch('plcnext_mcp.hmi_output.generate_hmi_pages',
                                                    side_effect=ProjectError('downstream HMI reached')))
                stack.enter_context(mock.patch.object(Path, 'read_bytes', read_snapshot))
                with self.assertRaises(ProjectError):
                    build_pcwe(store, project_id, project_hash, job_id)
                hmi.assert_not_called()
            self.assertEqual(image.read_bytes(), original_image)


if __name__ == '__main__':
    unittest.main()
