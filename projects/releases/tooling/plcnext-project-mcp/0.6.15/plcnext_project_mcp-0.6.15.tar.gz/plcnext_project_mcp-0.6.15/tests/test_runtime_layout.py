"""Independent frozen native/CIL layout checks; mutations stay in memory only."""
from copy import deepcopy
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock
import zipfile

from plcnext_mcp.project import ProjectError, sha
from plcnext_mcp.runtime_configuration import generate_runtime_configuration
from plcnext_mcp.runtime_layout import finalize_runtime_types, validate_runtime_layout

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'artifacts/pcwe-build-research/finalized-types-06'
PROJECT = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex')
RESOURCE = 'RES_23CA7F267545404C9FED5DC977A6399F'
AVAILABLE = PROJECT.is_file() and all((EVIDENCE / name).is_file() for name in ('TypeInformation.json', 'runtime-types-report.json'))


@unittest.skipUnless(AVAILABLE, 'Frozen 61-POU native layout evidence is not installed')
class RuntimeLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with zipfile.ZipFile(PROJECT) as archive:
            cls.project = {name: archive.read(name) for name in archive.namelist()}
        _, cls.source = generate_runtime_configuration(cls.project)
        cls.type_info = json.loads((EVIDENCE / 'TypeInformation.json').read_text(encoding='utf-8-sig'))
        cls.image_info = json.loads((EVIDENCE / 'runtime-types-report.json').read_text(encoding='utf-8-sig'))

    def setUp(self):
        self.members = dict(self.project)
        self.report = deepcopy(self.source)
        self.types = deepcopy(self.type_info)
        self.image = deepcopy(self.image_info)

    def validate(self):
        return validate_runtime_layout(self.members, self.report, self.types, self.image, RESOURCE)

    def field(self, kind, typename, name):
        record = next(t for t in self.image[kind] if t['name'] == typename)
        return next(field for field in record['fields'] if field['name'] == name)

    def test_real_61_pou_native_image_binding(self):
        result = self.validate()
        self.assertTrue(result['passed'])
        self.assertEqual(result['runtime_type_count'], 192)
        self.assertEqual(result['variable_count'], 77)
        self.assertEqual(result['hmi_mapping_count'], 10)
        self.assertEqual(result['fb_instance_count'], 109)
        self.assertFalse(result['controller_execution_verified'])
        self.assertTrue(result['offsets_are_local_image_metadata_not_live_addresses'])
        self.assertEqual(result['program_bindings'][0]['instance'], 'MainInstance')
        self.assertEqual(result['program_bindings'][0]['type'], 'Main')
        source_ids = {v['name']: v['id'] for v in self.source['variables']}
        self.assertEqual({v['name']: v['id'] for v in result['variables']}, source_ids)

    def test_structure_native_offset_mismatch_is_rejected(self):
        structure = next(t for t in self.types['Types'] if t['Name'] == 'NG_Hmi')
        structure['Fields'][0]['FieldOffset'] += 1
        with self.assertRaises(ProjectError):
            self.validate()

    def test_structure_runtime_field_type_change_is_rejected(self):
        structure = next(t for t in self.types['Types'] if t['Name'] == 'NG_Hmi')
        structure['Fields'][0]['FieldRuntimeType'] = 'System.UInt64'
        with self.assertRaises(ProjectError):
            self.validate()

    def test_structure_field_inventory_omission_is_rejected(self):
        structure = next(t for t in self.types['Types'] if t['Name'] == 'NG_Hmi')
        structure['Fields'].pop()
        with self.assertRaises(ProjectError):
            self.validate()

    def test_structure_native_size_mismatch_is_rejected(self):
        structure = next(t for t in self.types['Types'] if t['Name'] == 'NG_Hmi')
        structure['RuntimeSize'] += 4
        with self.assertRaises(ProjectError):
            self.validate()

    def test_global_cil_type_mismatch_is_rejected(self):
        name = self.source['variables'][0]['name']
        self.field('cil_layout', 'ProConOS_eCLR.ResGlobalVars', name)['type'] = 'System.Double'
        with self.assertRaises(ProjectError):
            self.validate()

    def test_global_native_negative_offset_is_rejected(self):
        name = self.source['variables'][0]['name']
        self.field('native_layout', 'ProConOS_eCLR.ResGlobalVars', name)['offset'] = -1
        with self.assertRaises(ProjectError):
            self.validate()

    def test_global_identity_is_bound_to_pcwex_not_only_report(self):
        self.report['variables'][0]['id'] = '00000000-0000-0000-0000-000000000001'
        with self.assertRaises(ProjectError):
            self.validate()

    def test_hmi_variable_identity_mismatch_is_rejected(self):
        self.report['hmi_mappings'][0]['id'] = '00000000-0000-0000-0000-000000000001'
        with self.assertRaises(ProjectError):
            self.validate()

    def test_hmi_mapping_omission_is_rejected(self):
        self.report['hmi_mappings'] = []
        self.report['hmi_mapping_count'] = 0
        with self.assertRaises(ProjectError):
            self.validate()

    def test_task_binding_omission_is_rejected(self):
        self.report['task_program_relations'] = []
        with self.assertRaises(ProjectError):
            self.validate()

    def test_task_cycle_report_is_bound_to_source(self):
        self.report['tasks'][0]['cycleTime'] = '40000000'
        with self.assertRaises(ProjectError):
            self.validate()

    def test_task_cil_static_storage_mismatch_is_rejected(self):
        self.field('cil_layout', 'ProConOS_eCLR.__Cyclic100', 'MainInstance')['is_static'] = False
        with self.assertRaises(ProjectError):
            self.validate()

    def test_task_native_instance_omission_is_rejected(self):
        task = next(t for t in self.image['native_layout'] if t['name'] == 'ProConOS_eCLR.__Cyclic100')
        task['fields'] = [f for f in task['fields'] if f['name'] != 'MainInstance']
        with self.assertRaises(ProjectError):
            self.validate()

    def test_native_fb_type_mismatch_is_rejected(self):
        self.field('native_layout', 'Main', 'Store')['type'] = 'Wrong.Type'
        with self.assertRaises(ProjectError):
            self.validate()

    def test_native_fb_storage_mismatch_is_rejected(self):
        self.field('native_layout', 'Main', 'Store')['is_static'] = True
        with self.assertRaises(ProjectError):
            self.validate()

    def test_native_fb_negative_offset_is_rejected(self):
        self.field('native_layout', 'Main', 'Store')['offset'] = -1
        with self.assertRaises(ProjectError):
            self.validate()

    def test_native_fb_positive_offset_outside_class_is_rejected(self):
        self.field('native_layout', 'Main', 'Store')['offset'] = 10**9
        with self.assertRaises(ProjectError):
            self.validate()

    def test_compiled_fb_instance_omission_is_rejected(self):
        main = next(t for t in self.image['cil_layout'] if t['name'] == 'Main')
        main['fields'] = [f for f in main['fields'] if f['name'] != 'Store']
        with self.assertRaises(ProjectError):
            self.validate()

    def test_source_fb_instance_change_is_rejected(self):
        path = next(n for n in self.members if n.endswith('/Main.pou/Variables.var'))
        self.assertIn(b'Store : NG_Store', self.members[path])
        self.members[path] = self.members[path].replace(b'Store : NG_Store', b'Store : NG_ReadAck', 1)
        with self.assertRaises(ProjectError):
            self.validate()


@unittest.skipUnless(os.name == 'nt', 'Local metadata host wrapper requires Windows')
class RuntimeLayoutInputBindingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.image = self.root / 'fixture.img'
        self.types = self.root / 'TypeInformation.json'
        self.cil = self.root / 'fixture.dll'
        self.image.write_bytes(b'not an executable image; input guard fixture')
        self.types.write_bytes(b'{}')
        self.cil.write_bytes(b'not an executable assembly; input guard fixture')
        self.expected = {p.name: sha(p.read_bytes()) for p in [self.image, self.types, self.cil]}

    def finalize(self):
        return finalize_runtime_types(self.image, self.types, self.root / 'output', self.root, self.expected)

    def test_changed_cil_never_starts_metadata_host(self):
        self.cil.write_bytes(b'changed after build')
        with mock.patch('plcnext_mcp.runtime_layout.shutil.which', return_value='pwsh'):
            with mock.patch('plcnext_mcp.runtime_layout.subprocess.run') as execute:
                with self.assertRaisesRegex(ProjectError, 'bound cold build'):
                    self.finalize()
                execute.assert_not_called()
        self.assertFalse((self.root / 'output').exists())

    def test_unlisted_cil_never_starts_metadata_host(self):
        (self.root / 'unexpected.exe').write_bytes(b'unlisted local artifact')
        with mock.patch('plcnext_mcp.runtime_layout.shutil.which', return_value='pwsh'):
            with mock.patch('plcnext_mcp.runtime_layout.subprocess.run') as execute:
                with self.assertRaisesRegex(ProjectError, 'output inventory'):
                    self.finalize()
                execute.assert_not_called()

    def test_cil_change_during_extraction_is_rejected(self):
        def simulated_host(command, **kwargs):
            output = self.root / 'output'
            (output / 'runtime-types-report.json').write_text(json.dumps({'status': 'runtime_types_finalized'}))
            (output / 'TypeInformation.json').write_bytes(b'{}')
            self.cil.write_bytes(b'changed while host was reading')
            return subprocess.CompletedProcess(command, 0, b'', b'')
        with mock.patch('plcnext_mcp.runtime_layout.shutil.which', return_value='pwsh'):
            with mock.patch('plcnext_mcp.runtime_layout.subprocess.run', side_effect=simulated_host) as execute:
                with self.assertRaisesRegex(ProjectError, 'changed during layout'):
                    self.finalize()
                execute.assert_called_once()


if __name__ == '__main__':
    unittest.main()
