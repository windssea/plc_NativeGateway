"""M12-S pre-armed parent audit, local TLS bursts and exact capability boundaries."""
import json,time
from pathlib import Path
from unittest.mock import patch
import test_audit_export as audit_fixtures
from plcnext_mcp.recovery_audit import ParentAudit
from plcnext_mcp.controller_control import ControlEndpointLease
from plcnext_mcp.controller_recovery import _digest
from plcnext_mcp.project import ProjectError
import unittest

class ParentAuditTests(unittest.TestCase):
    setUp=audit_fixtures.AuditRunnerTests.setUp
    client=audit_fixtures.AuditRunnerTests.client
    runner=audit_fixtures.AuditRunnerTests.runner
    def setup_parent(self,burst=1):
        if burst>1:
            values=self.fixture.values;prefix='CaptureBuffer.AuditEvents[1].'
            for seq in range(2,burst+1):
                values.update({f'CaptureBuffer.AuditEvents[{seq}].'+n[len(prefix):]:v for n,v in list(values.items()) if n.startswith(prefix)})
                values[f'CaptureBuffer.AuditEvents[{seq}].Event.SampleSeq']=seq
            values['CaptureBuffer.AuditWriteSeq']=burst
        a,store,static,peer=self.runner()
        peer.model.values['BootId']='boot-before'
        static['policy'].update(parent_recovery_plan_id='9'*32,boot_binding='observe_same_parent_start',expected_boot_id='observe_same_parent_start')
        parent={'plan_id':'9'*32,'project_id':'c'*32,'source':{'project_sha256':static['project_sha256']},
            'package':{'inventory_sha256':static['inventory_sha256']},'target':static['target'],
            'children':{'audit':{'plan_id':static['plan_id'],'plan_sha256':static['plan_sha256']},
                'stop':{'review_sha256':'8'*64},'start':{'review_sha256':'7'*64}},
            'approved_actions':['fsync_and_ack_fixed_audit_cursors_after_same_start'],'files':{'PUBLIC':1},
            'policy':{'expected_configuration':{'version':13}}}
        parent['review_sha256']=_digest(parent)
        review={'target':parent['target'],'review_sha256':'8'*64,'policy':{'plan_id':parent['plan_id']}}
        lease=ControlEndpointLease(review,self.root);self.addCleanup(lease.release)
        job=self.root/'parent';job.mkdir();(job/'load-result.json').write_text('{}')
        loaded={'load_state_verified':True,'files_verified':1,'outcome_unknown':False}
        mock=patch('plcnext_mcp.recovery_audit.load',return_value=(self.root,static,a.load(store,'c'*32,'a'*32,'b'*64)[2]));mock.start();self.addCleanup(mock.stop)
        start={'review_sha256':'7'*64,'target':parent['target'],'action':'start','status':'control_completed',
            'action_sent':True,'ack_received':True,'terminal_state_verified':True,'loaded_package_identity_verified':True,'outcome_unknown':False}
        return store,parent,lease,job,loaded,lambda:lease.validate(review),time.monotonic()+10,peer,start
    def test_start_burst_250_is_exported_before_parent_verification(self):
        *args,peer,start=self.setup_parent(250)
        session=ParentAudit(*args);self.assertEqual(peer.field_writes,[])
        # Equivalent of the verified Start edge: all quality events already exist.
        peer.model.values['BootId']='boot-a'
        with patch('plcnext_mcp.controller_package_read.read_reviewed_controller_package',side_effect=AssertionError('No post-Start full package read')):
            result=session.run(start)
        self.assertTrue(result['complete'],result);self.assertEqual(result['first_sample_seq'],1)
        self.assertEqual(result['capture'],250);self.assertEqual(result['post_start_package_reads'],0)
        self.assertTrue(args[2].path.exists());self.assertFalse(args[2].released)
    def test_wrong_parent_hash_or_lease_rejected_before_start(self):
        args=self.setup_parent();store,parent,lease,job,loaded,active,end,peer,start=args
        parent['review_sha256']='0'*64
        with self.assertRaises(ProjectError):ParentAudit(store,parent,lease,job,loaded,active,end)
        self.assertEqual(peer.field_writes,[])
    def test_wrong_causal_start_does_not_ack(self):
        *args,peer,start=self.setup_parent();session=ParentAudit(*args)
        start['review_sha256']='0'*64;peer.model.values['BootId']='boot-a'
        result=session.run(start);self.assertFalse(result['complete']);self.assertEqual(peer.field_writes,[])
    def test_cancel_and_unknown_ack_keep_parent_owned_evidence(self):
        *args,peer,start=self.setup_parent();session=ParentAudit(*args);peer.model.values['BootId']='boot-a'
        peer.profile_fault='commit_reply_lost'
        result=session.run(start);self.assertFalse(result['complete']);self.assertTrue(result['outcome_unknown'])
        self.assertTrue(args[2].path.exists());self.assertEqual(len(peer.field_writes),4)
    def test_unchanged_boot_never_guessed(self):
        *args,peer,start=self.setup_parent();args[-1]=time.monotonic()+.3;session=ParentAudit(*args)
        result=session.run(start);self.assertFalse(result['complete']);self.assertEqual(peer.field_writes,[])

    def test_unknown_audit_ack_resolution_is_read_only_and_bounded_by_durable_copy(self):
        from plcnext_mcp.recovery_audit import observe_ack_resolution
        from plcnext_mcp.audit_collector import EvidenceError
        *args,peer,start=self.setup_parent();session=ParentAudit(*args);peer.model.values['BootId']='boot-a'
        peer.profile_fault='commit_reply_lost';result=session.run(start)
        self.assertTrue(result['outcome_unknown']);count=len(peer.field_writes)
        parent=args[1]|{'audit_reconciliation_context':{'audit_plan_id':'a'*32,'audit_plan_sha256':'b'*64,
            'boot':'boot-a','durable_cursors':result['durable_cursors']}}
        proof=observe_ack_resolution(args[0],'c'*32,parent)
        self.assertTrue(proof['unknown_ack_resolved_by_current_readback']);self.assertFalse(proof['audit_complete'])
        self.assertEqual(len(peer.field_writes),count)
        peer.model.values['CaptureBuffer.AuditAckSeq']=2
        with self.assertRaises(EvidenceError):observe_ack_resolution(args[0],'c'*32,parent)
        self.assertEqual(len(peer.field_writes),count)

    def test_child_cancel_is_observed_before_any_ack(self):
        *args,peer,start=self.setup_parent();session=ParentAudit(*args);peer.model.values['BootId']='boot-a'
        (self.root/'cancel.json').write_text('{}')
        result=session.run(start)
        self.assertTrue(result['cancelled']);self.assertFalse(result['complete']);self.assertFalse(result['outcome_unknown'])
        self.assertEqual(peer.field_writes,[]);self.assertTrue(args[2].path.exists())

    def test_application_boot_delayed_more_than_two_seconds(self):
        import threading
        *args,peer,start=self.setup_parent();peer.model.values['BootId']=''
        initial=peer.model.values['CaptureBuffer.AuditWriteSeq']
        peer.model.values['CaptureBuffer.AuditWriteSeq']=0
        session=ParentAudit(*args)
        timer=threading.Timer(2.2,lambda:peer.model.values.update({'BootId':'boot-a','CaptureBuffer.AuditWriteSeq':initial}))
        timer.start();self.addCleanup(timer.join)
        result=session.run(start)
        self.assertTrue(result['complete'],result)
        self.assertGreater(result['boot_observation_delay_seconds'],2)
        self.assertEqual(result['first_sample_seq'],1)

    def test_boot_wait_does_not_hide_lost_prefix(self):
        *args,peer,start=self.setup_parent();session=ParentAudit(*args)
        peer.model.values['CaptureBuffer.AuditDropped']=1
        result=session.run(start)
        self.assertFalse(result['complete']);self.assertEqual(result['ack_write_attempts'],0)

    def test_zero_ack_readback_allows_overflow_but_not_consumer(self):
        from plcnext_mcp.recovery_audit import observe_ack_resolution
        from plcnext_mcp.audit_collector import EvidenceError
        *args,peer,start=self.setup_parent()
        peer.model.values.update(BootId='boot-later')
        for ring in ('Audit','Association'):
            peer.model.values.update({'CaptureBuffer.'+ring+'AckBootId':'','CaptureBuffer.'+ring+'AckSeq':0,
                'CaptureBuffer.'+ring+'ReadSeq':900,'CaptureBuffer.'+ring+'Dropped':900})
        parent=args[1]|{'audit_reconciliation_context':{'audit_plan_id':'a'*32,'audit_plan_sha256':'b'*64,
            'mode':'zero_ack_before_boot','boot':None,'durable_cursors':{'Audit':0,'Association':0}}}
        proof=observe_ack_resolution(args[0],'c'*32,parent)
        self.assertFalse(proof['historical_boot_observed']);self.assertFalse(proof['audit_complete'])
        peer.model.values['CaptureBuffer.AuditReadSeq']=901
        with self.assertRaises(EvidenceError):observe_ack_resolution(args[0],'c'*32,parent)
        peer.model.values['CaptureBuffer.AuditReadSeq']=900
        peer.model.values['CaptureBuffer.AuditAckSeq']=1
        with self.assertRaises(EvidenceError):observe_ack_resolution(args[0],'c'*32,parent)
        self.assertEqual(peer.field_writes,[])

    def test_partial64_zero_ack_and_acknowledged_overflow_windows(self):
        from plcnext_mcp.recovery_audit import observe_ack_resolution
        from plcnext_mcp.audit_collector import EvidenceError
        *args,peer,start=self.setup_parent();peer.model.values['BootId']='boot-a'
        context={'audit_plan_id':'a'*32,'audit_plan_sha256':'b'*64,'mode':'zero_ack_partial',
            'boot':'boot-a','durable_cursors':{'Audit':64,'Association':0}}
        parent=args[1]|{'audit_reconciliation_context':context}
        for ring in ('Audit','Association'):
            peer.model.values.update({'CaptureBuffer.'+ring+'AckBootId':'','CaptureBuffer.'+ring+'AckSeq':0,
                'CaptureBuffer.'+ring+'ReadSeq':900,'CaptureBuffer.'+ring+'Dropped':900})
        proof=observe_ack_resolution(args[0],'c'*32,parent)
        self.assertTrue(proof['historical_boot_observed']);self.assertFalse(proof['audit_complete'])
        peer.model.values['CaptureBuffer.AuditAckSeq']=64
        with self.assertRaises(EvidenceError):observe_ack_resolution(args[0],'c'*32,parent)
        context.pop('mode');peer.model.values['CaptureBuffer.AuditAckBootId']='boot-a'
        peer.model.values['CaptureBuffer.AuditReadSeq']=964
        self.assertTrue(observe_ack_resolution(args[0],'c'*32,parent)['unknown_ack_resolved_by_current_readback'])
        peer.model.values['CaptureBuffer.AuditReadSeq']=965
        with self.assertRaises(EvidenceError):observe_ack_resolution(args[0],'c'*32,parent)
        peer.model.values['CaptureBuffer.AuditReadSeq']=964;peer.model.values['CaptureBuffer.AuditAckSeq']=65
        with self.assertRaises(EvidenceError):observe_ack_resolution(args[0],'c'*32,parent)
        self.assertEqual(peer.field_writes,[])

    def test_partial64_frozen_business_unknown_exports_under_parent_lease(self):
        snap=json.loads((Path(__file__).parent/'fixtures/boot67-local-diagnostics.json').read_text(encoding='utf-8'))['row']['snapshot']
        self.diagnostic_snapshot=dict(snap,BootId='boot-a')
        *args,peer,start=self.setup_parent(64)
        session=ParentAudit(*args);peer.model.values['BootId']='boot-a'
        result=session.run(start)
        self.assertTrue(result['complete'],result);self.assertEqual(result['capture'],64)
        self.assertFalse(result['globalAccountingComplete']);self.assertTrue(result['restartLossUnknown'])
        self.assertTrue(result['gapDetailTruncated']);self.assertTrue(args[2].path.exists())

    def test_parent_source_cohort_reports_separate_boundaries(self):
        prefix='CaptureBuffer.Associations[1].'
        self.fixture.values.update({prefix+k:v for k,v in {'Ordinal':1,'MessageId':'m13','Digest':'a'*64,
            'Count':1,'ConfigSlot':1,'ConfigGeneration':7,'BatchGeneration':1,'Category':2,'SampleSeqs[1]':1}.items()})
        self.fixture.values['CaptureBuffer.AssociationWriteSeq']=1
        *args,peer,start=self.setup_parent();session=ParentAudit(*args)
        session.static['policy']['closure_mode']='source_cohort';peer.model.values['BootId']='boot-a'
        result=session.run(start)
        self.assertTrue(result['complete'],result);self.assertIsNone(result['tail'])
        self.assertEqual(result['source_boundary'],1);self.assertTrue(result['source_cohort_associations_complete'])
        self.assertFalse(result['business_delivery_verified']);self.assertTrue(args[2].path.exists())

    def test_v2_parent_source_cohort_versions_start_and_terminal(self):
        from plcnext_mcp.audit_facts import FIELDS
        prefix='CaptureBuffer.AuditEvents[1].'
        values={'Event.PollSkippedBefore':0,'DecisionFlags':63,'DecisionRevisionDelta':0,
            'DecisionDelayLo':10,'DecisionDelayHi':0,'ReportSkipped':0,'Event.Kind':1}
        self.fixture.values.update({prefix+k:v for k,v in values.items()})
        self.fixture.values.update({'CaptureBuffer.AuditFactSchema':2,'CaptureBuffer.AuditFactsComplete':True})
        self.fixture.values.update({'CaptureBuffer.Associations[1].'+k:v for k,v in {'Ordinal':1,'MessageId':'m14','Digest':'b'*64,
            'Count':1,'ConfigSlot':1,'ConfigGeneration':7,'BatchGeneration':1,'Category':2,'SampleSeqs[1]':1}.items()})
        self.fixture.values['CaptureBuffer.AssociationWriteSeq']=1
        *args,peer,start=self.setup_parent();session=ParentAudit(*args)
        session.static['policy'].update(closure_mode='source_cohort',fact_mode='decision_clock_slots_v2')
        peer.model.values['BootId']='boot-a';result=session.run(start)
        self.assertTrue(result['complete'],result);self.assertTrue(result['v2_facts_complete'])
        rows=[json.loads(l) for l in (self.root/'events.jsonl').read_text().splitlines()]
        self.assertEqual(next(r for r in rows if r['kind']=='start')['audit_fact_schema'],2)
        self.assertEqual(rows[-1]['kind'],'sourceCohortEnd');self.assertEqual(rows[-1]['audit_fact_schema'],2)
        self.assertTrue(rows[-1]['audit_facts_complete']);self.assertTrue(args[2].path.exists())
