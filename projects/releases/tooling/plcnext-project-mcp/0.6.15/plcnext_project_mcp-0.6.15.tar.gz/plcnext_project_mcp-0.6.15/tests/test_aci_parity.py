"""Coverage must expose gaps rather than convert API inventory into capability."""
import ast
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from plcnext_mcp.aci_parity import aci_replacement_coverage, aci_replacement_summary

ROOT = Path(__file__).resolve().parents[1]


def all_methods():
    result, offset = [], 0
    while True:
        page = aci_replacement_coverage(offset=offset, limit=60, include_details=True)
        result.extend(page['methods'])
        if page['next_offset'] is None:
            return result
        offset = page['next_offset']


class AciParityTests(unittest.TestCase):
    def test_complete_contract_identity_and_unique_overloads(self):
        methods = all_methods()
        source = json.loads((ROOT / 'artifacts/aci-analysis/public-client-api-map.json').read_text(encoding='utf-8-sig'))
        expected = {method['token']: (item['name'], method['signature'])
                    for item in source['types'] if item['is_interface'] for method in item['methods']}
        self.assertEqual(len(methods), 201)
        self.assertEqual(len({method['method_id'] for method in methods}), 201)
        self.assertEqual({method['token']: (method['interface'], method['signature']) for method in methods}, expected)
        self.assertEqual(sum(method['method'] == 'Connect' and method['interface'].endswith('.IOnlineChannel')
                             for method in methods), 2)
        self.assertEqual(sum(method['method'] == 'SaveAs' for method in methods), 2)
        self.assertNotIn('unclassified', {method['domain'] for method in methods})

    def test_official_stubs_and_hidden_interfaces_are_not_successes(self):
        methods = all_methods()
        self.assertEqual(sum(method['official_behavior']['kind'] == 'unconditional_NotImplementedException'
                             for method in methods), 7)
        slots = [method for method in methods if method['method'] == 'GetNextFreePosition']
        self.assertEqual(slots[0]['official_behavior']['kind'], 'constant_placeholder')
        self.assertEqual(slots[0]['official_behavior']['constant'], 0)
        hidden = [method for method in methods if method['interface'].endswith(('.IHmiTag', '.IProcessDatum'))]
        self.assertEqual(len(hidden), 5)
        self.assertTrue(all(method['status'] == 'contract_only' for method in hidden))
        online = [method for method in methods if method['method'] == 'Download']
        self.assertEqual(online[0]['status'], 'partial')
        self.assertIn('project_execute_controller_download', online[0]['related_mcp_tools'])
        self.assertIn('Real PLC write permission', online[0]['gap'])
        self.assertIn('unverified or incomplete', online[0]['gap'])

    def test_all_verified_scopes_have_independent_sources_and_execution_evidence(self):
        methods = all_methods()
        supported = [method for method in methods if method['status'] == 'independent_verified_supported_scope']
        self.assertTrue(supported)
        for method in supported:
            self.assertTrue(method['scope'])
            self.assertTrue(method['gap'])
            self.assertTrue(method['acceptance_checks'])
            self.assertTrue(method['independent_source'])
            self.assertTrue(method['independent_evidence'])
            for path in method['independent_source'] + method['independent_evidence']:
                self.assertTrue((ROOT / path).is_file(), path)
        registered = {node.name for node in ast.walk(ast.parse((ROOT / 'src/plcnext_mcp/server.py').read_text()))
                      if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        mapped = {tool for method in methods for tool in method['related_mcp_tools']}
        self.assertFalse(mapped - registered, f'Unregistered tool mappings: {mapped - registered}')

    def test_filters_pagination_empty_tail_and_copy_isolation(self):
        methods = all_methods()
        filtered = aci_replacement_coverage(domain='controller_download', status='research_only', limit=1)
        expected = [method for method in methods if method['domain'] == 'controller_download'
                    and method['status'] == 'research_only']
        self.assertEqual(filtered['total_matched'], len(expected))
        self.assertEqual(len(filtered['methods']), 1)
        self.assertEqual(filtered['next_offset'], 1)
        filtered['methods'][0]['related_mcp_tools'].clear()
        repeat = aci_replacement_coverage(domain='controller_download', status='research_only', limit=1)
        self.assertTrue(repeat['methods'][0]['related_mcp_tools'])
        tail = aci_replacement_coverage(offset=1000)
        self.assertEqual(tail['methods'], [])
        self.assertIsNone(tail['next_offset'])

    def test_invalid_queries_fail_before_returning_a_misleading_page(self):
        for kwargs in ({'offset': -1}, {'offset': True}, {'limit': False}, {'limit': 61},
                       {'limit': '20'}, {'include_details': 1}, {'domain': 'unknown'}, {'status': 'done'}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                aci_replacement_coverage(**kwargs)

    def test_summary_is_not_a_completion_percentage_or_runtime_probe(self):
        with patch('socket.create_connection', side_effect=AssertionError('coverage opened a socket')), \
             patch('subprocess.run', side_effect=AssertionError('coverage executed target code')):
            result = aci_replacement_summary()
            aci_replacement_coverage(domain='controller_readonly')
        self.assertEqual(result['declared_interfaces'], 56)
        self.assertEqual(sum(result['status_counts'].values()), 201)
        self.assertEqual(sum(item['declared_methods'] for item in result['domains']), 201)
        self.assertFalse(result['full_aci_replacement'])
        self.assertFalse(result['exact_aci_api_compatibility'])
        self.assertFalse(result['network_used_by_this_tool'])
        self.assertFalse(result['aci_required_by_this_tool'])
        self.assertTrue(result['dependency_boundary']['installed_vendor_compiler_and_referenced_packages_required_for_build'])
        self.assertFalse(result['dependency_boundary']['aci_reference_example_is_independent_replacement'])
        self.assertNotIn('completion_percent', result)


if __name__ == '__main__':
    unittest.main()
