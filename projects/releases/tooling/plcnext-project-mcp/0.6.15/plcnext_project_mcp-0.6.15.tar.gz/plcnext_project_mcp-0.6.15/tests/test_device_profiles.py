"""Independent chains and future registrations: offline, no controller/socket calls."""
from copy import deepcopy
import json,os
from pathlib import Path
import tempfile,unittest,zipfile
from unittest.mock import patch

from plcnext_mcp import device_profiles as profiles, releases
from plcnext_mcp.expanded_compile import _cold_project_snapshot, _stage_device_profile
from plcnext_mcp.native_image import inspect_native_image
from plcnext_mcp.pcwe_auxiliary import generate_auxiliary_payloads
from plcnext_mcp.project import ProjectError,ProjectStore,read_archive,sha

ENGINEER=Path(__file__).resolve().parents[2]/'PLCnext-Engineer'
SOURCE={
 'AXCF2152':ENGINEER/'projects/candidates/native-0.8.1/NativeGateway.pcwex',
 'AXCF1252':ENGINEER/'projects/variants/native-0.8.1-axcf1252/NativeGateway1252Candidate.pcwex'}

class IndependentProfiles(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.store=ProjectStore(self.root/'workspace')
        env=patch.dict(os.environ,{'PLCNEXT_MCP_DEVICE_PROFILES_DIRECTORY':str(self.root/'profiles'),
                                  'PLCNEXT_MCP_RELEASE_ROOT':str(self.root/'releases')})
        env.start();self.addCleanup(env.stop)

    def members(self, target):return read_archive(SOURCE[target])[1]
    def future(self):
        p=deepcopy(profiles.PROFILES['AXCF2152-2026-v1'])
        p.update(profile_id='PUBLIC-FUTURE-2026-v1',device_name='PUBLIC FUTURE PLC',device_type='PUBLIC_FUTURE',template='PUBLIC-FUTURE.pxctx')
        return p

    def future_project(self):
        _,members,infos,comment=read_archive(SOURCE['AXCF2152'])
        members['PROJECT/PROJECT.proj']=members['PROJECT/PROJECT.proj'].replace(b'AXC F 2152',b'PUBLIC FUTURE PLC')
        members[releases.MAIN]=members[releases.MAIN].replace(b'NG-HUB-2152-01',b'PUBLIC-FUTURE-GATEWAY')
        path=self.root/'future.pcwex'
        with zipfile.ZipFile(path,'w') as archive:
            archive.comment=comment
            for info in infos:archive.writestr(info,members[info.filename])
        return path

    def test_each_existing_device_has_different_backend_abi_and_hmi(self):
        a=profiles.device_profile(self.members('AXCF2152'));b=profiles.device_profile(self.members('AXCF1252'))
        for field in ('profile_id','profile_sha256','backend','image_processor','program_model','elf_class','elf_machine','product_code','hmi_authentication_protocol'):
            self.assertNotEqual(a[field],b[field],field)
        self.assertEqual(b['empty_system_variable_task_count'],7)
        self.assertEqual(a['empty_system_variable_task_count'],8)

    def test_1252_snapshot_selects_its_own_chain_without_seed(self):
        imported=self.store.import_copy(str(SOURCE['AXCF1252']))
        snapshot,_,index=_cold_project_snapshot(self.store,imported['project_id'],imported['project_sha256'])
        self.assertEqual(snapshot['capability']['device'],'AXC F 1252')
        self.assertEqual(snapshot['capability']['processor'],'aarch64')
        self.assertEqual(len(index),66)

    def test_unknown_device_never_falls_back_to_2152(self):
        path=self.future_project();members=read_archive(path)[1]
        with self.assertRaisesRegex(ProjectError,'register an exact'):profiles.device_profile(members)

    def test_new_registered_model_selects_chain_without_code_branch(self):
        profile=self.future();registered=profiles.register_profile(profile)
        self.assertEqual(registered['profile']['qualification'],'registered_not_hardware_validated')
        imported=self.store.import_copy(str(self.future_project()))
        snapshot,_,_=_cold_project_snapshot(self.store,imported['project_id'],imported['project_sha256'])
        self.assertEqual(snapshot['capability']['device'],'PUBLIC FUTURE PLC')
        self.assertEqual(snapshot['capability']['profile_id'],profile['profile_id'])

    def test_duplicate_model_or_profile_cannot_replace_existing_chain(self):
        profile=self.future();profiles.register_profile(profile)
        with self.assertRaises(ProjectError):profiles.register_profile(profile)
        with self.assertRaises(ProjectError):profiles.register_profile(deepcopy(profiles.PROFILES['AXCF1252-2026-v1']))

    def test_path_escape_backend_and_unknown_family_are_rejected(self):
        for key,value in [('backend','CIL-Compiler/../../evil.dll'),('runtime_package','Profiles/../secret.zip'),
                          ('compile_family','external_shell'),('elf_class',True),('hmi_mode','ignore_auth')]:
            with self.subTest(key=key),self.assertRaises(ProjectError):
                profiles.register_profile({**self.future(),key:value})

    def test_new_device_instance_needs_separate_gateway_and_target(self):
        profiles.register_profile(self.future());path=self.future_project()
        imported=self.store.import_copy(str(path))
        with self.assertRaises(ProjectError):
            releases.prepare_dev(self.store,imported['project_id'],imported['project_sha256'],'0.8.2','Unbound future device')
        releases.register_target(self.store,'PUBLIC_FUTURE','192.0.2.20','PUBLIC-FUTURE-GATEWAY')
        frozen=releases.prepare_dev(self.store,imported['project_id'],imported['project_sha256'],'0.8.2','Synthetic offline chain test')
        self.assertEqual(frozen['release']['target'],'PUBLIC_FUTURE')
        self.assertEqual(frozen['release']['address'],'192.0.2.20')
        self.assertFalse(frozen['downloaded'])

    def test_existing_device_address_and_gateway_cannot_be_stolen(self):
        for address,gateway in [('192.168.0.8','OTHER-1252-GW'),('192.0.2.22','NG-HUB-2152-01')]:
            with self.assertRaises(ProjectError):releases.register_target(self.store,'AXCF1252',address,gateway)

    def test_two_instances_of_same_hardware_are_independent(self):
        record=releases.register_target(self.store,'AXCF1252','192.0.2.21','PUBLIC-SECOND-1252')
        self.assertEqual(record['address'],'192.0.2.21')
        defaults=[r for r in releases.deployment_targets(self.store) if r['gateway_id']=='NG-HUB-1252-01']
        self.assertEqual(defaults[0]['address'],'192.168.0.10')

    def test_same_model_distinct_hardware_variants_select_exact_fingerprint(self):
        from plcnext_mcp.pcwe_auxiliary import _hardware_profile
        original=self.members('AXCF2152');variant=dict(original)
        variant['PROJECT/Hardware/VersionHistory.usermeta']+=b'\n'
        fingerprint,_,_=_hardware_profile(variant)
        spec={**deepcopy(profiles.PROFILES['AXCF2152-2026-v1']),
              'profile_id':'PUBLIC-SECOND-2152-2026-v1','hardware_sha256':fingerprint}
        profiles.register_profile(spec)
        self.assertEqual(profiles.device_profile(original)['profile_id'],'AXCF2152-2026-v1')
        self.assertEqual(profiles.device_profile(variant)['profile_id'],spec['profile_id'])
        variant['PROJECT/Hardware/VersionHistory.usermeta']+=b'\n'
        with self.assertRaises(ProjectError):profiles.device_profile(variant)

    def test_foreign_native_architecture_fails_even_with_valid_elf_magic(self):
        p32=profiles.device_profile(self.members('AXCF2152'));p64=profiles.device_profile(self.members('AXCF1252'))
        def elf(profile):
            data=bytearray(64);data[:4]=b'\x7fELF';data[4]=profile['elf_class'];data[5]=1
            data[18:20]=profile['elf_machine'].to_bytes(2,'little');return bytes(data)
        profiles.validate_elf(elf(p32),p32);profiles.validate_elf(elf(p64),p64)
        for image,profile in [(elf(p32),p64),(elf(p64),p32)]:
            with self.assertRaises(ProjectError):profiles.validate_elf(image,profile)

    def test_1252_auxiliaries_use_1252_product_and_hardware(self):
        files,report=generate_auxiliary_payloads(self.members('AXCF1252'),'PUBLIC-1252','2026-11-20T00:00:00Z')
        self.assertEqual(json.loads(files['PCWE.software-package-manifest.json'])['identification']['targetProductCodes'],['1646469'])
        self.assertIn('AXCF1252',report['scope'])

    def test_compiler_descriptor_and_runtime_inputs_are_frozen_per_job(self):
        install=Path('D:/Program Files/PHOENIX CONTACT/PLCnext Engineer 2026.0')
        hashes=[]
        for target in SOURCE:
            job=self.root/target;job.mkdir()
            inputs,chain=_stage_device_profile(job,self.members(target),install)
            self.assertEqual(inputs['device-profile.xml'],sha((job/'device-profile.xml').read_bytes()))
            self.assertEqual(chain['backend_sha256'],sha((install/chain['profile']['backend']).read_bytes()))
            self.assertEqual(inputs['libraries/device-runtime.zip'],sha((job/'libraries/device-runtime.zip').read_bytes()))
            hashes.append(chain['backend_sha256'])
        self.assertNotEqual(*hashes)

    def test_native_inspection_rejects_changed_image_before_host(self):
        path=self.root/'PUBLIC.img';path.write_bytes(b'not an executable image')
        with patch('plcnext_mcp.native_image.subprocess.run') as host:
            with self.assertRaises(ProjectError):inspect_native_image(str(path),'0'*64)
            host.assert_not_called()


if __name__=='__main__':unittest.main()
