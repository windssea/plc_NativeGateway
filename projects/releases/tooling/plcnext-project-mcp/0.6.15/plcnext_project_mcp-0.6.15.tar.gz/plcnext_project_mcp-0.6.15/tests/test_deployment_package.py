"""Offline PCWE integrity/staging tests; no controller or GUI is used."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import xml.etree.ElementTree as ET

from plcnext_mcp.deployment_package import MANIFEST, inspect_pcwe, overall_hash, stage_pcwe
from plcnext_mcp.project import ProjectError


ROOT = Path(__file__).resolve().parents[1]
GUI_SAMPLE = ROOT / 'artifacts/headless-research/cil-frontend/input/RES_23CA7F267545404C9FED5DC977A6399F/Configuration/Projects/PCWE'


def write_manifest(root, *, wrong_overall=False):
    document = ET.Element('ProjectManifestDocument', schemaVersion='1.0')
    metadata = ET.SubElement(document, 'Metadata')
    ET.SubElement(metadata, 'HashAlgorithm', type='Sha512')
    container = ET.SubElement(document, 'Files')
    values = []
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.name == MANIFEST:
            continue
        value = hashlib.sha512(path.read_bytes()).hexdigest()
        ET.SubElement(container, 'File', path=path.relative_to(root).as_posix(), hash=value)
        values.append(value)
    container.set('overallHash', '0' * 128 if wrong_overall else hashlib.sha512(''.join(values).encode('ascii')).hexdigest())
    (root / MANIFEST).write_bytes(ET.tostring(document, encoding='utf-8', xml_declaration=True))


def fixture(root):
    entries = {
        'PCWE.software-package-manifest.json': json.dumps({'manifestVersion': '1.0', 'identification':
            {'name': 'OfflineTest', 'targetProductCodes': ['2404267'], 'targetFirmwareRevision': '26.0.0'}}).encode(),
        'Plc/Eclr/eCLR.img': b'RLCE' + b'Offline fixture; never execute',
        'Plc/Domain/pcwe.plc.config': b'<PlcDomainConfigurationDocument />',
        'Plc/Esm/PCWE.esm.config': b'<EsmConfigurationDocument />',
        'Plc/Gds/PCWE.gds.config': b'<GdsConfigurationDocument />',
        'Plc/Plm/pcwe.plm.config': b'<PlmConfigurationDocument />',
    }
    root.mkdir()
    for relative, payload in entries.items():
        destination = root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(payload)
    write_manifest(root)
    return root


class PackageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.parent = Path(self.temp.name)
        self.source = fixture(self.parent / 'source')
        self.output = self.parent / 'output'
        self.output.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def test_overall_hash_independent_standard_vectors(self):
        # FIPS 180-4 SHA-512 vectors, not values calculated by the implementation.
        self.assertEqual(overall_hash([]),
            'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce'
            '47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e')
        self.assertEqual(overall_hash(['a', 'b', 'c']),
            'ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a'
            '2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f')
        with self.assertRaises(ProjectError):
            overall_hash(['a'], 'Sha256')
        with self.assertRaises(ProjectError):
            overall_hash(['not hexadecimal'])

    def test_complete_directory_is_inspected_and_staged_without_changes(self):
        inspected = inspect_pcwe(self.source)
        self.assertTrue(inspected['file_hashes_verified'])
        self.assertEqual(inspected['overall_hash_status'], 'verified')
        self.assertFalse(inspected['deployable'])
        staged = stage_pcwe(self.source, self.output, inspected['inventory_sha256'])
        self.assertEqual(staged['status'], 'staged_offline')
        self.assertTrue(staged['all_bytes_preserved'])
        self.assertFalse(staged['controller_connected'])
        self.assertFalse(staged['controller_downloaded'])
        target = Path(staged['pcwe_path'])
        for record in inspected['files']:
            self.assertEqual((self.source / record['path']).read_bytes(), (target / record['path']).read_bytes())
        self.assertEqual(inspect_pcwe(self.source)['inventory_sha256'], inspected['inventory_sha256'])
        second = stage_pcwe(self.source, self.output, inspected['inventory_sha256'])
        self.assertNotEqual(staged['pcwe_path'], second['pcwe_path'])

    def test_unknown_overall_order_is_explicit_not_a_full_integrity_claim(self):
        write_manifest(self.source, wrong_overall=True)
        result = inspect_pcwe(self.source)
        self.assertEqual(result['overall_hash_status'], 'unknown_order')
        self.assertTrue(result['file_hashes_verified'])
        staged = stage_pcwe(self.source, self.output, result['inventory_sha256'])
        self.assertEqual(staged['overall_hash_status'], 'unknown_order')
        self.assertFalse(staged['deployable'])

    def test_tampered_payload_rejected(self):
        (self.source / 'Plc/Eclr/eCLR.img').write_bytes(b'RLCEtampered')
        with self.assertRaisesRegex(ProjectError, 'hash mismatch'):
            inspect_pcwe(self.source)

    def test_missing_payload_rejected(self):
        (self.source / 'Plc/Esm/PCWE.esm.config').unlink()
        with self.assertRaisesRegex(ProjectError, 'missing:'):
            inspect_pcwe(self.source)

    def test_unlisted_payload_rejected(self):
        (self.source / 'unlisted.txt').write_text('unexpected')
        with self.assertRaisesRegex(ProjectError, 'unlisted'):
            inspect_pcwe(self.source)

    def test_manifest_traversal_and_absolute_paths_rejected(self):
        for path in ('../outside', '/absolute', 'C:/absolute', 'Plc\\Eclr\\eCLR.img', 'Plc/../eCLR.img', 'Plc/CON'):
            with self.subTest(path=path):
                write_manifest(self.source)
                tree = ET.parse(self.source / MANIFEST)
                tree.getroot().find('./Files/File').set('path', path)
                tree.write(self.source / MANIFEST, encoding='utf-8')
                with self.assertRaisesRegex(ProjectError, 'Unsafe manifest path'):
                    inspect_pcwe(self.source)

    def test_duplicate_casefold_manifest_member_rejected(self):
        tree = ET.parse(self.source / MANIFEST)
        first = tree.getroot().find('./Files/File')
        ET.SubElement(tree.getroot().find('Files'), 'File', path=first.get('path').upper(), hash=first.get('hash'))
        tree.write(self.source / MANIFEST, encoding='utf-8')
        with self.assertRaisesRegex(ProjectError, 'Duplicate'):
            inspect_pcwe(self.source)

    def test_stale_inventory_rejected_before_output_created(self):
        previous = inspect_pcwe(self.source)['inventory_sha256']
        (self.source / 'Plc/Eclr/eCLR.img').write_bytes(b'RLCEanother valid bound revision')
        write_manifest(self.source)
        with self.assertRaisesRegex(ProjectError, 'Stale PCWE inventory'):
            stage_pcwe(self.source, self.output, previous)
        self.assertEqual(list(self.output.iterdir()), [])

    def test_generated_img_directory_is_not_a_complete_package(self):
        generated = self.parent / 'generated'
        generated.mkdir()
        (generated / 'RES_Test.img').write_bytes(b'RLCEgenerated')
        with self.assertRaisesRegex(ProjectError, 'complete PCWE directory'):
            inspect_pcwe(generated)

    def test_output_cannot_be_inside_source(self):
        previous = inspect_pcwe(self.source)['inventory_sha256']
        with self.assertRaisesRegex(ProjectError, 'outside the source'):
            stage_pcwe(self.source, self.source, previous)

    def test_manifest_signature_bytes_are_preserved_not_rebuilt(self):
        tree = ET.parse(self.source / MANIFEST)
        ET.SubElement(tree.getroot(), 'Signature').text = 'opaque-unvalidated-signature-fixture'
        tree.write(self.source / MANIFEST, encoding='utf-8')
        before = (self.source / MANIFEST).read_bytes()
        checked = inspect_pcwe(self.source)
        staged = stage_pcwe(self.source, self.output, checked['inventory_sha256'])
        self.assertEqual((Path(staged['pcwe_path']) / MANIFEST).read_bytes(), before)
        self.assertEqual(staged['signature_validation'], 'not_performed')
        self.assertFalse(staged['signatures_rebuilt'])

    def test_dtd_is_rejected(self):
        (self.source / MANIFEST).write_text('<!DOCTYPE test [<!ENTITY x "value">]><ProjectManifestDocument schemaVersion="1.0" />')
        with self.assertRaisesRegex(ProjectError, 'DTD/entity'):
            inspect_pcwe(self.source)

    def test_symbolic_link_rejected(self):
        link = self.source / 'linked'
        try:
            link.symlink_to(self.source / 'Plc/Eclr/eCLR.img')
        except OSError as exc:
            self.skipTest('Creating symlinks is unavailable for this account: ' + str(exc))
        with self.assertRaisesRegex(ProjectError, 'Symlinks'):
            inspect_pcwe(self.source)

    @unittest.skipUnless(GUI_SAMPLE.is_dir(), 'Frozen GUI fixture is not installed')
    def test_real_gui_package_47_manifest_members(self):
        source = self.parent / 'gui-copy'
        shutil.copytree(GUI_SAMPLE, source)
        checked = inspect_pcwe(source)
        self.assertEqual(checked['listed_file_count'], 47)
        self.assertEqual(checked['file_count'], 48)
        self.assertEqual(checked['overall_hash_status'], 'unknown_order')
        staged = stage_pcwe(source, self.output, checked['inventory_sha256'])
        self.assertTrue(staged['all_bytes_preserved'])
        self.assertEqual(inspect_pcwe(GUI_SAMPLE)['inventory_sha256'], checked['inventory_sha256'])


if __name__ == '__main__':
    unittest.main()
