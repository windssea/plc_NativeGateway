"""Original synthetic MemoryStream vectors; no network or vendor calls in tests."""
import io
import json
from pathlib import Path
import struct
import unittest

from plcnext_mcp import rsc_error_codec as errors
from plcnext_mcp import rsc_plc_control as controls
from plcnext_mcp.rsc_codec import CommandHeader, encode_header

ROOT = Path(__file__).resolve().parents[1]


def oracle():
    return json.loads((ROOT / 'artifacts/rsc-error-control/oracle-02/report.json').read_text(encoding='utf-8-sig'))


class RscErrorControlTests(unittest.TestCase):
    def test_original_error_and_stop_vectors(self):
        for vector in oracle()['vectors']:
            with self.subTest(vector=vector['name']):
                raw = bytes.fromhex(vector['hex'])
                details = vector['details']
                if vector['name'].startswith('stop-'):
                    if vector['name'].endswith('request'):
                        self.assertEqual(controls.encode_stop_request(41, details['async'], provider_handle=5), raw)
                        self.assertEqual(controls.decode_stop_request(raw)[2], {'async_': details['async']})
                    else:
                        self.assertEqual(controls.encode_stop_response(41, provider_handle=5), raw)
                        self.assertIsNone(controls.decode_stop_response(raw)[1])
                else:
                    expected = {'code': details['code'], 'fatal': details['fatal'],
                                'message': details['message'], 'arguments': details['arguments'] or []}
                    self.assertEqual(errors.decode_error(raw)[2], expected)
                    self.assertEqual(errors.encode_error(41, 3, details['code'],
                        details['message'] or '', details['arguments'] or (), provider_handle=5), raw)

    def test_fragmented_errors_and_following_header_not_consumed(self):
        for vector in oracle()['vectors']:
            if not vector['name'].startswith('error-'):
                continue
            body = bytes.fromhex(vector['hex'])[16:]
            for fragment in (1, 2, 7):
                with self.subTest(vector=vector['name'], fragment=fragment):
                    stream = io.BytesIO(body + b'NEXT_FRAME')
                    decoded = errors.receive_error(lambda count: stream.read(min(fragment, count)))
                    self.assertEqual(decoded['code'], vector['details']['code'])
                    self.assertEqual(stream.read(), b'NEXT_FRAME')

    def test_every_truncation_and_trailing_bytes_rejected(self):
        for vector in oracle()['vectors']:
            if not vector['name'].startswith('error-'):
                continue
            raw = bytes.fromhex(vector['hex'])
            for size in range(len(raw)):
                with self.subTest(vector=vector['name'], size=size), self.assertRaises(ValueError):
                    errors.decode_error(raw[:size])
            with self.assertRaises(ValueError):
                errors.decode_error(raw + b'\xff')

    def test_errors_reject_unknown_objects_and_noncanonical_payloads(self):
        head = encode_header(CommandHeader(flags=64, command_type=4, service_handle=41,
                                            method_handle=3, service_provider_handle=5))
        prefix = b'\x09\x05\0\0\0\x1a\x01\0\0\x14\x1c'
        for body in [prefix + struct.pack('<i', -1), prefix + struct.pack('<i', 17),
                     prefix + struct.pack('<i', 1) + b'\x27',
                     b'\x09\x05\0\0\0\x1a\x02\0\xff\0\x14\x1c\0\0\0\0\xff',
                     b'\x09\x05\0\0\0\x1a\x01\0x\x14\x1c\0\0\0\0\xff']:
            with self.subTest(body=body.hex()), self.assertRaises(ValueError):
                errors.decode_error(head + body)
        for value in [None, [], {}, 1.5, 2 ** 64, 2 ** 32]:
            with self.subTest(argument=value), self.assertRaises(ValueError):
                errors.encode_error(41, 3, 5, 'x', [value])
        for kwargs in [{'code': True}, {'code': -1}, {'code': 2**32},
                       {'code': 0x80000000, 'message': 'not allowed'},
                       {'code': 5, 'message': 'x\0y'}, {'code': 5, 'message': '\ud800'},
                       {'code': 5, 'message': 'x' * 4096}]:
            with self.subTest(kwargs=repr(kwargs)), self.assertRaises(ValueError):
                errors.encode_error(41, 3, **kwargs)

    def test_wrong_profile_command_checksum_and_tokens_rejected(self):
        raw = errors.encode_error(41, 3, 5, 'fixture', provider_handle=5)
        for flags, command in [(0, 4), (0xc0, 4), (0x40, 3)]:
            changed = encode_header(CommandHeader(flags=flags, command_type=command,
                service_handle=41, method_handle=3, service_provider_handle=5)) + raw[16:]
            with self.assertRaises(ValueError):
                errors.decode_error(changed)
        damaged = bytearray(raw)
        damaged[10] ^= 1
        with self.assertRaises(ValueError):
            errors.decode_error(bytes(damaged))
        token = encode_header(CommandHeader(flags=64, command_type=4,
            service_handle=41, method_handle=3, service_provider_handle=5), 0) + raw[16:]
        with self.assertRaises(ValueError):
            errors.decode_error(token)

    def test_stop_ack_is_not_state_proof_and_wrong_methods_are_rejected(self):
        raw = controls.encode_stop_request(41, provider_handle=5, token=0)
        self.assertEqual(controls.decode_stop_request(raw)[1], 0)
        for invalid in (0, 1, None, 'true'):
            with self.assertRaises(ValueError):
                controls.encode_stop_request(41, invalid)
        for command in (2, 3):
            packet = encode_header(CommandHeader(flags=64, command_type=command,
                service_handle=41, method_handle=4, service_provider_handle=5)) + (b'\x02\x01\xff' if command == 2 else b'\xff')
            with self.assertRaises(ValueError):
                (controls.decode_stop_request if command == 2 else controls.decode_stop_response)(packet)


if __name__ == '__main__':
    unittest.main()
