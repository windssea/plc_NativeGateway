"""Native payload selection and integrity rules: offline positive/negative cases."""
import hashlib
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile
import zlib

from plcnext_mcp.pcwe_native import generate_native_payloads, library_crc, make_pcwe_manifest
from plcnext_mcp.project import ProjectError, read_archive, sha


REAL_JOB = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/builds/21ecd6da142147329a4053e1363a6adb')


def package(variants):
    project = ET.Element('Project', xmlns='http://schemas.microsoft.com/developer/msbuild/2003')
    payloads = []
    for number, (kind, version, simulation, content) in enumerate(variants):
        prefix = 'Logical Elements/bin/' + str(number)
        folder = ET.SubElement(project, 'Folder', Include=prefix)
        ET.SubElement(folder, 'AssemblyName').text = 'TestLibrary'
        ET.SubElement(folder, 'FolderType').text = 'NativeLibrary'
        profile = ET.SubElement(ET.SubElement(folder, 'DeviceProfiles'), 'DeviceProfile')
        ET.SubElement(profile, 'DeviceProfileType').text = kind
        ET.SubElement(profile, 'DeviceProfileVersion').text = version
        if simulation is not None:
            ET.SubElement(profile, 'SimulationMode').text = simulation
        payloads.append(('PROJECT/' + prefix.replace(' ', '%20') + '/libTest.so', content))
    result = io.BytesIO()
    with zipfile.ZipFile(result, 'w') as archive:
        archive.writestr('PROJECT/PROJECT.proj', ET.tostring(project))
        for name, payload in payloads:
            archive.writestr(name, payload)
    return result.getvalue()


class NativePayloadTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'libraries').mkdir()
        project = ET.Element('Project')
        node = ET.SubElement(project, 'SolutionReference', Include='TestLibrary')
        ET.SubElement(node, 'HintPath').text = 'Z:/must-not-be-read/secret.pcwlx'
        self.members = {'PROJECT/PROJECT.proj': ET.tostring(project)}
        self.inputs = {'project/PROJECT/PROJECT.proj': sha(self.members['PROJECT/PROJECT.proj'])}
        self.set_package(package([
            ('AXCF2152', '2025.0.3', None, b'\x7fELFolder'),
            ('AXCF2152', '2026.0.2', None, b'\x7fELFcorrect'),
            ('AXCF1152', '2026.0.2', None, b'\x7fELFotherdevice'),
            ('AXCF2152', '2026.0.4', 'true', b'\x7fELFsimulation')]))

    def set_package(self, payload):
        (self.root / 'libraries/0000.pcwlx').write_bytes(payload)
        self.inputs['libraries/0000.pcwlx'] = sha(payload)
        manifest = ET.Element('Libraries')
        ET.SubElement(manifest, 'Library', name='TestLibrary', hint='Z:/must-not-be-read/secret.pcwlx',
            staged='libraries/0000.pcwlx', sha256=sha(payload), source='Z:/must-not-be-read/secret.pcwlx')
        raw = ET.tostring(manifest)
        (self.root / 'library-inputs.xml').write_bytes(raw)
        self.inputs['library-inputs.xml'] = sha(raw)

    def generate(self, device='AXCF2152', version='2026.0.0'):
        return generate_native_payloads(self.root, self.inputs, self.members, device, version)

    def test_major_minor_match_selects_current_device_without_reading_original_hint(self):
        files, report = self.generate()
        self.assertEqual(files['Plc/Eclr/SharedLibraries/TestLibrary/libTest.so'], b'\x7fELFcorrect')
        self.assertEqual(report['selected_native_files'][0]['profiles'][0]['version'], '2026.0.2')
        self.assertFalse(report['controller_connected'])
        self.assertEqual(struct.unpack('<I', files['Libraries.crc'][:4])[0], 1)

    def test_no_exact_profile_is_not_a_guessed_fallback(self):
        with self.assertRaisesRegex(ProjectError, 'No unique exact'):
            self.generate(version='2027.0.0')

    def test_multiple_patch_versions_in_same_normalized_profile_are_ambiguous(self):
        self.set_package(package([('AXCF2152', '2026.0.2', None, b'\x7fELFa'),
                                  ('AXCF2152', '2026.0.3', None, b'\x7fELFb')]))
        with self.assertRaisesRegex(ProjectError, 'No unique exact'):
            self.generate()

    def test_non_elf_payload_is_rejected(self):
        self.set_package(package([('AXCF2152', '2026.0.2', None, b'not native ELF')]))
        with self.assertRaisesRegex(ProjectError, 'not an ELF'):
            self.generate()

    def test_modified_library_and_source_hashes_are_rejected(self):
        (self.root / 'libraries/0000.pcwlx').write_bytes(b'tampered')
        with self.assertRaisesRegex(ProjectError, 'Build input changed'):
            self.generate()
        self.members['PROJECT/PROJECT.proj'] += b'\n'
        with self.assertRaisesRegex(ProjectError, 'not bound'):
            self.generate()

    def test_manifest_cannot_substitute_a_different_source_reference(self):
        manifest = ET.parse(self.root / 'library-inputs.xml')
        manifest.getroot()[0].set('hint', 'different reference')
        manifest.write(self.root / 'library-inputs.xml')
        self.inputs['library-inputs.xml'] = sha((self.root / 'library-inputs.xml').read_bytes())
        with self.assertRaisesRegex(ProjectError, 'do not match'):
            self.generate()

    def test_manifest_path_escape_is_rejected(self):
        manifest = ET.parse(self.root / 'library-inputs.xml')
        manifest.getroot()[0].set('staged', 'libraries/../outside.pcwlx')
        manifest.write(self.root / 'library-inputs.xml')
        self.inputs['library-inputs.xml'] = sha((self.root / 'library-inputs.xml').read_bytes())
        self.inputs['libraries/../outside.pcwlx'] = self.inputs['libraries/0000.pcwlx']
        with self.assertRaisesRegex(ProjectError, 'Unsafe manifest path'):
            self.generate()

    def test_unbound_library_manifest_is_rejected(self):
        self.inputs['library-inputs.xml'] = '0' * 64
        with self.assertRaisesRegex(ProjectError, 'Build input changed'):
            self.generate()

    def test_crc_has_independent_known_vector_and_declared_order(self):
        self.assertEqual(library_crc([b'123456789']), bytes.fromhex('010000002639f4cb'))
        self.assertEqual(library_crc([]), bytes.fromhex('0100000000000000'))
        # crc32('abc') < crc32('123456789'), so the logical byte stream is fixed.
        expected = struct.pack('<II', 1, zlib.crc32(b'abc123456789'))
        self.assertEqual(library_crc([b'123456789', b'abc']), expected)
        self.assertEqual(library_crc([b'abc', b'123456789']), expected)

    @unittest.skipUnless((REAL_JOB / 'result.json').is_file(), '61 POU frozen job unavailable')
    def test_real_61_pou_library_matches_independent_gui_native_payload(self):
        receipt = json.loads((REAL_JOB / 'result.json').read_text())
        _, members, _, _ = read_archive(REAL_JOB.parent.parent / 'revision-0000.pcwex')
        files, report = generate_native_payloads(REAL_JOB, receipt['input_hashes'], members, 'AXCF2152', '2026.0.0')
        native = files['Plc/Eclr/SharedLibraries/IIoT_Library/libIIoT_Library.so']
        self.assertEqual(sha(native), '12b5d548fe20ddef4ef709bfac998f076efde206a7e264da930e5a46f452b44d')
        self.assertEqual(len(native), 4320156)
        self.assertEqual(files['Libraries.crc'].hex(), '01000000c2744b75')
        self.assertEqual(len(report['selected_native_files']), 1)


class ManifestTests(unittest.TestCase):
    def test_manifest_hashes_exact_bytes_and_its_declared_sorted_order(self):
        files = {'z.txt': b'z', 'a.txt': b'a'}
        document = ET.fromstring(make_pcwe_manifest(files))
        entries = document.findall('./Files/File')
        self.assertEqual([n.get('path') for n in entries], ['a.txt', 'z.txt'])
        self.assertEqual([n.get('hash') for n in entries], [hashlib.sha512(files[n.get('path')]).hexdigest() for n in entries])
        overall = hashlib.sha512(''.join(n.get('hash') for n in entries).encode('ascii')).hexdigest()
        self.assertEqual(document.find('Files').get('overallHash'), overall)
        self.assertIsNone(document.find('Signature'))
        self.assertEqual(make_pcwe_manifest(files), make_pcwe_manifest(dict(reversed(list(files.items())))))

    def test_unsafe_duplicate_and_self_manifest_paths_rejected(self):
        for files in ({'../outside': b'x'}, {'a.txt': b'a', 'A.TXT': b'b'}, {'PCWE.manifest.config': b'old'}):
            with self.subTest(files=files), self.assertRaises(ProjectError):
                make_pcwe_manifest(files)


if __name__ == '__main__':
    unittest.main()
