"""Offline regression tests: no vendor assemblies, Engineer process or PLC access."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import hashlib
from pathlib import Path
import shutil
import tempfile
from threading import Barrier
import unittest
from unittest import mock
import warnings
import zipfile

from plcnext_mcp.project import ProjectError, ProjectStore, read_archive


REPOSITORY = Path(__file__).resolve().parents[1]
FROZEN = REPOSITORY / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'
TARGET = 'NG_ReadAck'
PREFIX = 'PROJECT/Logical%20Elements/NG_ReadAck.pou/'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class NativeProjectTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='plcnext-native-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'source.pcwex'
        shutil.copyfile(FROZEN, self.source)
        self.source_digest = digest(self.source)
        self.frozen_digest = digest(FROZEN)
        self.store = ProjectStore(self.root / 'workspace')
        self.imported = self.store.import_copy(str(self.source))
        self.project_id = self.imported['project_id']
        self.pou = self.store.read_pou(self.project_id, TARGET)
        self.old_text = self.pou['code'].splitlines()[0]
        self.new_text = '(* Offline native MCP test. *)\n' + self.old_text

    def tearDown(self):
        # Both the test's selected source and the repository fixture must survive
        # every positive and negative case byte for byte.
        self.assertEqual(digest(self.source), self.source_digest)
        self.assertEqual(digest(FROZEN), self.frozen_digest)

    def patch(self, **overrides):
        values = {
            'project_id': self.project_id,
            'pou_name': TARGET,
            'expected_project_sha256': self.pou['project_sha256'],
            'expected_code_sha256': self.pou['code_sha256'],
            'old_text': self.old_text,
            'new_text': self.new_text,
        }
        values.update(overrides)
        return self.store.patch_st(**values)

    def revision_files(self):
        return sorted((self.store.root / self.project_id).glob('revision-*.pcwex'))

    def test_import_is_a_frozen_copy_and_never_claims_compilation(self):
        self.assertTrue(self.imported['source_untouched'])
        self.assertFalse(self.imported['compiled'])
        self.assertEqual(self.imported['revision'], 0)
        self.assertEqual(Path(self.imported['project_path']).read_bytes(), self.source.read_bytes())
        self.assertEqual((self.store.root / self.project_id / 'original.pcwex').read_bytes(), self.source.read_bytes())
        inspected = self.store.inspect(self.project_id)
        self.assertEqual(len(inspected['pous']), 31)
        self.assertFalse(inspected['aci_used'])
        self.assertFalse(inspected['compiled'])

    def test_only_selected_st_payload_changes_and_all_ids_mappings_survive(self):
        before = self.store.inspect(self.project_id)
        references = self.store.references(self.project_id, TARGET)
        patched = self.patch()
        after = self.store.inspect(self.project_id)
        _, source_members, source_infos, source_comment = read_archive(self.source)
        _, result_members, result_infos, result_comment = read_archive(Path(patched['project_path']))
        changed = [name for name in source_members if source_members[name] != result_members[name]]
        self.assertEqual(set(result_members), set(source_members))
        self.assertEqual(changed, [PREFIX + 'Code.st'])
        self.assertEqual(before['pous'], after['pous'])
        self.assertEqual(before['mapping_members'], after['mapping_members'])
        self.assertEqual(source_comment, result_comment)
        self.assertEqual([i.filename for i in source_infos], [i.filename for i in result_infos])
        self.assertEqual(references, self.store.references(self.project_id, TARGET))
        self.assertIn({'caller': 'Main', 'instance': 'AckReader'}, [
            {'caller': item['caller'], 'instance': item['instance']} for item in references['instances']
        ])
        self.assertEqual(patched['revision'], 1)
        self.assertFalse(patched['compiled'])
        self.assertFalse(patched['aci_used'])
        validated = self.store.validate(self.project_id)
        self.assertTrue(validated['preservation_passed'])
        self.assertEqual(validated['changed_members'], changed)
        self.assertEqual(validated['unexpected_members'], [])
        self.assertEqual(validated['checked_unchanged_members'], len(source_members) - 1)
        self.assertFalse(validated['controller_connected'])

    def test_unmodified_validation_and_diff_are_empty(self):
        validated = self.store.validate(self.project_id)
        self.assertTrue(validated['preservation_passed'])
        self.assertEqual(validated['changed_members'], [])
        self.assertEqual(self.store.diff(self.project_id, TARGET)['diff'], '')

    def test_diff_reports_real_patch_and_can_be_bounded(self):
        self.patch()
        full = self.store.diff(self.project_id, TARGET)
        self.assertIn('+(* Offline native MCP test. *)', full['diff'])
        self.assertFalse(full['compiled'])
        bounded = self.store.diff(self.project_id, TARGET, max_chars=10)
        self.assertEqual(len(bounded['diff']), 10)
        self.assertTrue(bounded['truncated'])
        with self.assertRaises(ProjectError):
            self.store.diff(self.project_id, TARGET, max_chars=64001)

    def test_stale_project_hash_rejected_without_extra_revision(self):
        self.patch()
        with self.assertRaisesRegex(ProjectError, 'Stale project'):
            self.patch()
        self.assertEqual(len(self.revision_files()), 2)

    def test_stale_code_hash_rejected_without_revision(self):
        with self.assertRaisesRegex(ProjectError, 'Stale worksheet'):
            self.patch(expected_code_sha256='0' * 64)
        self.assertEqual(len(self.revision_files()), 1)

    def test_bad_patch_requests_leave_no_revision_or_lock(self):
        for overrides in (
            {'old_text': ''},
            {'old_text': 'not present'},
            {'new_text': self.old_text},
            {'new_text': "'unterminated string"},
            {'new_text': '(* unterminated comment'},
        ):
            with self.subTest(overrides=overrides):
                with self.assertRaises(ProjectError):
                    self.patch(**overrides)
                self.assertEqual(len(self.revision_files()), 1)
                self.assertFalse((self.store.root / self.project_id / '.edit.lock').exists())

    def test_active_edit_lock_rejected_and_existing_lock_retained(self):
        lock = self.store.root / self.project_id / '.edit.lock'
        lock.write_text('other writer', encoding='utf-8')
        with self.assertRaisesRegex(ProjectError, 'being edited'):
            self.patch()
        self.assertTrue(lock.exists())
        self.assertEqual(len(self.revision_files()), 1)

    def test_competing_edits_commit_only_one_revision(self):
        barrier = Barrier(2)

        def compete():
            barrier.wait(timeout=10)
            try:
                return self.patch()
            except ProjectError as error:
                return error

        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda _: compete(), range(2)))
        self.assertEqual(sum(isinstance(result, dict) for result in results), 1)
        self.assertEqual(sum(isinstance(result, ProjectError) for result in results), 1)
        self.assertEqual(len(self.revision_files()), 2)
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_manifest_write_failure_leaves_old_revision_and_retry_succeeds(self):
        with mock.patch.object(self.store, '_save_manifest', side_effect=OSError('injected disk failure')):
            with self.assertRaisesRegex(OSError, 'injected disk failure'):
                self.patch()
        after_failure = self.store.read_pou(self.project_id, TARGET)
        self.assertEqual(after_failure['revision'], 0)
        self.assertEqual(after_failure['code'], self.pou['code'])
        self.assertEqual(after_failure['project_sha256'], self.pou['project_sha256'])
        self.assertEqual(len(self.revision_files()), 1)
        self.assertFalse((self.store.root / self.project_id / '.edit.lock').exists())
        retried = self.patch()
        self.assertEqual(retried['revision'], 1)
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_existing_orphan_revision_is_not_overwritten_or_permanent_blocker(self):
        orphan = self.store.root / self.project_id / 'revision-0001.pcwex'
        orphan.write_bytes(b'orphan from an interrupted process')
        result = self.patch()
        self.assertEqual(orphan.read_bytes(), b'orphan from an interrupted process')
        self.assertEqual(result['revision'], 2)
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_external_revision_modification_detected(self):
        current = Path(self.imported['project_path'])
        current.write_bytes(current.read_bytes() + b'external change')
        with self.assertRaisesRegex(ProjectError, 'outside MCP'):
            self.store.inspect(self.project_id)
        with self.assertRaisesRegex(ProjectError, 'outside MCP'):
            self.patch()

    def test_external_frozen_copy_modification_detected(self):
        original = self.store.root / self.project_id / 'original.pcwex'
        original.write_bytes(original.read_bytes() + b'external change')
        with self.assertRaisesRegex(ProjectError, 'Frozen original'):
            self.store.validate(self.project_id)

    def test_build_plan_requires_engineer_and_reports_no_compilation(self):
        plan = self.store.build_plan(self.project_id)
        self.assertEqual(plan['status'], 'engineer_rebuild_required')
        self.assertFalse(plan['compiled'])
        self.assertFalse(plan['aci_used'])
        self.assertIn('do not use Write and Start', ' '.join(plan['steps']))

    def test_invalid_project_ids_cannot_select_other_directories(self):
        for invalid in ('../source', '0' * 31, 'a' * 32, 'F' * 32, ''):
            with self.subTest(project_id=invalid):
                with self.assertRaises(ProjectError):
                    self.store.inspect(invalid)


class ArchiveInputTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='plcnext-archive-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def archive(self, members: list[tuple[str, bytes]]) -> Path:
        path = self.root / 'test.pcwex'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with zipfile.ZipFile(path, 'w') as zipped:
                for name, data in members:
                    info = zipfile.ZipInfo('placeholder')
                    # Assignment after construction preserves hostile raw names;
                    # ZipInfo otherwise normalizes backslashes on Windows.
                    info.filename = name
                    zipped.writestr(info, data)
        return path

    def test_unsafe_and_duplicate_archive_paths_rejected(self):
        for names in (
            ['../../outside'], ['/absolute'], ['C:/outside'], ['folder\\outside'],
            ['same', 'same'], ['Case', 'case'], ['safe\x00outside'],
        ):
            with self.subTest(names=names):
                path = self.archive([(name, b'data') for name in names])
                with self.assertRaisesRegex(ProjectError, 'Unsafe or duplicate'):
                    read_archive(path)

    def test_patch_preserves_bom_newlines_member_metadata_and_comment(self):
        path = self.root / 'bom.pcwex'
        code = b'\xef\xbb\xbfvalue := 1;\r\nother := 2;\r\n'
        metadata = b'<FunctionBlock><Kind>FunctionBlock</Kind><Id>test-id</Id></FunctionBlock>'
        with zipfile.ZipFile(path, 'w') as zipped:
            zipped.comment = b'archive-comment'
            info = zipfile.ZipInfo(PREFIX + 'Code.st', date_time=(2020, 1, 2, 3, 4, 6))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.comment = b'member-comment'
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, code)
            zipped.writestr(PREFIX + 'Metadata.meta', metadata)
            zipped.writestr('opaque/payload.bin', b'\x00\xffopaque')
        store = ProjectStore(self.root / 'workspace')
        imported = store.import_copy(str(path))
        original = store.read_pou(imported['project_id'], TARGET)
        result = store.patch_st(imported['project_id'], TARGET, original['project_sha256'],
                                original['code_sha256'], 'value := 1;', 'value := 3;')
        with zipfile.ZipFile(result['project_path']) as zipped:
            self.assertEqual(zipped.read(PREFIX + 'Code.st'), code.replace(b'1;', b'3;', 1))
            self.assertEqual(zipped.read('opaque/payload.bin'), b'\x00\xffopaque')
            self.assertEqual(zipped.comment, b'archive-comment')
            actual = zipped.getinfo(PREFIX + 'Code.st')
            self.assertEqual(actual.date_time, info.date_time)
            self.assertEqual(actual.comment, info.comment)
            self.assertEqual(actual.compress_type, info.compress_type)
            self.assertEqual(actual.external_attr, info.external_attr)


if __name__ == '__main__':
    unittest.main()
