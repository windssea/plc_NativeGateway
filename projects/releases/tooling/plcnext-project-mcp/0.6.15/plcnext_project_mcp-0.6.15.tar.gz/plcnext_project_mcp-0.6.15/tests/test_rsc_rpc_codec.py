"""Original complete v4 formatter vectors and bounded profile refusal tests."""
import hashlib
import json
from pathlib import Path
import struct
import unittest

from plcnext_mcp import rsc_rpc_codec as rpc
from plcnext_mcp.rsc_codec import CommandHeader, encode_header, decode_header, AuthenticationError

ORACLE = Path(__file__).resolve().parents[1] / 'artifacts/plc-download-research/auth/rpc-oracle-06'


class RscRpcTests(unittest.TestCase):
    def test_original_full_rpc_request_response_vectors(self):
        self.assertTrue(ORACLE.is_dir(), 'Recorded original pure RPC oracle required')
        report = json.loads((ORACLE / 'report.json').read_text(encoding='utf-8-sig'))
        generated = {
            'connect': rpc.encode_connect_request(),
            'connect-confirmation': rpc.encode_connect_confirmation(),
            'getservice': rpc.encode_get_service('Arp', 'Arp.System.Security.Services.IPasswordAuthenticationService'),
            'getservice-confirmation': rpc.encode_get_service_confirmation(41, 5),
            'create-session-request': rpc.encode_request(41, 1,
                rpc.encode_create_session('offline-user', 'offline-fixture-only'), provider_handle=5),
            'close-session-request': rpc.encode_request(41, 2, rpc.encode_close_session(0), 0, 5),
            'create-session-response-success': rpc.encode_response(41, 1,
                rpc.encode_create_session_result(0, 0, 0), provider_handle=5),
            'create-session-response-invalid-credentials': rpc.encode_response(41, 1,
                rpc.encode_create_session_result(0, 250, AuthenticationError.INVALID_CREDENTIALS), provider_handle=5),
            'create-session-response-penalty-active': rpc.encode_response(41, 1,
                rpc.encode_create_session_result(0, 500, AuthenticationError.PENALTY_DELAY_ACTIVE), provider_handle=5),
            'close-session-response': rpc.encode_response(41, 2, b'', provider_handle=5),
        }
        # The old error fixture manually chose UTF16 and was not the actual
        # MarshalType1 error profile. Keep it as historical data, superseded by
        # the new direct original Serialize/Deserialize ERROR oracle below.
        vectors = [v for v in report['vectors'] if v['name'] != 'server-error-response']
        self.assertEqual(set(generated), {v['name'] for v in vectors})
        for vector in vectors:
            with self.subTest(name=vector['name']):
                original = (ORACLE / vector['file']).read_bytes()
                self.assertEqual(hashlib.sha256(original).hexdigest(), vector['sha256'])
                self.assertEqual(generated[vector['name']], original)

    def test_original_untagged_error_utf8_empty_ascii_and_chinese(self):
        original = Path(__file__).resolve().parents[1] / 'artifacts/rsc-error-control/untagged-oracle-01/report.json'
        report = json.loads(original.read_text(encoding='utf-8-sig'))
        count = 0
        for vector in report['vectors']:
            details = vector['details']
            if not vector['name'].startswith('error-') or details['fatal'] or details['arguments']:
                continue
            count += 1
            raw = bytes.fromhex(vector['hex'])
            self.assertEqual(hashlib.sha256(raw).hexdigest(), vector['sha256'])
            header, _ = decode_header(raw[:16], require_checksum=True)
            self.assertTrue(details['original_reader_consumed_all'])
            self.assertEqual(rpc.decode_server_error(raw), (details['code'], details['message']))
            self.assertEqual(rpc.encode_server_error(header.service_handle, header.method_handle,
                details['code'], details['message'], header.service_provider_handle), raw)
        self.assertEqual(count, 3)

    def test_connect_advertisement_requires_bounded_confirmation(self):
        self.assertEqual(rpc.decode_connect(rpc.encode_connect_request()).flags, 0xc0)
        self.assertEqual(rpc.decode_connect(rpc.encode_connect_confirmation(), True).flags, 0)
        with self.assertRaises(ValueError):
            rpc.decode_connect(encode_header(CommandHeader(command_type=8, flags=0xc0)), True)

    def test_service_handles_are_discovered_not_fixed(self):
        self.assertEqual(rpc.decode_get_service(rpc.encode_get_service('Arp', 'Service')), ('Arp', 'Service'))
        for service, provider in ((1, 2), (32767, 19), (71, 43)):
            self.assertEqual(rpc.decode_get_service_confirmation(
                rpc.encode_get_service_confirmation(service, provider)), (service, provider))

    def test_service_names_reject_ambiguous_lengths_and_trailing_data(self):
        for name in ('', '含多字节', 'embedded\x00name'):
            with self.assertRaises(ValueError):
                rpc.encode_get_service('Arp', name)
        with self.assertRaises(ValueError):
            rpc.decode_get_service(rpc.encode_get_service('Arp', 'Service') + b'junk')

    def test_zero_token_in_request_and_body_preserved(self):
        body = rpc.encode_close_session(0)
        header, token, actual = rpc.decode_request(rpc.encode_request(34, 2, body, 0, 5))
        self.assertEqual((header.service_handle, header.method_handle, header.service_provider_handle), (34, 2, 5))
        self.assertEqual(token, 0)
        self.assertEqual(rpc.decode_close_session(actual), 0)
        self.assertIsNone(rpc.decode_request(rpc.encode_request(34, 2, body, None, 5))[1])

    def test_authentication_schema_consumes_exact_utf8_values(self):
        # Unicode value encoding is bounded/strict, distinct from the ASCII
        # service-name profile. Actual complete oracle uses fixture ASCII.
        body = rpc.encode_create_session('offline-user', 'offline-fixture-only')
        self.assertEqual(rpc.decode_create_session(body), ('offline-user', 'offline-fixture-only'))
        self.assertEqual(body[:2], struct.pack('<H', 13))
        for malformed in (body[:-1], body + b'x', b'\xff\xffx'):
            with self.assertRaises(ValueError):
                rpc.decode_create_session(malformed)
        for username, password in [('x'*64, 'p'), ('u', 'p'*128), ('u\0', 'p')]:
            with self.assertRaises(ValueError):
                rpc.encode_create_session(username, password)

    def test_authentication_out_arguments_precede_return(self):
        body = rpc.encode_create_session_result(0x12345678, 250, -1)
        self.assertEqual(body, bytes.fromhex('0978563412fa000000ffffffff'))
        self.assertEqual(rpc.decode_create_session_result(body), (0x12345678, 250, -1))
        for malformed in (body[:-1], body+b'x', b'\x08'+body[1:]):
            with self.assertRaises(ValueError):
                rpc.decode_create_session_result(malformed)

    def test_unimplemented_null_token_and_bad_values_rejected(self):
        for token in (None, True, -1, 2**32):
            with self.assertRaises(ValueError):
                rpc.encode_create_session_result(token, 0, 0)
        for penalty, error in ((-1, 0), (0, -7), (0, 1)):
            with self.assertRaises(ValueError):
                rpc.encode_create_session_result(0, penalty, error)

    def test_untagged_no_datagram_profile_is_enforced(self):
        for flags in (0x40, 0x80, 0xc0):
            packet = encode_header(CommandHeader(flags=flags, service_handle=1, method_handle=1))
            with self.assertRaises(ValueError):
                rpc.decode_request(packet)
        with self.assertRaises(ValueError):
            rpc.decode_request(encode_header(CommandHeader(version=3, service_handle=1, method_handle=1)))
        with self.assertRaises(ValueError):
            rpc.decode_request(encode_header(CommandHeader(data_length=5, service_handle=1, method_handle=1))+b'12345')

    def test_truncated_wrong_command_or_corrupted_headers_rejected(self):
        request = rpc.encode_request(1, 1, b'')
        corrupted = bytearray(request); corrupted[8] ^= 1
        for packet in (b'', request[:-1], bytes(corrupted), rpc.encode_response(1, 1, b'')):
            with self.assertRaises(ValueError):
                rpc.decode_request(packet)

    def test_measured_server_error_and_unknown_error_arguments(self):
        packet = rpc.encode_server_error(41, 1, 65537, 'offline error', 5)
        self.assertEqual(rpc.decode_server_error(packet), (65537, 'offline error'))
        with self.assertRaises(ValueError):
            rpc.decode_server_error(packet[:-4] + struct.pack('<i', 1))
        with self.assertRaises(ValueError):
            rpc.encode_server_error(41, 1, 0x80000000, 'unsupported fatal profile', 5)


if __name__ == '__main__':
    unittest.main()
