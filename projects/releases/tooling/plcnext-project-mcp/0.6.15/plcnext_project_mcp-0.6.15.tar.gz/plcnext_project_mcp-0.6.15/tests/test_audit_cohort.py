import json,time
from pathlib import Path
import unittest
from unittest.mock import patch
import test_audit_export as fixtures
from plcnext_mcp.audit_collector import Exporter,EvidenceError
from plcnext_mcp.audit_cohort import SourceCohort,close_source_window

class CohortTests(unittest.TestCase):
    setUp=fixtures.AuditTests.setUp
    client=fixtures.AuditTests.client
    def setup_export(self):
        values=self.fixture.values
        for seq in (2,3):
            prefix='CaptureBuffer.AuditEvents[1].'
            values.update({f'CaptureBuffer.AuditEvents[{seq}].'+k[len(prefix):]:v for k,v in list(values.items()) if k.startswith(prefix)})
            values[f'CaptureBuffer.AuditEvents[{seq}].Event.SampleSeq']=seq
        prefix='CaptureBuffer.Associations[1].'
        values.update({prefix+k:v for k,v in {'Ordinal':1,'MessageId':'batch','Digest':'a'*64,'Count':2,
            'ConfigSlot':1,'ConfigGeneration':7,'BatchGeneration':1,'Category':2,'SampleSeqs[1]':1,'SampleSeqs[2]':2}.items()})
        client,peer=self.client();ex=Exporter(client,self.journal);ex.cohort=SourceCohort();ex.poll()
        return ex,peer
    def test_delayed_mixed_batch_keeps_fixed_denominator_and_whole_association(self):
        ex,peer=self.setup_export();ticks=0
        def check():
            nonlocal ticks
            ticks+=1
            # SourceBoundary was fsynced at N=1. Continue input, same value/UTC.
            peer.model.values['CaptureBuffer.AuditWriteSeq']=2
            if ticks>=2:peer.model.values['CaptureBuffer.AssociationWriteSeq']=1
        result=close_source_window(ex,{'tail_seconds':1,'poll_interval_ms':20},time.monotonic()+2,check)
        self.assertEqual(result['source_boundary'],1);self.assertEqual(result['admitted_source_count'],1)
        self.assertEqual(result['associated_source_count'],1);self.assertEqual(result['outside_source_capture_range'],[2,2])
        self.assertTrue(result['source_cohort_associations_complete'])
        rows=[json.loads(l) for l in (self.root/'events.jsonl').read_text().splitlines()]
        assoc=next(r for r in rows if r['kind']=='association')
        self.assertEqual(assoc['association']['sampleSeqs'],[1,2]);self.assertEqual(assoc['association']['Digest'],'a'*64)
        self.assertFalse(any('complete_through_tail' in r for r in rows))
    def test_missing_association_deadline_preserves_denominator(self):
        ex,peer=self.setup_export()
        with self.assertRaisesRegex(EvidenceError,'deadline'):
            close_source_window(ex,{'tail_seconds':.04,'poll_interval_ms':20},time.monotonic()+1,lambda:None)
        r=ex.cohort.report(ex.capture,ex.association)
        self.assertEqual(r['source_boundary'],1);self.assertEqual(r['unassociated_source_seqs'],[1])
        self.assertTrue(r['raw_prefix_complete']);self.assertFalse(r['source_cohort_associations_complete'])
    def test_bad_generation_and_duplicate_reference_send_no_association_ack(self):
        ex,peer=self.setup_export();peer.model.values['CaptureBuffer.AuditWriteSeq']=2
        peer.model.values['CaptureBuffer.AssociationWriteSeq']=1
        peer.model.values['CaptureBuffer.Associations[1].ConfigGeneration']=8
        with self.assertRaises(EvidenceError):ex.poll()
        self.assertFalse(any('AssociationAck' in name for name in peer.field_writes))
        peer.model.values['CaptureBuffer.Associations[1].ConfigGeneration']=7
        peer.model.values['CaptureBuffer.Associations[1].SampleSeqs[2]']=1
        with self.assertRaises(EvidenceError):ex.poll()
    def test_closure_fsync_failure_cancel_and_overflow(self):
        ex,peer=self.setup_export();peer.model.values['CaptureBuffer.AuditWriteSeq']=2
        with patch('plcnext_mcp.audit_collector.os.fsync',side_effect=OSError('disk full')):
            with self.assertRaises(OSError):ex.poll()
        self.assertEqual(ex.cohort.report(1,0)['exported_capture_end'],1)
        peer.model.values['CaptureBuffer.AuditDropped']=1
        with self.assertRaises(EvidenceError):ex.poll()
    def test_frozen_boot69_remains_six_short(self):
        frozen=json.loads((Path(__file__).parent/'fixtures/boot69-source-cohort.json').read_text(encoding='utf-8'))
        t=SourceCohort();t.accept([r for r in frozen['rows'] if r['kind']=='capture']+[r for r in frozen['rows'] if r['kind']=='association'],commit=True);t.freeze(frozen['source_boundary'])
        result=t.report(1758,47)
        self.assertEqual(result['admitted_source_count'],1050)
        self.assertEqual(result['associated_source_count'],1044)
        self.assertEqual(len(result['unassociated_source_seqs']),6)
        self.assertFalse(result['source_cohort_associations_complete'])

    def test_cancel_and_record_limit_leave_exact_missing_source(self):
        ex,peer=self.setup_export()
        def cancelled():raise EvidenceError('cancelled')
        with self.assertRaisesRegex(EvidenceError,'cancelled'):
            close_source_window(ex,{'tail_seconds':1,'poll_interval_ms':20},time.monotonic()+2,cancelled)
        self.assertEqual(ex.cohort.report(1,0)['unassociated_source_seqs'],[1])
        self.journal.max_records=self.journal.records
        peer.model.values['CaptureBuffer.AuditWriteSeq']=2
        with self.assertRaises(EvidenceError):ex.poll()
        self.assertNotIn(2,ex.cohort.captures)
    def test_unknown_commit_does_not_claim_cohort_complete(self):
        ex,peer=self.setup_export();peer.profile_fault='commit_reply_lost'
        peer.model.values['CaptureBuffer.AuditWriteSeq']=2;peer.model.values['CaptureBuffer.AssociationWriteSeq']=1
        with self.assertRaises(Exception):
            close_source_window(ex,{'tail_seconds':1,'poll_interval_ms':20},time.monotonic()+2,lambda:None)
        self.assertTrue(ex.io.ack_unknown)
        self.assertFalse(ex.cohort.report(self.journal.durable['Audit'],self.journal.durable['Association'])['source_cohort_associations_complete'])
