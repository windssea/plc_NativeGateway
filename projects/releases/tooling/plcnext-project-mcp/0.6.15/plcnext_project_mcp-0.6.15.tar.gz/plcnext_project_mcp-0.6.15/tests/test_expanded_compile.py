"""NativeGateway source manifest and unsupported-member guards, without vendor execution."""
from pathlib import Path
import tempfile
import subprocess
import unittest
from unittest import mock
import xml.etree.ElementTree as ET
import zipfile

from plcnext_mcp.expanded_compile import (_project_snapshot, _cold_project_snapshot, _stage_libraries,
                                         _write_sources, compile_nativegateway)
from plcnext_mcp.project import ProjectError, ProjectStore, read_archive, sha


ROOT = Path(__file__).resolve().parents[1]


class ExpandedSourceGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore(self.root / 'projects')
        self.project = self.store.import_copy(str(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'))
        self.pid = self.project['project_id']

    def test_stale_compile_never_starts_host(self):
        with mock.patch('plcnext_mcp.expanded_compile.subprocess.run') as run:
            with self.assertRaisesRegex(ProjectError, 'Stale project'):
                compile_nativegateway(self.store, self.pid, '0' * 64)
            run.assert_not_called()

    def test_complete_manifest_has_all_code_interfaces_and_metadata(self):
        identity, members, index = _project_snapshot(self.store, self.pid, self.project['project_sha256'])
        job = self.root / 'job'
        job.mkdir()
        hashes = _write_sources(job, members, index)
        self.assertEqual(identity['pou_count'], 31)
        self.assertEqual(len(hashes), 31 * 3 + 1)
        nodes = ET.parse(job / 'sources.xml').getroot().findall('POU')
        self.assertEqual({n.attrib['name'] for n in nodes}, set(index))
        for node in nodes:
            for key in ('code', 'variables', 'metadata'):
                payload = (job / node.attrib[key]).read_bytes()
                self.assertEqual(sha(payload), node.attrib[key + '_sha256'])

    def test_variable_and_callsite_batch_is_supported_by_snapshot(self):
        updates = []
        for name in ('NG_ReadAck', 'Main'):
            pou = self.store.read_pou(self.pid, name)
            updates.append({'pou_name': name, 'expected_code_sha256': pou['code_sha256'],
                'expected_variables_sha256': pou['variables_sha256'],
                'variables': pou['variables'] + '\nVAR\nMcpProbe : BOOL;\nEND_VAR\n',
                'code': 'McpProbe := TRUE;\n' + pou['code']})
        changed = self.store.update_pous(self.pid, self.project['project_sha256'], updates)
        identity, _, _ = _project_snapshot(self.store, self.pid, changed['project_sha256'])
        self.assertEqual(len(identity['changed_source_members']), 4)

    def test_hidden_metadata_change_is_rejected_even_if_manifest_hash_is_updated(self):
        path = Path(self.project['project_path'])
        _, members, infos, comment = read_archive(path)
        target = 'PROJECT/Logical%20Elements/NG_ReadAck.pou/Metadata.meta'
        members[target] += b'\n'
        with zipfile.ZipFile(path, 'w') as archive:
            archive.comment = comment
            for info in infos:
                archive.writestr(info, members[info.filename])
        folder, manifest = self.store._load(self.pid)
        manifest['current_sha256'] = sha(path.read_bytes())
        self.store._save_manifest(folder, manifest)
        with self.assertRaisesRegex(ProjectError, 'Only existing POU'):
            _project_snapshot(self.store, self.pid, manifest['current_sha256'])

    def test_cold_build_never_looks_up_an_ast_seed(self):
        def run(command, **options):
            import json
            self.assertIn('-ColdProject', command)
            self.assertEqual(options['timeout'], 30)
            job = Path(command[command.index('-WorkRoot') + 1])
            self.assertFalse((job / 'input/LastBuild.ast').exists())
            self.assertFalse(list((job / 'references').iterdir()))
            self.assertTrue((job / 'project/PROJECT/PROJECT.proj').is_file())
            self.assertEqual(len(ET.parse(job / 'sources.xml').getroot().findall('POU')), 31)
            digest = sha((job / 'sources.xml').read_bytes())
            (job / 'host-result.json').write_text(json.dumps({'status': 'library_failed',
                'source_sha256': digest, 'source_sha256_after': digest}))
            return subprocess.CompletedProcess(command, 0, b'', b'')
        with mock.patch('plcnext_mcp.expanded_compile._verified_seed', side_effect=AssertionError('Seed access forbidden')) as seed:
            with mock.patch('plcnext_mcp.expanded_compile.shutil.which', return_value='pwsh'):
                with mock.patch('plcnext_mcp.expanded_compile.subprocess.run', side_effect=run) as execute:
                    result = compile_nativegateway(self.store, self.pid, self.project['project_sha256'], cold=True)
        seed.assert_not_called()
        self.assertEqual(execute.call_count, 1)
        self.assertFalse(result['compiled'])
        self.assertFalse(result['cache_assisted'])
        self.assertFalse(result['ast_seed_used'])
        self.assertEqual(result['stage'], 'libraries')

    def test_corrupted_source_snapshot_stops_before_backend(self):
        def run(command, **options):
            import json
            job = Path(command[command.index('-WorkRoot') + 1])
            digest = sha((job / 'sources.xml').read_bytes())
            (job / 'sources/NG_ReadAck/Variables.var').write_bytes(b'changed input')
            (job / 'host-result.json').write_text(json.dumps({'status': 'cil_generated',
                'source_sha256': digest, 'source_sha256_after': digest, 'pous_reparsed': 31,
                'interfaces_reparsed': 31}))
            return subprocess.CompletedProcess(command, 0, b'', b'')
        with mock.patch('plcnext_mcp.expanded_compile.shutil.which', return_value='pwsh'):
            with mock.patch('plcnext_mcp.expanded_compile.subprocess.run', side_effect=run) as execute:
                result = compile_nativegateway(self.store, self.pid, self.project['project_sha256'], cold=True)
        self.assertEqual(execute.call_count, 1)
        self.assertFalse(result['compiled'])
        self.assertEqual(result['status'], 'host_input_mismatch')
        self.assertFalse(result['iec_model_rebuilt_from_sources'])

    def import_variant(self, change, name='Independent.pcwex'):
        _, members, _, _ = read_archive(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex')
        members = change(members)
        path = self.root / name
        with zipfile.ZipFile(path, 'w') as archive:
            for member, payload in members.items():
                archive.writestr(member, payload)
        return self.store.import_copy(str(path))

    def test_independent_original_with_dynamic_resource_is_supported(self):
        old = 'RES_23CA7F267545404C9FED5DC977A6399F'
        new = 'RES_Independent'
        def change(members):
            return {p.replace(old, new): data.replace(old.encode(), new.encode()) for p, data in members.items()}
        project = self.import_variant(change)
        identity, _, index = _cold_project_snapshot(self.store, project['project_id'], project['project_sha256'])
        self.assertEqual(identity['resource_name'], new)
        self.assertEqual(identity['application_name'], 'Independent')
        self.assertEqual(len(index), 31)
        self.assertIn(new + '.exe', identity['required_application_cil'])
        self.assertNotIn(old + '.exe', identity['required_application_cil'])
        with self.assertRaisesRegex(ProjectError, 'frozen NativeGateway'):
            _project_snapshot(self.store, project['project_id'], project['project_sha256'])

    def test_independent_pou_inventory_is_not_fixed_to_31(self):
        def change(members):
            members = {p: d for p, d in members.items() if '.pou/' not in p or '/Main.pou/' in p}
            project = ET.fromstring(members['PROJECT/PROJECT.proj'])
            for parent in project.iter():
                for node in list(parent):
                    values = {c.tag.rsplit('}', 1)[-1]: c.text for c in node}
                    if (node.tag.rsplit('}', 1)[-1] == 'Folder' and values.get('FolderType') == 'PouFolder'
                            and not node.get('Include', '').replace('\\', '/').endswith('/Main.pou')):
                        parent.remove(node)
            members['PROJECT/PROJECT.proj'] = ET.tostring(project, encoding='utf-8')
            return members
        project = self.import_variant(change)
        identity, _, index = _cold_project_snapshot(self.store, project['project_id'], project['project_sha256'])
        self.assertEqual(list(index), ['Main'])
        self.assertEqual(identity['pou_count'], 1)

    def test_integrity_gate_rejects_hidden_edit_before_host(self):
        with mock.patch.object(self.store, 'validate', return_value={'preservation_passed': False}):
            with mock.patch('plcnext_mcp.expanded_compile.subprocess.run') as run:
                with self.assertRaisesRegex(ProjectError, 'integrity validation'):
                    compile_nativegateway(self.store, self.pid, self.project['project_sha256'], cold=True)
                run.assert_not_called()

    def test_wrong_device_and_duplicate_task_identities_are_explicitly_rejected(self):
        def wrong_device(members):
            members['PROJECT/PROJECT.proj'] = members['PROJECT/PROJECT.proj'].replace(b'AXC F 2152', b'AXC F 1152')
            return members
        project = self.import_variant(wrong_device)
        with self.assertRaisesRegex(ProjectError, 'Unsupported device/profile'):
            _cold_project_snapshot(self.store, project['project_id'], project['project_sha256'])
        def another_task(members):
            for path in members:
                if path.endswith('EsmConfiguration.esmc'):
                    node = ET.fromstring(members[path])
                    task = next(node.iter('Task'))
                    task_parent = next(p for p in node.iter() if task in list(p))
                    task_parent.append(ET.fromstring(ET.tostring(task)))
                    members[path] = ET.tostring(node)
            return members
        project = self.import_variant(another_task, 'TwoTasks.pcwex')
        with self.assertRaisesRegex(ProjectError, 'Duplicate ESM/task/program instance identity'):
            _cold_project_snapshot(self.store, project['project_id'], project['project_sha256'])

    def test_decoded_pou_traversal_and_reserved_name_rejected(self):
        for name in ('bad%2f..%2fescape', 'CON', 'Bad%5cName'):
            with self.subTest(name=name):
                def change(members):
                    return {p.replace('/NG_ReadAck.pou/', '/' + name + '.pou/'): d for p, d in members.items()}
                project = self.import_variant(change)
                with self.assertRaisesRegex(ProjectError, 'Unsupported'):
                    _cold_project_snapshot(self.store, project['project_id'], project['project_sha256'])

    def test_unicode_display_name_gets_stable_safe_backend_identifier(self):
        project = self.import_variant(lambda x: x, '我的 工程.pcwex')
        identity, _, _ = _cold_project_snapshot(self.store, project['project_id'], project['project_sha256'])
        self.assertEqual(identity['project_display_name'], '我的 工程')
        self.assertRegex(identity['application_name'], r'^Project_[0-9a-f]{12}$')
        self.assertNotIn('\n', identity['application_name'])

    def test_relative_library_paths_are_resolved_against_original_source(self):
        _, members, _, _ = read_archive(Path(self.project['project_path']))
        document = ET.fromstring(members['PROJECT/PROJECT.proj'])
        for entry in list(document):
            for child in list(entry):
                if child.tag.endswith('SolutionReference'):
                    entry.remove(child)
        ns = '{http://schemas.microsoft.com/developer/msbuild/2003}'
        group = ET.SubElement(document, ns + 'ItemGroup')
        reference = ET.SubElement(group, ns + 'SolutionReference', Include='Custom')
        ET.SubElement(reference, ns + 'HintPath').text = r'reference\Custom.pcwlx'
        members['PROJECT/PROJECT.proj'] = ET.tostring(document)
        library = self.root / 'reference/Custom.pcwlx'
        library.parent.mkdir()
        library.write_bytes(b'library snapshot')
        job = self.root / 'relative-job'
        job.mkdir()
        hashes = _stage_libraries(job, members, {'source_path': str(self.root / 'Independent.pcwex')}, self.root / 'install')
        self.assertEqual((job / 'libraries/0000.pcwlx').read_bytes(), library.read_bytes())
        record = ET.parse(job / 'library-inputs.xml').getroot().find('Library')
        self.assertEqual(record.attrib['source'], str(library))
        self.assertEqual(record.attrib['sha256'], hashes['libraries/0000.pcwlx'])
        ET.SubElement(group, ns + 'SolutionReference', Include='Bad')
        ET.SubElement(group[-1], ns + 'HintPath').text = '$(Unknown)/foo.pcwlx'
        members['PROJECT/PROJECT.proj'] = ET.tostring(document)
        with self.assertRaisesRegex(ProjectError, 'Unsupported library HintPath macro'):
            _stage_libraries(job, members, {'source_path': str(self.root / 'Independent.pcwex')}, self.root / 'install')

    def test_unreferenced_pou_dll_can_be_omitted_after_all_sources_are_checked(self):
        identity, _, _ = _cold_project_snapshot(self.store, self.pid, self.project['project_sha256'])
        resource = identity['resource_name']
        def run(command, **options):
            import json
            if '-WorkRoot' in command:
                job = Path(command[command.index('-WorkRoot') + 1])
                digest = sha((job / 'sources.xml').read_bytes())
                generated = job / 'generated'
                generated.mkdir()
                for name in identity['required_application_cil']:
                    (generated / name).write_bytes(b'newly generated test CIL')
                (job / 'host-result.json').write_text(json.dumps({'status': 'cil_generated',
                    'source_sha256': digest, 'source_sha256_after': digest, 'pous_reparsed': 31,
                    'interfaces_reparsed': 31, 'resource_name': resource,
                    'semantic': {'errors': 0, 'warnings': 1, 'messages': [{'type_id': 'SEM2005'}]}}))
            else:
                generated = Path(options['cwd'])
                self.assertIn('-exename ' + resource, (generated / 'cilc.opt').read_text())
                (generated / (resource + '.img')).write_bytes(b'new test image')
            return subprocess.CompletedProcess(command, 0, b'', b'')
        with mock.patch('plcnext_mcp.expanded_compile.shutil.which', return_value='pwsh'):
            with mock.patch('plcnext_mcp.expanded_compile.subprocess.run', side_effect=run) as execute:
                result = compile_nativegateway(self.store, self.pid, self.project['project_sha256'], cold=True)
        self.assertEqual(execute.call_count, 2)
        self.assertTrue(result['compiled'])
        self.assertEqual(result['pou_emission']['parsed_count'], 31)
        self.assertEqual(result['pou_emission']['emitted'], ['Main'])
        self.assertEqual(len(result['pou_emission']['not_emitted']), 30)
        self.assertFalse(result['deployable'])


if __name__ == '__main__':
    unittest.main()
