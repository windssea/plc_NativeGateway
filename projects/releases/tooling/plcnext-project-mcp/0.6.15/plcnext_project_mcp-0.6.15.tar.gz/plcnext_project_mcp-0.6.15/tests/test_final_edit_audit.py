"""Final audit: the compiler's POU graph must equal the registered project graph.

Only temporary variants of the frozen NativeGateway copy are used. These tests
exercise the Python admission gate and never start an Engineer/PLC process.
"""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
import uuid
import xml.etree.ElementTree as ET
import zipfile

from plcnext_mcp.expanded_compile import _cold_project_snapshot
from plcnext_mcp.lifecycle import _new_metadata
from plcnext_mcp.project import ProjectError, ProjectStore, read_archive

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'
PROJ = 'PROJECT/PROJECT.proj'
PREFIX = 'PROJECT/Logical%20Elements/'


@unittest.skipUnless(FROZEN.is_file(), 'Frozen NativeGateway source fixture unavailable')
class FinalRegisteredSourceAudit(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='plcnext-final-edit-audit-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore(self.root / 'managed')
        _, self.members, _, _ = read_archive(FROZEN)

    def snapshot(self):
        path = self.root / 'NativeGateway.audit-copy.pcwex'
        with zipfile.ZipFile(path, 'w') as archive:
            for name, data in self.members.items():
                archive.writestr(name, data)
        project = self.store.import_copy(str(path))
        return _cold_project_snapshot(self.store, project['project_id'], project['project_sha256'])

    def test_reference_search_keeps_all_names_in_one_standard_declaration(self):
        path = self.root / 'NativeGateway.references-copy.pcwex'
        with zipfile.ZipFile(path, 'w') as archive:
            for name, data in self.members.items():
                archive.writestr(name, data)
        project = self.store.import_copy(str(path))
        main = self.store.read_pou(project['project_id'], 'Main')
        self.store.update_pous(project['project_id'], project['project_sha256'], [{
            'pou_name': 'Main', 'expected_code_sha256': main['code_sha256'],
            'expected_variables_sha256': main['variables_sha256'],
            'variables': main['variables'] + '\nVAR\nauditA, auditB : NG_ReadAck;\nEND_VAR\n',
            'code': main['code'] + '\nauditA();\nauditB();\n'}])
        references = self.store.references(project['project_id'], 'NG_ReadAck')['instances']
        observed = {r['instance'] for r in references if r['caller'] == 'Main'}
        self.assertTrue({'auditA', 'auditB'} <= observed)

    def test_unregistered_orphan_pou_is_rejected(self):
        prefix = PREFIX + 'FB_OrphanAudit.pou/'
        metadata, _ = _new_metadata('FB_OrphanAudit')
        self.members.update({prefix + 'Metadata.meta': metadata,
            prefix + 'Code.st': b'(* orphan source is never registered in PROJECT.proj *)\n',
            prefix + 'Variables.var': b'VAR\nEND_VAR\n'})
        with self.assertRaises(ProjectError):
            self.snapshot()

    def test_nonempty_io_configuration_is_rejected_before_vendor_parser(self):
        path = next(p for p in self.members if p.endswith('/IOConfiguration.ioc'))
        self.members[path] = b"{ INPUT_IO_GROUP(NAME := 'AuditInput', START_ADR := 0, END_ADR := 7, DRIVER_NAME := 'AuditDriver') WITH Cyclic100 }"
        with self.assertRaisesRegex(ProjectError, 'Nonempty IOConfiguration'):
            self.snapshot()

    def test_registered_pou_missing_from_archive_is_rejected(self):
        prefix = PREFIX + 'NG_ReadAck.pou/'
        self.members = {p: data for p, data in self.members.items() if not p.startswith(prefix)}
        with self.assertRaises(ProjectError):
            self.snapshot()

    def test_registered_folder_and_metadata_id_disagreement_is_rejected(self):
        path = PREFIX + 'NG_ReadAck.pou/Metadata.meta'
        metadata = ET.fromstring(self.members[path])
        metadata.find('Id').text = str(uuid.uuid4())
        self.members[path] = ET.tostring(metadata)
        with self.assertRaises(ProjectError):
            self.snapshot()

    def test_duplicate_project_pou_registration_is_rejected(self):
        project = ET.fromstring(self.members[PROJ])
        for parent in project.iter():
            item = next((n for n in parent if n.tag.rsplit('}', 1)[-1] == 'Folder'
                and n.get('Include') == 'Logical Elements\\NG_ReadAck.pou'), None)
            if item is not None:
                parent.append(deepcopy(item))
                break
        self.members[PROJ] = ET.tostring(project)
        with self.assertRaises(ProjectError):
            self.snapshot()


if __name__ == '__main__':
    unittest.main()
