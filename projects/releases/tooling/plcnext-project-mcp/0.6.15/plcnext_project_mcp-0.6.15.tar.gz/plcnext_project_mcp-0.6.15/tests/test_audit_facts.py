import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import test_audit_export as fixture
from plcnext_mcp.audit_collector import Exporter,EvidenceError
from plcnext_mcp.audit_facts import FIELDS,HEAD,encoding_complete,SAFE

class FactTests(unittest.TestCase):
    setUp=fixture.AuditTests.setUp
    client=fixture.AuditTests.client
    def event(self):
        return {'Event.PollSkippedBefore':0,'DecisionFlags':63,'DecisionRevisionDelta':0,
            'DecisionDelayLo':10,'DecisionDelayHi':0,'ReportSkipped':0,
            'Event.CompletedMonoMs':100,'Event.ClockRevision':1,'Event.Kind':1}
    def exporter(self):
        e=self.event();prefix='CaptureBuffer.AuditEvents[1].'
        self.fixture.values.update({prefix+k:v for k,v in e.items()})
        self.fixture.values.update({'CaptureBuffer.AuditFactSchema':2,'CaptureBuffer.AuditFactsComplete':True})
        client,peer=self.client()
        # The mock uses the same scalar widths as the source-resolved v2 model.
        for name,dtype in {**HEAD,**{prefix+k:v for k,v in FIELDS.items()}}.items():
            client.symbols[name]['wire_type']=dtype;peer.types[name]=dtype
        ex=Exporter(client,self.journal);ex.fact_mode='decision_clock_slots_v2'
        return ex,peer
    def test_raw_v2_scalars_survive_tls_and_fsync_before_ack(self):
        ex,peer=self.exporter();ex.poll()
        rows=[json.loads(l) for l in (self.root/'events.jsonl').read_text().splitlines()]
        row=next(r['event'] for r in rows if r['kind']=='capture')
        for key in FIELDS:self.assertEqual(row[key],self.event()[key])
        self.assertEqual(len(peer.field_writes),4)
        self.assertEqual(ex.fact_metadata()['audit_fact_schema'],2)
        self.assertFalse(ex.fact_metadata()['missedSlotsIndependentlyVerified'])
    def test_encoding_boundaries_and_unknowns_remain_separate(self):
        e=self.event()
        for updates in ({'DecisionFlags':59},{'DecisionRevisionDelta':255},
                        {'DecisionDelayLo':65535,'DecisionDelayHi':255},{'ReportSkipped':254},
                        {'Event.Kind':2,'DecisionFlags':127,'ReportSkipped':0},
                        {'Event.Kind':2,'DecisionFlags':127,'ReportSkipped':254}):
            self.assertTrue(encoding_complete(e|updates),updates)
        for updates in ({'ReportSkipped':255},{'DecisionFlags':55},{'DecisionFlags':47},
                        {'Event.CompletedMonoMs':SAFE},{'Event.ClockRevision':SAFE,'DecisionRevisionDelta':1},
                        {'DecisionFlags':127},{'Event.Kind':2,'Event.PollSkippedBefore':1}):
            self.assertFalse(encoding_complete(e|updates),updates)
        for updates in ({'DecisionDelayLo':-1},{'DecisionDelayHi':256},{'DecisionRevisionDelta':True},
                        {'Event.PollSkippedBefore':4294967296}):
            with self.assertRaises(EvidenceError):encoding_complete(e|updates)
    def test_unknown_facts_are_preserved_without_becoming_raw_ring_loss(self):
        ex,peer=self.exporter()
        peer.model.values['CaptureBuffer.AuditFactsComplete']=False
        peer.model.values['CaptureBuffer.AuditEvents[1].ReportSkipped']=255
        ex.poll();meta=ex.fact_metadata()
        self.assertFalse(meta['audit_facts_complete']);self.assertFalse(meta['audit_fact_encoding_complete'])
        self.assertEqual(len(peer.field_writes),4)
    def test_schema_change_and_same_terminal_fact_mutation_block_ack(self):
        ex,peer=self.exporter();original=ex.io.read;changed=False
        def read(names):
            nonlocal changed
            result=original(names)
            if not changed and any(n.endswith('.DecisionDelayLo') for n in names):
                changed=True;peer.model.values['CaptureBuffer.AuditEvents[1].DecisionDelayLo']=11
            return result
        with patch.object(ex.io,'read',read):
            with self.assertRaises(EvidenceError):ex.poll()
        self.assertEqual(peer.field_writes,[])
        peer.model.values['CaptureBuffer.AuditFactSchema']=1
        with self.assertRaises(EvidenceError):ex.poll()
    def test_pending_decision_and_cancelled_commit_are_not_acknowledged(self):
        ex,peer=self.exporter();peer.model.values['CaptureBuffer.AuditEvents[1].Decision']=0
        self.assertEqual(ex.poll(),(0,0));self.assertEqual(peer.field_writes,[])
        peer.model.values['CaptureBuffer.AuditEvents[1].Decision']=2
        with patch('plcnext_mcp.audit_collector.os.fsync',side_effect=OSError('disk')):
            with self.assertRaises(OSError):ex.poll()
        self.assertEqual(peer.field_writes,[])

    def test_v2_mixed_batch_keeps_outside_facts_out_of_source_count(self):
        from plcnext_mcp.audit_cohort import SourceCohort,close_source_window
        import time
        first='CaptureBuffer.AuditEvents[1].';second='CaptureBuffer.AuditEvents[2].'
        self.fixture.values.update({second+k[len(first):]:v for k,v in list(self.fixture.values.items()) if k.startswith(first)})
        self.fixture.values.update({second+k:v for k,v in self.event().items()})
        self.fixture.values[second+'Event.SampleSeq']=2
        prefix='CaptureBuffer.Associations[1].'
        self.fixture.values.update({prefix+k:v for k,v in {'Ordinal':1,'MessageId':'mixed-v2','Digest':'a'*64,'Count':2,
            'ConfigSlot':1,'ConfigGeneration':7,'BatchGeneration':1,'Category':2,'SampleSeqs[1]':1,'SampleSeqs[2]':2}.items()})
        ex,peer=self.exporter();ex.cohort=SourceCohort();ex.poll()
        def check():
            peer.model.values['CaptureBuffer.AuditWriteSeq']=2
            peer.model.values['CaptureBuffer.AssociationWriteSeq']=1
        result=close_source_window(ex,{'tail_seconds':1,'poll_interval_ms':20},time.monotonic()+2,check)
        self.assertEqual(result['source_boundary'],1);self.assertEqual(result['admitted_source_count'],1)
        rows=[json.loads(l) for l in (self.root/'events.jsonl').read_text().splitlines()]
        outside=next(r for r in rows if r['kind']=='capture' and r['event']['Event.SampleSeq']==2)
        self.assertFalse(outside['within_source_window']);self.assertIn('DecisionDelayHi',outside['event'])
        self.assertEqual(rows[-1]['audit_fact_schema'],2)

class SourceProfileTests(unittest.TestCase):
    def test_explicit_v2_source_symbols_and_legacy_refusal(self):
        from plcnext_mcp.project import ProjectStore,ProjectError,sha
        from plcnext_mcp.audit_export import _symbols,names
        root=Path(__file__).resolve().parents[1]/'artifacts/audit-export-research'
        frozen=root/'NativeGateway.audit-v2-source.frozen.pcwex'
        self.assertEqual(sha(frozen.read_bytes()),'d403231d283d60d0e12f8dbdc7db38dd79c10d23490d1d8dd6c63eabfb1a65f4')
        with tempfile.TemporaryDirectory() as tmp:
            store=ProjectStore(Path(tmp));p=store.import_copy(str(frozen))
            symbols=_symbols(store,p['project_id'],p['project_sha256'],'decision_clock_slots_v2')
            self.assertEqual(len(symbols),20148)
            self.assertEqual(symbols['CaptureBuffer.AuditEvents[512].DecisionDelayLo']['wire_type'],'uint16')
            self.assertEqual(len(names()),17074)
            from plcnext_mcp.runtime_monitor import _source
            _,_,model=_source(store,p['project_id'],p['project_sha256'])
            resolve=model.resolve
            def wrong_type(path):
                row=resolve(path)
                return dict(row,wire_type='uint64') if path.endswith('.DecisionDelayLo') else row
            with patch('plcnext_mcp.audit_export._source',return_value=(None,None,model)),patch.object(model,'resolve',side_effect=wrong_type):
                with self.assertRaises(ProjectError):_symbols(store,p['project_id'],p['project_sha256'],'decision_clock_slots_v2')
            old=store.import_copy(str(root/'NativeGateway.audit-source.frozen.pcwex'))
            with self.assertRaises(ProjectError):_symbols(store,old['project_id'],old['project_sha256'],'decision_clock_slots_v2')
