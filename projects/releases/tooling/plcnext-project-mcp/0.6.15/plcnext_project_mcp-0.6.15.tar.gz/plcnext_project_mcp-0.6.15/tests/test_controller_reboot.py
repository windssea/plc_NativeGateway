"""Fixed reboot protocol over real loopback TLS; no PLC connection."""
import json
import unittest
from unittest.mock import patch
from datetime import datetime,timedelta,timezone
import test_controller_recovery as fixtures
PACKAGE=fixtures.PACKAGE
from plcnext_mcp import controller_reboot as reboot
from plcnext_mcp.runtime_monitor import prepare_runtime_read_plan,read_runtime_plan
from plcnext_mcp.reboot_test_peer import LocalRebootPeer
from plcnext_mcp.project import ProjectError

class RebootTests(unittest.TestCase):
    setUp=fixtures.RecoveryTests.setUp
    snapshot=fixtures.RecoveryTests.snapshot
    values=fixtures.RecoveryTests.values

    def fixture(self):
        values=self.values();symbols={};flat={}
        for i,(path,item) in enumerate(values.items()):
            name='BootId' if path.endswith('.BootId') else str(i)
            symbols[name]={'path':path,'wire_type':item['wire_type']};flat[name]=item['value']
        peer=LocalRebootPeer(self.root/'peer',symbols,flat)
        peer.__enter__();self.addCleanup(peer.__exit__,None,None,None)
        read=prepare_runtime_read_plan(self.store,self.pid,self.sha,peer.address,peer.certificate_sha256,
            port=peer.port,include_configuration=True)
        obs=read_runtime_plan(self.store,self.pid,read['plan_id'],read['plan_sha256'])
        self.assertEqual(obs['status'],'monitor_read_completed',obs)
        plan=reboot.prepare(self.store,self.pid,self.sha,PACKAGE,peer.address,peer.certificate_sha256,
            read['plan_id'],read['plan_sha256'],'PUBLIC-boot',
            {'version':13,'device_count':50,'point_count':250,'enabled':True},obs['configuration_digest']['sha256'],
            port=peer.port,timeout_seconds=30)
        return peer,plan

    def receipt(self,p):
        c=reboot.approval_contract(self.store,self.pid,p['plan_id'],p['plan_sha256']);now=datetime.now(timezone.utc)
        record={'schema':c.receipt_schema,'review_sha256':c.review_sha256,'confirmed_by':'human_user',
            **c.binding_fields,'confirmation_reference':'PUBLIC fixture only','confirmed_utc':now.isoformat(),
            'expires_utc':(now+timedelta(minutes=5)).isoformat()}
        d=self.store.root/c.approval_directory;d.mkdir(exist_ok=True)
        (d/(c.review_sha256+'.json')).write_text(json.dumps(record))

    def run_plan(self,p,**kw):
        with patch.object(reboot.time,'sleep',return_value=None):
            return reboot.execute(self.store,self.pid,p['plan_id'],p['plan_sha256'],**kw)

    def test_success_one_send_and_replay(self):
        peer,p=self.fixture();self.receipt(p);r=self.run_plan(p)
        self.assertEqual(r['status'],'reboot_auto_run_verified',r)
        self.assertEqual(peer.reboot_calls,1);self.assertFalse(r['endpoint_lease_retained'])
        self.assertTrue(self.run_plan(p)['replayed']);self.assertEqual(peer.reboot_calls,1)
        self.assertFalse(r['device_start_sent']);self.assertFalse(r['os_boot_id_verified'])

    def test_reply_loss_does_not_resend(self):
        peer,p=self.fixture();peer.lose_reply=True;self.receipt(p);r=self.run_plan(p)
        self.assertEqual(r['status'],'reboot_auto_run_verified',r)
        self.assertFalse(r['reboot_reply_received']);self.assertEqual(peer.reboot_calls,1)

    def test_stopped_then_read_only_resume(self):
        peer,p=self.fixture();peer.auto_run=False;self.receipt(p);r=self.run_plan(p)
        self.assertEqual(r['status'],'reboot_wait_failed',r);self.assertTrue(r['endpoint_lease_retained'])
        with self.assertRaises(ProjectError):self.run_plan(p)
        peer.state=3;r=self.run_plan(p,resume=True)
        self.assertEqual(r['status'],'reboot_auto_run_verified',r);self.assertEqual(peer.reboot_calls,1)

    def test_unchanged_boot_fails(self):
        peer,p=self.fixture();peer.boot_changes=False;self.receipt(p);r=self.run_plan(p)
        self.assertFalse(r['auto_run_verified']);self.assertTrue(r['endpoint_lease_retained'])
        self.assertEqual(peer.reboot_calls,1)

    def test_no_approval_no_connection(self):
        peer,p=self.fixture();n=peer.connections
        with self.assertRaises(FileNotFoundError):self.run_plan(p)
        self.assertEqual(peer.connections,n);self.assertEqual(peer.reboot_calls,0)

    def test_baseline_change_denies_reboot(self):
        peer,p=self.fixture();peer.model.values['BootId']='unexpected';self.receipt(p);r=self.run_plan(p)
        self.assertFalse(r['auto_run_verified']);self.assertFalse(r['endpoint_lease_retained'])
        self.assertEqual(peer.reboot_calls,0)

    def test_cancel_before_send(self):
        peer,p=self.fixture();self.receipt(p);reboot.cancel(self.store,self.pid,p['plan_id'],p['plan_sha256'])
        r=self.run_plan(p);self.assertEqual(peer.reboot_calls,0);self.assertFalse(r['endpoint_lease_retained'])

    def test_resume_rejects_tampered_baseline(self):
        peer,p=self.fixture();peer.auto_run=False;self.receipt(p);self.run_plan(p)
        folder,_=reboot.load(self.store,self.pid,p['plan_id'],p['plan_sha256'])
        (folder/'baseline.json').write_bytes((folder/'baseline.json').read_bytes()+b' ')
        peer.state=3;r=self.run_plan(p,resume=True)
        self.assertFalse(r['auto_run_verified']);self.assertIn('baseline bytes changed',r['error'])
        self.assertEqual(peer.reboot_calls,1)

    def test_replay_preserves_new_owner_and_finishes_own_release(self):
        peer,p=self.fixture();self.receipt(p);r=self.run_plan(p)
        self.assertTrue(r['auto_run_verified'],r)
        folder,_=reboot.load(self.store,self.pid,p['plan_id'],p['plan_sha256'])
        started=json.loads((folder/'started.json').read_bytes());path=reboot.Path(started['lease_path'])
        path.write_bytes(bytes.fromhex(started['lease_bytes_hex']))
        self.assertTrue(self.run_plan(p)['replayed']);self.assertFalse(path.exists())
        path.write_bytes(b'new operation owner')
        self.assertTrue(self.run_plan(p)['replayed']);self.assertEqual(path.read_bytes(),b'new operation owner')
        self.assertEqual(peer.reboot_calls,1)

    def test_wrong_configuration_and_pin_prevent_success(self):
        peer,p=self.fixture();self.receipt(p)
        original=reboot.read_runtime_plan;calls=0
        def observe(*a,**kw):
            nonlocal calls
            calls+=1;o=original(*a,**kw)
            if calls>1:o['configuration_digest']['sha256']='0'*64
            return o
        with patch.object(reboot,'read_runtime_plan',side_effect=observe):r=self.run_plan(p)
        self.assertFalse(r['auto_run_verified']);self.assertTrue(r['endpoint_lease_retained'])
        def pin_error(*a,**kw):return {'status':'monitor_failed','failure_code':'certificate_pin_mismatch'}
        with patch.object(reboot,'read_runtime_plan',side_effect=pin_error):r=self.run_plan(p,resume=True)
        self.assertIn('Certificate changed',r['error']);self.assertEqual(peer.reboot_calls,1)
