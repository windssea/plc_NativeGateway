"""M11 local evidence and crash/concurrency tests. Never accesses a PLC."""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from plcnext_mcp import lease_reconciliation as r
from plcnext_mcp.project import sha, ProjectError
from plcnext_mcp.operator_approval import issue_mcp_approval
from plcnext_mcp.controller_transfer import _claim_endpoint_lease
from plcnext_mcp.endpoint_guard import endpoint_guard

class ReconciliationTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);root=Path(tmp.name)
        self.pid='a'*32;self.oid='b'*32;self.eid='c'*32;self.digest='d'*64
        self.folder=root/self.pid;self.folder.mkdir()
        self.store=SimpleNamespace(root=root,_folder=lambda p:self.folder if p==self.pid else None)
        self.target={'address':'127.0.0.1','port':41100,'expected_certificate_sha256':'e'*64}
        self.job=self.folder/'controller-recoveries'/self.eid;self.job.mkdir(parents=True)
        self.opdir=self.folder/'controller-operation-jobs'/self.oid;self.opdir.mkdir(parents=True)
        self.leaseroot=root/'leases';self.leaseroot.mkdir()
        self.lease=self.leaseroot/(sha(b'127.0.0.1:41100')+'.json')
        self.old={'target':self.target,'source':{'project_sha256':'1'*64},'package':{'inventory_sha256':'2'*64},
            'plan_id':'f'*32,'children':{'monitor':{'plan_id':'3'*32,'plan_sha256':'4'*64}},
            'policy':{'expected_configuration':{}}}
        self.result={'execution_id':self.eid,'plan_id':'f'*32,'review_sha256':self.digest,'target':self.target,
            'status':'original_loaded_verification_incomplete','stage':'completed','outcome_unknown':False,
            'receipt_persisted':True,'original_package_loaded':True,'original_configuration_verified':True,
            'steps':[{'terminal_state_verified':True,'review_sha256':'5'*64},
            {'load_state_verified':True,'unacknowledged_mutation_requests':0},
            {'terminal_state_verified':True,'loaded_package_identity_verified':True}]}
        self.op={'schema':'plcnext-controller-operation-job/v1','project_id':self.pid,'operation_id':self.oid,
            'review_sha256':self.digest,'kind':'recovery','phase':'finished','status':'needs_attention',
            'host_pid':12345,'host_process_birth':'dead-fixture','driver_report_path':str(self.job/'result.json')}
        self.publish_result()
        binding={'operation':'RecoveryBinding','execution_id':self.eid,'review_sha256':self.digest,
            'target':self.target,'project_sha256':'1'*64,'inventory_sha256':'2'*64,'plan_id':'f'*32}
        from plcnext_mcp.controller_transport import PLC
        mutations=[{'operation':'Invoke','service':PLC,'method':m,'mutating':True,'send_attempted':True,'response_received':True} for m in (4,1,2)]
        self.events=[binding,*mutations,{'operation':'ExecutionOutcome','stage':'completed','outcome_unknown':False,'receipt_persisted':True}]
        self.journal()
        self.write(self.lease,{'target':self.target,'job_directory':str(self.job),'review_sha256':'5'*64})
        for name,value in [('_endpoint_lease_root',lambda:self.leaseroot),('_process_birth',lambda p:None),
            ('load_recovery_plan',lambda *a:self.old),('_observe',lambda *a:{'report_path':'PUBLIC','observation_sha256':'6'*64})]:
            mock=patch.object(r,name,value);mock.start();self.addCleanup(mock.stop)
        mock=patch('plcnext_mcp.controller_transfer._endpoint_lease_root',return_value=self.leaseroot);mock.start();self.addCleanup(mock.stop)
    def write(self,path,value):path.write_text(json.dumps(value),encoding='utf-8')
    def journal(self):self.job.joinpath('journal.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in self.events),encoding='utf-8')
    def publish_result(self):
        self.write(self.job/'result.json',self.result)
        env={'operation_id':self.oid,'project_id':self.pid,'review_sha256':self.digest,'result':self.result}
        self.write(self.opdir/'result.json',env);self.op['result_sha256']=sha((self.opdir/'result.json').read_bytes());self.write(self.opdir/'operation.json',self.op)
    def prepare(self):return r.prepare(self.store,self.pid,self.oid,self.digest,'e'*64)
    def authorize(self,p):return issue_mcp_approval(self.store.root,lambda:r.approval_contract(self.store,self.pid,p['plan_id'],p['plan_sha256']),reason='PUBLIC fixture')
    def execute(self,p):return r.execute(self.store,self.pid,p['plan_id'],p['plan_sha256'])
    def test_archive_and_replay_never_remove_new_owner(self):
        p=self.prepare();self.authorize(p);out=self.execute(p)
        self.assertFalse(self.lease.exists());self.assertTrue(Path(out['archive_path']).is_file())
        self.write(self.lease,{'new_owner':True});self.assertTrue(self.execute(p)['replayed']);self.assertTrue(self.lease.exists())
    def test_live_owner_and_unknown_or_unclosed_rejected(self):
        with patch.object(r,'_process_birth',return_value='dead-fixture'):
            with self.assertRaises(ProjectError):self.prepare()
        self.result['outcome_unknown']=True;self.publish_result()
        with self.assertRaises(ProjectError):self.prepare()
        self.result['outcome_unknown']=False;self.publish_result();self.events.pop();self.journal()
        with self.assertRaises(ProjectError):self.prepare()
    def test_wrong_pin_and_missing_journal(self):
        with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,self.oid,self.digest,'0'*64)
        (self.job/'journal.jsonl').unlink()
        with self.assertRaises(ProjectError):self.prepare()
    def test_changed_lease_and_journal_refused(self):
        p=self.prepare();self.authorize(p);self.events.append({'operation':'unexpected'});self.journal()
        with self.assertRaises(ProjectError):self.execute(p)
        self.events.pop();self.journal();self.write(self.lease,{'new_owner':True})
        with self.assertRaises(ProjectError):self.execute(p)
        self.assertEqual(json.loads(self.lease.read_text()),{'new_owner':True})
    def test_no_authorization_or_bad_runtime_leaves_lease(self):
        p=self.prepare()
        with self.assertRaises(ProjectError):self.execute(p)
        self.authorize(p)
        with patch.object(r,'_observe',side_effect=ProjectError('not GOOD')):
            with self.assertRaises(ProjectError):self.execute(p)
        self.assertTrue(self.lease.exists())
    def test_common_guard_excludes_claim_and_reconciliation(self):
        p=self.prepare();self.authorize(p)
        with endpoint_guard(self.lease):
            with self.assertRaises(ProjectError):self.execute(p)
            with self.assertRaises(ProjectError):_claim_endpoint_lease({'target':self.target,'review_sha256':'0'*64},self.job)
    def test_crash_after_archive_can_finalize_but_claims_are_blocked(self):
        p=self.prepare();self.authorize(p);save=r._save_new
        def crash(path,value):
            if path.name=='result.json':raise OSError('PUBLIC crash after archive')
            return save(path,value)
        with patch.object(r,'_save_new',side_effect=crash):
            with self.assertRaises(OSError):self.execute(p)
        self.assertFalse(self.lease.exists())
        with self.assertRaises(ProjectError):_claim_endpoint_lease({'target':self.target,'review_sha256':'0'*64},self.job)
        self.assertEqual(self.execute(p)['status'],'reconciled')
    def test_crash_before_claim_can_resume_with_valid_authorization(self):
        p=self.prepare();self.authorize(p);save=r._save_new
        def crash(path,value):
            if path.name.endswith('.claimed.json'):raise OSError('PUBLIC crash before claim')
            return save(path,value)
        with patch.object(r,'_save_new',side_effect=crash):
            with self.assertRaises(OSError):self.execute(p)
        self.assertTrue(self.lease.exists());self.assertEqual(self.execute(p)['status'],'reconciled')
    def test_missing_claim_after_archive_refused(self):
        p=self.prepare();self.authorize(p);save=r._save_new
        def crash(path,value):
            if path.name=='result.json':raise OSError('crash')
            return save(path,value)
        with patch.object(r,'_save_new',side_effect=crash):
            with self.assertRaises(OSError):self.execute(p)
        (self.store.root/'controller-lease-reconciliation-approvals'/(p['plan_sha256']+'.claimed.json')).unlink()
        with self.assertRaises(ProjectError):self.execute(p)
    def test_evidence_changes_during_final_read(self):
        p=self.prepare();self.authorize(p)
        def change(*a):
            self.write(self.lease,{'new_owner':True});return {}
        with patch.object(r,'_observe',side_effect=change):
            with self.assertRaises(ProjectError):self.execute(p)
        self.assertTrue(self.lease.exists())

    def test_journal_send_response_pairs_and_missing_response(self):
        sent=dict(self.events[1],response_received=False)
        self.events.insert(1,sent);self.journal();self.prepare()
        self.events.pop(2);self.journal()
        with self.assertRaises(ProjectError):self.prepare()

    def sync_fixture(self):
        from plcnext_mcp.operator_approval import OperatorApprovalContract
        from datetime import datetime,timezone,timedelta
        self.result.update(project_id=self.pid,endpoint_lease_retained=True,endpoint_quarantine_reason='business_verification_incomplete')
        self.publish_result();self.events[-1]['status']=self.result['status'];self.journal()
        contract=OperatorApprovalContract(kind='recovery',review_sha256=self.digest,
            receipt_schema='plcnext-controller-recovery-operator-approval/v1',approval_directory='controller-recovery-approvals',
            binding_fields={'target':self.target,'project_sha256':'1'*64,'inventory_sha256':'2'*64,'policy':{},'approved_actions':['PUBLIC']},display={})
        mock=patch('plcnext_mcp.controller_recovery.approval_contract',return_value=contract);mock.start();self.addCleanup(mock.stop)
        now=datetime.now(timezone.utc)
        receipt={'schema':contract.receipt_schema,'review_sha256':self.digest,'confirmed_by':'human_user',
            **contract.binding_fields,'confirmation_reference':'PUBLIC','confirmed_utc':now.isoformat(),'expires_utc':(now+timedelta(minutes=5)).isoformat()}
        directory=self.store.root/contract.approval_directory;directory.mkdir()
        self.write(directory/(self.digest+'.json'),receipt)
        self.claim=directory/(self.digest+'.claimed.json')
        self.write(self.claim,{'execution_id':self.eid,'review_sha256':self.digest,'approval_sha256':sha((directory/(self.digest+'.json')).read_bytes())})
    def sync_prepare(self):return r.prepare(self.store,self.pid,'sync:'+self.eid,self.digest,'e'*64)
    def test_sync_terminal_with_consumed_approval_archives(self):
        self.sync_fixture();p=self.sync_prepare()
        self.assertIsNone(p['operation_id']);self.assertEqual(p['execution_id'],self.eid)
        self.authorize(p);self.assertEqual(self.execute(p)['status'],'reconciled')
        self.assertTrue(self.claim.exists())
    def test_sync_rejects_missing_claim_or_active_execution(self):
        self.sync_fixture()
        guard=self.folder/'controller-recovery-plans'/('f'*32)/'execution'
        with endpoint_guard(guard):
            with self.assertRaises(ProjectError):self.sync_prepare()
        self.claim.unlink()
        with self.assertRaises(ProjectError):self.sync_prepare()
    def test_sync_incomplete_unknown_and_wrong_identity_refused(self):
        self.sync_fixture()
        for field,value in [('outcome_unknown',True),('stage','starting'),('project_id','0'*32)]:
            old=self.result[field];self.result[field]=value;self.publish_result()
            with self.assertRaises(ProjectError):self.sync_prepare()
            self.result[field]=old;self.publish_result()
    def test_sync_refuses_hash_change_and_wrong_claim(self):
        self.sync_fixture();p=self.sync_prepare();self.authorize(p)
        self.write(self.claim,{'execution_id':'0'*32})
        with self.assertRaises(ProjectError):self.execute(p)
        self.assertTrue(self.lease.exists())

    def audit_fixture(self):
        self.sync_fixture()
        self.old['children']['audit']={'plan_id':'6'*32,'plan_sha256':'7'*64}
        folder=self.folder/'audit-exports'/('6'*32);folder.mkdir(parents=True)
        rows=[{'kind':'capture','event':{'Event.SampleSeq':1}}]
        data=''.join(json.dumps(row)+'\n' for row in rows).encode();(folder/'events.jsonl').write_bytes(data)
        (folder/'transport.jsonl').write_text('PUBLIC terminal ACK transport')
        audit={'parent_review_sha256':self.digest,'parent_plan_id':'f'*32,'audit_plan_id':'6'*32,'audit_plan_sha256':'7'*64,
            'complete':False,'outcome_unknown':True,'observed_boot_id':'PUBLIC-boot','durable_bytes':len(data),
            'actual_file_sha256':sha(data),'journal_sha256':sha(data),'durable_cursors':{'Audit':1,'Association':0}}
        self.write(folder/'result.json',audit)
        self.result.update(status='recovery_failed',stage='audit_after_start',failure_code='parent_audit_incomplete',
            outcome_unknown=True,audit_result=audit,original_configuration_verified=False,endpoint_quarantine_reason='unknown_device_outcome')
        self.publish_result();self.events[-1].update(status='recovery_failed',stage='audit_after_start',outcome_unknown=True);self.journal()
        return folder
    def test_parent_audit_failure_has_distinct_reviewed_reconciliation(self):
        self.audit_fixture();p=r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)
        self.assertEqual(p['owner_kind'],'parent_audit');self.assertEqual(p['evidence']['audit_resolution']['durable_cursors']['Audit'],1)
        self.authorize(p);self.assertEqual(self.execute(p)['status'],'reconciled')
        self.assertTrue(self.result['outcome_unknown']);self.assertFalse(self.result['audit_result']['complete'])
    def test_parent_audit_tampered_evidence_or_control_uncertainty_refused(self):
        folder=self.audit_fixture();(folder/'events.jsonl').write_text('modified')
        with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)

    def zero_fixture(self):
        folder=self.audit_fixture();a=self.result['audit_result'];a.pop('observed_boot_id')
        data=b'{"kind":"armedBeforeStart"}\n';(folder/'events.jsonl').write_bytes(data)
        (folder/'transport.jsonl').write_text('{"operation":"Connect","mutating":false}\n')
        a.update(ack_write_attempts=0,outcome_unknown=False,durable_bytes=len(data),actual_file_sha256=sha(data),
            journal_sha256=sha(data),durable_cursors={'Audit':0,'Association':0})
        self.result.update(outcome_unknown=False,endpoint_quarantine_reason='known_execution_failure')
        self.events[-1]['outcome_unknown']=False;self.journal();self.publish_result();self.write(folder/'result.json',a)
        self.zero_observation={'audit_ack_readback':{'values':{'BootId':'current-only','Active.Version':13}}}
        self.zero_mock=patch.object(r,'_observe',return_value=self.zero_observation);self.zero_mock.start();self.addCleanup(self.zero_mock.stop)
        return folder
    def test_zero_ack_archives_without_inventing_historical_boot(self):
        folder=self.zero_fixture();p=r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)
        self.assertFalse(p['evidence']['audit_resolution']['historical_boot_observed'])
        self.authorize(p);self.assertEqual(self.execute(p)['status'],'reconciled')
        self.assertNotIn('observed_boot_id',json.loads((folder/'result.json').read_text()))
    def test_zero_ack_rejects_transport_writes_and_intents(self):
        folder=self.zero_fixture();transport=folder/'transport.jsonl';original=transport.read_bytes()
        transport.write_text('{"operation":"AuditAckWrite","send_attempted":true}\n')
        with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)
        transport.write_bytes(original);(folder/'ack-journal.jsonl').write_text('{"operation":"DurableAckIntent"}\n')
        with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)
    def test_zero_ack_rejects_counter_missing_boolean_positive(self):
        folder=self.zero_fixture();a=self.result['audit_result']
        for value in (None,False,1):
            a['ack_write_attempts']=value;self.publish_result();self.write(folder/'result.json',a)
            with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)
    def test_zero_ack_rejects_current_boot_change_before_execute(self):
        self.zero_fixture();p=r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64);self.authorize(p)
        with patch.object(r,'_observe',return_value={'audit_ack_readback':{'values':{'BootId':'different','Active.Version':13}}}):
            with self.assertRaises(ProjectError):self.execute(p)
        self.assertTrue(self.lease.exists())

    def test_zero_ack_rejects_active_execution_wrong_hash_and_changed_file(self):
        folder=self.zero_fixture()
        guard=self.folder/'controller-recovery-plans'/('f'*32)/'execution'
        with endpoint_guard(guard):
            with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)
        with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,'audit:'+self.eid,'0'*64,'e'*64)
        p=r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64);self.authorize(p)
        (folder/'events.jsonl').write_text('changed')
        with self.assertRaises(ProjectError):self.execute(p)
        self.assertTrue(self.lease.exists())

    def test_zero_ack_unknown_result_refused(self):
        folder=self.zero_fixture();self.result['outcome_unknown']=True
        self.result['audit_result']['outcome_unknown']=True;self.events[-1]['outcome_unknown']=True
        self.journal();self.publish_result();self.write(folder/'result.json',self.result['audit_result'])
        with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)

    def test_observed_boot_partial64_zero_ack_reconciliation(self):
        folder=self.zero_fixture();a=self.result['audit_result']
        data=b''.join((json.dumps({'kind':'capture','event':{'Event.SampleSeq':i}})+'\n').encode() for i in range(1,65))
        (folder/'events.jsonl').write_bytes(data)
        a.update(observed_boot_id='current-only',durable_cursors={'Audit':64,'Association':0},
            durable_bytes=len(data),actual_file_sha256=sha(data),journal_sha256=sha(data))
        self.publish_result();self.write(folder/'result.json',a)
        p=r.prepare(self.store,self.pid,'audit:'+self.eid,self.digest,'e'*64)
        self.assertEqual(p['evidence']['audit_resolution']['mode'],'zero_ack_partial')
        self.authorize(p);self.assertEqual(self.execute(p)['status'],'reconciled')
        self.assertEqual(json.loads((folder/'result.json').read_text())['durable_cursors']['Audit'],64)

    def observation_fixture(self):
        self.sync_fixture();self.old['files']={'file':{}}
        self.result.update(status='recovery_failed',stage='verify_runtime',failure_code='recovery_observation_failed',
            original_configuration_verified=False,endpoint_quarantine_reason='known_execution_failure')
        for i in (0,2):self.result['steps'][i].update(action_sent=True,ack_received=True)
        self.result['steps'][1].update(load_ack_received=True,files_verified=1)
        self.events[-1].update(status='recovery_failed',stage='verify_runtime');self.publish_result();self.journal()
        evidence=self.folder/'external.json';evidence.write_text('PUBLIC external restore fixture')
        context={'project_id':'9'*32,'project_sha256':'1'*64,'plan_id':'2'*32,'plan_sha256':'3'*64,
            'expected_boot_id':'stable-v15','expected_configuration':{'version':15,'device_count':50,'point_count':250,'enabled':True},
            'expected_configuration_sha256':'4'*64,'external_evidence_path':str(evidence),'external_evidence_sha256':sha(evidence.read_bytes()),'description':'PUBLIC stable restored'}
        mock=patch('plcnext_mcp.observation_reconciliation.load_runtime_read_plan',return_value={'target':self.target,'project_sha256':'1'*64})
        mock.start();self.addCleanup(mock.stop)
        return context,evidence
    def test_observation_failure_handoff_archives_exact_old_failure(self):
        context,evidence=self.observation_fixture();old=(self.job/'result.json').read_bytes()
        p=r.prepare(self.store,self.pid,self.oid,self.digest,'e'*64,current_state=context)
        self.authorize(p);result=self.execute(p)
        self.assertTrue(result['old_failure_preserved']);self.assertEqual((self.job/'result.json').read_bytes(),old)
        self.assertFalse(result['controller_mutations'])
    def test_observation_handoff_rejects_changed_external_evidence_or_authorization(self):
        context,evidence=self.observation_fixture();p=r.prepare(self.store,self.pid,self.oid,self.digest,'e'*64,current_state=context)
        self.authorize(p);evidence.write_text('changed')
        with self.assertRaises(ProjectError):self.execute(p)
        self.assertTrue(self.lease.exists())
    def test_observation_handoff_rejects_unknown_control_and_missing_ack(self):
        context,_=self.observation_fixture()
        self.result['steps'][2]['ack_received']=False;self.publish_result()
        with self.assertRaises(ProjectError):r.prepare(self.store,self.pid,self.oid,self.digest,'e'*64,current_state=context)

    def test_observation_handoff_archive_crash_resumes_without_second_read(self):
        context,_=self.observation_fixture();p=r.prepare(self.store,self.pid,self.oid,self.digest,'e'*64,current_state=context);self.authorize(p)
        original=r._save_new
        def save(path,value):
            if path.name=='result.json':raise OSError('crash after archive')
            return original(path,value)
        with patch.object(r,'_save_new',save):
            with self.assertRaises(OSError):self.execute(p)
        self.assertFalse(self.lease.exists())
        with patch.object(r,'_observe',side_effect=AssertionError('No new device I/O after archive')):
            self.assertEqual(self.execute(p)['status'],'reconciled')
    def test_observation_handoff_changed_current_source_rejected(self):
        context,_=self.observation_fixture();p=r.prepare(self.store,self.pid,self.oid,self.digest,'e'*64,current_state=context);self.authorize(p)
        with patch('plcnext_mcp.observation_reconciliation.load_runtime_read_plan',return_value={'target':self.target,'project_sha256':'0'*64}):
            with self.assertRaises(ProjectError):self.execute(p)
        self.assertTrue(self.lease.exists())
