"""Production TCP client against a literal-loopback filesystem peer only."""
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

from plcnext_mcp.controller_test_peer import LocalTlsController, PUBLIC_PASSWORD, PUBLIC_USERNAME
from plcnext_mcp.controller_transport import (ControllerEndpoint, DownloadScope,
    TlsControllerClient, ControllerFailure, FILE, PLC, _AUTHORITY)
from plcnext_mcp.controller_transfer import (execute_transfer, _operator_scope,
    APPROVAL_SCHEMA, APPROVED_ACTIONS, _check_old_manifest)
from plcnext_mcp.controller_download_plan import POLICY
from plcnext_mcp.deployment_package import MANIFEST
from plcnext_mcp.pcwe_native import make_pcwe_manifest
from plcnext_mcp.project import ProjectError


def fixture_files():
    files = {'Plc/public.txt': b'PUBLIC inert fixture\x00\xff', 'Hmi/fixture.txt': b'PUBLIC data'}
    files[MANIFEST] = make_pcwe_manifest(files)
    return files


class ControllerTransportTests(unittest.TestCase):
    def test_only_optional_source_backups_may_be_preserved_outside_runtime_manifest(self):
        files = fixture_files()
        for extras, allowed in (({'Src/Project.src':b'backup','Src/PUBLIC.pcweax':b'archive'}, True),
                ({'Plc/unknown.so':b'unknown'},False),
                ({'Src/nested/unknown.pcweax':b'unknown'},False),
                ({'Src/one.pcweax':b'one','Src/two.pcweax':b'two'},False)):
            remote = {**{k:v for k,v in files.items() if k != MANIFEST}, **extras}
            client = types.SimpleNamespace(read_many=lambda paths:[{'result':0,'data':make_pcwe_manifest(remote)}])
            if allowed:
                evidence = _check_old_manifest(client, files)
                self.assertEqual(evidence['preserved_remote_source_archive_paths'], sorted(extras))
                self.assertFalse(evidence['old_files_deleted'])
            else:
                with self.assertRaises(ControllerFailure):_check_old_manifest(client, files)

    def test_unchanged_mapped_native_library_is_never_overwritten(self):
        files = fixture_files()
        native = 'Plc/Eclr/SharedLibraries/PUBLIC/libfixture.so'
        files[native] = b'PUBLIC inert library fixture'
        files[MANIFEST] = make_pcwe_manifest({k:v for k,v in files.items() if k != MANIFEST})
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsController(Path(directory)/'peer', allowed_files=set(files)) as peer:
                path = peer.root / native
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(files[native])
                endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
                result = execute_transfer(TlsControllerClient(endpoint,
                    scope=DownloadScope.loopback_fixture(endpoint, files)), files)
                self.assertEqual(result['status'], 'loopback_download_passed')
                self.assertEqual(result['files_verified'], len(files))
                self.assertEqual(result['files_skipped_identical'], [native])
                self.assertNotIn(native, [e['path'] for e in peer.trace if e['operation']=='FileWritten'])

    def test_changed_native_library_refuses_before_any_file_write(self):
        files = fixture_files()
        native = 'Plc/Eclr/SharedLibraries/PUBLIC/libfixture.so'
        files[native] = b'PUBLIC new library'
        files[MANIFEST] = make_pcwe_manifest({k:v for k,v in files.items() if k != MANIFEST})
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsController(Path(directory)/'peer', allowed_files=set(files)) as peer:
                path = peer.root / native
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b'PUBLIC old library')
                endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
                result = execute_transfer(TlsControllerClient(endpoint,
                    scope=DownloadScope.loopback_fixture(endpoint, files)), files)
                self.assertEqual(result['failure_code'], 'native_library_update_requires_unloaded_runtime')
                self.assertEqual(peer.write_calls, 0)
                self.assertEqual(peer.reset_calls, 0)
                self.assertEqual(path.read_bytes(), b'PUBLIC old library')

    def test_hot_metadata_survives_full_transfer_reset_and_load(self):
        result, peer, files = self.run_peer(fault='hot_metadata')
        self.assertEqual(result['status'], 'loopback_download_passed')
        self.assertTrue(result['load_state_verified'])
        self.assertEqual(result['initial_state_raw'], 0x20002)
        self.assertEqual(result['final_state_raw'], 0x20002)

    def run_peer(self, fault='none', *, anonymous=True, credentials=None, fragmented=None):
        files = fixture_files()
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsController(Path(directory) / 'peer', allowed_files=set(files), fault=fault,
                                    anonymous=anonymous, response_fragment_bytes=fragmented) as peer:
                endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
                client = TlsControllerClient(endpoint, scope=DownloadScope.loopback_fixture(endpoint, files))
                result = execute_transfer(client, files, credentials=credentials,
                                          poll_timeout_seconds=0.2, poll_interval_seconds=0.02)
                observation = {'snapshot': peer.snapshot(), 'reset': peer.reset_calls,
                               'load': peer.load_calls, 'stop': peer.stop_calls, 'loaded': peer.loaded,
                               'trace': list(peer.trace), 'errors': list(peer.errors)}
            self.assertFalse(peer.thread_alive)
        self.assertTrue(result['connection_closed'])
        self.assertFalse(result['stop_command_sent'])
        self.assertFalse(result['start_command_sent'])
        self.assertEqual(observation['stop'], 0)
        self.assertFalse(result['controller_downloaded'])
        return result, observation, files

    def test_socket_tls_anonymous_transfer_manifest_last_readback_and_stopped_load(self):
        result, peer, files = self.run_peer(fragmented=7)
        self.assertEqual(result['status'], 'loopback_download_passed')
        self.assertEqual(result['files_verified'], 3)
        self.assertEqual(peer['snapshot'], files)
        self.assertTrue(result['manifest_written_last'])
        written = [item['path'] for item in peer['trace'] if item['operation'] == 'FileWritten']
        self.assertEqual(written[-1], MANIFEST)
        self.assertTrue(result['load_state_verified'])
        self.assertTrue(peer['loaded'])
        self.assertEqual((peer['reset'], peer['load']), (1, 1))
        self.assertTrue(result['socket_transport_used'])
        self.assertFalse(result['memory_bio_used'])

    def test_password_mode_uses_same_transport_without_credentials_in_receipts(self):
        result, peer, files = self.run_peer(anonymous=False, credentials=(PUBLIC_USERNAME, PUBLIC_PASSWORD))
        self.assertEqual(result['status'], 'loopback_download_passed')
        self.assertEqual(peer['snapshot'], files)
        encoded = json.dumps(result)
        self.assertNotIn(PUBLIC_USERNAME, encoded)
        self.assertNotIn(PUBLIC_PASSWORD, encoded)
        result, peer, _ = self.run_peer(anonymous=False, credentials=(PUBLIC_USERNAME, 'PUBLIC-wrong'))
        self.assertEqual(result['failure_code'], 'authentication_failed')
        self.assertFalse(result['files_may_have_changed'])
        self.assertEqual(peer['snapshot'], {})

    def test_chunked_readback_with_large_buffer_hint_uses_same_tcp_client(self):
        result, peer, files = self.run_peer('chunked_readback', fragmented=13)
        self.assertEqual(result['status'], 'loopback_download_passed')
        self.assertEqual(peer['snapshot'], files)
        self.assertTrue(result['load_state_verified'])

    def test_readonly_client_cannot_call_file_session_or_control_methods(self):
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsController(Path(directory) / 'peer', allowed_files=set()) as peer:
                endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
                client = TlsControllerClient(endpoint)
                client.connect()
                self.assertEqual(client.get_state(), 2)
                for service, method, args in [(FILE, 8, [[]]), (FILE, 9, [[]]), (PLC, 1, [True]),
                                               (PLC, 3, [True]), (PLC, 4, [True])]:
                    with self.subTest(method=method), self.assertRaisesRegex(ControllerFailure, 'confirmation'):
                        client._call(service, method, args)
                client.close()
                invoked = [item for item in peer.trace if item['operation'] == 'Invoke']
                self.assertEqual([(item['service'], item['method']) for item in invoked], [(PLC, 5)])
                self.assertEqual(peer.write_calls, 0)

    def test_changed_pin_and_real_address_fixture_scope_are_blocked(self):
        with self.assertRaises(ProjectError):
            DownloadScope.loopback_fixture(ControllerEndpoint('192.168.0.8', 41100, '0' * 64), fixture_files())
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsController(Path(directory) / 'peer', allowed_files=set()) as peer:
                endpoint = ControllerEndpoint(peer.address, peer.port, '0' * 64)
                files = fixture_files()
                result = execute_transfer(TlsControllerClient(endpoint,
                    scope=DownloadScope.loopback_fixture(endpoint, files)), files)
                self.assertEqual(result['failure_code'], 'certificate_pin_mismatch')
                self.assertEqual(peer.trace, [])

    def test_faults_stop_at_correct_phase_and_never_retry_uncertain_mutations(self):
        faults = ['readback_corrupt', 'write_error', 'short_results', 'write_reply_lost',
                  'initial_running', 'permission_denied', 'insufficient_space', 'tls_error',
                  'rpc_error', 'fatal_error', 'reset_timeout', 'load_timeout', 'load_error',
                  'reset_reply_lost', 'load_reply_lost']
        for fault in faults:
            with self.subTest(fault=fault):
                result, peer, _ = self.run_peer(fault)
                self.assertEqual(result['status'], 'transfer_failed')
                self.assertFalse(result['automatic_retry'])
                self.assertLessEqual(peer['reset'], 1)
                self.assertLessEqual(peer['load'], 1)
                if fault in ('readback_corrupt', 'write_error', 'short_results', 'write_reply_lost',
                             'initial_running', 'permission_denied', 'insufficient_space',
                             'tls_error', 'rpc_error', 'fatal_error'):
                    self.assertEqual(peer['reset'], 0)
                    self.assertEqual(peer['load'], 0)
                if fault.endswith('reply_lost'):
                    self.assertTrue(result['outcome_unknown'])
                if fault == 'load_reply_lost':
                    self.assertTrue(peer['loaded'])
                    self.assertFalse(result['load_state_verified'])
                if fault in ('rpc_error', 'fatal_error'):
                    self.assertEqual(result['failure_code'], 'remote_rsc_error')

    def test_exact_package_scope_is_checked_before_network_and_paths_are_bounded(self):
        endpoint = ControllerEndpoint('127.0.0.1', 12345, '0' * 64)
        scope = DownloadScope.loopback_fixture(endpoint, fixture_files())
        with patch('plcnext_mcp.controller_transport.socket.create_connection') as connect:
            with self.assertRaises(ProjectError):
                execute_transfer(TlsControllerClient(endpoint, scope=scope), {'Plc/public.txt': b'changed'})
            connect.assert_not_called()
        client = TlsControllerClient(endpoint, scope=scope)
        client.root = '/emulated/projects/PCWE'
        for path in ('../outside', '/absolute', 'unknown.txt', 'Plc\\public.txt'):
            with self.subTest(path=path), self.assertRaises(ProjectError):
                client._path(path)

    def test_missing_or_mismatched_operator_record_never_connects_and_valid_record_is_one_use(self):
        with tempfile.TemporaryDirectory() as directory:
            store = types.SimpleNamespace(root=Path(directory))
            review = {'review_sha256': 'a' * 64,
                      'target': {'address': '192.0.2.8', 'port': 41100,
                                 'expected_certificate_sha256': 'b' * 64,
                                 'certificate_policy': 'explicit_sha256_pin', 'authentication_mode': 'anonymous'},
                      'source': {'project_sha256': 'c' * 64}, 'package': {'inventory_sha256': 'd' * 64}}
            with patch('plcnext_mcp.controller_transport.socket.create_connection') as connect:
                with self.assertRaisesRegex(ControllerFailure, 'approval'):
                    _operator_scope(store, review, fixture_files())
                folder = store.root / 'controller-download-approvals'
                folder.mkdir()
                path = folder / ('a' * 64 + '.json')
                now = datetime.now(timezone.utc)
                receipt = {'schema': APPROVAL_SCHEMA, 'review_sha256': 'a' * 64, 'confirmed_by': 'human_user',
                           'target': review['target'], 'project_sha256': 'c' * 64, 'inventory_sha256': 'd' * 64,
                           'policy': POLICY, 'approved_actions': APPROVED_ACTIONS,
                           'preserved_unlisted_remote_files_acknowledged': True,
                           'confirmation_reference': 'PUBLIC synthetic unit fixture, not a real human approval',
                           'confirmed_utc': now.isoformat(), 'expires_utc': (now + timedelta(minutes=5)).isoformat()}
                path.write_text(json.dumps(receipt | {'inventory_sha256': 'e' * 64}))
                with self.assertRaises(ControllerFailure):
                    _operator_scope(store, review, fixture_files())
                path.write_text(json.dumps(receipt))
                scope = _operator_scope(store, review, fixture_files())
                self.assertEqual(scope.kind, 'operator_confirmed')
                with self.assertRaisesRegex(ControllerFailure, 'claimed'):
                    _operator_scope(store, review, fixture_files())
                connect.assert_not_called()

    def test_approved_transport_checks_old_declared_manifest_paths_before_any_write(self):
        files = fixture_files()
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsController(Path(directory) / 'peer', allowed_files=set(files)) as peer:
                endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
                scope = DownloadScope(endpoint, files, 'operator_confirmed', authority=_AUTHORITY)
                client = TlsControllerClient(endpoint, scope=scope)
                # Seed a fixture's existing project before any socket write;
                # this is test data in its owned temporary directory only.
                for name, data in files.items():
                    path = peer.root / name
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(data)
                result = execute_transfer(client, files, poll_timeout_seconds=0.2)
                self.assertEqual(result['status'], 'loopback_download_passed')
                self.assertFalse(result['controller_downloaded'])
                self.assertTrue(result['remote_inventory']['declared_manifest_paths_match'])
                self.assertFalse(result['remote_inventory']['complete_remote_directory_listing'])
                self.assertEqual(peer.stop_calls, 0)
                self.assertEqual(peer.load_calls, 1)


if __name__ == '__main__':
    unittest.main()
