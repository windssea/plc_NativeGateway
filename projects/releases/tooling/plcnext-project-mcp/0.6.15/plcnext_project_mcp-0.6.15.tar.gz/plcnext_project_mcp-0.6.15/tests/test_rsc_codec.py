"""Frozen actual vendor serializer vectors, plus malformed/ambiguous headers."""
from dataclasses import replace
import unittest

from plcnext_mcp.rsc_codec import (AuthenticationError, CommandHeader, CommandType,
    DATA_TAGGING, DATAGRAMMING, SECURE, decode_header, encode_header)


class RscCodecTests(unittest.TestCase):
    # Captured by tools/Invoke-RscHeaderOracle.ps1. These bytes come from the
    # installed CommandHeader.Write into a MemoryStream, not this implementation.
    VECTORS = (
        (CommandHeader(data_length=99, service_handle=12, method_handle=3, service_provider_handle=9),
         None, True, '04000200000063000c00030009007eff'),
        (CommandHeader(data_length=99, service_handle=12, method_handle=3, service_provider_handle=9),
         0, True, '04080200040063000c00030009007af700000000'),
        (CommandHeader(data_length=99, service_handle=12, method_handle=3, service_provider_handle=9),
         1, True, '04080200040063000c00030009007af701000000'),
        (CommandHeader(flags=192, data_length=32767, service_handle=32767, method_handle=32767, service_provider_handle=32767),
         0xffffffff, True, '04c802000400ff7fff7fff7fff7ff737ffffffff'),
        (CommandHeader(command_type=7, service_handle=-1, method_handle=-32768, service_provider_handle=-1),
         None, True, '0400070000000000ffff0080fffff47f'),
        (CommandHeader(data_length=1), None, False, '04000200000001000000000000000000'),
    )

    def test_actual_vendor_serialization_vectors(self):
        for header, token, checksum, expected in self.VECTORS:
            with self.subTest(expected=expected):
                self.assertEqual(encode_header(header, token, checksum=checksum).hex(), expected)

    def test_zero_token_has_secure_extension_but_absent_token_does_not(self):
        plain = encode_header(CommandHeader())
        authenticated = encode_header(CommandHeader(), 0)
        self.assertEqual(len(plain), 16)
        self.assertEqual(len(authenticated), 20)
        header, token = decode_header(authenticated, require_checksum=True)
        self.assertEqual(token, 0)
        self.assertEqual(header.flags & SECURE, SECURE)
        self.assertEqual(header.additional_header_size, 4)
        self.assertIsNone(decode_header(plain)[1])

    def test_header_preserves_measured_flags_and_signed_handles(self):
        header, token = decode_header(encode_header(CommandHeader(flags=DATAGRAMMING | DATA_TAGGING,
            service_handle=-32768, method_handle=-1), 0xffffffff))
        self.assertEqual(header.flags, DATAGRAMMING | DATA_TAGGING | SECURE)
        self.assertEqual(header.service_handle, -32768)
        self.assertEqual(header.method_handle, -1)
        self.assertEqual(token, 0xffffffff)

    def test_corrupt_nonzero_checksum_is_rejected(self):
        encoded = bytearray(encode_header(CommandHeader()))
        encoded[9] ^= 1
        with self.assertRaisesRegex(ValueError, 'checksum'):
            decode_header(bytes(encoded))

    def test_checksum_zero_sentinel_matches_vendor_but_strict_mode_rejects(self):
        raw = encode_header(CommandHeader(), checksum=False)
        self.assertEqual(decode_header(raw)[0].checksum, 0)
        with self.assertRaisesRegex(ValueError, 'checksum'):
            decode_header(raw, require_checksum=True)

    def test_truncated_or_extra_header_data_is_rejected(self):
        plain = encode_header(CommandHeader())
        secure = encode_header(CommandHeader(), 3)
        for raw in (b'', plain[:-1], secure[:-1], plain + b'x', secure + b'x'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                decode_header(raw)

    def test_unimplemented_additional_header_is_not_accepted(self):
        with self.assertRaises(ValueError):
            encode_header(CommandHeader(additional_header_size=8))
        with self.assertRaises(ValueError):
            encode_header(CommandHeader(flags=SECURE))
        raw = bytearray(encode_header(CommandHeader(), checksum=False))
        raw[4] = 8
        with self.assertRaises(ValueError):
            decode_header(bytes(raw))

    def test_out_of_range_and_boolean_fields_are_rejected(self):
        for name, value in [('version', 256), ('flags', -1), ('flags', True), ('command_type', 65536),
                            ('data_length', 32768), ('service_handle', -32769)]:
            with self.subTest(name=name), self.assertRaises(ValueError):
                encode_header(replace(CommandHeader(), **{name: value}))
        for token in (-1, 2**32, True, '1'):
            with self.subTest(token=token), self.assertRaises(ValueError):
                encode_header(CommandHeader(), token)
        with self.assertRaises(ValueError):
            encode_header(CommandHeader(flags=True), 0)
        with self.assertRaises(ValueError):
            encode_header(CommandHeader(), 0, checksum=False)

    def test_error_and_command_enums_are_measured_service_values(self):
        self.assertEqual([int(x) for x in AuthenticationError], [0, -1, -2, -3, -4, -5, -6])
        self.assertEqual(CommandType.CONNECT_REQUEST, 7)
        self.assertEqual(CommandType.CONNECT_CONFIRM, 8)
        self.assertEqual(CommandType.INVOKE_REQUEST, 2)


if __name__ == '__main__':
    unittest.main()
