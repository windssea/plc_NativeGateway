"""Source-derived runtime configuration compared with frozen vendor output."""
from copy import deepcopy
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
import zipfile

from plcnext_mcp.project import ProjectError
from plcnext_mcp.runtime_configuration import generate_runtime_configuration, validate_runtime_configuration, PATHS

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'
CURRENT = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex')
GUI = ROOT / 'artifacts/headless-research/cil-frontend/input/RES_23CA7F267545404C9FED5DC977A6399F/Configuration/Projects/PCWE'


def read_members(path):
    with zipfile.ZipFile(path) as archive:
        return {name: archive.read(name) for name in archive.namelist()}


def semantic_xml(payload):
    def node(element):
        return element.tag, sorted(element.attrib.items()), (element.text or '').strip(), [node(child) for child in element]
    return node(ET.fromstring(payload))


class RuntimeConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.members = read_members(FROZEN)

    def mutate(self, suffix, operation):
        path = next(n for n in self.members if n.endswith(suffix))
        root = ET.fromstring(self.members[path])
        operation(root)
        self.members[path] = ET.tostring(root, encoding='utf-8')

    def test_frozen_source_regenerates_vendor_runtime_documents(self):
        files, report = generate_runtime_configuration(self.members, project_title='revision-0001')
        for path, payload in files.items():
            with self.subTest(path=path):
                self.assertEqual(semantic_xml(payload), semantic_xml((GUI / path).read_bytes()))
        self.assertEqual(report['domain']['version'], '1.4.0.37')
        self.assertEqual(report['hmi_mapping_count'], 10)
        self.assertEqual(report['variable_count'], 77)
        self.assertEqual(report['gds_connector_count'], 0)
        self.assertFalse(report['runtime_execution_verified'])

    @unittest.skipUnless(CURRENT.is_file(), 'Current 61-POU managed copy not installed')
    def test_current_61_pou_source_preserves_runtime_and_mapping_semantics(self):
        current_files, current = generate_runtime_configuration(read_members(CURRENT))
        frozen_files, frozen = generate_runtime_configuration(self.members)
        self.assertEqual(current_files, frozen_files)
        self.assertEqual(current['variables'], frozen['variables'])
        self.assertEqual(current['hmi_mappings'], frozen['hmi_mappings'])
        self.assertEqual(current['ports'], frozen['ports'])
        self.assertEqual(current['programs'][0]['name'], 'MainInstance')
        self.assertEqual(current['tasks'][0]['cycleTime'], '20000000')
        self.assertTrue(current['semantic_validation']['passed'])

    def test_task_cycle_change_is_generated_and_old_output_is_rejected(self):
        before, _ = generate_runtime_configuration(self.members)
        self.mutate('EsmConfiguration.esmc', lambda root: root.find('./Tasks/Task').set('intervalTime', '40000000'))
        files, report = generate_runtime_configuration(self.members)
        self.assertEqual(report['tasks'][0]['cycleTime'], '40000000')
        self.assertNotEqual(files[PATHS['esm']], before[PATHS['esm']])
        with self.assertRaisesRegex(ProjectError, 'task timing'):
            validate_runtime_configuration(before, report)

    def test_instance_rename_updates_task_program_binding(self):
        self.mutate('EsmConfiguration.esmc', lambda root: root.find('.//ProgramInstance').set('name', 'RenamedInstance'))
        _, report = generate_runtime_configuration(self.members)
        self.assertEqual(report['programs'][0]['name'], 'RenamedInstance')
        self.assertEqual(report['task_program_relations'][0]['programName'], 'Arp.Plc.Eclr/RenamedInstance')

    def test_missing_program_or_esm_reference_is_rejected(self):
        original = deepcopy(self.members)
        self.mutate('EsmConfiguration.esmc', lambda root: root.find('.//ProgramInstance').set('programType', 'DoesNotExist'))
        with self.assertRaisesRegex(ProjectError, 'missing/non-program'):
            generate_runtime_configuration(self.members)
        self.members = original
        self.mutate('EsmConfiguration.esmc', lambda root: root.find('./Tasks/Task').set('esmId', 'missing'))
        with self.assertRaisesRegex(ProjectError, 'missing ESM'):
            generate_runtime_configuration(self.members)

    def test_changed_variable_type_or_id_is_not_hidden(self):
        original = deepcopy(self.members)
        self.mutate('DataList.dl', lambda root: root.find('.//Role/DataType').__setattr__('text', 'DINT'))
        with self.assertRaisesRegex(ProjectError, 'name/type differs'):
            generate_runtime_configuration(self.members)
        self.members = original
        self.mutate('DataList.dl', lambda root: root.find('.//Role').set('ObjectId', '00000000-0000-0000-0000-000000000000'))
        with self.assertRaisesRegex(ProjectError, 'no matching global Id'):
            generate_runtime_configuration(self.members)

    def test_nonempty_external_gds_pair_is_rejected(self):
        def connect(root):
            datums = root.findall('./DataList/Datum')
            input_datum = next(d for d in datums if d.find("Role[@TypeName='InPort']") is not None)
            output = next(d.find("Role[@TypeName='OutPort']") for d in datums if d.find("Role[@TypeName='OutPort']") is not None)
            input_datum.append(deepcopy(output))
        self.mutate('DataList.dl', connect)
        with self.assertRaisesRegex(ProjectError, 'Nonempty GDS'):
            generate_runtime_configuration(self.members)

    def test_user_plm_component_is_rejected(self):
        self.mutate('PlmConfiguration.plmc', lambda root: root.find('.//ComponentInstance').set('isReadOnly', 'false'))
        with self.assertRaisesRegex(ProjectError, 'User PLM'):
            generate_runtime_configuration(self.members)

    def test_changed_output_relation_is_rejected(self):
        files, report = generate_runtime_configuration(self.members)
        root = ET.fromstring(files[PATHS['esm']])
        relation = next(n for n in root.iter() if n.tag.endswith('}TaskProgramRelation'))
        relation.set('programName', 'Arp.Plc.Eclr/WrongInstance')
        files[PATHS['esm']] = ET.tostring(root, encoding='utf-8')
        with self.assertRaisesRegex(ProjectError, 'task/program mappings'):
            validate_runtime_configuration(files, report)

    def test_system_address_mismatch_is_rejected(self):
        def change(root):
            role = next(r for r in root.iter('Role') if r.findtext('Name') == 'IP_ACTIVE_SOCKETS')
            role.find('Address').text = '%MW1.30001'
        self.mutate('DataList.dl', change)
        with self.assertRaisesRegex(ProjectError, 'address mismatch'):
            generate_runtime_configuration(self.members)

    def test_nonempty_system_variable_task_assignment_is_rejected(self):
        def assign(root):
            node = next(n for n in root.iter('InstVal') if 'SysVarUpdateTask' in n.get('xPath', ''))
            node.text = '[UTF-8;Cyclic100]'
        self.mutate('.ds', assign)
        with self.assertRaisesRegex(ProjectError, 'system-variable update-task'):
            generate_runtime_configuration(self.members)


if __name__ == '__main__':
    unittest.main()
