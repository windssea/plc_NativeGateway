"""Final independent protocol audit: error preservation and UTF-8 credentials.

These are controlled in-memory failures. No real endpoint, username, password,
or project payload is used, and any Python socket construction fails the test.
"""
import socket
import unittest
from unittest import mock

from plcnext_mcp.binary_download import BinaryLoopbackController
from plcnext_mcp.download_services import InMemoryController, ServiceFailure
from plcnext_mcp.download_simulation import execute_download


class CloseFailingController(InMemoryController):
    def close(self):
        super().close()
        raise ServiceFailure('close_failed', 'PUBLIC offline cleanup failure fixture')


class FinalProtocolAuditTests(unittest.TestCase):
    def setUp(self):
        self.patches = [
            mock.patch.object(socket, 'socket', side_effect=AssertionError('Socket forbidden')),
            mock.patch.object(socket, 'create_connection', side_effect=AssertionError('Network forbidden')),
        ]
        for patch in self.patches:
            patch.start()
            self.addCleanup(patch.stop)

    def test_primary_write_error_survives_a_secondary_close_error(self):
        controller = CloseFailingController('write_error')
        result = execute_download({'Plc/public-fixture.bin': b'not executable'}, controller)
        self.assertEqual(result['status'], 'simulation_failed')
        self.assertEqual(result['failure_code'], 'file_write_failed')
        self.assertFalse(result['simulated_configuration_loaded'])
        self.assertTrue(result['simulated_session_disposed'])
        self.assertFalse(any(e['operation'] == 'IPlcManagerService.Load' for e in controller.trace))

    def test_close_error_preserves_the_already_loaded_configuration_fact(self):
        controller = CloseFailingController()
        result = execute_download({'Plc/public-fixture.bin': b'not executable'}, controller)
        self.assertEqual(result['status'], 'simulation_failed')
        self.assertTrue(result['simulated_configuration_loaded'])
        self.assertEqual(result['last_stage'], 'loaded_stopped')
        self.assertTrue(result['simulated_session_disposed'])
        self.assertEqual(sum(e['operation'] == 'IPlcManagerService.Load' for e in controller.trace), 1)

    def test_utf8_credentials_fail_as_authentication_not_python_type_error(self):
        # Both strings are deliberately wrong; UTF-8 is admitted by the measured
        # proxy schema. The service should return INVALID_CREDENTIALS (-1).
        for username, password in [('wrong-用户名', 'wrong-password'),
                                   ('offline-test-user', 'wrong-密码🔐')]:
            with self.subTest(username=username):
                controller = BinaryLoopbackController(token_value=0)
                try:
                    controller.check_peer_policy()
                    error, _, _ = controller.create_session(username, password)
                    self.assertEqual(error, -1)
                    self.assertFalse(controller._backend._authenticated)
                    self.assertFalse(controller._backend._enabled)
                finally:
                    controller.close()


if __name__ == '__main__':
    unittest.main()
