"""M03/M05 exact reviewed disk reads via own TLS peer; zero remote mutations."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest import mock

from plcnext_mcp import controller_package_read as module
from plcnext_mcp.controller_test_peer import LocalTlsController
from plcnext_mcp.controller_transport import ControllerEndpoint,ControllerFailure,FILE,PLC
from plcnext_mcp.deployment_package import MANIFEST
from plcnext_mcp.pcwe_native import make_pcwe_manifest
from plcnext_mcp.project import ProjectError


def files(large=False):
    value={'PCWE.software-package-manifest.json':json.dumps({'manifestVersion':'1.0','identification':
        {'name':'PUBLIC-disk-read','targetProductCodes':['2404267'],'targetFirmwareRevision':'26.0.0'}}).encode(),
        'Plc/Eclr/eCLR.img':b'RLCEPUBLIC inert image; never execute',
        'Plc/Domain/pcwe.plc.config':b'<PlcDomainConfigurationDocument/>',
        'Plc/Esm/PCWE.esm.config':b'<EsmConfigurationDocument/>',
        'Plc/Gds/PCWE.gds.config':b'<GdsConfigurationDocument/>',
        'Plc/Plm/pcwe.plm.config':b'<PlmConfigurationDocument/>'}
    if large:value['Data/PUBLIC-large.bin']=b'x'*(2*1024*1024)
    value[MANIFEST]=make_pcwe_manifest(value)
    return value


def populate(peer,payloads):
    for name,raw in payloads.items():
        path=peer.root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)


class ChangingPeer(LocalTlsController):
    def _invoke(self,service,method,values):
        result=super()._invoke(service,method,values)
        if service==FILE and method==9 and self.read_calls==1:
            path=self.root/MANIFEST;path.write_bytes(path.read_bytes()+b'\n')
        return result


class ChangingStatePeer(LocalTlsController):
    def _invoke(self,service,method,values):
        result=super()._invoke(service,method,values)
        if service==FILE and method==9 and self.read_calls==1:self.state=3 if self.state==2 else 2
        return result


class ReviewedPackageReadTests(unittest.TestCase):
    def run_read(self,root,peer,local,*,capture=False,budget=33554432,side_effect=None):
        pid='a'*32;folder=root/'managed'/pid;folder.mkdir(parents=True,exist_ok=True)
        store=SimpleNamespace(_folder=lambda selected:folder)
        review={'project_id':pid,'review_id':'b'*32,'review_sha256':'c'*64,
            'source':{'project_sha256':'d'*64},'target':{'address':peer.address,'port':peer.port,
                'expected_certificate_sha256':peer.certificate_sha256}}
        with mock.patch.object(module,'review_package_snapshot',return_value=(review,local),side_effect=side_effect) as snapshot:
            result=module.read_reviewed_controller_package(store,pid,'b'*32,'c'*64,
                capture_files=capture,maximum_bytes=budget)
        self.assertFalse(result['file_writes_attempted']);self.assertFalse(result['configuration_commands_sent'])
        self.assertFalse(result['memory_loaded_package_verified']);self.assertFalse(result['boot_identity_observed'])
        self.assertEqual(peer.write_calls,0);self.assertEqual(peer.reset_calls,0);self.assertEqual(peer.load_calls,0);self.assertEqual(peer.stop_calls,0)
        self.assertTrue(Path(result['report_path']).is_file())
        return result,snapshot,review

    def test_exact_hash_disk_read_and_capture_are_readonly(self):
        local=files()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            with LocalTlsController(root/'peer',allowed_files=set(local),initial_state=3) as peer:
                populate(peer,local);before=peer.snapshot()
                original_connect=module.ReviewedPackageReadClient.connect
                def deadline_checked(client):
                    self.assertIsNotNone(client.overall_end)
                    self.assertGreater(client.overall_end,time.monotonic())
                    self.assertLessEqual(client.overall_end-time.monotonic(),30)
                    return original_connect(client)
                with mock.patch.object(module.ReviewedPackageReadClient,'connect',deadline_checked):
                    result,snapshot,_=self.run_read(root,peer,local,capture=True)
                self.assertEqual(result['status'],'disk_package_read_verified')
                self.assertTrue(result['remote_file_contents_verified']);self.assertTrue(result['source_and_package_unchanged'])
                self.assertEqual(peer.snapshot(),before)
                self.assertGreaterEqual(snapshot.call_count,3)
                target=Path(result['snapshot_path'])
                self.assertEqual({p.relative_to(target).as_posix():p.read_bytes() for p in target.rglob('*') if p.is_file()},local)
                self.assertFalse(result['snapshot_is_source_matched_restore_package'])

    def test_corrupt_missing_and_extra_cannot_claim_complete_or_expand_paths(self):
        for selected in ('corrupt','missing','extra'):
            with self.subTest(selected=selected),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);local=files();remote=dict(local)
                if selected=='corrupt':remote['Plc/Eclr/eCLR.img']=b'PUBLIC changed bytes'
                elif selected=='missing':del remote['Plc/Gds/PCWE.gds.config']
                else:
                    remote['UNREVIEWED.bin']=b'PUBLIC must not be read'
                    remote[MANIFEST]=make_pcwe_manifest({k:v for k,v in remote.items() if k!=MANIFEST})
                with LocalTlsController(root/'peer',allowed_files=set(remote)|set(local),initial_state=3) as peer:
                    populate(peer,remote)
                    result,_,_=self.run_read(root,peer,local,capture=True)
                    self.assertFalse(result['remote_file_contents_verified']);self.assertIsNone(result['snapshot_path'])
                    self.assertFalse((Path(result['report_path']).parent/'PCWE').exists())
                    reads=[e.get('path') for e in peer.trace if e.get('operation')=='FileRead']
                    self.assertNotIn('UNREVIEWED.bin',reads)
                    if selected=='extra':self.assertEqual(result['unread_extra_manifest_paths'],['UNREVIEWED.bin'])

    def test_total_response_budget_is_enforced(self):
        local=files(large=True)
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            with LocalTlsController(root/'peer',allowed_files=set(local)) as peer:
                populate(peer,local)
                result,_,_=self.run_read(root,peer,local,capture=True,budget=1048576)
                self.assertEqual(result['status'],'package_read_failed')
                self.assertEqual(result['failure_code'],'package_read_byte_limit')
                self.assertLessEqual(result['bytes_received'],1048576);self.assertIsNone(result['snapshot_path'])

    def test_unreviewed_paths_and_write_control_are_denied_before_send(self):
        local=files()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            with LocalTlsController(root/'peer',allowed_files=set(local)) as peer:
                populate(peer,local)
                client=module.ReviewedPackageReadClient(ControllerEndpoint(peer.address,peer.port,peer.certificate_sha256),list(local))
                client.connect();client.resolve_root()
                before=len(peer.trace)
                with self.assertRaises(ControllerFailure):client.read_many(['UNREVIEWED.bin'])
                with self.assertRaises(ControllerFailure):client._call(FILE,9,[[{'path':client.root+'/UNREVIEWED.bin','traits':0}]])
                for method in (1,3,4):
                    with self.assertRaises(ControllerFailure):client._call(PLC,method,[True])
                with self.assertRaises(ControllerFailure):client.write_many([(MANIFEST,b'bad')])
                client.close()
                self.assertEqual(len(peer.trace),before)

    def test_capture_is_not_published_on_remote_or_local_identity_changes(self):
        local=files()
        for peer_type in (ChangingPeer,ChangingStatePeer):
            with tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp)
                with peer_type(root/'peer',allowed_files=set(local)) as peer:
                    populate(peer,local)
                    result,_,_=self.run_read(root,peer,local,capture=True)
                    self.assertFalse(result['manifest_and_state_stable_during_window']);self.assertIsNone(result['snapshot_path'])
        for fail_after in (1,2):
            with tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp)
                with LocalTlsController(root/'peer',allowed_files=set(local)) as peer:
                    populate(peer,local)
                    count=[0]
                    def binding(*args):
                        count[0]+=1
                        if count[0]>fail_after:raise ProjectError('PUBLIC source/package changed during read/capture')
                        return ({'source':{'project_sha256':'d'*64},'target':{'address':peer.address,'port':peer.port,
                            'expected_certificate_sha256':peer.certificate_sha256}},local)
                    result,_,_=self.run_read(root,peer,local,capture=True,side_effect=binding)
                    self.assertEqual(result['status'],'package_read_failed');self.assertIsNone(result['snapshot_path'])
                    self.assertFalse((Path(result['report_path']).parent/'PCWE').exists())


if __name__=='__main__':unittest.main()
