"""M07: independent local supervisor; never operate PLC/Hub/broker/mock."""
import json
from pathlib import Path
import socket
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock
import time
import uuid

from plcnext_mcp import fault_supervision as fault
from plcnext_mcp.controller_transport import ControllerFailure
from plcnext_mcp.project import ProjectError


class FaultSupervisionTests(unittest.TestCase):
    def test_real_backend_is_explicitly_unsupported_without_socket(self):
        caps=fault.fault_supervision_capabilities()
        self.assertFalse(caps['real_backend_available'])
        self.assertFalse(caps['restore_archive_supported'])
        with mock.patch.object(socket,'create_connection',side_effect=AssertionError('No real fault activation')) as connect:
            with self.assertRaises(ControllerFailure) as result:fault.execute_fault_review('PUBLIC')
            self.assertEqual(result.exception.code,'fault_backend_unsupported')
            connect.assert_not_called()

    def test_ttl_releases_in_independent_supervisor(self):
        with tempfile.TemporaryDirectory() as directory:
            with fault.LocalFaultSupervisor(Path(directory)/'peer') as peer:
                active=peer.activate('business_ack_blocked',150)
                self.assertTrue(active['active'])
                self.assertTrue(active['data_submission_enabled'])
                self.assertFalse(active['business_ack_enabled'])
                time.sleep(0.25)
                final=peer.observe()
                self.assertFalse(final['active'])
                self.assertTrue(final['release_verified'])
                self.assertEqual(final['release_reason'],'hard_ttl')
                self.assertGreaterEqual(final['released_monotonic_ns'],active['deadline_monotonic_ns'])
                self.assertLess(final['released_monotonic_ns']-active['deadline_monotonic_ns'],150000000)
                self.assertNotIn(peer.token,json.dumps(final))

    def test_cancel_requires_same_fault_and_boot(self):
        with tempfile.TemporaryDirectory() as directory:
            with fault.LocalFaultSupervisor(Path(directory)/'peer') as peer:
                active=peer.activate('agent_connection_offline',500)
                self.assertFalse(active['data_submission_enabled'])
                with self.assertRaises(ControllerFailure):peer.cancel('f'*32)
                with self.assertRaises(ControllerFailure):peer.cancel(active['request_id'],boot_id='wrong-boot')
                final=peer.cancel(active['request_id'])
                self.assertFalse(final['active'])
                self.assertTrue(final['data_submission_enabled'])
                self.assertTrue(final['business_ack_enabled'])

    def test_whitelist_boot_program_ttl_and_repeat_boundaries(self):
        with tempfile.TemporaryDirectory() as directory:
            with fault.LocalFaultSupervisor(Path(directory)/'peer') as peer:
                for kwargs in ({'boot_id':'wrong'}, {'inventory_sha256':'f'*64}):
                    with self.assertRaises(ControllerFailure):peer.activate('business_ack_blocked',200,**kwargs)
                for selected,ttl in [('force_anything',200),('agent_connection_offline',0),('business_ack_blocked',300001)]:
                    with self.assertRaises(ControllerFailure):peer.activate(selected,ttl)
                active=peer.activate('business_ack_blocked',500)
                with self.assertRaises(ControllerFailure):peer.activate('business_ack_blocked',500)
                peer.cancel(active['request_id'])
                with self.assertRaises(ControllerFailure):peer.activate('business_ack_blocked',500,request_id=active['request_id'])

    def test_boot_change_disarms_and_invalidates_old_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            with fault.LocalFaultSupervisor(Path(directory)/'peer') as peer:
                peer.activate('business_ack_blocked',500)
                final=peer.command({'operation':'fixture_boot_change','new_boot_id':'PUBLIC-boot-next'})
                self.assertFalse(final['active'])
                self.assertEqual(final['release_reason'],'boot_changed')
                with self.assertRaises(ControllerFailure):peer.activate('business_ack_blocked',200)

    def test_release_failure_is_reported_and_blocks_next_fault(self):
        with tempfile.TemporaryDirectory() as directory:
            with fault.LocalFaultSupervisor(Path(directory)/'peer',fixture_fault='release_failure') as peer:
                peer.activate('business_ack_blocked',100)
                time.sleep(0.2)
                final=peer.observe()
                self.assertTrue(final['release_failed'])
                self.assertFalse(final['release_verified'])
                with self.assertRaises(ControllerFailure):peer.activate('business_ack_blocked',200)

    def test_nonloopback_and_existing_directory_refused(self):
        with self.assertRaises(ProjectError):fault.fixture_request('192.0.2.8',41100,'PUBLIC',{})
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory);(p/'keep.txt').write_text('PUBLIC')
            with self.assertRaises(ProjectError):fault.LocalFaultSupervisor(p)

    def test_separate_client_exit_still_releases_and_preserves_data(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);pid='a'*32;(root/pid).mkdir()
            store=SimpleNamespace(root=root,_folder=lambda selected:root/selected)
            with mock.patch.object(fault,'_binding',return_value=(root/pid,{}, {}, {})):
                result=fault.test_fault_supervision(store,pid,'e'*64,'b'*32,fault='client_exit')
            self.assertEqual(result['status'],'loopback_supervision_passed')
            self.assertTrue(result['client_exit_injection_executed'])
            self.assertTrue(result['final']['release_verified'])
            self.assertTrue(result['final']['data_submission_enabled'])
            self.assertFalse(result['real_controller_connected'])
            self.assertTrue(Path(result['report_path']).exists())


if __name__=='__main__':unittest.main()
