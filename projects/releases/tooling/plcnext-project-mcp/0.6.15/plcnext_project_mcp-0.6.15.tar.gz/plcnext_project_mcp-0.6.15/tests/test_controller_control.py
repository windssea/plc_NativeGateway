"""M02: inert PUBLIC loopback controls and no-socket approval guards only."""
from copy import deepcopy
from contextlib import nullcontext
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest import mock

from plcnext_mcp import controller_control as control
from plcnext_mcp.controller_control_test_peer import LocalTlsControlPeer
from plcnext_mcp.controller_transport import ControllerEndpoint, ControllerFailure, FILE
from plcnext_mcp.operator_approval import OperatorApprovalError
from plcnext_mcp.project import ProjectError, sha
from plcnext_mcp.rsc_start_control import (encode_start_request, decode_start_request,
    encode_start_response, decode_start_response)


def fixture_review(endpoint=None, *, action='stop', initial_state=None, plan_id=None):
    endpoint = endpoint or ControllerEndpoint('192.0.2.8', 41100, 'f'*64)
    review = {'schema': control.REVIEW_SCHEMA, 'project_id': 'a'*32, 'review_id': 'b'*32,
        'target': control._target(endpoint.address, endpoint.certificate_sha256, endpoint.port),
        'source': {'project_sha256': sha(b'PUBLIC source'), 'project_name': 'PUBLIC inert control fixture'},
        'package': {'inventory_sha256': sha(b'PUBLIC package'), 'package_job_id': 'c'*32},
        'policy': control._policy(action, 'cold' if action == 'start' else None, 1, initial_state, plan_id),
        'approved_actions': [action], 'write_authorized': False,
        'authorization_status': 'awaiting_user_confirmation', 'requires_user_confirmation': True}
    review['review_sha256'] = control._digest(review)
    return review


def loaded_identity(client, review):
    return {'loaded_package_identity_verified': True,
        'observed_loaded_inventory_sha256': review['package']['inventory_sha256'],
        'source': 'device_loaded_module_hash', 'target': review['target']}


class ControlCodecTests(unittest.TestCase):
    def test_original_start_vectors(self):
        path = Path(__file__).resolve().parents[1]/'artifacts/rsc-control-start/oracle-01/report.json'
        report = json.loads(path.read_text(encoding='utf-8-sig'))
        for item in report['vectors']:
            name = {'RestoreWarm': 'restore_warm'}.get(item['name'], item['name'].lower())
            raw = encode_start_request(41, name, item['async'], provider_handle=5)
            self.assertEqual(raw.hex(), item['hex'])
            self.assertEqual(decode_start_request(raw)[2], {'start_kind': name, 'async_': item['async']})
        self.assertEqual(len(report['vectors']), 8)
        self.assertEqual(report['network_operations'], 0)

    def test_start_codec_strictness(self):
        raw = encode_start_request(41, 'cold', provider_handle=5)
        for length in range(len(raw)):
            with self.assertRaises(ValueError):
                decode_start_request(raw[:length])
        for kind in (None, 'Cold', 'none', 'warm_restart', 0, True):
            with self.assertRaises(ValueError):
                encode_start_request(41, kind)
        with self.assertRaises(ValueError):
            encode_start_request(41, 'cold', 1)
        with self.assertRaises(ValueError):
            decode_start_request(raw+b'\x00')
        ack = encode_start_response(41, provider_handle=5)
        self.assertEqual(decode_start_response(ack)[0].method_handle, 2)


class ControlFlowTests(unittest.TestCase):
    def run_peer(self, *, action='stop', fault='none', initial_state=None, review_initial=None,
                 verifier=loaded_identity, cancel=None, fragmented=None, plan_id=None):
        state = (3 if action == 'stop' else 2) if initial_state is None else initial_state
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsControlPeer(Path(directory)/'peer', fault=fault, initial_state=state,
                                     response_fragment_bytes=fragmented) as peer:
                endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
                review = fixture_review(endpoint, action=action, initial_state=review_initial, plan_id=plan_id)
                client = control.ControllerControlClient(endpoint, control_scope=control.ControlScope.loopback_fixture(review))
                result = control.execute_control(client, review, verify_loaded_identity=verifier,
                    cancel_event=cancel, poll_interval_seconds=0.01)
                snapshot = {'start': peer.start_calls, 'stop': peer.stop_calls,
                            'total': peer.control_calls, 'state': peer.state, 'errors': list(peer.errors)}
        self.assertFalse(peer.thread_alive)
        self.assertEqual(snapshot['errors'], [])
        self.assertFalse(result['automatic_retry'])
        self.assertLessEqual(result['request_attempt_count'], 1)
        return result, snapshot

    def test_running_stop_and_loaded_stop_start(self):
        for action in ('stop','start'):
            with self.subTest(action=action):
                result, peer = self.run_peer(action=action)
                self.assertEqual(result['status'], 'control_completed')
                self.assertTrue(result['terminal_state_verified'])
                self.assertTrue(result['action_sent'])
                self.assertTrue(result['ack_received'])
                self.assertFalse(result['outcome_unknown'])
                self.assertEqual(peer['state'], 2 if action == 'stop' else 3)
                self.assertEqual(peer['total'], 1)

    def test_already_stopped_is_readonly_completion(self):
        result, peer = self.run_peer(initial_state=2, review_initial=2)
        self.assertEqual(result['status'], 'control_already_complete')
        self.assertFalse(result['action_sent'])
        self.assertEqual(peer['total'], 0)

    def test_hot_metadata_is_not_an_error_and_does_not_cause_resend(self):
        for action in ('stop', 'start'):
            result, peer = self.run_peer(action=action, fault='hot_metadata')
            self.assertEqual(result['status'], 'control_completed')
            self.assertEqual(peer['total'], 1)
            self.assertEqual(result['final_state_raw'], (2 if action == 'stop' else 3) | 0x20000)
        result, peer = self.run_peer(initial_state=2 | 0x20000, review_initial=2 | 0x20000)
        self.assertEqual(result['status'], 'control_already_complete')
        self.assertEqual(peer['total'], 0)

    def test_original_warm_flag_allows_loaded_stop_and_running(self):
        for action in ('stop','start'):
            result, peer = self.run_peer(action=action, fault='warm_metadata')
            self.assertEqual(result['status'], 'control_completed')
            self.assertEqual(result['final_state_raw'], (2 if action == 'stop' else 3) | 0x100000)
            self.assertEqual(peer['total'], 1)
        result, peer = self.run_peer(initial_state=0x100002, review_initial=0x100002)
        self.assertEqual(result['status'],'control_already_complete')
        self.assertEqual(peer['total'],0)

    def test_hot_normalization_never_discards_error_busy_or_unknown_bits(self):
        from plcnext_mcp.plc_state import stable_state
        self.assertTrue(stable_state(0x20002, 2))
        self.assertFalse(stable_state(0x20003, 2))
        for flag in (0x80, 0x100, 0x200, 0x400, 0x800, 0x1000, 0x2000, 0x4000, 0x8000, 0x10000, 0x40000, 0x80000000):
            self.assertFalse(stable_state(2 | 0x20000 | flag, 2))

    def test_wrong_initial_state_never_sends_action(self):
        result, peer = self.run_peer(initial_state=2)
        self.assertEqual(result['failure_code'], 'control_initial_state_mismatch')
        self.assertFalse(result['action_sent'])
        self.assertEqual(peer['total'], 0)

    def test_delayed_completion_and_short_tls_fragments(self):
        for action in ('stop','start'):
            result, _ = self.run_peer(action=action, fault='state_delayed', fragmented=1)
            self.assertEqual(result['status'], 'control_completed')

    def test_ack_does_not_prove_completion(self):
        for fault in ('state_timeout','state_error','disconnect_after_ack'):
            with self.subTest(fault=fault):
                result, peer = self.run_peer(fault=fault)
                self.assertEqual(result['status'], 'control_failed')
                self.assertTrue(result['ack_received'])
                self.assertTrue(result['action_sent'])
                self.assertFalse(result['terminal_state_verified'])
                self.assertTrue(result['outcome_unknown'])
                self.assertEqual(peer['total'], 1)

    def test_lost_reply_keeps_side_effect_and_no_resend(self):
        for action in ('stop','start'):
            result, peer = self.run_peer(action=action, fault='reply_lost')
            self.assertEqual(result['status'], 'control_failed')
            self.assertFalse(result['ack_received'])
            self.assertTrue(result['action_sent'])
            self.assertTrue(result['outcome_unknown'])
            self.assertEqual(peer['total'], 1)
            self.assertEqual(peer['state'], 2 if action == 'stop' else 3)

    def test_missing_or_manifest_only_loaded_identity_refuses_start(self):
        for verifier in (None, lambda c,r:{}, lambda c,r:{**loaded_identity(c,r),'source':'remote_manifest_declaration'},
                         lambda c,r:{**loaded_identity(c,r),'observed_loaded_inventory_sha256':'e'*64}):
            result, peer = self.run_peer(action='start', verifier=verifier)
            self.assertEqual(result['status'], 'control_failed')
            self.assertFalse(result['action_sent'])
            self.assertEqual(peer['total'], 0)

    def test_cancel_before_connection_and_after_identity(self):
        event=threading.Event(); event.set()
        result, peer = self.run_peer(cancel=event)
        self.assertEqual(result['failure_code'], 'control_cancelled')
        self.assertFalse(result['action_sent'])
        event.clear()
        def verify(client, review):
            event.set()
            return loaded_identity(client, review)
        result, peer = self.run_peer(action='start', verifier=verify, cancel=event)
        self.assertEqual(result['failure_code'], 'control_cancelled')
        self.assertFalse(result['action_sent'])

    def test_cancel_after_ack_keeps_unknown_and_never_sends_inverse(self):
        event=threading.Event()
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsControlPeer(Path(directory)/'peer',fault='state_timeout') as peer:
                ep=ControllerEndpoint(peer.address,peer.port,peer.certificate_sha256)
                review=fixture_review(ep)
                def sink(item):
                    if item.get('mutating') and item.get('response_received'):event.set()
                client=control.ControllerControlClient(ep,control_scope=control.ControlScope.loopback_fixture(review),event_sink=sink)
                result=control.execute_control(client,review,cancel_event=event,poll_interval_seconds=0.01)
                self.assertTrue(result['action_sent'])
                self.assertTrue(result['ack_received'])
                self.assertTrue(result['cancelled'])
                self.assertTrue(result['outcome_unknown'])
                self.assertEqual(peer.stop_calls,1)
                self.assertEqual(peer.start_calls,0)

    def test_pin_mismatch_never_sends_rsc_or_control(self):
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsControlPeer(Path(directory)/'peer') as peer:
                ep=ControllerEndpoint(peer.address,peer.port,'0'*64)
                review=fixture_review(ep)
                client=control.ControllerControlClient(ep,control_scope=control.ControlScope.loopback_fixture(review))
                result=control.execute_control(client,review)
                self.assertEqual(result['status'],'control_failed')
                self.assertFalse(result['action_sent'])
                self.assertEqual(peer.control_calls,0)
                self.assertEqual(peer.trace,[])
    def test_same_plan_load_evidence_must_bind_all_fields(self):
        plan='d'*32
        def verify(client, review):
            return {**loaded_identity(client,review),'source':'same_plan_verified_load', 'plan_id':plan,
                'lease_held_continuously':True, 'journal_binding_verified':True,
                'readback_all_files_verified':True, 'load_state_verified':True,
                'fresh_project_name_matches':True, 'fresh_plc_state_raw':2,
                'load_execution_id':'e'*32,'load_receipt_sha256':'f'*64,'load_journal_sha256':'a'*64}
        result,_=self.run_peer(action='start',verifier=verify,plan_id=plan)
        self.assertEqual(result['status'],'control_completed')
        for field,value in [('plan_id','b'*32),('lease_held_continuously',False),('load_execution_id','bad'),('load_journal_sha256','bad')]:
            result,peer=self.run_peer(action='start',verifier=lambda c,r:{**verify(c,r),field:value},plan_id=plan)
            self.assertFalse(result['action_sent'])
            self.assertEqual(peer['total'],0)

    def test_scope_does_not_admit_download_or_second_action(self):
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsControlPeer(Path(directory)/'peer') as peer:
                ep=ControllerEndpoint(peer.address,peer.port,peer.certificate_sha256)
                review=fixture_review(ep)
                client=control.ControllerControlClient(ep,control_scope=control.ControlScope.loopback_fixture(review))
                client.connect()
                for method in (1,2,4):
                    with self.assertRaises(ControllerFailure): client._call(control.PLC,method,[True])
                with self.assertRaises(ControllerFailure):client._call(FILE,9,[])
                client.stop()
                with self.assertRaises(ControllerFailure):client.stop()
                client.close()
                self.assertEqual(peer.control_calls,1)


class ControlApprovalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.store=SimpleNamespace(root=self.root)
        self.review=fixture_review()
        self.block=mock.patch('socket.create_connection',side_effect=AssertionError('No real sockets in approval guards'))
        self.socket=self.block.start();self.addCleanup(self.block.stop)

    def receipt(self):
        now=datetime.now(timezone.utc)
        return {'schema':control.APPROVAL_SCHEMA,'review_sha256':self.review['review_sha256'],
            'confirmed_by':'human_user',**control._approval_bindings(self.review),
            'confirmed_utc':(now-timedelta(seconds=1)).isoformat(),
            'expires_utc':(now+timedelta(seconds=60)).isoformat(),
            'confirmation_reference':'PUBLIC fixture; not real human approval'}

    def write(self, record):
        directory=self.root/'controller-control-approvals';directory.mkdir(exist_ok=True)
        path=directory/(self.review['review_sha256']+'.json')
        path.write_text(json.dumps(record),encoding='utf-8')
        return path

    def test_missing_expired_wrong_action_and_download_receipt_refuse(self):
        with self.assertRaises(ControllerFailure):control._consume_control_approval(self.store,self.review,'a'*32)
        for field,value in [('approved_actions',['write_package_paths','reset','load']),('schema','plcnext-controller-download-operator-approval/v1'),('target',{}),('project_sha256','f'*64),('inventory_sha256','e'*64),('expires_utc','2020-01-01T00:00:00+00:00')]:
            record=self.receipt();record[field]=value;self.write(record)
            with self.assertRaises(OperatorApprovalError):control._consume_control_approval(self.store,self.review,'a'*32)
        self.socket.assert_not_called()

    def test_single_consumer_and_explicit_revocation(self):
        path=self.write(self.receipt())
        scope=control._consume_control_approval(self.store,self.review,'a'*32)
        self.assertEqual(scope.kind,'operator_confirmed')
        self.assertTrue(path.with_suffix('.claimed.json').exists())
        with self.assertRaises(ControllerFailure) as exc:control._consume_control_approval(self.store,self.review,'b'*32)
        self.assertEqual(exc.exception.code,'approval_already_consumed')
        self.socket.assert_not_called()

    def test_denied_and_revoked_are_distinct(self):
        path=self.write(self.receipt())
        for marker,code in [('.denied.json','approval_denied'),('.revoked.json','approval_revoked')]:
            path.with_suffix(marker).write_text('{}')
            with self.assertRaises(ControllerFailure) as exc:control._consume_control_approval(self.store,self.review,'a'*32)
            self.assertEqual(exc.exception.code,code)
            path.with_suffix(marker).unlink()

    def test_concurrent_consumption_only_one_wins(self):
        self.write(self.receipt())
        barrier=threading.Barrier(3);results=[]
        def consume():
            barrier.wait()
            try:control._consume_control_approval(self.store,self.review,uuid32());results.append('claimed')
            except ControllerFailure as exc:results.append(exc.code)
        threads=[threading.Thread(target=consume) for _ in range(2)]
        for t in threads:t.start()
        barrier.wait()
        for t in threads:t.join()
        self.assertCountEqual(results,['claimed','approval_already_consumed'])


class ControlReviewIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.pid='a'*32;self.folder=self.root/self.pid;self.folder.mkdir()
        self.store=SimpleNamespace(root=self.root,_folder=lambda pid:self.root/pid,_lock=lambda folder:nullcontext())
        self.binding={'source':{'project_sha256':sha(b'PUBLIC source'),'project_name':'PUBLIC'},
            'package':{'package_job_id':'c'*32,'inventory_sha256':sha(b'PUBLIC inventory')},'files':[]}
        self.bound=mock.patch.object(control,'_binding',return_value=(self.folder,{},self.binding,{}))
        self.binding_call=self.bound.start();self.addCleanup(self.bound.stop)
        self.lease_patch=mock.patch('plcnext_mcp.controller_transfer._endpoint_lease_root',return_value=self.root/'leases')
        self.lease_patch.start();self.addCleanup(self.lease_patch.stop)

    def prepare(self,action='stop',plan_id=None):
        return control.prepare_control_review(self.store,self.pid,self.binding['source']['project_sha256'],
            'c'*32,'192.0.2.8','f'*64,action,start_kind='cold' if action=='start' else None,plan_id=plan_id)

    def approve(self,review):
        now=datetime.now(timezone.utc)
        record={'schema':control.APPROVAL_SCHEMA,'review_sha256':review['review_sha256'],
            'confirmed_by':'human_user',**control._approval_bindings(review),
            'confirmation_reference':'PUBLIC synthetic guard fixture',
            'confirmed_utc':(now-timedelta(seconds=1)).isoformat(),'expires_utc':(now+timedelta(seconds=60)).isoformat()}
        directory=self.root/'controller-control-approvals';directory.mkdir(exist_ok=True)
        (directory/(review['review_sha256']+'.json')).write_text(json.dumps(record),encoding='utf-8')

    def test_prepare_load_revalidate_and_issuer_contract(self):
        review=self.prepare()
        loaded=control.revalidate_control_review(self.store,self.pid,review['review_id'],review['review_sha256'])
        self.assertFalse(loaded['write_authorized'])
        self.assertFalse(loaded['controller_connected'])
        contract=control.approval_contract(self.store,self.pid,review['review_id'],review['review_sha256'])
        self.assertEqual(contract.kind,'control')
        self.assertEqual(contract.approval_directory,'controller-control-approvals')
        self.assertEqual(contract.binding_fields['approved_actions'],['stop'])

    def test_source_package_tamper_and_review_tamper_rejected(self):
        review=self.prepare()
        altered=deepcopy(self.binding);altered['package']['inventory_sha256']='e'*64
        self.binding_call.return_value=(self.folder,{},altered,{})
        with self.assertRaises(ProjectError):control.revalidate_control_review(self.store,self.pid,review['review_id'],review['review_sha256'])
        path=Path(review['review_path'])
        record=json.loads(path.read_text());record['policy']['action']='start';path.write_text(json.dumps(record))
        with self.assertRaises(ProjectError):control.load_control_review(self.store,self.pid,review['review_id'],review['review_sha256'])

    def test_missing_approval_fails_before_client_creation(self):
        review=self.prepare()
        with mock.patch.object(control,'ControllerControlClient',side_effect=AssertionError('No client without approval')) as client:
            with self.assertRaises(ControllerFailure):
                control.execute_reviewed_control(self.store,self.pid,review['review_id'],review['review_sha256'])
            client.assert_not_called()
        self.assertEqual(list((self.root/'leases').glob('*.json')),[])

    def test_held_plan_lease_excludes_other_work_and_requires_same_plan(self):
        review=self.prepare(plan_id='d'*32)
        lease=control.ControlEndpointLease(review,self.folder/'PUBLIC-plan')
        try:
            with self.assertRaises(ControllerFailure):control.ControlEndpointLease(review,self.folder/'PUBLIC-other')
            other=deepcopy(review);other['policy']['plan_id']='e'*32
            with self.assertRaises(ControllerFailure):lease.validate(other)
            lease.validate(review)
        finally:lease.release()

    def test_success_and_uncertainty_lease_lifecycle(self):
        for uncertain in (False,True):
            with self.subTest(uncertain=uncertain):
                review=self.prepare();self.approve(review)
                result={'status':'control_failed' if uncertain else 'control_completed',
                    'action_sent':True,'terminal_state_verified':not uncertain,'outcome_unknown':uncertain}
                with mock.patch.object(control,'ControllerControlClient'),mock.patch.object(control,'execute_control',return_value=result):
                    returned=control.execute_reviewed_control(self.store,self.pid,review['review_id'],review['review_sha256'])
                self.assertEqual(returned['endpoint_lease_retained'],uncertain)
                self.assertEqual(Path(returned['endpoint_lease_path']).exists(),uncertain)
                if uncertain:Path(returned['endpoint_lease_path']).unlink()  # PUBLIC test cleanup after explicit assertions only.

    def test_result_persistence_failure_preserves_effect_and_quarantine(self):
        review=self.prepare();self.approve(review)
        result={'status':'control_completed','action_sent':True,'terminal_state_verified':True,'outcome_unknown':False}
        def failed_persist(path,result,sink):result['receipt_persisted']=False
        with mock.patch.object(control,'ControllerControlClient'),mock.patch.object(control,'execute_control',return_value=result),mock.patch.object(control,'_persist_result',side_effect=failed_persist):
            returned=control.execute_reviewed_control(self.store,self.pid,review['review_id'],review['review_sha256'])
        self.assertTrue(returned['terminal_state_verified'])
        self.assertFalse(returned['receipt_persisted'])
        self.assertTrue(returned['endpoint_lease_retained'])
        self.assertTrue(Path(returned['endpoint_lease_path']).exists())

    def test_loopback_entrypoint_saves_complete_evidence(self):
        for action,fault,expected in [('stop','none','loopback_control_passed'),
                                      ('start','none','loopback_control_passed'),
                                      ('start','wrong_identity','control_failed'),
                                      ('stop','reply_lost','control_failed')]:
            with self.subTest(action=action,fault=fault):
                result=control.test_controller_control(self.store,self.pid,self.binding['source']['project_sha256'],
                    'c'*32,action=action,fault=fault)
                self.assertEqual(result['status'],expected)
                self.assertTrue(Path(result['report_path']).is_file())
                self.assertTrue(Path(result['journal_path']).is_file())
                self.assertFalse(result['real_device_tested'])
                self.assertFalse(result['operator_approval_issued'])
                self.assertEqual(result['target']['address'],'127.0.0.1')


def uuid32():
    import uuid
    return uuid.uuid4().hex


if __name__=='__main__':unittest.main()
