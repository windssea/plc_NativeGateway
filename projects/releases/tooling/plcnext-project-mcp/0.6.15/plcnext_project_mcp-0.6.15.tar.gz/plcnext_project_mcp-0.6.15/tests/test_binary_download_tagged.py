"""Tagged download traffic really crosses MemoryBIO TLS; sockets are forbidden."""
import json
import socket
import unittest
from unittest import mock

from plcnext_mcp import rsc_tagged_codec as tagged
from plcnext_mcp import rsc_rpc_codec as untagged
from plcnext_mcp.binary_download_tagged import (
    TaggedBinaryLoopbackController, FILE_SERVICE, PASSWORD_SERVICE, FS_SERVICE,
    PLC_SERVICE, SERVICES, SCHEMAS,
)
from plcnext_mcp.download_services import FAULTS, FileSystemError, ServiceFailure, WriteFileData
from plcnext_mcp.download_simulation import execute_download
from plcnext_mcp.project import ProjectError
from plcnext_mcp.rsc_codec import CommandHeader, CommandType, DATA_TAGGING, DATAGRAMMING, SECURE, encode_header

FILES = {'Plc/Eclr/eCLR.img': b'TAGGED_PRIVATE_IMAGE\x00\xff\x14\x12\x09',
         'Plc/Domain/pcwe.plc.config': b'<tagged-offline-fixture/>'}


class TaggedBinaryDownloadTests(unittest.TestCase):
    def setUp(self):
        for name in ('socket', 'create_connection'):
            guard = mock.patch.object(socket, name, side_effect=AssertionError('Network forbidden'))
            guard.start()
            self.addCleanup(guard.stop)

    def ready(self, token_value=0):
        controller = TaggedBinaryLoopbackController(token_value=token_value)
        self.addCleanup(controller.close)
        controller.check_peer_policy()
        error, token, penalty = controller.create_session(*controller.credentials())
        self.assertEqual((error, token, penalty), (0, token_value, 0))
        controller.enable_security(token)
        return controller

    def assert_closed(self, controller):
        self.assertTrue(controller.session_closed)
        self.assertFalse(controller._backend._authenticated)
        self.assertFalse(controller._backend._enabled)
        self.assertEqual(controller._backend._password, '')
        self.assertIsNone(controller._backend._token)
        self.assertIsNone(controller._client_token)
        self.assertFalse(controller._connected)
        self.assertFalse(controller._client_handles)
        self.assertFalse(controller._server_handles)
        self.assertIsNone(controller._pair)

    def test_full_tagged_wire_sequence_not_untagged_payloads(self):
        controller = TaggedBinaryLoopbackController(token_value=0)
        password = controller._backend._password
        captured = []
        exchange = controller._exchange
        def capture(packet):
            answer = exchange(packet)
            header, token = controller._header(packet)
            if header.command_type == CommandType.INVOKE_REQUEST:
                service = next(name for name, handle in controller._server_handles.items()
                               if handle == header.service_handle)
                request_schemas, response_schemas = SCHEMAS[(service, header.method_handle)]
                request = tagged.decode_request(packet, request_schemas)
                response = tagged.decode_response(answer, response_schemas)
                captured.append((service, header.method_handle, packet, answer, request, response))
            else:
                captured.append((None, header.command_type, packet, answer, None, None))
            return answer
        with mock.patch.object(controller, '_exchange', side_effect=capture):
            result = execute_download(FILES, controller)
        self.assertEqual(result['status'], 'simulation_passed')
        self.assertEqual(controller.snapshot(), FILES)
        self.assertEqual(controller.tagged_discoveries, 4)
        self.assertEqual(controller.tagged_invocations, 12)
        self.assertEqual(result['rpc_exchange_attempts'], result['rpc_exchanges_completed'])
        self.assertEqual(result['memory_tls']['tls_version'], 'TLSv1.2')
        self.assertTrue(result['memory_tls']['application_data_roundtrip'])
        self.assertFalse(result['memory_tls']['socket_created'])
        self.assertFalse(result['controller_connected'])
        self.assertFalse(result['controller_downloaded'])
        self.assertFalse(result['program_started'])
        for service, method, packet, answer, request, response in captured:
            if service is None:
                if method == CommandType.CONNECT_REQUEST:
                    self.assertEqual(packet[1], DATA_TAGGING | DATAGRAMMING)
                else:
                    self.assertEqual(packet[1], DATA_TAGGING)
                self.assertEqual(answer[1], DATA_TAGGING)
                continue
            self.assertEqual(packet[1] & ~SECURE, DATA_TAGGING)
            self.assertEqual(answer[1], DATA_TAGGING)
            self.assertEqual(packet[-1:], b'\xff')
            self.assertEqual(answer[-1:], b'\xff')
            if service != PASSWORD_SERVICE:
                self.assertEqual(request[1], 0)
                self.assertEqual(packet[1], DATA_TAGGING | SECURE)
            if (service, method) == (PLC_SERVICE, 5):
                self.assertEqual(packet[20:], b'\xff')
                self.assertEqual(answer[16:17], b'\x09')
            elif service == PLC_SERVICE:
                self.assertEqual(packet[20:], b'\x02\x01\xff')
                self.assertEqual(answer[16:], b'\xff')
            elif (service, method) == (FILE_SERVICE, 8):
                self.assertEqual(packet[20:24], b'\x14\x12\x04\x00')
                self.assertEqual(answer[16:18], b'\x14\x08')
            elif (service, method) == (PASSWORD_SERVICE, 1):
                self.assertEqual(packet[16], 0x13)
                self.assertIn(b'\x24', packet[16:])
                self.assertEqual(answer[16:18], b'\x27\x09')
            elif (service, method) == (PASSWORD_SERVICE, 2):
                self.assertEqual(packet[16:], b'\x27\x09\x00\x00\x00\x00\xff')
        operations = [entry['operation'] for entry in controller.trace]
        self.assertLess(operations.index('IFileService2.ReadMany'), operations.index('IPlcManagerService.Reset'))
        self.assertLess(operations.index('IPlcManagerService.Reset'), operations.index('IPlcManagerService.Load'))
        serialized = json.dumps(result) + json.dumps(controller.trace)
        self.assertNotIn(password, serialized)
        self.assertNotIn(controller.username, serialized)
        self.assertNotIn('TAGGED_PRIVATE_IMAGE', serialized)
        self.assertNotIn('untagged', serialized)
        self.assertTrue(result['rpc_close_session_confirmed'])
        self.assert_closed(controller)

    def test_random_dynamic_handles_are_discovered_and_not_fixed(self):
        registries = []
        for seed in (200, 700):
            with mock.patch('plcnext_mcp.binary_download_tagged.secrets.randbelow', side_effect=[seed, seed + 1]):
                controller = TaggedBinaryLoopbackController(token_value=0)
            self.addCleanup(controller.close)
            controller.check_peer_policy()
            self.assertEqual(set(controller._client_handles), set(SERVICES))
            self.assertEqual(controller._client_handles, controller._server_handles)
            self.assertEqual(controller._provider_handle, seed + 1)
            self.assertEqual(len(set(controller._client_handles.values())), 4)
            registries.append(dict(controller._client_handles))
        self.assertNotEqual(registries[0], registries[1])

    def test_large_binary_stream_crosses_many_tls_records_without_ff_scanning(self):
        controller = self.ready()
        payload = bytes(range(256)) * 8193
        path = controller.root + '/Plc/large-tagged.bin'
        self.assertEqual(controller.write_many([WriteFileData(path, payload)]), [FileSystemError.NONE])
        self.assertEqual(controller.read_many([path]), [(FileSystemError.NONE, payload)])
        self.assertTrue(controller.tls_report['application_data_roundtrip'])
        self.assertGreater(len(payload), 128 * 16384)

    def test_negotiation_rejects_untagged_confirmation_and_duplicate_handles(self):
        controller = TaggedBinaryLoopbackController(token_value=0)
        self.addCleanup(controller.close)
        with mock.patch.object(controller, '_exchange', return_value=untagged.encode_connect_confirmation()):
            with self.assertRaises(ValueError):
                controller.check_peer_policy()
        controller.close()
        for fault in ('provider', 'duplicate'):
            controller = TaggedBinaryLoopbackController(token_value=0)
            self.addCleanup(controller.close)
            exchange = controller._exchange
            first = None
            def corrupt(packet):
                nonlocal first
                answer = exchange(packet)
                if int.from_bytes(packet[2:4], 'little') != CommandType.GET_SERVICE_HANDLES_REQUEST:
                    return answer
                handle, provider = tagged.decode_get_service_confirmation(answer)
                if fault == 'provider':
                    return tagged.encode_get_service_confirmation(handle, provider + 1)
                if first is None:
                    first = handle
                    return answer
                return tagged.encode_get_service_confirmation(first, provider)
            with self.subTest(fault=fault), mock.patch.object(controller, '_exchange', side_effect=corrupt):
                with self.assertRaises(ServiceFailure) as caught:
                    controller.check_peer_policy()
                self.assertEqual(caught.exception.code, 'service_negotiation_failed')

    def test_bad_headers_tags_markers_tokens_handles_and_untagged_calls_rejected(self):
        controller = self.ready()
        handle = controller._client_handles[PLC_SERVICE]
        provider = controller._provider_handle
        valid = tagged.encode_request(handle, 5, [], [], provider_handle=provider, token=0)
        corrupt = bytearray(valid)
        corrupt[0] ^= 1
        datagram = encode_header(CommandHeader(flags=DATA_TAGGING | DATAGRAMMING,
            service_handle=handle, method_handle=5, service_provider_handle=provider), 0) + b'\xff'
        packets = [bytes(corrupt), valid[:15], valid[:-1], datagram,
            untagged.encode_request(handle, 5, b'', 0, provider_handle=provider),
            tagged.encode_request(handle, 5, [], [], provider_handle=provider, token=None),
            tagged.encode_request(handle, 5, [], [], provider_handle=provider, token=1),
            tagged.encode_request(handle, 5, [], [], provider_handle=provider + 1, token=0),
            tagged.encode_request(max(controller._client_handles.values()) + 10, 5, [], [], provider_handle=provider, token=0),
            tagged.encode_request(handle, 99, [], [], provider_handle=provider, token=0),
            tagged.encode_response(handle, 5, ['uint32'], [2], provider_handle=provider)]
        for packet in packets:
            with self.subTest(packet=packet.hex()), self.assertRaises((ServiceFailure, ValueError)):
                controller._dispatch(packet)
        self.assertEqual(controller._backend._write_calls, 0)

    def test_response_wrong_type_handle_token_extra_values_and_unknown_error_profile_rejected(self):
        controller = self.ready()
        handle, provider = controller._client_handles[PLC_SERVICE], controller._provider_handle
        packets = [tagged.encode_response(handle + 1, 5, ['uint32'], [2], provider_handle=provider),
            tagged.encode_response(handle, 4, ['uint32'], [2], provider_handle=provider),
            tagged.encode_response(handle, 5, ['uint32'], [2], provider_handle=provider + 1),
            tagged.encode_response(handle, 5, ['uint32'], [2], provider_handle=provider, token=0),
            tagged.encode_response(handle, 5, ['int32'], [2], provider_handle=provider),
            tagged.encode_response(handle, 5, ['uint32', 'bool'], [2, True], provider_handle=provider),
            untagged.encode_server_error(handle, 5, 536870921, 'PUBLIC error fixture', provider_handle=provider)]
        for packet in packets:
            with self.subTest(packet=packet.hex()), mock.patch.object(controller, '_exchange', return_value=packet):
                with self.assertRaises((ServiceFailure, ValueError)):
                    controller.get_state()

    def test_all_supported_faults_fail_closed_and_preserve_ambiguous_writes(self):
        for fault in FAULTS:
            if fault == 'none':
                continue
            with self.subTest(fault=fault):
                controller = TaggedBinaryLoopbackController(fault, token_value=0)
                result = execute_download(FILES, controller)
                self.assertEqual(result['status'], 'simulation_failed')
                self.assertFalse(result['simulated_configuration_loaded'])
                self.assertFalse(result['program_started'])
                operations = [entry['operation'] for entry in controller.trace]
                if fault not in ('load_timeout', 'load_error'):
                    self.assertNotIn('IPlcManagerService.Load', operations)
                if fault not in ('load_timeout', 'load_error', 'reset_timeout'):
                    self.assertNotIn('IPlcManagerService.Reset', operations)
                if fault == 'transport_interrupted':
                    self.assertTrue(result['simulated_writes_possible'])
                    self.assertEqual(operations.count('IFileService2.WriteMany'), 1)
                self.assert_closed(controller)

    def test_unsafe_paths_and_terminal_close_have_no_hidden_writes(self):
        controller = self.ready()
        for path in (controller.root + '/../outside', controller.root + 'extra/file',
                     controller.root + '/Plc/../../outside', controller.root + '/Plc\\file'):
            with self.subTest(path=path), self.assertRaises(ProjectError):
                controller.write_many([WriteFileData(path, b'private fixture')])
        self.assertEqual(controller.snapshot(), {'obsolete-offline-fixture.tmp': b'previous simulated project'})
        controller.close()
        exchanges = controller.rpc_exchanges
        controller.close()
        self.assertEqual(controller.rpc_exchanges, exchanges)
        self.assert_closed(controller)
        for action in (controller.check_peer_policy, controller.get_state,
                       lambda: controller._dispatch(b'\0' * 16)):
            with self.assertRaises(ServiceFailure):
                action()


if __name__ == '__main__':
    unittest.main()
