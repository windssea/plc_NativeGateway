"""Review-bound preflight over actual localhost TCP/TLS; no external device."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from plcnext_mcp import controller_preflight as module
from plcnext_mcp.controller_test_peer import LocalTlsController, REMOTE_ROOT
from plcnext_mcp.controller_transport import (
    ControllerEndpoint, ControllerFailure, TlsControllerClient, FILE, FILESYSTEM, PASSWORD, PLC,
)
from plcnext_mcp.project import ProjectError

PROJECT = 'c' * 32
REVIEW = 'a' * 32
REVIEW_HASH = 'b' * 64


def software(revision='review-2'):
    return json.dumps({'manifestVersion': '1.0', 'identification': {'name': 'NativeGateway',
        'softwareRevision': revision, 'releaseDate': '2026-10-26T00:00:00Z',
        'targetProductCodes': ['2404267'], 'targetFirmwareRevision': '26.0.0'},
        'tags': {'ignored_untrusted': 'NEVER_RETURN_RAW_METADATA_SENTINEL'}}).encode('utf-8')

def manifest(files):
    items = ''.join(f'<File path="{path}" hash="{hashlib.sha512(data).hexdigest()}"/>'
                    for path, data in sorted(files.items()))
    return ('<ProjectManifestDocument schemaVersion="1.0"><Metadata><HashAlgorithm type="Sha512"/>'
            '</Metadata><Files overallHash="' + '0' * 128 + '">' + items + '</Files></ProjectManifestDocument>').encode('utf-8')

def files():
    value = {module.SOFTWARE: software(), 'Plc/Eclr/eCLR.img': b'PUBLIC preflight fixture only'}
    value[module.MANIFEST] = manifest(value)
    return value


class FakeStore:
    def __init__(self, directory):
        self.folder = Path(directory) / PROJECT
        self.folder.mkdir()
        (self.folder / 'manifest.json').write_text('{}')

    def _folder(self, identity):
        if identity != PROJECT:
            raise ProjectError('Unknown project.')
        return self.folder


def review_for(peer, payloads):
    return {'review_id': REVIEW, 'review_sha256': REVIEW_HASH,
            'source': {'project_sha256': 'e' * 64},
            'package': {'inventory_sha256': 'f' * 64, 'total_bytes': sum(map(len, payloads.values()))},
            'target': {'address': peer.address, 'port': peer.port,
                       'expected_certificate_sha256': peer.certificate_sha256}}


class ControllerPreflightTests(unittest.TestCase):
    def run_preflight(self, directory, peer, payloads, *, snapshot_side_effect=None):
        store = FakeStore(Path(directory) / 'managed') if (Path(directory) / 'managed').is_dir() else None
        if store is None:
            (Path(directory) / 'managed').mkdir()
            store = FakeStore(Path(directory) / 'managed')
        review = review_for(peer, payloads)
        with patch.object(module, 'review_package_snapshot',
                side_effect=snapshot_side_effect,
                return_value=(deepcopy(review), payloads)) as snapshot:
            result = module.preflight_download_review(store, PROJECT, REVIEW, REVIEW_HASH)
            self.assertTrue(Path(result['report_path']).is_file())
            self.assertEqual(json.loads(Path(result['report_path']).read_text())['status'], result['status'])
            self.assertEqual(snapshot.call_args_list[0].args[1:], (PROJECT, REVIEW, REVIEW_HASH))
        return result

    def test_running_controller_is_read_without_auth_or_mutations(self):
        with tempfile.TemporaryDirectory() as directory, LocalTlsController(
                Path(directory) / 'device', initial_state=3,
                allowed_files=set(module.READ_PATHS)) as peer:
            payloads = files()
            for name in module.READ_PATHS:
                (peer.root / name).write_bytes(payloads[name])
            before = peer.snapshot()
            result = self.run_preflight(directory, peer, payloads)
            self.assertEqual(result['status'], 'preflight_read_completed')
            self.assertEqual(result['plc_base_state'], 'Running')
            self.assertIn('controller_not_in_exact_stop_state', result['execution_blockers'])
            self.assertTrue(result['file_set_comparison']['declared_paths_match_review'])
            self.assertTrue(result['source_and_package_unchanged'])
            self.assertFalse(result['write_authorized'])
            self.assertFalse(result['absence_of_unlisted_files_verified'])
            self.assertEqual(peer.snapshot(), before)
            self.assertEqual((peer.write_calls, peer.stop_calls, peer.reset_calls, peer.load_calls), (0, 0, 0, 0))
            actual = {(event['service'], event['method']) for event in peer.trace if event['operation'] == 'Invoke'}
            self.assertEqual(actual, {(PLC, 5), (FILESYSTEM, 5), (FILESYSTEM, 6), (FILE, 9)})
            self.assertEqual({event['path'] for event in peer.trace if event['operation'] == 'FileRead'}, set(module.READ_PATHS))
            serialized = json.dumps(result)
            self.assertNotIn('<ProjectManifestDocument', serialized)
            self.assertNotIn('NEVER_RETURN_RAW_METADATA_SENTINEL', serialized)

    def test_remote_version_and_declared_path_difference_is_reported_without_following_paths(self):
        with tempfile.TemporaryDirectory() as directory, LocalTlsController(
                Path(directory) / 'device', allowed_files=set(module.READ_PATHS)) as peer:
            payloads = files()
            remote = {module.SOFTWARE: software('device-1'), 'Plc/obsolete.bin': b'not actually read'}
            (peer.root / module.SOFTWARE).write_bytes(remote[module.SOFTWARE])
            (peer.root / module.MANIFEST).write_bytes(manifest(remote))
            result = self.run_preflight(directory, peer, payloads)
            self.assertEqual(result['status'], 'preflight_read_completed')
            self.assertEqual(result['remote_software_identification']['softwareRevision'], 'device-1')
            self.assertFalse(result['software_comparison']['software_revision_matches'])
            self.assertEqual(result['file_set_comparison']['only_in_remote_manifest'], ['Plc/obsolete.bin'])
            self.assertIn('remote_declared_file_set_differs', result['execution_blockers'])
            self.assertFalse(result['complete_remote_directory_listing'])
            self.assertFalse(result['remote_file_contents_verified'])
            self.assertEqual(peer.read_calls, 1)
            self.assertEqual(peer.write_calls, 0)

    def test_missing_and_malformed_metadata_are_persisted_as_incomplete(self):
        for invalid in (None, b'<!DOCTYPE x [<!ENTITY e "x">]><ProjectManifestDocument/>',
                        manifest({'../outside.bin': b'fixture'})):
            with self.subTest(invalid=invalid), tempfile.TemporaryDirectory() as directory, LocalTlsController(
                    Path(directory) / 'device', allowed_files=set(module.READ_PATHS)) as peer:
                payloads = files()
                (peer.root / module.SOFTWARE).write_bytes(payloads[module.SOFTWARE])
                if invalid is not None:
                    (peer.root / module.MANIFEST).write_bytes(invalid)
                result = self.run_preflight(directory, peer, payloads)
                self.assertEqual(result['status'], 'preflight_incomplete')
                self.assertFalse(result['write_authorized'])
                self.assertTrue(any('remote_metadata_' in blocker for blocker in result['execution_blockers']))
                self.assertEqual(peer.write_calls, 0)
                self.assertNotIn('outside.bin', json.dumps(result))

    def test_stale_review_fails_before_client_creation_and_still_saves_report(self):
        with tempfile.TemporaryDirectory() as directory:
            store = FakeStore(directory)
            with patch.object(module, 'review_package_snapshot', side_effect=ProjectError('Stale review')), \
                    patch.object(module, 'TlsControllerClient') as client:
                result = module.preflight_download_review(store, PROJECT, REVIEW, REVIEW_HASH)
            client.assert_not_called()
            self.assertEqual(result['status'], 'preflight_failed')
            self.assertEqual(result['stage'], 'review_validation')
            self.assertTrue(Path(result['report_path']).is_file())
            self.assertFalse(result['peer_connected'])

    def test_review_change_during_network_reads_cannot_be_reported_current(self):
        with tempfile.TemporaryDirectory() as directory, LocalTlsController(
                Path(directory) / 'device', allowed_files=set(module.READ_PATHS)) as peer:
            payloads = files()
            for name in module.READ_PATHS:
                (peer.root / name).write_bytes(payloads[name])
            result = self.run_preflight(directory, peer, payloads, snapshot_side_effect=[
                (review_for(peer, payloads), payloads), ProjectError('Source changed')])
            self.assertEqual(result['status'], 'preflight_failed')
            self.assertEqual(result['stage'], 'source_revalidation')
            self.assertFalse(result['source_and_package_unchanged'])
            self.assertEqual(peer.write_calls, 0)

    def test_preflight_transport_private_calls_cannot_escape_fixed_read_scope(self):
        with tempfile.TemporaryDirectory() as directory, LocalTlsController(
                Path(directory) / 'device', initial_state=3) as peer:
            client = TlsControllerClient(ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256),
                                         preflight_readonly=True)
            try:
                client.connect()
                client.resolve_root()
                before = len(client.trace)
                forbidden = [
                    (PASSWORD, 1, ['fixture-user', 'PUBLIC-fixture-password']),
                    (FILE, 8, [[]]), (PLC, 1, [True]), (PLC, 3, [True]), (PLC, 4, [True]),
                    (FILESYSTEM, 5, [0, '$ARP_PROJECTS_DIR$/OTHER/']),
                    (FILESYSTEM, 6, ['/not/PCWE']),
                    (FILE, 9, [[{'path': REMOTE_ROOT + '/Plc/secret', 'traits': 0}]]),
                    (FILE, 9, [[{'path': REMOTE_ROOT + '/' + module.MANIFEST, 'traits': 1}]]),
                ]
                for service, method, values in forbidden:
                    with self.subTest(service=service, method=method), self.assertRaises(ControllerFailure):
                        client._call(service, method, values)
                self.assertEqual(len(client.trace), before)
                with self.assertRaises(ControllerFailure):
                    client.read_many(['Plc/not-metadata.bin'])
            finally:
                client.close()
            self.assertEqual((peer.write_calls, peer.stop_calls, peer.reset_calls, peer.load_calls), (0, 0, 0, 0))


if __name__ == '__main__':
    unittest.main()
