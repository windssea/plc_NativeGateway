"""Original buffer-hint/chunk oracle, not a guessed length-prefixed stream."""
import hashlib
import io
import json
from pathlib import Path
import struct
import unittest

from plcnext_mcp import rsc_tagged_codec as codec

ROOT = Path(__file__).resolve().parents[1]


class RscStreamChunkTests(unittest.TestCase):
    def test_original_nonseekable_producer_and_null_error_dto_vectors(self):
        report = json.loads((ROOT / 'artifacts/rsc-read-errors/oracle-04/report.json').read_text(encoding='utf-8-sig'))
        supported = 0
        for case in report['results']:
            if not case.get('serialize_succeeded') or not case.get('deserialize_succeeded'):
                continue
            raw = bytes.fromhex(case['hex'])
            self.assertEqual(hashlib.sha256(raw).hexdigest(), case['sha256'])
            if case['name'].startswith('nonseek-'):
                value = codec.decode_value(raw, 'stream')
                self.assertEqual(hashlib.sha256(value).hexdigest(), case['decoded_data_sha256'])
                self.assertEqual(len(value), case['decoded_data_bytes'])
                details = case['details']
                self.assertEqual(codec.encode_value('stream', codec.ChunkedStream(
                    value, 65536, details['max_read'])), raw)
            elif case['name'].startswith('read-'):
                values = codec.decode_value(raw, 'read_file_data[]')
                for value, expected in zip(values, case['decoded_items']):
                    self.assertEqual(value['result'], expected['result'])
                    self.assertEqual(hashlib.sha256(value['data']).hexdigest(), expected['data_sha256'])
            else:
                continue
            supported += 1
        self.assertGreaterEqual(supported, 20)

    def test_arbitrary_hint_multiple_zero_and_large_chunks_preserve_next_frame(self):
        payload = bytes(range(256)) * 600
        for hint in (0, 1, 7, 65536, 0x7fffffff):
            raw = b'\x22' + struct.pack('<i', hint) + struct.pack('<i', 0)
            raw += struct.pack('<i', len(payload)) + payload + struct.pack('<i', -1)
            stream = io.BytesIO(raw + b'\xffNEXT')
            decoded = codec.receive_values(lambda count: stream.read(min(count, 17)), ['stream'])
            self.assertEqual(decoded, [payload])
            self.assertEqual(stream.read(), b'NEXT')
        raw = codec.encode_values(['stream'], [codec.ChunkedStream(payload, 0x7fffffff, 7)])
        self.assertEqual(codec.decode_values(raw, ['stream']), [payload])

    def test_bounds_truncation_and_negative_fields_are_rejected(self):
        cases = [b'\x22' + struct.pack('<i', -1),
                 b'\x22' + struct.pack('<ii', 7, -2),
                 b'\x22' + struct.pack('<ii', 7, 7) + b'123',
                 b'\x22' + struct.pack('<ii', 65536, 0x7fffffff),
                 b'\x22' + struct.pack('<i', 0) + b'\0\0\0\0' * (codec.MAX_STREAM_CHUNKS + 1)]
        for raw in cases:
            with self.subTest(bytes=len(raw)), self.assertRaises(ValueError):
                codec.decode_value(raw, 'stream')
        original = codec.encode_value('stream', codec.ChunkedStream(b'\xffabc', 65536, 2))
        for length in range(len(original)):
            with self.subTest(length=length), self.assertRaises(ValueError):
                codec.decode_value(original[:length], 'stream')


if __name__ == '__main__':
    unittest.main()
