"""Outcome receipts survive cleanup errors and asynchronous load uncertainty.

The scripted clients perform no I/O. One integration case uses only an owned
literal 127.0.0.1 peer to ensure an operator-shaped scope is still not reported
as a real PLC download. No external controller or vendor service is contacted.
"""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from plcnext_mcp.controller_test_peer import LocalTlsController
from plcnext_mcp.controller_transport import (ControllerEndpoint, ControllerFailure,
    DownloadScope, TlsControllerClient, _AUTHORITY, FILE, PLC)
from plcnext_mcp.controller_transfer import execute_transfer
from plcnext_mcp.deployment_package import MANIFEST
from plcnext_mcp.pcwe_native import make_pcwe_manifest


def fixture_files():
    result = {'Plc/public-outcome-fixture.txt': b'PUBLIC inert outcome fixture\x00\xff'}
    result[MANIFEST] = make_pcwe_manifest(result)
    return result


class _Channel:
    def __init__(self, close_error=False):
        self.close_error, self.closed = close_error, False

    def close(self):
        self.closed = True
        if self.close_error:
            raise OSError('PUBLIC synthetic socket cleanup failure')


class _Clock:
    def __init__(self):
        self.value = 0.0

    def monotonic(self):
        return self.value

    def sleep(self, seconds):
        self.value += max(seconds, 0.001)


class _ScriptedClient(TlsControllerClient):
    """Retain the production close method while replacing all network methods."""
    def __init__(self, files, *, fault='none', close_error=False):
        endpoint = ControllerEndpoint('127.0.0.1', 12345, '0' * 64)
        super().__init__(endpoint, scope=DownloadScope.loopback_fixture(endpoint, files))
        self.files = files
        self.fault, self.close_error = fault, close_error
        self.phase = 'initial'
        self.reset_count = self.load_count = 0

    def connect(self):
        self.channel, self.connected = _Channel(self.close_error), True
        return {'certificate_pin_verified': True, 'fixture': 'no-I/O scripted client'}

    def get_state(self):
        if self.phase == 'initial':
            return 3 if self.fault == 'initial_running' else 2
        if self.phase == 'reset':
            return 2 if self.fault == 'reset_timeout' else 1
        if self.fault == 'load_poll_disconnected':
            raise ConnectionError('PUBLIC synthetic state-poll EOF after acknowledged Load')
        return 1 if self.fault == 'load_timeout' else 2

    def resolve_root(self):
        self.root = '/fixture/projects/PCWE'
        return self.root

    def get_space(self):
        return 2 ** 30

    def _ack(self, service, method):
        self.trace.append({'operation': 'Invoke', 'service': service, 'method': method,
                           'mutating': True, 'send_attempted': True, 'response_received': True})

    def write_many(self, batch):
        self._ack(FILE, 8)
        if self.fault == 'write_failed':
            return [5 for _ in batch]
        return [0 for _ in batch]

    def read_many(self, paths):
        return [{'result': 0, 'traits': [], 'data':
                 b'PUBLIC prior bytes' if self.fault == 'write_failed' and name != MANIFEST
                 else self.files[name]} for name in paths]

    def reset(self):
        self._ack(PLC, 4)
        self.reset_count += 1
        self.phase = 'reset'

    def load(self):
        self._ack(PLC, 1)
        self.load_count += 1
        self.phase = 'load'


class TransferOutcomeGuardTests(unittest.TestCase):
    def scripted(self, fault='none', close_error=False):
        files = fixture_files()
        client = _ScriptedClient(files, fault=fault, close_error=close_error)
        clock = _Clock()
        with patch('plcnext_mcp.controller_transport.socket.create_connection',
                   side_effect=AssertionError('Scripted outcome tests must not connect')), \
                patch('plcnext_mcp.controller_transfer.time.monotonic', side_effect=clock.monotonic), \
                patch('plcnext_mcp.controller_transfer.time.sleep', side_effect=clock.sleep):
            result = execute_transfer(client, files, poll_timeout_seconds=0.1,
                                      poll_interval_seconds=0.01)
        self.assertIsNone(client.channel)
        self.assertIsNone(client.token)
        self.assertEqual(client.handles, {})
        self.assertFalse(result['automatic_retry'])
        self.assertFalse(result['stop_command_sent'])
        self.assertFalse(result['start_command_sent'])
        self.assertFalse(result['controller_downloaded'])
        return client, result

    def test_cleanup_error_preserves_primary_write_failure_and_side_effect_receipt(self):
        client, result = self.scripted('write_failed', close_error=True)
        self.assertEqual(result['status'], 'transfer_failed')
        self.assertEqual(result['failure_code'], 'file_write_failed')
        self.assertEqual(result['cleanup_error_class'], 'OSError')
        self.assertTrue(result['files_may_have_changed'])
        self.assertEqual(client.reset_count, 0)
        self.assertEqual(client.load_count, 0)
        self.assertFalse(result['load_state_verified'])
        self.assertFalse(result['configuration_outcome_unknown'])

    def test_cleanup_error_does_not_erase_observed_loaded_stopped_state(self):
        client, result = self.scripted(close_error=True)
        self.assertEqual(result['status'], 'transfer_failed')
        self.assertEqual(result['failure_code'], 'session_cleanup_failed')
        self.assertEqual(result['cleanup_error_class'], 'OSError')
        self.assertTrue(result['configuration_reset_confirmed'])
        self.assertTrue(result['load_ack_received'])
        self.assertTrue(result['load_state_verified'])
        self.assertTrue(result['loopback_download_completed'])
        self.assertEqual(result['final_state_raw'], 2)
        self.assertEqual((client.reset_count, client.load_count), (1, 1))

    def test_acknowledged_load_with_lost_state_poll_is_unknown_without_retry(self):
        client, result = self.scripted('load_poll_disconnected')
        self.assertEqual(result['status'], 'transfer_failed')
        self.assertTrue(result['load_ack_received'])
        self.assertFalse(result['load_state_verified'])
        self.assertEqual(result['unacknowledged_mutation_requests'], 0)
        self.assertTrue(result['configuration_outcome_unknown'])
        self.assertTrue(result['outcome_unknown'])
        self.assertEqual((client.reset_count, client.load_count), (1, 1))

    def test_acknowledged_load_or_reset_timeout_is_configuration_unknown(self):
        for fault in ('load_timeout', 'reset_timeout'):
            with self.subTest(fault=fault):
                client, result = self.scripted(fault)
                self.assertEqual(result['failure_code'], 'configuration_timeout')
                self.assertEqual(result['unacknowledged_mutation_requests'], 0)
                self.assertTrue(result['configuration_outcome_unknown'])
                self.assertTrue(result['outcome_unknown'])
                self.assertFalse(result['load_state_verified'])
                self.assertEqual(client.reset_count, 1)
                self.assertEqual(client.load_count, 1 if fault == 'load_timeout' else 0)

    def test_initial_running_rejection_is_known_and_has_no_mutation(self):
        client, result = self.scripted('initial_running')
        self.assertEqual(result['failure_code'], 'initial_state_not_stopped')
        self.assertFalse(result['files_may_have_changed'])
        self.assertFalse(result['configuration_outcome_unknown'])
        self.assertFalse(result['outcome_unknown'])
        self.assertEqual(result['mutation_request_count'], 0)
        self.assertEqual((client.reset_count, client.load_count), (0, 0))

    def test_actual_loopback_with_operator_shaped_scope_never_claims_real_device_download(self):
        files = fixture_files()
        with tempfile.TemporaryDirectory() as directory:
            with LocalTlsController(Path(directory) / 'peer', allowed_files=set(files)) as peer:
                # Seed the owned localhost directory directly so the real
                # approval-shaped path can verify its old manifest before writes.
                for name, data in files.items():
                    path = peer.root / name
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(data)
                endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
                scope = DownloadScope(endpoint, files, 'operator_confirmed', authority=_AUTHORITY)
                result = execute_transfer(TlsControllerClient(endpoint, scope=scope), files,
                                          poll_timeout_seconds=0.2)
                self.assertEqual(peer.snapshot(), files)
                self.assertTrue(peer.loaded)
                self.assertEqual(peer.stop_calls, 0)
            self.assertFalse(peer.thread_alive)
        self.assertEqual(result['status'], 'loopback_download_passed')
        self.assertTrue(result['peer_connected'])
        self.assertTrue(result['loopback_download_completed'])
        self.assertTrue(result['socket_transport_used'])
        self.assertFalse(result['memory_bio_used'])
        self.assertFalse(result['controller_connected'])
        self.assertFalse(result['controller_downloaded'])
        self.assertTrue(result['load_state_verified'])


if __name__ == '__main__':
    unittest.main()
