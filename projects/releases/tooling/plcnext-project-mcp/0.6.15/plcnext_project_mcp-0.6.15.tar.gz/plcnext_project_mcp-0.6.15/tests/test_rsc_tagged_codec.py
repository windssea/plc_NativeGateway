"""Pure byte compatibility, malformed input and framing checks; no network."""
import base64
import io
import json
from pathlib import Path
import struct
import unittest

from plcnext_mcp import rsc_tagged_codec as codec
from plcnext_mcp.rsc_codec import CommandHeader, encode_header

ROOT = Path(__file__).resolve().parents[1]


def report(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8-sig'))


def sample_file():
    return {'path': '$ARP_PROJECTS_DIR$/PCWE/Plc/Eclr/eCLR.img', 'overwrite': True,
            'traits': [{'trait': 1, 'value': 420}], 'data': bytes([0, 1, 255, 128, 65, 66, 0])}


class TaggedCodecTests(unittest.TestCase):
    def test_original_scalar_array_and_struct_oracle(self):
        data = report('artifacts/rsc-tagged-values/oracle-02/report.json')
        schemas = {'bool-false': 'bool', 'bool-true': 'bool', 'byte-255': 'byte',
                   'sbyte-minus128': 'sbyte', 'int16-min': 'int16', 'uint16-max': 'uint16',
                   'int32-min': 'int32', 'int32-max': 'int32', 'uint32-zero': 'uint32',
                   'uint32-max': 'uint32', 'int64-min': 'int64', 'uint64-max': 'uint64',
                   'single': 'float32', 'double': 'float64', 'utf8-empty': 'utf8',
                   'utf8-ascii': 'utf8', 'utf8-chinese': 'utf8', 'bytes-empty': 'byte[]',
                   'bytes-binary': 'byte[]', 'int32-array': 'int32[]', 'bool-array': 'bool[]',
                   'utf8-array': 'utf8[]', 'security-token': 'security_token',
                   'write-file-array': 'write_file[]', 'write-file-struct': 'write_file'}
        for vector in data['vectors']:
            if vector['name'] == 'utf16-chinese':
                continue  # Deliberately outside the bounded UTF8 profile.
            with self.subTest(name=vector['name']):
                schema = schemas[vector['name']]
                expected = vector['input']
                if schema == 'byte[]':
                    expected = bytes(expected)
                elif schema == 'write_file[]':
                    expected = [sample_file()]
                elif schema == 'write_file':
                    expected = sample_file()
                actual = codec.encode_value(schema, expected)
                self.assertEqual(actual.hex(), vector['hex'])
                self.assertEqual(codec.decode_value(bytes.fromhex(vector['hex']), schema), expected)

    def test_original_file_service_oracle(self):
        cases = report('artifacts/plc-download-research/files/file-service-vectors.json')
        oracle = report('artifacts/rsc-tagged-values/file-oracle-01/report.json')
        vectors = {vector['case']: vector for vector in oracle['results']}
        for case in cases:
            with self.subTest(name=case['name']):
                value = case['value']
                kind = case['kind']
                if kind == 'read_request':
                    schemas, values = ['read_file_info[]'], [value]
                elif kind == 'read_response':
                    values = [[{'result': item['result'], 'traits': item['traits'],
                                'data': base64.b64decode(item['data_base64'])} for item in value]]
                    schemas = ['read_file_data[]']
                elif kind == 'errors':
                    schemas, values = ['int32[]'], [value]
                elif kind == 'supported_traits':
                    schemas, values = ['int32'], [value]
                elif kind == 'traits_request':
                    schemas, values = ['int32', 'utf8'], [value['traits'], value['path']]
                elif kind == 'traits_response':
                    schemas, values = ['filesystem_traits_entry', 'int32'], [value['entry'], value['result']]
                elif kind == 'space_request':
                    schemas, values = ['utf8'], [value]
                elif kind == 'space_response':
                    schemas, values = ['space_info', 'int32'], [value['space'], value['result']]
                else:
                    self.fail(kind)
                raw = (ROOT / 'artifacts/rsc-tagged-values/file-oracle-01' /
                       vectors[case['name']]['file']).read_bytes()
                self.assertEqual(codec.encode_values(schemas, values, end_marker=False), raw)
                self.assertEqual(codec.decode_values(raw, schemas, end_marker=False), values)

    def test_actual_original_call_message_vectors(self):
        data = report('artifacts/rsc-tagged-values/call-oracle-03/report.json')
        for vector in data['vectors']:
            with self.subTest(name=vector['name']):
                request = vector['name'].endswith('-request')
                details = vector['details']
                method = details['method']
                if method in ('Reset', 'Load'):
                    schemas = ['bool'] if request else []
                    values = [vector['name'].split('-')[1] == 'true'] if request else []
                elif method == 'GetPlcState':
                    schemas = [] if request else ['uint32']
                    values = [] if request else [int(vector['name'].split('-')[1])]
                elif method == 'CreateSession':
                    schemas = ['utf8', 'secure_utf8'] if request else ['security_token', 'int32', 'int32']
                    values = ['offline-user', 'offline-fixture-only'] if request else [1234567, 0, 0]
                elif method == 'CloseSession':
                    schemas, values = (['security_token'], [1234567]) if request else ([], [])
                else:
                    self.fail(method)
                encode = codec.encode_request if request else codec.encode_response
                actual = encode(41, details['method_id'], schemas, values, provider_handle=5)
                self.assertEqual(actual.hex(), vector['hex'])
                decode = codec.decode_request if request else codec.decode_response
                header, token, decoded = decode(bytes.fromhex(vector['hex']), schemas)
                self.assertEqual(decoded, values)
                self.assertIsNone(token)
                self.assertEqual(header.flags, 64)

    def test_prior_tagged_readonly_vectors(self):
        data = report('artifacts/plc-connection-test/tagged-oracle/vectors-01/report.json')
        for vector in data['vectors']:
            with self.subTest(name=vector['name']):
                raw = bytes.fromhex(vector['hex'])
                name = vector['name']
                if name == 'get-plc-service-request':
                    self.assertEqual(codec.encode_get_service('Arp',
                        'Arp.Plc.Domain.Services.IPlcManagerService'), raw)
                    self.assertEqual(codec.decode_get_service(raw),
                        ('Arp', 'Arp.Plc.Domain.Services.IPlcManagerService'))
                elif name == 'get-plc-service-confirmation':
                    self.assertEqual(codec.decode_get_service_confirmation(raw), (41, 5))
                    self.assertEqual(codec.encode_get_service_confirmation(41, 5), raw)
                elif name == 'get-plc-state-request':
                    self.assertEqual(codec.encode_request(41, 5, [], [], provider_handle=5), raw)
                elif name.startswith('get-state-response-'):
                    state = vector['details']['raw_state']
                    self.assertEqual(codec.encode_response(41, 5, ['uint32'], [state], provider_handle=5), raw)
                    self.assertEqual(codec.decode_response(raw, ['uint32'])[2], [state])
                else:
                    self.fail(name)

    def test_truncation_wrong_types_bounds_and_trailing_bytes(self):
        raw = codec.encode_values(['write_file[]'], [[sample_file()]])
        # Every truncation must fail; FF inside stream bytes cannot terminate a value.
        for index in range(len(raw)):
            with self.subTest(index=index):
                with self.assertRaises(ValueError):
                    codec.decode_values(raw[:index], ['write_file[]'])
        with self.assertRaises(ValueError):
            codec.decode_values(raw + b'\0', ['write_file[]'])
        for schema, value in [('bool', 1), ('byte', True), ('uint32', -1), ('int32', 2**31),
                              ('utf8', 'a\0b'), ('utf8', '\ud800'), ('float32', float('inf')),
                              ('arbitrary.Clr.Type', 0), ('byte[]', [0]), ('int32[]', [True]),
                              ('trait_item', {'trait': 2, 'value': 420})]:
            with self.subTest(schema=schema, value=repr(value)):
                with self.assertRaises(ValueError):
                    codec.encode_value(schema, value)
        for raw, schema in [(b'\x02\x02', 'bool'), (b'\x09\0\0\0\0', 'int32'),
                            (b'\x14\x08' + struct.pack('<i', -1), 'int32[]'),
                            (b'\x13\x02\0\xff\0', 'utf8'),
                            (b'\x12\x03\0', 'write_file')]:
            with self.subTest(raw=raw.hex()):
                with self.assertRaises(ValueError):
                    codec.decode_value(raw, schema)

    def test_authenticated_envelope_header_and_profile_rejection(self):
        raw = codec.encode_request(12, 5, [], [], provider_handle=9, token=0)
        header, token, values = codec.decode_request(raw, [])
        self.assertEqual(header.flags, 0x48)
        self.assertEqual(token, 0)
        self.assertEqual(values, [])
        for flags in (0, 0x80, 0xc0):
            bad = encode_header(CommandHeader(flags=flags, command_type=2,
                        service_handle=12, method_handle=5, service_provider_handle=9)) + b'\xff'
            with self.assertRaises(ValueError):
                codec.decode_request(bad, [])
        self.assertEqual(codec.decode_connect_confirmation(bytes.fromhex(
            '0440080000000000000000000000f3bf')).flags, 0x40)
        self.assertEqual(codec.encode_connect_confirmation().hex(),
                         '0440080000000000000000000000f3bf')

    def test_fragmented_schema_reader_preserves_next_frame(self):
        schemas = ['write_file[]', 'space_info', 'int32']
        values = [[sample_file()], {'capacity': 1000, 'free': 900, 'available': 800}, 0]
        raw = codec.encode_values(schemas, values)
        following = b'next frame is not consumed'
        for fragment_size in (1, 2, 7, 127):
            with self.subTest(fragment_size=fragment_size):
                memory = io.BytesIO(raw + following)
                result = codec.receive_values(lambda count: memory.read(min(fragment_size, count)), schemas)
                self.assertEqual(result, values)
                self.assertEqual(memory.read(), following)
        for index in range(len(raw)):
            memory = io.BytesIO(raw[:index])
            with self.assertRaises(ValueError):
                codec.receive_values(memory.read, schemas)
        called = []
        def unexpected(count):
            called.append(count)
            return b''
        with self.assertRaises(ValueError):
            codec.receive_values(unexpected, ['arbitrary.Clr.Type'])
        self.assertEqual(called, [])
        for result in (b'', None, b'\xff\xff'):
            with self.assertRaises(ValueError):
                codec.receive_values(lambda count: result, [])


if __name__ == '__main__':
    unittest.main()
