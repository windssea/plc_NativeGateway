"""Compare raw file DTO values with a pure original-vendor serializer oracle."""
import base64
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct
import unittest

from plcnext_mcp.project import ProjectError
from plcnext_mcp.rsc_file_codec import encode_write_many, decode_write_many
from plcnext_mcp import rsc_file_codec as codec

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'artifacts/plc-download-research/files'
ORACLE = EVIDENCE / 'oracle-vectors-01'


class RscFileCodecTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sample = {'path': '$ARP_PROJECTS_DIR$/PCWE/a', 'overwrite': True,
                      'traits': [{'trait': 1, 'value': 0o664}], 'data': b'\x00\xffA'}

    @unittest.skipUnless((ORACLE / 'report.json').is_file(), 'Original vendor value fixtures unavailable')
    def test_fifteen_original_vendor_vectors(self):
        vectors_bytes = (EVIDENCE / 'write-many-vectors.json').read_bytes()
        report = json.loads((ORACLE / 'report.json').read_text(encoding='utf-8-sig'))
        self.assertEqual(hashlib.sha256(vectors_bytes).hexdigest(), report['vectors_sha256'])
        cases = {}
        for case in json.loads(vectors_bytes):
            cases[case['name']] = [dict(path=f['path'], overwrite=f['overwrite'], traits=f['traits'],
                data=base64.b64decode(f['data_base64'])) for f in case['files']]
        self.assertEqual(len(report['results']), 15)
        for record in report['results']:
            with self.subTest(case=record['case'], version=record['version']):
                raw = (ORACLE / record['file']).read_bytes()
                self.assertEqual(hashlib.sha256(raw).hexdigest(), record['sha256'])
                self.assertTrue(record['typed_roundtrip_passed'])
                self.assertTrue(record['all_bytes_consumed'])
                self.assertEqual(encode_write_many(cases[record['case']], record['version']), raw)
                self.assertEqual(decode_write_many(raw, record['version']), cases[record['case']])

    def test_encode_rejects_unverified_version_traits_and_field_types(self):
        for version in [1, 2, 6, True, '3']:
            with self.subTest(version=version), self.assertRaises(ProjectError):
                encode_write_many([self.sample], version)
        for changes in [{'traits': [{'trait': 2, 'value': 0}]}, {'traits': [{'trait': 1, 'value': 0o1000}]},
                        {'traits': [{'trait': 1, 'value': True}]}, {'overwrite': 1}, {'data': bytearray(b'a')},
                        {'path': 'a\x00b'}, {'path': ''}, {'path': '中' * 171}, {'extra': 1}]:
            with self.subTest(changes=changes), self.assertRaises(ProjectError):
                encode_write_many([self.sample | changes])

    def test_decoder_rejects_every_truncation_and_trailing_data(self):
        encoded = encode_write_many([self.sample])
        for size in range(len(encoded)):
            with self.subTest(size=size), self.assertRaises(ProjectError):
                decode_write_many(encoded[:size])
        with self.assertRaises(ProjectError):
            decode_write_many(encoded + b'\x00')

    def test_decoder_rejects_invalid_counts_utf8_and_boolean(self):
        encoded = encode_write_many([self.sample])
        invalid_count = struct.pack('<i', -1) + encoded[4:]
        path_length = struct.unpack('<H', encoded[4:6])[0]
        boolean_offset = 6 + path_length
        invalid_boolean = encoded[:boolean_offset] + b'\x02' + encoded[boolean_offset + 1:]
        invalid_utf8 = encoded[:6] + b'\xff' + encoded[7:]
        for raw in [invalid_count, invalid_boolean, invalid_utf8]:
            with self.assertRaises(ProjectError):
                decode_write_many(raw)

    def test_decoder_rejects_unverified_chunk_form_and_wrong_terminator(self):
        item = deepcopy(self.sample)
        item['traits'] = []
        raw = encode_write_many([item])
        stream_offset = len(raw) - len(item['data']) - 12
        mismatch = raw[:stream_offset + 4] + struct.pack('<i', 1) + raw[stream_offset + 8:]
        for invalid in [mismatch, raw[:-4] + struct.pack('<i', 0)]:
            with self.assertRaises(ProjectError):
                decode_write_many(invalid)

    def test_decoder_rejects_unknown_permissions_trait(self):
        raw = encode_write_many([self.sample])
        prefix = 6 + len(self.sample['path'].encode('utf8')) + 1 + 1 + 4
        unknown = raw[:prefix] + struct.pack('<i', 2) + raw[prefix + 4:]
        with self.assertRaises(ProjectError):
            decode_write_many(unknown)

    @unittest.skipUnless((EVIDENCE / 'oracle-services-03/report.json').is_file(), 'Original service fixtures unavailable')
    def test_thirty_original_file_service_value_vectors(self):
        vector_bytes = (EVIDENCE / 'file-service-vectors.json').read_bytes()
        directory = EVIDENCE / 'oracle-services-03'
        report = json.loads((directory / 'report.json').read_text(encoding='utf-8-sig'))
        self.assertEqual(report['marshal_value'], 2)
        self.assertEqual(hashlib.sha256(vector_bytes).hexdigest(), report['vectors_sha256'])
        cases = {c['name']: c for c in json.loads(vector_bytes)}
        self.assertEqual(len(report['results']), 30)
        for record in report['results']:
            with self.subTest(case=record['case'], version=record['version']):
                case = cases[record['case']]
                value, version = deepcopy(case['value']), record['version']
                kind = case['kind']
                raw = (directory / record['file']).read_bytes()
                self.assertEqual(hashlib.sha256(raw).hexdigest(), record['sha256'])
                self.assertTrue(record['typed_roundtrip_passed'])
                self.assertTrue(record['all_bytes_consumed'])
                if kind == 'read_request':
                    encoded, decoded = codec.encode_read_many_request(value, version), codec.decode_read_many_request(raw, version)
                elif kind == 'read_response':
                    value = [{'result': f['result'], 'traits': f['traits'], 'data': base64.b64decode(f['data_base64'])} for f in value]
                    encoded, decoded = codec.encode_read_many_response(value, version), codec.decode_read_many_response(raw, version)
                elif kind == 'errors':
                    encoded, decoded = codec.encode_file_errors(value, version), codec.decode_file_errors(raw, version)
                elif kind == 'supported_traits':
                    encoded, decoded = codec.encode_supported_traits_response(value, version), codec.decode_supported_traits_response(raw, version)
                elif kind == 'traits_request':
                    encoded, decoded = codec.encode_traits_entry_request(value['path'], value['traits'], version), codec.decode_traits_entry_request(raw, version)
                elif kind == 'traits_response':
                    encoded, decoded = codec.encode_traits_entry_response(value['entry'], value['result'], version), codec.decode_traits_entry_response(raw, version)
                elif kind == 'space_request':
                    encoded, decoded = codec.encode_space_request(value, version), codec.decode_space_request(raw, version)
                elif kind == 'space_response':
                    encoded, decoded = codec.encode_space_response(value['space'], value['result'], version), codec.decode_space_response(raw, version)
                else:
                    self.fail(kind)
                self.assertEqual(encoded, raw)
                self.assertEqual(decoded, value)

    def test_additional_value_decoders_reject_truncation_and_trailing_bytes(self):
        entry = {'path': '/sim/PCWE/', 'is_file': False, 'is_directory': True, 'traits': []}
        fixtures = [(codec.encode_read_many_request([{'path': 'a', 'traits': 1}]), codec.decode_read_many_request),
            (codec.encode_read_many_response([{'result': 0, 'traits': [], 'data': b'ab'}]), codec.decode_read_many_response),
            (codec.encode_file_errors([0, 5]), codec.decode_file_errors),
            (codec.encode_supported_traits_response(31), codec.decode_supported_traits_response),
            (codec.encode_traits_entry_request('a', 1), codec.decode_traits_entry_request),
            (codec.encode_traits_entry_response(entry), codec.decode_traits_entry_response),
            (codec.encode_space_request('a'), codec.decode_space_request),
            (codec.encode_space_response({'capacity': 100, 'free': 90, 'available': 80}), codec.decode_space_response)]
        for payload, decode in fixtures:
            for length in range(len(payload)):
                with self.subTest(decode=decode.__name__, length=length), self.assertRaises(ProjectError):
                    decode(payload[:length])
            with self.subTest(decode=decode.__name__), self.assertRaises(ProjectError):
                decode(payload + b'\x00')

    def test_additional_value_encoders_reject_unknown_results_masks_and_space(self):
        for value in [-1, 7, True]:
            with self.subTest(result=value), self.assertRaises(ProjectError):
                codec.encode_file_errors([value])
        for value in [-1, 32, True]:
            with self.subTest(mask=value), self.assertRaises(ProjectError):
                codec.encode_supported_traits_response(value)
        with self.assertRaises(ProjectError):
            codec.encode_space_response({'capacity': -1, 'free': 0, 'available': 0})
        with self.assertRaises(ProjectError):
            codec.encode_traits_entry_response({'path': 'a', 'is_file': 1, 'is_directory': False, 'traits': []})


if __name__ == '__main__':
    unittest.main()
