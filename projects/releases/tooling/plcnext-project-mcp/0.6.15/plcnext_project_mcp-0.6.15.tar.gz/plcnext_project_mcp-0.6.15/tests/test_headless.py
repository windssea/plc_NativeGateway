"""Host trust boundaries; no vendor execution in these unit tests."""
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

from plcnext_mcp.headless import check_st
from plcnext_mcp.project import ProjectError, ProjectStore


ROOT = Path(__file__).resolve().parents[1]


class HeadlessHostTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = ProjectStore(Path(self.temp.name))
        self.project = self.store.import_copy(str(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'))
        self.environment = mock.patch('plcnext_mcp.headless.parser_environment', return_value={
            'available': True, 'powershell': 'pwsh', 'install_directory': 'vendor-install'})
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def call(self):
        return check_st(self.store, self.project['project_id'], 'NG_ReadAck')

    def report(self, command, **options):
        source = Path(command[command.index('-Source') + 1])
        output = Path(command[command.index('-Output') + 1])
        import hashlib
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        data = {'status': 'completed', 'source_sha256': digest, 'source_sha256_after': digest,
                'parse': {'errors': 0, 'warnings': 0, 'messages': []}}
        output.write_text(json.dumps(data))
        self.assertEqual(options['timeout'], 30)
        self.assertNotIn('shell', options)
        return subprocess.CompletedProcess(command, 0)

    def test_timeout_never_becomes_success(self):
        with mock.patch('plcnext_mcp.headless.subprocess.run', side_effect=subprocess.TimeoutExpired('pwsh', 30)):
            with self.assertRaisesRegex(ProjectError, '30 seconds'):
                self.call()

    def test_missing_report_never_becomes_success(self):
        with mock.patch('plcnext_mcp.headless.subprocess.run', return_value=subprocess.CompletedProcess([], 0)):
            with self.assertRaisesRegex(ProjectError, 'JSON report'):
                self.call()

    def test_input_hash_mismatch_is_rejected(self):
        def changed_report(command, **options):
            result = self.report(command, **options)
            output = Path(command[command.index('-Output') + 1])
            data = json.loads(output.read_text())
            data['source_sha256_after'] = '0' * 64
            output.write_text(json.dumps(data))
            return result
        with mock.patch('plcnext_mcp.headless.subprocess.run', side_effect=changed_report):
            with self.assertRaisesRegex(ProjectError, 'exact input'):
                self.call()

    def test_syntax_success_is_never_compile_success(self):
        with mock.patch('plcnext_mcp.headless.subprocess.run', side_effect=self.report):
            result = self.call()
        self.assertTrue(result['syntax_passed'])
        self.assertFalse(result['compiled'])
        self.assertFalse(result['whole_project_compiled'])
        self.assertEqual(result['project_sha256'], self.project['project_sha256'])


if __name__ == '__main__':
    unittest.main()
