"""M01 PUBLIC issuer fixtures only: no real review, PLC or human impersonation.

Interactive IO is an explicit terminal double. It tests the dialog and receipt
contract, not physical human presence or OS account isolation. Every endpoint is
RFC5737 documentation space; socket creation is forbidden throughout.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from dataclasses import asdict
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest import mock

from plcnext_mcp import operator_approval as issuer
from plcnext_mcp import controller_transfer as transfer
from plcnext_mcp.controller_download_plan import POLICY
from plcnext_mcp.project import sha


class TerminalDouble(io.StringIO):
    def isatty(self):
        return True


class OperatorApprovalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.now = datetime.now(timezone.utc)
        self.review_sha = sha(b'PUBLIC review: not a real program or target')
        self.contract = issuer.OperatorApprovalContract(
            kind='download', review_sha256=self.review_sha,
            receipt_schema=issuer.DOWNLOAD_RECEIPT_SCHEMA,
            approval_directory='controller-download-approvals',
            binding_fields={
                'target': {'address': '192.0.2.8', 'port': 41100,
                    'expected_certificate_sha256': 'f' * 64,
                    'certificate_policy': 'explicit_sha256_pin', 'authentication_mode': 'anonymous'},
                'project_sha256': sha(b'PUBLIC source'),
                'inventory_sha256': sha(b'PUBLIC inventory'),
                'policy': dict(POLICY), 'approved_actions': list(issuer.DOWNLOAD_ACTIONS),
                'preserved_unlisted_remote_files_acknowledged': True,
            },
            display={'source': {'project_name': 'PUBLIC-inert-fixture'}, 'impact': {'no_test_device': True}},
        )
        for name in ('socket', 'create_connection'):
            patch = mock.patch.object(socket, name, side_effect=AssertionError('No device/network in issuer tests'))
            patch.start()
            self.addCleanup(patch.stop)

    def console(self, text=None, *, terminal=True):
        if text is None:
            text = ('APPROVE ' + self.review_sha + '\nPUBLIC-TEST-NOT-A-HUMAN-APPROVAL\n'
                    'I ACCEPT THE DISPLAYED ACTIONS AND EFFECTS\n')
        stream_type = TerminalDouble if terminal else io.StringIO
        return issuer.InteractiveConsole(stream_type(text), stream_type())

    def issue(self, **kwargs):
        return issuer.issue_interactive_approval(self.root, lambda: self.contract,
            console=kwargs.pop('console', self.console()), now=self.now, **kwargs)

    def paths(self):
        return issuer._paths(self.root, self.contract)

    def withdraw(self):
        return issuer.withdraw_interactive_approval(self.root, lambda: self.contract,
            console=self.console('WITHDRAW ' + self.review_sha + '\nPUBLIC-WITHDRAWAL\n'))

    def test_fixture_terminal_issues_exact_v1_download_receipt(self):
        result = self.issue()
        self.assertEqual(result['status'], 'ready')
        self.assertFalse(result['device_contacted'])
        record = json.loads(self.paths()['receipt'].read_bytes())
        self.assertEqual(record['approved_actions'], ['write_package_paths', 'sha512_readback', 'reset', 'load'])
        self.assertNotIn('stop', record['approved_actions'])
        self.assertNotIn('start', record['approved_actions'])
        self.assertEqual(record['policy'], POLICY)
        self.assertEqual(record['review_sha256'], self.review_sha)
        self.assertEqual(record['confirmed_by'], 'human_user')
        self.assertTrue(result['audit_completion_persisted'])
        issuer.validate_operator_receipt(record, self.contract, now=self.now)

    def test_mcp_issues_distinct_exact_receipts_for_all_operation_kinds(self):
        for kind in ('download', 'control', 'recovery', 'instrumented_fault'):
            contract = issuer.OperatorApprovalContract(**{**asdict(self.contract), 'kind': kind,
                'approval_directory': f'controller-{kind.replace("_", "-")}-approvals',
                'receipt_schema': f'plcnext-controller-{kind}-operator-approval/v1'})
            result = issuer.issue_mcp_approval(self.root, lambda: contract,
                reason='PUBLIC autonomous MCP decision', now=self.now)
            self.assertEqual(result['status'], 'ready')
            self.assertEqual(result['confirmed_by'], 'mcp_policy')
            self.assertFalse(result['device_contacted'])
            receipt = json.loads(issuer._paths(self.root, contract)['receipt'].read_bytes())
            self.assertIn('-mcp-approval/v1', receipt['schema'])
            issuer.validate_operator_receipt(receipt, contract, now=self.now)
            with self.assertRaises(issuer.OperatorApprovalError):
                issuer.issue_mcp_approval(self.root, lambda: contract, reason='No duplicate', now=self.now)

    def test_mcp_download_consumer_checks_contract_and_claims_once(self):
        issuer.issue_mcp_approval(self.root, lambda: self.contract, reason='PUBLIC decision', now=self.now)
        review = {'project_id':'a'*32, 'review_id':'b'*32, 'review_sha256':self.review_sha,
            'source':{'project_sha256':self.contract.binding_fields['project_sha256']},
            'package':{'inventory_sha256':self.contract.binding_fields['inventory_sha256']},
            'target':self.contract.binding_fields['target']}
        store = type('PublicStore', (), {'root':self.root})()
        with mock.patch.object(issuer, 'download_approval_contract', return_value=self.contract):
            scope = transfer._operator_scope(store, review, {'PUBLIC.txt':b'inert'})
            self.assertEqual(scope.kind, 'mcp_authorized')
            with self.assertRaises(transfer.ControllerFailure) as failure:
                transfer._operator_scope(store, review, {'PUBLIC.txt':b'inert'})
            self.assertEqual(failure.exception.code, 'approval_already_consumed')

    def test_mcp_cannot_relabel_human_receipt_or_skip_revalidation(self):
        self.issue()
        original = json.loads(self.paths()['receipt'].read_bytes())
        with self.assertRaises(issuer.OperatorApprovalError):
            issuer.validate_operator_receipt({**original,'confirmed_by':'mcp_policy'}, self.contract, now=self.now)
        self.paths()['receipt'].unlink()
        changed = issuer.OperatorApprovalContract(**{**asdict(self.contract),
            'display':{'source':'changed PUBLIC fixture'}})
        contracts = iter((self.contract, changed))
        with self.assertRaises(issuer.OperatorApprovalError) as failure:
            issuer.issue_mcp_approval(self.root, lambda: next(contracts), reason='PUBLIC decision', now=self.now)
        self.assertEqual(failure.exception.code, 'review_changed')
        self.assertFalse(self.paths()['receipt'].exists())

    def test_refuses_noninteractive_stdin_or_stdout_before_loading_review(self):
        for stdin, stdout in ((io.StringIO('yes\n'), TerminalDouble()),
                              (TerminalDouble('yes\n'), io.StringIO())):
            loader = mock.Mock(side_effect=AssertionError('Review must not be loaded'))
            with self.subTest(stdin=type(stdin).__name__), self.assertRaises(issuer.OperatorApprovalError) as failure:
                issuer.issue_interactive_approval(self.root, loader,
                    console=issuer.InteractiveConsole(stdin, stdout))
            self.assertEqual(failure.exception.code, 'interactive_operator_required')
            loader.assert_not_called()
        self.assertFalse(self.paths()['receipt'].exists())

    def test_requires_exact_full_hash_and_effect_phrase(self):
        invalid = ['yes\n', 'APPROVE ' + self.review_sha[:12] + '\n',
                   'APPROVE ' + '0' * 64 + '\n',
                   'APPROVE ' + self.review_sha + '\nPUBLIC-ref\nyes\n']
        for answer in invalid:
            with self.subTest(answer=answer[:20]), self.assertRaises(issuer.OperatorApprovalError) as failure:
                self.issue(console=self.console(answer))
            self.assertEqual(failure.exception.code, 'operator_cancelled')
            self.assertFalse(self.paths()['receipt'].exists())
            self.assertFalse(self.paths()['lock'].exists())

    def test_reference_empty_overlong_control_char_or_eof_refused(self):
        for reference in ('', 'x' * 513, 'PUBLIC\x1bsecret'):
            text = 'APPROVE ' + self.review_sha + '\n' + reference + '\nI ACCEPT THE DISPLAYED ACTIONS AND EFFECTS\n'
            with self.subTest(reference=reference[:8]), self.assertRaises(issuer.OperatorApprovalError):
                self.issue(console=self.console(text))
            self.assertFalse(self.paths()['receipt'].exists())
        with self.assertRaises(issuer.OperatorApprovalError):
            self.issue(console=self.console(''))

    def test_validity_boundaries_and_booleans_refused(self):
        for lifetime in (0, 3601, True, 1.5):
            with self.subTest(lifetime=lifetime), self.assertRaises(issuer.OperatorApprovalError) as failure:
                self.issue(lifetime_seconds=lifetime)
            self.assertEqual(failure.exception.code, 'invalid_lifetime')
        result = self.issue(lifetime_seconds=3600)
        self.assertEqual(result['status'], 'ready')

    def test_no_silent_reissue_existing_or_expired_receipt(self):
        self.issue(lifetime_seconds=1)
        raw = self.paths()['receipt'].read_bytes()
        future = self.now + timedelta(seconds=2)
        state = issuer.inspect_operator_approval(self.root, self.contract, now=future)
        self.assertEqual(state['status'], 'expired')
        self.assertFalse(state['may_issue'])
        with self.assertRaises(issuer.OperatorApprovalError) as failure:
            self.issue()
        self.assertEqual(failure.exception.code, 'approval_not_reissuable')
        self.assertEqual(self.paths()['receipt'].read_bytes(), raw)

    def test_changed_contract_during_confirmation_never_publishes(self):
        changed = issuer.OperatorApprovalContract(**{
            **self.contract.__dict__, 'display': {'source': {'project_name': 'PUBLIC-changed'}}})
        loader = mock.Mock(side_effect=[self.contract, changed])
        with self.assertRaises(issuer.OperatorApprovalError) as failure:
            issuer.issue_interactive_approval(self.root, loader, console=self.console(), now=self.now)
        self.assertEqual(failure.exception.code, 'review_changed')
        self.assertFalse(self.paths()['receipt'].exists())

    def test_revocation_reserves_consumer_claim_and_keeps_evidence(self):
        self.issue()
        raw = self.paths()['receipt'].read_bytes()
        result = self.withdraw()
        self.assertEqual(result['status'], 'revoked')
        self.assertTrue(self.paths()['claimed'].exists())
        self.assertTrue(self.paths()['revoked'].exists())
        self.assertEqual(self.paths()['receipt'].read_bytes(), raw)
        status = issuer.inspect_operator_approval(self.root, self.contract)
        self.assertEqual(status['status'], 'revoked')
        self.assertFalse(status['may_issue'])
        with self.assertRaises(issuer.OperatorApprovalError):
            self.issue()

    def test_denial_without_receipt_permanently_reserves_hash(self):
        result = self.withdraw()
        self.assertEqual(result['status'], 'denied')
        self.assertFalse(self.paths()['receipt'].exists())
        self.assertTrue(self.paths()['claimed'].exists())
        self.assertEqual(issuer.inspect_operator_approval(self.root, self.contract)['status'], 'denied')
        with self.assertRaises(issuer.OperatorApprovalError):
            self.issue()

    def test_cannot_revoke_a_consumed_or_uncertain_action(self):
        self.issue()
        paths = self.paths()
        paths['claimed'].write_text(json.dumps({'review_sha256': self.review_sha, 'execution_id': 'PUBLIC-uncertain'}))
        with self.assertRaises(issuer.OperatorApprovalError) as failure:
            self.withdraw()
        self.assertEqual(failure.exception.code, 'approval_already_consumed')
        self.assertEqual(issuer.inspect_operator_approval(self.root, self.contract)['status'], 'consumed')
        self.assertTrue(paths['receipt'].exists())

    def test_existing_consumer_accepts_issued_receipt_once_without_network(self):
        self.issue()
        review = {'review_sha256': self.review_sha,
            'source': {'project_sha256': self.contract.binding_fields['project_sha256']},
            'package': {'inventory_sha256': self.contract.binding_fields['inventory_sha256']},
            'target': self.contract.binding_fields['target']}
        store = type('PublicStore', (), {'root': self.root})()
        scope = transfer._operator_scope(store, review, {'PUBLIC-fixture.txt': b'PUBLIC inert'})
        self.assertEqual(scope.kind, 'operator_confirmed')
        with self.assertRaises(transfer.ControllerFailure) as failure:
            transfer._operator_scope(store, review, {'PUBLIC-fixture.txt': b'PUBLIC inert'})
        self.assertEqual(failure.exception.code, 'approval_already_consumed')
        self.assertEqual(issuer.inspect_operator_approval(self.root, self.contract)['status'], 'consumed')

    def test_revoked_receipt_rejected_by_existing_consumer(self):
        self.issue()
        self.withdraw()
        review = {'review_sha256': self.review_sha,
            'source': {'project_sha256': self.contract.binding_fields['project_sha256']},
            'package': {'inventory_sha256': self.contract.binding_fields['inventory_sha256']},
            'target': self.contract.binding_fields['target']}
        store = type('PublicStore', (), {'root': self.root})()
        with self.assertRaises(transfer.ControllerFailure) as failure:
            transfer._operator_scope(store, review, {'PUBLIC-fixture.txt': b'PUBLIC inert'})
        self.assertEqual(failure.exception.code, 'approval_already_consumed')

    def test_concurrent_issuers_publish_only_one_receipt(self):
        entered = threading.Event()
        release = threading.Event()
        output = []
        class PausingConsole(issuer.InteractiveConsole):
            def ask(inner, question):
                entered.set()
                release.wait(3)
                return super().ask(question)
        console = self.console()
        paused = PausingConsole(console.stdin, console.stdout)
        def worker():
            try:
                output.append(self.issue(console=paused))
            except Exception as exc:
                output.append(exc)
        thread = threading.Thread(target=worker)
        thread.start()
        self.assertTrue(entered.wait(3))
        try:
            with self.assertRaises(issuer.OperatorApprovalError) as failure:
                self.issue()
            self.assertEqual(failure.exception.code, 'issuer_busy')
        finally:
            release.set()
            thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertEqual(len(output), 1)
        self.assertIsInstance(output[0], dict)
        self.assertEqual(output[0]['status'], 'ready')

    def test_consumer_wins_during_withdrawal_and_no_cancel_is_claimed(self):
        self.issue()
        review = {'review_sha256': self.review_sha,
            'source': {'project_sha256': self.contract.binding_fields['project_sha256']},
            'package': {'inventory_sha256': self.contract.binding_fields['inventory_sha256']},
            'target': self.contract.binding_fields['target']}
        store = type('PublicStore', (), {'root': self.root})()
        io_pair = self.console('WITHDRAW ' + self.review_sha + '\nPUBLIC-WITHDRAWAL\n')
        class ConsumerRacesConsole(issuer.InteractiveConsole):
            def ask(inner, question):
                answer = super().ask(question)
                if question.startswith('Human withdrawal'):
                    transfer._operator_scope(store, review, {'PUBLIC-fixture.txt': b'PUBLIC inert'})
                return answer
        with self.assertRaises(issuer.OperatorApprovalError) as failure:
            issuer.withdraw_interactive_approval(self.root, lambda: self.contract,
                console=ConsumerRacesConsole(io_pair.stdin,io_pair.stdout))
        self.assertEqual(failure.exception.code,'approval_already_consumed')
        self.assertFalse(self.paths()['revoked'].exists())
        self.assertEqual(issuer.inspect_operator_approval(self.root,self.contract)['status'],'consumed')

    def test_distinct_versioned_control_contract_does_not_expand_download_actions(self):
        control = issuer.OperatorApprovalContract(
            kind='control',review_sha256=sha(b'PUBLIC stop review'),
            receipt_schema='plcnext-controller-control-operator-approval/v1',
            approval_directory='controller-control-approvals',
            binding_fields={**self.contract.binding_fields,'approved_actions':['stop'],
                            'policy':{'action':'stop','automatic_retry':False}},
            display={'action':'stop','expected_initial_state':3,'required_terminal_state':2})
        typed = 'APPROVE '+control.review_sha256+'\nPUBLIC-CONTROL-FIXTURE\nI ACCEPT THE DISPLAYED ACTIONS AND EFFECTS\n'
        result = issuer.issue_interactive_approval(self.root,lambda:control,
            console=self.console(typed),now=self.now)
        receipt = json.loads(Path(result['receipt_path']).read_bytes())
        self.assertEqual(receipt['approved_actions'],['stop'])
        self.assertEqual(receipt['schema'],'plcnext-controller-control-operator-approval/v1')
        self.assertFalse(self.paths()['receipt'].exists())

    def test_receipt_boolean_and_integer_binding_are_distinct(self):
        self.issue()
        record=json.loads(self.paths()['receipt'].read_bytes())
        record['preserved_unlisted_remote_files_acknowledged']=1
        with self.assertRaises(issuer.OperatorApprovalError) as failure:
            issuer.validate_operator_receipt(record,self.contract,now=self.now)
        self.assertEqual(failure.exception.code,'approval_binding_mismatch')

    def test_receipt_validation_rejects_each_binding_mismatch(self):
        self.issue()
        record = json.loads(self.paths()['receipt'].read_bytes())
        for field, value in [('schema','wrong'), ('review_sha256','0'*64),
            ('target',{'address':'192.0.2.9'}), ('project_sha256','0'*64),
            ('inventory_sha256','0'*64), ('approved_actions',['stop']),
            ('policy',{}), ('confirmed_by','mcp_model')]:
            altered = deepcopy(record)
            altered[field] = value
            with self.subTest(field=field), self.assertRaises(issuer.OperatorApprovalError) as failure:
                issuer.validate_operator_receipt(altered, self.contract, now=self.now)
            self.assertEqual(failure.exception.code, 'approval_binding_mismatch')

    def test_receipt_time_validation_rejects_expired_future_naive_overlong(self):
        self.issue()
        record = json.loads(self.paths()['receipt'].read_bytes())
        intervals = [(self.now-timedelta(hours=1), self.now-timedelta(seconds=1)),
                     (self.now+timedelta(seconds=1), self.now+timedelta(minutes=5)),
                     (self.now.replace(tzinfo=None), self.now+timedelta(minutes=5)),
                     (self.now-timedelta(minutes=1), self.now+timedelta(hours=2))]
        for begin,end in intervals:
            altered = {**record, 'confirmed_utc':begin.isoformat(), 'expires_utc':end.isoformat()}
            with self.subTest(begin=begin), self.assertRaises(issuer.OperatorApprovalError) as failure:
                issuer.validate_operator_receipt(altered, self.contract, now=self.now)
            self.assertEqual(failure.exception.code, 'approval_expired')

    def test_invalid_contract_paths_and_reserved_fields_refused(self):
        for changes in ({'approval_directory':'../escape'}, {'review_sha256':'0'*12},
                        {'binding_fields':{**self.contract.binding_fields,'confirmed_by':'mcp'}},
                        {'binding_fields':{**self.contract.binding_fields,'approved_actions':[]}}):
            value = issuer.OperatorApprovalContract(**{**self.contract.__dict__,**changes})
            with self.subTest(changes=list(changes)), self.assertRaises(issuer.OperatorApprovalError):
                value.checked()

    def test_audit_has_no_file_payloads_credentials_or_token(self):
        self.issue()
        raw = self.paths()['audit'].read_text(encoding='utf-8')
        for secret in ('password','token','PUBLIC source','PUBLIC inventory','confirmation_reference'):
            self.assertNotIn(secret, raw)
        records = [json.loads(line) for line in raw.splitlines()]
        self.assertEqual([r['operation'] for r in records], ['issuance_intent','approval_issued'])

    def test_public_cli_inspect_and_noninteractive_issue(self):
        base = ['--workspace',str(self.root),'--project-id','a'*32,
                '--review-id','b'*32,'--review-sha256',self.review_sha]
        with mock.patch.object(issuer,'load_approval_contract',return_value=self.contract), \
             mock.patch('sys.stdout',new_callable=io.StringIO) as stdout:
            code = issuer.main(['inspect',*base])
            self.assertEqual(code,0)
            self.assertEqual(json.loads(stdout.getvalue())['status'],'unconfirmed')
        with mock.patch.object(issuer,'load_approval_contract',side_effect=AssertionError('Not loaded')), \
             mock.patch('sys.stdin',io.StringIO('yes\n')), \
             mock.patch('sys.stdout',io.StringIO()), \
             mock.patch('sys.stderr',new_callable=io.StringIO) as stderr:
            code = issuer.main(['issue',*base])
            self.assertEqual(code,2)
            self.assertEqual(json.loads(stderr.getvalue())['failure_code'],'interactive_operator_required')
        self.assertFalse(self.paths()['receipt'].exists())

    def test_cli_has_no_automatic_yes_option(self):
        with mock.patch('sys.stderr',io.StringIO()), self.assertRaises(SystemExit) as failure:
            issuer.main(['issue','--project-id','a'*32,'--review-id','b'*32,
                         '--review-sha256',self.review_sha,'--yes'])
        self.assertEqual(failure.exception.code,2)

    def test_module_entry_uses_canonical_adapter_dataclass_identity(self):
        # Actual -m/runpy entry used to define a second __main__ dataclass, so
        # genuine control/recovery adapter contracts failed isinstance checks.
        # PUBLIC adapter doubles test this startup boundary without any network,
        # approval issuance, build/package fixture or human impersonation.
        code = '''
import importlib,json,runpy,socket,sys,warnings
from unittest.mock import patch
from plcnext_mcp import operator_approval as issuer
def no_network(*args,**kwargs): raise AssertionError('PUBLIC CLI must not connect')
socket.socket=socket.create_connection=no_network
data=json.load(sys.stdin)
contract=issuer.OperatorApprovalContract(**data['contract'])
adapter=importlib.import_module('plcnext_mcp.'+data['adapter'])
sys.argv=['plcnext_mcp.operator_approval','inspect','--workspace',data['workspace'],
 '--kind',data['contract']['kind'],'--project-id','a'*32,'--review-id','b'*32,
 '--review-sha256',data['contract']['review_sha256']]
warnings.filterwarnings('ignore',category=RuntimeWarning,module='runpy')
with patch.object(adapter,'approval_contract',return_value=contract):
 runpy.run_module('plcnext_mcp.operator_approval',run_name='__main__')
'''
        for kind,adapter in [('control','controller_control'),('recovery','controller_recovery'),
                              ('instrumented_fault','instrumented_fault')]:
            with self.subTest(kind=kind):
                contract=asdict(self.contract)
                contract.update(kind=kind,approval_directory='controller-'+kind.replace('_','-')+'-approvals')
                process=subprocess.run([sys.executable,'-I','-c',code],
                    input=json.dumps({'contract':contract,'adapter':adapter,'workspace':str(self.root)}),
                    capture_output=True,text=True,timeout=20)
                self.assertEqual(process.returncode,0,process.stderr)
                self.assertEqual(json.loads(process.stdout)['status'],'unconfirmed')
                self.assertFalse(any(self.root.rglob('*.json')))


if __name__ == '__main__':
    unittest.main()
