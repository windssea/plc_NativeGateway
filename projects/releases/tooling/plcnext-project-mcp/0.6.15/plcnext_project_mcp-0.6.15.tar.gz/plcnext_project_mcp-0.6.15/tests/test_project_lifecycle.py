"""Project creation and FB lifetime: files only, no Engineer/ACI/PLC execution."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import tempfile
from threading import Barrier
import unittest
from unittest import mock
import xml.etree.ElementTree as ET
import zipfile

from plcnext_mcp.lifecycle import DEFAULT_TEMPLATE, PROJ, TYPES
from plcnext_mcp.project import ProjectError, ProjectStore, pou_index, read_archive, sha, xml


FROZEN = Path(__file__).resolve().parents[1] / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'
MAIN = 'PROJECT/Logical%20Elements/Main.pou/'
FB = 'PROJECT/Logical%20Elements/FB_New.pou/'


def local(node):
    return node.tag.rsplit('}', 1)[-1]


def minimal_project(path):
    members = {
        PROJ: b'''<Project xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><PropertyGroup><ProjectId>12345678-1234-1234-1234-123456789abc</ProjectId></PropertyGroup><ItemGroup><Folder Include="Logical Elements\\Main.pou"><Id>11111111-1111-1111-1111-111111111111</Id><FolderType>PouFolder</FolderType><ParentIndex>0</ParentIndex></Folder><File Include="mapping.xml"><Id>22222222-2222-2222-2222-222222222222</Id></File></ItemGroup></Project>''',
        TYPES: b'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="meta" ContentType="application/octet-stream"/><Default Extension="var" ContentType="application/octet-stream"/></Types>',
        MAIN + 'Metadata.meta': b'<Metadata><Kind>Program</Kind><Id>11111111-1111-1111-1111-111111111111</Id><ItemGroup><VariableWorksheet><Id>33333333-3333-3333-3333-333333333333</Id></VariableWorksheet><CodeWorksheet Include="Code.st"><Id>44444444-4444-4444-4444-444444444444</Id><Extension>.st</Extension><Type>.st</Type><ParentIndex>2</ParentIndex></CodeWorksheet></ItemGroup></Metadata>',
        MAIN + 'Code.st': b'(* Main *)\r\n',
        MAIN + 'Variables.var': b'VAR\r\nEND_VAR\r\n',
        'PROJECT/mapping.xml': b'<Mapping object="22222222-2222-2222-2222-222222222222"/>',
        'PROJECT/opaque.bin': b'\xff\x00\x81PLC fixture',
    }
    with zipfile.ZipFile(path, 'w') as archive:
        archive.comment = b'preserve package comment'
        for name, payload in members.items():
            info = zipfile.ZipInfo(name, (2026, 2, 3, 4, 5, 6))
            info.comment = b'preserve member comment'
            info.external_attr = 0o100640 << 16
            archive.writestr(info, payload)


class ProjectLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='plcnext-lifecycle-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'minimal.pcwex'
        minimal_project(self.source)
        self.original = self.source.read_bytes()
        self.store = ProjectStore(self.root / 'managed')
        self.initial = self.store.import_copy(str(self.source))
        self.project_id = self.initial['project_id']

    def tearDown(self):
        self.assertEqual(self.source.read_bytes(), self.original)

    def add(self, **overrides):
        values = dict(project_id=self.project_id,
                      expected_project_sha256=self.store.inspect(self.project_id)['project_sha256'],
                      add_fbs=[{'pou_name': 'FB_New', 'code': 'Value := Value + 1;\n',
                                'variables': 'VAR_INPUT\nEnable : BOOL;\nEND_VAR\nVAR\nValue : INT;\nEND_VAR\n'}])
        values.update(overrides)
        return self.store.change_structure(**values)

    def update(self, name='Main', **values):
        pou = self.store.read_pou(self.project_id, name)
        return dict(pou_name=name, expected_code_sha256=pou['code_sha256'],
                    expected_variables_sha256=pou['variables_sha256'], **values)

    def current(self):
        return self.store._current(self.project_id)[2]

    def tamper(self, member, payload):
        folder, manifest, members, infos, comment = self.store._current(self.project_id)
        members[member] = payload
        path = Path(self.store.inspect(self.project_id)['project_path'])
        with zipfile.ZipFile(path, 'w') as archive:
            archive.comment = comment
            existing = set()
            for info in infos:
                archive.writestr(info, members[info.filename])
                existing.add(info.filename)
            for name in set(members) - existing:
                archive.writestr(name, members[name])
        manifest['current_sha256'] = sha(path.read_bytes())
        self.store._save_manifest(folder, manifest)

    def test_add_retains_every_other_payload_id_and_zip_record(self):
        _, before, infos, comment = read_archive(self.source)
        result = self.add()
        _, after, new_infos, new_comment = read_archive(Path(result['project_path']))
        self.assertEqual(set(after) - set(before), {FB, FB + 'Code.st', FB + 'Variables.var', FB + 'Metadata.meta'})
        for name in before:
            if name not in {PROJ, TYPES}:
                self.assertEqual(before[name], after[name], name)
        self.assertEqual(comment, new_comment)
        for old, new in zip(infos, new_infos):
            self.assertEqual((old.filename, old.date_time, old.external_attr, old.comment),
                             (new.filename, new.date_time, new.external_attr, new.comment))
        old_project, new_project = xml(before[PROJ]), xml(after[PROJ])
        old_nodes = [ET.tostring(n) for group in old_project for n in group]
        new_nodes = [ET.tostring(n) for group in new_project for n in group]
        self.assertEqual(old_nodes, new_nodes[:-1])
        metadata = xml(after[FB + 'Metadata.meta'])
        ids = [node.text for node in metadata.iter('Id')]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(metadata.findtext('Kind'), 'FunctionBlock')
        self.assertEqual(pou_index(before)['Main'], pou_index(after)['Main'])
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])
        self.assertFalse(result['compiled'])
        self.assertFalse(result['aci_used'])
        self.assertEqual(self.store.diff(self.project_id, 'FB_New')['change'], 'added')
        self.assertIn('+Value :=', self.store.diff_pou(self.project_id, 'FB_New')['code']['diff'])

    def test_add_with_caller_update_then_atomic_remove_and_delete(self):
        result = self.add(updates=[self.update(code='Runner(Enable := TRUE);\n',
                                              variables='VAR\nRunner : FB_New;\nEND_VAR\n')])
        with self.assertRaisesRegex(ProjectError, 'referenced'):
            self.store.change_structure(self.project_id, result['project_sha256'], delete_fbs=['FB_New'])
        result = self.store.change_structure(self.project_id, result['project_sha256'], delete_fbs=['FB_New'],
                                            updates=[self.update(code='(* caller removed *)\n', variables='VAR\nEND_VAR\n')])
        self.assertNotIn('FB_New', pou_index(self.current()))
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])
        self.assertFalse(result['compiled'])

    def test_delete_existing_fb_has_removed_diff(self):
        first = self.add()
        imported = self.store.import_copy(first['project_path'])
        self.project_id = imported['project_id']
        deleted = self.store.change_structure(self.project_id, imported['project_sha256'], delete_fbs=['FB_New'])
        self.assertEqual(self.store.diff(self.project_id, 'FB_New')['change'], 'deleted')
        diff = self.store.diff_pou(self.project_id, 'FB_New')
        self.assertIn('-Value :=', diff['code']['diff'])
        self.assertIn('-Enable : BOOL;', diff['variables']['diff'])
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])
        self.assertEqual(deleted['revision'], 1)

    def test_array_and_multi_variable_type_references_are_not_missed(self):
        for declaration in ('a, b : FB_New;', 'a : ARRAY [0..2] OF FB_New;'):
            with self.subTest(declaration=declaration):
                if 'FB_New' not in pou_index(self.current()):
                    self.add()
                p = self.store.inspect(self.project_id)
                self.store.update_pous(self.project_id, p['project_sha256'],
                                       [self.update(variables='VAR\n' + declaration + '\nEND_VAR\n')])
                p = self.store.inspect(self.project_id)
                with self.assertRaisesRegex(ProjectError, 'referenced'):
                    self.store.change_structure(self.project_id, p['project_sha256'], delete_fbs=['FB_New'])

    def test_calls_and_xml_mappings_prevent_dangling_deleted_instance(self):
        first = self.add(updates=[self.update(code='Runner();\n', variables='VAR\nRunner : FB_New;\nEND_VAR\n')])
        self.tamper('PROJECT/mapping.xml', b'<Mapping instance="Runner"/>')
        # This reference check is independent of the external-edit integrity gate.
        p = self.store.inspect(self.project_id)
        with self.assertRaisesRegex(ProjectError, 'remains referenced'):
            self.store.change_structure(self.project_id, p['project_sha256'], delete_fbs=['FB_New'],
                                        updates=[self.update(code='(* gone *)\n', variables='VAR\nEND_VAR\n')])
        self.assertEqual(self.store.inspect(self.project_id)['revision'], first['revision'])

    def test_stale_or_invalid_batch_never_creates_partial_revision(self):
        old = self.initial['project_sha256']
        self.add()
        with self.assertRaises(ProjectError):
            self.add(expected_project_sha256=old, add_fbs=[{'pou_name': 'Other'}])
        before = self.store.inspect(self.project_id)
        bad_requests = [dict(add_fbs=[{'pou_name': 'Good'}, {'pou_name': '../Bad'}]),
                        dict(add_fbs=[{'pou_name': 'fb_new'}]), dict(add_fbs=[{'pou_name': 'CON'}]),
                        dict(add_fbs=[{'pou_name': 'VAR_INPUT'}]), dict(add_fbs=[{'pou_name': 'A', 'extra': 1}]),
                        dict(add_fbs={}), dict(add_fbs=[{'pou_name': 'A'}], updates=[{'pou_name': []}]),
                        dict(add_fbs=None, delete_fbs=['Main'])]
        for request in bad_requests:
            with self.subTest(request=request), self.assertRaises(ProjectError):
                self.add(**request)
            self.assertEqual(self.store.inspect(self.project_id), before)
        self.assertEqual(len(list((self.store.root / self.project_id).glob('revision-*.pcwex'))), 2)

    def test_orphan_project_folder_record_cannot_be_duplicated(self):
        self.tamper(PROJ, self.current()[PROJ].replace(b'</Project>',
                    b'<ItemGroup><Folder Include="Logical Elements\\FB_New.pou"><Id>55555555-5555-5555-5555-555555555555</Id></Folder></ItemGroup></Project>'))
        with self.assertRaisesRegex(ProjectError, 'folder record'):
            self.add()
        self.assertEqual(self.store.inspect(self.project_id)['revision'], 0)

    def test_new_worksheets_remain_editable_and_validate_after_regular_updates(self):
        self.add()
        p = self.store.read_pou(self.project_id, 'FB_New')
        self.store.update_pous(self.project_id, p['project_sha256'],
                               [self.update('FB_New', code='Value := Value + 2;\n',
                                            variables='VAR\nValue : DINT;\nEND_VAR\n')])
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_structural_ledger_cannot_allow_metadata_or_project_payload_drift(self):
        self.add()
        for member in (FB + 'Metadata.meta', PROJ, 'PROJECT/opaque.bin'):
            with self.subTest(member=member):
                before = self.current()[member]
                self.tamper(member, before + b' ')
                result = self.store.validate(self.project_id)
                self.assertFalse(result['preservation_passed'])
                self.assertIn(member, result['unexpected_members'])
                self.tamper(member, before)
        folder, manifest = self.store._load(self.project_id)
        manifest['allowed_variable_members'].append(FB + 'Metadata.meta')
        self.store._save_manifest(folder, manifest)
        self.assertIn(FB + 'Metadata.meta', self.store.validate(self.project_id)['invalid_allowed_members'])

    def test_deleted_members_cannot_be_resurrected_through_worksheet_allowlist(self):
        first = self.add()
        self.store.change_structure(self.project_id, first['project_sha256'], delete_fbs=['FB_New'])
        self.tamper(FB + 'Code.st', b'RETURN;\n')
        folder, manifest = self.store._load(self.project_id)
        manifest['allowed_code_members'].append(FB + 'Code.st')
        self.store._save_manifest(folder, manifest)
        self.assertFalse(self.store.validate(self.project_id)['preservation_passed'])

    def test_manifest_failure_rolls_back_and_orphan_revision_can_be_skipped(self):
        folder = self.store.root / self.project_id
        with mock.patch.object(self.store, '_save_manifest', side_effect=OSError('injected manifest failure')):
            with self.assertRaises(OSError):
                self.add()
        self.assertEqual(self.store.inspect(self.project_id)['revision'], 0)
        self.assertFalse((folder / 'revision-0001.pcwex').exists())
        (folder / 'revision-0001.pcwex').write_bytes(b'orphan never overwrite')
        result = self.add()
        self.assertEqual(result['revision'], 2)
        self.assertEqual((folder / 'revision-0001.pcwex').read_bytes(), b'orphan never overwrite')
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_competing_structure_requests_have_one_atomic_winner(self):
        barrier = Barrier(2)
        def attempt(name):
            barrier.wait()
            try:
                return self.add(expected_project_sha256=self.initial['project_sha256'], add_fbs=[{'pou_name': name}])
            except ProjectError as error:
                return error
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(attempt, ['FB_One', 'FB_Two']))
        self.assertEqual(sum(isinstance(item, dict) for item in results), 1)
        self.assertEqual(len(pou_index(self.current())), 2)
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_real_frozen_engineering_payloads_survive_addition(self):
        frozen_sha = sha(FROZEN.read_bytes())
        p = self.store.import_copy(str(FROZEN))
        before = self.store._current(p['project_id'])[2]
        result = self.store.change_structure(p['project_id'], p['project_sha256'], add_fbs=[{'pou_name': 'FB_Extra'}])
        after = read_archive(Path(result['project_path']))[1]
        for name in before:
            if name not in {PROJ, TYPES}:
                self.assertEqual(before[name], after[name], name)
        self.assertEqual(len(pou_index(after)), 32)
        self.assertEqual(sha(FROZEN.read_bytes()), frozen_sha)
        self.assertTrue(self.store.validate(p['project_id'])['preservation_passed'])


@unittest.skipUnless(DEFAULT_TEMPLATE.is_file(), 'official AXC F 2152 template is not installed')
class InstalledTemplateCreationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='plcnext-template-')
        self.addCleanup(self.temp.cleanup)
        self.store = ProjectStore(Path(self.temp.name) / 'managed')
        self.template_hash = sha(DEFAULT_TEMPLATE.read_bytes())

    def tearDown(self):
        self.assertEqual(sha(DEFAULT_TEMPLATE.read_bytes()), self.template_hash)

    def test_fresh_independent_projects_have_st_main_and_no_template_cache(self):
        a, b = self.store.create_project('Alpha'), self.store.create_project('Beta')
        self.assertNotEqual(a['resource_name'], b['resource_name'])
        self.assertNotEqual(a['project_id'], b['project_id'])
        source = read_archive(DEFAULT_TEMPLATE)[1]
        built = [read_archive(Path(item['project_path']))[1] for item in (a, b)]
        identities = []
        for item, members in zip((a, b), built):
            index = pou_index(members)
            self.assertEqual(set(index), {'Main'})
            self.assertTrue(index['Main']['has_st'])
            self.assertFalse(item['compiled'])
            self.assertEqual(xml(members['_properties/Extended.xml']).findtext('Type'), 'Project')
            project = xml(members[PROJ])
            self.assertFalse(any(local(node) in {'TemplateDescription', 'TemplateImage', 'CompilerProjectReference'} for node in project.iter()))
            self.assertFalse(any(Path(path).name.lower().startswith(('compilerproject', 'lastbuild')) for path in members))
            ids = {node.text for node in project.iter() if local(node) in {'Id', 'ProjectId', 'InstanceId'}}
            identities.append(ids)
            self.assertTrue(self.store.validate(item['project_id'])['preservation_passed'])
            content_types = xml(members[TYPES])
            self.assertTrue(any(node.get('Extension') == 'st' for node in content_types))
            for node in content_types:
                if local(node) == 'Override':
                    self.assertIn(node.get('PartName').lstrip('/'), members)
            for path, payload in members.items():
                if path.endswith('.rels'):
                    for node in xml(payload):
                        if node.get('TargetMode') != 'External':
                            self.assertIn(node.get('Target').lstrip('/'), members)
            reimported = self.store.import_copy(item['project_path'])
            self.assertEqual(pou_index(self.store._current(reimported['project_id'])[2]), index)
        self.assertTrue(identities[0].isdisjoint(identities[1]))
        # Device/catalog identity is retained while project object identities change.
        def type_ids(members):
            return [node.text for node in xml(members[PROJ]).iter() if local(node) == 'TypeId']
        self.assertEqual(type_ids(source), type_ids(built[0]))

    def test_invalid_creation_never_writes_a_managed_project(self):
        for name in ('../bad', 'CON', '', 'trailing.', ' spaced ', 'line\nname'):
            with self.subTest(name=name), self.assertRaises(ProjectError):
                self.store.create_project(name)
        self.assertFalse(self.store.root.exists())
        with mock.patch.object(self.store, '_save_manifest', side_effect=OSError('manifest unavailable')):
            with self.assertRaises(OSError):
                self.store.create_project('Fault')
        self.assertEqual(list(self.store.root.iterdir()), [])


if __name__ == '__main__':
    unittest.main()
