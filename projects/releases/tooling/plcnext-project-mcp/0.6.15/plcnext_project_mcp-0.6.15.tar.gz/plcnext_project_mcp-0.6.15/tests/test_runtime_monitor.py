"""Runtime scalar oracle, source fences, real local TLS, and window semantics."""
from pathlib import Path
from io import BytesIO
import json
import tempfile
import unittest
from unittest.mock import patch

from plcnext_mcp.project import ProjectStore, ProjectError, read_archive, sha
from plcnext_mcp.runtime_monitor import (SourceSymbols, RuntimeReadClient, prepare_runtime_read_plan,
    load_runtime_read_plan, read_runtime_plan, test_runtime_monitor, project_runtime_symbols, _canonical)
from plcnext_mcp.rsc_runtime_codec import receive_read_items, receive_variant, encode_read_items
from plcnext_mcp.controller_transport import ControllerEndpoint, ControllerFailure

ROOT=Path(__file__).resolve().parents[1]
FROZEN=ROOT/'artifacts/runtime-monitor-research/NativeGateway.restore-native-0.5.0.frozen.pcwex'
ORACLE=ROOT/'artifacts/runtime-monitor-research/oracle-01/report.json'


class RuntimeCodecTests(unittest.TestCase):
    def test_original_formatter_all_32_vectors_are_exactly_consumed(self):
        vectors=json.loads(ORACLE.read_text(encoding='utf-8-sig'))['vectors']
        count=0
        for vector in vectors:
            if not vector['name'].endswith('-response'):continue
            body=bytes.fromhex(vector['hex'])[16:]
            reader=BytesIO(body)
            if vector['name']=='read-mixed-response':
                result=receive_read_items(reader.read,expected_count=4)
                self.assertEqual([x['wire_type'] for x in result],['uint64','utf8','float64','null'])
                self.assertEqual(result[3]['error_code'],1)
                encoded=encode_read_items([{k:x[k] for k in ['error_code','wire_type','value']} for x in result])
                self.assertEqual(encoded,body)
            elif vector['name']=='project-name-response':
                self.assertEqual(receive_variant(reader.read)['value'],'NativeGateway')
            else:
                # ReadSingle uses a single struct tag, the same measured item payload.
                converted=b'\x14'+body[:3]+b'\x01\x00\x00\x00'+body[3:]
                reader=BytesIO(converted)
                result=receive_read_items(reader.read,expected_count=1)
                self.assertEqual(encode_read_items([{k:x[k] for k in ['error_code','wire_type','value']} for x in result]),converted)
            self.assertEqual(reader.read(),b'')
            count+=1
        self.assertEqual(count,16)

    def test_partial_count_unknown_tag_composite_and_truncation_fail(self):
        good=encode_read_items([{'error_code':0,'wire_type':'bool','value':True}])
        for bad in [good[:-1],good[:10]+b'\x12'+good[11:],good.replace(b'\x05\x00',b'\x08\x00',1)]:
            with self.subTest(body=bad.hex()),self.assertRaises(ValueError):
                receive_read_items(BytesIO(bad).read,expected_count=1)
        with self.assertRaisesRegex(ValueError,'count'):
            receive_read_items(BytesIO(good).read,expected_count=2)
        with self.assertRaisesRegex(ValueError,'Unsupported runtime value tag'):
            receive_variant(BytesIO(b'\x12\x00\x00\xff').read)

    def test_short_fragment_reader_and_strict_string_limit(self):
        data=encode_read_items([{'error_code':0,'wire_type':'utf8','value':'测试'}])
        reader=BytesIO(data)
        row=receive_read_items(lambda count:reader.read(min(count,1)),expected_count=1)[0]
        self.assertEqual(row['value'],'测试')
        with self.assertRaisesRegex(ValueError,'string exceeds'):
            receive_variant(BytesIO(b'\x13\x00\x20').read)


class RuntimeMonitorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='runtime-read-')
        self.addCleanup(self.temp.cleanup)
        self.store=ProjectStore(Path(self.temp.name)/'managed')
        self.project=self.store.import_copy(str(FROZEN))
        self.pid,self.hash=self.project['project_id'],self.project['project_sha256']
        self.model=SourceSymbols(read_archive(Path(self.project['project_path']))[1])

    def plan(self,**kwargs):
        return prepare_runtime_read_plan(self.store,self.pid,self.hash,'127.0.0.1','a'*64,**kwargs)

    def test_declared_alias_struct_array_and_global_paths(self):
        self.assertEqual(self.model.resolve('MainInstance.Active.Version')['wire_type'],'uint64')
        self.assertEqual(self.model.resolve('MainInstance.Samples[250].Quality')['declared_type'],'STRING[24]')
        self.assertEqual(self.model.resolve('HMI.InvalidAcks')['wire_type'],'uint32')
        for symbol in ['MainInstance.Samples[321].Quality','MainInstance.Samples[0].Quality',
                'MainInstance.Active','MainInstance.Bootstrap.Password','/etc/passwd','Arp.Other/x',
                'MainInstance.NoSuchVariable','MainInstance.Samples','MainInstance..BootId']:
            with self.subTest(symbol=symbol),self.assertRaises(ProjectError):self.model.resolve(symbol)
        listing=project_runtime_symbols(self.store,self.pid,self.hash)
        self.assertFalse(listing['controller_connected'])
        self.assertFalse(listing['remote_loaded_identity_verified'])

    def test_source_plan_hash_and_limits_no_network(self):
        with patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
            p=self.plan(symbols=['MainInstance.BootId','MainInstance.Missing'])
            self.assertFalse(p['write_authorized'])
            self.assertEqual(p['requests'][1]['status'],'unsupported_source_symbol')
            self.assertEqual(load_runtime_read_plan(self.store,self.pid,p['plan_id'],p['plan_sha256'])['project_sha256'],self.hash)
        for kwargs in [{'chunk_size':65},{'minimum_interval_seconds':0},{'maximum_bytes':99999999},
                       {'symbols':['MainInstance.BootId']*2},{'timeout_seconds':True}]:
            with self.subTest(kwargs=kwargs),self.assertRaises(ProjectError):self.plan(**kwargs)
        with self.assertRaisesRegex(ProjectError,'Stale'):
            prepare_runtime_read_plan(self.store,self.pid,'0'*64,'127.0.0.1','a'*64)

    def test_tampered_plan_limits_rejected_even_with_recomputed_digest(self):
        p=self.plan(symbols=['MainInstance.BootId'])
        path=Path(p['plan_path']);data=json.loads(path.read_bytes())
        data['limits']['maximum_duration_seconds']=999999
        data.pop('plan_sha256');digest=sha(_canonical(data));data['plan_sha256']=digest
        path.write_bytes(_canonical(data))
        with self.assertRaisesRegex(ProjectError,'limits'):
            load_runtime_read_plan(self.store,self.pid,p['plan_id'],digest)

    def test_transport_final_boundary_denies_arbitrary_path_and_write(self):
        endpoint=ControllerEndpoint('127.0.0.1',41100,'a'*64)
        client=RuntimeReadClient(endpoint,['Arp.Plc.Eclr/HMI.InvalidAcks'])
        with patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
            for method in [lambda:client.read_variables(['Arp.Plc.Eclr/HMI.Password']),
                    lambda:client._runtime_call('Arp.Plc.Gds.Services.IDataAccessService',3,[]),
                    lambda:client._runtime_call('Arp.Plc.Domain.Services.IPlcInfoService',2),
                    lambda:client.write_many([('other',b'bytes')])]:
                with self.assertRaises(ControllerFailure):method()
        self.assertEqual(client.bytes_sent,0)

    def test_local_tls_250_point_cover_and_exact_no_mutation_trace(self):
        r=test_runtime_monitor(self.store,self.pid,self.hash)
        self.assertTrue(r['test_passed'],r)
        self.assertEqual(r['requested_count'],767)
        self.assertEqual(r['quality_coverage']['good'],250)
        self.assertTrue(r['quality_coverage']['complete_expected_point_coverage'])
        self.assertFalse(r['atomic_snapshot'])
        self.assertEqual(r['consistency'],'guarded_window_observation')
        self.assertEqual(r['loaded_identity']['status'],'unknown')
        self.assertTrue(all(not event.get('mutating') for event in r['fixture_trace']))
        self.assertTrue(Path(r['report_path']).is_file())

    def test_bad_quality_missing_type_and_identity_changes(self):
        for fault in ['bad_quality','missing_field','wrong_type','boot_change','config_change',
                'short_results','disconnect','oversized_string']:
            with self.subTest(fault=fault):
                r=test_runtime_monitor(self.store,self.pid,self.hash,fault=fault)
                self.assertTrue(r['test_passed'],r)
                self.assertFalse(r['real_controller_connected'])
                self.assertEqual(len(r['items']),r['requested_count'])
                self.assertTrue(all(not event.get('mutating') for event in r['fixture_trace']))

    def test_rate_limiter_rejects_second_call_before_client_creation(self):
        p=self.plan(symbols=['MainInstance.BootId'])
        class FailureClient:
            def __init__(self,*a,**k):raise AssertionError('client created')
        with patch('plcnext_mcp.runtime_monitor.Path.home',return_value=Path(self.temp.name)):
            with self.assertRaisesRegex(AssertionError,'client created'):
                read_runtime_plan(self.store,self.pid,p['plan_id'],p['plan_sha256'],client_factory=FailureClient)
            with self.assertRaisesRegex(ControllerFailure,'minimum observation interval'):
                read_runtime_plan(self.store,self.pid,p['plan_id'],p['plan_sha256'],client_factory=FailureClient)


if __name__=='__main__':unittest.main()
