"""Deployment prerequisites reject stale, mixed and tampered offline evidence."""
import json
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile

from plcnext_mcp.deployment_plan import deployment_plan, _library_candidates
from plcnext_mcp.expanded_compile import _write_sources
from plcnext_mcp.project import ProjectError, ProjectStore, pou_index, sha

ROOT = Path(__file__).resolve().parents[1]


class DeploymentPlanTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore(self.root / 'workspace')
        self.project = self.store.import_copy(str(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'))
        self.pid = self.project['project_id']
        self.hash = self.project['project_sha256']
        self.job_id = 'a' * 32
        self.job = self.store.root / self.pid / 'builds' / self.job_id
        self.job.mkdir(parents=True)
        _, _, members, _, _ = self.store._current(self.pid)
        inputs = _write_sources(self.job, members, pou_index(members))
        for name, payload in members.items():
            if name.endswith('/'):
                continue
            relative = 'project/' + name
            destination = self.job / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(payload)
            inputs[relative] = sha(payload)
        resource = 'RES_' + 'B' * 32
        image = resource + '.img'
        (self.job / 'generated').mkdir()
        self.image = self.job / 'generated' / image
        # Synthetic receipt exercises verification only; it is never a real build claim.
        self.image.write_bytes(b'RLCE: test fixture, not executable')
        self.report = {'project_id': self.pid, 'project_sha256': self.hash,
            'job_id': self.job_id, 'compiled': True, 'build_mode': 'cold',
            'resource_name': resource, 'capability': {'device': 'AXC F 2152'},
            'input_hashes': inputs, 'generated_files': [{'name': image, 'sha256': sha(self.image.read_bytes())}],
            'image_sha256': sha(self.image.read_bytes())}
        self.save()

    def save(self):
        (self.job / 'result.json').write_text(json.dumps(self.report), encoding='utf-8')

    def plan(self):
        return deployment_plan(self.store, self.pid, self.hash, self.job_id)

    def test_valid_iec_receipt_stays_blocked_without_complete_package(self):
        result = self.plan()
        self.assertEqual(result['pou_count'], 31)
        self.assertEqual(len(result['missing_pcwe_files']), 7)
        self.assertTrue(result['source_and_generated_hashes_verified'])
        self.assertFalse(result['deployable'])
        self.assertEqual(result['network_operations_performed'], 0)
        self.assertIn('controller_transport_not_implemented', [i['code'] for i in result['blocking_issues']])

    def test_revision_and_job_are_bound(self):
        with self.assertRaisesRegex(ProjectError, 'Stale'):
            deployment_plan(self.store, self.pid, '0' * 64, self.job_id)
        self.report['job_id'] = 'b' * 32
        self.save()
        with self.assertRaisesRegex(ProjectError, 'exact project'):
            self.plan()

    def test_failed_or_cached_receipt_is_rejected(self):
        self.report['compiled'] = False
        self.save()
        with self.assertRaisesRegex(ProjectError, 'successful cold build'):
            self.plan()
        self.report['compiled'] = True
        self.report['build_mode'] = 'cached'
        self.save()
        with self.assertRaisesRegex(ProjectError, 'successful cold build'):
            self.plan()

    def test_output_and_input_tampering_are_rejected(self):
        before = self.image.read_bytes()
        self.image.write_bytes(before + b'changed')
        with self.assertRaisesRegex(ProjectError, 'changed or is missing'):
            self.plan()
        self.image.write_bytes(before)
        path = self.job / 'sources/Main/Code.st'
        path.write_bytes(path.read_bytes() + b'changed')
        with self.assertRaisesRegex(ProjectError, 'changed or is missing'):
            self.plan()

    def test_compiler_input_cannot_differ_even_if_its_receipt_is_updated(self):
        relative = 'sources/Main/Code.st'
        path = self.job / relative
        path.write_bytes(path.read_bytes() + b'(* changed copy *)')
        self.report['input_hashes'][relative] = sha(path.read_bytes())
        tree = ET.parse(self.job / 'sources.xml')
        node = next(n for n in tree.getroot() if n.get('name') == 'Main')
        node.set('code_sha256', sha(path.read_bytes()))
        tree.write(self.job / 'sources.xml', encoding='utf-8')
        self.report['input_hashes']['sources.xml'] = sha((self.job / 'sources.xml').read_bytes())
        self.save()
        with self.assertRaisesRegex(ProjectError, 'Compiler POU source differs'):
            self.plan()

    def test_missing_source_node_is_rejected(self):
        tree = ET.parse(self.job / 'sources.xml')
        tree.getroot().remove(tree.getroot()[0])
        tree.write(self.job / 'sources.xml', encoding='utf-8')
        self.report['input_hashes']['sources.xml'] = sha((self.job / 'sources.xml').read_bytes())
        self.save()
        with self.assertRaisesRegex(ProjectError, 'manifest does not match'):
            self.plan()

    def test_duplicate_outputs_and_path_escape_are_rejected(self):
        self.report['generated_files'].append(dict(self.report['generated_files'][0]))
        self.save()
        with self.assertRaisesRegex(ProjectError, 'Ambiguous'):
            self.plan()
        self.report['generated_files'].pop()
        self.report['input_hashes']['../outside'] = '0' * 64
        self.save()
        with self.assertRaisesRegex(ProjectError, 'Unsafe path'):
            self.plan()

    def test_native_library_profiles_are_nested_and_uri_encoded(self):
        library = self.job / 'libraries/test.pxclx'
        library.parent.mkdir()
        project = ET.Element('Project', xmlns='http://schemas.microsoft.com/developer/msbuild/2003')
        entries = []
        for device, version in [('AXCF2152', '2025.0.3'), ('AXCF2152', '2026.0.2'), ('AXCF1152', '2026.0.2')]:
            relative = f'Logical Elements/bin/{device}_{version}'
            folder = ET.SubElement(project, 'Folder', Include=relative)
            profile = ET.SubElement(ET.SubElement(folder, 'DeviceProfiles'), 'DeviceProfile')
            ET.SubElement(profile, 'DeviceProfileType').text = device
            ET.SubElement(profile, 'DeviceProfileVersion').text = version
            entries.append(('PROJECT/' + relative.replace(' ', '%20') + '/libTest.so', device.encode()))
        with zipfile.ZipFile(library, 'w') as archive:
            archive.writestr('PROJECT/PROJECT.proj', ET.tostring(project))
            for name, content in entries:
                archive.writestr(name, content)
        candidates = _library_candidates(library, 'AXCF2152')
        self.assertEqual(len(candidates), 2)
        self.assertEqual({v['device_profile_version'] for v in candidates}, {'2025.0.3', '2026.0.2'})
        self.assertTrue(all(v['selected_for_deployment'] is False for v in candidates))
        self.report['input_hashes']['libraries/test.pxclx'] = sha(library.read_bytes())
        self.save()
        self.assertEqual(len(self.plan()['native_libraries'][0]['native_candidates']), 2)


if __name__ == '__main__':
    unittest.main()
