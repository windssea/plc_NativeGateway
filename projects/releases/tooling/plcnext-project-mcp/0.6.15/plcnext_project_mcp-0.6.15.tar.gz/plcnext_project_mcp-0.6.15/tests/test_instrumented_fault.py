"""Explicit instrumented copy, original byte oracle, own TLS/scans; no PLC."""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import io
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

from plcnext_mcp import fault_profile as profile
from plcnext_mcp import instrumented_fault as fault
from plcnext_mcp.controller_transport import ControllerEndpoint,ControllerFailure
from plcnext_mcp.fault_profile_test_peer import LocalFaultProfilePeer,FaultScanModel
from plcnext_mcp.project import ProjectStore,ProjectError,sha
from plcnext_mcp.rsc_fault_write_codec import encode_fault_write,receive_fault_write,receive_write_error

ORIGINAL=Path(__file__).resolve().parents[1]/'artifacts/runtime-monitor-research/NativeGateway.restore-native-0.5.0.frozen.pcwex'


class FaultWriteOracleTests(unittest.TestCase):
    def test_original_single_write_vectors_and_truncations(self):
        p=Path(__file__).resolve().parents[1]/'artifacts/fault-write-research/oracle-02/report.json'
        oracle=json.loads(p.read_text(encoding='utf-8-sig'))
        values={'RequestBootId':('utf8','PUBLIC-boot'),'RequestKind':('uint16',2),'RequestTtlMs':('uint32',300000),
            'RequestDeadlineMs':('uint64',1234567890123),'RequestId':('uint32',17),'CommitId':('uint32',17),'CancelId':('uint32',17)}
        for row in oracle['vectors']:
            if row['name'].startswith('write-two'):continue
            field,suffix=row['name'].rsplit('-',1);raw=bytes.fromhex(row['hex'])
            if suffix=='request':
                kind,value=values[field];path='Arp.Plc.Eclr/MainInstance.McpFault.'+field
                self.assertEqual(encode_fault_write(41,5,path,kind,value),raw)
                self.assertEqual(receive_fault_write(io.BytesIO(raw[16:]).read),(path,{'wire_type':kind,
                    'wire_tag':{'utf8':19,'uint16':7,'uint32':9,'uint64':11}[kind],'value':value}))
                for n in range(len(raw)-16):
                    with self.assertRaises(ValueError):receive_fault_write(io.BytesIO(raw[16:16+n]).read)
            else:self.assertEqual(receive_write_error(io.BytesIO(raw[16:]).read),0)
        self.assertEqual(len(oracle['vectors']),16)
        self.assertEqual(oracle['network_operations'],0)


class FaultScanInvariantTests(unittest.TestCase):
    def arm(self,model,now=1000,ttl=200):
        model.values.update(RequestId=1,CommitId=1,RequestBootId='PUBLIC-boot-1',RequestKind=2,
            RequestTtlMs=ttl,RequestDeadlineMs=now+ttl)
        model.scan(now);self.assertFalse(model.values['Active'])
        model.scan(now+20);self.assertTrue(model.values['Active'])

    def test_two_scans_ttl_and_replay(self):
        model=FaultScanModel('a'*32);self.arm(model)
        model.scan(1200);self.assertFalse(model.values['Active']);self.assertEqual(model.values['ReleasedId'],1)
        model.scan(1220);self.assertFalse(model.values['Active'])

    def test_boot_ready_clock_rollback_cancel_disarm(self):
        for condition,reason in [('boot',3),('ready',4),('clock',5),('cancel',2)]:
            model=FaultScanModel('a'*32);self.arm(model)
            now=1040
            if condition=='boot':model.values['CurrentBoot']='PUBLIC-boot-2'
            if condition=='ready':model.values['Ready']=False
            if condition=='clock':now=500
            if condition=='cancel':model.values['CancelId']=1
            model.scan(now);self.assertFalse(model.values['Active']);self.assertEqual(model.values['ReleaseReason'],reason)

    def test_stopped_then_late_start_cannot_activate_expired_commit(self):
        model=FaultScanModel('a'*32)
        model.values.update(RequestId=1,CommitId=1,RequestBootId='PUBLIC-boot-1',RequestKind=1,
            RequestTtlMs=200,RequestDeadlineMs=1200)
        # No scans while stopped; late first/second scans must reject old absolute expiry.
        model.scan(8000);model.scan(8020)
        self.assertFalse(model.values['Active']);self.assertEqual(model.values['ReleaseReason'],6)


@unittest.skipUnless(ORIGINAL.is_file(),'Original authorized restore archive not available on this host')
class InstrumentedFaultTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.store=ProjectStore(self.root/'workspace')
        self.created=profile.create_fault_profile(self.store,str(ORIGINAL));self.pid=self.created['project_id']
        self.source=self.created['project_sha256'];self.profile=self.created['profile']
        self.binding={'source':{'project_sha256':self.source,'project_name':'PUBLIC instrumented copy'},
            'package':{'package_job_id':'c'*32,'inventory_sha256':'e'*64},'files':[]}
        self.patch=mock.patch.object(fault,'_binding',return_value=(self.store._folder(self.pid),{},self.binding,{}));self.patch.start();self.addCleanup(self.patch.stop)

    def review(self,peer=None,kind='business_ack_blocked',ttl=200):
        return fault.prepare_instrumented_fault_review(self.store,self.pid,self.source,self.created['profile_sha256'],
            'c'*32,peer.address if peer else '192.0.2.8',peer.certificate_sha256 if peer else 'f'*64,
            'PUBLIC-boot-1',kind,ttl,port=peer.port if peer else 41100)

    def run_peer(self,selected='none',kind='business_ack_blocked',cancel=None):
        with LocalFaultProfilePeer(self.root/('peer-'+selected),self.profile,fault=selected) as peer:
            review=self.review(peer,kind)
            scope=fault.FaultWriteScope(review,authority=fault._FAULT_AUTHORITY,fixture=True)
            result=fault.execute_instrumented_fault(fault.InstrumentedFaultClient(scope),review,cancel_event=cancel,poll_interval=0.02)
            observed={'writes':list(peer.field_writes),'values':dict(peer.model.values),'errors':list(peer.errors)}
        self.assertEqual(observed['errors'],[])
        return result,observed

    def test_source_generation_preserves_original_and_only_narrow_gates(self):
        self.assertEqual(sha(ORIGINAL.read_bytes()),profile.ORIGINAL_SHA256)
        self.assertEqual(len(self.store.inspect(self.pid)['pous']),33)
        code=self.store.read_pou(self.pid,'Main')['code']
        self.assertEqual(code.count('AND NOT McpFault.BlockConnection'),1)
        self.assertEqual(code.count('IF NOT McpFault.BlockBusinessAck THEN'),1)
        self.assertIn('McpFault(NowMs:=GET_MICROSECONDS(TRUE)/ULINT#1000,',code)
        self.assertIn('RxAccept := TRUE; RxStage := 0;',code)
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        profile.load_fault_profile(self.store,self.pid,self.source,self.created['profile_sha256'])

    def test_profile_stale_source_and_wrong_archive_refused(self):
        with self.assertRaises(ProjectError):profile.create_fault_profile(self.store,str(ORIGINAL),'0'*64)
        main=self.store.read_pou(self.pid,'Main')
        self.store.patch_st(self.pid,'Main',self.source,main['code_sha256'],'Clock(IN := NOT Clock.Q, PT := T#20d);','Clock(IN := NOT Clock.Q, PT := T#20d); (* test *)')
        with self.assertRaises(ProjectError):profile.load_fault_profile(self.store,self.pid,self.source,self.created['profile_sha256'])

    def test_real_codec_loopback_stages_then_commits_and_ttl_releases(self):
        result,peer=self.run_peer()
        self.assertEqual(result['status'],'fault_released_verified')
        self.assertTrue(result['release_verified'])
        self.assertEqual(peer['writes'],['RequestBootId','RequestKind','RequestTtlMs','RequestDeadlineMs','RequestId','CommitId'])
        self.assertFalse(peer['values']['BlockBusinessAck'])
        self.assertFalse(peer['values']['BlockConnection'])
        self.assertFalse(result['outcome_unknown'])

    def test_connection_fault_is_only_agent_gate_and_releases(self):
        result,peer=self.run_peer(kind='agent_connection_offline')
        self.assertEqual(result['status'],'fault_released_verified')
        self.assertTrue(result['agent_disconnect_observed'])
        self.assertTrue(result['agent_connection_restored_observed'])
        self.assertFalse(result['real_DATA_STORED_and_Hub_receipts_verified'])

    def test_cancel_before_commit_writes_no_activation(self):
        event=threading.Event();event.set()
        result,peer=self.run_peer(cancel=event)
        self.assertEqual(result['failure_code'],'fault_cancelled_before_commit')
        self.assertEqual(peer['writes'],[])
        self.assertFalse(result['commit_request_attempted'])

    def test_wrong_profile_boot_or_stopped_plc_writes_nothing(self):
        for selected in ('wrong_profile','wrong_boot','plc_stopped','clock_frozen'):
            result,peer=self.run_peer(selected)
            self.assertEqual(result['status'],'fault_failed')
            self.assertEqual(peer['writes'],[])

    def test_staging_mismatch_never_commits(self):
        result,peer=self.run_peer('stage_mismatch')
        self.assertEqual(result['failure_code'],'fault_staging_mismatch')
        self.assertNotIn('CommitId',peer['writes']);self.assertFalse(result['outcome_unknown'])

    def test_commit_reply_loss_is_unknown_but_plc_scans_still_expire(self):
        with LocalFaultProfilePeer(self.root/'lost-peer',self.profile,fault='commit_reply_lost') as peer:
            review=self.review(peer);scope=fault.FaultWriteScope(review,authority=fault._FAULT_AUTHORITY,fixture=True)
            result=fault.execute_instrumented_fault(fault.InstrumentedFaultClient(scope),review,poll_interval=0.02)
            self.assertTrue(result['outcome_unknown']);self.assertEqual(peer.field_writes.count('CommitId'),1)
            time.sleep(0.3)
            self.assertFalse(peer.model.values['Active'])
            self.assertEqual(peer.model.values['ReleasedId'],1)

    def test_cancel_exact_active_request_and_release_readback(self):
        event=threading.Event()
        with LocalFaultProfilePeer(self.root/'cancel-peer',self.profile) as peer:
            review=self.review(peer,ttl=500)
            scope=fault.FaultWriteScope(review,authority=fault._FAULT_AUTHORITY,fixture=True)
            def sink(item):
                if item.get('field')=='CommitId' and item.get('response_received'):event.set()
            result=fault.execute_instrumented_fault(fault.InstrumentedFaultClient(scope,event_sink=sink),review,cancel_event=event,poll_interval=0.02)
            self.assertTrue(result['release_verified']);self.assertEqual(result['release_reason'],2)
            self.assertEqual(peer.field_writes[-1],'CancelId')

    def test_fault_client_process_dies_after_commit_plc_scans_expire(self):
        with LocalFaultProfilePeer(self.root/'exiting-client-peer',self.profile) as peer:
            review=self.review(peer,ttl=300)
            code="""import json,os,sys
from plcnext_mcp.instrumented_fault import FaultWriteScope,InstrumentedFaultClient,execute_instrumented_fault,_FAULT_AUTHORITY
r=json.loads(sys.stdin.readline())
def sink(e):
    if e.get('field')=='CommitId' and e.get('response_received'):os._exit(23)
s=FaultWriteScope(r,authority=_FAULT_AUTHORITY,fixture=True)
execute_instrumented_fault(InstrumentedFaultClient(s,event_sink=sink),r,poll_interval=0.02)
"""
            child=subprocess.run([sys.executable,'-I','-c',code],input=json.dumps(review)+'\n',
                text=True,encoding='utf-8',capture_output=True,timeout=5)
            self.assertEqual(child.returncode,23)
            time.sleep(0.4)
            self.assertFalse(peer.model.values['Active'])
            self.assertEqual(peer.model.values['ReleasedId'],1)
            self.assertEqual(peer.field_writes.count('CommitId'),1)

    def test_scope_denies_unstaged_commit_arbitrary_field_and_repeat(self):
        review=self.review()
        with self.assertRaises(ProjectError):fault.FaultWriteScope(review)
        scope=fault.FaultWriteScope(review,authority=fault._FAULT_AUTHORITY);scope.capture_request(0,100)
        client=fault.InstrumentedFaultClient(scope)
        for name in ('CommitId','SomeOtherVariable','CancelId'):
            with self.assertRaises(ControllerFailure):client._write_fixed(name)

    def test_missing_operator_receipt_is_zero_socket(self):
        review=self.review()
        with mock.patch('plcnext_mcp.controller_transfer._endpoint_lease_root',return_value=self.root/'leases'),mock.patch.object(socket,'socket',side_effect=AssertionError('No approval no socket')) as opened,mock.patch.object(socket,'create_connection',side_effect=AssertionError('No real PLC')) as connected:
            with self.assertRaises(ControllerFailure) as failure:fault.execute_reviewed_instrumented_fault(self.store,self.pid,review['review_id'],review['review_sha256'])
            self.assertEqual(failure.exception.code,'user_confirmation_required')
            opened.assert_not_called();connected.assert_not_called()

    def test_exact_fault_receipt_expiry_binding_and_single_claim(self):
        review=self.review();contract=fault.approval_contract(self.store,self.pid,review['review_id'],review['review_sha256'])
        directory=self.store.root/contract.approval_directory;directory.mkdir()
        path=directory/(review['review_sha256']+'.json')
        now=datetime.now(timezone.utc)
        receipt={'schema':fault.RECEIPT_SCHEMA,'review_sha256':review['review_sha256'],
            'confirmed_by':'human_user',**contract.binding_fields,'confirmation_reference':'PUBLIC RFC5737 fixture; not real approval',
            'confirmed_utc':(now-timedelta(seconds=1)).isoformat(),'expires_utc':(now+timedelta(seconds=60)).isoformat()}
        with mock.patch.object(socket,'socket',side_effect=AssertionError('No device in approval guard')) as opened:
            bad=deepcopy(receipt);bad['policy']['expected_boot_id']='PUBLIC-wrong-boot';path.write_text(json.dumps(bad))
            with self.assertRaises(ProjectError):fault._consume(self.store,review,'d'*32)
            bad=deepcopy(receipt);bad['expires_utc']='2020-01-01T00:00:00+00:00';path.write_text(json.dumps(bad))
            with self.assertRaises(ProjectError):fault._consume(self.store,review,'d'*32)
            path.write_text(json.dumps(receipt));fault._consume(self.store,review,'d'*32)
            with self.assertRaises(ControllerFailure) as result:fault._consume(self.store,review,'e'*32)
            self.assertEqual(result.exception.code,'approval_already_consumed')
            opened.assert_not_called()


if __name__=='__main__':unittest.main()
