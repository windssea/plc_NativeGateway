"""M06 same-peer recovery; PUBLIC inert fixtures only, never real authorization."""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import hashlib
import itertools
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

from plcnext_mcp import controller_recovery as recovery
from plcnext_mcp import controller_download_plan as download
from plcnext_mcp.controller_transport import ControllerFailure
from plcnext_mcp.project import ProjectError,ProjectStore,sha
from plcnext_mcp.runtime_monitor import SourceSymbols,nativegateway_runtime_preset
from plcnext_mcp.recovery_test_peer import LocalRecoveryPeer

ROOT=Path(__file__).resolve().parents[1]
FROZEN=ROOT/'artifacts/runtime-monitor-research/NativeGateway.restore-native-0.5.0.frozen.pcwex'
PACKAGE='c'*32


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='recovery-public-');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.store=ProjectStore(self.root/'managed')
        self.source=self.store.import_copy(str(FROZEN));self.pid=self.source['project_id'];self.sha=self.source['project_sha256']
        self.files={'Plc/Eclr/eCLR.img':b'PUBLIC inert image never executed',
            'Plc/Domain/pcwe.plc.config':b'<PlcDomainConfigurationDocument><Project name="PUBLIC-original" /></PlcDomainConfigurationDocument>',
            'PCWE.software-package-manifest.json':json.dumps({'identification':{'name':'PUBLIC-original',
                'softwareRevision':'PUBLIC-1','releaseDate':'2026-10-26T00:00:00Z',
                'targetProductCodes':['2404267'],'targetFirmwareRevision':'26.0.0'}}).encode(),
            'dlc.bin':b''}
        self.files.update({f'PUBLIC/padding-{i:02d}.dat':b'PUBLIC inert fixture '+str(i).encode() for i in range(44)})
        manifest=ET.Element('ProjectManifestDocument',{'schemaVersion':'1.0'});group=ET.SubElement(manifest,'Files')
        for name,data in self.files.items():ET.SubElement(group,'File',{'path':name,'hash':hashlib.sha512(data).hexdigest()})
        self.files['PCWE.manifest.config']=ET.tostring(manifest)
        self.assertEqual(len(self.files),49)
        self.snapshot_patch=patch.object(download,'_package_snapshot',side_effect=self.snapshot)
        self.snapshot_patch.start();self.addCleanup(self.snapshot_patch.stop)
        self.home_patch=patch('pathlib.Path.home',return_value=self.root/'PUBLIC-home')
        self.home_patch.start();self.addCleanup(self.home_patch.stop)
        # Accelerate only the observation scheduler. M04 separately tests its
        # real interval gate; all recovery TLS sessions and payloads remain real.
        self.wait_patch=patch.object(recovery,'_wait_monitor_interval',return_value=None)
        self.wait_patch.start();self.addCleanup(self.wait_patch.stop)
        ticks=itertools.count(10000000000,10)
        self.time_patch=patch('plcnext_mcp.runtime_monitor.time.time',side_effect=lambda:next(ticks))
        self.time_patch.start();self.addCleanup(self.time_patch.stop)

    def snapshot(self,store,pid,expected,package):
        folder,manifest,_,_,_=store._current(pid)
        if expected!=manifest['current_sha256'] or package!=PACKAGE:raise ProjectError('PUBLIC fixture stale package.')
        receipt={'build_job_id':'b'*32,'build_receipt_sha256':'d'*64,'pou_count':32}
        inventory={'inventory_sha256':sha(b'PUBLIC inert file inventory')}
        bindings={'variable_count':77,'fb_instance_count':70,'hmi_mapping_count':10}
        return folder,manifest,folder/'deployments'/package,b'PUBLIC fixture package receipt',receipt,inventory,bindings,deepcopy(self.files)

    def prepare(self,address='127.0.0.1',pin='a'*64,port=41100,**kwargs):
        return recovery.prepare_recovery_plan(self.store,self.pid,self.sha,PACKAGE,address,pin,port=port,
            volatile_data_policy=kwargs.pop('volatile_data_policy','record_unknown_loss'),**kwargs)

    def receipt(self,plan,**updates):
        contract=recovery.approval_contract(self.store,self.pid,plan['plan_id'],plan['review_sha256'])
        now=datetime.now(timezone.utc)
        record={'schema':contract.receipt_schema,'review_sha256':contract.review_sha256,'confirmed_by':'human_user',
            **contract.binding_fields,'confirmation_reference':'PUBLIC fixture only',
            'confirmed_utc':now.isoformat(),'expires_utc':(now+timedelta(minutes=5)).isoformat()}
        record.update(updates)
        directory=self.store.root/contract.approval_directory;directory.mkdir(exist_ok=True)
        path=directory/(contract.review_sha256+'.json');path.write_text(json.dumps(record),encoding='utf-8')
        return path

    def values(self):
        from plcnext_mcp.project import read_archive
        model=SourceSymbols(read_archive(Path(self.source['project_path']))[1]);values={}
        for symbol in nativegateway_runtime_preset(model,point_count=250,include_configuration=True):
            try:d=model.resolve(symbol)
            except ProjectError:continue
            t=d['wire_type']
            value=('GOOD' if symbol.endswith('.Quality') else 'PUBLIC-boot') if t=='utf8' else True if t=='bool' else 230.1 if t.startswith('float') else 13 if symbol.endswith('.Active.Version') else 50 if symbol.endswith('.Active.DeviceCount') else 250 if symbol.endswith('.Active.PointCount') else 1
            values[d['path']]={'wire_type':t,'value':value}
        return values

    def run_peer(self,fault='none',hook=None,cancel=None):
        directory=self.root/('peer-'+str(len(list(self.root.glob('peer-*')))))
        with LocalRecoveryPeer(directory,self.files,self.values(),fault=fault) as peer:
            plan=self.prepare(peer.address,peer.certificate_sha256,peer.port)
            recovery._issue_public_loopback_receipt(self.store,plan,peer)
            key=sha((peer.address+':'+str(peer.port)).encode())
            lease=self.root/'PUBLIC-home/.plcnext-mcp/controller-endpoint-leases'/(key+'.json')
            held=[];peer.on_session=lambda _:held.append(lease.is_file())
            if hook is not None:hook(peer,plan,lease)
            result=recovery.execute_recovery_plan(self.store,self.pid,plan['plan_id'],plan['review_sha256'],cancel_event=cancel)
            state={'connections':peer.connections,'stop':peer.stop_calls,'start':peer.start_calls,
                'write':peer.write_calls,'load':peer.load_calls,'reset':peer.reset_calls,
                'files_match':peer.snapshot()==self.files,'held':held,'errors':list(peer.errors),
                'trace':list(peer.trace),'lease_exists':lease.exists(),'plan':plan}
        return result,state

    def test_full_same_peer_49_file_chain_and_causal_start(self):
        result,peer=self.run_peer()
        self.assertEqual(result['status'],'original_loaded_runtime_observed',result)
        self.assertTrue(result['original_package_loaded'])
        self.assertTrue(result['original_program_restored'])
        self.assertFalse(result['original_project_restored'])
        self.assertFalse(result['joint_acceptance_complete'])
        self.assertEqual(peer['connections'],7)
        self.assertEqual((peer['stop'],peer['reset'],peer['load'],peer['start']),(1,1,1,1))
        self.assertTrue(peer['files_match'])
        self.assertTrue(all(peer['held']))
        self.assertFalse(peer['lease_exists'])
        self.assertEqual(peer['errors'],[])
        start=result['steps'][-1]
        self.assertEqual(start['loaded_identity_evidence']['source'],'same_plan_verified_load')
        self.assertFalse(start['loaded_identity_evidence']['device_loaded_module_hash_read'])
        self.assertEqual(result['runtime_verification']['quality_coverage']['good'],250)
        operations=[x['operation'] for x in peer['trace']]
        self.assertLess(operations.index('Stop'),operations.index('FileWritten'))
        self.assertLess(operations.index('Load'),operations.index('Start'))
        self.assertTrue(Path(result['report_path']).is_file())

    def test_identical_package_readback_load_can_start_without_writes(self):
        def seed(peer,plan,lease):
            for name,data in self.files.items():
                peer.root.joinpath(*name.split('/')).write_bytes(data)
        result,peer=self.run_peer(hook=seed)
        self.assertEqual(result['status'],'original_loaded_runtime_observed',result)
        self.assertEqual(peer['write'],0)
        self.assertEqual(peer['start'],1)
        self.assertEqual(result['steps'][1]['files_verified'],49)
        self.assertTrue(result['steps'][-1]['loaded_identity_evidence']['journal_binding_verified'])

    def test_lost_replies_keep_quarantine_and_never_repeat(self):
        for fault in ['stop_reply_lost','write_reply_lost','reset_reply_lost','load_reply_lost','start_reply_lost']:
            with self.subTest(fault=fault):
                result,peer=self.run_peer(fault)
                self.assertEqual(result['status'],'recovery_failed',result)
                self.assertTrue(result['controller_changed'])
                self.assertTrue(result['outcome_unknown'])
                self.assertTrue(result['endpoint_lease_retained'])
                self.assertTrue(peer['lease_exists'])
                self.assertLessEqual(peer['start'],1);self.assertEqual(peer['stop'],1)
                self.assertFalse(result['automatic_retry'])
                self.assertFalse(result['original_project_restored'])

    def test_readback_and_project_name_prevent_start(self):
        for fault in ['readback_corrupt','wrong_project_name']:
            with self.subTest(fault=fault):
                result,peer=self.run_peer(fault)
                self.assertEqual(result['status'],'recovery_failed',result)
                self.assertGreater(peer['write'],0)
                self.assertEqual(peer['start'],0)
                self.assertTrue(result['endpoint_lease_retained'])
        self.assertTrue(result['original_package_loaded'])

    def test_before_observation_failure_and_wrong_state_never_stop(self):
        for fault in ['baseline_disconnect','initial_wrong']:
            with self.subTest(fault=fault):
                result,peer=self.run_peer(fault)
                self.assertEqual(result['status'],'recovery_failed')
                self.assertEqual((peer['stop'],peer['write'],peer['start']),(0,0,0))
                self.assertFalse(result['controller_changed'])
                self.assertFalse(peer['lease_exists'])

    def test_configuration_mismatch_and_read_disconnect_do_not_claim_restored(self):
        for fault in ['configuration_mismatch','runtime_disconnect']:
            with self.subTest(fault=fault):
                result,peer=self.run_peer(fault)
                self.assertTrue(result['original_package_loaded'])
                self.assertEqual(peer['start'],1)
                self.assertFalse(result['original_program_restored'])
                self.assertFalse(result['original_project_restored'])
                self.assertTrue(result['endpoint_lease_retained'])
        self.assertEqual(result['status'],'recovery_failed')

    def test_zero_socket_unconfirmed_expired_wrong_and_consumed_receipts(self):
        for mode in ['missing','expired','wrong_actions','revoked','denied','claimed']:
            with self.subTest(mode=mode):
                plan=self.prepare()
                if mode!='missing':
                    path=self.receipt(plan)
                    if mode=='expired':
                        old=datetime.now(timezone.utc)-timedelta(hours=2)
                        self.receipt(plan,confirmed_utc=old.isoformat(),expires_utc=(old+timedelta(minutes=5)).isoformat())
                    elif mode=='wrong_actions':self.receipt(plan,approved_actions=['start'])
                    elif mode in ('revoked','denied','claimed'):path.with_suffix('.'+mode+'.json').write_text('{}')
                with patch('socket.create_connection',side_effect=AssertionError('ZERO socket')):
                    result=recovery.execute_recovery_plan(self.store,self.pid,plan['plan_id'],plan['review_sha256'])
                self.assertEqual(result['status'],'recovery_failed')
                self.assertFalse(result['controller_changed'])
                self.assertEqual(result['steps'],[])
                self.assertTrue(Path(result['report_path']).is_file())

    def test_wrong_monitor_target_and_child_roles_are_rejected(self):
        plan=self.prepare();parent_path=Path(plan['plan_path'])
        monitor_ref=plan['children']['monitor'];monitor_path=self.store._folder(self.pid)/'runtime-read-plans'/monitor_ref['plan_id']/'plan.json'
        monitor=json.loads(monitor_path.read_bytes());monitor['target']['port']=41101
        monitor.pop('plan_sha256');monitor['plan_sha256']=sha(json.dumps(monitor,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())
        monitor_path.write_text(json.dumps(monitor));parent=json.loads(parent_path.read_bytes())
        parent['children']['monitor']['plan_sha256']=monitor['plan_sha256'];parent['review_sha256']=download._digest(parent)
        parent_path.write_text(json.dumps(parent))
        with self.assertRaisesRegex(ProjectError,'monitor source binding'):
            recovery.load_recovery_plan(self.store,self.pid,parent['plan_id'],parent['review_sha256'])

    def test_load_receipt_and_terminal_result_io_failures_preserve_effects(self):
        original=recovery._save_new
        def fail_load(path,value):
            if path.name=='load-result.json':raise OSError('PUBLIC disk failure')
            return original(path,value)
        with patch.object(recovery,'_save_new',side_effect=fail_load):
            result,peer=self.run_peer()
        self.assertTrue(result['original_package_loaded']);self.assertTrue(result['controller_changed'])
        self.assertEqual(peer['start'],0);self.assertTrue(result['endpoint_lease_retained'])
        with patch.object(recovery,'_persist_result',side_effect=OSError('PUBLIC terminal persistence failure')):
            result,peer=self.run_peer()
        self.assertTrue(result['original_program_restored']);self.assertTrue(result['controller_changed'])
        self.assertFalse(result['receipt_persisted']);self.assertTrue(result['endpoint_lease_retained'])

    def test_cancellation_and_lease_tamper_after_stop_never_transfer(self):
        event=threading.Event()
        result,peer=self.run_peer(hook=lambda peer,plan,lease:setattr(peer,'on_stop',lambda _:event.set()),cancel=event)
        self.assertTrue(result['cancelled']);self.assertTrue(result['outcome_unknown'])
        self.assertEqual(peer['write'],0);self.assertTrue(result['endpoint_lease_retained'])
        def tamper(peer,plan,lease):peer.on_stop=lambda _:lease.write_text('PUBLIC changed lease')
        result,peer=self.run_peer(hook=tamper)
        self.assertEqual(result['status'],'recovery_failed');self.assertTrue(result['controller_changed'])
        self.assertTrue(result['endpoint_lease_retained']);self.assertEqual(peer['write'],0)

    def test_duplicate_concurrent_plan_is_denied_by_same_endpoint_lease(self):
        duplicate=[]
        def hook(peer,plan,lease):
            def attempt(_):
                try:recovery.execute_recovery_plan(self.store,self.pid,plan['plan_id'],plan['review_sha256'])
                except ProjectError as exc:duplicate.append(str(exc))
            peer.on_stop=attempt
        result,peer=self.run_peer(hook=hook)
        self.assertEqual(result['status'],'original_loaded_runtime_observed',result)
        self.assertEqual(len(duplicate),1)
        self.assertIn('endpoint_transition_busy',duplicate[0])
        self.assertEqual(peer['connections'],7)


    def test_startup_invalidated_read_retries_only_reads_within_budget(self):
        from plcnext_mcp import runtime_monitor
        original=runtime_monitor.read_runtime_plan;calls=0
        frozen=json.loads((ROOT/'docs/evidence/lease-observation-20261027/failed-read-window.json').read_text(encoding='utf-8'))
        frozen=frozen.get('result',frozen)
        def read(*args,**kwargs):
            nonlocal calls
            calls+=1
            if calls==2:return deepcopy(frozen)
            return original(*args,**kwargs)
        with patch.object(runtime_monitor,'read_runtime_plan',side_effect=read):result,peer=self.run_peer()
        self.assertEqual(result['status'],'original_loaded_runtime_observed',result)
        self.assertEqual((peer['stop'],peer['load'],peer['start']),(1,1,1))
        self.assertEqual(result['runtime_observations'][0]['status'],'snapshot_invalidated')

    def test_startup_invalidated_read_exhausts_original_budget(self):
        from plcnext_mcp import runtime_monitor
        original=runtime_monitor.read_runtime_plan;calls=0
        frozen=json.loads((ROOT/'docs/evidence/lease-observation-20261027/failed-read-window.json').read_text(encoding='utf-8'))
        frozen=frozen.get('result',frozen)
        def read(*args,**kwargs):
            nonlocal calls
            calls+=1
            return original(*args,**kwargs) if calls==1 else deepcopy(frozen)
        with patch.object(runtime_monitor,'read_runtime_plan',side_effect=read):result,peer=self.run_peer()
        self.assertEqual(result['failure_code'],'recovery_observation_failed',result)
        self.assertEqual(calls,4);self.assertEqual((peer['stop'],peer['load'],peer['start']),(1,1,1))

if __name__=='__main__':unittest.main()


class RecoveryWindowTests(unittest.TestCase):
    def test_review_bound_window_limits_and_defaults(self):
        config={'version':13,'device_count':50,'point_count':250,'enabled':True}
        args=('a'*32,'record_unknown_loss','cold',3,config)
        default=recovery._policy(*args)
        longer=recovery._policy(*args,12,5)
        self.assertEqual(default['maximum_runtime_observations'],3)
        self.assertEqual(longer['maximum_runtime_observations'],12)
        self.assertEqual(longer['operation_timeout_seconds'],300)
        for count,interval in [(0,5),(25,5),(12,4),(12,11),(True,5)]:
            with self.assertRaises(ProjectError):recovery._policy(*args,count,interval)
