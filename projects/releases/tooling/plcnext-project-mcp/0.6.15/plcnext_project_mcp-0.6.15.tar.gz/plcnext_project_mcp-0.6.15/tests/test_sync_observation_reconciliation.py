"""S01 real loopback recovery followed by read-only synchronous reconciliation."""
import unittest,json
from pathlib import Path
from unittest.mock import patch
import test_controller_recovery as fixture
from plcnext_mcp import controller_recovery as recovery,runtime_monitor,lease_reconciliation as leases
from plcnext_mcp.recovery_test_peer import LocalRecoveryPeer
from plcnext_mcp.project import sha,ProjectError
from plcnext_mcp.operator_approval import issue_mcp_approval
from plcnext_mcp.endpoint_guard import endpoint_guard

class SyncObservationTests(unittest.TestCase):
    setUp=fixture.RecoveryTests.setUp
    snapshot=fixture.RecoveryTests.snapshot
    values=fixture.RecoveryTests.values
    prepare=fixture.RecoveryTests.prepare
    receipt=fixture.RecoveryTests.receipt
    def failed(self):
        peer=LocalRecoveryPeer(self.root/'peer',self.files,self.values());peer.__enter__();self.addCleanup(peer.__exit__,None,None,None)
        peer.state=2
        p=self.prepare(peer.address,peer.certificate_sha256,peer.port,expected_initial_state=2)
        self.receipt(p);original=runtime_monitor.read_runtime_plan
        def read(*args,**kwargs):
            o=original(*args,**kwargs)
            if peer.start_calls:
                for group in ('guards_before','guards_after'):
                    for row in o[group]:
                        if row['symbol']=='MainInstance.BootId':row['value']=''
            return o
        with patch.object(runtime_monitor,'read_runtime_plan',side_effect=read):
            result=recovery.execute_recovery_plan(self.store,self.pid,p['plan_id'],p['review_sha256'])
        self.assertEqual(result['failure_code'],'recovery_observation_failed',result)
        self.assertEqual(result['steps'][0]['status'],'control_already_complete')
        ref=p['children']['monitor'];o=original(self.store,self.pid,ref['plan_id'],ref['plan_sha256'])
        external=self.root/'external.json';external.write_text('PUBLIC later ready evidence')
        context=dict(project_id=self.pid,project_sha256=self.sha,plan_id=ref['plan_id'],plan_sha256=ref['plan_sha256'],
            expected_boot_id='PUBLIC-restored-boot',expected_configuration=p['policy']['expected_configuration'],
            expected_configuration_sha256=o['configuration_digest']['sha256'],external_evidence_path=str(external),
            external_evidence_sha256=sha(external.read_bytes()),description='PUBLIC late readiness')
        return peer,p,result,context
    def prepare_resolution(self,peer,p,r,c):
        return leases.prepare(self.store,self.pid,'sync:'+r['execution_id'],p['review_sha256'],peer.certificate_sha256,current_state=c)
    def test_skip_stop_late_ready_and_read_only_archive(self):
        peer,p,r,c=self.failed();old=Path(r['report_path']).read_bytes();plan=self.prepare_resolution(peer,p,r,c)
        self.assertTrue(plan['evidence']['stop_legally_skipped']);self.assertIsNone(plan['operation_id'])
        leases.inspect(self.store,self.pid,plan['plan_id'],plan['plan_sha256'])
        issue_mcp_approval(self.store.root,lambda:leases.approval_contract(self.store,self.pid,plan['plan_id'],plan['plan_sha256']),reason='PUBLIC archive only')
        counts=(peer.stop_calls,peer.start_calls,peer.reset_calls,peer.load_calls,peer.write_calls)
        done=leases.execute(self.store,self.pid,plan['plan_id'],plan['plan_sha256'])
        self.assertFalse(done['controller_mutations']);self.assertEqual(counts,(peer.stop_calls,peer.start_calls,peer.reset_calls,peer.load_calls,peer.write_calls))
        self.assertEqual(Path(r['report_path']).read_bytes(),old);self.assertEqual(peer.stop_calls,0)
    def test_active_execution_and_changed_evidence_rejected(self):
        peer,p,r,c=self.failed();guard=self.store._folder(self.pid)/'controller-recovery-plans'/p['plan_id']/'execution'
        with endpoint_guard(guard),self.assertRaises(ProjectError):self.prepare_resolution(peer,p,r,c)
        plan=self.prepare_resolution(peer,p,r,c)
        Path(c['external_evidence_path']).write_text('changed')
        with self.assertRaises(ProjectError):leases.inspect(self.store,self.pid,plan['plan_id'],plan['plan_sha256'])
    def test_invalid_skip_unknown_and_incomplete_readback_rejected(self):
        peer,p,r,c=self.failed();path=Path(r['report_path']);raw=path.read_bytes()
        for index,key,value in [(0,'initial_state_raw',3),(0,'action_sent',True),(0,'ack_received',True),(1,'files_verified',48),(1,'outcome_unknown',True)]:
            bad=json.loads(raw);bad['steps'][index][key]=value;path.write_text(json.dumps(bad))
            with self.assertRaises(ProjectError):self.prepare_resolution(peer,p,r,c)
        path.write_bytes(raw)
    def test_skip_stop_conflicting_or_unclosed_journal_rejected(self):
        peer,p,r,c=self.failed();path=Path(r['journal_path']);raw=path.read_bytes();events=[json.loads(x) for x in raw.splitlines()]
        from plcnext_mcp.controller_transport import PLC
        events.insert(-1,dict(operation='Invoke',service=PLC,method=3,mutating=True,send_attempted=False,response_received=False,
            recovery_stage='stopping',execution_id=r['execution_id']))
        path.write_text(''.join(json.dumps(x)+'\n' for x in events))
        with self.assertRaises(ProjectError):self.prepare_resolution(peer,p,r,c)
    def test_current_boot_change_rejects_no_lease_release(self):
        peer,p,r,c=self.failed();c['expected_boot_id']='wrong-boot'
        with self.assertRaises(ProjectError):self.prepare_resolution(peer,p,r,c)
        self.assertTrue(Path(r['endpoint_lease_path']).exists())
