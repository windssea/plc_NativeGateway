"""Stop-before-preflight regression and zero-transfer handoff over owned TLS only."""
import json,hashlib
from pathlib import Path
import xml.etree.ElementTree as ET
from unittest.mock import patch
import unittest
import test_controller_recovery as fixtures
from plcnext_mcp import controller_recovery as recovery,stopped_recovery as handoff,controller_preflight as preflight
from plcnext_mcp.recovery_test_peer import LocalRecoveryPeer
from plcnext_mcp.project import ProjectError,sha
from plcnext_mcp.endpoint_guard import endpoint_guard
from plcnext_mcp.controller_transfer import _endpoint_lease_root

class StoppedRecoveryTests(unittest.TestCase):
    setUp=fixtures.RecoveryTests.setUp
    snapshot=fixtures.RecoveryTests.snapshot
    values=fixtures.RecoveryTests.values
    prepare=fixtures.RecoveryTests.prepare
    receipt=fixtures.RecoveryTests.receipt

    def peer(self):
        p=LocalRecoveryPeer(self.root/'peer',self.files,self.values());p.__enter__();self.addCleanup(p.__exit__,None,None,None)
        return p

    def altered_manifest(self,peer):
        doc=ET.fromstring(self.files['PCWE.manifest.config'])
        ET.SubElement(doc.find('Files'),'File',{'path':'unsupported.dat','hash':'a'*128})
        peer.root.joinpath('PCWE.manifest.config').write_bytes(ET.tostring(doc))

    def old_failure(self):
        peer=self.peer();plan=self.prepare(peer.address,peer.certificate_sha256,peer.port);self.receipt(plan)
        peer.on_stop=self.altered_manifest
        result=recovery.execute_recovery_plan(self.store,self.pid,plan['plan_id'],plan['review_sha256'])
        self.assertEqual(result['stage'],'transferring',result);self.assertEqual(result['action_counts'],dict(stop=1,file_write=0,reset=0,load=0,start=0))
        peer.on_stop=None
        peer.root.joinpath('PCWE.manifest.config').write_bytes(self.files['PCWE.manifest.config'])
        return peer,plan,result

    def followup(self,peer,old,result):
        return handoff.prepare(self.store,self.pid,result['execution_id'],old['review_sha256'],peer.certificate_sha256,
            self.pid,self.sha,fixtures.PACKAGE,{'version':13,'device_count':50,'point_count':250,'enabled':True},'record_unknown_loss')

    def test_conflict_rejected_before_stop(self):
        peer=self.peer();self.altered_manifest(peer);plan=self.prepare(peer.address,peer.certificate_sha256,peer.port);self.receipt(plan)
        r=recovery.execute_recovery_plan(self.store,self.pid,plan['plan_id'],plan['review_sha256'])
        self.assertEqual(r['failure_code'],'preflight_rejected',r)
        self.assertEqual(r['action_counts'],dict(stop=0,file_write=0,reset=0,load=0,start=0))
        self.assertEqual(peer.state,3);self.assertFalse(r['endpoint_lease_retained'])
        self.assertEqual(r['download_preflight']['path_comparison']['unsupported_remote_extras']['paths'],['unsupported.dat'])

    def test_race_zero_write_failure_handoff_and_replay(self):
        peer,old,r=self.old_failure();old_bytes=Path(r['report_path']).read_bytes();new=self.followup(peer,old,r)
        self.assertTrue(handoff.inspect(self.store,self.pid,new['plan_id'],new['review_sha256'])['handoff_evidence_verified'])
        self.receipt(new);held=[]
        lease=_endpoint_lease_root()/(sha((peer.address+':'+str(peer.port)).encode())+'.json')
        peer.on_session=lambda _:held.append(lease.exists())
        restored=recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        self.assertEqual(restored['status'],'original_loaded_runtime_observed',restored)
        self.assertTrue(all(held));self.assertFalse(lease.exists());self.assertEqual(Path(r['report_path']).read_bytes(),old_bytes)
        counts=(peer.stop_calls,peer.start_calls,peer.write_calls);replay=recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        self.assertTrue(replay['replayed']);self.assertEqual(counts,(peer.stop_calls,peer.start_calls,peer.write_calls))
        job=Path(restored['report_path']).parent
        lease.write_bytes((job/'new-endpoint-lease.json').read_bytes())
        replay=recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        self.assertTrue(replay['lease_release_reconciled']);self.assertFalse(lease.exists())
        lease.write_bytes(b'new owner')
        replay=recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        self.assertFalse(replay['lease_release_reconciled']);self.assertEqual(lease.read_bytes(),b'new owner')
        job=Path(restored['report_path']).parent;self.assertTrue((job/'previous-endpoint-lease.json').exists());self.assertTrue((job/'handoff.json').exists())

    def test_active_execution_rejected_even_in_same_service(self):
        peer,old,r=self.old_failure()
        guard=self.store._folder(self.pid)/'controller-recovery-plans'/old['plan_id']/'execution'
        with endpoint_guard(guard),self.assertRaisesRegex(ProjectError,'busy'):self.followup(peer,old,r)
        self.followup(peer,old,r) # Service PID is still alive, execution lock is released.

    def test_wrong_pin_and_changed_evidence_denied(self):
        peer,old,r=self.old_failure();new=self.followup(peer,old,r)
        with self.assertRaises(ProjectError):handoff.snapshot(self.store,self.pid,r['execution_id'],old['review_sha256'],'0'*64)
        p=Path(r['journal_path']);p.write_bytes(p.read_bytes()+b'{}\n')
        with self.assertRaises(ProjectError):handoff.inspect(self.store,self.pid,new['plan_id'],new['review_sha256'])

    def test_missing_authorization_preserves_old_lease(self):
        peer,old,r=self.old_failure();new=self.followup(peer,old,r)
        lease=Path(r['endpoint_lease_path']);raw=lease.read_bytes();n=peer.connections
        result=recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        self.assertEqual(lease.read_bytes(),raw);self.assertEqual(peer.connections,n)
        self.assertFalse(result['controller_changed'])

    def test_post_handoff_preflight_failure_keeps_stopped_responsibility(self):
        peer,old,r=self.old_failure();new=self.followup(peer,old,r);self.receipt(new);self.altered_manifest(peer)
        result=recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        self.assertEqual(result['failure_code'],'preflight_rejected',result);self.assertTrue(result['endpoint_lease_retained'])
        self.assertEqual(peer.state,2);self.assertEqual(peer.start_calls,0)

    def test_partial_write_and_unknown_rejected(self):
        peer,old,r=self.old_failure();path=Path(r['report_path']);original=path.read_bytes()
        for key,value in [('mutation_request_count',1),('outcome_unknown',True),('configuration_reset_attempted',True),('cleanup_error_class','OSError')]:
            changed=json.loads(original);changed['steps'][1][key]=value;path.write_text(json.dumps(changed))
            with self.assertRaises(ProjectError):self.followup(peer,old,r)
        path.write_bytes(original)

    def test_interrupted_transition_never_replays_actions(self):
        peer,old,r=self.old_failure();new=self.followup(peer,old,r);self.receipt(new)
        real=handoff.adopt
        def crash(*a,**kw):real(*a,**kw);raise KeyboardInterrupt('PUBLIC process interruption')
        with patch.object(handoff,'adopt',side_effect=crash),self.assertRaises(KeyboardInterrupt):
            recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        before=(peer.stop_calls,peer.start_calls,peer.write_calls)
        replay=recovery.execute_recovery_plan(self.store,self.pid,new['plan_id'],new['review_sha256'])
        self.assertTrue(replay['endpoint_lease_retained']);self.assertEqual(before,(peer.stop_calls,peer.start_calls,peer.write_calls))

    def test_exact_omit_dlc_conflict_and_bounded_diff(self):
        peer=self.peer()
        self.files.pop('dlc.bin')
        doc=ET.fromstring(self.files['PCWE.manifest.config']);group=doc.find('Files')
        for e in list(group):
            if e.get('path')=='dlc.bin':group.remove(e)
        self.files['PCWE.manifest.config']=ET.tostring(doc)
        plan=self.prepare(peer.address,peer.certificate_sha256,peer.port);self.receipt(plan)
        r=recovery.execute_recovery_plan(self.store,self.pid,plan['plan_id'],plan['review_sha256'])
        diff=r['download_preflight']['path_comparison']
        self.assertEqual(diff['unsupported_remote_extras']['paths'],['dlc.bin']);self.assertIn('empty_capability_v1',diff['remediation'])
        self.assertEqual(peer.stop_calls,0);self.assertEqual(peer.write_calls,0)
        from plcnext_mcp.controller_transfer import _check_old_manifest
        from plcnext_mcp.controller_transport import ControllerFailure
        from types import SimpleNamespace
        for i in range(400):ET.SubElement(group,'File',{'path':str(i)+'x'*100,'hash':'a'*128})
        client=SimpleNamespace(read_many=lambda _: [{'result':0,'data':ET.tostring(doc)}])
        with self.assertRaises(ControllerFailure) as caught:_check_old_manifest(client,self.files)
        d=caught.exception.details['unsupported_remote_extras'];self.assertTrue(d['truncated'])
        self.assertLessEqual(len(d['paths']),128);self.assertLessEqual(sum(len(x.encode()) for x in d['paths']),8192)

    def test_async_terminal_alive_service_is_accepted(self):
        from plcnext_mcp import operation_jobs as jobs
        import time
        peer=self.peer();old=self.prepare(peer.address,peer.certificate_sha256,peer.port);self.receipt(old)
        peer.on_stop=self.altered_manifest
        op=jobs.start_recovery_operation(self.store,self.pid,old['plan_id'],old['review_sha256'])
        with jobs._registry_lock:worker=jobs._threads[jobs._key(self.store,self.pid,op['operation_id'])]
        worker.join(timeout=20);self.assertFalse(worker.is_alive())
        terminal=jobs.controller_operation_status(self.store,self.pid,op['operation_id'],old['review_sha256'],include_result=True)
        r=terminal['result'];self.assertEqual(r['stage'],'transferring',r)
        _,_,_,e=handoff.snapshot(self.store,self.pid,r['execution_id'],old['review_sha256'],peer.certificate_sha256,op['operation_id'])
        self.assertIn('operation_sha256',e)
        folder,record=jobs._load(self.store,self.pid,op['operation_id'],old['review_sha256'])
        record['phase']='transferring';jobs._atomic(folder/'operation.json',record)
        with self.assertRaises(ProjectError):handoff.snapshot(self.store,self.pid,r['execution_id'],old['review_sha256'],peer.certificate_sha256,op['operation_id'])

    def test_handoff_observation_budget_forwarded_and_bounded(self):
        peer,old,r=self.old_failure()
        args=(self.store,self.pid,r['execution_id'],old['review_sha256'],peer.certificate_sha256,
            self.pid,self.sha,fixtures.PACKAGE,{'version':13,'device_count':50,'point_count':250,'enabled':True},'record_unknown_loss')
        p=handoff.prepare(*args,maximum_runtime_observations=24,runtime_observation_interval_seconds=10)
        self.assertEqual(p['policy']['maximum_runtime_observations'],24)
        self.assertEqual(p['policy']['runtime_observation_interval_seconds'],10)
        default=handoff.prepare(*args);self.assertEqual(default['policy']['maximum_runtime_observations'],12)
        self.assertNotEqual(default['review_sha256'],p['review_sha256'])
        for count,interval in [(25,5),(0,5),(12,11),(24,11),(True,5)]:
            with self.assertRaises(ProjectError):handoff.prepare(*args,maximum_runtime_observations=count,runtime_observation_interval_seconds=interval)
