"""M10 offline task/Program lifecycle and explicit ownership, never PLC access."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import uuid
import xml.etree.ElementTree as ET

from plcnext_mcp.project import ProjectError, ProjectStore, read_archive, sha
from plcnext_mcp.task_configuration import (
    clone_program, change_cyclic_tasks, declare_task_ownership, inspect_task_configuration,
    update_cyclic_task, validate_cyclic_schedule, make_task_ownership_contract)
from plcnext_mcp.expanded_compile import _cold_project_snapshot
from plcnext_mcp.runtime_configuration import generate_runtime_configuration, validate_runtime_configuration

FROZEN=Path(__file__).resolve().parents[1]/'artifacts/aci-poc/NativeGateway.frozen.pcwex'


class MultitaskConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='independent-tasks-')
        self.addCleanup(self.temp.cleanup)
        self.store=ProjectStore(Path(self.temp.name)/'workspace')
        self.initial=self.store.import_copy(str(FROZEN))
        self.pid=self.initial['project_id']
        self.before=inspect_task_configuration(self.store,self.pid)
        self.primary=self.before['tasks'][0]['name']

    def current(self):
        return self.store.inspect(self.pid)

    def clone(self,name='IndependentProbe',**kwargs):
        return clone_program(self.store,self.pid,self.current()['project_sha256'],'Main',name,
            code=kwargs.get('code','Counter := Counter + 1;\n'),
            variables=kwargs.get('variables','VAR\n Counter : UDINT;\nEND_VAR\n'))

    def request(self,names=None):
        return {'schema':'plcnext-multitask-ownership-request/v1','exclusive_owner_task':self.primary,
            'independent_local_tasks':['IndependentTask'] if names is None else names,
            'no_cross_task_data_handoff':True,'primary_owns_existing_globals_and_native_io':True,
            'arbitrary_memory_safety_proven':False}

    def addition(self,**overrides):
        return {'name':'IndependentTask','program_type':'IndependentProbe','instance_name':'IndependentInstance',
                'interval_ns':100000000,'watchdog_ns':1000000000,'priority':30,**overrides}

    def add(self,**kwargs):
        return change_cyclic_tasks(self.store,self.pid,self.current()['project_sha256'],
            add_tasks=kwargs.pop('add_tasks',[self.addition()]),
            ownership_contract=kwargs.pop('ownership_contract',self.request()),**kwargs)

    def test_clone_fresh_ids_and_unrelated_payloads_preserved(self):
        raw,before,_,_=read_archive(Path(self.initial['project_path']))
        cloned=self.clone()
        _,after,_,_=read_archive(Path(cloned['project_path']))
        main_before=self.store.read_pou(self.pid,'Main')
        probe=self.store.read_pou(self.pid,'IndependentProbe')
        self.assertEqual(probe['kind'],'Program')
        self.assertNotEqual(main_before['id'],probe['id'])
        self.assertFalse(cloned['attached_to_task'])
        self.assertEqual(len(inspect_task_configuration(self.store,self.pid)['tasks']),1)
        for path,payload in before.items():
            if path not in ('PROJECT/PROJECT.proj','[Content_Types].xml'):
                self.assertEqual(after[path],payload,path)
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        self.assertEqual(Path(self.initial['project_path']).read_bytes(),raw)

    def test_multitask_task_and_instance_identities_and_full_runtime_bindings(self):
        self.clone()
        result=self.add()
        tasks=inspect_task_configuration(self.store,self.pid)
        self.assertEqual(len(tasks['tasks']),2)
        self.assertEqual(tasks['tasks'][0]['id'],self.before['tasks'][0]['id'])
        self.assertEqual(tasks['tasks'][0]['program_instances'],self.before['tasks'][0]['program_instances'])
        ids=[task['id'] for task in tasks['tasks']]+[instance['id'] for task in tasks['tasks'] for instance in task['program_instances']]
        self.assertEqual(len(ids),len(set(ids)))
        identity,members,_=_cold_project_snapshot(self.store,self.pid,result['project_sha256'])
        self.assertEqual(identity['capability']['task_count'],2)
        self.assertTrue(identity['capability']['source_isolation']['explicit_ownership_contract_verified'])
        contract=self.store._load(self.pid)[1]['multitask_ownership_contract']
        files,report=generate_runtime_configuration(members,ownership_contract=contract)
        self.assertEqual(len(report['tasks']),2)
        self.assertEqual(len(report['programs']),2)
        self.assertEqual(len(report['task_program_relations']),2)
        self.assertTrue(validate_runtime_configuration(files,report)['passed'])
        relation=next(node for node in ET.fromstring(files['Plc/Esm/PCWE.esm.config']).iter() if node.tag.endswith('}TaskProgramRelation'))
        self.assertTrue(relation.get('programName').startswith('Arp.Plc.Eclr/'))

    def test_add_delete_and_numeric_edit_roundtrip_preserves_existing_instance(self):
        self.clone()
        result=self.add()
        new_task=result['added_tasks'][0]['id']
        edited=update_cyclic_task(self.store,self.pid,result['project_sha256'],new_task,
            {'interval_ns':200000000,'watchdog_ns':1500000000,'priority':31})
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        _cold_project_snapshot(self.store,self.pid,edited['project_sha256'])
        deleted=change_cyclic_tasks(self.store,self.pid,edited['project_sha256'],delete_task_ids=[new_task])
        final=inspect_task_configuration(self.store,self.pid)
        self.assertEqual(len(final['tasks']),1)
        self.assertEqual(final['tasks'][0]['id'],self.before['tasks'][0]['id'])
        self.assertEqual(final['tasks'][0]['program_instances'],self.before['tasks'][0]['program_instances'])
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        self.assertNotIn('multitask_ownership_contract',self.store._load(self.pid)[1])
        _cold_project_snapshot(self.store,self.pid,deleted['project_sha256'])

    def test_shared_program_type_and_duplicate_instance_or_task_names_refused(self):
        self.clone()
        original_task=self.before['tasks'][0]
        invalid=[self.addition(program_type='Main'),
                 self.addition(instance_name=original_task['program_instances'][0]['name']),
                 self.addition(name=original_task['name'])]
        revision=self.current()['revision']
        for addition in invalid:
            with self.subTest(addition=addition),self.assertRaises(ProjectError):
                self.add(add_tasks=[addition])
            self.assertEqual(self.current()['revision'],revision)

    def test_unknown_program_esm_bad_timing_and_last_task_delete_refused(self):
        self.clone()
        for addition in [self.addition(program_type='Missing'),self.addition(esm_id=str(uuid.uuid4())),
                         self.addition(interval_ns=0),self.addition(watchdog_ns=True),self.addition(priority=100)]:
            with self.subTest(addition=addition),self.assertRaises(ProjectError):
                self.add(add_tasks=[addition])
        with self.assertRaises(ProjectError):
            change_cyclic_tasks(self.store,self.pid,self.current()['project_sha256'],
                delete_task_ids=[self.before['tasks'][0]['id']])
        self.assertEqual(self.current()['revision'],1)

    def test_no_implicit_ownership_for_legacy_pointer_or_external_program(self):
        self.clone()
        with self.assertRaisesRegex(ProjectError,'external/global/addressed/pointer'):
            self.add(ownership_contract=None)
        self.assertEqual(self.current()['revision'],1)

    def test_secondary_global_access_or_pointer_or_unknown_native_call_refused(self):
        for code,variables in [('Counter := TO_UDINT(IP_ACTIVE_SOCKETS);','VAR\n Counter : UDINT;\nEND_VAR'),
                               ('Counter := ADR(Counter);','VAR\n Counter : UDINT;\nEND_VAR'),
                               ('UnknownNativeStatefulCall();','VAR\n Counter : UDINT;\nEND_VAR')]:
            with self.subTest(code=code):
                if 'IndependentProbe' in {item['name'] for item in self.current()['pous']}:
                    pou=self.store.read_pou(self.pid,'IndependentProbe')
                    self.store.update_pous(self.pid,pou['project_sha256'],[{'pou_name':'IndependentProbe',
                        'expected_code_sha256':pou['code_sha256'],'expected_variables_sha256':pou['variables_sha256'],
                        'code':code,'variables':variables}])
                else:self.clone(code=code,variables=variables)
                with self.assertRaises(ProjectError):self.add()
        self.assertEqual(len(inspect_task_configuration(self.store,self.pid)['tasks']),1)

    def test_pou_edit_invalidates_contract_until_explicit_redeclaration(self):
        self.clone();self.add()
        pou=self.store.read_pou(self.pid,'IndependentProbe')
        changed=self.store.update_pous(self.pid,pou['project_sha256'],[{'pou_name':'IndependentProbe',
            'expected_code_sha256':pou['code_sha256'],'expected_variables_sha256':pou['variables_sha256'],
            'code':'Counter := Counter + 2;\n'}])
        with self.assertRaisesRegex(ProjectError,'contract is stale'):
            _cold_project_snapshot(self.store,self.pid,changed['project_sha256'])
        fixed=declare_task_ownership(self.store,self.pid,changed['project_sha256'],self.request())
        self.assertTrue(fixed['source_member_payloads_identical'])
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        _cold_project_snapshot(self.store,self.pid,fixed['project_sha256'])

    def test_redeclaration_never_accepts_shared_data_or_false_proof_claim(self):
        self.clone();self.add()
        bad={**self.request(),'arbitrary_memory_safety_proven':True}
        with self.assertRaises(ProjectError):
            declare_task_ownership(self.store,self.pid,self.current()['project_sha256'],bad)
        pou=self.store.read_pou(self.pid,'IndependentProbe')
        changed=self.store.update_pous(self.pid,pou['project_sha256'],[{'pou_name':'IndependentProbe',
            'expected_code_sha256':pou['code_sha256'],'expected_variables_sha256':pou['variables_sha256'],
            'code':'Counter := TO_UDINT(IP_ACTIVE_SOCKETS);'}])
        with self.assertRaisesRegex(ProjectError,'primary-owned globals'):
            declare_task_ownership(self.store,self.pid,changed['project_sha256'],self.request())

    def test_task_history_forged_program_assignment_not_authorized(self):
        self.clone();result=self.add()
        folder,manifest,members,_,_=self.store._current(self.pid)
        event=manifest['task_history'][0]
        event['add_tasks'][0]['instance_name']='ForgedInstance'
        self.store._save_manifest(folder,manifest)
        checked=self.store.validate(self.pid)
        self.assertFalse(checked['preservation_passed'])
        self.assertIn('invalid task history',checked['invalid_task_history'])

    def test_clone_and_fb_lifecycle_registration_history_interleave(self):
        cloned=self.clone()
        added=self.store.change_structure(self.pid,cloned['project_sha256'],add_fbs=[{'pou_name':'ExtraFB'}])
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        cloned_again=clone_program(self.store,self.pid,added['project_sha256'],'Main','AnotherProgram',
            code='',variables='VAR\nEND_VAR\n')
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        deleted=self.store.change_structure(self.pid,cloned_again['project_sha256'],delete_fbs=['ExtraFB'])
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        pou=self.store.read_pou(self.pid,'IndependentProbe')
        self.store.update_pous(self.pid,deleted['project_sha256'],[{'pou_name':'IndependentProbe',
            'expected_code_sha256':pou['code_sha256'],'expected_variables_sha256':pou['variables_sha256'],
            'code':'Counter := Counter + 3;'}])
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])

    def test_stale_source_and_clone_nonprogram_name_conflicts_refused(self):
        with self.assertRaisesRegex(ProjectError,'Stale'):
            clone_program(self.store,self.pid,'0'*64,'Main','IndependentProbe')
        with self.assertRaises(ProjectError):self.clone('Main')
        self.clone()
        with self.assertRaisesRegex(ProjectError,'Stale'):
            change_cyclic_tasks(self.store,self.pid,self.initial['project_sha256'],add_tasks=[self.addition()],ownership_contract=self.request())

    def test_failed_manifest_publish_leaves_current_revision_and_lock_intact(self):
        self.clone()
        current=self.current()
        with mock.patch.object(self.store,'_save_manifest',side_effect=OSError('PUBLIC disk full')):
            with self.assertRaises(OSError):self.add()
        self.assertEqual(self.current()['revision'],current['revision'])
        self.assertFalse((self.store._folder(self.pid)/'.edit.lock').exists())
        self.add()
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])


if __name__=='__main__':unittest.main()
