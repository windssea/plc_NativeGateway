"""MCP-facing async lifecycle and persistent cross-process cancel, no real PLC."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from plcnext_mcp import operation_jobs as jobs
from plcnext_mcp.project import ProjectStore,ProjectError,sha

ROOT=Path(__file__).resolve().parents[1]
FROZEN=ROOT/'artifacts/runtime-monitor-research/NativeGateway.restore-native-0.5.0.frozen.pcwex'


class OperationJobsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='operation-public-');self.addCleanup(self.temp.cleanup)
        self.store=ProjectStore(Path(self.temp.name)/'managed');p=self.store.import_copy(str(FROZEN))
        self.pid=p['project_id'];self.review='b'*32;self.digest='c'*64
        self.contract={'target':{'address':'192.0.2.18','port':41100,'expected_certificate_sha256':'a'*64},
            'source':{'project_sha256':p['project_sha256']},'package':{'inventory_sha256':'d'*64}}
        self.admit=patch.object(jobs,'_admit',return_value=self.contract);self.admit.start();self.addCleanup(self.admit.stop)
        self.finish=threading.Event();self.addCleanup(self.finish.set)
        self.running=threading.Event()

    def tearDown(self):
        self.finish.set()
        # Let owned workers publish their last snapshot before TemporaryDirectory
        # cleanup, including assertion failures during the initial status query.
        prefix=os.path.normcase(str(self.store.root.resolve()))+':'
        with jobs._registry_lock:
            threads=[t for key,t in jobs._threads.items() if key.startswith(prefix)]
        for thread in threads:thread.join(timeout=4)

    def driver(self,store,pid,review,digest,event):
        self.assertEqual((pid,review,digest),(self.pid,self.review,self.digest))
        event.record_progress('PUBLIC-boundary');self.running.set()
        while not self.finish.wait(.01):
            if event.is_set():return {'status':'recovery_failed','cancelled':True,'outcome_unknown':False,
                'controller_changed':False,'receipt_persisted':True,'endpoint_lease_retained':False}
        return {'status':'original_loaded_runtime_observed','outcome_unknown':False,'controller_changed':False,
            'receipt_persisted':True,'endpoint_lease_retained':False}

    def start(self,driver=None):
        self.driver_patch=patch.object(jobs,'_execute_recovery',side_effect=driver or self.driver)
        self.driver_patch.start();self.addCleanup(self.driver_patch.stop)
        result=jobs.start_recovery_operation(self.store,self.pid,self.review,self.digest)
        self.assertTrue(self.running.wait(3))
        return result

    def terminal(self,operation):
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            value=jobs.controller_operation_status(self.store,self.pid,operation['operation_id'],self.digest,include_result=True)
            if value['status'] in jobs._TERMINAL:return value
            time.sleep(.01)
        self.fail('Worker did not terminate.')

    def test_status_and_success_are_persistent_and_exactly_bound(self):
        operation=self.start()
        status=jobs.controller_operation_status(self.store,self.pid,operation['operation_id'],self.digest)
        self.assertEqual(status['phase'],'PUBLIC-boundary')
        self.assertFalse(status['approval_issued'])
        self.finish.set();done=self.terminal(operation)
        self.assertEqual(done['status'],'completed')
        self.assertEqual(done['result']['status'],'original_loaded_runtime_observed')
        with self.assertRaises(ProjectError):jobs.controller_operation_status(self.store,self.pid,operation['operation_id'],'e'*64)
        response=jobs.cancel_controller_operation(self.store,self.pid,operation['operation_id'],self.digest)
        self.assertEqual(response['cancel_request_status'],'already_terminal')
        self.assertFalse(response['inverse_action_sent'])

    def test_instrumented_fault_uses_fixed_driver_and_same_cancel_contract(self):
        def fault_driver(store,pid,review,digest,event):
            self.running.set()
            while not self.finish.wait(.01):
                if event.is_set():
                    return {'status':'fault_released_verified','cancel_requested':True,
                        'cancel_same_request_sent':True,'release_verified':True,
                        'outcome_unknown':False,'receipt_persisted':True,'endpoint_lease_retained':False}
            return {'status':'fault_released_verified','release_verified':True}
        with patch.object(jobs,'_execute_instrumented_fault',side_effect=fault_driver):
            operation=jobs.start_instrumented_fault_operation(self.store,self.pid,self.review,self.digest)
            self.assertTrue(self.running.wait(3))
            jobs.cancel_controller_operation(self.store,self.pid,operation['operation_id'],self.digest)
            done=self.terminal(operation)
        self.assertEqual(done['kind'],'instrumented_fault')
        self.assertTrue(done['result']['cancel_same_request_sent'])
        self.assertTrue(done['result']['release_verified'])

    @unittest.skipUnless(os.name=='nt','Windows sharing races are platform-specific')
    def test_transient_windows_reader_sharing_error_is_local_only(self):
        operation=self.start()
        original=Path.open;failures=[]
        def opening(path,*args,**kwargs):
            if path.name=='operation.json' and args and args[0]=='rb' and not failures:
                failures.append(path)
                raise PermissionError(13,'PUBLIC transient sharing violation')
            return original(path,*args,**kwargs)
        with patch.object(Path,'open',opening):
            value=jobs.controller_operation_status(self.store,self.pid,operation['operation_id'],self.digest)
        self.assertEqual(value['operation_id'],operation['operation_id'])
        self.assertEqual(len(failures),1)
        self.assertFalse(value['approval_issued'])

    def test_another_process_requests_cancel_and_worker_sees_marker(self):
        operation=self.start()
        code=('import sys,json;from pathlib import Path;from plcnext_mcp.project import ProjectStore;'
            'from plcnext_mcp.operation_jobs import cancel_controller_operation;'
            'print(json.dumps(cancel_controller_operation(ProjectStore(Path(sys.argv[1])),sys.argv[2],sys.argv[3],sys.argv[4])))')
        child=subprocess.run([sys.executable,'-I','-c',code,str(self.store.root),self.pid,operation['operation_id'],self.digest],
            capture_output=True,text=True,timeout=10)
        self.assertEqual(child.returncode,0,child.stderr)
        response=json.loads(child.stdout)
        self.assertEqual(response['cancel_request_status'],'requested')
        self.assertFalse(response['request_sent_actions_undone'])
        done=self.terminal(operation)
        self.assertEqual(done['status'],'failed');self.assertTrue(done['cancel_observed'])
        self.assertTrue(done['result']['cancelled'])

    def test_wrong_cancel_binding_no_marker_and_invalid_marker_fail_closed(self):
        operation=self.start();folder=Path(operation['operation_path']).parent
        with self.assertRaises(ProjectError):jobs.cancel_controller_operation(self.store,self.pid,operation['operation_id'],'e'*64)
        self.assertFalse((folder/'cancel-request.json').exists())
        (folder/'cancel-request.json').write_text('{malformed PUBLIC fixture')
        done=self.terminal(operation)
        self.assertTrue(done['cancel_marker_invalid']);self.assertTrue(done['result']['cancelled'])

    def test_dead_host_or_reused_pid_is_unknown_without_restart_or_deletion(self):
        operation=self.start();path=Path(operation['operation_path'])
        value=json.loads(path.read_bytes());value['host_process_birth']='PUBLIC-different-process'
        jobs._atomic(path,value)
        with patch('os.kill',side_effect=AssertionError('Never probe Windows process with kill')):
            status=jobs.controller_operation_status(self.store,self.pid,operation['operation_id'],self.digest)
        self.assertEqual(status['status'],'worker_outcome_unknown');self.assertTrue(status['outcome_unknown'])
        self.assertFalse(status['automatic_restart'])
        self.assertEqual(json.loads(path.read_bytes())['status'],'running')
        self.finish.set();self.terminal(operation)

    def test_result_tamper_is_rejected(self):
        operation=self.start();self.finish.set();done=self.terminal(operation)
        Path(done['result_path']).write_text('{}')
        with self.assertRaisesRegex(ProjectError,'changed'):
            jobs.controller_operation_status(self.store,self.pid,operation['operation_id'],self.digest,include_result=True)

    def test_uncaught_driver_failure_is_not_reported_as_no_device_effect(self):
        def driver(*args):
            self.running.set();raise RuntimeError('PUBLIC worker failure')
        operation=self.start(driver)
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            value=jobs.controller_operation_status(self.store,self.pid,operation['operation_id'],self.digest)
            if value['status']=='needs_attention':break
            time.sleep(.01)
        self.assertEqual(value['status'],'needs_attention');self.assertTrue(value['outcome_unknown'])
        self.assertFalse(value['automatic_restart'])

    def test_actual_local_tls_control_cancel_is_cooperative_not_inverse(self):
        from plcnext_mcp.controller_control import (ControllerControlClient,ControlScope,execute_control,_policy,_digest)
        from plcnext_mcp.controller_control_test_peer import LocalTlsControlPeer
        from plcnext_mcp.controller_transport import ControllerEndpoint
        with LocalTlsControlPeer(Path(self.temp.name)/'peer',fault='state_timeout',initial_state=3) as peer:
            endpoint=ControllerEndpoint(peer.address,peer.port,peer.certificate_sha256)
            review={'target':{'address':peer.address,'port':peer.port,'expected_certificate_sha256':peer.certificate_sha256},
                'source':self.contract['source'],'package':self.contract['package'],
                'policy':_policy('stop',None,5,3,None)}
            review['review_sha256']=_digest(review)
            def driver(store,pid,rid,digest,event):
                self.running.set();event.record_progress('PUBLIC-control-fixture')
                client=ControllerControlClient(endpoint,control_scope=ControlScope.loopback_fixture(review))
                return execute_control(client,review,cancel_event=event,poll_interval_seconds=.01)
            operation=self.start(driver)
            deadline=time.monotonic()+3
            while not peer.stop_calls and time.monotonic()<deadline:time.sleep(.01)
            self.assertEqual(peer.stop_calls,1)
            jobs.cancel_controller_operation(self.store,self.pid,operation['operation_id'],self.digest)
            done=self.terminal(operation)
            self.assertEqual(done['status'],'needs_attention')
            self.assertTrue(done['result']['cancelled']);self.assertTrue(done['result']['outcome_unknown'])
            self.assertEqual(peer.stop_calls,1);self.assertEqual(peer.start_calls,0)


if __name__=='__main__':unittest.main()
