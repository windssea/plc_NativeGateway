"""M12 bounded event/ACK evidence tests: local files and owned loopback only."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from plcnext_mcp.audit_collector import Exporter,EvidenceError,EVENT_FIELDS,DIAGNOSTIC_FIELDS,GAP_FIELDS
from plcnext_mcp.audit_export import DurableJournal,AuditClient,_AUTHORITY,_ACK
from plcnext_mcp.audit_test_peer import LocalAuditPeer

class Transport:
    def __init__(self, journal):
        self.journal=journal
        self.writes=[]
        self.hook=None
        self.read_calls=0
        self.values={'BootId':'boot-a', 'Active.Version':13, 'CaptureBuffer.AuditEnabled':True,
            'CaptureBuffer.AuditReadSeq':0,'CaptureBuffer.AuditWriteSeq':1,
            'CaptureBuffer.AssociationReadSeq':0,'CaptureBuffer.AssociationWriteSeq':0,
            'CaptureBuffer.AuditDropped':0,'CaptureBuffer.AssociationDropped':0,
            'CaptureBuffer.EvidenceComplete':True,'CaptureBuffer.Diagnostics.Revision':0}
        base='CaptureBuffer.AuditEvents[1].'
        self.values.update({base+'Event.'+n:0 for n in EVENT_FIELDS})
        self.values.update({base+'Event.SampleSeq':1,base+'Event.ConfigSlot':1,
            base+'Event.ConfigGeneration':7,base+'Event.PointIndex':1,
            base+'Decision':2,base+'Reason':0})
        base='CaptureBuffer.Configs[1].'
        for n,v in {'Generation':7,'GatewayId':'gateway','CaptureBootId':'boot-a',
            'Config.Version':13,'Config.DeviceCount':1,'Config.PointCount':1,
            'Config.Points[1].pointId':'point','Config.Points[1].dataType':'float64',
            'Config.Points[1].reportMode':'cyclic','Config.Points[1].reportIntervalMs':5000,
            'Config.Points[1].deadband':0,'Config.Devices[1].deviceId':'device',
            'Config.Devices[1].PointStart':1,'Config.Devices[1].PointCount':1}.items():
            self.values[base+n]=v
    def read(self, names):
        self.read_calls+=1
        if self.hook:self.hook(names)
        return {n:self.values[n] for n in names}
    def write(self, name, value):
        assert self.journal.rows, 'ACK before durable append'
        self.writes.append((name,value))



class AuditTests(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup);self.root=Path(t.name)
        self.journal=DurableJournal(self.root/'events.jsonl');self.addCleanup(self.journal.close)
        self.fixture=Transport(self.journal)
        self.fixture.values.update({k:'' if v=='utf8' else 0 for k,v in _ACK.items()})
    def client(self,fault='none'):
        values=self.fixture.values
        symbols={n:{'path':'Arp.Plc.Eclr/MainInstance.'+n,'symbol':'MainInstance.'+n,
            'wire_type':'utf8' if type(v) is str else 'bool' if type(v) is bool else 'uint64',
            'string_capacity':256} for n,v in values.items()}
        peer=LocalAuditPeer(self.root/'peer',symbols,values,fault=fault);peer.start();self.addCleanup(peer.close)
        plan={'target':{'address':peer.address,'port':peer.port,'expected_certificate_sha256':peer.certificate_sha256},
            'output_path':str(self.root/'events.jsonl'),'policy':{'expected_boot_id':'boot-a','maximum_network_bytes':1048576,'maximum_network_operations':20000}}
        client=AuditClient(plan,symbols,_AUTHORITY,lambda:None,lambda e:None);client.connect();self.addCleanup(client.close)
        return client,peer
    def test_tls_durable_capture_then_exact_four_ack_fields(self):
        client,peer=self.client();export=Exporter(client,self.journal)
        self.assertEqual(export.poll(),(1,0));self.assertFalse(client.ack_unknown)
        self.assertEqual(peer.field_writes,['CaptureBuffer.AuditAckBootId','CaptureBuffer.AuditAckSeq']*2)
        self.assertEqual(self.journal.durable['Audit'],1)
        self.assertEqual(peer.model.values['CaptureBuffer.AuditAckSeq'],1)
        rows=[json.loads(x) for x in (self.root/'events.jsonl').read_text().splitlines()]
        self.assertEqual(rows[0]['kind'],'dictionary');self.assertEqual(rows[1]['event']['Event.SampleSeq'],1)
        self.assertEqual(peer.errors,[])
    def test_fsync_failure_sends_no_ack(self):
        client,peer=self.client()
        with patch('plcnext_mcp.audit_collector.os.fsync',side_effect=OSError('disk failed')):
            with self.assertRaises(OSError):Exporter(client,self.journal).poll()
        self.assertEqual(peer.field_writes,[]);self.assertEqual(self.journal.durable['Audit'],0)
    def test_lost_commit_reply_and_wrong_readback_remain_unknown(self):
        for fault in ('commit_reply_lost','stage_mismatch'):
            # Each attempt is an independent local fixture, never a retry against a PLC.
            with self.subTest(fault=fault):
                client,peer=self.client(fault)
                with self.assertRaises(Exception):Exporter(client,self.journal).poll()
                self.assertTrue(client.ack_unknown);self.assertEqual(len(peer.field_writes),4)
                client.close();peer.close()
                self.journal.close();(self.root/'events.jsonl').unlink()
                self.journal=DurableJournal(self.root/'events.jsonl');self.addCleanup(self.journal.close)
    def test_no_arbitrary_write_or_unpersisted_ack(self):
        client,peer=self.client()
        with self.assertRaises(EvidenceError):client._fixed_write('CaptureBuffer.AuditAckSeq',999)
        with self.assertRaises(EvidenceError):client.acknowledge('Audit','boot-a',1,self.journal)
        with self.assertRaises(EvidenceError):client.acknowledge('Business','boot-a',1,self.journal)
        self.assertEqual(peer.field_writes,[])
    def test_lost_prefix_overflow_boot_and_generation_fail_before_ack(self):
        for key,value in [('CaptureBuffer.AuditReadSeq',1),('CaptureBuffer.AuditDropped',1),
            ('CaptureBuffer.AssociationDropped',1),('CaptureBuffer.AuditWriteSeq',513),
            ('CaptureBuffer.Configs[1].Generation',8),('CaptureBuffer.EvidenceComplete',False)]:
            with self.subTest(key=key):
                old=self.fixture.values[key];self.fixture.values[key]=value
                client,peer=self.client()
                with self.assertRaises(EvidenceError):Exporter(client,self.journal).poll()
                self.assertEqual(peer.field_writes,[]);client.close();peer.close();self.fixture.values[key]=old
    def test_record_and_byte_caps(self):
        with DurableJournalContext(self.root/'small.jsonl',max_records=1) as j:
            j.append([{}])
            with self.assertRaises(EvidenceError):j.append([{},{}])
            self.assertEqual(j.records,1)
        with DurableJournalContext(self.root/'bytes.jsonl',max_bytes=4) as j:
            j.append([{}])
            with self.assertRaises(EvidenceError):j.append([{}])
    def test_identical_utc_keeps_distinct_sequences_and_tail_bound(self):
        values=self.fixture.values;prefix='CaptureBuffer.AuditEvents[1].'
        for seq in (2,3):
            values.update({f'CaptureBuffer.AuditEvents[{seq}].'+n[len(prefix):]:v for n,v in list(values.items()) if n.startswith(prefix)})
            values[f'CaptureBuffer.AuditEvents[{seq}].Event.SampleSeq']=seq
        values['CaptureBuffer.AuditWriteSeq']=3
        client,peer=self.client();export=Exporter(client,self.journal);export.tail=(2,0)
        self.assertEqual(export.poll(),(2,0));self.assertEqual(export.capture,2)
        rows=[json.loads(x) for x in (self.root/'events.jsonl').read_text().splitlines() if '"kind":"capture"' in x]
        self.assertEqual([r['event']['Event.SampleSeq'] for r in rows],[1,2])
    def test_restart_never_overwrites_previous_evidence(self):
        self.journal.append([{'kind':'start'}])
        with self.assertRaises(FileExistsError):DurableJournal(self.root/'events.jsonl')

    def test_boot_or_config_changes_between_fsync_and_ack(self):
        for field,value in [('BootId','other-boot'),('Active.Version',14)]:
            client,peer=self.client();original=self.journal.append
            def append(rows):
                original(rows);peer.model.values[field]=value
            # Pin the configuration as the real executor does before collecting.
            client.config=13
            with patch.object(self.journal,'append',side_effect=append):
                with self.assertRaises(EvidenceError):Exporter(client,self.journal).poll()
            self.assertEqual(peer.field_writes,[]);client.close();peer.close()
            self.journal.close();(self.root/'events.jsonl').unlink();self.journal=DurableJournal(self.root/'events.jsonl');self.addCleanup(self.journal.close)
    def test_ring_wrap_preserves_contiguous_sample_sequence(self):
        self.fixture.values['CaptureBuffer.AuditReadSeq']=512
        self.fixture.values['CaptureBuffer.AuditWriteSeq']=513
        self.fixture.values['CaptureBuffer.AuditEvents[1].Event.SampleSeq']=513
        self.journal.durable['Audit']=512
        client,peer=self.client();client.last_ack['Audit']=512
        export=Exporter(client,self.journal);export.capture=512
        self.assertEqual(export.poll(),(1,0));self.assertEqual(export.capture,513)
    def test_association_copy_precedes_ack_and_has_sample_links(self):
        base='CaptureBuffer.Associations[1].'
        self.fixture.values.update({base+k:v for k,v in {'Ordinal':1,'MessageId':'PUBLIC-msg','Digest':'a'*64,'Count':1,
            'ConfigSlot':1,'ConfigGeneration':7,'BatchGeneration':9,'Category':2,'SampleSeqs[1]':1}.items()})
        self.fixture.values['CaptureBuffer.AssociationWriteSeq']=1
        client,peer=self.client();self.assertEqual(Exporter(client,self.journal).poll(),(1,1))
        self.assertEqual(self.journal.durable,{'Audit':1,'Association':1})
        self.assertEqual(peer.field_writes[-4:],['CaptureBuffer.AssociationAckBootId','CaptureBuffer.AssociationAckSeq']*2)

class AuditRunnerTests(unittest.TestCase):
    setUp=AuditTests.setUp
    client=AuditTests.client
    # Reuses the same owned TLS fixture; all package/source mocks stay local.
    def runner(self,*,cancel=False,package_match=True):
        import plcnext_mcp.audit_export as a
        from types import SimpleNamespace
        from plcnext_mcp.operator_approval import OperatorApprovalContract,issue_mcp_approval
        base='CaptureBuffer.Diagnostics.'
        for n in DIAGNOSTIC_FIELDS+[f'Totals[{i}]' for i in range(1,17)]+['LastGap.'+n for n in GAP_FIELDS]:self.fixture.values[base+n]=0
        self.fixture.values[base+'Revision']=2;self.fixture.values[base+'BootId']='boot-a'
        self.fixture.values[base+'AccountingComplete']=True;self.fixture.values[base+'EvidenceComplete']=True
        for key,value in getattr(self,'diagnostic_snapshot',{}).items():
            if key!='LastGap.eventCount':self.fixture.values[base+key]=0 if value is None else value
        client,peer=self.client();client.close()  # Executor creates its own real TLS session.
        self.journal.close();(self.root/'events.jsonl').unlink()
        store=SimpleNamespace(root=self.root,_folder=lambda _:self.root)
        plan=client.plan|{'plan_id':'a'*32,'plan_sha256':'b'*64,'project_id':'c'*32,'project_sha256':'d'*64,
            'inventory_sha256':'e'*64,'symbols_sha256':'f'*64,'approved_actions':['PUBLIC audit'],
            'package_review':{'review_id':'1'*32,'review_sha256':'2'*64}}
        plan['policy']=plan['policy']|{'duration_seconds':1,'tail_seconds':1,'poll_interval_ms':20,'maximum_records':1000,'maximum_bytes':1048576}
        contract=OperatorApprovalContract('audit_export','b'*64,'plcnext-audit-export-operator-approval/v1',
            'controller-audit-export-approvals',{k:plan[k] for k in ('target','project_sha256','inventory_sha256','policy','approved_actions')},plan)
        patches=[patch.object(a,'_plan',return_value=(self.root,plan)),patch.object(a,'load',return_value=(self.root,plan,client.symbols)),patch.object(a,'approval_contract',return_value=contract),
            patch('plcnext_mcp.controller_transfer._endpoint_lease_root',return_value=self.root/'leases'),
            patch('plcnext_mcp.controller_package_read.read_reviewed_controller_package',return_value={'report_path':'PUBLIC',
                'remote_file_contents_verified':package_match,'changed_from_reviewed_candidate':[]})]
        for p in patches:p.start();self.addCleanup(p.stop)
        issue_mcp_approval(store.root,lambda:contract,reason='PUBLIC fixture')
        if cancel:a.cancel(store,'c'*32,'a'*32,'b'*64)
        return a,store,plan,peer
    def test_complete_runner_with_prefix_tail_and_hash(self):
        a,store,plan,peer=self.runner();result=a.execute(store,'c'*32,'a'*32,'b'*64)
        self.assertTrue(result['complete'],result);self.assertEqual(result['journal_sha256'],result['actual_file_sha256'])
        self.assertFalse(result['endpoint_lease_retained']);self.assertEqual(result['capture'],1)
        rows=[json.loads(x) for x in Path(plan['output_path']).read_text().splitlines()]
        self.assertEqual(rows[0]['kind'],'start');self.assertEqual(rows[-1]['kind'],'end')
        self.assertTrue(any(r['kind']=='tailBoundary' for r in rows))
        from plcnext_mcp.project import ProjectError
        writes=len(peer.field_writes)
        with self.assertRaises(ProjectError):a.execute(store,'c'*32,'a'*32,'b'*64)
        self.assertEqual(len(peer.field_writes),writes)
    def test_cancel_before_network_never_acks(self):
        a,store,plan,peer=self.runner(cancel=True);result=a.execute(store,'c'*32,'a'*32,'b'*64)
        self.assertFalse(result['complete']);self.assertEqual(peer.field_writes,[])
    def test_package_mismatch_never_acks(self):
        a,store,plan,peer=self.runner(package_match=False);result=a.execute(store,'c'*32,'a'*32,'b'*64)
        self.assertFalse(result['complete']);self.assertEqual(peer.field_writes,[])
    def test_host_loss_is_unknown_and_no_restart(self):
        a,store,plan,peer=self.runner()
        (self.root/'started.json').write_text(json.dumps({'host_pid':12345,'host_process_birth':'PUBLIC-dead'}))
        with patch.object(a,'_process_birth',return_value=None):result=a.status(store,'c'*32,'a'*32,'b'*64)
        self.assertEqual(result['status'],'host_outcome_unknown');self.assertFalse(result['automatic_retry'])

    def test_same_endpoint_consumer_is_exclusive(self):
        from plcnext_mcp.controller_control import ControlEndpointLease
        from plcnext_mcp.project import ProjectError
        a,store,plan,peer=self.runner()
        review={'target':plan['target'],'review_sha256':plan['plan_sha256'],'policy':{'plan_id':plan['plan_id']}}
        held=ControlEndpointLease(review,self.root)
        try:
            with self.assertRaises(ProjectError):a.execute(store,'c'*32,'a'*32,'b'*64)
        finally:held.release()
        self.assertEqual(peer.field_writes,[])
    def test_cancellation_after_first_durable_cursor_stops_without_retry(self):
        a,store,plan,peer=self.runner();original=AuditClient.acknowledge
        def ack(client,*args):
            original(client,*args);a.cancel(store,'c'*32,'a'*32,'b'*64)
        with patch.object(AuditClient,'acknowledge',ack):result=a.execute(store,'c'*32,'a'*32,'b'*64)
        self.assertFalse(result['complete']);self.assertEqual(len(peer.field_writes),4)
        self.assertFalse(result['outcome_unknown'])

class DurableJournalContext(DurableJournal):
    def __enter__(self):return self
    def __exit__(self,*args):self.close()


class AuditSourceTests(unittest.TestCase):
    def test_full_fixed_source_profile_and_original_unsupported(self):
        from plcnext_mcp.project import ProjectStore,ProjectError
        from plcnext_mcp.audit_export import _symbols,names
        root=Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as tmp:
            store=ProjectStore(Path(tmp))
            candidate=store.import_copy(str(root/'artifacts/audit-export-research/NativeGateway.audit-source.frozen.pcwex'))
            symbols=_symbols(store,candidate['project_id'],candidate['project_sha256'])
            self.assertEqual(set(symbols),set(names()));self.assertEqual(len(symbols),17074)
            original=store.import_copy(str(root/'artifacts/runtime-monitor-research/NativeGateway.restore-native-0.5.0.frozen.pcwex'))
            with self.assertRaisesRegex(ProjectError,'audit_profile_unsupported'):_symbols(store,original['project_id'],original['project_sha256'])

class FrozenDiagnosticsTests(unittest.TestCase):
    setUp=AuditTests.setUp
    client=AuditTests.client
    def frozen(self):
        data=json.loads((Path(__file__).parent/'fixtures/boot67-local-diagnostics.json').read_text(encoding='utf-8'))
        snap=data['row']['snapshot']
        # Fixture retains exact raw evidence; adapt only identity/nullable presentation
        # fields to this isolated transport's existing boot and wire representation.
        for key,value in snap.items():
            if key=='LastGap.eventCount':continue
            self.fixture.values['CaptureBuffer.Diagnostics.'+key]=0 if value is None else value
        self.fixture.values['CaptureBuffer.Diagnostics.BootId']='boot-a'
        return snap
    def test_frozen_business_unknown_does_not_block_durable_audit_ack(self):
        snap=self.frozen();self.assertFalse(snap['AccountingComplete'])
        self.assertTrue(snap['RestartLossUnknown']);self.assertTrue(snap['DetailTruncated'])
        client,peer=self.client();export=Exporter(client,self.journal)
        self.assertEqual(export.poll(),(1,0));self.assertEqual(len(peer.field_writes),4)
        self.assertEqual(export.business_completeness,{'globalAccountingComplete':False,'restartLossUnknown':True,'gapDetailTruncated':True})
        rows=[json.loads(l) for l in (self.root/'events.jsonl').read_text().splitlines()]
        saved=next(r['snapshot'] for r in rows if r['kind']=='localDiagnostics')
        self.assertFalse(saved['AccountingComplete']);self.assertTrue(saved['RestartLossUnknown'])
    def test_actual_diagnostic_loss_and_counter_overflow_still_block_ack(self):
        self.frozen()
        for key,value in [('EvidenceComplete',False),('CounterOverflow',True),('AuditDropped',1),('AssociationDropped',1)]:
            name='CaptureBuffer.Diagnostics.'+key;old=self.fixture.values[name];self.fixture.values[name]=value
            client,peer=self.client()
            with self.assertRaises(EvidenceError):Exporter(client,self.journal).poll()
            self.assertEqual(peer.field_writes,[]);client.close();peer.close();self.fixture.values[name]=old
            self.journal.close();(self.root/'events.jsonl').unlink()
            self.journal=DurableJournal(self.root/'events.jsonl');self.addCleanup(self.journal.close)
