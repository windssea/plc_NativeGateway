"""M08: finite receipt analysis, no P06, no PLC network or CPU inference."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

from plcnext_mcp import runtime_evidence as evidence
from plcnext_mcp.project import ProjectError, sha


def fixture_contract():
    roles=list(evidence.ROLES)
    return {'schema':evidence.PROBE_SCHEMA,'source_project_sha256':'a'*64,
        'probe_version':'PUBLIC-probe-v1','resolution_us':1,
        'fields':[{'role':role,'symbol':'Main.Probe.'+role,'unit':evidence.ROLES[role][0]} for role in roles]}


def fixture_observation(tick=0):
    values={'boot_id':'PUBLIC-boot-1','configuration_version':13,'reset_generation':1,
        'probe_version':'PUBLIC-probe-v1','device_monotonic_us':tick*5000000,
        'task_cycle_us':20000,'task_peak_us':1500+tick,'task_overrun_total':0,
        'watchdog_violation_total':0,'increment_probe_peak_us':800+tick,'release_total':tick*450}
    return {'schema':'plcnext-runtime-observation/v1','project_id':'c'*32,'plan_id':'d'*32,
        'plan_sha256':'e'*64,'source_project_sha256':'a'*64,'read_only':True,
        'control_requests_sent':False,'write_requests_sent':False,'force_requests_sent':False,
        'target':{'address':'192.0.2.8','port':41100,'expected_certificate_sha256':'f'*64},
        'status':'monitor_read_completed','consistency':'guarded_window_observation',
        'created_utc':'2026-10-26T00:00:00+00:00','finished_utc':'2026-10-26T00:00:01+00:00',
        'host_monotonic_clock_domain':'PUBLIC-separate-host-window-'+str(tick),
        'started_monotonic_ns':10000000000,'finished_monotonic_ns':11000000000,
        'bytes_received':1200,'bytes_sent':200,'network_operation_count':4,
        'items':[{'symbol':'Main.Probe.'+role,'status':'read','value':value,'source':'PUBLIC_fixture'} for role,value in values.items()]}


def analyze(records,contract=True):
    chosen=fixture_contract() if contract is True else contract
    return evidence.analyze_observations(records,chosen,source_project_sha256='a'*64,
        allowed_symbols=[f['symbol'] for f in fixture_contract()['fields']],expected_interval_seconds=5)


class RuntimeEvidenceTests(unittest.TestCase):
    def test_without_probe_does_not_reinterpret_rpc_duration(self):
        result=analyze([fixture_observation()],None)
        self.assertEqual(result['status'],'timing_evidence_unsupported')
        self.assertEqual(result['release_throughput']['status'],'unknown')
        self.assertEqual(result['windows'][0]['host_read_window_seconds'],1)
        self.assertFalse(result['windows'][0]['rpc_time_used_as_plc_cpu'])
        self.assertEqual(result['p06_acceptance']['status'],'not_evaluated')

    def test_probes_whole_task_and_increment_are_separate(self):
        result=analyze([fixture_observation(0),fixture_observation(1)])
        self.assertEqual(result['status'],'timing_evidence_observed')
        self.assertEqual(result['whole_task']['task_peak_us']['maximum_observed'],1501)
        self.assertEqual(result['increment_probe']['maximum_observed_us'],801)
        self.assertEqual(result['release_throughput']['events_per_second'],90)
        self.assertFalse(result['release_throughput']['unique_stored_release_semantics_verified'])
        self.assertIsNone(result['release_throughput']['acceptance_decision'])
        self.assertFalse(result['increment_probe']['worst_case_execution_proved'])
        self.assertEqual(result['baseline_comparison']['status'],'unknown')

    def test_boot_config_reset_changes_invalidate_without_stitching(self):
        for role,value in [('boot_id','PUBLIC-boot-2'),('configuration_version',14),('reset_generation',2)]:
            records=[fixture_observation(0),fixture_observation(1)]
            next(item for item in records[1]['items'] if item['symbol'].endswith('.'+role))['value']=value
            result=analyze(records)
            self.assertEqual(result['status'],'timing_evidence_invalidated')
            self.assertIsNone(result['release_throughput']['events_per_second'])
            self.assertIsNone(result['counter_deltas']['release_total']['delta'])

    def test_counter_decrease_and_missing_reset_guard_do_not_infer_wrap(self):
        records=[fixture_observation(1),fixture_observation(2)]
        next(i for i in records[1]['items'] if i['symbol'].endswith('.release_total'))['value']=1
        result=analyze(records)
        self.assertIsNone(result['counter_deltas']['release_total']['delta'])
        self.assertTrue(result['counter_deltas']['release_total']['counter_reset_or_wrap_possible'])
        records=[fixture_observation(0),fixture_observation(1)]
        records[0]['items']=[i for i in records[0]['items'] if not i['symbol'].endswith('.reset_generation')]
        result=analyze(records)
        self.assertFalse(result['guard_fields_complete'])
        self.assertIsNone(result['release_throughput']['events_per_second'])

    def test_missing_fields_bad_types_and_wrong_probe_version(self):
        for change in ('missing','wrong_type','wrong_version'):
            records=[fixture_observation(0),fixture_observation(1)]
            if change=='missing':records[1]['items']=[i for i in records[1]['items'] if not i['symbol'].endswith('.task_peak_us')]
            elif change=='wrong_type':next(i for i in records[1]['items'] if i['symbol'].endswith('.task_peak_us'))['value']='800'
            else:next(i for i in records[1]['items'] if i['symbol'].endswith('.probe_version'))['value']='PUBLIC-v2'
            result=analyze(records)
            self.assertEqual(result['status'],'timing_evidence_incomplete')
            self.assertEqual(result['whole_task']['task_peak_us']['status'],'incomplete')

    def test_device_clock_gaps_and_reset_are_reported(self):
        records=[fixture_observation(0),fixture_observation(3)]
        result=analyze(records)
        self.assertEqual(len(result['sampling_gaps']),1)
        records=[fixture_observation(1),fixture_observation(0)]
        result=analyze(records)
        self.assertIsNone(result['release_throughput']['events_per_second'])
        self.assertTrue(any(i['reason']=='device_monotonic_reset_or_nonincrease' for i in result['issues']))

    def test_mutating_unknown_duplicate_cross_target_and_count_rejected(self):
        cases=[]
        record=fixture_observation();record['write_requests_sent']=True;cases.append([record])
        record=fixture_observation();record['items'].append(deepcopy(record['items'][0]));cases.append([record])
        record=fixture_observation();record['items'][0]['symbol']='Arbitrary.Memory';cases.append([record])
        records=[fixture_observation(0),fixture_observation(1)];records[1]['target']['address']='192.0.2.9';cases.append(records)
        cases.append([fixture_observation()]*33)
        for records in cases:
            with self.assertRaises(ProjectError):analyze(records)

    def test_probe_units_source_and_role_whitelist_strict(self):
        for field,value in [('schema','invented'),('source_project_sha256','f'*64),('resolution_us',0)]:
            contract=fixture_contract();contract[field]=value
            with self.assertRaises(ProjectError):analyze([fixture_observation()],contract)
        contract=fixture_contract();contract['fields'][0]['unit']='ms'
        with self.assertRaises(ProjectError):analyze([fixture_observation()],contract)

    def test_exact_receipt_loader_and_no_network_adapter(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);pid='c'*32;oid='b'*32
            store=SimpleNamespace(_folder=lambda selected:root/selected)
            folder=root/pid/'runtime-observations'/oid;folder.mkdir(parents=True)
            record=fixture_observation();record['observation_id']=oid;record['report_path']=str(folder/'result.json')
            record['observation_sha256']=sha(evidence._canonical(record))
            (folder/'result.json').write_bytes(evidence._canonical(record)+b'\n')
            reference={'observation_id':oid,'observation_sha256':record['observation_sha256']}
            plan={'plan_id':'d'*32,'plan_sha256':'e'*64,'project_sha256':'a'*64,
                'requests':[{'symbol':f['symbol']} for f in fixture_contract()['fields']],
                'limits':{'minimum_interval_seconds':5}}
            with mock.patch('plcnext_mcp.runtime_monitor.load_runtime_read_plan',return_value=plan),mock.patch('socket.create_connection',side_effect=AssertionError('Receipt evidence must be offline')):
                result=evidence.runtime_timing_evidence(store,pid,'d'*32,'e'*64,[reference])
            self.assertFalse(result['device_contacted'])
            self.assertFalse(result['performance_test_started'])
            self.assertTrue(Path(result['report_path']).exists())
            record['items'][0]['value']='changed'
            (folder/'result.json').write_bytes(evidence._canonical(record))
            with self.assertRaises(ProjectError):evidence._load_observation(store,pid,reference)


if __name__=='__main__':unittest.main()
