"""Real in-memory TLS trust/name checks with no network sockets."""
import json
import socket
import ssl
import unittest
from unittest.mock import patch

from plcnext_mcp.offline_tls import offline_tls_probe, SERVER_NAME, MemoryTlsPair


class OfflineTlsTests(unittest.TestCase):
    def test_actual_tls12_and_rsc_header_roundtrip_without_socket(self):
        with patch.object(socket, 'socket', side_effect=AssertionError('Socket creation forbidden')):
            report = offline_tls_probe()
        self.assertTrue(report['passed'])
        self.assertTrue(report['handshake_completed'])
        self.assertEqual(report['tls_version'], 'TLSv1.2')
        self.assertEqual(report['server_name'], SERVER_NAME)
        self.assertTrue(report['trusted_test_ca_validated'])
        self.assertTrue(report['fixed_hostname_validated'])
        self.assertTrue(report['application_data_roundtrip'])
        self.assertTrue(report['synthetic_rsc_header_roundtrip'])
        self.assertFalse(report['socket_created'])
        self.assertFalse(report['real_endpoint_connected'])
        self.assertFalse(report['vendor_tls_compatibility_verified'])

    def test_real_certificate_verifier_rejects_untrusted_ca(self):
        with patch.object(socket, 'socket', side_effect=AssertionError('Socket creation forbidden')):
            report = offline_tls_probe('untrusted_peer')
        self.assertFalse(report['passed'])
        self.assertFalse(report['handshake_completed'])
        self.assertTrue(report['certificate_rejection_observed'])
        self.assertEqual(report['error_category'], 'untrusted_certificate_chain')

    def test_real_certificate_verifier_rejects_wrong_hostname(self):
        with patch.object(socket, 'socket', side_effect=AssertionError('Socket creation forbidden')):
            report = offline_tls_probe('hostname_mismatch')
        self.assertFalse(report['passed'])
        self.assertFalse(report['handshake_completed'])
        self.assertTrue(report['certificate_rejection_observed'])
        self.assertEqual(report['error_category'], 'hostname_mismatch')
        self.assertEqual(report['certificate_verification_code'], 62)

    def test_unknown_fault_is_rejected(self):
        with self.assertRaises(ValueError):
            offline_tls_probe('arbitrary_real_hostname')

    def test_unknown_ssl_error_is_not_misreported_as_expected_rejection(self):
        with patch.object(ssl.SSLObject, 'do_handshake', side_effect=ssl.SSLError('unexpected local failure')):
            with self.assertRaises(ssl.SSLError):
                offline_tls_probe('untrusted_peer')

    def test_report_contains_no_private_key_or_token_material(self):
        report = offline_tls_probe()
        encoded = json.dumps(report)
        self.assertNotIn('PRIVATE KEY', encoded)
        self.assertNotIn('token', encoded.lower())
        self.assertNotIn('credential', encoded.lower())

    def test_persistent_pair_carries_many_tls_records_and_reuses_handshake(self):
        payload = bytes(range(256)) * (1024 * 36)  # 9 MiB, over 500 TLS records.
        with patch.object(socket, 'socket', side_effect=AssertionError('Socket creation forbidden')):
            pair = MemoryTlsPair()
            self.assertEqual(pair.exchange(payload, lambda data: data[::-1]), payload[::-1])
            self.assertEqual(pair.exchange(b'second RPC', lambda data: data.upper()), b'SECOND RPC')
        self.assertEqual(pair.report['exchange_count'], 2)
        self.assertEqual(pair.report['tls_version'], 'TLSv1.2')

    def test_failed_pair_cannot_exchange(self):
        pair = MemoryTlsPair('hostname_mismatch')
        with self.assertRaises(RuntimeError):
            pair.exchange(b'bad', lambda data: data)


if __name__ == '__main__':
    unittest.main()
