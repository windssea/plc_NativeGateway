"""Independent ESM task changes preserve source identities and other payloads."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from plcnext_mcp.project import ProjectError, ProjectStore, read_archive, sha
from plcnext_mcp.task_configuration import inspect_task_configuration, update_cyclic_task
from plcnext_mcp.expanded_compile import _cold_project_snapshot

FROZEN = Path(__file__).resolve().parents[1] / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'


class TaskConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='task-edit-')
        self.addCleanup(self.temporary.cleanup)
        self.store = ProjectStore(Path(self.temporary.name) / 'managed')
        self.initial = self.store.import_copy(str(FROZEN))
        self.pid = self.initial['project_id']
        self.inspected = inspect_task_configuration(self.store, self.pid)
        self.task_id = self.inspected['tasks'][0]['id']

    def update(self, updates=None, **overrides):
        args = dict(store=self.store, project_id=self.pid,
                    expected_project_sha256=self.store.inspect(self.pid)['project_sha256'],
                    task_id=self.task_id, updates=updates or {'interval_ns': 25000000})
        args.update(overrides)
        return update_cyclic_task(**args)

    def test_inspect_reports_actual_source_and_mapping(self):
        task = self.inspected['tasks'][0]
        self.assertEqual(task['name'], 'Cyclic100')
        self.assertEqual(task['interval_ns'], 20000000)
        self.assertEqual(task['watchdog_ns'], 500000000)
        self.assertEqual(task['priority'], 0)
        self.assertEqual(task['program_instances'][0]['name'], 'MainInstance')
        self.assertEqual(task['program_instances'][0]['program_type'], 'Main')
        self.assertTrue(task['program_instances'][0]['local_program_pou_exists'])
        self.assertFalse(self.inspected['aci_used'])

    def test_only_numeric_attribute_bytes_change_and_mapping_preserved(self):
        original_raw, before, before_infos, before_comment = read_archive(Path(self.initial['project_path']))
        changed = self.update({'interval_ns': 25000000, 'watchdog_ns': 750000000, 'priority': 2})
        _, after, after_infos, after_comment = read_archive(Path(changed['project_path']))
        member = self.inspected['esm_member']
        expected = before[member].replace(b'intervalTime="20000000"', b'intervalTime="25000000"')
        expected = expected.replace(b'watchdogTime="500000000"', b'watchdogTime="750000000"')
        expected = expected.replace(b'priority="0"', b'priority="2"')
        self.assertEqual(after[member], expected)
        self.assertEqual({name for name in before if before[name] != after[name]}, {member})
        self.assertEqual(before_comment, after_comment)
        self.assertEqual([(i.filename, i.date_time, i.external_attr, i.comment) for i in before_infos],
                         [(i.filename, i.date_time, i.external_attr, i.comment) for i in after_infos])
        snapshot = inspect_task_configuration(self.store, self.pid)
        self.assertEqual(snapshot['tasks'][0]['program_instances'], self.inspected['tasks'][0]['program_instances'])
        self.assertEqual(snapshot['tasks'][0]['id'], self.task_id)
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        self.assertEqual(Path(self.initial['project_path']).read_bytes(), original_raw)
        self.assertFalse(changed['compiled'])
        self.assertFalse(changed['runtime_effect_verified'])
        # Existing cold build gate accepts the new source values, with no AST seed or ACI.
        identity, _, _ = _cold_project_snapshot(self.store, self.pid, changed['project_sha256'])
        self.assertEqual(identity['project_sha256'], changed['project_sha256'])
        with self.assertRaisesRegex(ProjectError, 'Stale'):
            _cold_project_snapshot(self.store, self.pid, self.initial['project_sha256'])

    def test_mixed_pou_fb_and_task_history_validates(self):
        self.update()
        pou = self.store.read_pou(self.pid, 'Main')
        changed = self.store.update_pous(self.pid, pou['project_sha256'], [{
            'pou_name': 'Main', 'expected_code_sha256': pou['code_sha256'],
            'expected_variables_sha256': pou['variables_sha256'], 'code': '(* task test *)\n' + pou['code']}])
        changed = self.store.change_structure(self.pid, changed['project_sha256'], add_fbs=[{'pou_name': 'TaskEditTestFB'}])
        self.update({'priority': 3})
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])
        self.assertEqual(inspect_task_configuration(self.store, self.pid)['tasks'][0]['priority'], 3)

    def test_stale_hash_no_change_unknown_task_and_bad_values_rejected(self):
        with self.assertRaisesRegex(ProjectError, 'Stale'):
            self.update(expected_project_sha256='0' * 64)
        with self.assertRaisesRegex(ProjectError, 'identity'):
            self.update(task_id='00000000-0000-0000-0000-000000000000')
        with self.assertRaisesRegex(ProjectError, 'no change'):
            self.update({'priority': 0})
        for values in ({'name': 'other'}, {'priority': -1}, {'priority': 100}, {'interval_ns': 0},
                       {'watchdog_ns': True}, {'interval_ns': 1.5}, {'priority': '3'},
                       {'interval_ns': 86400000000001}):
            with self.subTest(values=values), self.assertRaises(ProjectError):
                self.update(values)
        self.assertEqual(self.store.inspect(self.pid)['revision'], 0)

    def test_forged_history_cannot_authorize_program_mapping_change(self):
        changed = self.update()
        folder, manifest, members, infos, comment = self.store._current(self.pid)
        member = self.inspected['esm_member']
        members[member] = members[member].replace(b'name="MainInstance"', b'name="HijackedInstance"')
        path = Path(changed['project_path'])
        with zipfile.ZipFile(path, 'w') as archive:
            archive.comment = comment
            for info in infos:
                archive.writestr(info, members[info.filename])
        manifest['current_sha256'] = sha(path.read_bytes())
        manifest['task_history'][0]['after_sha256'] = sha(members[member])
        self.store._save_manifest(folder, manifest)
        result = self.store.validate(self.pid)
        self.assertFalse(result['preservation_passed'])
        self.assertEqual(result['invalid_task_history'], ['invalid task history'])
        self.assertIn(member, result['unexpected_members'])

    def test_manifest_save_failure_retains_old_revision_and_releases_lock(self):
        with patch.object(self.store, '_save_manifest', side_effect=OSError('disk full')):
            with self.assertRaisesRegex(OSError, 'disk full'):
                self.update()
        self.assertEqual(self.store.inspect(self.pid)['revision'], 0)
        self.assertFalse((self.store._folder(self.pid) / '.edit.lock').exists())
        self.update()
        self.assertTrue(self.store.validate(self.pid)['preservation_passed'])


if __name__ == '__main__':
    unittest.main()
