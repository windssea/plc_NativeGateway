"""Read-only send policy, fragmented frames, exact pin and failure boundaries.

All TLS/socket behavior below is an injected double; no test contacts a device.
"""
import hashlib
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

from plcnext_mcp import controller_readonly as reader
from plcnext_mcp.project import ProjectError
from plcnext_mcp.rsc_codec import CommandHeader, encode_header


CERTIFICATE = b'PUBLIC unit-test certificate placeholder, not DER or a private key'
PIN = hashlib.sha256(CERTIFICATE).hexdigest()


class Channel:
    def __init__(self, data=b''):
        self.data = data
        self.sent = []
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.closed = True

    def settimeout(self, seconds):
        assert 0 < seconds <= 30

    def recv(self, size):
        # Split every header and UInt32 value across reads.
        block, self.data = self.data[:min(size, 3)], self.data[min(size, 3):]
        return block

    def sendall(self, data):
        self.sent.append(data)

    def getpeercert(self, binary_form=False):
        assert binary_form
        return CERTIFICATE

    def version(self):
        return 'TLSv1.2'

    def cipher(self):
        return ('PUBLIC_TEST_CIPHER', 'TLSv1.2', 256)


def response(command, service=0, method=0, provider=0, flags=0x40):
    return encode_header(CommandHeader(command_type=command, flags=flags,
        service_handle=service, method_handle=method, service_provider_handle=provider))


class ControllerReadonlyTests(unittest.TestCase):
    def probe(self, channel, pin=PIN):
        tcp = Channel()
        context = unittest.mock.Mock()
        context.wrap_socket.return_value = channel
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(reader.socket, 'create_connection', return_value=tcp), \
                patch.object(reader.ssl, 'SSLContext', return_value=context):
            result = reader.read_controller_state(Path(directory), '192.0.2.8', pin)
            self.assertEqual(json.loads(Path(result['report_path']).read_text())['status'], result['status'])
        self.assertTrue(tcp.closed)
        self.assertTrue(channel.closed)
        return result

    def test_fragmented_state_reply_uses_dynamic_handles_and_only_three_requests(self):
        channel = Channel(response(8) + response(16, service=417, provider=901)
                          + response(3, service=417, method=5, provider=901)
                          + b'\x09' + struct.pack('<I', 3) + b'\xff')
        result = self.probe(channel)
        self.assertTrue(result['state_read'])
        self.assertEqual(result['plc_base_state'], 'Running')
        self.assertTrue(result['certificate_pin_verified'])
        self.assertFalse(result['pki_chain_and_hostname_verified'])
        self.assertEqual(channel.sent, [reader.encode_connect_request(), reader.readonly_discovery_request(),
                                        reader.readonly_state_request(417, 901)])
        self.assertFalse(result['downloaded'])
        self.assertFalse(result['program_started_or_stopped'])

    def test_changed_certificate_sends_no_rsc_application_data(self):
        channel = Channel()
        result = self.probe(channel, pin='0' * 64)
        self.assertEqual(result['status'], 'read_failed')
        self.assertEqual(result['stage'], 'certificate_pin')
        self.assertEqual(channel.sent, [])

    def test_unsupported_negotiation_stops_before_service_or_state_requests(self):
        channel = Channel(response(8, flags=0xc0))
        result = self.probe(channel)
        self.assertEqual(result['status'], 'read_failed')
        self.assertEqual(result['stage'], 'rsc_connect')
        self.assertEqual(len(channel.sent), 1)

    def test_rejected_service_and_state_have_no_retries_or_write_requests(self):
        for data, count in [(response(8) + response(16), 2),
                            (response(8) + response(16, 51, 0, 72) + response(4, 51, 5, 72), 3)]:
            with self.subTest(count=count):
                channel = Channel(data)
                result = self.probe(channel)
                self.assertFalse(result['state_read'])
                self.assertEqual(len(channel.sent), count)
                self.assertFalse(result['configuration_commands_sent'])

    def test_corrupt_header_wrong_state_tag_or_closed_connection_fail_closed(self):
        corrupt = bytearray(response(8))
        corrupt[10] ^= 1
        prefix = response(8) + response(16, 51, 0, 72) + response(3, 51, 5, 72)
        for data in [bytes(corrupt), prefix + b'\x08\x03\x00\x00\x00\xff', prefix + b'\x09\x03']:
            with self.subTest(data=data.hex()):
                result = self.probe(Channel(data))
                self.assertEqual(result['status'], 'read_failed')
                self.assertFalse(result['state_read'])

    def test_every_non_readonly_method_is_rejected_at_send_boundary(self):
        for method in (1, 2, 3, 4, 6, 7, 8):
            packet = response(2, 51, method, 72) + b'\xff'
            with self.subTest(method=method), self.assertRaises(ProjectError):
                reader.validate_readonly_request(packet, (51, 72))
        for handles in [None, (51, 73)]:
            with self.assertRaises(ProjectError):
                reader.validate_readonly_request(reader.readonly_state_request(51, 72), handles)
        with self.assertRaises(ProjectError):
            reader.validate_readonly_request(reader.readonly_state_request(51, 72) + b'\x00', (51, 72))

    def test_input_rejected_before_any_network_or_report_directory(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(reader.socket, 'create_connection') as connect:
            base = dict(address='192.0.2.8', expected_certificate_sha256=PIN, port=41100, timeout_seconds=5)
            for field, invalid in [('address', 'http://192.0.2.8'), ('address', True),
                                   ('expected_certificate_sha256', ''), ('expected_certificate_sha256', 'g' * 64),
                                   ('port', True), ('port', 65536), ('timeout_seconds', 0)]:
                with self.subTest(field=field, invalid=invalid), self.assertRaises(ProjectError):
                    reader.read_controller_state(Path(directory), **{**base, field: invalid})
            connect.assert_not_called()
            self.assertFalse(list(Path(directory).iterdir()))

    def test_total_deadline_expires_before_connect_without_retry(self):
        with patch.object(reader.time, 'monotonic', side_effect=[0, 6]), \
                patch.object(reader.socket, 'create_connection') as connect:
            result = reader._probe('192.0.2.8', 41100, PIN, 5)
        self.assertEqual(result['status'], 'read_failed')
        connect.assert_not_called()


if __name__ == '__main__':
    unittest.main()
