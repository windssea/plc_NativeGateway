"""Cache-assisted orchestration trust boundaries; no vendor tool execution."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest import mock
import zipfile

from plcnext_mcp import cached_compile as cc
from plcnext_mcp.project import ProjectError, ProjectStore, pou_index, read_archive, sha

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'


class ProjectCompileGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = ProjectStore(Path(self.temp.name) / 'projects')
        self.project = self.store.import_copy(str(FROZEN))

    def call(self, digest=None):
        return cc.compile_cached_ng_readack(self.store, self.project['project_id'],
                                           digest or self.project['project_sha256'])

    def test_stale_request_is_rejected_before_any_host(self):
        with mock.patch.object(cc.subprocess, 'run') as run:
            with self.assertRaisesRegex(ProjectError, 'Stale project'):
                self.call('0' * 64)
            run.assert_not_called()

    def test_other_pou_body_change_is_rejected_before_any_host(self):
        pou = self.store.read_pou(self.project['project_id'], 'Main')
        changed = self.store.patch_st(self.project['project_id'], 'Main', pou['project_sha256'],
                                      pou['code_sha256'], pou['code'], pou['code'] + '\n(* unsupported change *)')
        with mock.patch.object(cc.subprocess, 'run') as run:
            with self.assertRaisesRegex(ProjectError, 'Only the NG_ReadAck ST body'):
                self.call(changed['project_sha256'])
            run.assert_not_called()

    def test_variable_member_change_is_rejected_even_with_updated_manifest(self):
        path = Path(self.project['project_path'])
        _, members, infos, comment = read_archive(path)
        variable = cc.TARGET_MEMBER.removesuffix('Code.st') + 'Variables.var'
        members[variable] += b'\n'
        with zipfile.ZipFile(path, 'w') as archive:
            archive.comment = comment
            for info in infos:
                archive.writestr(info, members[info.filename])
        folder, manifest = self.store._load(self.project['project_id'])
        manifest['current_sha256'] = sha(path.read_bytes())
        self.store._save_manifest(folder, manifest)
        with mock.patch.object(cc.subprocess, 'run') as run:
            with self.assertRaisesRegex(ProjectError, 'Only the NG_ReadAck ST body'):
                self.call(manifest['current_sha256'])
            run.assert_not_called()

    def test_unknown_original_is_not_accepted_as_nativegateway(self):
        folder, manifest = self.store._load(self.project['project_id'])
        manifest['original_sha256'] = '0' * 64
        self.store._save_manifest(folder, manifest)
        with mock.patch.object(cc.subprocess, 'run') as run:
            with self.assertRaisesRegex(ProjectError, 'exact frozen NativeGateway'):
                self.call()
            run.assert_not_called()

    def test_polluted_seed_with_old_image_is_rejected(self):
        if not cc.DEFAULT_SEED.is_dir():
            self.skipTest('Measured local seed has not been prepared.')
        seed = Path(self.temp.name) / 'polluted-seed'
        shutil.copytree(cc.DEFAULT_SEED, seed)
        (seed / 'old-image.img').write_bytes(b'old image')
        with mock.patch.dict(os.environ, {'PLCNEXT_NATIVEGATEWAY_SEED': str(seed)}):
            with self.assertRaisesRegex(ProjectError, 'unexpected files'):
                cc._verified_seed()


@unittest.skipUnless(os.name == 'nt', 'Host orchestration is Windows-specific.')
class CachedHostGuards(unittest.TestCase):
    def setUp(self):
        ProjectCompileGuards.setUp(self)
        self.seed = Path(self.temp.name) / 'mock-seed'
        (self.seed / 'input').mkdir(parents=True)
        (self.seed / 'references').mkdir()
        (self.seed / 'input/LastBuild.ast').write_bytes(b'static model fixture')
        (self.seed / 'references/System.dll').write_bytes(b'runtime fixture')
        (self.seed / 'cilc.opt').write_text('-exename ' + cc.RESOURCE_NAME)
        self.manifest = {'files': {p.relative_to(self.seed).as_posix(): {'sha256': sha(p.read_bytes())}
                                   for p in self.seed.rglob('*') if p.is_file()}}
        self.install = Path(self.temp.name) / 'mock-install'
        self.seed_patch = mock.patch.object(cc, '_verified_seed', return_value=(self.seed, self.manifest, self.install))
        self.seed_patch.start()
        self.addCleanup(self.seed_patch.stop)
        self.shell_patch = mock.patch.object(cc.shutil, 'which', return_value='pwsh')
        self.shell_patch.start()
        self.addCleanup(self.shell_patch.stop)

    def call(self, digest=None):
        return ProjectCompileGuards.call(self, digest)

    def host(self, command, *, status='cil_generated', source_hash=None, old_image=False, **options):
        job = Path(command[command.index('-WorkRoot') + 1])
        digest = sha((job / 'source.st').read_bytes())
        report = {'status': status, 'source_sha256': source_hash or digest,
                  'source_sha256_after': digest, 'resource_name': cc.RESOURCE_NAME,
                  'semantic': {'errors': int(status == 'semantic_failed'), 'warnings': 0}}
        (job / 'host-result.json').write_text(json.dumps(report), encoding='utf-8')
        if status == 'cil_generated':
            output = job / 'generated'
            output.mkdir()
            applications = [name + '.dll' for name in pou_index(read_archive(FROZEN)[1])]
            applications += [cc.RESOURCE_NAME + '.Common.dll', cc.RESOURCE_NAME + '.exe']
            for name in applications:
                (output / name).write_bytes(b'new generated CIL fixture')
            if old_image:
                (output / (cc.RESOURCE_NAME + '.img')).write_bytes(b'stale image')
        self.assertEqual(options['timeout'], 30)
        self.assertNotIn('shell', options)
        return subprocess.CompletedProcess(command, 0, b'', b'')

    def test_semantic_failure_never_starts_backend(self):
        with mock.patch.object(cc.subprocess, 'run', side_effect=lambda c, **k: self.host(c, status='semantic_failed', **k)) as run:
            result = self.call()
        self.assertFalse(result['compiled'])
        self.assertEqual(result['stage'], 'semantic')
        self.assertEqual(run.call_count, 1)

    def test_source_hash_mismatch_never_starts_backend(self):
        with mock.patch.object(cc.subprocess, 'run', side_effect=lambda c, **k: self.host(c, source_hash='0' * 64, **k)) as run:
            result = self.call()
        self.assertFalse(result['compiled'])
        self.assertEqual(result['status'], 'host_input_mismatch')
        self.assertEqual(run.call_count, 1)

    def test_preexisting_native_image_is_rejected(self):
        with mock.patch.object(cc.subprocess, 'run', side_effect=lambda c, **k: self.host(c, old_image=True, **k)) as run:
            result = self.call()
        self.assertFalse(result['compiled'])
        self.assertEqual(result['status'], 'unexpected_old_image')
        self.assertEqual(run.call_count, 1)

    def test_host_timeout_never_becomes_success(self):
        with mock.patch.object(cc.subprocess, 'run', side_effect=subprocess.TimeoutExpired('pwsh', 30)) as run:
            result = self.call()
        self.assertFalse(result['compiled'])
        self.assertEqual(result['status'], 'host_timeout')
        self.assertEqual(run.call_count, 1)

    def test_native_failure_never_becomes_success(self):
        def execute(command, **options):
            if '-WorkRoot' in command:
                return self.host(command, **options)
            self.assertEqual(options['timeout'], 15)
            return subprocess.CompletedProcess(command, 3, b'', b'backend error')
        with mock.patch.object(cc.subprocess, 'run', side_effect=execute):
            result = self.call()
        self.assertFalse(result['compiled'])
        self.assertEqual(result['status'], 'backend_failed')


if __name__ == '__main__':
    unittest.main()
