"""Atomic multi-POU code/interface editing; no compiler, IDE or controller calls."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import tempfile
from threading import Barrier
import unittest
from unittest import mock
import zipfile

from plcnext_mcp.project import MAX_CODE, ProjectError, ProjectStore, read_archive, sha

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'
PREFIX = 'PROJECT/Logical%20Elements/NG_ReadAck.pou/'


class PouUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='plcnext-pou-update-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'source.pcwex'
        shutil.copyfile(FROZEN, self.source)
        self.source_bytes = self.source.read_bytes()
        self.fixture_hash = sha(FROZEN.read_bytes())
        self.store = ProjectStore(self.root / 'workspace')
        self.project = self.store.import_copy(str(self.source))
        self.project_id = self.project['project_id']

    def tearDown(self):
        self.assertEqual(self.source.read_bytes(), self.source_bytes)
        self.assertEqual(sha(FROZEN.read_bytes()), self.fixture_hash)

    def update(self, name='NG_ReadAck', **texts):
        pou = self.store.read_pou(self.project_id, name)
        return {'pou_name': name, 'expected_code_sha256': pou['code_sha256'],
                'expected_variables_sha256': pou['variables_sha256'], **texts}

    def commit(self, updates, digest=None):
        return self.store.update_pous(self.project_id, digest or self.project['project_sha256'], updates)

    def assert_uncommitted(self):
        folder = self.store.root / self.project_id
        self.assertEqual(self.store.inspect(self.project_id)['revision'], 0)
        self.assertEqual(len(list(folder.glob('revision-*.pcwex'))), 1)
        self.assertFalse((folder / '.edit.lock').exists())

    def test_all_existing_pous_code_and_variables_commit_in_one_revision(self):
        before = self.store.inspect(self.project_id)
        updates = []
        for item in before['pous']:
            pou = self.store.read_pou(self.project_id, item['name'])
            updates.append(self.update(item['name'], code=pou['code'] + '\n(* complete batch code *)\n',
                                       variables=pou['variables'] + '\n(* complete batch interface *)\n'))
        result = self.commit(updates)
        self.assertEqual(result['revision'], 1)
        self.assertEqual(len(result['updates']), 31)
        self.assertEqual(len(result['changed_members']), 62)
        self.assertFalse(result['compiled'])
        self.assertFalse(result['aci_used'])
        after = self.store.inspect(self.project_id)
        self.assertEqual(before['pous'], after['pous'])
        self.assertEqual(before['mapping_members'], after['mapping_members'])
        _, original, infos, comment = read_archive(self.source)
        _, current, new_infos, new_comment = read_archive(Path(result['project_path']))
        changed = set(result['changed_members'])
        self.assertEqual(set(original), set(current))
        for member in original:
            if member not in changed:
                self.assertEqual(original[member], current[member], member)
        self.assertEqual([i.filename for i in infos], [i.filename for i in new_infos])
        self.assertEqual(comment, new_comment)
        validated = self.store.validate(self.project_id)
        self.assertTrue(validated['preservation_passed'])
        self.assertEqual(validated['unexpected_members'], [])
        self.assertEqual(set(validated['changed_members']), changed)
        _, manifest = self.store._load(self.project_id)
        self.assertEqual(len(manifest['allowed_code_members']), 31)
        self.assertEqual(len(manifest['allowed_variable_members']), 31)
        self.assertEqual(len(manifest['history']), 1)

    def test_interface_only_update_keeps_code_and_metadata_exact(self):
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        new_vars = pou['variables'].replace('count : INT;', 'count : DINT;\n    AddedInput : BOOL;', 1)
        self.assertNotEqual(new_vars, pou['variables'])
        result = self.commit([self.update(variables=new_vars)])
        self.assertEqual(result['changed_members'], [PREFIX + 'Variables.var'])
        after = self.store.read_pou(self.project_id, 'NG_ReadAck')
        self.assertEqual(pou['code_sha256'], after['code_sha256'])
        self.assertEqual(pou['metadata_sha256'], after['metadata_sha256'])
        self.assertNotEqual(pou['variables_sha256'], after['variables_sha256'])
        self.assertEqual(self.store.diff(self.project_id, 'NG_ReadAck')['diff'], '')
        both = self.store.diff_pou(self.project_id, 'NG_ReadAck')
        self.assertEqual(both['code']['diff'], '')
        self.assertIn('+', both['variables']['diff'])
        bounded = self.store.diff_pou(self.project_id, 'NG_ReadAck', max_chars=12)
        self.assertEqual(len(bounded['variables']['diff']), 12)
        self.assertTrue(bounded['variables']['truncated'])

    def test_one_stale_variable_hash_rolls_back_entire_valid_batch(self):
        first = self.store.read_pou(self.project_id, 'Main')
        valid = self.update('Main', code=first['code'] + '\n(* valid first item *)')
        stale = self.update(variables='VAR\nnewVar : BOOL;\nEND_VAR')
        stale['expected_variables_sha256'] = '0' * 64
        with self.assertRaisesRegex(ProjectError, 'Stale variables worksheet'):
            self.commit([valid, stale])
        self.assert_uncommitted()

    def test_duplicate_pous_and_unknown_fields_never_create_a_revision(self):
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        update = self.update(code=pou['code'] + '\n(* change *)')
        for updates in ([update, update.copy()],
                        [update, dict(update, pou_name='ng_readack')],
                        [dict(update, metadata='<new-id/>')],
                        [dict(update, pou_name='NotExisting')], [], 'invalid'):
            with self.subTest(updates=updates):
                with self.assertRaises(ProjectError):
                    self.commit(updates)
                self.assert_uncommitted()

    def test_both_hashes_are_required_even_for_code_only_update(self):
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        update = self.update(code=pou['code'] + '\n(* edit *)')
        for values in (dict(update, expected_variables_sha256='0' * 64),
                       {k: v for k, v in update.items() if k != 'expected_variables_sha256'},
                       dict(update, expected_code_sha256=None)):
            with self.subTest(values=values):
                with self.assertRaises(ProjectError):
                    self.commit([values])
                self.assert_uncommitted()

    def test_stale_project_hash_cannot_apply_a_second_transaction(self):
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        self.commit([self.update(code=pou['code'] + '\n(* first *)')])
        after = self.store.read_pou(self.project_id, 'NG_ReadAck')
        with self.assertRaisesRegex(ProjectError, 'Stale project'):
            self.commit([self.update(code=after['code'] + '\n(* second *)')])
        self.assertEqual(self.store.inspect(self.project_id)['revision'], 1)

    def test_invalid_utf8_oversized_and_nontext_inputs_leave_no_revision(self):
        for text in ('\ud800', 'x' * (MAX_CODE + 1), 10, None):
            with self.subTest(text_type=type(text).__name__):
                with self.assertRaises(ProjectError):
                    self.commit([self.update(variables=text)])
                self.assert_uncommitted()

    def test_no_change_after_style_normalization_is_not_committed(self):
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        with self.assertRaisesRegex(ProjectError, 'no change'):
            self.commit([self.update(code=pou['code'], variables=pou['variables'])])
        self.assert_uncommitted()

    def test_declared_syntax_is_left_for_vendor_compiler(self):
        # An unfinished declaration is a valid draft update. This API must not
        # silently substitute its own ST parser or claim syntax/compile success.
        result = self.commit([self.update(code="'unfinished draft", variables='VAR_INPUT\nDraft :')])
        self.assertFalse(result['compiled'])
        after = self.store.read_pou(self.project_id, 'NG_ReadAck')
        self.assertEqual(after['code'], "'unfinished draft")
        self.assertIn('Draft :', after['variables'])
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_manifest_failure_rolls_back_all_updated_members(self):
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        updates = [self.update(code=pou['code'] + '\n(* code *)', variables=pou['variables'] + '\n(* variables *)')]
        with mock.patch.object(self.store, '_save_manifest', side_effect=OSError('injected storage failure')):
            with self.assertRaisesRegex(OSError, 'injected storage failure'):
                self.commit(updates)
        self.assert_uncommitted()
        self.assertEqual(self.store.read_pou(self.project_id, 'NG_ReadAck')['variables'], pou['variables'])
        self.assertEqual(self.commit(updates)['revision'], 1)

    def test_competing_batches_have_one_atomic_winner(self):
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        update = self.update(code=pou['code'] + '\n(* code *)', variables=pou['variables'] + '\n(* variables *)')
        barrier = Barrier(2)
        def run():
            barrier.wait(timeout=10)
            try:
                return self.commit([update])
            except ProjectError as exc:
                return exc
        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda _: run(), range(2)))
        self.assertEqual(sum(isinstance(r, dict) for r in results), 1)
        self.assertEqual(self.store.inspect(self.project_id)['revision'], 1)
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])

    def test_old_manifest_is_migrated_and_metadata_cannot_be_allowlisted(self):
        folder, manifest = self.store._load(self.project_id)
        manifest.pop('allowed_variable_members')
        self.store._save_manifest(folder, manifest)
        pou = self.store.read_pou(self.project_id, 'NG_ReadAck')
        self.commit([self.update(variables=pou['variables'] + '\n(* update *)')])
        self.assertTrue(self.store.validate(self.project_id)['preservation_passed'])
        folder, manifest = self.store._load(self.project_id)
        manifest['allowed_variable_members'].append(PREFIX + 'Metadata.meta')
        self.store._save_manifest(folder, manifest)
        validation = self.store.validate(self.project_id)
        self.assertFalse(validation['preservation_passed'])
        self.assertIn(PREFIX + 'Metadata.meta', validation['invalid_allowed_members'])


class WorksheetStyleTests(unittest.TestCase):
    def test_bom_newlines_and_archive_metadata_survive_two_worksheet_update(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / 'styles.pcwex'
            metadata = b'<FunctionBlock><Kind>FunctionBlock</Kind><Id>same-pou-id</Id><ItemGroup><Code><Id>code-id</Id></Code><Variables><Id>variables-id</Id></Variables></ItemGroup></FunctionBlock>'
            code = b'\xef\xbb\xbfvalue := 1;\r\nother := 2;\r\n'
            variables = b'VAR_INPUT\nvalue : INT;\nEND_VAR\n'
            code_info = zipfile.ZipInfo(PREFIX + 'Code.st', date_time=(2021, 2, 3, 4, 5, 6))
            code_info.comment = b'code-comment'
            code_info.external_attr = 0o100644 << 16
            with zipfile.ZipFile(source, 'w') as archive:
                archive.comment = b'project-comment'
                archive.writestr(code_info, code)
                archive.writestr(PREFIX + 'Variables.var', variables)
                archive.writestr(PREFIX + 'Metadata.meta', metadata)
                archive.writestr('opaque/data.bin', b'\x00\xffopaque')
            original_bytes = source.read_bytes()
            store = ProjectStore(root / 'workspace')
            imported = store.import_copy(str(source))
            pou = store.read_pou(imported['project_id'], 'NG_ReadAck')
            result = store.update_pous(imported['project_id'], imported['project_sha256'], [{
                'pou_name': 'NG_ReadAck', 'expected_code_sha256': pou['code_sha256'],
                'expected_variables_sha256': pou['variables_sha256'],
                'code': 'value := 3;\nother := 2;\n',
                'variables': '\ufeffVAR_INPUT\r\nvalue : DINT;\r\nEND_VAR\r\n',
            }])
            with zipfile.ZipFile(result['project_path']) as archive:
                self.assertEqual(archive.read(PREFIX + 'Code.st'), code.replace(b'1;', b'3;', 1))
                self.assertEqual(archive.read(PREFIX + 'Variables.var'), variables.replace(b'INT;', b'DINT;', 1))
                self.assertEqual(archive.read(PREFIX + 'Metadata.meta'), metadata)
                self.assertEqual(archive.read('opaque/data.bin'), b'\x00\xffopaque')
                self.assertEqual(archive.comment, b'project-comment')
                actual = archive.getinfo(PREFIX + 'Code.st')
                self.assertEqual((actual.date_time, actual.comment, actual.external_attr),
                                 (code_info.date_time, code_info.comment, code_info.external_attr))
            self.assertEqual(source.read_bytes(), original_bytes)

    def test_missing_variable_member_cannot_be_created(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / 'missing-var.pcwex'
            with zipfile.ZipFile(source, 'w') as archive:
                archive.writestr(PREFIX + 'Code.st', b'x:=0;')
                archive.writestr(PREFIX + 'Metadata.meta', b'<FunctionBlock><Kind>FunctionBlock</Kind><Id>pou-id</Id></FunctionBlock>')
            store = ProjectStore(root / 'workspace')
            imported = store.import_copy(str(source))
            pou = store.read_pou(imported['project_id'], 'NG_ReadAck')
            with self.assertRaisesRegex(ProjectError, 'no existing supported Variables.var'):
                store.update_pous(imported['project_id'], imported['project_sha256'], [{
                    'pou_name': 'NG_ReadAck', 'expected_code_sha256': pou['code_sha256'],
                    'expected_variables_sha256': pou['variables_sha256'], 'variables': 'VAR\nx:INT;\nEND_VAR',
                }])
            self.assertEqual(store.inspect(imported['project_id'])['revision'], 0)


if __name__ == '__main__':
    unittest.main()
