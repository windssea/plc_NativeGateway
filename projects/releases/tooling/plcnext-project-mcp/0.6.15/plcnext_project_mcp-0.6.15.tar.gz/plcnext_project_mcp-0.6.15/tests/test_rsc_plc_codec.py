"""PLC value codecs checked against original local formatter oracle bytes."""
import json
from pathlib import Path
import unittest

from plcnext_mcp.project import ProjectError
from plcnext_mcp.rsc_plc_codec import (
    PLC_METHODS, PLC_METHODS2, PLC_PROVIDER, PLC_SERVICE, PLC_SERVICE2,
    PLC_SERVICE_METADATA, decode_plc_request, decode_plc_response,
    encode_plc_request, encode_plc_response,
)

ORACLE = Path(__file__).resolve().parents[1] / 'artifacts/plc-download-research/load/plc-value-oracle.json'


@unittest.skipUnless(ORACLE.is_file(), 'Original local formatter oracle is unavailable')
class PlcValueOracleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.oracle = json.loads(ORACLE.read_text(encoding='utf-8-sig'))

    def test_v4_request_and_response_values_match_all_measured_vectors(self):
        vectors = [v for v in self.oracle['vectors'] if v['version'] == 4]
        self.assertEqual(len(vectors), 13)
        for vector in vectors:
            method = vector['method']
            with self.subTest(method=method, vector=vector):
                request = encode_plc_request(method, vector.get('async'))
                response = encode_plc_response(method, vector.get('raw_state'))
                self.assertEqual(request.hex(), vector['request_hex'])
                self.assertEqual(response.hex(), vector['response_hex'])
                self.assertEqual(decode_plc_request(method, request),
                    {} if method == 'GetPlcState' else {'async_': vector['async']})
                self.assertEqual(decode_plc_response(method, response), vector.get('raw_state'))

    def test_recorded_oracle_was_local_and_all_39_value_roundtrips_succeeded(self):
        self.assertEqual(len(self.oracle['vectors']), 39)
        self.assertEqual(self.oracle['network_operations_performed'], 0)
        self.assertFalse(self.oracle['target_online_objects_created'])
        for vector in self.oracle['vectors']:
            self.assertFalse(vector['tagging'])
            if vector['method'] != 'GetPlcState':
                self.assertTrue(vector['void_deserializer_accepted_empty'])
            else:
                self.assertTrue(vector['typed_roundtrip_passed'])
                self.assertTrue(vector['all_bytes_consumed'])

    def test_service_metadata_matches_real_interface_attributes(self):
        services = {s['interface_name']: s for s in self.oracle['services']}
        for name, ids in ((PLC_SERVICE, PLC_METHODS), (PLC_SERVICE2, PLC_METHODS2)):
            service = services[name]
            self.assertEqual(service['provider'], PLC_PROVIDER)
            self.assertIsNone(service['declared_service_version'])
            self.assertEqual({m['name']: m['id'] for m in service['methods']}, ids)
        self.assertFalse(PLC_SERVICE_METADATA['wire_service_discovery_verified'])
        base = {m['name']: m for m in services[PLC_SERVICE]['methods']}
        self.assertEqual(base['Reset']['parameters'], [{'name': 'async', 'type': 'System.Boolean'}])
        self.assertEqual(base['Load']['return_type'], 'System.Void')
        self.assertEqual(base['GetPlcState']['parameters'], [])
        self.assertEqual(base['GetPlcState']['return_type'], 'Arp.Plc.Domain.Services.PlcState')


class PlcValueBoundsTests(unittest.TestCase):
    def test_default_async_is_true_and_get_state_has_no_inputs(self):
        self.assertEqual(encode_plc_request('Reset'), b'\x01')
        self.assertEqual(encode_plc_request('Load'), b'\x01')
        self.assertEqual(encode_plc_request('GetPlcState'), b'')

    def test_uint32_state_preserves_high_error_bits_and_zero(self):
        for value, data in ((0, b'\0\0\0\0'), (0x80000002, b'\x02\0\0\x80'),
                            (0xFFFFFFFF, b'\xff' * 4)):
            self.assertEqual(encode_plc_response('GetPlcState', value), data)
            self.assertEqual(decode_plc_response('GetPlcState', data), value)

    def test_unsupported_method_versions_and_types_are_rejected(self):
        for method in ('Start', 'Stop', 'Change', 'Restart', 'reset', '', 4, None):
            with self.subTest(method=method), self.assertRaises(ProjectError):
                encode_plc_request(method)
        for version in (3, 5, 0, True, '4', None):
            with self.subTest(version=version), self.assertRaises(ProjectError):
                encode_plc_response('Reset', version=version)
        for value in (0, 1, 'true', b'\1', []):
            with self.subTest(value=value), self.assertRaises(ProjectError):
                encode_plc_request('Load', value)
        for value in (-1, 0x100000000, True, '2', None):
            with self.subTest(value=value), self.assertRaises(ProjectError):
                encode_plc_response('GetPlcState', value)

    def test_truncated_trailing_or_invalid_request_bytes_are_rejected(self):
        for payload in (b'', b'\x02', b'\xff', b'\x01\0', bytearray(b'\1'), None):
            with self.subTest(payload=payload), self.assertRaises(ProjectError):
                decode_plc_request('Reset', payload)
        for payload in (b'\0', b'\1', None):
            with self.subTest(payload=payload), self.assertRaises(ProjectError):
                decode_plc_request('GetPlcState', payload)
        with self.assertRaises(ProjectError):
            encode_plc_request('GetPlcState', True)

    def test_void_and_uint32_response_lengths_are_exact(self):
        for method in ('Reset', 'Load'):
            self.assertIsNone(decode_plc_response(method, b''))
            for payload in (b'\0', b'\1', bytearray(), None):
                with self.subTest(method=method, payload=payload), self.assertRaises(ProjectError):
                    decode_plc_response(method, payload)
            with self.assertRaises(ProjectError):
                encode_plc_response(method, 0)
        for payload in (b'', b'\0', b'\0' * 3, b'\0' * 5, bytearray(b'\0' * 4), None):
            with self.subTest(payload=payload), self.assertRaises(ProjectError):
                decode_plc_response('GetPlcState', payload)


if __name__ == '__main__':
    unittest.main()
