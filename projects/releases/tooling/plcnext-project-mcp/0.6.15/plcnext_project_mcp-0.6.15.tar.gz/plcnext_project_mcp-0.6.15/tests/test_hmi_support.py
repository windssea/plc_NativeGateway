"""Fresh HMI support generation, independent CRC oracle and refusal checks."""
import copy
import json
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

from plcnext_mcp.hmi_support import generate_hmi_support, hmi_checksums, _data_dictionary, PREFIX, UNLISTED_ASSETS
from plcnext_mcp.project import ProjectError, read_archive
from plcnext_mcp.runtime_configuration import generate_runtime_configuration

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / 'artifacts/headless-research/cil-frontend/input/RES_23CA7F267545404C9FED5DC977A6399F/Configuration/Projects/PCWE/Services/Ehmi/ehmi'
CURRENT = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex')
INSTALL = Path('D:/Program Files/PHOENIX CONTACT/PLCnext Engineer 2026.0')
PAGE_OUTPUT = ROOT / 'artifacts/pcwe-aux-research/probe-34'
TYPES = ROOT / 'artifacts/pcwe-build-research/finalized-types-06/TypeInformation.json'


class HmiChecksumTests(unittest.TestCase):
    @unittest.skipUnless(BASELINE.is_dir(), 'Independent recorded Engineer output is unavailable')
    def test_crc_matches_independent_vendor_output(self):
        files = {p.name: p.read_bytes() for p in BASELINE.iterdir() if p.is_file()}
        expected = json.loads(files['project.checksum-full.json'])
        summary, full = hmi_checksums(files, expected['id'])
        self.assertEqual(summary['checksum'], 1245810364)
        self.assertEqual(full, expected)
        self.assertEqual(len(full['files']), 24)

    @unittest.skipUnless(BASELINE.is_dir(), 'Independent recorded Engineer output is unavailable')
    def test_data_and_type_serializers_match_independent_vendor_output(self):
        _, members, _, _ = read_archive(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex')
        _, runtime = generate_runtime_configuration(members)
        # TypeInformation belongs to the resource folder, outside the PCWE tree.
        type_path = ROOT / 'artifacts/headless-research/cil-frontend/input/RES_23CA7F267545404C9FED5DC977A6399F/TypeInformation.json'
        information = json.loads(type_path.read_text(encoding='utf-8-sig'))
        data, types = _data_dictionary(members, information, runtime)
        self.assertEqual(data, json.loads((BASELINE / 'data.dictionary.json').read_text(encoding='utf8')))
        self.assertEqual(types, json.loads((BASELINE / 'type.dictionary.json').read_text(encoding='utf8')))

    def test_crc_changes_with_generated_data_but_not_late_stage_lists(self):
        files = {'project.json': b'{}', 'gateway.json': b'{"a":1}', 'textlist.json': b'[]'}
        before = hmi_checksums(files, 'x')[0]
        files['textlist.json'] = b'[1]'
        self.assertEqual(before, hmi_checksums(files, 'x')[0])
        files['gateway.json'] = b'{"a":2}'
        self.assertNotEqual(before, hmi_checksums(files, 'x')[0])


@unittest.skipUnless(CURRENT.is_file() and TYPES.is_file() and PAGE_OUTPUT.is_dir() and INSTALL.is_dir(),
                     'Local source/finalized-layout/vendor page fixtures are unavailable')
class HmiSupportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        _, cls.source, _, _ = read_archive(CURRENT)
        cls.types = json.loads(TYPES.read_text(encoding='utf-8-sig'))
        _, cls.runtime = generate_runtime_configuration(cls.source)
        cls.pages = {p.name: p.read_bytes() for p in PAGE_OUTPUT.iterdir() if p.is_file() and p.name != 'result.json'}
        cls.generated, cls.report = generate_hmi_support(cls.source, cls.types, cls.runtime, cls.pages, INSTALL, 'NativeGateway')

    def generate(self, members=None, types=None, runtime=None, pages=None):
        return generate_hmi_support(self.source if members is None else members,
            self.types if types is None else types, self.runtime if runtime is None else runtime,
            self.pages if pages is None else pages, INSTALL, 'NativeGateway')

    def load(self, name):
        return json.loads(self.generated[PREFIX + name])

    def test_complete_current_source_output_and_checksum_inventory(self):
        self.assertEqual(len(self.generated), 33)
        self.assertTrue(self.report['hmi_complete'])
        self.assertFalse(self.report['controller_acceptance_tested'])
        self.assertFalse(self.report['gui_cache_used'])
        self.assertEqual(self.report['runtime_mapping_count'], 10)
        self.assertEqual(self.report['runtime_type_count'], 20)
        project = self.load('project.json')
        self.assertEqual(project['name'], 'NativeGateway')
        self.assertEqual(project['homePage'], 'gateway.json')
        self.assertEqual(project['id'], 'ec4bcef4-d7ab-474c-80d7-b5dfda91b45d')
        self.assertTrue(all(PREFIX + n in self.generated for n in project['files']))
        self.assertFalse(set(project['files']) & UNLISTED_ASSETS)
        self.assertEqual(len(self.load('project.checksum-full.json')['files']), 24)
        local = {n.removeprefix(PREFIX): b for n, b in self.generated.items() if n.startswith(PREFIX)}
        self.assertEqual(hmi_checksums(local, project['id'])[1], self.load('project.checksum-full.json'))

    def test_new_layout_uses_current_fields_and_nonzero_offsets(self):
        types = self.load('type.dictionary.json')['Types']
        hmi = next(t for t in types if t['Name'] == 'NG_Hmi')
        current = next(t for t in self.types['Types'] if t['Name'] == 'NG_Hmi')
        self.assertEqual(hmi['RuntimeSize'], 19756)
        self.assertEqual(hmi['Fields'], [{k: f[k] for k in ('Name', 'FieldType', 'FieldOffset')} for f in current['Fields']])
        self.assertIn('HubBaselineVersion', [f['Name'] for f in hmi['Fields']])
        self.assertEqual(types[-1]['Name'], 'AlarmViewEntry')
        self.assertEqual(len(types[-1]['Fields']), 25)
        self.assertEqual(self.load('data.dictionary.json')['HmiVariables2']['Arp.Plc.Eclr/HMI']['Type'], 'NG_Hmi')
        self.assertEqual(self.load('data.dictionary.json')['HmiVariables2']['Arp.Plc.Eclr/ESM_DATA.ESM_INFOS[1].TICK_COUNT'],
                         {'Type': 'DINT', 'InitValue': '0', 'ReadOnly': True})

    def test_image_assets_and_localized_text_come_from_current_inputs(self):
        for item in self.report['images']:
            self.assertEqual(self.generated[PREFIX + item['file']], self.source[item['source']])
        for name, item in self.report['installed_assets'].items():
            self.assertEqual(self.generated[PREFIX + name], Path(item['path']).read_bytes())
        self.assertEqual(self.generated[PREFIX + 'languages-static.dictionary.json'], self.pages['languages-static.dictionary.json'])
        self.assertEqual(self.load('languages-dynamic.dictionary.json')['languages'], [])

    def test_zero_layout_missing_dependency_and_overlapping_field_rejected(self):
        for mutation in ('zero', 'missing', 'overlap'):
            types = copy.deepcopy(self.types)
            hmi = next(t for t in types['Types'] if t['Name'] == 'NG_Hmi')
            if mutation == 'zero':
                hmi['RuntimeSize'] = 0
            elif mutation == 'missing':
                hmi['Fields'][0]['FieldType'] = 'UnresolvedType'
            else:
                hmi['Fields'][1]['FieldOffset'] = hmi['Fields'][0]['FieldOffset']
            with self.subTest(mutation=mutation), self.assertRaises(ProjectError):
                self.generate(types=types)

    def test_stale_mapping_and_missing_page_are_rejected(self):
        runtime = copy.deepcopy(self.runtime)
        runtime['hmi_mappings'][0]['name'] = 'OldHmi'
        with self.assertRaisesRegex(ProjectError, 'does not match current source'):
            self.generate(runtime=runtime)
        pages = dict(self.pages)
        del pages['loginModule.js']
        with self.assertRaisesRegex(ProjectError, 'output inventory'):
            self.generate(pages=pages)

    def test_unknown_service_configuration_is_rejected(self):
        members = dict(self.source)
        path = next(n for n in members if n.endswith('.ds'))
        root = ET.fromstring(members[path])
        node = next(n for n in root.iter() if 'HMI:HttpPort' in n.get('xPath', ''))
        node.text = '8080'
        members[path] = ET.tostring(root)
        with self.assertRaisesRegex(ProjectError, 'hardware/service profile'):
            self.generate(members=members)

    def test_source_custom_initializer_and_dynamic_resources_rejected(self):
        members = dict(self.source)
        name = next(n for n in members if n.endswith('/GlobalVariables.var'))
        members[name] = members[name].replace(b'GW_Nav : INT ', b'GW_Nav : INT := 3 ')
        _, runtime = generate_runtime_configuration(members)
        with self.assertRaisesRegex(ProjectError, 'initializers'):
            self.generate(members=members, runtime=runtime)
        members = dict(self.source)
        members['PROJECT/extra.locreslst'] = b'<Resources/>'
        with self.assertRaisesRegex(ProjectError, 'dynamic HMI resource lists'):
            self.generate(members=members)


if __name__ == '__main__':
    unittest.main()
