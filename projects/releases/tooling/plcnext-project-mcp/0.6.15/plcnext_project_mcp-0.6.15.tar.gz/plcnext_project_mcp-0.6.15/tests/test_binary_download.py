"""Independent fault and boundary checks for socket-free TLS/RSC loopback.

These tests exercise original-oracle-backed codecs composed with a local server
double. They do not assert real firmware, credentials, discovery or PLC support.
"""
import json
import socket
import unittest
from unittest import mock

from plcnext_mcp import rsc_rpc_codec as rpc
from plcnext_mcp.binary_download import (
    BinaryLoopbackController, FILE_SERVICE, FS_SERVICE, PASSWORD_SERVICE, PLC_SERVICE, SERVICES,
)
from plcnext_mcp.download_services import FAULTS, FileSystemError, ServiceFailure, WriteFileData
from plcnext_mcp.download_simulation import execute_download
from plcnext_mcp.project import ProjectError
from plcnext_mcp.rsc_codec import CommandType

FILES = {'Plc/Eclr/eCLR.img': b'BINARY_LOOPBACK_PRIVATE_PAYLOAD_fixture_not_executed',
         'Plc/Domain/Domain.config': b'<offline-runtime-fixture/>'}


class BinaryDownloadTests(unittest.TestCase):
    def setUp(self):
        # The production implementation uses SSLObject/MemoryBIO. Any attempted
        # Python socket creation by the exercised implementation fails this test.
        self.no_socket = mock.patch.object(socket, 'socket', side_effect=AssertionError('Socket forbidden'))
        self.no_connect = mock.patch.object(socket, 'create_connection', side_effect=AssertionError('Network forbidden'))
        self.no_socket.start()
        self.no_connect.start()
        self.addCleanup(self.no_connect.stop)
        self.addCleanup(self.no_socket.stop)

    def ready(self, token_value=0):
        controller = BinaryLoopbackController(token_value=token_value)
        self.addCleanup(controller.close)
        controller.check_peer_policy()
        user, password = controller.credentials()
        error, token, penalty = controller.create_session(user, password)
        self.assertEqual((error, token, penalty), (0, token_value, 0))
        controller.enable_security(token)
        return controller

    def assert_closed(self, controller):
        self.assertTrue(controller.session_closed)
        self.assertFalse(controller._backend._authenticated)
        self.assertFalse(controller._backend._enabled)
        self.assertEqual(controller._backend._password, '')
        self.assertIsNone(controller._backend._token)
        self.assertIsNone(controller._client_token)
        self.assertFalse(controller._connected)
        self.assertFalse(controller._client_handles)
        self.assertFalse(controller._server_handles)
        self.assertIsNone(controller._pair)

    def test_real_memory_tls_full_binary_sequence_and_private_trace(self):
        controller = BinaryLoopbackController(token_value=0)
        password = controller._backend._password
        result = execute_download(FILES, controller)
        self.assertEqual(result['status'], 'simulation_passed')
        self.assertTrue(result['tls_handshake_performed'])
        self.assertTrue(result['binary_rpc_loopback_used'])
        self.assertTrue(result['rpc_close_session_confirmed'])
        self.assertEqual(controller.snapshot(), FILES)
        self.assertEqual(result['memory_tls']['tls_version'], 'TLSv1.2')
        self.assertTrue(result['memory_tls']['fixed_hostname_validated'])
        self.assertTrue(result['memory_tls']['trusted_test_ca_validated'])
        self.assertFalse(result['memory_tls']['socket_created'])
        self.assertFalse(result['memory_tls']['real_endpoint_connected'])
        self.assertFalse(result['memory_tls']['vendor_tls_compatibility_verified'])
        self.assertFalse(result['controller_connected'])
        self.assertFalse(result['controller_downloaded'])
        self.assertFalse(result['program_started'])
        self.assertFalse(result['deployable'])
        self.assertEqual(result['network_operations_performed'], 0)
        self.assertEqual(result['rpc_exchange_attempts'], result['rpc_exchanges_completed'])
        self.assertGreaterEqual(result['rpc_exchanges_completed'], 17)
        ops = [entry['operation'] for entry in controller.trace]
        self.assertEqual(ops.count('Simulator.RscGetServiceHandles'), 4)
        self.assertEqual(ops.count('Simulator.RscConnect'), 1)
        self.assertEqual(ops.count('IPlcManagerService.Reset'), 1)
        self.assertEqual(ops.count('IPlcManagerService.Load'), 1)
        self.assertLess(ops.index('IFileService2.ReadMany'), ops.index('IPlcManagerService.Reset'))
        self.assertLess(ops.index('IPlcManagerService.Reset'), ops.index('IPlcManagerService.Load'))
        close_calls = [e for e in controller.trace if e['operation'] == 'Simulator.RscInvoke'
                       and e['service'] == PASSWORD_SERVICE and e['method_id'] == 2]
        self.assertEqual(len(close_calls), 1)
        serialized = json.dumps(result) + json.dumps(controller.trace)
        self.assertNotIn(password, serialized)
        self.assertNotIn(controller.username, serialized)
        self.assertNotIn(FILES['Plc/Eclr/eCLR.img'].decode(), serialized)
        self.assert_closed(controller)

    def test_dynamic_provider_and_all_four_service_handles_are_discovered(self):
        registries = []
        for seed in (200, 700):
            with mock.patch('plcnext_mcp.binary_download.secrets.randbelow', side_effect=[seed, seed + 1]):
                controller = BinaryLoopbackController(token_value=0)
            self.addCleanup(controller.close)
            controller.check_peer_policy()
            self.assertEqual(set(controller._client_handles), set(SERVICES))
            self.assertEqual(controller._client_handles, controller._server_handles)
            self.assertEqual(len(set(controller._client_handles.values())), 4)
            self.assertEqual(controller._provider_handle, seed + 1)
            registries.append(dict(controller._client_handles))
        self.assertNotEqual(registries[0], registries[1])

    def test_zero_token_reaches_each_non_password_service_header(self):
        controller = self.ready(0)
        seen = []
        original = controller._exchange
        def capture(packet):
            if int.from_bytes(packet[2:4], 'little') == CommandType.INVOKE_REQUEST:
                header, token, _ = rpc.decode_request(packet)
                seen.append((header.service_handle, token))
            return original(packet)
        with mock.patch.object(controller, '_exchange', side_effect=capture):
            controller.get_state()
            controller.resolve_project_root()
            controller.get_space()
            controller.write_many([WriteFileData(controller.root + '/file', b'zero-token')])
            controller.read_many([controller.root + '/file'])
        self.assertGreaterEqual(len(seen), 6)
        self.assertTrue(all(token == 0 for _, token in seen))

    def test_discovery_rejects_wrong_provider_or_duplicate_dynamic_service_handle(self):
        for fault in ('provider', 'duplicate'):
            controller = BinaryLoopbackController(token_value=0)
            self.addCleanup(controller.close)
            original = controller._exchange
            first = None
            def corrupt(packet):
                nonlocal first
                response = original(packet)
                if int.from_bytes(packet[2:4], 'little') != CommandType.GET_SERVICE_HANDLES_REQUEST:
                    return response
                handle, provider = rpc.decode_get_service_confirmation(response)
                if fault == 'provider':
                    return rpc.encode_get_service_confirmation(handle, provider + 1)
                if first is None:
                    first = handle
                    return response
                return rpc.encode_get_service_confirmation(first, provider)
            with self.subTest(fault=fault):
                with mock.patch.object(controller, '_exchange', side_effect=corrupt):
                    with self.assertRaises(ServiceFailure) as caught:
                        controller.check_peer_policy()
                self.assertEqual(caught.exception.code, 'service_negotiation_failed')
                self.assertFalse(controller._backend._authenticated)

    def test_binary_files_fsinfo_and_large_record_transfer_readback(self):
        controller = self.ready(0)
        error, root = controller.resolve_project_root()
        self.assertEqual(error, FileSystemError.NONE)
        self.assertEqual(root, controller.root)
        self.assertGreater(controller.get_space(), 1024 * 1024)
        payload = bytes(range(256)) * 8193  # >2 MiB and >16 plaintext TLS records.
        path = root + '/Plc/large.bin'
        self.assertEqual(controller.write_many([WriteFileData(path, payload)]), [FileSystemError.NONE])
        self.assertEqual(controller.read_many([path]), [(FileSystemError.NONE, payload)])
        self.assertTrue(controller.tls_report['application_data_roundtrip'])
        self.assertGreater(controller.tls_report['exchange_count'], 10)

    def test_binary_value_payload_cannot_escape_resolved_simulated_root(self):
        controller = self.ready(0)
        for path in (controller.root + '/../outside', controller.root + 'extra/file',
                     controller.root + '/Plc/../../outside', controller.root + '/Plc\\file'):
            with self.subTest(path=path), self.assertRaises(ProjectError):
                controller.write_many([WriteFileData(path, b'private path fixture')])
        self.assertEqual(controller.snapshot(), {'obsolete-offline-fixture.tmp': b'previous simulated project'})

    def test_all_declared_faults_fail_closed_without_unrequested_load(self):
        for fault in FAULTS:
            if fault == 'none':
                continue
            with self.subTest(fault=fault):
                controller = BinaryLoopbackController(fault, token_value=0)
                result = execute_download(FILES, controller)
                self.assertEqual(result['status'], 'simulation_failed')
                self.assertFalse(result['simulated_configuration_loaded'])
                self.assertFalse(result['program_started'])
                ops = [e['operation'] for e in controller.trace]
                if fault not in ('load_timeout', 'load_error'):
                    self.assertNotIn('IPlcManagerService.Load', ops)
                if fault not in ('load_timeout', 'load_error', 'reset_timeout'):
                    self.assertNotIn('IPlcManagerService.Reset', ops)
                if fault == 'transport_interrupted':
                    self.assertTrue(result['simulated_writes_possible'])
                    self.assertEqual(ops.count('IFileService2.WriteMany'), 1)
                if fault in ('untrusted_peer', 'hostname_mismatch'):
                    self.assertNotIn('IPasswordAuthenticationService.CreateSession', ops)
                    self.assertNotIn('Simulator.RscConnect', ops)
                self.assert_closed(controller)

    def test_dispatch_rejects_corrupt_header_and_wrong_token_provider_service_method(self):
        controller = self.ready(0)
        handle = controller._client_handles[PLC_SERVICE]
        provider = controller._provider_handle
        valid = rpc.encode_request(handle, 5, b'', 0, provider_handle=provider)
        corrupted = bytearray(valid)
        corrupted[0] ^= 1
        packets = [bytes(corrupted), valid[:15],
            rpc.encode_request(handle, 5, b'', None, provider_handle=provider),
            rpc.encode_request(handle, 5, b'', 1, provider_handle=provider),
            rpc.encode_request(handle, 5, b'', 0, provider_handle=provider + 1),
            rpc.encode_request(max(controller._client_handles.values()) + 10, 5, b'', 0, provider_handle=provider),
            rpc.encode_request(handle, 99, b'', 0, provider_handle=provider),
            rpc.encode_response(handle, 5, b'', provider_handle=provider)]
        for packet in packets:
            with self.subTest(packet=packet.hex()), self.assertRaises((ServiceFailure, ValueError)):
                controller._dispatch(packet)

    def test_response_handle_and_unexpected_security_token_substitution_are_rejected(self):
        controller = self.ready(0)
        handle, provider = controller._client_handles[PLC_SERVICE], controller._provider_handle
        packets = [rpc.encode_response(handle + 1, 5, b'\x02\0\0\0', provider_handle=provider),
            rpc.encode_response(handle, 4, b'\x02\0\0\0', provider_handle=provider),
            rpc.encode_response(handle, 5, b'\x02\0\0\0', provider_handle=provider + 1),
            rpc.encode_response(handle, 5, b'\x02\0\0\0', token=0, provider_handle=provider),
            rpc.encode_response(handle, 5, b'\x02\0\0\0', token=123, provider_handle=provider)]
        for packet in packets:
            with self.subTest(packet=packet.hex()):
                with mock.patch.object(controller, '_exchange', return_value=packet):
                    with self.assertRaises((ServiceFailure, ValueError)):
                        controller.get_state()

    def test_scalar_response_schema_and_server_errors_do_not_become_success(self):
        controller = self.ready(0)
        handle, provider = controller._client_handles[PLC_SERVICE], controller._provider_handle
        for body in (b'', b'\0' * 3, b'\0' * 5):
            packet = rpc.encode_response(handle, 5, body, provider_handle=provider)
            with self.subTest(body=body):
                with mock.patch.object(controller, '_exchange', return_value=packet):
                    with self.assertRaises((ProjectError, ValueError)):
                        controller.get_state()
        error = rpc.encode_server_error(handle, 5, 536870921, 'PUBLIC offline error fixture', provider_handle=provider)
        with mock.patch.object(controller, '_exchange', return_value=error):
            with self.assertRaises(ServiceFailure) as caught:
                controller.get_state()
        self.assertEqual(caught.exception.code, 'rsc_server_error')

    def test_closed_session_is_terminal_idempotent_and_clears_transport_handles(self):
        controller = self.ready(0)
        controller.close()
        exchanges = controller.rpc_exchanges
        controller.close()
        self.assertEqual(controller.rpc_exchanges, exchanges)
        self.assertTrue(controller.rpc_cleanup_confirmed)
        self.assert_closed(controller)
        for action in (controller.check_peer_policy, lambda: controller._exchange(rpc.encode_connect_request()),
                       lambda: controller._dispatch(rpc.encode_connect_request()), controller.get_state):
            with self.assertRaises(ServiceFailure):
                action()

    def test_uncertain_close_response_still_clears_local_credentials_and_tls_state(self):
        controller = self.ready(0)
        handle = controller._client_handles[PASSWORD_SERVICE]
        bad_close = rpc.encode_response(handle, 99, b'', provider_handle=controller._provider_handle)
        with mock.patch.object(controller, '_exchange', return_value=bad_close):
            with self.assertRaises(ServiceFailure):
                controller.close()
        self.assertFalse(controller.rpc_cleanup_confirmed)
        self.assert_closed(controller)


if __name__ == '__main__':
    unittest.main()
