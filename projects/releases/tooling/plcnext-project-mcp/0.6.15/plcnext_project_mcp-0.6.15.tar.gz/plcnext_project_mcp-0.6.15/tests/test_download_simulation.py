"""Offline service-contract orchestration and source-bound package guards.

All device state and credentials below belong to an in-memory test double.
Passing these tests is not evidence of a PLC connection or firmware acceptance.
"""
from copy import deepcopy
import json
from pathlib import Path
import shutil
import socket
import tempfile
import unittest
from unittest import mock

from plcnext_mcp.download_services import (
    FAULTS, FileSystemError, InMemoryController, PlcState, ServiceFailure,
    WriteFileData, device_state,
)
from plcnext_mcp.download_simulation import BATCH_LIMIT, download_plan, execute_download, file_batches
from plcnext_mcp.deployment_package import MANIFEST, inspect_pcwe
from plcnext_mcp.pcwe_native import make_pcwe_manifest
from plcnext_mcp.project import ProjectError, ProjectStore, sha

ROOT = Path(__file__).resolve().parents[1]
MANAGED = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395')
PACKAGE_ID = '5e4a155de2d8486ba6df5f0a019380a1'
PACKAGE = MANAGED / 'deployments' / PACKAGE_ID
FILES = {'Plc/Eclr/eCLR.img': b'offline test image data; never execute',
         'Plc/Domain/Domain.config': b'<offline-fixture/>', 'project.manifest.xml': b'fixture'}


class DownloadServiceSimulationTests(unittest.TestCase):
    def run_double(self, fault='none', controller=None):
        controller = controller or InMemoryController(fault)
        original_password = controller._password
        with mock.patch.object(socket, 'socket', side_effect=AssertionError('No sockets permitted')):
            with mock.patch.object(socket, 'create_connection', side_effect=AssertionError('No network permitted')):
                result = execute_download(FILES, controller)
        self.assertTrue(controller.session_closed)
        self.assertFalse(controller._authenticated)
        self.assertFalse(controller._enabled)
        self.assertEqual(controller._password, '')
        self.assertIsNone(controller._token)
        self.assertNotIn(original_password, json.dumps(result) + json.dumps(controller.trace))
        self.assertEqual(result['network_operations_performed'], 0)
        self.assertFalse(result['controller_connected'])
        self.assertFalse(result['controller_downloaded'])
        self.assertFalse(result['program_started'])
        self.assertFalse(result['deployable'])
        operations = [entry['operation'] for entry in controller.trace]
        self.assertFalse(any(op.endswith(('Start', 'Change', 'Restart')) for op in operations))
        return result, controller, operations

    def test_full_in_memory_sequence_and_exact_readback(self):
        result, controller, ops = self.run_double()
        self.assertEqual(result['status'], 'simulation_passed')
        self.assertTrue(result['simulated_configuration_loaded'])
        self.assertEqual(controller.snapshot(), FILES)
        self.assertEqual(result['files_verified'], len(FILES))
        self.assertEqual(result['readback_hash'], 'SHA-512')
        # Independent IL evidence: each successful wait delays 100 ms before
        # evaluating the state predicate, even when the initial state matches.
        self.assertEqual(result['virtual_elapsed_ms'], 200)
        ordered = ['IPasswordAuthenticationService.CreateSession', 'CommonRemoting.EnableSecurity',
                   'Simulator.GetOperationPermissions', 'IFileService2.WriteMany',
                   'IFileService2.ReadMany', 'Simulator.ReconcileProjectFiles',
                   'IPlcManagerService.Reset', 'IPlcManagerService.Load', 'Simulator.DisposeSecurityContext']
        self.assertEqual([ops.index(x) for x in ordered], sorted(ops.index(x) for x in ordered))
        for entry in controller.trace:
            if entry['operation'] in ('IPlcManagerService.Reset', 'IPlcManagerService.Load'):
                self.assertIs(entry['async_'], True)

    def test_every_declared_fault_is_fail_closed_and_session_disposed(self):
        no_write = {'bad_credentials', 'penalty_active', 'permission_denied', 'insufficient_space',
                    'initial_running', 'untrusted_peer'}
        for fault in FAULTS:
            if fault == 'none':
                continue
            with self.subTest(fault=fault):
                result, controller, ops = self.run_double(fault)
                self.assertEqual(result['status'], 'simulation_failed')
                self.assertFalse(result['simulated_configuration_loaded'])
                self.assertFalse(controller.loaded)
                if fault not in {'reset_timeout', 'load_timeout', 'load_error'}:
                    self.assertNotIn('IPlcManagerService.Reset', ops)
                    self.assertNotIn('IPlcManagerService.Load', ops)
                if fault == 'reset_timeout':
                    self.assertNotIn('IPlcManagerService.Load', ops)
                if fault in no_write:
                    self.assertNotIn('IFileService2.WriteMany', ops)
                if fault == 'transport_interrupted':
                    self.assertTrue(result['simulated_writes_possible'])
                    self.assertEqual(ops.count('IFileService2.WriteMany'), 1)
                if fault in {'reset_timeout', 'load_timeout'}:
                    # Vendor uses elapsed > 300 seconds, observed at next poll.
                    expected_ms = 300100 + (100 if fault == 'load_timeout' else 0)
                    self.assertEqual(result['virtual_elapsed_ms'], expected_ms)
                    self.assertEqual(result['failure_code'], 'configuration_timeout')

    def test_uint32_zero_token_is_valid_and_not_treated_as_false(self):
        result, _, _ = self.run_double(controller=InMemoryController(token_value=0))
        self.assertEqual(result['status'], 'simulation_passed')
        for token in (-1, 0x100000000, True, '0'):
            with self.subTest(token=token), self.assertRaises(ProjectError):
                InMemoryController(token_value=token)

    def test_unauthenticated_calls_and_wrong_token_are_rejected(self):
        controller = InMemoryController(token_value=0)
        for call in [controller.get_permissions, controller.get_state,
                     lambda: controller.write_many([]), lambda: controller.read_many([]),
                     controller.reset, controller.load]:
            with self.assertRaises(ServiceFailure):
                call()
        user, password = controller.credentials()
        self.assertEqual(controller.create_session(user, password), (0, 0, 0))
        with self.assertRaises(ServiceFailure):
            controller.enable_security(1)
        controller.enable_security(0)
        controller.close()
        with self.assertRaises(ServiceFailure):
            controller.enable_security(0)

    def test_payload_paths_cannot_escape_or_spoof_project_root(self):
        controller = InMemoryController()
        user, password = controller.credentials()
        _, token, _ = controller.create_session(user, password)
        controller.enable_security(token)
        for suffix in ['../outside', 'Plc/../../outside', '/evil', 'Plc\\file', 'Plc//file', 'C:/file']:
            with self.subTest(suffix=suffix), self.assertRaises(ProjectError):
                controller.write_many([WriteFileData(controller.root + '/' + suffix, b'x')])
        for prefix in [controller.root + 'suffix/file', '/another-root/file', controller.root]:
            with self.subTest(prefix=prefix), self.assertRaises(ProjectError):
                controller.read_many([prefix])
        self.assertNotIn('outside', controller.snapshot())
        controller.close()

    def test_file_batches_flush_after_exceeding_8mib_without_splitting_a_file(self):
        exact = b'x' * BATCH_LIMIT
        self.assertEqual(list(file_batches({'a': exact})), [[('a', exact)]])
        batches = list(file_batches({'a': exact, 'b': b'y', 'c': b'z'}))
        self.assertEqual([list(map(lambda item: item[0], b)) for b in batches], [['a', 'b'], ['c']])
        self.assertEqual(sum(len(data) for _, data in batches[0]), BATCH_LIMIT + 1)
        oversized = b'x' * (BATCH_LIMIT + 1)
        self.assertEqual(list(file_batches({'a': oversized, 'b': b'y'})), [[('a', oversized)], [('b', b'y')]])

    def test_write_many_has_one_result_per_file_and_overwrite_behavior(self):
        controller = InMemoryController()
        user, password = controller.credentials()
        _, token, _ = controller.create_session(user, password)
        controller.enable_security(token)
        path = controller.root + '/Plc/test'
        self.assertEqual(controller.write_many([WriteFileData(path, b'first')]), [FileSystemError.NONE])
        self.assertEqual(controller.write_many([WriteFileData(path, b'second', overwrite=False)]), [FileSystemError.ALREADY_EXISTS])
        self.assertEqual(controller.read_many([path]), [(FileSystemError.NONE, b'first')])
        self.assertEqual(controller.read_many([controller.root + '/missing']), [(FileSystemError.NOT_EXIST, b'')])
        controller.close()

    def test_observed_state_and_error_projection(self):
        for raw, expected in ((0, (9, 0)), (63, (9, 0)), (1, (0, 0)), (2, (7, 0)), (3, (3, 0)), (4, (5, 0)),
                              (2 | 0x100, (7, 2)), (1 | 0x40000000, (0, 3)),
                              (2 | 0x80000000, (7, 4)), (3 | 0x80, (3, 1)),
                              (2 | 0x400, (7, 1)), (3 | 0x200, (10, 5)),
                              (3 | 0x800 | 0x200 | 0x80, (11, 6))):
            with self.subTest(raw=raw):
                self.assertEqual(device_state(raw), expected)

    def test_load_allows_suspended_error_but_prioritizes_fatal_before_predicate(self):
        class SuspendedController(InMemoryController):
            def get_state(self):
                if self._phase in ('reset', 'load'):
                    return (0 if self._phase == 'reset' else 7), 2
                return super().get_state()
        result, _, _ = self.run_double(controller=SuspendedController())
        self.assertEqual(result['status'], 'simulation_passed')
        class FatalController(InMemoryController):
            def get_state(self):
                if self._phase == 'load':
                    return 10, 5
                return super().get_state()
        result, _, _ = self.run_double(controller=FatalController())
        self.assertEqual(result['status'], 'simulation_failed')
        self.assertEqual(result['failure_code'], 'controller_state_error')


@unittest.skipUnless((MANAGED / 'revision-0000.pcwex').is_file() and (PACKAGE / 'PCWE').is_dir(),
                     'Current local 61-POU PCWE fixture is unavailable')
class DownloadPackageGuards(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        cls.store = ProjectStore(Path(cls.temp.name) / 'workspace')
        identity = cls.store.import_copy(str(MANAGED / 'revision-0000.pcwex'))
        cls.pid, cls.source_hash = identity['project_id'], identity['project_sha256']
        cls.package = cls.store.root / cls.pid / 'deployments' / PACKAGE_ID
        cls.package.mkdir(parents=True)
        shutil.copytree(PACKAGE / 'PCWE', cls.package / 'PCWE')
        (cls.package / 'runtime-layout').mkdir()
        for filename in ('TypeInformation.json', 'runtime-types-report.json'):
            shutil.copyfile(PACKAGE / 'runtime-layout' / filename, cls.package / 'runtime-layout' / filename)
        cls.receipt = json.loads((PACKAGE / 'result.json').read_bytes())
        build_id = cls.receipt['build_job_id']
        cls.build = cls.store.root / cls.pid / 'builds' / build_id
        cls.build.mkdir(parents=True)
        build = json.loads((MANAGED / 'builds' / build_id / 'result.json').read_bytes())
        build.update(project_id=cls.pid, project_sha256=cls.source_hash)
        (cls.build / 'result.json').write_text(json.dumps(build), encoding='utf8')
        cls.receipt.update(project_id=cls.pid, project_sha256=cls.source_hash,
            pcwe_path=str(cls.package / 'PCWE'), build_receipt_sha256=sha((cls.build / 'result.json').read_bytes()))
        cls.save_receipt()

    @classmethod
    def save_receipt(cls, receipt=None):
        (cls.package / 'result.json').write_text(json.dumps(cls.receipt if receipt is None else receipt), encoding='utf8')

    def tearDown(self):
        self.save_receipt()

    def plan(self, source_hash=None, package_id=PACKAGE_ID):
        return download_plan(self.store, self.pid, source_hash or self.source_hash, package_id)

    def test_current_48_file_copy_has_source_bound_offline_plan(self):
        plan = self.plan()
        self.assertEqual(plan['file_count'], 48)
        self.assertEqual(plan['variable_count'], 77)
        self.assertEqual(plan['fb_instance_count'], 109)
        self.assertEqual(plan['hmi_mapping_count'], 10)
        self.assertFalse(plan['real_transport_available'])
        self.assertFalse(plan['wire_compatibility_verified'])

    def test_stale_source_and_package_path_escape_are_rejected(self):
        with self.assertRaises(ProjectError):
            self.plan('0' * 64)
        for job in ('../outside', '0' * 31, 'A' * 32):
            with self.subTest(job=job), self.assertRaises(ProjectError):
                self.plan(package_id=job)

    def test_receipt_identity_and_pcwe_path_substitution_are_rejected(self):
        for field, value in (('project_id', '0' * 32), ('package_complete', False),
                             ('pcwe_path', str(PACKAGE / 'PCWE')), ('project_sha256', '0' * 64)):
            altered = deepcopy(self.receipt)
            altered[field] = value
            self.save_receipt(altered)
            with self.subTest(field=field), self.assertRaises(ProjectError):
                self.plan()

    def test_tampered_final_types_and_build_receipts_are_rejected(self):
        for path in (self.package / 'runtime-layout/TypeInformation.json', self.build / 'result.json'):
            before = path.read_bytes()
            try:
                path.write_bytes(before + b' ')
                with self.subTest(path=path), self.assertRaises(ProjectError):
                    self.plan()
            finally:
                path.write_bytes(before)

    def test_tampered_packaged_image_is_rejected(self):
        image = self.package / 'PCWE/Plc/Eclr/eCLR.img'
        before = image.read_bytes()
        try:
            image.write_bytes(before + b'offline tamper fixture')
            with self.assertRaises(ProjectError):
                self.plan()
        finally:
            image.write_bytes(before)

    def test_rehashed_packaged_image_is_still_bound_to_original_cold_build(self):
        pcwe = self.package / 'PCWE'
        image = pcwe / 'Plc/Eclr/eCLR.img'
        manifest = pcwe / MANIFEST
        before, before_manifest = image.read_bytes(), manifest.read_bytes()
        try:
            image.write_bytes(before + b'current-package-manifest-cannot-rebind-the-cold-image')
            files = {p.relative_to(pcwe).as_posix(): p.read_bytes() for p in pcwe.rglob('*')
                     if p.is_file() and p != manifest}
            manifest.write_bytes(make_pcwe_manifest(files))
            inspection = inspect_pcwe(pcwe)
            self.assertEqual(inspection['overall_hash_status'], 'verified')
            altered = deepcopy(self.receipt)
            altered['inventory_sha256'] = inspection['inventory_sha256']
            self.save_receipt(altered)
            with self.assertRaises(ProjectError):
                self.plan()
        finally:
            image.write_bytes(before)
            manifest.write_bytes(before_manifest)


if __name__ == '__main__':
    unittest.main()
