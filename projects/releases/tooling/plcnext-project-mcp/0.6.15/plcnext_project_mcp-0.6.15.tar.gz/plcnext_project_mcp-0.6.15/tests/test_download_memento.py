import hashlib
import unittest

from plcnext_mcp.download_memento import download_memento_payloads
from plcnext_mcp.pcwe_native import make_pcwe_manifest
from plcnext_mcp.project import ProjectError, xml


class DownloadMementoTests(unittest.TestCase):
    def test_empty_original_vector_is_included_in_integrity_manifest(self):
        files, report = download_memento_payloads('empty_capability_v1')
        # Original Save/Load oracle: empty dictionary serializes to exactly zero
        # bytes; do not fabricate a populated history for the new program.
        self.assertEqual(files, {'dlc.bin': b''})
        self.assertFalse(report['populated_online_change_history'])
        self.assertFalse(report['controller_acceptance_verified'])
        manifest = xml(make_pcwe_manifest(files))
        item = manifest.find('./Files/File')
        self.assertEqual(item.get('path'), 'dlc.bin')
        self.assertIn(hashlib.sha512(b'').hexdigest().lower(),
                      str(item.attrib).lower())

    def test_omission_is_explicit_and_unknown_policy_rejected(self):
        self.assertEqual(download_memento_payloads('omit')[0], {})
        for policy in ('preserve_any_remote', 'fake_previous_version', None, True):
            with self.assertRaises(ProjectError):
                download_memento_payloads(policy)


if __name__ == '__main__':
    unittest.main()
