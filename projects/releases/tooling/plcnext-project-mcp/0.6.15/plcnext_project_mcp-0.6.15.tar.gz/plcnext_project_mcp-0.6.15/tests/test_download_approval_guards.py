"""PUBLIC temporary operator receipts; never create approval for a real PLC.

The address is RFC 5737 documentation space, socket creation is blocked, and
the source/package snapshot is a bounded test double. These test admission and
one-use semantics; they do not authenticate a human or exercise a real device.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import socket
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

from plcnext_mcp import controller_transfer as transfer
from plcnext_mcp.controller_download_plan import POLICY
from plcnext_mcp.project import sha


class DownloadApprovalGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.pid = 'a' * 32
        (self.root / self.pid).mkdir()
        self.store = SimpleNamespace(root=self.root, _folder=lambda pid: self.root / pid)
        self.files = {'Plc/PUBLIC-inert-fixture.txt': b'PUBLIC approval test data; not executable'}
        self.review = {
            'project_id': self.pid, 'review_id': 'b' * 32,
            'review_sha256': sha(b'PUBLIC test review identity'),
            'source': {'project_sha256': sha(b'PUBLIC test source')},
            'package': {'inventory_sha256': sha(b'PUBLIC test package inventory')},
            'target': {'address': '192.0.2.8', 'port': 41100,
                       'expected_certificate_sha256': 'f' * 64,
                       'certificate_policy': 'explicit_sha256_pin', 'authentication_mode': 'anonymous'},
            'authorization_status': 'awaiting_user_confirmation', 'write_authorized': False,
        }
        self.patch_snapshot = mock.patch.object(transfer, 'review_package_snapshot',
            return_value=(self.review, self.files))
        self.snapshot = self.patch_snapshot.start()
        self.addCleanup(self.patch_snapshot.stop)
        self.patch_socket = mock.patch.object(socket, 'socket', side_effect=AssertionError('No socket in approval tests'))
        self.socket = self.patch_socket.start()
        self.addCleanup(self.patch_socket.stop)
        self.patch_connect = mock.patch.object(socket, 'create_connection', side_effect=AssertionError('No device in approval tests'))
        self.connect = self.patch_connect.start()
        self.addCleanup(self.patch_connect.stop)
        self.actual_lease_root = transfer._endpoint_lease_root
        self.patch_lease_root = mock.patch.object(transfer, '_endpoint_lease_root',
            return_value=self.root / 'PUBLIC-shared-lease-root')
        self.patch_lease_root.start()
        self.addCleanup(self.patch_lease_root.stop)

    def approval(self):
        now = datetime.now(timezone.utc)
        return {
            'schema': transfer.APPROVAL_SCHEMA, 'review_sha256': self.review['review_sha256'],
            'confirmed_by': 'human_user', 'target': deepcopy(self.review['target']),
            'project_sha256': self.review['source']['project_sha256'],
            'inventory_sha256': self.review['package']['inventory_sha256'],
            'policy': dict(POLICY), 'approved_actions': list(transfer.APPROVED_ACTIONS),
            'preserved_unlisted_remote_files_acknowledged': True,
            'confirmation_reference': 'PUBLIC-TEST-NOT-AN-ACTUAL-HUMAN-CONFIRMATION',
            'confirmed_utc': (now - timedelta(minutes=1)).isoformat(),
            'expires_utc': (now + timedelta(minutes=5)).isoformat(),
        }

    def write_approval(self, record):
        directory = self.root / 'controller-download-approvals'
        directory.mkdir(exist_ok=True)
        path = directory / (self.review['review_sha256'] + '.json')
        path.write_text(json.dumps(record), encoding='utf-8')
        return path

    def execute(self):
        # This suite isolates authorization with a synthetic store/package.
        # The outer real-release admission is exercised in test_releases.py.
        return transfer.execute_reviewed_download.__wrapped__(self.store, self.pid,
            self.review['review_id'], self.review['review_sha256'])

    def assert_no_network(self):
        self.socket.assert_not_called()
        self.connect.assert_not_called()

    def test_review_only_has_no_write_authority_and_opens_zero_sockets(self):
        with mock.patch.object(transfer, 'TlsControllerClient') as constructor:
            with self.assertRaisesRegex(transfer.ControllerFailure, 'No separate operator approval'):
                self.execute()
            constructor.assert_not_called()
        self.assert_no_network()
        self.assertFalse((self.root / self.pid / 'controller-transfers').exists())

    def test_a_review_marked_approved_cannot_replace_a_separate_receipt(self):
        self.review.update(authorization_status='approved', write_authorized=True,
                           approval_token='PUBLIC-FAKE-REVIEW-TOKEN')
        with self.assertRaises(transfer.ControllerFailure) as failed:
            self.execute()
        self.assertEqual(failed.exception.code, 'user_confirmation_required')
        self.assert_no_network()

    def test_wrong_target_source_inventory_policy_actions_or_ack_never_reaches_client(self):
        for field, invalid in [
                ('confirmed_by', 'mcp_model'), ('review_sha256', '0' * 64),
                ('project_sha256', '0' * 64), ('inventory_sha256', '0' * 64),
                ('target', {**self.review['target'], 'address': '192.0.2.9'}),
                ('policy', {**POLICY, 'automatic_start': True}),
                ('approved_actions', ['write_package_paths']),
                ('preserved_unlisted_remote_files_acknowledged', False),
                ('confirmation_reference', '')]:
            value = self.approval()
            value[field] = invalid
            self.write_approval(value)
            with self.subTest(field=field), mock.patch.object(transfer, 'TlsControllerClient') as constructor:
                with self.assertRaises(transfer.ControllerFailure):
                    self.execute()
                constructor.assert_not_called()
        self.assert_no_network()

    def test_expired_future_naive_and_overlong_time_windows_fail_before_claim(self):
        now = datetime.now(timezone.utc)
        windows = [
            (now - timedelta(minutes=10), now - timedelta(seconds=1)),
            (now + timedelta(seconds=1), now + timedelta(minutes=10)),
            (now - timedelta(minutes=1), now + timedelta(hours=2)),
            (now.replace(tzinfo=None) - timedelta(minutes=1), now + timedelta(minutes=5)),
        ]
        for confirmed, expires in windows:
            value = self.approval()
            value.update(confirmed_utc=confirmed.isoformat(), expires_utc=expires.isoformat())
            path = self.write_approval(value)
            with self.subTest(confirmed=confirmed), self.assertRaises(transfer.ControllerFailure) as failed:
                self.execute()
            self.assertEqual(failed.exception.code, 'approval_expired')
            self.assertFalse(path.with_suffix('.claimed.json').exists())
        self.assert_no_network()

    def test_valid_public_receipt_is_claimed_once_and_not_a_reusable_review_token(self):
        path = self.write_approval(self.approval())
        raw = path.read_bytes()
        scope = transfer._operator_scope(self.store, self.review, self.files)
        self.assertEqual(scope.kind, 'operator_confirmed')
        scope.validate_files(self.files)
        claim = path.with_suffix('.claimed.json')
        receipt = json.loads(claim.read_bytes())
        self.assertEqual(receipt['approval_sha256'], sha(raw))
        with self.assertRaises(transfer.ControllerFailure) as failed:
            transfer._operator_scope(self.store, self.review, self.files)
        self.assertEqual(failed.exception.code, 'approval_already_consumed')
        self.assert_no_network()

    def test_receipt_changed_after_exclusive_claim_is_rejected_and_claim_is_retained(self):
        path = self.write_approval(self.approval())
        original_open = transfer.os.open
        def changed_claim_open(*args, **kwargs):
            descriptor = original_open(*args, **kwargs)
            value = self.approval()
            value['confirmation_reference'] += '-CHANGED'
            path.write_text(json.dumps(value), encoding='utf-8')
            return descriptor
        with mock.patch.object(transfer.os, 'open', side_effect=changed_claim_open):
            with self.assertRaises(transfer.ControllerFailure) as failed:
                transfer._operator_scope(self.store, self.review, self.files)
        self.assertEqual(failed.exception.code, 'approval_changed')
        self.assertTrue(path.with_suffix('.claimed.json').is_file())
        self.assert_no_network()

    def test_snapshot_validation_failure_prevents_receipt_consumption_and_client_creation(self):
        path = self.write_approval(self.approval())
        self.snapshot.side_effect = ValueError('PUBLIC stale snapshot fixture')
        with mock.patch.object(transfer, 'TlsControllerClient') as constructor:
            with self.assertRaisesRegex(ValueError, 'stale snapshot'):
                self.execute()
            constructor.assert_not_called()
        self.assertFalse(path.with_suffix('.claimed.json').exists())
        self.assert_no_network()

    def test_approval_presence_does_not_bypass_exact_package_scope(self):
        self.write_approval(self.approval())
        scope = transfer._operator_scope(self.store, self.review, self.files)
        with self.assertRaisesRegex(ValueError, 'Package bytes differ'):
            scope.validate_files({next(iter(self.files)): b'PUBLIC altered bytes'})
        self.assert_no_network()

    def test_approval_claim_is_flushed_and_fsynced_before_scope_returns(self):
        path = self.write_approval(self.approval())
        claim = path.with_suffix('.claimed.json')
        original_fsync = transfer.os.fsync
        observed = []
        def verify_then_sync(descriptor):
            # The whole JSON must already be readable when fsync is invoked;
            # returning a capability before this durable intent is forbidden.
            record = json.loads(claim.read_bytes())
            observed.append(record['execution_id'])
            return original_fsync(descriptor)
        with mock.patch.object(transfer.os, 'fsync', side_effect=verify_then_sync):
            scope = transfer._operator_scope(self.store, self.review, self.files,
                                              execution_id='PUBLIC-test-execution')
        self.assertEqual(observed, ['PUBLIC-test-execution'])
        self.assertEqual(scope.kind, 'operator_confirmed')
        self.assert_no_network()

    def test_target_lease_excludes_other_reviews_workspaces_and_certificate_pins(self):
        first = transfer._claim_endpoint_lease(self.review, self.root / 'workspace-a/job')
        other = deepcopy(self.review)
        other['review_sha256'] = sha(b'PUBLIC other reviewed version')
        other['target']['expected_certificate_sha256'] = 'e' * 64
        with self.assertRaises(transfer.ControllerFailure) as failed:
            transfer._claim_endpoint_lease(other, self.root / 'workspace-b/job')
        self.assertEqual(failed.exception.code, 'endpoint_busy_or_quarantined')
        self.assertTrue(first.is_file())
        other['target']['port'] += 1
        separate = transfer._claim_endpoint_lease(other, self.root / 'workspace-b/job')
        self.assertNotEqual(first, separate)
        self.assert_no_network()

    def test_shared_user_profile_lease_root_does_not_follow_per_process_tmp(self):
        profile = self.root / 'PUBLIC-user-profile'
        with mock.patch.object(Path, 'home', return_value=profile):
            with mock.patch.dict(os.environ, {'TMP': str(self.root / 'PUBLIC-tmp-a'),
                                               'TEMP': str(self.root / 'PUBLIC-tmp-a')}):
                first = self.actual_lease_root()
            with mock.patch.dict(os.environ, {'TMP': str(self.root / 'PUBLIC-tmp-b'),
                                               'TEMP': str(self.root / 'PUBLIC-tmp-b')}):
                second = self.actual_lease_root()
        self.assertEqual(first, second)
        self.assertTrue(first.is_relative_to(profile))
        self.assertFalse(first.exists())
        self.assert_no_network()

    def test_uncertain_mutation_keeps_target_quarantined_and_blocks_another_approval(self):
        self.write_approval(self.approval())
        uncertain = {'status': 'transfer_failed', 'stage': 'transferring',
                     'mutation_request_count': 1, 'files_may_have_changed': True,
                     'outcome_unknown': True, 'controller_downloaded': False,
                     'configuration_load_attempted': False, 'load_state_verified': False}
        with mock.patch.object(transfer, 'TlsControllerClient'), \
                mock.patch.object(transfer, 'execute_transfer', return_value=uncertain):
            result = self.execute()
        self.assertTrue(result['endpoint_lease_retained'])
        self.assertTrue(Path(result['endpoint_lease_path']).is_file())
        binding = json.loads(Path(result['journal_path']).read_text().splitlines()[0])
        self.assertEqual(binding['operation'], 'ExecutionBinding')
        self.assertEqual(binding['review_sha256'], self.review['review_sha256'])
        self.review['review_sha256'] = sha(b'PUBLIC second reviewed version after uncertain write')
        path = self.write_approval(self.approval())
        with mock.patch.object(transfer, 'TlsControllerClient') as constructor:
            with self.assertRaises(transfer.ControllerFailure) as failed:
                self.execute()
            constructor.assert_not_called()
        self.assertEqual(failed.exception.code, 'endpoint_busy_or_quarantined')
        self.assertFalse(path.with_suffix('.claimed.json').exists())
        self.assert_no_network()

    def test_report_disk_failure_preserves_completed_load_facts_and_target_quarantine(self):
        self.write_approval(self.approval())
        completed = {'status': 'controller_download_completed', 'stage': 'loaded_stopped',
                     'mutation_request_count': 3, 'files_may_have_changed': True,
                     'outcome_unknown': False, 'controller_downloaded': True,
                     'configuration_load_attempted': True, 'load_state_verified': True}
        original_open = Path.open
        def fail_result_file(path, *args, **kwargs):
            if path.name == 'result.json':
                raise OSError('PUBLIC simulated disk-full result receipt failure')
            return original_open(path, *args, **kwargs)
        with mock.patch.object(transfer, 'TlsControllerClient'), \
                mock.patch.object(transfer, 'execute_transfer', return_value=completed), \
                mock.patch.object(Path, 'open', new=fail_result_file):
            result = self.execute()
        self.assertEqual(result['status'], 'controller_download_completed')
        self.assertTrue(result['controller_downloaded'])
        self.assertTrue(result['load_state_verified'])
        self.assertFalse(result['receipt_persisted'])
        self.assertEqual(result['receipt_error_class'], 'OSError')
        self.assertTrue(result['endpoint_lease_retained'])
        self.assertTrue(Path(result['endpoint_lease_path']).is_file())
        terminal = json.loads(Path(result['journal_path']).read_text().splitlines()[-1])
        self.assertEqual(terminal['operation'], 'ExecutionOutcome')
        self.assertTrue(terminal['controller_downloaded'])
        self.assertFalse(terminal['receipt_persisted'])
        self.assert_no_network()

    def test_prewrite_failure_consumes_approval_but_releases_target_lease(self):
        path = self.write_approval(self.approval())
        failed = {'status': 'transfer_failed', 'stage': 'initial_state',
                  'mutation_request_count': 0, 'files_may_have_changed': False,
                  'outcome_unknown': False, 'controller_downloaded': False,
                  'configuration_load_attempted': False, 'load_state_verified': False}
        with mock.patch.object(transfer, 'TlsControllerClient'), \
                mock.patch.object(transfer, 'execute_transfer', return_value=failed):
            result = self.execute()
        self.assertFalse(result['endpoint_lease_retained'])
        self.assertFalse(Path(result['endpoint_lease_path']).exists())
        self.assertTrue(path.with_suffix('.claimed.json').is_file())
        with self.assertRaises(transfer.ControllerFailure) as repeated:
            self.execute()
        self.assertEqual(repeated.exception.code, 'approval_already_consumed')
        self.assert_no_network()

    def test_initial_binding_journal_failure_is_before_any_client_or_socket(self):
        path = self.write_approval(self.approval())
        def failed_sink(event):
            self.assertEqual(event['operation'], 'ExecutionBinding')
            raise OSError('PUBLIC simulated durable journal failure')
        with mock.patch.object(transfer, '_journal_sink', return_value=failed_sink), \
                mock.patch.object(transfer, 'TlsControllerClient') as constructor:
            with self.assertRaisesRegex(OSError, 'journal failure'):
                self.execute()
            constructor.assert_not_called()
        self.assertTrue(path.with_suffix('.claimed.json').is_file())
        lease_root = self.root / 'PUBLIC-shared-lease-root'
        self.assertEqual(len(list(lease_root.glob('*.json'))), 1)
        self.assert_no_network()

    def test_lease_cleanup_failure_cannot_hide_verified_device_effect_facts(self):
        self.write_approval(self.approval())
        completed = {'status': 'controller_download_completed', 'stage': 'loaded_stopped',
                     'mutation_request_count': 3, 'files_may_have_changed': True,
                     'outcome_unknown': False, 'controller_downloaded': True,
                     'configuration_load_attempted': True, 'load_state_verified': True}
        lease_name = sha((self.review['target']['address'] + ':' +
                          str(self.review['target']['port'])).encode('utf-8')) + '.json'
        original_unlink = Path.unlink
        def fail_lease_removal(path, *args, **kwargs):
            if path.name == lease_name:
                raise OSError('PUBLIC simulated endpoint lease removal failure')
            return original_unlink(path, *args, **kwargs)
        with mock.patch.object(transfer, 'TlsControllerClient'), \
                mock.patch.object(transfer, 'execute_transfer', return_value=completed), \
                mock.patch.object(Path, 'unlink', new=fail_lease_removal):
            result = self.execute()
        self.assertEqual(result['status'], 'controller_download_completed')
        self.assertTrue(result['load_state_verified'])
        self.assertTrue(result['controller_downloaded'])
        self.assertTrue(result['endpoint_lease_retained'])
        self.assertEqual(result['endpoint_lease_cleanup_error_class'], 'OSError')
        self.assertTrue(Path(result['endpoint_lease_path']).is_file())
        terminal = json.loads(Path(result['journal_path']).read_text().splitlines()[-1])
        self.assertEqual(terminal['operation'], 'EndpointLeaseCleanupFailed')
        self.assert_no_network()

    def test_lease_cleanup_failure_cannot_mask_missing_approval(self):
        lease_name = sha((self.review['target']['address'] + ':' +
                          str(self.review['target']['port'])).encode('utf-8')) + '.json'
        original_unlink = Path.unlink
        def fail_lease_removal(path, *args, **kwargs):
            if path.name == lease_name:
                raise OSError('PUBLIC simulated endpoint lease removal failure')
            return original_unlink(path, *args, **kwargs)
        with mock.patch.object(Path, 'unlink', new=fail_lease_removal):
            with self.assertRaises(transfer.ControllerFailure) as failed:
                self.execute()
        self.assertEqual(failed.exception.code, 'user_confirmation_required')
        self.assert_no_network()


if __name__ == '__main__':
    unittest.main()
