"""Actual NativeGateway source-to-auxiliary outputs and fail-closed scope tests."""
import json
from pathlib import Path
import sqlite3
import struct
import unittest
import xml.etree.ElementTree as ET
import zlib

from plcnext_mcp.pcwe_auxiliary import generate_auxiliary_payloads
from plcnext_mcp.project import ProjectError, read_archive

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / 'artifacts/headless-research/cil-frontend/input/RES_23CA7F267545404C9FED5DC977A6399F/Configuration/Projects/PCWE'
REAL_PROJECT = Path('D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex')
STAMP = '2026-10-23T07:48:53.999295Z'


class AuxiliaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        _, cls.frozen, _, _ = read_archive(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex')

    def setUp(self):
        self.members = dict(self.frozen)

    def generate(self, name='NativeGateway', stamp=STAMP):
        return generate_auxiliary_payloads(self.members, name, stamp)

    def replace_setting(self, key, value):
        path = next(name for name in self.members if name.endswith('.ds'))
        root = ET.fromstring(self.members[path])
        node = next(node for node in root.iter() if f"Para[@uID='{key}']/Current" in node.get('xPath', ''))
        node.text = value
        self.members[path] = ET.tostring(root)

    def test_new_xml_and_tic_crc_match_independent_frozen_gui_output(self):
        files, report = self.generate()
        self.assertEqual(len(files), 7)
        for name in ['Services/OpcUA/PCWE.opcua.config', 'Services/OpcUA/Modules/Client/client.module.config',
                     'Io/Arp.Io.PnC/controller.tic', 'Io/Arp.Io.PnC/links.xml', 'Io/Arp.Io.PnC/Tic.crc']:
            self.assertEqual(files[name], (BASELINE / name).read_bytes(), name)
        self.assertEqual(report['opcua_setting_count'], 119)
        self.assertFalse(report['gui_cache_used'])
        self.assertFalse(report['controller_connected'])

    def test_new_sqlite_has_same_schema_and_rows_as_frozen_gui_database(self):
        files, _ = self.generate()
        connection = sqlite3.connect(':memory:')
        self.addCleanup(connection.close)
        connection.deserialize(files['Io/Arp.Io.PnC/ProfinetDiagnosticDatabase.db'])
        baseline = sqlite3.connect('file:' + (BASELINE / 'Io/Arp.Io.PnC/ProfinetDiagnosticDatabase.db').as_posix() + '?mode=ro', uri=True)
        self.addCleanup(baseline.close)
        schema = connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
        self.assertEqual(schema, baseline.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name").fetchall())
        self.assertEqual(len(schema), 12)
        for name, _ in schema:
            self.assertEqual(connection.execute('SELECT * FROM ' + name).fetchall(),
                             baseline.execute('SELECT * FROM ' + name).fetchall(), name)
        self.assertEqual(connection.execute('PRAGMA integrity_check').fetchone(), ('ok',))

    def test_source_node_name_is_actually_used_not_cached(self):
        self.replace_setting('opcuaNodeName', 'offline-nativegateway-validation')
        files, report = self.generate()
        node = ET.fromstring(files['Services/OpcUA/PCWE.opcua.config']).find('{http://www.phoenixcontact.com/schema/opcuaconfig}NodeName')
        self.assertEqual(node.text, 'offline-nativegateway-validation')
        self.assertEqual(report['opcua_node_name'], node.text)

    def test_unknown_service_setting_is_rejected(self):
        self.replace_setting('opcuaFiletransferEnabled', 'True')
        with self.assertRaisesRegex(ProjectError, 'Unsupported NativeGateway hardware/service profile'):
            self.generate()

    def test_new_hardware_member_and_changed_station_are_rejected(self):
        path = next(name for name in self.members if '/PN_Master/' in name and name.endswith('.station'))
        self.members[path] += b'changed'
        with self.assertRaisesRegex(ProjectError, 'Unsupported NativeGateway'):
            self.generate()
        self.members = dict(self.frozen)
        self.members['PROJECT/Hardware/AdditionalDevice.ds'] = b'<DevInstDoc />'
        with self.assertRaisesRegex(ProjectError, 'Unsupported NativeGateway'):
            self.generate()

    def test_changed_hardware_manifest_identity_is_rejected(self):
        root = ET.fromstring(self.members['PROJECT/PROJECT.proj'])
        node = next(n for n in root.iter() if n.get('Include', '').startswith('Hardware'))
        node.set('UnknownDeploymentSetting', 'changed')
        self.members['PROJECT/PROJECT.proj'] = ET.tostring(root)
        with self.assertRaisesRegex(ProjectError, 'Unsupported NativeGateway'):
            self.generate()

    def test_modified_hmi_is_not_claimed_to_be_validated_by_this_module(self):
        path = next(name for name in self.members if name.endswith('Gateway.hmi/Definition.hmipagedef'))
        self.members[path] = b'not a valid HMI page'
        _, report = self.generate()
        self.assertNotIn(path, report['source_members'])
        self.assertTrue(any('do not validate HMI' in text for text in report['limitations']))

    def test_software_manifest_uses_true_name_timestamp_and_observed_epoch_algorithm(self):
        files, _ = self.generate('ExplicitOfflineProject')
        document = json.loads(files['PCWE.software-package-manifest.json'])
        identity = document['identification']
        self.assertEqual(identity['name'], 'ExplicitOfflineProject')
        self.assertEqual(identity['releaseDate'], STAMP)
        self.assertEqual(identity['softwareRevision'], '1792741733999295000')
        self.assertEqual(identity['targetProductCodes'], ['2404267'])
        self.assertEqual(identity['targetFirmwareRevision'], '26.0.0')
        self.assertEqual(document['updateBehavior'], ['KeepsParameters', 'WillDisconnect', 'NeedsPreparation'])

    def test_timestamp_requires_explicit_timezone_and_invalid_name_is_rejected(self):
        with self.assertRaisesRegex(ProjectError, 'UTC offset'):
            self.generate(stamp='2026-10-25T08:00:00')
        with self.assertRaisesRegex(ProjectError, 'project name'):
            self.generate(name='bad\nname')

    def test_tic_checksum_uses_document_then_links_and_excludes_database(self):
        files, _ = self.generate()
        actual = struct.unpack('<II', files['Io/Arp.Io.PnC/Tic.crc'])
        first, second = files['Io/Arp.Io.PnC/controller.tic'], files['Io/Arp.Io.PnC/links.xml']
        self.assertEqual(actual, (1, zlib.crc32(first + second)))
        self.assertEqual(actual[1], 0x853B4AD4)

    @unittest.skipUnless(REAL_PROJECT.is_file(), 'Current 61 POU source copy unavailable')
    def test_real_61_pou_source_produces_new_auxiliary_files(self):
        _, self.members, _, _ = read_archive(REAL_PROJECT)
        files, report = self.generate()
        self.assertEqual(len(files), 7)
        self.assertEqual(len(report['source_members']), 36)
        self.assertEqual(report['tic_crc_hex'], '01000000d44a3b85')


if __name__ == '__main__':
    unittest.main()
