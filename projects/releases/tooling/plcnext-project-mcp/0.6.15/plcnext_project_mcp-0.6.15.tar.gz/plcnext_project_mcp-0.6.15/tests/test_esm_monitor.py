"""M08 system-type profile, source bindings and real local-only RSC reads."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from plcnext_mcp.project import ProjectStore,ProjectError,read_archive
from plcnext_mcp.runtime_monitor import SourceSymbols
from plcnext_mcp.esm_monitor import (prepare_esm_read_plan,load_esm_read_plan,test_esm_read_plan,
    analyze_esm_observation,PROFILE)

ROOT=Path(__file__).resolve().parents[1]
FROZEN=ROOT/'artifacts/runtime-monitor-research/NativeGateway.restore-native-0.5.0.frozen.pcwex'


class EsmMonitorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='esm-read-public-');self.addCleanup(self.tmp.cleanup)
        self.store=ProjectStore(Path(self.tmp.name)/'managed');p=self.store.import_copy(str(FROZEN))
        self.pid,self.sha=p['project_id'],p['project_sha256']

    def test_actual_generated_no_semicolon_structs_and_counter_width(self):
        model=SourceSymbols(read_archive(FROZEN)[1])
        base='ESM_DATA.ESM_INFOS[1].TASK_INFOS[1].'
        self.assertEqual(model.resolve(base+'EXEC_TIME_THRESHOLD_CNT')['wire_type'],'uint32')
        self.assertEqual(model.resolve(base+'NAME')['string_capacity'],80)
        self.assertEqual(model.resolve(base+'INTERVAL')['wire_type'],'int64')
        self.assertEqual(model.resolve(base+'PRIORITY')['wire_type'],'int16')
        for symbol in ['ESM_DATA.ESM_INFOS[3].TASK_INFOS[1].INTERVAL',
                'ESM_DATA.ESM_INFOS[1].TASK_INFOS[17].NAME','ESM_DATA.NoSuchField']:
            with self.assertRaises(ProjectError):model.resolve(symbol)

    def test_exact_plan_without_network_and_invalid_indices(self):
        with patch('socket.create_connection',side_effect=AssertionError('No network')):
            p=prepare_esm_read_plan(self.store,self.pid,self.sha,'127.0.0.1','a'*64,esm_indices=[1],task_indices=[1])
            r=load_esm_read_plan(self.store,self.pid,p['plan_id'],p['plan_sha256'])
        self.assertEqual(r['profile'],PROFILE);self.assertFalse(r['source_modified'])
        self.assertEqual(len(r['system_symbols']),15)
        for kw in [{'esm_indices':[3]},{'task_indices':[0]},{'task_indices':[1,1]},{'esm_indices':[True]}]:
            with self.subTest(kw=kw),self.assertRaises(ProjectError):
                prepare_esm_read_plan(self.store,self.pid,self.sha,'127.0.0.1','a'*64,**kw)

    def test_same_tls_fixed_profile_and_no_performance_pass(self):
        r=test_esm_read_plan(self.store,self.pid,self.sha)
        self.assertTrue(r['test_passed'],r)
        self.assertTrue(r['all_source_task_bindings_observed'])
        self.assertEqual(r['task_rows'][0]['values']['MAX_EXEC_DURATION'],1200)
        self.assertFalse(r['performance_pass']);self.assertIsNone(r['new_work_cpu_microseconds'])
        self.assertFalse(r['profile']['device_export_verified'])
        self.assertTrue(all(not row.get('mutating') for row in r['fixture_trace']))

    def test_missing_export_boot_change_and_wrong_name_are_not_mapping_success(self):
        for fault in ['missing_field','boot_change','wrong_task_name']:
            with self.subTest(fault=fault):
                r=test_esm_read_plan(self.store,self.pid,self.sha,fault=fault)
                self.assertTrue(r['test_passed'],r)
                self.assertFalse(r['all_source_task_bindings_observed'])
                self.assertFalse(r['performance_pass'])

    def test_counter_decrease_and_boot_changes_never_invent_deltas(self):
        p=prepare_esm_read_plan(self.store,self.pid,self.sha,'127.0.0.1','a'*64,esm_indices=[1],task_indices=[1])
        prefix='ESM_DATA.ESM_INFOS[1].TASK_INFOS[1].'
        values={'NAME':'Cyclic100','INTERVAL':20000,'WATCHDOG':500000,'PRIORITY':0,
            'LAST_EXEC_DURATION':100,'MIN_EXEC_DURATION':80,'MAX_EXEC_DURATION':120,
            'LAST_ACTIVATION_DELAY':0,'MIN_ACTIVATION_DELAY':0,'MAX_ACTIVATION_DELAY':0,
            'EXEC_TIME_THRESHOLD':0,'EXEC_TIME_THRESHOLD_CNT':10}
        obs={'status':'monitor_read_completed','consistency':'guarded_window_observation',
            'items':[{'symbol':prefix+k,'value':v,'status':'read'} for k,v in values.items()],
            'guards_after':[{'symbol':'MainInstance.BootId','value':'boot-1','status':'read'}]}
        obs['items'] += [{'symbol':name,'value':value,'status':'read'} for name,value in {
            'ESM_DATA.ESM_COUNT':2,'ESM_DATA.EXCEPTION_COUNT':0,'ESM_DATA.ESM_INFOS[1].TASK_COUNT':1}.items()]
        old=analyze_esm_observation(p,obs)
        current=deepcopy(obs)
        next(x for x in current['items'] if x['symbol'].endswith('THRESHOLD_CNT'))['value']=2
        r=analyze_esm_observation(p,current,previous=old)
        self.assertEqual(r['counter_deltas'][0]['status'],'unknown_reset_or_wrap')
        self.assertIsNone(r['counter_deltas'][0]['delta'])
        current['guards_after'][0]['value']='boot-2';r=analyze_esm_observation(p,current,previous=old)
        self.assertEqual(r['counter_epoch_comparison'],'unknown_boot_config_source_or_window_changed')
        self.assertIsNone(r['counter_deltas'][0]['delta'])


if __name__=='__main__':unittest.main()
