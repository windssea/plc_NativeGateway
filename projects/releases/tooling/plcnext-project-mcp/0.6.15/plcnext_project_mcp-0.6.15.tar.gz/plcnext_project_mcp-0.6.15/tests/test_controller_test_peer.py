"""Real loopback TCP/TLS fixture checks; never contact an external controller."""
from contextlib import contextmanager
import hashlib
from pathlib import Path
import socket
import ssl
import tempfile
import unittest

from plcnext_mcp import rsc_tagged_codec as tagged
from plcnext_mcp.binary_download_tagged import FILE_SERVICE, FS_SERVICE, PASSWORD_SERVICE, PLC_SERVICE
from plcnext_mcp.controller_test_peer import LocalTlsController, REMOTE_ROOT
from plcnext_mcp.rsc_codec import decode_header
from plcnext_mcp.rsc_rpc_codec import encode_connect_request
from plcnext_mcp.rsc_error_codec import receive_error


def exact(channel, count):
    data = bytearray()
    while len(data) < count:
        block = channel.recv(count - len(data))
        if not block:
            raise EOFError('Fixture channel closed.')
        data.extend(block)
    return bytes(data)


class FixtureClient:
    """Small fixture smoke client, not the production download implementation."""
    def __init__(self, peer):
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        raw = socket.create_connection((peer.address, peer.port), timeout=3)
        self.channel = context.wrap_socket(raw, server_hostname='offline-plc.invalid')
        self.channel.settimeout(3)
        assert hashlib.sha256(self.channel.getpeercert(binary_form=True)).hexdigest() == peer.certificate_sha256
        self.channel.sendall(encode_connect_request())
        tagged.decode_connect_confirmation(exact(self.channel, 16))
        self.handles, self.token = {}, None
        for name in (PASSWORD_SERVICE, FILE_SERVICE, FS_SERVICE, PLC_SERVICE):
            self.channel.sendall(tagged.encode_get_service('Arp', name))
            self.handles[name] = tagged.decode_get_service_confirmation(exact(self.channel, 16))

    def close(self):
        self.channel.close()

    def call(self, service, method, schemas, values, returns, *, anonymous=False):
        handle, provider = self.handles[service]
        self.channel.sendall(tagged.encode_request(handle, method, schemas, values,
            provider_handle=provider, token=None if anonymous else self.token))
        raw = exact(self.channel, 16)
        header, token = decode_header(raw, require_checksum=True)
        if header.command_type == 4:
            error = receive_error(self.channel.recv)
            raise RuntimeError('Fixture remote error code ' + str(error['code']))
        assert header.command_type == 3 and token is None
        assert (header.service_handle, header.method_handle, header.service_provider_handle) == (handle, method, provider)
        return tagged.receive_values(self.channel.recv, returns)


@contextmanager
def peer_client(directory, **kwargs):
    with LocalTlsController(Path(directory) / 'device', **kwargs) as peer:
        client = FixtureClient(peer)
        try:
            yield peer, client
        finally:
            client.close()


class ControllerTestPeerTests(unittest.TestCase):
    def test_anonymous_fragmented_tls_files_and_configuration_use_real_directory(self):
        with tempfile.TemporaryDirectory() as directory, peer_client(directory,
                allowed_files={'Plc/a.bin'}, response_fragment_bytes=7) as (peer, client):
            self.assertEqual(peer.address, '127.0.0.1')
            self.assertGreater(peer.port, 0)
            entry, error = client.call(FS_SERVICE, 5, ['int32', 'utf8'],
                [0, '$ARP_PROJECTS_DIR$/PCWE/'], ['filesystem_traits_entry', 'int32'])
            self.assertEqual((error, entry['path']), (0, REMOTE_ROOT))
            data = bytes(range(256)) * 4
            written = client.call(FILE_SERVICE, 8, ['write_file[]'], [[{
                'path': REMOTE_ROOT + '/Plc/a.bin', 'overwrite': True, 'traits': [], 'data': data}]], ['int32[]'])
            self.assertEqual(written, [[0]])
            self.assertEqual((peer.root / 'Plc/a.bin').read_bytes(), data)
            read = client.call(FILE_SERVICE, 9, ['read_file_info[]'], [[{
                'path': REMOTE_ROOT + '/Plc/a.bin', 'traits': 0}]], ['read_file_data[]'])[0]
            self.assertEqual(read[0]['data'], data)
            self.assertEqual(client.call(PLC_SERVICE, 4, ['bool'], [True], []), [])
            self.assertEqual(client.call(PLC_SERVICE, 5, [], [], ['uint32']), [1])
            self.assertEqual(client.call(PLC_SERVICE, 1, ['bool'], [True], []), [])
            self.assertEqual(client.call(PLC_SERVICE, 5, [], [], ['uint32']), [2])
            self.assertTrue(peer.loaded)
            self.assertEqual(peer.snapshot(), {'Plc/a.bin': data})
            self.assertEqual(peer.errors, [])

    def test_public_fixture_password_session_and_no_credential_logging(self):
        with tempfile.TemporaryDirectory() as directory, peer_client(directory,
                anonymous=False, allowed_files={'Plc/auth.txt'}) as (peer, client):
            rejected = client.call(PASSWORD_SERVICE, 1, ['utf8', 'secure_utf8'],
                [peer.username, 'PUBLIC-incorrect-password'], ['security_token', 'int32', 'int32'], anonymous=True)
            self.assertEqual(rejected, [0, 0, -1])
            result = client.call(PASSWORD_SERVICE, 1, ['utf8', 'secure_utf8'],
                [peer.username, peer.password], ['security_token', 'int32', 'int32'], anonymous=True)
            self.assertEqual(result[1:], [0, 0])
            client.token = result[0]
            self.assertEqual(client.call(PLC_SERVICE, 5, [], [], ['uint32']), [2])
            self.assertEqual(client.call(PASSWORD_SERVICE, 2, ['security_token'], [client.token], [], anonymous=True), [])
            self.assertNotIn(peer.password, repr(peer.trace))
            self.assertNotIn(str(client.token), repr(peer.trace))

    def test_write_reply_lost_has_file_side_effect_and_no_load(self):
        with tempfile.TemporaryDirectory() as directory, peer_client(directory,
                fault='write_reply_lost', allowed_files={'Plc/a.bin'}) as (peer, client):
            with self.assertRaises((EOFError, OSError)):
                client.call(FILE_SERVICE, 8, ['write_file[]'], [[{
                    'path': REMOTE_ROOT + '/Plc/a.bin', 'overwrite': True, 'traits': [], 'data': b'written-before-reply'}]], ['int32[]'])
            self.assertEqual(peer.snapshot(), {'Plc/a.bin': b'written-before-reply'})
            self.assertFalse(peer.loaded)
            self.assertEqual(peer.load_calls, 0)
            self.assertEqual(peer.errors, [])

    def test_inventory_and_traversal_paths_cannot_write_outside_fixture(self):
        with tempfile.TemporaryDirectory() as directory, peer_client(directory,
                allowed_files={'Plc/a.bin'}) as (peer, client):
            for path, error in [(REMOTE_ROOT + '/../escape.bin', 2),
                                (REMOTE_ROOT + '/Plc/not-approved.bin', 5),
                                ('/not-the-project/a.bin', 2)]:
                with self.subTest(path=path):
                    result = client.call(FILE_SERVICE, 8, ['write_file[]'], [[{
                        'path': path, 'overwrite': True, 'traits': [], 'data': b'no'}]], ['int32[]'])
                    self.assertEqual(result, [[error]])
            self.assertEqual(peer.snapshot(), {})
            self.assertEqual(list(Path(directory).glob('escape.bin')), [])

    def test_load_error_and_running_stop_are_explicit_fixture_states(self):
        with tempfile.TemporaryDirectory() as directory, peer_client(directory,
                fault='load_error', initial_state=3) as (peer, client):
            self.assertEqual(client.call(PLC_SERVICE, 5, [], [], ['uint32']), [3])
            self.assertEqual(client.call(PLC_SERVICE, 3, ['bool'], [True], []), [])
            self.assertEqual(client.call(PLC_SERVICE, 5, [], [], ['uint32']), [2])
            client.call(PLC_SERVICE, 1, ['bool'], [True], [])
            self.assertEqual(client.call(PLC_SERVICE, 5, [], [], ['uint32']), [130])
            self.assertFalse(peer.loaded)
            self.assertEqual(peer.stop_calls, 1)

    def test_large_binary_stream_crosses_real_tcp_tls_records(self):
        content = bytes(range(256)) * (8192 + 1)
        with tempfile.TemporaryDirectory() as directory, peer_client(directory,
                allowed_files={'Plc/large.bin'}) as (peer, client):
            self.assertEqual(client.call(FILE_SERVICE, 8, ['write_file[]'], [[{
                'path': REMOTE_ROOT + '/Plc/large.bin', 'overwrite': True, 'traits': [], 'data': content}]], ['int32[]']), [[0]])
            actual = client.call(FILE_SERVICE, 9, ['read_file_info[]'], [[{
                'path': REMOTE_ROOT + '/Plc/large.bin', 'traits': 0}]], ['read_file_data[]'])[0][0]['data']
            self.assertEqual(hashlib.sha512(actual).digest(), hashlib.sha512(content).digest())
            self.assertEqual(peer.snapshot()['Plc/large.bin'], content)

    def test_confirmed_error_framing_and_auth_denial_leave_files_untouched(self):
        for fault in ('rpc_error', 'fatal_error'):
            with self.subTest(fault=fault), tempfile.TemporaryDirectory() as directory, \
                    peer_client(directory, fault=fault) as (peer, client):
                with self.assertRaisesRegex(RuntimeError, 'remote error code'):
                    client.call(FS_SERVICE, 6, ['utf8'], [REMOTE_ROOT], ['space_info', 'int32'])
                self.assertEqual(peer.snapshot(), {})
                self.assertEqual(peer.write_calls, 0)
                # Error parser consumes exactly its frame, including fatal no-FF.
                self.assertEqual(client.call(PLC_SERVICE, 5, [], [], ['uint32']), [2])
        with tempfile.TemporaryDirectory() as directory, peer_client(directory,
                anonymous=False) as (peer, client):
            with self.assertRaisesRegex(RuntimeError, 'remote error code'):
                client.call(PLC_SERVICE, 5, [], [], ['uint32'])
            self.assertEqual(peer.snapshot(), {})

    def test_existing_nonempty_root_is_rejected_without_overwriting_and_thread_closes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / 'existing'
            root.mkdir()
            (root / 'preserve.txt').write_bytes(b'untouched')
            with self.assertRaisesRegex(ValueError, 'new or empty'):
                LocalTlsController(root)
            self.assertEqual((root / 'preserve.txt').read_bytes(), b'untouched')
            peer = LocalTlsController(Path(directory) / 'new').start()
            peer.close()
            self.assertFalse(peer._thread.is_alive())
            with self.assertRaises(TypeError):
                LocalTlsController(Path(directory) / 'other', address='192.168.0.8')


if __name__ == '__main__':
    unittest.main()
