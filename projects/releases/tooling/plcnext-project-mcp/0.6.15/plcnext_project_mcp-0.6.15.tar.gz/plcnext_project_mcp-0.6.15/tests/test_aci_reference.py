"""Contract checks for the optional example; no Engineer or sockets are used."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import types
import unittest
from unittest.mock import patch

PATH = Path(__file__).resolve().parents[1] / 'examples/aci_mcp/reference_server.py'
SPEC = importlib.util.spec_from_file_location('aci_reference_example', PATH)
reference = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reference)


class AciReferenceTests(unittest.TestCase):
    def test_disabled_does_not_start_helper_or_copy_files(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(reference.subprocess, 'run') as run:
            with self.assertRaisesRegex(ValueError, 'disabled'):
                reference.run_offline_roundtrip('does-not-exist.pcwex')
            run.assert_not_called()

    def test_catalog_is_static_and_resolves_download_enum(self):
        result = reference.aci_api_catalog('Ade.ApplicationControl.Iec.DownloadTypes')
        self.assertTrue(result['static_only'])
        self.assertEqual(result['types'][0]['values'],
                         {'None': 0, 'Full': 1, 'OnlyChanges': 2, 'IncludeSources': 4})
        self.assertEqual(len(result['assembly_sha256']), 64)
        task = reference.aci_api_catalog('Ade.ApplicationControl.Iec.ITask')['types'][0]
        unsupported = [method for method in task['methods'] if method.get('server_implementation')]
        self.assertEqual(len(unsupported), 5)
        self.assertTrue(all(method['server_implementation']['status'] == 'unsupported_in_analyzed_build'
                            for method in unsupported))

    def test_copy_success_and_unknown_outcomes(self):
        for outcome in ('success', 'failed', 'timeout', 'missing'):
            with self.subTest(outcome=outcome), tempfile.TemporaryDirectory() as directory:
                base = Path(directory)
                source = base / 'original.pcwex'
                source.write_bytes(b'original snapshot')
                imported = base / 'fb.xml'
                imported.write_bytes(b'<project/>')
                environment = {'PLCNEXT_ACI_REFERENCE_ENABLE': '1',
                               'PLCNEXT_ACI_REFERENCE_PID': '123456789',
                               'PLCNEXT_ACI_REFERENCE_WORKSPACE': str(base / 'jobs')}
                def fake_helper(args, **kwargs):
                    job = Path(args[-1]).parent
                    self.assertEqual(args[0], 'pwsh')
                    self.assertFalse(kwargs.get('shell', False))
                    self.assertEqual((job / 'project-copy.pcwex').read_bytes(), b'original snapshot')
                    self.assertEqual((job / 'import.xml').read_bytes(), b'<project/>')
                    request = json.loads((job / 'request.json').read_text())
                    self.assertEqual(request['pid'], 123456789)
                    if outcome == 'timeout':
                        raise subprocess.TimeoutExpired(args, kwargs['timeout'])
                    if outcome != 'missing':
                        (job / 'result.json').write_text(json.dumps({
                            'status': 'completed' if outcome == 'success' else 'failed_or_indeterminate'
                        }))
                    return types.SimpleNamespace(returncode=0 if outcome == 'success' else 1)
                with patch.dict(os.environ, environment, clear=True), \
                     patch.object(reference.tempfile, 'gettempdir', return_value=str(base)), \
                     patch.object(reference.subprocess, 'run', side_effect=fake_helper) as run:
                    result = reference.run_offline_roundtrip(str(source), str(imported), 10)
                    self.assertEqual(source.read_bytes(), b'original snapshot')
                    self.assertEqual(imported.read_bytes(), b'<project/>')
                    lease = base / 'plcnext-aci-reference-leases/123456789.lock'
                    self.assertEqual(lease.exists(), outcome != 'success')
                    self.assertEqual(run.call_count, 1)
                    self.assertEqual(result['status'], 'completed' if outcome == 'success' else
                                     'failed_or_indeterminate' if outcome == 'failed' else 'outcome_unknown')
                    if outcome != 'success':
                        with self.assertRaisesRegex(ValueError, 'leased'):
                            reference.run_offline_roundtrip(str(source), timeout_seconds=10)
                        self.assertEqual(run.call_count, 1)

    def test_missing_pid_and_invalid_inputs_never_start_helper(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(reference.subprocess, 'run') as run:
            source = Path(directory) / 'original.txt'
            source.write_text('sample')
            with patch.dict(os.environ, {'PLCNEXT_ACI_REFERENCE_ENABLE': '1'}, clear=True):
                with self.assertRaisesRegex(ValueError, 'PID'):
                    reference.run_offline_roundtrip(str(source))
            with patch.dict(os.environ, {'PLCNEXT_ACI_REFERENCE_ENABLE': '1',
                                         'PLCNEXT_ACI_REFERENCE_PID': '3'}, clear=True):
                with self.assertRaisesRegex(ValueError, 'PCWEX'):
                    reference.run_offline_roundtrip(str(source))
            run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
