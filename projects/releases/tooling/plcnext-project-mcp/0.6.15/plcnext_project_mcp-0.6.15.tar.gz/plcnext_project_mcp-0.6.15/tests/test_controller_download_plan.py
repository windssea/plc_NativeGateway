"""Review identity, approval separation and stale-byte rejection; no device I/O."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import tempfile
import unittest
from unittest import mock

from plcnext_mcp import controller_download_plan as review
from plcnext_mcp.project import ProjectError, ProjectStore, sha

ROOT = Path(__file__).resolve().parents[1]
PIN = 'ab' * 32
ADDRESS = '192.168.0.8'
PACKAGE_ID = 'e' * 32


class ControllerDownloadReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = ProjectStore(Path(self.temp.name) / 'workspace')
        self.identity = self.store.import_copy(str(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'))
        self.pid = self.identity['project_id']
        self.project_hash = self.identity['project_sha256']
        self.files = {'Plc/Eclr/eCLR.img': b'PUBLIC inert test image, never executable',
                      'PCWE.software-package-manifest.json': json.dumps({'identification': {
                          'name': 'NativeGateway-review-fixture', 'softwareRevision': 'fixture-v1',
                          'releaseDate': '2026-10-26T00:00:00Z', 'targetProductCodes': ['2404267'],
                          'targetFirmwareRevision': '26.0.0'}}).encode('utf-8')}
        self.receipt = {'build_job_id': 'd' * 32, 'build_receipt_sha256': '1' * 64,
                        'pou_count': 31}
        self.package_patch = mock.patch.object(review, '_package_snapshot', side_effect=self.snapshot)
        self.snapshot_mock = self.package_patch.start()
        self.addCleanup(self.package_patch.stop)
        for target in [(socket, 'socket'), (socket, 'create_connection'), (subprocess, 'run')]:
            patch = mock.patch.object(*target, side_effect=AssertionError('Network/vendor execution forbidden'))
            patch.start()
            self.addCleanup(patch.stop)

    def snapshot(self, store, project_id, expected, package_id):
        folder, manifest, _, _, _ = store._current(project_id)
        if expected != manifest['current_sha256']:
            raise ProjectError('Stale project fixture hash.')
        if package_id != PACKAGE_ID:
            raise ProjectError('Unknown package fixture ID.')
        return (folder, manifest, folder / 'deployments' / package_id, b'PUBLIC package receipt',
                self.receipt, {'inventory_sha256': '2' * 64},
                {'variable_count': 77, 'fb_instance_count': 109, 'hmi_mapping_count': 10}, deepcopy(self.files))

    def prepare(self):
        return review.prepare_download_review(self.store, self.pid, self.project_hash,
                                               PACKAGE_ID, ADDRESS, PIN)

    def overwrite_record(self, plan, **updates):
        path = Path(plan['review_path'])
        value = json.loads(path.read_bytes())
        value.update(updates)
        value['review_sha256'] = review._digest(value)
        path.write_text(json.dumps(value), encoding='utf-8')
        return value

    def test_exact_version_files_impact_and_no_self_authorization(self):
        plan = self.prepare()
        self.assertEqual(plan['authorization_status'], 'awaiting_mcp_authorization')
        self.assertFalse(plan['write_authorized'])
        self.assertNotIn('approval_token', plan)
        self.assertEqual(plan['source']['project_sha256'], self.project_hash)
        self.assertEqual(plan['source']['project_name'], 'NativeGateway-review-fixture')
        self.assertEqual(plan['source']['software_revision'], 'fixture-v1')
        self.assertEqual(plan['package']['image_sha256'], sha(self.files['Plc/Eclr/eCLR.img']))
        self.assertEqual(plan['package']['total_bytes'], sum(map(len, self.files.values())))
        self.assertEqual(plan['policy']['file_readback_algorithm'], 'SHA-512')
        self.assertTrue(plan['policy']['initial_stop_required'])
        self.assertFalse(plan['policy']['automatic_stop'])
        self.assertFalse(plan['policy']['automatic_start'])
        self.assertFalse(plan['policy']['delete_old_files'])
        self.assertTrue(plan['policy']['require_remote_inventory_review'])
        self.assertIn('remote_inventory_and_old_file_handling_not_verified', plan['execution_blockers'])
        for entry in plan['files']:
            expected = self.files[entry['path']]
            self.assertEqual(entry['sha256'], sha(expected))
            self.assertEqual(entry['sha512'], hashlib.sha512(expected).hexdigest())
        loaded = review.load_download_review(self.store, self.pid, plan['review_id'])
        self.assertFalse(loaded['revalidated_against_current_package'])
        checked, payload = review.review_package_snapshot(self.store, self.pid,
            plan['review_id'], plan['review_sha256'])
        self.assertEqual(payload, self.files)
        self.assertTrue(checked['revalidated_against_current_package'])
        self.assertFalse(checked['write_authorized'])
        self.assertEqual(checked['authorization_status'], 'awaiting_mcp_authorization')

    def test_invalid_input_rejected_before_snapshot_or_artifact_creation(self):
        base = [self.store, self.pid, self.project_hash, PACKAGE_ID, ADDRESS, PIN, 41100]
        for position, invalid in [(2, 'bad'), (4, True), (4, 'https://192.168.0.8'),
                                  (5, ''), (5, 'g' * 64), (6, True), (6, 65536)]:
            args = list(base)
            args[position] = invalid
            with self.subTest(position=position), self.assertRaises(ProjectError):
                review.prepare_download_review(*args)
        self.snapshot_mock.assert_not_called()
        self.assertFalse((self.store.root / self.pid / 'controller-download-reviews').exists())

    def test_tampered_or_retargeted_review_cannot_match_selected_hash(self):
        plan = self.prepare()
        changed = deepcopy(plan['target'])
        changed['address'] = '192.168.0.9'
        self.overwrite_record(plan, target=changed)
        with self.assertRaisesRegex(ProjectError, 'hash has changed'):
            review.revalidate_download_review(self.store, self.pid, plan['review_id'], plan['review_sha256'])
        # Even a recomputed self-hash cannot convert a review into permission.
        self.overwrite_record(plan, authorization_status='approved', write_authorized=True)
        with self.assertRaisesRegex(ProjectError, 'cannot authorize'):
            review.load_download_review(self.store, self.pid, plan['review_id'])
        self.overwrite_record(plan, authorization_status='awaiting_user_confirmation', write_authorized=False,
                              impact={'existing_program_execution_interrupted': False})
        with self.assertRaisesRegex(ProjectError, 'policy'):
            review.load_download_review(self.store, self.pid, plan['review_id'])

    def test_policy_hash_corruption_paths_duplicates_and_size_fail_closed(self):
        plan = self.prepare()
        original = Path(plan['review_path']).read_bytes()
        path = Path(plan['review_path'])
        altered = json.loads(original)
        altered['policy']['automatic_stop'] = True
        altered['review_sha256'] = review._digest(altered)
        path.write_text(json.dumps(altered), encoding='utf-8')
        with self.assertRaisesRegex(ProjectError, 'policy'):
            review.load_download_review(self.store, self.pid, plan['review_id'])
        path.write_bytes(original.replace(b'fixture-v1', b'fixture-v2'))
        with self.assertRaisesRegex(ProjectError, 'hash mismatch'):
            review.load_download_review(self.store, self.pid, plan['review_id'])
        path.write_bytes(b'{"schema":"a","schema":"b"}')
        with self.assertRaises(ProjectError):
            review.load_download_review(self.store, self.pid, plan['review_id'])
        path.write_bytes(b' ' * (review.MAX_REVIEW_BYTES + 1))
        with self.assertRaisesRegex(ProjectError, 'oversized'):
            review.load_download_review(self.store, self.pid, plan['review_id'])
        for invalid in ('../outside', 'A' * 32, ''):
            with self.subTest(invalid=invalid), self.assertRaises(ProjectError):
                review.load_download_review(self.store, self.pid, invalid)

    def test_changed_current_source_or_package_bytes_need_a_new_review(self):
        plan = self.prepare()
        self.files['Plc/Eclr/eCLR.img'] += b'changed after review'
        with self.assertRaisesRegex(ProjectError, 'bytes have changed'):
            review.revalidate_download_review(self.store, self.pid, plan['review_id'], plan['review_sha256'])
        pou = self.store.read_pou(self.pid, 'NG_ReadAck')
        self.store.patch_st(self.pid, 'NG_ReadAck', self.project_hash, pou['code_sha256'],
                            pou['code'], pou['code'] + '\n(* stale review test *)\n')
        with self.assertRaisesRegex(ProjectError, 'Stale'):
            review.revalidate_download_review(self.store, self.pid, plan['review_id'], plan['review_sha256'])

    def test_saved_running_state_is_context_only_and_target_bound(self):
        directory = self.store.root / 'controller-reads' / ('a' * 32)
        directory.mkdir(parents=True)
        observation = {'status': 'state_read', 'state_read': True, 'address': ADDRESS, 'port': 41100,
            'peer_certificate_sha256': PIN, 'certificate_pin_verified': True,
            'observed_utc': '2026-10-26T01:00:00+00:00', 'plc_base_state': 'Running', 'plc_state_raw': 3}
        (directory / 'result.json').write_text(json.dumps(observation), encoding='utf-8')
        plan = self.prepare()
        history = plan['historical_observation']
        self.assertEqual(history['last_matching_saved_read']['plc_base_state'], 'Running')
        self.assertFalse(history['fresh_read_performed'])
        self.assertFalse(history['used_to_authorize_writes'])
        self.assertTrue(plan['policy']['initial_stop_required'])
        observation['peer_certificate_sha256'] = '0' * 64
        (directory / 'result.json').write_text(json.dumps(observation), encoding='utf-8')
        self.assertIsNone(self.prepare()['historical_observation']['last_matching_saved_read'])


if __name__ == '__main__':
    unittest.main()
