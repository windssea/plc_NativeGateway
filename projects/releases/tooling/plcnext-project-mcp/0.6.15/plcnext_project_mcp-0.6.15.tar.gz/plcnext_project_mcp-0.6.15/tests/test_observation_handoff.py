import json
from pathlib import Path
from unittest.mock import patch
import unittest
from plcnext_mcp.startup_observation import classify
from plcnext_mcp.controller_transport import ControllerFailure
from plcnext_mcp.project import ProjectError
from plcnext_mcp.observation_reconciliation import observe_current

ROOT=Path(__file__).resolve().parents[1]/'docs/evidence/lease-observation-20261027'
class StartupTests(unittest.TestCase):
    def test_frozen_initialization_window_discard_then_ready(self):
        data=json.loads((ROOT/'failed-read-window.json').read_text(encoding='utf-8'))
        o=data.get('result',data)
        expected={'version':13,'device_count':50,'point_count':250,'enabled':True}
        retry,boot=classify(o,expected,None);self.assertTrue(retry);self.assertIsNone(boot)
        ready=json.loads((ROOT/'stable-after-engineer-read.json').read_text(encoding='utf-8'))['result']
        retry,boot=classify(ready,expected,None);self.assertFalse(retry);self.assertTrue(boot)
        with self.assertRaises(ControllerFailure):classify(ready,expected,'different-boot')
        with self.assertRaises(ControllerFailure):classify(o,expected,'established')
    def test_handoff_requires_exact_boot_digest_and_fresh_good(self):
        o=json.loads((ROOT/'stable-after-engineer-read.json').read_text(encoding='utf-8'))['result']
        boot=next(r['value'] for r in o['guards_after'] if r['symbol'].endswith('.BootId'))
        c={'project_id':o['project_id'],'plan_id':o['plan_id'],'plan_sha256':o['plan_sha256'],
            'project_sha256':o['source_project_sha256'],'expected_boot_id':boot,
            'expected_configuration':{'version':15,'device_count':50,'point_count':250,'enabled':True},
            'expected_configuration_sha256':o['configuration_digest']['sha256']}
        with patch('plcnext_mcp.observation_reconciliation.read_runtime_plan',return_value=o):
            result=observe_current(None,c);self.assertEqual(result['current_boot_id'],boot)
            for key,value in [('expected_boot_id','wrong'),('expected_configuration_sha256','0'*64)]:
                with self.assertRaises(ProjectError):observe_current(None,c|{key:value})

    def test_frozen_original_bytes_match_manifest_and_refusal_remains(self):
        import hashlib
        manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
        for item in manifest['files']:
            self.assertEqual(hashlib.sha256((ROOT/item['file']).read_bytes()).hexdigest(),item['sha256'])
        self.assertIn('Only known completed recovery',(ROOT/'reconciliation-refusal.json').read_text(encoding='utf-8'))
