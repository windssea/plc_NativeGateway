# PLCnext Engineer MCP 可行性调查

**2026-10-23 更新：本机 ACI 已实际通过已有 FB 的导出、修改、导入、三次全量编译与实例/变量映射保留验证。见 [实测记录](aci-poc.md)。下文为先前静态调查，已验证事项以实测记录为准。**

调查日期：2026-10-23。目标：让 AI 快速修改工程、编译、更新 PLC，并分析运行状态，减少依赖 computer use。

## 结论

可以开发。优先方案是封装 PLCnext Engineer 已有的 Application Control Interface（ACI），并为 PLC 运行时增加独立的数据与诊断适配器。工程开发通常仍需要已安装且具备对应授权的 Engineer 后端，但可以通过接口操作，无需逐步操作界面。监控和诊断可以按目标设备能力，通过 OPC UA、REST 或 PLC 本地 gRPC agent 独立实现。

这是有官方文档和本机程序集依据的可行性结论，尚不是已经实现或通过真机验证的 MCP 产品。

## 已核实的本机环境

- 安装产品：PLCnext Engineer 2026.0.4；Windows 安装登记和文件版本为 9.0.373.0。
- 安装目录：`D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0`。
- 启动入口：`PLCNENG64.exe`。
- runtimeconfig 指定 .NET 8 和 Windows Desktop 8。
- 包内包含 `Ade.ApplicationControl.dll`、`Ade.ApplicationControl.ClientImpl.dll`、`Ade.ApplicationControl.Communication.dll`、`Ade.ApplicationControl.ServerImpl.dll`。
- 包内存在 ACI 试用许可文件；这只能证明安装包附带该文件，不能证明本机已激活或有可用试用期。
- 根目录未按 MCP、assistant、semantic、openai 文件名匹配到组件；这个有限文件名检索不能排除其他命名或嵌入式实现。

本轮仅读取安装文件、静态解析程序集和查阅官方资料。没有启动 Engineer、启用 ACI、读取认证 cookie、连接 PLC、下载程序或写变量。

## 官方资料与最新动态

1. [Engineer 安全指南](https://engineer.plcnext.help/latest/SecurityGuidelines.htm) 明确说明 ACI 可供外部应用控制 Engineer，并支持无界面运行。启用/停用需要以管理员身份启动 Engineer，且无工程打开；通信使用受 Windows DPAPI 保护并绑定用户的 cookie。该页对能力的总体描述不能替代每个具体 API 的实测。
2. [官方产品页](https://www.phoenixcontact.com/en-nl/products/programming-software-plcnext-engineer-1046008) 将 PLCnext ENG ACI 列为可选扩展；不能把基础版免费理解为 ACI 无需授权。
3. [2026-10-20 官方 AI 公告](https://www.plcnext-community.net/news/ai-integration-in-plcnext-engineer/) 明确采用专用 MCP servers，为工程结构、选中代码和知识库提供上下文，并介绍 ST、变量、数据类型、FB 和状态机生成、代码分析及编译结果反馈。文中没有给出对外 MCP endpoint、可下载 SDK、兼容版本及第三方客户端连接方法，不能据此认定当前安装版可直接接入 Codex。
4. [官方导入导出菜单说明](https://engineer.plcnext.help/latest/File_Menu.htm) 记录 PLCopen XML、IEC 61131-10、AutomationML 等交换能力。实际导入替换语义和工程完整性约束需要样例工程验证。
5. [官方 PLCnext CLI 源码](https://github.com/PLCnext/PLCnext_CLI) 说明其高层语言/C++工具链用途，包括 SDK、CMake、元数据及 Engineer 库生成；没有证据表明它能直接替代 Engineer 编译整个 IEC/ST 工程。
6. [官方 gRPC 仓库](https://github.com/PLCnext/gRPC) 提供 PLC 运行时部分 RSC 服务的 protobuf 和例程。明确可用的基线是 PLC 本地 Unix socket；是否支持外部直接远程连接必须按具体固件确认。
7. [Phoenix Contact REST 激活说明](https://www.phoenixcontact.com/en-us/us-lp-us-plcnextedgegateway/us-lp-us-plcnextedgegateway-drivers/us-lp-us-plcnextedgegateway-plcnextapi) 说明 2022 及以后的工程需启用 REST Interface 并下载相应工程配置；不能假定任意现有 PLC 已开启 REST。
8. [官方运行时服务目录](https://www.plcnext-community.net/infocenter_topics/communication_interfaces/remote_service_calls_rsc/) 与 [OPC UA 文档目录](https://www.plcnext-community.net/infocenter_topics/communication_interfaces/opc_ua/page/2/) 可用来进一步核对目标固件的数据和诊断能力。

## 本机静态证据

下列都是程序集中的类型和方法声明、引用或代理实现观察；不代表已执行成功。

| 目标 | 观察 | REA Evidence |
|---|---|---|
| Ade.ApplicationControl.dll | 98 个类型、269 个 MethodDef；元数据完整，成员解析总体覆盖 partial | `ev_3d5a4ee9d2cfdc61753472813989edd7c7dd8f10a180df8b97adad5d5529311c` |
| IApplication | OpenProject、NewProject、BuildPath、ProjectOpened | 同上 |
| IProject | Save、SaveAs、Compile、CompileFinished、ImportProgramOrganizationUnits、ImportDataTypeWorksheets、ImportAutomationML、ExportAutomationML、ImportIec61131_10、ExportIec61131_10 | 同上 |
| IOnlineChannel | Connect、Disconnect、Download、DownloadFinished、Start、Stop、GetControllerState、ReadVariable、WriteVariable、GetDeviceInfoAttribute、GetDeviceStatusAttribute | 同上 |
| IIecControllerPart / IVariable | 在线通道、任务、变量及变量类型、初值等属性 | 同上 |
| ClientImpl 程序集 | .NET 8；引用 Grpc.Net.Client、Grpc.Core.Api、Google.Protobuf、System.Security.Cryptography 等 | `ev_98d8889feedd449bd8303ad4e608b99bf338e57e39f5c1e39f4085da31309de4` |
| ClientImpl 成员 | Grpc 命名空间下的 ApplicationProxy、ProjectProxy、OnlineChannelProxy、AttachToLocalServerClient、StartServerClient、ClientBase.Run 等 | `ev_b14be58071ce0d6c374e0a31f3e72a7f2ea141bbcbc06719742973ade5fa8e38` |
| AutomationShell 程序集 | 托管 .NET 8，引用 Online/PlcNext/Project 等组件；仅作初始路由参考 | `ev_babdcf89d71123f062fb696da744d3bcdd20ae60e86fa50881c1929728b781c6` |

关键程序集哈希：

- `Ade.ApplicationControl.dll` SHA-256：`80f3e5df6dcc8ffc22c0cf0a566c2693b1b59037bb62e29ab8ec1ec31fb7fc11`；MVID：`f252f828-6184-4a72-9e22-d6f25af03846`。
- `Ade.ApplicationControl.ClientImpl.dll` SHA-256：`f0191c438eb6a48a31a1dc3d62859e382e87f9577395176cc447d752e01ecf42`。

部分泛型、事件和导入方法签名在 REA 中返回 unsupported，不能把它们当成已经恢复的完整 C# 签名。原始 token 仅对上述哈希和 MVID 对应构建有效。选取的证据摘录保存在 [local-aci.json](evidence/local-aci.json)，它不是完整 REA 导出包。

ACI 的 gRPC 是 PC 上 Engineer 的控制通信；PLC runtime 的 gRPC 是设备上的 RSC 接口。它们是不同服务，协议和认证不能混用。本机代理类型、实现方法及引用共同支持当前版本使用 gRPC 的判断，但未验证地址、认证握手、服务生命周期或连接成功率。旧版基于其他通信栈的示例不应直接套用。

## 建议架构（设计建议）

```mermaid
flowchart LR
    AI[AI 客户端] --> MCP[PLCnext MCP]
    MCP --> ENG[Windows 工程适配器]
    ENG --> ACI[Engineer ACI]
    ACI --> PROJ[工程编辑与编译]
    ACI --> PLC[PLC]
    MCP --> RT[运行时诊断适配器]
    RT --> UA[OPC UA / REST]
    RT --> AGENT[PLC 本地 gRPC agent]
    UA --> PLC
    AGENT --> PLC
```

工程适配器优先使用当前版本厂商 SDK/客户端程序集，通过自己的 C# 适配层提供稳定 JSON 输出。MCP 可以同进程托管，也可以通过本地进程协议调用适配层。无需把厂商二进制复制进开源仓库；运行时从用户本机安装目录加载匹配版本。

程序修改先采用交换格式：AI 生成 ST、变量和类型，打包为已验证的 XML，导入工程副本，再用真实编译器检查并把错误反馈给 AI。直接修改内部工程文件需额外核实格式和完整性保护，不应作为第一版依赖。当前静态证据还不能证明 ACI 提供任意代码工作表的逐字编辑 API。

诊断适配器按设备选择 OPC UA、已开启的 REST，或 PLC 本地 agent 转接 gRPC/RSC。AI 获取变量时应同时得到时间戳、数据质量和采样窗口；状态解释需要变量含义、工程映射和故障上下文，不能仅凭某个数值推断原因。

## 第一版 MCP 范围（拟议工具名）

| 工具 | 目标能力 | 需要先验证 |
|---|---|---|
| engineer_get_environment | 版本、ACI 状态、支持能力 | SDK、许可及认证 |
| project_open / project_get_structure | 打开工程、枚举控制器/POU/变量/任务 | 元数据遍历、工程版本 |
| project_import / project_build | 导入生成物、编译并返回消息 | XML替换语义、异步完成事件及消息 |
| plc_connect / plc_get_state | 连接、读取运行状态 | 型号、固件、凭据及权限 |
| plc_read_variables | 读取指定变量快照 | 变量映射、数据类型和质量 |
| plc_get_diagnostics | 返回设备状态、日志或趋势 | 选定 runtime 服务实际暴露内容 |
| project_prepare_download / project_download | 固定待下载构建并更新设备 | 实际下载模式、停机需求和目标匹配 |

这些名字是接口设计，不是现有厂商 API 或已经实现的工具。第一版不必暴露 Reset 等与主要开发目标无关的动作。下载应使用已编译且可识别的工程产物，区分全量下载与在线变更；当前未证明在线变更能力。

## 建议验证顺序

1. 核对本机 ACI 有效授权、获取与 2026.0.4 匹配的 SDK/示例，验证正常认证和启动；不绕过许可或认证。
2. 在工程副本上完成“无界面打开 → 导入小型 ST/FB → 编译 → 读取错误 → 修正 → 编译成功”，记录实际调用和输出。
3. 通过指定测试 PLC 验证连接、状态及变量读取，确定诊断选用的协议。
4. 在测试设备完成受控下载及运行结果核对，再补充 MCP 的长任务进度、取消、超时、会话串行化和错误分类。

## 调查问题完成度与剩余未知

| 问题 | 状态 |
|---|---|
| 是否能减少 computer use | 已回答：有 ACI 官方依据和本机接口证据 |
| 是否有工程编译、PLC下载、状态读写入口 | 已回答到静态接口层；执行尚待实测 |
| 是否可完全卸载 Engineer 仍开发 IEC 工程 | 未证实；建议保留 Engineer 后端 |
| 是否能独立进行运行时监控诊断 | 有官方接口依据；目标设备能力待确认 |
| 是否可直接复用官方现成 MCP | 部分回答：有公告，公开接入方式未确认 |
| 现有软件是否整体开源 | 未证实；含开源组件不意味着整个 Engineer 开源 |
| 本机许可、工程、PLC型号/固件及凭据 | 未验证，影响下一阶段实测 |
| 修改任意 ST 工作表、全工程重建、在线变更、调试断点 | 尚未逐项验证 |

建议优先顺序：核对官方 MCP 可复用性 → 验证 ACI 最小工程闭环 → 建立独立 Runtime 诊断 MCP。已有接口存在明确缺口后，再对该缺口做有目标的逆向分析。

