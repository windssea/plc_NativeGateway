# PLCnext MCP 0.6.13 全部工具参考

本文件由 `tools/export_mcp_reference.py` 从实际 FastMCP `list_tools()` 生成，共 **89 个工具**。参数、默认值与枚举均取自实际 `inputSchema`，不硬编码工具数量。运行时校验可能比 Schema 更严格。

[使用与测试手册](mcp-user-guide.md) · [M01～M10 联调指南](joint-implementation-user-guide.md) · [机器可读 Schema](mcp-tool-schema.json)

## 共同约定

- 本文工具存在、代码已实现、本机通过、真机通过是不同状态。实际交付证据见联调指南和报告。
- 每次编辑使用返回的新 `project_sha256`。POU 批量接口编辑还需各自 `code_sha256` 与 `variables_sha256`。
- `project_compile` 返回 `job_id`，下一步参数叫 `build_job_id`；生成包返回独立 `package_job_id`。
- `review_id/review_sha256` 与运行读取/恢复的 `plan_id/plan_sha256` 都是选择器，不是授权收据。
- 真实写入、控制与恢复需操作者精确确认。普通 MCP 没有批准工具；只读查询和本机测试不能代签。
- `isError=true` 与工具正常返回的失败 `status` 都要检查。结构通过、语法通过、编译通过、包完整、加载/运行及业务通过分别验收。
- 工具注解是客户端提示，不能代替实现中的身份、范围与审批检查。本地只读查询也可能保存报告。

## 能力与替代账本

### `server_capabilities`

实际能力和环境。

按实现、离线/本机证据、真机证据分别判断；工具存在不表示设备验收通过。

无参数，传 `{}`。

实现描述（原始工具说明）：

> Report the actual backend and limits; never infer compile success from validation.

### `aci_replacement_status`

ACI 替代状态。

只读本地替代账本，不执行 ACI。201 个声明方法不等于全部已替代。

无参数，传 `{}`。

实现描述（原始工具说明）：

> Report evidence-backed independent ACI coverage, remaining gaps and priorities.
> 
>     Static API discovery, a partial substitute or official unimplemented property
>     is never counted as full replacement. Does not execute ACI or use the network.

### `aci_replacement_methods`

ACI 方法分页。

过滤值取自 status 的当前分类；include_details 提供证据/验收缺口。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `domain` | string / null | 否 | `null` |
| `status` | string / null | 否 | `null` |
| `offset` | integer | 否 | `0` |
| `limit` | integer | 否 | `40` |
| `include_details` | boolean | 否 | `false` |

实现描述（原始工具说明）：

> Page all 201 declared ACI interface methods with substitutes and acceptance gaps.
> 
>     Use aci_replacement_status to discover domain/status filters. include_details
>     adds evidence and acceptance criteria. A mapped tool has the bounded scope
>     stated per member, not necessarily the full official API semantics.

## 下载、预检和状态

### `controller_read_state`

真实设备只读状态。

明确字面 IP/端口/证书 pin；仅固定状态服务，没有变量写或启停。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `port` | integer | 否 | `41100` |
| `timeout_seconds` | integer | 否 | `5` |

实现描述（原始工具说明）：

> Read one PLC state over independent pinned TLS/RSC, without ACI or GUI.
> 
>     Sends only Connect, fixed IPlcManagerService discovery and GetPlcState(method 5).
>     Requires a literal IP and explicitly supplied peer certificate SHA-256; no
>     trust-on-first-use, credentials, file access, download or PLC control. Supports
>     only the verified RSC v4 tagged/no-datagram response profile. Saves a local
>     action report. A certificate mismatch sends no RSC request; no automatic retry.

### `project_prepare_download_review`

下载版本和影响审阅。

精确源/包/目标/策略，不连设备、不发行收据；下载固定动作不包含 Stop/Start。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `port` | integer | 否 | `41100` |

实现描述（原始工具说明）：

> Prepare an immutable version/target/impact review; never approve or contact PLCs.
> 
>     Binds the exact source revision, cold build, PCWE inventory and every file hash
>     to the literal IP/port/certificate pin. Lists Stop requirement, overwrite,
>     Reset/Load, possible interruption/autostart and lack of rollback/old-file
>     deletion. Review IDs/hashes are selectors, not write permission. Requires
>     separately recorded human confirmation before real execution.

### `project_inspect_download_review`

重验下载审阅。

默认重新检查当前源与包，不能通过关闭 revalidate 参数获得权限。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `revalidate_package` | boolean | 否 | `true` |

实现描述（原始工具说明）：

> Inspect/revalidate exact reviewed source and package; never grant write access.

### `project_preflight_controller_download`

真实目标只读预检与显式包冻结。

默认只读状态/根/空间及两份元数据。verify_package_files=true才按不可变review路径做SHA-512和前后manifest/状态守卫；capture_package_files=true还要求verify并保存新本地窗口一致磁盘快照。响应预算默认32MiB、范围1..64MiB。不会扩展到远端manifest额外路径，不写/控制PLC，不证明内存loaded或可执行回滚。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `verify_package_files` | boolean | 否 | `false` |
| `capture_package_files` | boolean | 否 | `false` |
| `maximum_package_read_bytes` | integer | 否 | `33554432` |

实现描述（原始工具说明）：

> Read live download context from the exact reviewed target; never authorize/write.
> 
>     Default reads only state, root/space and two fixed metadata files. Explicit
>     verify_package_files additionally audits exact review-listed remote files by
>     SHA-512 against their remote manifest, under a 1..64MiB total response budget;
>     capture_package_files saves a new coherent disk snapshot only. No credentials,
>     arbitrary paths, writes, Stop/Start/Reset/Load or deletion. Running is allowed.
>     Disk bytes do not attest active memory, write permission or unlisted files.

### `project_test_controller_download`

本机生产客户端传输测试。

只创建 127.0.0.1 随机 TLS 测试端；真实本地文件、SHA-512、Reset/Load；不接受真实地址。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `fault` | string | 否 | `"none"` |

`fault` 枚举：`none`、`write_reply_lost`、`readback_corrupt`、`write_error`、`short_results`、`load_error`、`load_timeout`、`reset_timeout`、`initial_running`、`tls_error`、`permission_denied`、`insufficient_space`、`load_reply_lost`、`reset_reply_lost`、`rpc_error`、`fatal_error`、`chunked_readback`。

实现描述（原始工具说明）：

> Use the production socket client to transfer a copy to a local test peer.
> 
>     Starts only a 127.0.0.1 random-port TLS fixture, writes real files under a new
>     owned workspace job, verifies SHA-512 readback and test Reset/Load/Stop state.
>     Does not accept an external endpoint or use ACI, Engineer or MemoryBIO. No
>     controller approval is issued; real-device success is never inferred.

### `project_execute_controller_download`

经确认的真实全包下载。

需有效人工或MCP一次性收据、初始 Stop、文件集合策略、回读、Reset/Load；无自动启停/删旧文件/回滚/不确定重试。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Execute ONLY an exact review with a separate, one-use human approval receipt.
> 
>     This tool never creates that receipt. Without it, fails before opening a
>     socket. Revalidates all local source/package/target bindings and the approval,
>     pins the live TLS certificate, requires fresh Stop state and matching existing
>     manifest paths, then writes/readbacks/resets/loads. No automatic Stop, Start,
>     delete, rollback or retry; a lost mutation reply is outcome_unknown. Partial
>     writes and firmware autostart remain material effects; first review with user.

### `project_download_plan`

下载包计划检查。

复核源/布局/清单；本地计划不授予真实写权限。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |

实现描述（原始工具说明）：

> Verify a generated current NativeGateway PCWE copy and plan an offline simulation.
> 
>     Rechecks source identity, package inventory, runtime bindings and final type metadata.
>     Reports service contracts and remaining real transport/TLS work. No endpoint or
>     credential input; no device discovery, network connection, PLC stop/start or download.

### `project_simulate_download`

内存 TLS 模拟。

无 socket；临时测试认证和 tagged/untagged 流程，不证明真实设备权限。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `fault` | string | 否 | `"none"` |
| `protocol_profile` | string | 否 | `"v4_untagged"` |

`fault` 枚举：`none`、`bad_credentials`、`penalty_active`、`permission_denied`、`session_expired`、`insufficient_space`、`write_error`、`short_results`、`transport_interrupted`、`readback_corrupt`、`reset_timeout`、`load_timeout`、`load_error`、`initial_running`、`untrusted_peer`、`hostname_mismatch`。

`protocol_profile` 枚举：`v4_untagged`、`v4_tagged`。

实现描述（原始工具说明）：

> Exercise the download flow with an in-memory controller and ephemeral test credentials.
> 
>     Simulates password authentication and token context, whole-file WriteMany batches,
>     per-file errors, SHA-512 readback and Reset(true)/Load(true) state polling. Saves a
>     local diagnostic report and redacted operation trace; never starts the program.
>     A simulated failure returns simulation_failed, never controller_downloaded=true.
>     TLS runs through MemoryBIO with public offline test CA/keys. Bounded v4
>     untagged or tagged binary calls negotiate handles and carry session/file/
>     configuration values; codecs match measured vendor vectors. Tagged uses typed
>     values, DTOs and terminators, not just a changed header flag. Only known method
>     schemas are covered; generic RSC framing/error profiles remain incomplete.
>     No real endpoint, credentials, PLC TLS channel or vendor online client is used.
>     Only generated packages bound to the current managed copy qualify.

## 任务与独立 Program

### `project_inspect_tasks`

源任务与实例映射。

纳秒时序；不是设备实测。支持查看既有任务，编辑范围以实际 profile 为准。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |

实现描述（原始工具说明）：

> Read source ESM/task identities, timings and program-instance bindings.
> 
>     Timings use nanoseconds. Source values are not measured runtime execution or
>     controller state. Does not invoke ACI, Engineer or a network connection.

### `project_update_cyclic_task`

修改指定周期任务。

可从多任务中按精确 ID 选择，改纳秒周期/看门狗/优先级，保持其他任务和实例。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `task_id` | string | 是 | — |
| `updates` | object | 是 | — |

实现描述（原始工具说明）：

> Change supported cyclic scheduling on a new offline project-copy revision.
> 
>     updates may contain interval_ns, watchdog_ns and/or priority. Requires the
>     supported AXCF2152/2026 single-eCLR, 1..16 cyclic-task source profile, exact current project hash
>     and existing task ID. Preserves all other ESM bytes and task/program-instance
>     IDs; old builds become stale. Compile again to verify the new source. Does not
>     create/delete tasks, connect to PLC or change the running program.

### `project_clone_program`

创建独立 Program。

标准 Program 克隆/可选完整代码和变量，新 ID；不自动挂接任务。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `source_pou_name` | string | 是 | — |
| `new_pou_name` | string | 是 | — |
| `code` | string / null | 否 | `null` |
| `variables` | string / null | 否 | `null` |

实现描述（原始工具说明）：

> Clone a standard Program into a new source revision with fresh object/worksheet IDs.
> 
>     Optional complete code/variables replace cloned text; no task assignment or
>     device access. Independent multi-task programs require explicit safe ownership.

### `project_change_cyclic_tasks`

周期任务增删。

单 eCLR、1..16 周期任务、资源内实例唯一；共享数据保守拒绝或要求明确独占合同。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `add_tasks` | array[object] / null | 否 | `null` |
| `delete_task_ids` | array[string] / null | 否 | `null` |
| `ownership_contract` | object / null | 否 | `null` |

实现描述（原始工具说明）：

> Add/delete bounded independent cyclic tasks and source program-instance mappings.
> 
>     New IDs, exact timing/priority, no duplicate program ownership. Complex existing
>     primary code requires an explicit source/closure-bound ownership contract;
>     extra tasks remain local-only, without shared mutable buffers or pointer access.
>     Does not change PLC scheduling until separately reviewed deployment.

### `project_declare_task_ownership`

重新声明任务所有权。

源码/闭包改变后重新检查精确合同；不是任意指针形式化安全证明或共享 FIFO 实现。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `ownership_contract` | object | 是 | — |

实现描述（原始工具说明）：

> Recheck explicit task ownership against the exact current source/closure hashes.
> 
>     A previous contract is invalid after source changes; declarations are not a
>     proof of arbitrary memory safety and cannot permit shared unguarded FIFO access.

## 工程、POU、代码和接口

### `project_import_copy`

导入 PCWEX 副本。

source_path 是现有文件绝对路径；不覆盖原件，返回新 project_id 和 SHA。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `source_path` | string | 是 | — |

实现描述（原始工具说明）：

> Copy a user-selected .pcwex into a managed workspace; never modify the source.

### `project_create`

新建独立工程。

默认受支持 AXC F 2152 空模板，创建 ST Main 和新身份；不是任意设备模板。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `name` | string | 是 | — |
| `template_path` | string / null | 否 | `null` |

实现描述（原始工具说明）：

> Create a separate offline .pcwex from an installed device template.
> 
>     Default: AXC F 2152 template with a fresh ST Main program. Returns a managed
>     project_id and path; never creates a controller connection or downloads.

### `project_inspect`

查看工程身份和 POU。

返回当前修订、POU/工作表 ID 和已知映射成员；不编译。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |

实现描述（原始工具说明）：

> List standard POUs, identities, worksheet IDs, current revision and mapping members.

### `project_read_pou`

读取代码、变量及哈希。

code/variables 为完整文本；修改前读取 code_sha256、variables_sha256 和工程 SHA。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `pou_name` | string | 是 | — |

实现描述（原始工具说明）：

> Read ST and variable declarations, plus exact code/project hashes required for patches.

### `project_find_references`

查找 ST 实例/调用。

有限源搜索，不是完整编译器符号表或任意外部配置引用证明。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `pou_name` | string | 是 | — |

实现描述（原始工具说明）：

> Find bounded standard-ST instance declarations and call locations; not a compiler symbol table.

### `project_patch_st`

唯一片段替换。

old_text 恰好一次，工程/代码双 SHA；只改正文，生成新修订。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `pou_name` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `expected_code_sha256` | string | 是 | — |
| `old_text` | string | 是 | — |
| `new_text` | string | 是 | — |

实现描述（原始工具说明）：

> Replace exactly one ST fragment, producing a new revision with every other payload unchanged.
> 
>     Both hashes must match the current revision. Does not change POU interfaces, variables,
>     mappings, worksheet IDs or any vendor license, and does not compile or download.

### `project_update_pous`

原子修改代码/变量接口。

每项有 pou_name、两个工作表 SHA，至少 code/variables 之一；完整文本，可同步调用方。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `updates` | array[object] | 是 | — |

实现描述（原始工具说明）：

> Atomically update existing POU code and variable interfaces in one new revision.
> 
>     Each item requires pou_name, expected_code_sha256, expected_variables_sha256 and
>     optional full code/variables strings. Update FB interfaces and affected callers
>     together. Preserves every metadata/ID/mapping member; compile to check syntax/types.

### `project_change_fbs`

原子增删 FB 及调用方。

add_fbs 为名称和可选完整代码/变量，delete_fbs 为名称数组；最终仍引用时拒绝删除。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `add_fbs` | array[object] / null | 否 | `null` |
| `delete_fbs` | array[string] / null | 否 | `null` |
| `updates` | array[object] / null | 否 | `null` |

实现描述（原始工具说明）：

> Atomically add/delete standard ST function blocks and update affected callers.
> 
>     add_fbs items contain pou_name and optional complete code/variables text.
>     delete_fbs contains existing FB names; remaining references prevent deletion.
>     updates uses project_update_pous items with both worksheet hashes. New FBs get
>     fresh object/worksheet IDs; unrelated payloads and existing mapping IDs persist.
>     This is an offline editing transaction; call project_compile afterwards.

### `project_add_fb`

新增标准 ST FB。

新对象/工作表 ID；不会自动添加调用方实例。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `pou_name` | string | 是 | — |
| `code` | string | 否 | `""` |
| `variables` | string | 否 | `"VAR\nEND_VAR\n"` |

实现描述（原始工具说明）：

> Add one standard ST FB with fresh metadata/worksheet IDs to a new revision.

### `project_delete_fb`

删除未引用 ST FB。

有引用拒绝；同步移除调用/实例请使用 change_fbs。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `pou_name` | string | 是 | — |

实现描述（原始工具说明）：

> Delete an unreferenced ST FB; use project_change_fbs for coordinated caller updates.

### `project_validate`

结构与成员保留检查。

不证明语法、类型、签名、运行映射或功能正确。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |

实现描述（原始工具说明）：

> Compare original/current payload bytes. Structural success is NOT compile success.

### `project_diff`

代码差异。

对冻结原件的有界 ST diff；max_chars 可能截断。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `pou_name` | string | 是 | — |
| `max_chars` | integer | 否 | `16000` |

实现描述（原始工具说明）：

> Return a bounded ST diff against the frozen original.

### `project_diff_pou`

代码和变量差异。

分别检查完整代码/声明差异，结合 validate 和冷编译。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `pou_name` | string | 是 | — |
| `max_chars` | integer | 否 | `16000` |

实现描述（原始工具说明）：

> Show separate ST code and variable declaration diffs against the frozen original.

### `project_prepare_audit_export`

准备独立审计导出。

仅完整审计候选；绑定源/包/目标/boot/固定白名单/限额及托管输出目录，不连接PLC。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `expected_boot_id` | string | 是 | — |
| `port` | integer | 否 | `41100` |
| `duration_seconds` | integer | 否 | `30` |
| `poll_interval_ms` | integer | 否 | `100` |
| `maximum_records` | integer | 否 | `100000` |
| `maximum_bytes` | integer | 否 | `67108864` |
| `closure_mode` | string | 否 | `"raw_tail"` |
| `tail_seconds` | integer | 否 | `10` |
| `fact_mode` | string | 否 | `"legacy_v1"` |

`closure_mode` 枚举：`raw_tail`、`source_cohort`。

`fact_mode` 枚举：`legacy_v1`、`decision_clock_slots_v2`。

实现描述（原始工具说明）：

> Prepare fixed capture/association audit export; local source/package checks only.
> 
>     Requires complete 512/32 audit rings and source-resolved scalar whitelist;
>     original projects without rings are unsupported and never modified. Output is
>     a new managed events.jsonl path. Duration 1..300s plus bounded tail/package checks.
>     fact_mode='decision_clock_slots_v2' binds typed raw decision-clock/slot fields;
>     defaults stay legacy_v1. Raw fact flags do not attest independent slot proof.
>     Separately authorize with kind=audit_export. No PLC calls in preparation.

### `project_inspect_audit_export`

检查审计导出计划。

本地重验类型、包、输出及限额，不授权。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Revalidate audit plan source/package/types/limits and show output path; no PLC I/O.

### `project_execute_audit_export`

执行有界审计导出。

kind=audit_export授权后，只读原始环并先fsync再确认四个ACK字段；无业务FIFO/控制/下载。保持会话到终态。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Execute a bounded audit session; keep the MCP connection alive until terminal result.
> 
>     Exact authorization, endpoint exclusion, fresh boot and disk package check.
>     Only four audit ACK fields may be written, after contiguous fsynced copies.
>     No business FIFO/DATA/STORED, Force, downloads or PLC task/configuration edits.
>     Lost ACK replies/host exit are incomplete and never automatically retried.
>     Physical throughput is unverified until a separately arranged candidate test.

### `project_audit_export_status`

审计导出状态。

本地查看结果；宿主退出报unknown，不自动重启。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Inspect local audit status; host loss remains unknown, never an automatic restart.

### `project_cancel_audit_export`

取消审计导出。

本地请求在下次I/O边界停止；不撤销已发ACK、不重放。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Request bounded cancellation locally; never rolls back or retries audit ACKs.

### `project_prepare_lease_reconciliation`

准备旧租约核销。

只接受已结束且结果明确的后台恢复执行；核对旧记录并只读验证 Running、配置和全部 GOOD，不控制设备。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `operation_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Prepare exact lease archival for a known completed recovery with pending business checks.
> 
>     Requires terminal owner/journal/results and dead process identity. Reads PLC
>     to verify Running, original configuration and GOOD coverage; no controller writes.
>     Unknown writes and legacy synchronous owners are unsupported and refused.

### `project_prepare_sync_lease_reconciliation`

准备同步恢复核销。

传 execution_id，不伪造 operation_id；核验已消费授权、完成隔离终态及闭合日志，后续复用核销检查/授权/执行。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `execution_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Prepare reconciliation for an explicitly synchronous completed recovery.
> 
>     Requires exact consumed authorization, completed quarantined result, closed
>     mutation journal and terminal executor protocol. Rejects incomplete/unknown
>     executions. Reads Running/configuration/GOOD; never writes to the controller.
>     Uses the existing inspect/authorize/execute reconciliation tools afterward.

### `project_prepare_reboot`

准备整机重启。

绑定源/包/读计划/当前boot/配置及停机影响，纯本地准备；使用reboot授权。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `read_plan_id` | string | 是 | — |
| `read_plan_sha256` | string | 是 | — |
| `expected_boot_id` | string | 是 | — |
| `expected_configuration` | object | 是 | — |
| `configuration_sha256` | string | 是 | — |
| `port` | integer | 否 | `41100` |
| `timeout_seconds` | integer | 否 | `240` |
| `poll_interval_seconds` | integer | 否 | `5` |

实现描述（原始工具说明）：

> Prepare exact device reboot once, then read-only reconnect and automatic Running verification.
> 
>     Local only; binds current source/package/read plan/boot/configuration and disruption.
>     Does not authorize reboot. Use kind=reboot authorization. No fallback PLC Start.

### `project_inspect_reboot`

检查整机重启计划。

本地核验计划与执行状态，不连接设备。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Inspect exact reboot plan and local progress; no controller connection.

### `project_execute_reboot`

整机重启并确认自动运行。

固定RestartDevice只发送一次；有界重连，新boot及连续两次Running/配置/GOOD通过才成功。resume_read_only只读续查，不重发、不补Start。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |
| `resume_read_only` | boolean | 否 | `false` |

实现描述（原始工具说明）：

> Consume exact reboot authorization, reboot once and wait within reviewed budget.
> 
>     Requires changed application BootId and two consistent Running/config/GOOD reads.
>     resume_read_only only observes the already claimed operation; never resends reboot
>     or sends Start. Uncertain/failed waits retain the endpoint lease and original evidence.

### `project_reboot_status`

查询重启进度。

读取本地状态和证据，不连接设备。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Read local reboot receipt/progress; never reconnect or retry a mutation.

### `project_cancel_reboot_wait`

取消重启等待。

停止后续等待，不撤销已发重启，不补发控制；结果未知保留租约。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Cancel waiting; does not undo a reboot or send compensating control.

### `project_prepare_observation_reconciliation`

启动观测失败租约交接。

仅控制明确完成的观测失败；绑定当前源、读计划、boot/配置摘要与外部证据，纯只读核对后精确归档。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `operation_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `current_project_id` | string | 是 | — |
| `current_project_sha256` | string | 是 | — |
| `current_read_plan_id` | string | 是 | — |
| `current_read_plan_sha256` | string | 是 | — |
| `expected_boot_id` | string | 是 | — |
| `expected_configuration` | object | 是 | — |
| `expected_configuration_sha256` | string | 是 | — |
| `external_evidence_path` | string | 是 | — |
| `external_evidence_sha256` | string | 是 | — |
| `description` | string | 是 | — |

实现描述（原始工具说明）：

> Prepare archival of confirmed-control / failed-runtime-observation quarantine.
> 
>     Binds the terminal async operation and consumed authorization, exact current
>     source/read plan/boot/configuration digest, and hashed external handoff record.
>     Fresh reads only; no device writes, automatic restore or memory image attestation.
>     Use existing lease reconciliation inspect/authorize/execute. Old failure remains.

### `project_prepare_sync_observation_reconciliation`

同步启动观察失败核销。

传真实execution_id及显式当前源/读计划/boot/配置/外部证据；接受经计划、只读状态和闭合日志证明的skip-Stop。仅新鲜读取准备，不发控制，独立授权后归档精确租约。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `execution_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `current_project_id` | string | 是 | — |
| `current_project_sha256` | string | 是 | — |
| `current_read_plan_id` | string | 是 | — |
| `current_read_plan_sha256` | string | 是 | — |
| `expected_boot_id` | string | 是 | — |
| `expected_configuration` | object | 是 | — |
| `expected_configuration_sha256` | string | 是 | — |
| `external_evidence_path` | string | 是 | — |
| `external_evidence_sha256` | string | 是 | — |
| `description` | string | 是 | — |

实现描述（原始工具说明）：

> Prepare archival of confirmed-control / failed-runtime-observation quarantine.
> 
>     Binds the terminal synchronous execution (including proven no-op Stop) and consumed authorization, exact current
>     source/read plan/boot/configuration digest, and hashed external handoff record.
>     Fresh reads only; no device writes, automatic restore or memory image attestation.
>     Use existing lease reconciliation inspect/authorize/execute. Old failure remains.

### `project_prepare_parent_audit_reconciliation`

父恢复审计失败核销。

仅已结束且控制结果明确的父审计失败；核验fsync文件并只读回查ACK不超出持久化游标。不伪造审计完整、不自动恢复。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `execution_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Prepare controlled archival after an isolated terminal parent-audit failure.
> 
>     Verifies the exact parent claim, closed control outcome, durable audit bytes,
>     and stable readback of four ACK fields within fsynced cursors on the same boot.
>     Zero ACK supports absent boot or an observed boot with a durable partial prefix;
>     exact zero writes/intents and fresh boot/config/empty ACK guards are required.
>     Read cursors use overflow windows; ACK cursors remain bounded by durable bytes.
>     Unknown writes outside audit, live executors and changed/missing evidence fail closed.
>     Never marks audit complete or automatically restores/downloads. Use ordinary
>     reconciliation inspect/authorize/execute, then a new exact recovery plan.

### `project_inspect_lease_reconciliation`

检查核销计划。

本地重验目标、旧租约/日志/结果哈希及终态；不授权。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Inspect exact reconciliation evidence locally; no authorization or PLC I/O.

### `project_execute_lease_reconciliation`

执行受控核销。

使用 lease_reconciliation 精确授权；重新只读核验后归档旧租约。可完成中断核销，不重放设备动作。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Consume exact authorization, repeat read-only verification and archive the bound lease.
> 
>     No Stop/download/Start/retry. Retains old claims/journal and crash intent.
>     Repeating an interrupted exact plan finalizes its archival, never replays device actions.

## 语法、构建和诊断

### `project_build_plan`

冷编译能力预检。

支持时返回准确 compile 参数，否则给出具体 unsupported_reason。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |

实现描述（原始工具说明）：

> Check project capabilities and return an exact offline cold-build call.

### `project_check_st`

单工作表语法检查。

依赖厂商解析库；不做全工程语义和镜像生成。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `pou_name` | string | 是 | — |

实现描述（原始工具说明）：

> Run the installed ST worksheet syntax parser in a bounded headless subprocess.
> 
>     No ACI, GUI or controller access. Syntax success is NOT whole-project compilation,
>     type checking or code generation. Keeps a report tied to the exact input hashes.

### `project_compile_cached`

历史缓存实验。

固定 NG_ReadAck/样例/种子限制；日常验收使用 project_compile。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Experimentally recompile NG_ReadAck through fresh semantic analysis, CIL and native image.
> 
>     Only supports the pinned NativeGateway copy with unchanged declarations and every
>     other project member. Requires its frozen GUI-created AST/library seed and installed
>     compiler. No ACI, UI, execution or PLC access. The resulting offline image is not
>     validated for deployment; this is not a cold full-project PCWEX build.

### `project_compile`

源驱动 IEC 冷编译。

支持范围内重建 POU/类型/库/任务，无项目 AST 种子；依赖厂商编译组件。不是完整 PCWE。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Cold-build a supported offline project from its exact current source revision.
> 
>     Checks device and source capabilities, reconstructs POUs/interfaces/types/libraries
>     and cyclic tasks without a project AST seed, runs semantic analysis and generates
>     fresh CIL/native image. Requires the local Engineer compiler installation.
>     Returns deployable=false: hardware/HMI/signature packages and execution are outside
>     this build. Never connects to a PLC or uses ACI/GUI.

### `project_compile_nativegateway`

旧构建名称兼容。

默认 cold；cached 保留固定样例和种子限制，不用于通用冷编译声明。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `mode` | string | 否 | `"cold"` |

`mode` 枚举：`cached`、`cold`。

实现描述（原始工具说明）：

> Compatibility alias; prefer project_compile for general supported projects.
> 
>     Allows local/input/output/in-out variable changes in existing POUs and coordinated
>     caller updates. mode=cached requires the frozen NativeGateway original and uses a
>     library/device/type seed. mode=cold rebuilds its IEC model from project source
>     and installed/referenced library packages, with no project AST seed. Neither mode
>     regenerates a complete deployment package or accesses ACI, GUI or a PLC.

## PCWE 生成与本地快照

### `project_deployment_plan`

构建与包缺口分析。

build_job_id 使用 compile 返回的 job_id；不生成设备授权。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `build_job_id` | string | 是 | — |

实现描述（原始工具说明）：

> Verify an exact cold build's sources/outputs and report missing deployment components.
> 
>     Reports native-library candidates without guessing target compatibility. A successful
>     IEC image is not a complete PCWE package. Always offline; does not invoke a compiler.

### `deployment_inspect_pcwe`

本地 PCWE 完整性。

检查清单/文件 SHA-512；不是设备内存身份或签名兼容证明。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `source_path` | string | 是 | — |

实现描述（原始工具说明）：

> Inspect a complete local PCWE directory; verify each listed SHA-512 file hash.
> 
>     Original manifest overall order may be unknowable. Does not validate signatures,
>     hardware compatibility, runtime mappings or controller acceptance; deployable=false.

### `project_generate_pcwe`

完整本地 PCWE 候选。

限定 NativeGateway 硬件/HMI profile；download_memento_policy 必须明确理解，完整包不等于真机验收。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `build_job_id` | string | 是 | — |
| `download_memento_policy` | string | 否 | `"omit"` |

`download_memento_policy` 枚举：`omit`、`empty_capability_v1`。

实现描述（原始工具说明）：

> Generate a complete local PCWE candidate from an exact fresh cold build.
> 
>     Supports the verified NativeGateway AXCF2152/2026 hardware/services and Gateway/Login
>     HMI profile only. Rebuilds runtime XML, native library selection, HMI pages/dictionaries,
>     auxiliaries and integrity manifest. Cross-checks source mappings against finalized
>     native/CIL types. Requires installed Engineer compiler libraries and Windows .NET.
>     Writes a new workspace directory. No old GUI cache, ACI, GUI or PLC communication.
>     Optional empty_capability_v1 generates the original empty dlc.bin history format;
>     it explicitly discards prior Engineer download-capability history, not runtime code.
>     Returns deployable=false: no controller acceptance/execution/signature validation.

### `deployment_stage_pcwe`

本地冻结快照。

按 inventory SHA 新建本地快照，不上传；不能冒充当前工程生成包 ID。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `source_path` | string | 是 | — |
| `expected_inventory_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Create a new byte-preserving local PCWE snapshot tied to an inspected inventory.
> 
>     Requires a complete existing PCWE directory. Output stays under the MCP workspace.
>     Does not combine cold images with old configurations, create a DAuM ZIP or access PLCs.

## 运行符号、只读窗口与时序证据

### `project_inspect_runtime_symbols`

解析源符号/类型。

不连接 PLC；源中存在不证明当前已加载版本相同。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Resolve source-defined instance/global paths and types without connecting to PLC.
> 
>     Source symbols are not proof that the same program is currently loaded.
>     No arbitrary memory addresses, writes or Force are exposed.

### `project_prepare_runtime_read`

冻结有限变量读计划。

源/类型/目标绑定，最多2048符号、64项分块、1MiB响应、至少5秒间隔；未知字段保持 unsupported。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `symbols` | array[string] / null | 否 | `null` |
| `port` | integer | 否 | `41100` |
| `chunk_size` | integer | 否 | `64` |
| `timeout_seconds` | integer | 否 | `5` |
| `maximum_bytes` | integer | 否 | `1048576` |
| `minimum_interval_seconds` | integer | 否 | `5` |
| `point_count` | integer | 否 | `250` |
| `include_samples` | boolean | 否 | `true` |
| `include_configuration` | boolean | 否 | `false` |

实现描述（原始工具说明）：

> Freeze a finite source/type/target-bound read plan; no device access yet.
> 
>     Defaults select bounded NativeGateway identity/configuration/250-point fields.
>     Missing source fields stay unsupported; no new program is downloaded for them.
>     Observations are guarded windows, not atomic snapshots or active-image attestation.

### `project_read_runtime`

真实设备有界只读变量。

固定计划、严格数量/类型/错误和前后身份守卫；窗口观察不冒充原子快照/内存镜像认证。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Read only the exact reviewed source symbols through pinned TLS/RSC.
> 
>     Bounded types/count/bytes/time/frequency, per-item errors and observation times;
>     boot/config changes invalidate the window. No write, Force, file or control RPC.

### `project_test_runtime_read`

本机在线读取测试。

127.0.0.1 测试端；缺项、坏质量、类型错、部分返回和跨boot/config变化按实际 fault 校验。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `fault` | string | 否 | `"none"` |
| `point_count` | integer | 否 | `250` |

实现描述（原始工具说明）：

> Test source-bound runtime reads against an owned 127.0.0.1 TLS peer only.
> 
>     Covers missing/bad/type/partial/identity-change cases without connecting PLCs.

### `project_runtime_timing_evidence`

既有收据/探针取证。

聚合精确运行读取报告与明确探针合同，不把RPC耗时当任务执行时间，不启动P06或虚称≤1ms/≥90。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `read_plan_id` | string | 是 | — |
| `expected_read_plan_sha256` | string | 是 | — |
| `observations` | array[object] | 是 | — |
| `probe_contract` | object / null | 否 | `null` |

实现描述（原始工具说明）：

> Create bounded timing/counter evidence from exact existing runtime-read receipts.
> 
>     No network or P06 run. Absent existing versioned probes/ESM metrics stay unknown;
>     RPC durations never stand in for PLC CPU time or <=1ms/>=90/s acceptance.

### `project_prepare_esm_read`

固定ESM系统变量读计划。

按当前设备模板/源ESM任务建立白名单和类型，限定ESM[1..2]/TASK[1..16]，不修改原程序、不连接设备。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `port` | integer | 否 | `41100` |
| `esm_indices` | array[integer] / null | 否 | `null` |
| `task_indices` | array[integer] / null | 否 | `null` |

实现描述（原始工具说明）：

> Prepare typed reads of existing ESM_DATA from the exact installed/source profile.
> 
>     Fixed ESM1..2/task1..16 fields only; no program instrumentation or arbitrary
>     addresses. Source/template types, task names and timing units are explicit.

### `project_read_esm`

有界读取ESM时序系统变量。

固定类型/范围/目标计划；保持boot/计数重置/窗口和缺字段状态。系统LAST/MAX含抢占，不等于新增业务CPU耗时或P06通过。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |
| `previous_observation_id` | string / null | 否 | `null` |
| `expected_previous_sha256` | string / null | 否 | `null` |

实现描述（原始工具说明）：

> Read exact existing ESM fields with boot/config guards and source task matching.
> 
>     Optional previous receipt enables bounded delta checks. Reset/wrap, missing
>     fields or changed identities stay unknown; elapsed execution includes preemption,
>     never proves incremental CPU <=1ms or restarts P06 acceptance.

### `project_test_esm_read`

本机ESM系统变量测试。

仅工具自建127.0.0.1；类型、计数、boot、缺项和异常按实际fixture验证，不冒充真实PLC量测。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `fault` | string | 否 | `"none"` |

`fault` 枚举：`none`、`missing_field`、`boot_change`、`wrong_task_name`。

实现描述（原始工具说明）：

> Test typed existing-ESM reads against a new owned 127.0.0.1 TLS peer only.

## 受控 Stop / Start

### `project_prepare_controller_control`

独立 Stop/Start 审阅。

绑定精确前态、终态、包和启动模式；不同于下载收据，不连设备。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `action` | string | 是 | — |
| `port` | integer | 否 | `41100` |
| `start_kind` | string / null | 否 | `null` |
| `timeout_seconds` | integer | 否 | `30` |
| `expected_initial_state` | integer / null | 否 | `null` |

`action` 枚举：`stop`、`start`。

实现描述（原始工具说明）：

> Prepare a separate exact Stop/Start review; not permission or device access.
> 
>     Start needs verified loaded identity, unavailable from a name/manifest alone.
>     Use the continuous recovery plan for causal identity from its own verified Load.

### `project_inspect_controller_control`

重验控制审阅。

只读本地精确动作/源/包/目标；不批准。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Revalidate exact control source/package/target/action review; never approve.

### `project_execute_controller_control`

经确认的一次 Stop/Start。

人工或MCP控制收据；请求与完成分开，无自动逆动作/重发。独立 Start 缺已加载身份时拒绝。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Consume a separate operator control receipt and send at most one action.
> 
>     No automatic retries/inverse control. A standalone Start without proven loaded
>     identity is refused; recovery-plan Start uses its continuously held Load proof.

### `project_test_controller_control`

本机控制状态机。

生产控制 codec/client 与本机 TLS；覆盖前态、延迟、错误、丢回复和身份。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `action` | string | 否 | `"stop"` |
| `fault` | string | 否 | `"none"` |
| `start_kind` | string | 否 | `"cold"` |

`action` 枚举：`stop`、`start`。

`start_kind` 枚举：`cold`、`warm`、`hot`、`restore_warm`。

实现描述（原始工具说明）：

> Use production control codec/client with a fresh 127.0.0.1 TLS peer.
> 
>     Local proof only, including wrong states, lost replies, timeouts and identity.

## 操作者审批与显式恢复

### `project_inspect_operator_approval`

授权生命周期检查。

检查四类操作的人工或MCP授权收据，不连接设备。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `kind` | string | 否 | `"download"` |

`kind` 枚举：`download`、`control`、`recovery`、`instrumented_fault`、`lease_reconciliation`、`audit_export`、`reboot`。

实现描述（原始工具说明）：

> Inspect operator receipt lifecycle; cannot issue, renew or approve anything.
> 
>     The issuer may be MCP-managed or the optional interactive operator terminal.

### `project_authorize_controller_operation`

MCP自主授权。

MCP自行决定并签发精确限时一次性授权；kind支持download/control/recovery/instrumented_fault，无需人工终端。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `reason` | string | 是 | — |
| `kind` | string | 否 | `"download"` |
| `lifetime_seconds` | integer | 否 | `900` |

`kind` 枚举：`download`、`control`、`recovery`、`instrumented_fault`、`lease_reconciliation`、`audit_export`、`reboot`。

实现描述（原始工具说明）：

> MCP decides and issues exact one-use authorization; no human terminal required.
> 
>     Supports download, Stop/Start, whole recovery and instrumented fault reviews.
>     Revalidates source/package/target/actions and records mcp_policy as issuer.
>     No device I/O here; use the corresponding executor after this returns ready.
>     Existing consumed/denied/revoked/expired records are never overwritten.

### `project_prepare_stopped_recovery`

准备停止零写入恢复交接。

本地核验旧Stop成功、零传输失败和已消费授权；必须显式选择恢复源/包/配置/RAM策略。返回普通recovery计划，独立授权后原子交接租约并完整恢复。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `execution_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `restore_project_id` | string | 是 | — |
| `restore_project_sha256` | string | 是 | — |
| `restore_package_job_id` | string | 是 | — |
| `expected_configuration` | object | 是 | — |
| `volatile_data_policy` | string | 是 | — |
| `operation_id` | string / null | 否 | `null` |
| `maximum_runtime_observations` | integer | 否 | `12` |
| `runtime_observation_interval_seconds` | integer | 否 | `5` |

实现描述（原始工具说明）：

> Prepare an explicit full-package recovery after confirmed Stop and known zero transfer.
> 
>     Local only. Validates consumed old authorization, closed terminal journal and released execution lock.
>     Restoring source/package/configuration must be explicit. Inspect with project_inspect_stopped_recovery,
>     authorize kind=recovery against returned restore project/plan hash, execute project_execute_recovery.
>     Endpoint lease is atomically handed over during execution. Never infer memory identity or auto Start.

### `project_inspect_stopped_recovery`

检查停止恢复交接。

本地重验旧终态、闭合日志、授权和租约字节及新恢复包；不连接PLC。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Revalidate the exact old stopped failure and new full recovery locally, before authorization.

### `project_preflight_recovery_download`

完整下载只读预检。

传children.download的review；与实际传输共用路径、旧文件及原生库策略，允许稳定Running或Stop，差异有条数/字节限额。不授权写入。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Run the same strict file/native-library policy used before Stop and before transfer.
> 
>     Pass a download review (recovery plan children.download), not the parent recovery hash.
>     Bounded pinned read-only connections; no write authorization, Stop, Reset, Load or Start.

### `project_prepare_recovery`

显式原工程恢复计划。

独立版本化 Stop/下载/回读/Reset/Load/Start/变量核验计划；绑定RAM政策和配置期望，不是自动回滚。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `port` | integer | 否 | `41100` |
| `volatile_data_policy` | string | 否 | `"require_drain"` |
| `expected_configuration` | object / null | 否 | `null` |
| `start_kind` | string | 否 | `"cold"` |
| `expected_initial_state` | integer | 否 | `3` |
| `maximum_runtime_observations` | integer | 否 | `3` |
| `runtime_observation_interval_seconds` | integer | 否 | `5` |
| `audit_duration_seconds` | integer / null | 否 | `null` |
| `audit_closure_mode` | string | 否 | `"raw_tail"` |
| `audit_tail_seconds` | integer | 否 | `10` |
| `audit_fact_mode` | string | 否 | `"legacy_v1"` |

`volatile_data_policy` 枚举：`require_drain`、`record_unknown_loss`。

`start_kind` 枚举：`cold`、`warm`、`hot`、`restore_warm`。

`audit_closure_mode` 枚举：`raw_tail`、`source_cohort`。

`audit_fact_mode` 枚举：`legacy_v1`、`decision_clock_slots_v2`。

实现描述（原始工具说明）：

> Prepare an explicit original-project recovery with separately reviewed Stop/Load/Start.
> 
>     audit_fact_mode='decision_clock_slots_v2' explicitly binds the six new raw scalars
>     and runtime schema guard. Independent clock/slot verification remains external.
>     audit_closure_mode='source_cohort' fixes source N and waits at most audit_tail_seconds
>     for admitted source associations while continuing raw export. No delivery attestation.
>     Optional audit_duration_seconds (1..120) binds a child audit: pre-arm before Start,
>     observe the new boot and export immediately under the parent lease before business checks.
>     No network/approval. Includes exact file/memento effects, RAM-loss policy,
>     configuration expectations and runtime read plan. Never automatic rollback.

### `project_inspect_recovery`

重验恢复及子审阅。

重新检查所有源/包/控制/读计划身份；不批准或操作设备。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Revalidate recovery plan and all exact child source/package/control/read bindings.

### `project_execute_recovery`

经确认的完整恢复执行。

连续端点租约、人工或MCP recovery 收据；严格区分包加载、运行窗口与外部 DATA/STORED/采样验收。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Execute a human- or MCP-authorized recovery plan, under a continuous endpoint lease.
> 
>     Observe/Stop/write/readback/Reset/Load/Start/runtime checks; preserve uncertain
>     effects and quarantine. No retry, automatic fallback, or external Hub proof.

### `project_test_recovery`

本机完整恢复验证。

仅本机测试端或夹具；每阶段副作用、不确定结果、日志和恢复状态分别记录，不证明真实恢复。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `fault` | string | 否 | `"none"` |

实现描述（原始工具说明）：

> Test the whole recovery flow on one owned 127.0.0.1 TLS peer only.
> 
>     Includes continuous lease, Stop/write/readback/Reset/Load/Start/runtime reads.
>     PUBLIC fixture approval cannot authorize external endpoints or real operation.
>     Business DATA/STORED/mock acceptance is not inferred from the local fixture.

### `project_start_recovery_job`

启动后台受控恢复作业。

复用精确恢复计划与一次性消费门禁，返回operation_id；不是立即完成或批准。连续租约和不确定结果纪律不变。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `plan_id` | string | 是 | — |
| `expected_plan_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Start a fixed recovery worker and immediately return an inspectable operation ID.
> 
>     The worker consumes the normal exact independent approval; this tool issues none.
>     Persistent cancellation stops future actions/polling, never reverses sent actions.

### `project_start_controller_control_job`

启动后台受控控制作业。

仅运行既有精确Stop/Start消费者；不接受任意回调、原始RPC或自动重启。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Start a fixed Stop/Start worker using the normal separately approved control review.
> 
>     No raw RPC or callable input. Start still requires verified loaded identity.

### `project_controller_operation_status`

读取本地作业进度。

精确operation/review绑定，只读本地状态与可选结果，不访问设备；宿主失效保留outcome_unknown。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `operation_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `include_result` | boolean | 否 | `false` |

实现描述（原始工具说明）：

> Read exact operation progress/result, recognizing lost hosts and reused PIDs.
> 
>     A lost host or missing terminal receipt is unknown, not an automatic restart.

### `project_cancel_controller_operation`

请求协作取消作业。

持久化取消标记，在执行器检查边界生效；不是设备回滚、已发送动作撤销或自动逆控制。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `operation_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |
| `reason` | string | 否 | `"operator_requested"` |

实现描述（原始工具说明）：

> Persist a precise operation cancellation request, including across MCP processes.
> 
>     Does not send Stop/Start, retry, roll back or clear any approval claim/lease.
>     Read the terminal result to distinguish cancelled-before-action from uncertainty.

## 有界故障控制与监督

### `project_prepare_fault_control`

受限故障审阅。

boot/包/TTL绑定；原32POU未提供独立硬截止后端时返回 unsupported，不能借私有写入绕过。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `expected_boot_id` | string | 是 | — |
| `fault` | string | 是 | — |
| `ttl_ms` | integer | 是 | — |
| `port` | integer | 否 | `41100` |

`fault` 枚举：`agent_connection_offline`、`business_ack_blocked`。

实现描述（原始工具说明）：

> Prepare a boot/package/TTL-bound fault review; no activation or device access.
> 
>     The unchanged restore archive has no verified independent expiry hook, so real
>     activation remains unsupported. No shared Hub/broker/mock is stopped.

### `project_execute_fault_control`

故障执行安全门禁。

当前普通原归档缺验证过的独立TTL后端，必须拒绝且不消费收据/不操作目标。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Refuse real fault activation without a verified independent hard-TTL backend.
> 
>     No receipt consumption, variable writes or network request on unsupported source.
>     A finally block is not an independent expiry mechanism after host failure.

### `project_test_fault_supervision`

独立监督进程本机测试。

127.0.0.1 子进程监督，含客户端真实退出；本地解除不等于真实 PLC 自TTL已验。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `fault` | string | 否 | `"none"` |

`fault` 枚举：`none`、`client_exit`、`cancel`、`boot_change`、`release_failure`。

实现描述（原始工具说明）：

> Test an independent 127.0.0.1 supervisor process, including real client-process exit.
> 
>     Public synthetic booleans only; never touches PLC, shared services or P06 load.

### `project_create_fault_profile`

创建独立自TTL故障测试副本。

仅精确支持的原归档生成独立插桩Program/profile；不改32POU恢复源，不自动部署或启用场景。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `source_path` | string | 是 | — |
| `expected_source_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Create a separate instrumented copy of the exact supported original archive.
> 
>     Adds PLC-scan-owned boot/deadline/TTL release and exact Agent/ACK gates.
>     Never changes the original or deploys the instrumented copy. It is not the
>     unchanged original-project recovery candidate and does not establish P06 cost.

### `project_prepare_instrumented_fault`

审阅独立自TTL故障。

仅显式profile/source/package/boot绑定和绝对期限；原归档无后端仍拒绝，不与恢复包混用。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `expected_profile_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `address` | string | 是 | — |
| `expected_certificate_sha256` | string | 是 | — |
| `expected_boot_id` | string | 是 | — |
| `fault` | string | 是 | — |
| `ttl_ms` | integer | 是 | — |
| `port` | integer | 否 | `41100` |

`fault` 枚举：`agent_connection_offline`、`business_ack_blocked`。

实现描述（原始工具说明）：

> Prepare exact fixed-field fault authority for an explicitly instrumented profile.
> 
>     Separate source/profile/package/boot/deadline/pin/action review; not approval.
>     Original unmodified archives remain unsupported; no shared-service shutdown.

### `project_inspect_instrumented_fault`

重验自TTL故障审阅。

本地检查精确插桩profile、源、包、目标、boot与动作；不批准、不激活。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Revalidate instrumented fault source/profile/package and exact action bindings.

### `project_execute_instrumented_fault`

经确认的自TTL故障执行。

独立instrumented_fault收据，窄字段/值与TTL/绝对到期，staging前实读核钟推进，读回激活/解除；仅新版GET_MICROSECONDS(TRUE)/1000核内CLOCK_MONOTONIC profile，旧TON profile拒绝。真实故障需单独授权，真机期限未验。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Consume independent instrumented-fault approval; stage exact fields and Commit once.
> 
>     Must observe the deployed profile/boot; PLC scans enforce the fixed deadline
>     independently of host survival. No arbitrary writes/Force, inverse retry or
>     actual activation on the unchanged recovery archive.

### `project_start_instrumented_fault_job`

启动后台自TTL故障作业。

仅独立profile/boot/包/动作审阅及收据的固定消费者；可用作业状态/协作取消，PLC自截止独立于宿主存活。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `review_id` | string | 是 | — |
| `expected_review_sha256` | string | 是 | — |

实现描述（原始工具说明）：

> Start only the fixed separately approved instrumented-fault worker.
> 
>     Returns a job ID for progress/cancellation; no arbitrary variable writer.
>     PLC-scan hard deadline remains independent of the frontend/worker lifetime.

### `project_test_instrumented_fault`

本机自TTL故障验证。

独立本机扫描/双端测试，包括Commit后客户端退出和晚启动过期拒绝；不证明真实PLC扫描期限。

| 参数 | 类型 | 必填 | 默认值 |
|---|---|---|---|
| `project_id` | string | 是 | — |
| `expected_project_sha256` | string | 是 | — |
| `expected_profile_sha256` | string | 是 | — |
| `package_job_id` | string | 是 | — |
| `fault` | string | 否 | `"none"` |
| `kind` | string | 否 | `"business_ack_blocked"` |

`kind` 枚举：`agent_connection_offline`、`business_ack_blocked`。

实现描述（原始工具说明）：

> Test the fixed fault backend and PLC-scan model on an owned 127.0.0.1 TLS peer.
> 
>     Exact instrumented source/profile/package only; no real hook deployment or
>     fault activation, shared service changes, approvals or P06 acceptance.

## 嵌套结构与返回值

`project_update_pous.updates[]` / `project_change_fbs.updates[]` 每项要求 `pou_name`、`expected_code_sha256`、`expected_variables_sha256`，至少提供完整 `code` 或 `variables`。省略的文本保持。

`add_fbs[]` 为 `pou_name` 和可选 `code/variables`；`delete_fbs[]` 为名称。`add_tasks[]` 及 ownership 请求见 [多任务说明](independent-multitask.md)。

读取/恢复/时序的嵌套计划和观测身份见 [联调指南](joint-implementation-user-guide.md)，不要猜测字段或把旧报告当新鲜状态。

没有统一强类型 outputSchema 时，按当前工具返回的 status/诊断、已发送动作、不确定标记及 report_path 检查；不要要求所有工具返回同名 success。

