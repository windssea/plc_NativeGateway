# 2026-10-26 NativeGateway 真机重试

目标：192.168.0.8:41100，固定 TLS 指纹；匿名认证。使用冻结恢复工程副本，32 POU，49 文件，9,193,238 字节。源 SHA256：7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154。包清单 SHA256：c83ee20636924cfb29d9459127d77a88f4cbdbe444613a092f0bf373ec69a4cf。

## 结论

独立 MCP 的文件传输、SHA-512 回读、Reset、Load、Cold Start 链路已在该设备/该包验证，最终为 Running（raw=3）。无 ACI、无 computer use。此次用户手动恢复后的首轮有效传输改写 15 文件并跳过 34 个相同文件；最后启动成功的一轮全部文件相同，因此写入 0 文件，重新读取校验 49 文件并执行 Reset/Load/Cold Start。

配置核验：版本 13、50 个设备、250 个点位、enabled=true。启动后的追加只读结果为 250 个 BAD_CONNECTION。程序下载和启动成功，但采集及外部 DATA/STORED 联调未通过，不报告完整业务恢复。未修改用户源码；未重复停机排查业务连接。

## 修复

- 原厂枚举 Hot/Warm 标志不应被当成错误，仍拒绝未知/错误/强制等标志。
- 允许保留有限的 Src/Project.src 和单个 Src/*.pcweax 工程备份；不删除远端文件，不保证旧源码备份与新运行包一致。
- 先比较全部文件，跳过 SHA-512 相同内容，避免重复截断正在映射的原生共享库。不同内容的原生库更新仍拒绝，尚未支持其卸载流程。
- 全部文件相同时，启动因果证明允许没有 WriteMany，但必须有全部文件比较/回读、同计划 Reset/Load、连续租约、日志哈希和新鲜设备状态/工程名证据。

## 证据

- [硬件调用报告](../artifacts/original-recovery-hardware/1273d52e0f9e45c99896aa935c359704/result.json)
- 执行报告：D:/PLCnext-MCP-Workspace/17ae4361baa846868b14775bf1de15ea/controller-recoveries/71d9ff1bdc624fd3a7913bdeae36c038/result.json
- 追加只读：D:/PLCnext-MCP-Workspace/17ae4361baa846868b14775bf1de15ea/runtime-observations/30f592b88030478bab7fc3eb9103ca4f/result.json

执行状态 original_loaded_verification_incomplete 是点位业务验收未通过，不是 Load 或 Start 失败。原历史错误结果不覆盖，已知前序客户端误判经新鲜状态和原日志核验后归档租约，再发行新计划。最后业务不完整的租约仍保留。

回归验证：521 项中 520 通过、1 跳过；69 工具参考与当前服务 schema 一致。[测试日志](../artifacts/joint-implementation/full-tests-hardware-retry-final.log)。
