# ACI 的授权、通信安全和在线操作实现

分析日期：2026-10-26。对象是本机 PLCnext Engineer 2026.0.4，程序集构建 9.0.373.0。本节只解析磁盘上的 PE/CLI 元数据和 CIL；没有启动 Engineer、构造厂商客户端、读取实际证书库、激活许可、连接或操作 PLC。此前 ACI 离线往返实测见 [aci-poc.md](../aci-poc.md)，不能替代本节在线操作的运行验证。

## 证据身份

以下 token 均是相应 SHA-256/MVID 下的本构建坐标，跨版本不能直接复用。

| 程序集 | SHA-256 | MVID | REA Evidence |
|---|---|---|---|
| Ade.ApplicationControl.ServerImpl.dll | `2472a11f283c04abae006b27ab883d435e9c0eb6dabb5c8e935977e37d05e628` | `21257623-89d2-4006-abde-ab3108addefe` | artifact `ev_239d56757e0a410d25c7ed6b367100601bac3a80f4d9262f3598e1a1a9c4c6d0`；members `ev_670357749e9e03c5dbb6ced106222bdaeb512f8082a26a9e3afdac609d9bbad4` |
| Ade.ApplicationControl.Communication.dll | `cf5f7620d4b4fb973f587bba098ec1c6305c71828a4782b9a14a6c5ab0853bfd` | `a242a5cf-3a8b-4306-b12a-d74b3b52b721` | artifact `ev_93bbe0b63617d50f3771437dfc20d03ff5a91def9435ee37f77182e6c30a388d` |
| Ade.ApplicationControl.ClientImpl.dll | `f0191c438eb6a48a31a1dc3d62859e382e87f9577395176cc447d752e01ecf42` | `909b5c50-ea98-4eaf-be66-d45d4ccf79a6` | artifact `ev_98d8889feedd449bd8303ad4e608b99bf338e57e39f5c1e39f4085da31309de4` |
| Ade.ApplicationControl.dll | `80f3e5df6dcc8ffc22c0cf0a566c2693b1b59037bb62e29ab8ec1ec31fb7fc11` | `f252f828-6184-4a72-9e22-d6f25af03846` | artifact `ev_b4657922295cab50f1059bb85ff68ae12825e42524913df02c3fe78dc2021a4e` |

REA 原记录见 [server-project-rea-evidence.json](../../artifacts/aci-analysis/server-project-rea-evidence.json)、[public-client-rea-artifacts.json](../../artifacts/aci-analysis/public-client-rea-artifacts.json)。完整可读 CIL 来自只加载 Mono.Cecil 解析器、不执行被分析程序集的 [Inspect-ManagedIl.ps1](../../tools/Inspect-ManagedIl.ps1)；服务端全量 1,292 方法在 [security-online-il.json](../../artifacts/aci-analysis/security-online-il.json)。客户端和通信层使用同目录的 `public-client-Ade.ApplicationControl*.json` 全量清单。下面标为“观察”的是静态代码事实，不是声称已在运行时触发。

## 许可和接口启用：业务服务在启动时按状态注册

**观察**：`ApplicationControlServerComponent.OnImportsSatisfied`（ServerImpl `0x06000391`）注入 Engineer 的编译器、工程服务、在线上下文、网络、ESM、变量、虚拟文件系统等服务，创建 Facade/ObjectModelManager，读取 `AciStates`，并设置 ComponentFramework 的 `IsApplicationControlInterfaceEnabled`。`AciStates`（`0x06000394`）从位掩码 15 开始，逐项消除阻塞位：

| 位 | 公共枚举名 | 本构建判断 |
|---|---|---|
| 0 | `Okay` | 所有阻塞位均已消除 |
| 1 | `NotAvailableInUserInterfaceMode` | `ShowUI` 为 false 时消除；`IsEnabledForUI`（`0x06000395`）固定返回 false |
| 2 | `NoLicenseAvailable` | `ILicenseCheck.IsLicensed((LicenseId)2)` 为 true 时消除 |
| 4 | `NotEnabledInOptions` | `ApplicationControlConfiguration.Enabled` 为 true 时消除 |
| 8 | `AlreadyInUseByAnotherInstance` | ComponentFramework `IsRestricted` 为 false 时消除 |

`ApplicationControlServer.Start(states)`（`0x06000346`）始终准备 `localhost` 上的 TLS gRPC，并注册只提供可用性/产品/状态等的 `ApplicationControlService`。**只有 `states == Okay` 才注册 Application、Project、OnlineChannel 及其他业务服务**。当位 8 存在时，上层直接不调用 `Start`。因此“31172 正在监听”和“IsInitialized 返回 true”均不能证明 ACI 可用。`IsAvailable`（`0x0600039f`）检查构造时保存的 `states == 0`，`GetStates`（`0x060003a6`）返回该保存值。

**边界**：这是启动时的 ACI 服务注册和状态快照。该层没有逐请求再次 `IsLicensed` 的调用；不能由此推断厂商授权系统、底层功能或长期运行进程在试用到期后的全部行为。本轮没有修改或绕过任何检查。MCP 应通过正常客户端检查可用性，失败时报告具体阻塞位。

启用配置实际委托给 `Ade.Security.dll` 的 `ApplicationControlConfiguration.ReadConfiguration`（`0x060002a1`）：读取配置名 `ApplicationControlConfiguration`、origin 数值 2；不存在时默认端口 **31172**，默认 `Enabled` 为 false。证据 [security-online-configuration.json](../../artifacts/aci-analysis/security-online-configuration.json)，SHA-256 `2b83a1b9c854b969981cb982a790bd4ee658fdc9d07025a2e6eade8f9926991b`，MVID `514545e2-326f-445b-8a3f-6a059a3ca530`。此处未执行其写入方法，也未解析该 origin 到实际注册表/文件路径。

`Ade.Core.dll` 的 `ILicenseCheck.IsLicensed` 是接口声明；`Ade.LicensingImpl.dll` 的 `LicenseManager.IsLicensed`（`0x06000021`）在本次过滤结果没有可读 CIL 方法体，未继续推断其底层有效期策略。只确认 ACI 显式依赖该厂商许可接口，不把 14 天试用规则伪装成在这几个 ACI DLL 中自行实现的计时器。

## 本构建使用 mTLS，DPAPI 保护证书库

**观察**：静态调用链中的认证是客户端证书，而不是从安全指南描述直接推定的 HTTP cookie。

1. Communication `CertificateStore..ctor()`（`0x06000020`）拼出 `%APPDATA%\PHOENIX CONTACT\Application Control\CertificateStore.bin`。`CertificateStoreCore`（`0x06000022`）在文件不存在时创建，再读取；根证书不在有效期时重建证书库。
2. `CreateCertificateStore`（`0x0600002d`）创建 `CN=gRPC CA`、`CN=localhost` 服务端证书、`CN=gRPC Client` 客户端证书，将 CA/server/client 公钥证书和 server/client 私钥以命名 PEM 项序列化保存。
3. `Encrypt/Decrypt`（`0x06000030/31`）调用 Windows `ProtectedData.Protect/Unprotect`，scope 数值 0，即 `CurrentUser`，无额外熵。这里只读取代码，没有读取或导出用户实际私钥。
4. ServerImpl `GetServerCredentials`（`0x06000348`）将服务端证书和私钥、根证书交给 `SslServerCredentials`，client certificate request type 数值 4，要求并验证客户端证书。
5. ClientImpl `ServiceManager.CreateSecureChannelOptions`（`0x06000150`）正常创建同一厂商 CertificateStore，将客户端证书及私钥交给 HttpClientHandler，关闭代理。验证回调 `0x06000187` 使用 `X509ChainTrustMode.CustomRootTrust` 和库内 CA 再 `Build(serverCertificate)`。随后以 `Grpc.Net.Client.GrpcChannel.ForAddress` 建立连接（`0x0600014f`）。

**推断**：合法 ACI 适配器应在相同 Windows 用户下复用厂商客户端和证书管理，不应自行复制凭证/重写信任规则。Windows 服务账户、跨用户调用、容器部署的可用性尚未实测。代码中的自定义验证回调只返回 Chain.Build 结果，没有另外引用传入的 `SslPolicyErrors`；这是本构建实现描述，不是对全部部署环境的安全评估。

默认 `AttachToLocalServerClient` 使用 `https://localhost:31172`；可接受 host/port 重载。服务端显式绑定 `localhost`，不是由该构造重载就获得远程 ACI 服务。`StartServerClient.StartServer`（ClientImpl `0x06000172`）只调用 `Process.Start(serverFileName, arguments)`；调用者需自己给正确的 `/NOUI /NOSPLASHSCREEN` 等启动参数、绑定预期进程和完整生命周期，不能假定它自动以无界面方式启动。

## 在线接口完整映射

公共 `IOnlineChannel` 共 18 个方法记录，包含属性访问器和事件 add/remove；实际入口全量如下。服务器一律先按请求的对象 GUID 从 repository 找 OnlineChannel/Variable/Endpoint，再调用下面的对象模型和 Facade；GUID 是进程内对象句柄，不是跨进程永久设备 ID。

| 公共入口 | ServerImpl 对象模型 token | Facade/实际委托 | 完成和边界 |
|---|---|---|---|
| `Connect()` | `0x060002a7` | `FacadeOnlineChannel.Connect` → `IDeviceOnlineContext.Connect(true)`（`0x060000ce`） | 返回 bool；不是绕过设备权限的接口 |
| `Connect(userName, SecureString)` | `0x060002a8` | `IDeviceOnlineContext.Connect(userName, secret)`（`0x060000cf`） | 拒绝空 userName/null secret；gRPC 收 bytes，转换 SecureString，finally 清除临时 byte[]（`0x06000410`） |
| `Disconnect()` | `0x060002a9` | `IDeviceOnlineContext.Disconnect` 经 InvokeHelper | 返回 void |
| `Download(DownloadTypes)` | `0x060002aa` | `FullDownload/DownloadChanges` → `Task.Run` → `DownloadCore` → `IPlcService.DownloadProject(deviceName, fullDownload, includeSources)`（`0x060000bd/bf/d1`、`0x0600049d/4a0`） | 异步启动；立即返回 void；下载最终结果必须等事件 |
| `DownloadFinished +=/-=` | `0x060002a5/2a6` | Facade boolean → DownloadResult → OnlineChannel 事件 → gRPC server stream（`0x060000e7/2b9/42a/500`） | 成功 1、失败 2；调用链本身仅映射 bool。公共枚举也包含 Unknown=0/Canceled=3 |
| `Start(Cold/Warm/Hot)` | `0x060002ab` | `IDeviceControlService.CanColdStart/CanWarmStart/CanHotStart`，再 `ColdStartAsync/WarmStartAsync/HotStartAsync`（`0x060000d2/d3/d4`） | 枚举校验；Can* false 或服务缺失可能直接返回；需再读状态 |
| `Stop()` | `0x060002ac` | `CanStopExecution` → `StopExecutionAsync`（`0x060000d5`） | void；需后读状态验证 |
| `Reset()` | `0x060002ad` | `CanReset` → `ResetAsync`（`0x060000d6`） | void；改变设备状态 |
| `Restart()` | `0x060002ae` | 按可用上下文调用 Mona 或 PlcNext 专用 `RestartDeviceAsync`（`0x060000d7`） | void；不是 Start 的别名 |
| `GetControllerState()` | `0x060002af` | `IDeviceControlService.DeviceState`（`0x060000d8`） | 未连接默认 NotConnected；只映射已识别状态，未知状态也可落默认值 |
| `ReadVariable(IVariable)` | `0x060002b0` | 由实例链生成名称路径 → `IOnlineItemAccessService.ReadItemsAsync`（`0x060000d9/2b8`） | 非任意裸地址读；变量必须是对象模型变量；返回 object |
| `WriteVariable(IVariable, object)` | `0x060002b1` | 同路径生成 → `IOnlineItemAccessService.WriteItemsAsync`（`0x060000da/2b8`） | 拒绝 null variable/value；需验证读回，void 并不保证写已生效 |
| `ConnectionEndpoints` get | `0x060002b2` | 项目网络拓扑 TCP/IP 端点；受 SimulationSupported 判断的仿真端点（`0x060000e0/e1`） | 枚举不是连接；没有自动切仿真 |
| `ActiveConnectionEndpoint` get/set | `0x060002b3/2b4` | 按保存通信配置识别 active；set 调 `CommunicationSettingsHelper.WriteCommunicationSettings`（`0x060000dd`） | 修改工程通信设置；不是立即修改 PLC IP |
| `GetDeviceInfoAttribute(name)` | `0x060002b5` | `IAttributeAccessService<string>`，Mona/PlcNext，domain=`Info`（`0x060000cc/df`） | 拒绝空名；attribute 可用性取决于服务 |
| `GetDeviceStatusAttribute(name)` | `0x060002b6` | 同上，domain=`Status`（`0x060000cd/df`） | 不能仅由入口字符串枚举断言所有设备支持的属性 |

`DownloadTypes` 为 flags：`None=0`、`Full=1`、`OnlyChanges=2`、`IncludeSources=4`。ServerImpl `OnlineChannel.Download` 先校验枚举，再取 `IncludeSources`，先判断 `OnlyChanges`，否则判断 `Full`，两者都没有时抛错。MCP 最好只暴露 `full`/`changes` 二选一和独立 `include_sources` bool，避免把所有 flags 组合无约束交给模型。

`StartType`：`Cold=0/Warm=1/Hot=2`。`ControllerState`：`NotConnected=0/Ready=1/Stop=2/Running=3/Halt=4`。这些 ACI 枚举与具体 PLC 协议/固件原始状态值不能仅因某几个数字相同就视为完全等价。

TCP/IP endpoint 的 IP/subnet/gateway setter 最终是修改项目拓扑 property，并标 `SolutionModified=true`（FacadeTcpIPConnectionEndpoint `0x06000028`），缺少相应 property 时直接返回。它们不是“远程网络配置下发”命令。冗余 S2 控制器端点还有 Physical First/Second 或 Backup 分支；只用单 AXCF2152 样例无法证明其实际表现。

## 不能在 MCP 中抹掉的完成语义

**观察**：Facade 通过 `ISynchronizeInvoke`/`InvokeHelper`（`0x0600015a`）将操作封送到 Engineer 线程，并传回 `InvokeResult.Exception`；本质上依赖 Engineer 服务容器，不是独立的 PLC SDK。

`Download` 的 gRPC unary 返回 `Empty`（`0x06000412`），只说明触发调用返回。完成路径为后台 `DownloadProject` 返回 bool → `OnDownloadFinished` → `OnlineChannelService.downloadFinishedResponse` → `ManualResetEvent` → server stream。响应只含 `DownloadResult`，没有工程、onlineChannel 或 job correlation ID；stream 请求是 `Empty`。ClientImpl 在首个订阅者注册后后台开启 stream（`0x060000d0/d2/17b`），不提供单独的订阅就绪握手。

该服务端使用单个 response 字段和单个 reset event，并非逐 job 保留的通知队列。静态代码还可见 continuation 直接读取 `Task<bool>.Result` 后才通知（`0x0600049e/4a1`）；若后台任务异常，是否有独立通知不能在这段路径得到保证。这不是声称运行时已复现通知丢失，而是 MCP 设计必须覆盖的超时/不确定状态。

`ExecuteOnService`（`0x060000e3`）在 service 不存在或 `CanExecute()` 为 false 时返回 `default(T)`；void async 版本（`0x060000e4`）直接返回。由此**不能以 RPC 没有异常，或返回 false/default，就推断唯一的设备失败原因**。启停后的状态读回、变量写后的读回、明确的 `accepted/completed/unknown` 分离，是适配器应补的行为。

## MCP 参考约束和未完成验证

建议复用厂商 ClientImpl，在 Windows 当前用户下通过受控后台进程正常连接。许可缺失/未启用/UI 模式不支持/实例限制分别返回明确诊断；不复制厂商服务端来绕过这些约束。

同一 Engineer 后台进程串行运行改变工程或设备的任务。订阅完成事件在触发之前，超时后报告 `unknown` 并保留后台状态，不自动重复下载。不要把取消 MCP 等待等同于取消已开始的设备操作。对下载、启动、停止、重启、复位和变量写分别提供明确权限开关与调用审计；默认离线参考实现不暴露这些可执行入口。

| 问题 | 覆盖状态 |
|---|---|
| 授权/启用/启动注册链 | 静态回答；CodeMeter 有效期内部策略未还原 |
| 当前 ACI 客户端和服务器 TLS 认证 | 静态回答；未读取实际证书/未握手 |
| IOnlineChannel 全部入口/枚举/委托服务 | 静态回答；未操作设备 |
| Download 的实际服务调用与完成事件 | 静态回答到 Engineer `IPlcService.DownloadProject`；其内部构建/传输链由独立下载研究覆盖，非本节全量穷尽 |
| 真实 PLC 下载、在线变更、变量写、Start/Stop/Reset/Restart | 未运行；没有来自本轮的设备效果验证 |
| 跨用户、远程 ACI、并发多订阅、异常丢事件 | 静态指出设计边界；需要独立运行验证，不能称已证实问题 |

