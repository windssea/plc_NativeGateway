# MCP 自主授权：0.6.1

2026-10-26，用户明确要求“移除这个限制，mcp可以自行决定”，因此取消必须由独立人工终端签发的要求。当前 MCP 可自行准备、检查、授权和执行设备操作，无需另一次人工确认。

调用顺序：准备对应审阅或恢复计划 → `project_authorize_controller_operation` → 对应执行工具。授权工具只做本地核验和发行，不连接 PLC。

```json
{"tool":"project_authorize_controller_operation","arguments":{"project_id":"<PROJECT_ID>","review_id":"<REVIEW_OR_PLAN_ID>","expected_review_sha256":"<FULL_SHA256>","kind":"recovery","reason":"本次操作的目标与决策依据","lifetime_seconds":900}}
```

| kind | 准备 | 执行 |
|---|---|---|
| download | project_prepare_download_review | project_execute_controller_download |
| control | project_prepare_controller_control | project_execute_controller_control |
| recovery | project_prepare_recovery | project_execute_recovery / project_start_recovery_job |
| instrumented_fault | project_prepare_instrumented_fault | project_execute_instrumented_fault / project_start_instrumented_fault_job |

恢复计划的 plan_id/plan_sha256 传给授权工具的 review_id/expected_review_sha256。默认有效期 900 秒，允许 1…3600 秒。MCP 收据使用 `mcp-approval/v1` schema、`confirmed_by=mcp_policy`、`authorization_channel=mcp_managed`，如实记录来源。可选人工终端仍可使用原收据格式。

精确源/构建/包/目标/动作绑定、完整性核验、一次领取、端点互斥和审计继续有效。已经消费、撤销或过期的旧记录不覆盖；新的明确操作使用新审阅。取消人工签发要求不把错误状态改成成功，也不自动重发结果未知的写入。

本机 Codex 的注册仍指向 editable 源码。新 MCP 连接读取 0.6.1，共 69 个工具。已经运行的旧 MCP 进程需要重新连接才能发现新工具。[Schema](mcp-tool-schema.json) / [实际参考](mcp-tool-reference.md)。

验证：516 项测试中 515 通过、1 跳过，[测试日志](../artifacts/joint-implementation/full-tests-0.6.1.log)。包含四类 MCP 收据、独立 schema、源/审阅变化拒绝、一次领取、Hot 标志的控制及完整传输。

最新真机重试（2026-10-26）：独立 MCP 已完成文件传输/回读、Reset、Load 和 Cold Start；最终 PLC 为 Running（raw=3）。指定冻结副本 SHA256 为 `7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154`，49 文件包清单 SHA256 为 `c83ee20636924cfb29d9459127d77a88f4cbdbe444613a092f0bf373ec69a4cf`。用户手动恢复后的一轮实际改写了 15 文件、跳过 34 个相同文件，49 文件均通过 SHA-512 回读；最终成功启动的一轮发现全部相同，写入 0 文件，再次回读全部 49 文件后 Reset/Load/Cold Start 成功。

修复了 Hot/Warm 正常状态标志、可选 Src 工程备份保留、跳过相同原生库，以及“全部文件相同时无写入事件”的加载因果校验。不同内容的原生共享库仍拒绝在线覆盖，需要另外验证卸载更新流程。

配置版本 13、50 个设备、250 个点位及 enabled=true 均匹配。启动后追加只读检查仍为 Running，250 个质量值为 `BAD_CONNECTION`；下载启动成功，但采集连接及外部存储联调尚未通过。恢复执行结果如实保持 `original_loaded_verification_incomplete`，没有伪装为完整业务验收通过。租约、收据和 journal 保留，未再次停机重刷。

[最新硬件报告](../artifacts/original-recovery-hardware/1273d52e0f9e45c99896aa935c359704/result.json)。运行读证据：`D:/PLCnext-MCP-Workspace/17ae4361baa846868b14775bf1de15ea/runtime-observations/30f592b88030478bab7fc3eb9103ca4f/result.json`。使用冻结工程副本，未修改用户工程；不依赖 ACI 或 computer use。

本次最终回归：521 项中 520 通过、1 跳过，[日志](../artifacts/joint-implementation/full-tests-hardware-retry-final.log)；69 工具 schema 检查一致。
