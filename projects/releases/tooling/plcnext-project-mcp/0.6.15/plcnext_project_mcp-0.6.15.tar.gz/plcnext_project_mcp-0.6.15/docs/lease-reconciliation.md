# M11 / M11-S：端点租约受控核销（0.6.3）

> 2026-10-28待修复：0.6.11发生“Stop成功、下载预检拒绝、文件零写入”，PLC停机且同步租约无法交接。优先恢复要求及精确execution/包/证据见[主线下载预检与停止零写入恢复缺口](主线下载预检与停止零写入恢复缺口-20261028.md)。该分支不属于下文已完成业务隔离或审计零ACK核销，不得据此声称已支持。

> 2026-10-27新增、待修复的另一类场景：[启动观测失效与外部恢复后的租约核销缺口](启动观测失效与外部恢复后的租约核销缺口-20261027.md)。它是已确认Load/Start后`verify_runtime`只读窗口失效的失败终态，且后续已由Engineer恢复stable/v15；不属于本文原先已交付的“completed、业务核验待补”分支。本文既有历史接收结论保持不变。

已公开 4 个核销工具，总工具数 73。适用场景：后台或同步 recovery 已完成且设备结果明确，但业务验证不完整而保留租约。后台分支要求终态 operation、匹配进程创建身份且宿主已退出；同步分支要求合法已消费授权、明确完成且业务隔离的结果、闭合日志和已知执行器终态协议。重新只读检查 Running、原配置和全部预期 GOOD 点后，归档精确旧租约。

当前范围不包括未知写入、活跃执行者、缺少合法授权或终态日志的执行。它们明确拒绝，不能用设备 Running 或进程退出单独作为清锁依据。不会自动重新刷入，也不撤销旧 claimed 或改写历史失败结果。

## 调用顺序

1. `project_prepare_lease_reconciliation(project_id, operation_id, expected_review_sha256, expected_certificate_sha256)`：传旧后台 recovery 的 operation ID 和完整恢复计划哈希；不是租约中的 Stop 子审阅哈希。创建计划并做只读观测。
2. `project_inspect_lease_reconciliation(project_id, plan_id, expected_plan_sha256)`：重验本地证据。
3. `project_authorize_controller_operation(project_id, review_id=plan_id, expected_review_sha256=plan_sha256, kind="lease_reconciliation", reason=...)`：MCP 自主发行精确一次授权，无需人工终端。
4. `project_execute_lease_reconciliation(project_id, plan_id, expected_plan_sha256)`：持端点互斥锁重新核验和只读观察，归档旧租约，落盘结果。

后续下载必须另行准备和授权。核销本身不授予新候选下载权限。

## 并发与中断

下载、控制、恢复的租约创建/释放与核销共用操作系统文件锁；进程退出时 OS 释放互斥锁。`.guard` 文件可以长期存在，不代表设备仍被隔离。持久化租约及 pending 核销标记仍阻止新任务。

核销先原子发布 intent 和一次 claim，再将旧租约重命名为唯一归档，原子发布结果后去掉 pending 标记。中途退出时，使用同一个核销 plan 再次 execute，可核验后完成剩余本地步骤；不会重放设备操作。若已完成，返回 replayed=true，不触碰任何新租约。缺少合法 claim、证据变化或出现不同 owner 时拒绝。旧授权过期且尚未成功领取时也拒绝继续。

锁的范围是同一 OS 用户、使用本版本实现的客户端；不控制外部 Engineer 或其他系统用户。新操作前仍须自己的新鲜预检和精确计划。旧 MCP 进程应重连，以加载一致实现。

## 本次现场验收

目标 192.168.0.8:41100；旧执行 `71d9ff1bdc624fd3a7913bdeae36c038`，旧后台 operation `bef5c48bfd8f4a3a8cfb1cbc4cdb3eec`。

通过全新 stdio 会话调用上述公开工具，版本 0.6.2、72 工具。核销计划 `3641ba9aed324a68a0f54fd21f1e965f`，SHA256 `f31ca3cbc5192ad1dee31cf7730c11aa0d2a5165558678cb70f90b184afa6485`。

结果：旧租约已归档，归档 SHA256 与旧租约一致；活动租约和 pending 标记已不存在。只读观测 Running，配置版本13、50台/250点、enabled=true，250/250 GOOD。没有 PLC 写入或控制动作。外部 DATA/STORED 收据不由本工具重新背书。

[公开工具验收记录](../artifacts/lease-reconciliation/d0cb6aca04354d5d9f669a54e72f8da6/result.json)。本机注册仍指向 editable 源码，重连 MCP 或重启 Codex 加载新工具，不需重启 PLC。

最终回归：532 项中 531 通过、1 跳过。[测试日志](../artifacts/joint-implementation/full-tests-m11-final.log)。新增 11 项核销测试覆盖精确归档、重放不碰新 owner、活跃宿主、未知结果、日志缺失/未闭合、错误 pin、证据变化、无授权、观测失败、并发互斥、归档前后崩溃续办及缺失 claim。

## M11-S 同步入口与观察窗口

`project_prepare_sync_lease_reconciliation(project_id, execution_id, expected_review_sha256, expected_certificate_sha256)` 接收同步 execution ID 和完整恢复计划哈希。后续继续使用现有 inspect、`kind="lease_reconciliation"` 授权及 execute 工具。计划明确记录 operation_id=null 和真实 execution_id，不创建或伪造 operation.json。

新恢复执行持有贯穿完整生命周期的 OS 执行锁，核销遇到活跃执行锁会拒绝。旧同步执行没有该历史锁：只接受结果 completed、outcome_unknown=false、receipt_persisted=true、业务隔离、已消费精确授权、Reset/Load/Start 已确认且 journal 最后为相同 ExecutionOutcome 的情况。依据已知执行器协议，此终态之后不再发设备 RPC；不会伪称具有历史 PID 证明。不满足条件则拒绝。

`project_prepare_recovery` 新增 `maximum_runtime_observations`（1..24，默认3）和 `runtime_observation_interval_seconds`（5..10秒，默认5），乘积不超过240秒。推荐启动较慢时使用12次、5秒间隔；观察窗口写入 policy 并绑定计划哈希和授权。整个操作仍受300秒总期限约束，文件传输及读取耗时可能减少可用观察次数。GOOD标准、PLC任务、采样与吞吐配置不变。

本轮通过新 stdio 会话确认 0.6.3、73工具，核销同步执行 `73f10fed2eb445abb00bddb76d6c2ad6` 的旧租约。只读确认 Running、配置13/50台/250点、250/250 GOOD；无 PLC 写入。设备仍为授时候选，本轮没有恢复原工程。[本轮公开工具证据](../artifacts/lease-reconciliation/c7728d663c3a412db031925cdcb254a0/result.json)。后续恢复应重新准备计划（可加长观察窗口）、授权并执行，不把旧失败结果改为成功。

0.6.3 最终回归：537 项中 536 通过、1 跳过，[日志](../artifacts/joint-implementation/full-tests-m11-sync-final.log)。包含同步授权/身份/活跃锁/未知结果拒绝及观察窗口边界测试；73 工具 Schema 与源码一致。
