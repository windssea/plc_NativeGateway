# 独立 MCP 完整替代 ACI：能力账本

更新：2026-10-26 / MCP 0.6.0；对照本机 Engineer **2026.0.4 / 9.0.373.0** 的公开契约。本账本覆盖 **56 个公共接口的全部 201 个显式声明方法**，保留重载、属性访问器、事件 add/remove 和方法 token。继承自 .NET collection 的成员保存在接口继承关系中，不人为增加方法数量。193 个 gRPC RPC 与这 201 个声明不是一一对应关系。

0.6 纳入独立审批、精确 Stop/Start、源绑定运行变量、显式恢复、限定多任务和独立故障 profile 的本机实现。各项真机验收仍分别记录；[三方实施指南](joint-implementation-user-guide.md)和[实际能力](../src/plcnext_mcp/server.py)保留支持范围。

**当前尚未完整替代 ACI。** 已实现的独立 ST 开发、限定编译/打包、只读设备状态和周期任务编辑都有明确范围；“读取过接口”“恢复了 protobuf”“模拟通过”均不算已完成设备功能。可选的 `examples/aci_mcp` 仍调用官方 ACI，完全不计入独立替代成果。

## 可执行账本

实现：[aci_parity.py](../src/plcnext_mcp/aci_parity.py)，随包数据：[完整 201 方法清单](../src/plcnext_mcp/aci_contract/aci_2026_0_4.json)。它只读取已保存证据，不加载厂商程序集、不启动 Engineer、不调用网络。

- `aci_replacement_summary()`：按能力域和状态汇总，显示依赖及优先级；`full_aci_replacement` 始终为 false。
- `aci_replacement_coverage(domain=None, status=None, offset=0, limit=40, include_details=False)`：分页列出方法，带真实 MCP 工具映射、范围、缺口和官方实现状态；开启 details 可读对应源码、执行证据及逐项验收条件。
- [清单生成器](../tools/build_aci_parity_manifest.py)：从之前保存的 ACI 静态元数据、已审查的原生实现和真实证据生成可重现快照。新增功能应同时更新清单及验收记录，不能只改状态标签。

例如 `domain="controller_download"` 会分开列出真实客户端的本机传输验证与尚未等价替代的完成事件；`domain="tasks"` 列出源配置、多任务增删及明确所有权范围，事件/安全任务仍未覆盖。

## 状态含义

| 状态 | 方法数 | 含义 |
| --- | ---: | --- |
| `independent_verified_supported_scope` | 11 | 独立可调用路径在明确限定范围内有执行证据；不表示兼容全部 ACI 场景 |
| `partial` | 56 | 有相关独立实现，但对象模型、格式、设备范围或行为仍不完整 |
| `research_only` | 21 | 有静态、oracle、模拟或诊断研究，尚未成为经过验证的等价功能 |
| `missing` | 90 | 没有该行为的独立替代实现 |
| `official_stub` | 4 | 当前仍按官方异常/恒值占位处理，不能复制空实现就算完成 |
| `contract_only` | 19 | ACI 特有生命周期/身份契约或隐藏接口，需要独立语义设计 |

这些数字是方法工作项分类，**不是功能完成率**。一个 Compile 方法覆盖的编译/运行配置工作远大于十个元数据 getter；也不能把“有限范围验证”和“与全部 ACI 等价”混为一谈。

官方静态事实独立保留：7 个 getter 直接抛 `NotImplementedException`，另一个槽位方法恒返回 0。独立周期任务读取已经覆盖其中 Interval/Priority/Watchdog/Comment 的有用源信息，因此这 4 项在独立状态上可变为已验证/部分完成；它们的 `official_behavior` 仍准确记录官方空实现。

## 当前各域的实际替代范围

| 能力域 | 独立 MCP 已做到 | 完整替代仍缺什么 |
| --- | --- | --- |
| 工程生命周期 | 从设备模板新建、导入副本、基于哈希的不可变版本保存；仓库外客户端重读 | 通用 PCWEF/SaveAs 格式和冲突语义、通用项目会话 |
| POU / FB | 读取标准 POU；标准 ST FB 增删；代码/变量/调用方同批编辑；有限引用保护 | 其他 POU/语言/安全类型、完整语义引用和符号重命名 |
| 变量 | 标准声明和接口编辑；类型白名单在线标量读取与250点窗口；固定故障 profile 字段受控写入 | 任意变量写/Force、完整在线对象类型/会话、所有 pragma/变量组/符号重命名 |
| 任务和程序分配 | ESM v2 源配置；周期参数；Program克隆及1..16独立周期任务增删/绑定；源/闭包哈希所有权合同 | 事件/安全任务、任意共享缓冲与其他设备、实际调度和物理I/O验证 |
| 编译和部署包 | 支持 AXC F 2152 / 2026 单资源单周期标准 ST 的源冷构建；限定 NativeGateway 的完整离线 PCWE | 更广设备/图形/安全/多资源、一般硬件/HMI 配置、设备接受与执行证明 |
| 实例和映射 | 有界 ST 引用搜索，所测配置运行布局及 ESM/DataList/HMI 绑定核验 | 通用任务→程序→嵌套库 FB→变量树；物理/安全 I/O 映射编辑和 CSV 交换 |
| 源码交换 | 原生 PCWEX ST 功能编辑 | 独立 IEC61131-10、PLCopen、AutomationML 的完整导入导出和冲突行为 |
| 库 | 编译时快照/校验/解析已有引用 | 原生 Add/Accept/Remove/Replace、完整 load/signature/version 状态与引用修复 |
| 硬件和设备属性 | 校验已支持配置，不默许未知配置 | 控制器替换、目录、槽位、设备/模块增删、参数/选项、Profinet/I/O 重建 |
| 编译选项 | 明确的固定编译配置和有效范围 | 三个 ACI 公开应用选项及更一般的项目局部选项模型 |
| 设备只读连接 | 实际 MCP 通过证书 pin、TLS/RSC、动态服务句柄读取 192.168.0.8 的 Running 状态，随后关闭 | 持久会话、凭据重载、其他协商 profile、Info/Status 属性和更广设备 |
| 下载 | 完整包检查、内存模拟、独立真实 TCP/TLS 客户端与本机 48 文件读写/Reset/Load，以及实机固定元数据只读预检 | 真设备写入/权限与接受、旧文件处理、在线变更/源下载和实机异常恢复；当前不会未确认就下载 |
| 启停/复位/重启 | 独立授权Stop/Start；精确原厂启动种类；治理下载内Reset/Load；连续租约恢复及丢回复处置 | 独立Restart/Reset与完整ACI语义、真机启停/输出/加载效果验证 |
| HMI / 过程数据 | 限定 NativeGateway HMI 生成和绑定核验 | 通用编辑；隐藏的 IHmiTag/IProcessDatum 声明不是可工作的官方客户端实现 |

“不通过 computer use”与“不依赖 ACI”是两个独立条件。当前原生编辑/编译/打包/任务配置已经同时满足这两个条件，但编译仍使用本机厂商编译库和项目引用包；这不等于调用 ACI，也不等于已经实现一套通用独立 IEC 编译器。

## 本轮纳入的执行证据

1. [真实只读 MCP 连接](../artifacts/controller-readonly-mcp/4d159ee2b094406f95f0157274f0eb8e/result.json)：只发送 Connect、固定 PLC manager 服务查找、GetPlcState，使用动态句柄，结果 Running；未认证会话、文件、配置、启停或下载。
2. [61 POU 任务配置副本](../artifacts/task-configuration/result.json)：周期 20→25 ms、看门狗 500→750 ms、优先级 0→2；只有 ESM 数字属性变化，ID/MainInstance/其他映射保留，实际冷编译及运行 ESM 检查通过。不是设备调度实测。
3. [既有综合离线 MCP](../artifacts/final-audit-e2e/54086508fc07409f8571c1ee24540fcf/result.json)：61→62→61、源编译、48 文件包和 16 个离线下载场景。模拟不升级为真实下载证据。
4. [新工程跨项目](../artifacts/codex-registration/1448b81b96bf4709a2f28178984c03e1/result.json) 和 [全 POU/接口修改](../artifacts/cold-compile-mcp-e2e/1bd4056b36054ce2b13394d2fb622515/result.json)。
5. [本轮 30 工具 MCP 全链](../artifacts/independent-aci-mcp/88aca674c55b444cad806d12a69583d8/result.json)：任务参数修改后重新冷编译 61 POU，生成 48 文件包，通过 tagged TLS 模拟及回读损坏拒绝；没有真实设备写入。
6. [0.5 实际 socket 客户端](controller-download-client.md)：48 文件本机 TCP/TLS 写/读/Reset/Load、独立确认门禁、35 工具中的实机只读预检；仍不构成真实 PLC 下载已验收。

账本自身 [6 项测试](../tests/test_aci_parity.py) 验证全部 token/签名/重载对齐、真实工具映射、官方 stub 与隐藏接口不误判、分页/过滤、返回副本隔离和无外部执行。它们验证账本诚实且可查询，不替代每项工程/设备功能的实测。

## 完整替代的验收顺序

1. **P0：真实部署闭环。** 明确源 revision 和包哈希→协商真实 controller profile→目标身份与写权限→文件传输及回读→配置加载→设备状态确认→中断/超时/断电后的收据与恢复。Full、OnlyChanges、IncludeSources 分别验收，不能用 Full 模拟覆盖三者。
2. **P1：一般工程开发。** 完整源码交换、类型/变量/实例/任务/映射模型、库生命周期、诊断、在线变量。每类改变都验证正例、拒绝例、源身份和保存重开后的映射。
3. **P2：工程覆盖扩展。** 新设备架构、硬件/协议/参数目录、图形/安全工程、HMI/过程数据及明确的会话兼容层。官方空实现可由独立实现补强，不需要复制其缺陷。

每项条目都有自己的 acceptance_checks。只有真实对应行为及预期失败处理均通过，才能改变该项状态；没有一个“启用完整替代”的开关。
