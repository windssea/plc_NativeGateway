# PLC 下载链路的 REA 实现与离线验证

2026-10-25，已完成认证、文件传输和配置加载的服务契约实现，并通过本机注册的 MCP 对当前 NativeGateway 副本完成离线验证。新增 `project_download_plan` 和 `project_simulate_download`，全局服务现有 **25 个工具**。

**当前实现是离线下载模拟，不是可连接真实 PLC 的下载客户端。** 实际执行了 TLS 1.2 内存握手、Connect、服务发现/动态句柄协商、二进制会话认证、文件/文件系统/配置方法的请求响应，以及内存设备上的写入、回读和状态流转。范围限定为 RSC v4、untagged、无 datagram、按已知方法 schema 消费一条调用的完整字节；通用流解析、其他协议 profile 和真实设备通道仍待实现。工具没有 PLC 地址、URL 或真实凭证参数，不创建 socket。

## 本轮实测

[真实注册 MCP 端到端结果](../artifacts/download-simulation-mcp-e2e/d02e22ddd3574233950757fc7de53d90/result.json)；
[正常流程详细结果](../artifacts/download-simulation-mcp-e2e/d02e22ddd3574233950757fc7de53d90/none.json)；
[源及部署包核验计划](../artifacts/download-simulation-mcp-e2e/d02e22ddd3574233950757fc7de53d90/plan.json)。

| 验证项 | 结果及证据性质 |
| --- | --- |
| MCP 调用 | 使用原 Codex 注册的 command/args/env，从仓库外目录启动真实 stdio；发现 25 工具 |
| 当前源 | 61 POU 副本，SHA-256 `e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0`，前后不变 |
| 包 | 48 文件、9,370,814 字节；绑定当前源、冷构建、最终类型表及完整清单 |
| 运行映射 | 再次核验 77 全局变量、109 个工程内 FB 实例、10 HMI 映射；库 FB 不计入这 109 项布局检查 |
| 内存 TLS | OpenSSL SSLObject/MemoryBIO，TLS 1.2，测试 CA 与固定名称校验通过，双向加密传输合成 RSC 头 |
| RSC 固定头 | 6 个原厂纯序列化向量逐字节一致，包含 UInt32 token=0/1/max、负 handle、checksum 分支 |
| RSC 完整受支持消息 | 11 组最终原厂向量逐字节一致；真实 proxy 默认 marshal2=UTF8；四服务 FullName/provider 由原厂纯静态方法核验 |
| 文件/文件系统值体 | 45 个原厂向量逐字节一致，含 WriteMany/ReadMany/错误数组/traits/空间；15 个 WriteMany 向量覆盖版本 3/4/5、空值、权限、中文/emoji 路径及跨 64 KiB 缓冲大小的流 |
| 配置服务值体 | 39 个原厂向量通过，含 Reset/Load bool、void 和 GetPlcState UInt32 高位错误标志；Python 限定 v4 |
| 模拟传输 | 两个整文件批次：27 文件/9,163,525 字节、21 文件/207,289 字节；所有 48 文件 SHA-512 回读相同 |
| 持久通道 | 同一 TLS 会话中实际执行 20 次二进制往返，含协商、认证、数据、配置及 CloseSession；另有 9MiB 多 TLS record 双向传输测试 |
| 配置加载 | 文件阶段成功后 Reset(true) → 等待 On → Load(true) → 等待 Stop；没有 Start/Change/Restart |
| 故障 | 15 种故障均返回 simulation_failed；加正常路径共 16 种场景通过断言 |

正常模拟结果目录为 `D:\PLCnext-MCP-Workspace\a431bdc32f2a4aa1812c94683db38395\download-simulations\` 下新建的作业目录，具体 UUID、trace 路径和模拟 inventory 见上方报告。没有修改工程或原 PCWE 包；模拟传输字节仅存在于内存，磁盘只新增诊断报告与哈希清单。

最终全套回归 **262 项：261 通过、1 跳过**，耗时 25.767 秒。[完整日志](../artifacts/plc-download-research/full-tests.log)。跳过项受 Windows 符号链接创建权限限制。新增测试在禁止 socket/create_connection 的条件下检查 TLS、密码/令牌、字节 codec、大数据传输、失败不加载、终态清理及源绑定；模拟成功不作为真 PLC 验证。[独立二进制流程审查](../artifacts/plc-download-research/load/binary-loopback-review.json)。

## 原厂契约与实现

认证由 `IPasswordAuthenticationService.CreateSession(username, SecureString, out SecurityToken, out penaltyDelayMillis)` 完成，原始 `AuthenticationError` 使用 0、-1..-6。成功后 `EnableSecurity` 将 UInt32 token 放入后续 CommonRemoting 头，不是另外发一个 Authenticate RPC。默认 token=null 与有效 token=0 必须区分。原始错误码不同于 Engineer UI 的翻译值；已从原参数名确认惩罚时间单位为毫秒。用户名和密码在此代理中都按 UTF8 值体编码，返回顺序是 token→惩罚时间→错误码。

`rsc_codec.py` 复现固定头；`rsc_rpc_codec.py` 复现受支持完整消息与认证值体；`rsc_file_codec.py` 复现文件及文件系统值体；`rsc_plc_codec.py` 复现配置值体。所有 codec 都与已安装组件的纯 MemoryStream oracle 比对；不是根据往返自洽就宣称原厂兼容。早期手工指定 marshal0 的 UTF16 用户名探测已被纠正，最终以 `auth/rpc-oracle-06` 的真实代理默认 marshal2 向量为准。

`BinaryLoopbackController` 通过 `MemoryTlsPair` 发送字节，模拟端解码后调用内存服务，再把二进制响应经同一 TLS 通道返回客户端。四个服务 FullName 和 provider=`Arp` 取自原厂 `GetServiceTypeNames`/`GetServiceProviderName` 结果；handle 由模拟端分配并通过 GetServiceHandles 确认，客户端不硬编码目标 handle。协议 v4 的 Invoke DataLength=0，值体长度由方法 schema 决定；本实现只支持单请求完整值边界，不把它称为通用 TCP/RSC stream framer。不同 header、响应 token、handle 或未支持的方法会拒绝。

原厂不能直接序列化 Value=null 的默认 SecurityToken；本模拟端在认证失败时选择可序列化的 UInt32(0) out 值，客户端先检查非零错误码再拒绝会话，不接受该 token。这是明确的模拟选择，不声称真实固件失败时一定返回 0。

文件传输使用 `IFileService2.WriteMany`；原代码先向批次追加整个文件，累计**超过** 8 MiB 才封批，因此批次可以大于 8 MiB，单文件不拆成自定义 chunk。每项 `FileSystemError` 都必须为 0，结果缺项也失败。目标符号根从设备 profile 继承链得到 `$ARP_PROJECTS_DIR$/PCWE/`，实际绝对根须由文件系统服务解析。模拟器返回明确的 `/simulated-device/...` 根，未假定真实 `/opt/...` 路径。

完整配置加载采用 `IPlcManagerService.Reset(async=true)`，等待 Ade DeviceState=On(0)，再 `Load(async=true)`，等待 DeviceState>0。原代码不在这里启动程序。状态低位与 Loading/Resetting 等标志分别处理，错误检查优先于成功谓词。允许 Suspended，其余相关错误失败；未知状态在自有流程中保守拒绝。轮询使用虚拟时间模拟原厂 100 ms 的等待顺序和 300 秒的 `elapsed > timeout` 判定；不会真实等待五分钟。

原厂下载有独立的 ResetBeforeDownload 和在线 Change 分支，当前固定完整加载模式不实现它们。原厂 Load 成功判据大于 0，模拟器正常路径选择 Stop；不把这推导成所有设备必然停机或自动运行。

自有流程额外采用初始 Stop、操作权限和空间预检、SHA-512 全量回读、旧文件集合核对、失败不继续 Load、写入结果不确定时不自动重试等策略。这些属于本实现的策略。权限目前是内存设备的能力模型；旧文件清理由虚拟文件集合实现，尚未实现真实删除 RPC；不宣称远端写入原子性或失败后自动回滚。

## 故障及清理

支持 `bad_credentials`、`penalty_active`、`permission_denied`、`session_expired`、`insufficient_space`、`write_error`、`short_results`、`transport_interrupted`、`readback_corrupt`、`reset_timeout`、`load_timeout`、`load_error`、`initial_running`、`untrusted_peer` 和 `hostname_mismatch`。

证书和名称错误由 OpenSSL 在内存握手中实际拒绝。其他故障由对应内存服务注入，检验真实编排代码是否停止后续操作。传输中断明确模拟“有文件可能已经写入但响应丢失”，报告保留副作用信息，不自动重传或加载。所有场景清理模拟安全上下文，密码及 token 不写入报告。测试 CA、证书和私钥都是公开离线 fixture，仅用于模拟；它们与真实设备身份无关。

## 调用方法

本机注册配置不变，重载 MCP 后在其他项目也能发现新工具。当前可调用参数：

```json
{
  "project_id": "a431bdc32f2a4aa1812c94683db38395",
  "expected_project_sha256": "e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0",
  "package_job_id": "5e4a155de2d8486ba6df5f0a019380a1"
}
```

先调用 `project_download_plan`；再用同一组参数调用 `project_simulate_download`，默认 `fault="none"`。选择 `fault="readback_corrupt"` 等可验证失败流程。旧源哈希、包 ID 路径逃逸、不同源/构建、最终类型表篡改或 IMG 与冷构建不一致都会在模拟前被拒绝；即使篡改 IMG 后重算包清单和 inventory，仍不能通过冷构建镜像哈希绑定。

复跑全部真实 MCP 场景：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I 'D:\work\code\PLCnext-Engineer-mcp\tools\download_simulation_mcp_e2e.py'
```

## 证据索引与剩余工作

- [认证、固定头及 TLS 研究](plc-auth-research.md)：REA `ev_c252d00e070586ce938c59271bdc347a961dca75e2eed0386fd4107ce19aa722`；纯 header oracle 与内存 TLS 结果在 `artifacts/plc-download-research/auth/`。
- [文件传输与值体研究](plc-file-transfer-research.md)：REA `ev_1c141e205ca7933c3afbe93518fad17df7d3b84c44b1901710a21a1bb7e39688`；45 个原厂值体向量（含 15 个 WriteMany `.bin`）和 profile 根链在 `artifacts/plc-download-research/files/`。
- [配置加载研究](plc-load-research.md)：REA `ev_0479c64423afd09d67262110893bfd5681013a7e8d523e225992bd29a2634743`；完整 IL、状态/服务枚举及独立审查在 `artifacts/plc-download-research/load/`。

| 问题 | 当前状态 |
| --- | --- |
| 认证/写文件/加载的调用契约 | 静态方法体及元数据已确认；编排代码已在内存服务上执行 |
| RSC 固定头、受支持 RPC 及 auth/file/PLC 值体 | 已实现有限 codec，并与原厂字节 oracle 匹配 |
| TLS 密码学和证书/主机名失败分支 | 自建测试 CA 的 OpenSSL 内存握手通过；不证明 BouncyCastle 或真 PLC 等价 |
| Connect、四服务发现/handle、CreateSession/CloseSession、文件/配置调用 | 已在持久内存 TLS 中实际交换；限定 v4 untagged/no-datagram profile |
| 通用 streaming、多请求拼接、tagging/datagram、其他版本/服务与重连恢复 | 尚未实现，未支持输入会拒绝 |
| 真 PLC 证书获取、信任配置、认证权限、空间/签名策略及固件兼容 | 未连接、未验证 |
| 真实控制器文件传输、配置加载与执行 | 没有启用，controller_access/real_transport_available/deployable 均为 false |

因此，这次可以确认受支持 profile 的离线二进制端到端流程、原厂向量兼容性和拒绝分支。后续可扩展通用消息层及其他 profile；接入真实 PLC 仍需要单独授权和验证。
