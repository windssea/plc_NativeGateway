# 原工程恢复：最终版本与停启影响审阅

日期：2026-10-26，Asia/Shanghai。状态：**等待操作者精确确认，尚未 Stop、下载、Reset/Load 或 Start 真实 PLC。**

本单只对应指定原归档的恢复，使用原始 32 POU、单任务源码。实现新增的多任务、故障插桩只在额外副本验证；本次恢复输入的源码哈希保持原值。

## 待执行的精确版本

| 项目 | 冻结值 |
|---|---|
| MCP | 0.6.0，68 工具；独立实现，不调用 ACI 或 computer use |
| 目标 | `192.168.0.8:41100` |
| 证书 SHA256 | `3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863` |
| 原归档 | `D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex` |
| 源 SHA256 | `7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154` |
| 受管副本 | `17ae4361baa846868b14775bf1de15ea`，revision 0，32 POU / 单周期任务 |
| 冷构建 | `41be9d3f0e7d4a738c49928c46f84673`；无工程 AST 种子 |
| 包作业 | `f7fc619d55ba42c091f4ca0efed23e73` |
| 包清单 SHA256 | `c83ee20636924cfb29d9459127d77a88f4cbdbe444613a092f0bf373ec69a4cf` |
| eCLR 镜像 SHA256 | `8bda2ba406256aa8e4a6bc86511899f12cbfd9835ecc13f9ddea65bbd3364954` |
| 文件 | 49 个，9,193,238 bytes；文件清单及逐文件 SHA512 已绑定审阅 |
| 软件标识 | `NativeGateway`；构建标识 `1792996875218850000`，生成于 2026-10-26 14:41:15.218850 +08:00 |
| 整体恢复计划 | `b5394f7a512c4c94b2a5836f9abc7671` |
| 计划 SHA256 | `0b977fedac3979549b95f9686de48809a8eb82398a29471c62368ec6e19dc3bc` |

[完整不可变计划](</D:/PLCnext-MCP-Workspace/17ae4361baa846868b14775bf1de15ea/controller-recovery-plans/b5394f7a512c4c94b2a5836f9abc7671/plan.json>)。

## 本次新鲜只读观察

文件窗口开始于 **2026-10-26 15:44:46 +08:00**。设备报告 `Running`，PLC Info 的项目名与远端软件声明均为 `NativeGateway.p06-performance-v32-group2`。这是当次观察，执行时还会重新读取状态。

- 已实际回读远端 **49 文件 / 9,385,464 bytes**，逐项 SHA512 匹配远端 manifest；读取窗口中 manifest 和状态保持一致，保存了本地磁盘快照。
- 这 49 个路径与恢复候选相同。15 个实际文件内容与候选不同（包含 manifest 自身）；其中旧 `dlc.bin` 为 399 bytes，候选将写入原厂有效的 0-byte 空下载能力历史。
- 运行读取完整覆盖 1767 个字段、250 个点的质量；当次 250 个质量值均为 `GOOD`。这是有 boot/config 守卫的窗口，不能证明这些缓存点正在持续产生新样本。
- 当前 `gatewayId=NG-HUB-2152-01`、boot `ng-d4f61b3085b97c5e3831983b-60`；配置版本 13、50 台设备、250 点，**Active.enabled=false（采集关闭）**。
- `QueueCount=0`、PublishedBatches=ConfirmedBatches=306、InvalidAcks=0。它们不能证明性能候选的全部入口/所有权/RAM事件已经完整排空。
- 既有 ESM 读取成功，任务名/源调度一致。没有重新运行 P06、注入故障或据此作性能放行。

记录：[只读观察与准备报告](../artifacts/original-recovery-review/8024f75ff6ea4c0f9ec27d990caec9fd/result.json)。初次连续读取触发了端点最小间隔保护；遵守间隔后 ESM 成功，历史拒绝也保存在报告中。

磁盘快照：`D:\PLCnext-MCP-Workspace\17ae4361baa846868b14775bf1de15ea\controller-package-observations\951dfb60deb54580ad8af7f07d5eb0d3\PCWE`。
快照 inventory SHA256：`054db9106fb2af6f3b306a643c349df58a5196fa020e075d97292acdc43f11c6`。
该快照验证的是清单内磁盘文件，不是内存已加载镜像证明，也没有被认定为可自动执行的回滚包。

## 确认所覆盖的动作和影响

1. 独立人工确认仅授权上表的目标、源码、包及计划。后台作业取得连续端点租约后再次读取现场，要求初始精确 Running。
2. 发送一次 **Stop**，读取到精确 Stop 后才继续。当前 v32 的程序执行和通信会中断；物理输出及保持行为尚未实机验证。
3. 覆盖这 **49 个包路径**，manifest 最后写；全部文件回读 SHA512 通过后才发 **Reset → Load**。不删除未列入清单的文件；未知路径集合变化会拒绝。
4. `Reset/Load` 会重建程序配置，**未持久化 RAM、队列、在途事件和会话状态可能丢失**。本计划选择 `record_unknown_loss`：损失范围保持 unknown，不能据 QueueCount=0 宣称零损失。
5. `dlc.bin` 被替换为空历史，旧 Engineer 下载能力历史被清除，不再声称保留旧程序的增量下载兼容性。
6. Load 后要求精确 Stop，并核验本次回读/加载日志、新鲜 ProjectName 及状态，然后执行 **Cold Start**，读取到 Running。设备加载时自动启动策略尚未实机验证；非预期状态会停止流程。
7. 原程序启动后会按其原逻辑和持久化配置运行采集、MQTT/HMI 等业务。恢复核验期望 **配置13 / 50台 / 250点 / enabled=true**；MCP本次不直接写配置开关。当前 enabled=false，若加载后仍为 false，会如实报告配置/采集未恢复，不悄悄降低验收条件。
8. 最多3次有间隔的只读运行核验。Running、250 GOOD 或计数值不能代替真实 DATA/STORED、mock 对照及原采样摘要的三方最终验收。

执行期间请暂停其他下载或调试写入。本机租约隔离同一用户下的 MCP 作业，不能阻止外部 Engineer、其他用户或其他主机改设备。

没有自动回滚、自动重发或故障后反向启停。回复丢失、状态不确定或结果落盘失败会保留 claimed、journal 与隔离信息；可能需要明确的人工恢复步骤。匿名只读已验证，匿名写入权限及包的真实加载兼容仍由本次经确认的联调验证。

## 如何确认

按 [修复清单 M01](三方联调MCP修复清单-20261026.md)，收据由操作者在独立终端发行。普通 MCP 工具和开发 AI 不签发真实批准。

在 **PowerShell 7 独立终端**运行以下一条命令（它只发行确认，不连接或下载 PLC）：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\tools\Approve-Original-Recovery.ps1' -Issue
```

终端会展示完整计划，并要求手工输入完整计划 SHA256、确认来源及影响接受。该次收据有效15分钟、一次性；不要使用 AI 工具代填。只想查看时去掉 `-Issue`。

完成后回复“已批准这份恢复计划”。随后才执行 PLC 恢复联调。拒绝、过期、已消费或绑定变化都会在变更前拒绝；文档本身和计划 ID/hash 都不授予写权限。

## 已完成验证

- [最终509项回归](../artifacts/joint-implementation/full-tests-final.log)：508通过，1项 Windows 符号链接权限跳过。
- [独立0.6.0 wheel全链](../artifacts/joint-mcp-e2e/df695d60992541b7ba7d25366eaa3903/result.json)：仓库外/非源码导入、68工具、原归档冷编译/49文件打包、同一TLS peer恢复闭环、多任务编译及未批准拒绝。
- [68工具与23个示例核对](../artifacts/mcp-documentation/0.6.0-validation.json)。
- [完整使用手册](mcp-user-guide.md) / [M01～M10实施指南](joint-implementation-user-guide.md)。
