# M07 有界故障监督与本机验证

2026-10-26。新增 [fault_supervision.py](../src/plcnext_mcp/fault_supervision.py) 与
[独立监督进程](../src/plcnext_mcp/fault_supervisor_worker.py)。不依赖 ACI 或 computer use。

**指定 32 POU 原恢复归档没有已验证的独立 TTL 故障 hook，真实启用当前明确不支持。**
不会通过普通变量写入加 `finally`、私有 RSC、Force、停共享 broker/Hub 或修改系统时钟来绕过。
本模块的独立监督进程仅操作它自己拥有的 loopback 测试布尔状态，不作用于实际 Agent、Hub 或 PLC。

## 实际接口

- `fault_supervision_capabilities()`：分别报告合同实现、本机双端验证和真实 backend 不可用。
- `prepare_fault_review(store, project_id, expected_project_sha256, package_job_id, address,
  expected_certificate_sha256, expected_boot_id, fault, ttl_ms, port=41100)`：本地审阅，绑定源、包、
  目标 pin、预期 boot、故障白名单和最大期限。返回 `execution_supported=false`，不连接或批准。
- `execute_fault_review(...)`：目前在任何 socket 或审批消费之前返回 `fault_backend_unsupported`。
- `test_fault_supervision(store, project_id, expected_project_sha256, package_job_id, fault='none')`：
  验证包身份后，新建本机测试目录与 127.0.0.1 随机端口独立监督进程。

MCP 工具由根集成层注册；不能把“已有这些函数”解释成真实故障功能已启用。

真实白名单合同为 `plcnext-bounded-fault-supervision/v1`，仅两种动作：

| 故障 | 作用边界 |
|---|---|
| `agent_connection_offline` | 仅受测 Agent 的连接隔离 |
| `business_ack_blocked` | 仅业务 ACK 隔离；真实 DATA 提交路径必须保持 |

期限必须为整数 100…300000 ms，不能续租、扩展或无期限保持。每次请求绑定精确 boot、
程序 inventory 和单次 request_id；重复请求、其他 boot/程序、其他故障和未解除状态都拒绝。
实际部署 backend 未来必须证明：计时和解除不依赖开发 AI/MCP 客户进程存活，异常仍有独立解除端，
且能读取解除结果。没有这些证据时保持 unsupported，不因源码中出现同名变量自动判断支持。

## 本机监督模型及测试含义

客户端经有界 TCP 请求调用另一个独立进程。该进程使用自己的单调时钟保存起点、截止点、
解除原因及时间；即使客户进程 `os._exit(21)`，它仍能处理到期解除。本机进程有固定最大生存期，
不会留下无限运行的测试服务。通信 capability 经私有初始化管道传递，不出现在结果或动作日志中。

fixture 的循环分辨率为 10 ms；本机操作系统调度和磁盘阻塞不构成实时系统硬截止保证。
这里证明独立期限状态机和进程边界，**不证明真实 PLC/网络故障已独立解除**。
主机断电、整个宿主消失或现场 backend 的故障恢复亦未由此测试覆盖。

`fault` 可选：`none`、`client_exit`、`cancel`、`boot_change`、`release_failure`。
`client_exit` 会启动单独客户进程、激活后直接退出，再由外层只读核查监督端到期状态。
`release_failure` 明确返回 `release_failed`、`release_verified=false`，拒绝后续故障；
不能把 finally 清理或进程退出包装成业务解除成功。

成功的本机报告为 `loopback_supervision_passed`，包含起止单调时刻、deadline、解除读回、
独立进程标记、真实 backend 未测试和共享服务未改变。业务 ACK 测试只证明本机 fixture 的 DATA
布尔保持；没有伪造 STORED、Hub 收据或 MQTT 数据。

## 验证

[test_fault_supervision.py](../tests/test_fault_supervision.py) 覆盖 8 项：独立 TTL、取消、
客户进程退出、boot/程序/白名单/重复和期限拒绝、boot 切换、解除失败以及真实 backend 零 socket 拒绝。
这些测试不会停止共享 Hub、broker、mock 或 PLC，也不会重启 P06。

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -m unittest discover -s 'D:\work\code\PLCnext-Engineer-mcp\tests' -p test_fault_supervision.py -v
```
