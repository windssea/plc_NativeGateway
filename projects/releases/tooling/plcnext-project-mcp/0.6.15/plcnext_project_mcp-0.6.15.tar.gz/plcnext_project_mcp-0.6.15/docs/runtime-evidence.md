# M08 运行时证据与时序报告

2026-10-26。新增 [runtime_evidence.py](../src/plcnext_mcp/runtime_evidence.py)。本模块读取已有的、
精确哈希绑定的运行观察收据，不建立网络连接，不启动 P06 或任何性能测试。

当前没有实现通用 ESM 运行诊断服务。指定原恢复归档也没有已验证的版本化增量耗时探针。
无相应证据时返回 unsupported/unknown，不以 RPC 耗时估算 PLC CPU、≤1ms 或≥90条/秒。

## 调用与边界

`runtime_timing_evidence(store, project_id, read_plan_id, expected_read_plan_sha256,
observations, probe_contract=None)`：

- `observations` 为 1…32 个精确 `{observation_id, observation_sha256}`，来自
  `read_runtime_plan` 的 `runtime-observations/<id>/result.json`。
- 每份收据最多 2 MiB，检查规范摘要、工程、read-plan、目标/pin、只读标记和项目符号范围。
- 重复、跨目标、跨源/计划、已变更字节、含 Write/Control/Force 的观察均拒绝。
- 调用方先用现有有界只读监视工具采集；本接口只离线分析，不暗中补发观察或无限重试。

没有 `probe_contract` 时仍报告每个观察的 UTC 标签、host 单调窗口、分块数、字节数、
网络操作数和一致性限制；测量字段与 release rate 为 unknown。
不同 observation 的 host monotonic clock domain 不直接相减。

## 版本化探针合同

支持明确的 `plcnext-runtime-probe-contract/v1`：

```json
{
  "schema": "plcnext-runtime-probe-contract/v1",
  "source_project_sha256": "<EXACT_SOURCE_SHA256>",
  "probe_version": "<ACTUAL_PROBE_VERSION>",
  "resolution_us": 1,
  "fields": [
    {"role":"boot_id","symbol":"<REVIEWED_BOOT_SYMBOL>","unit":"identity"},
    {"role":"probe_version","symbol":"<REVIEWED_VERSION_SYMBOL>","unit":"identity"}
  ]
}
```

符号必须已在精确 read-plan 内，role/unit 使用固定白名单，boot 和 probe_version 必需；
实际返回版本必须与合同匹配。合同本身不是运行镜像证明，声明的分辨率也不等于实测时钟校准。
不能给原程序新增假字段或把本地合同字符串当作设备已有探针。

| role | 单位/类型 | 含义 |
|---|---|---|
| `boot_id`, `probe_version` | identity/string | 同运行期和实际探针版本 |
| `configuration_version`, `reset_generation` | generation/integer | 配置与计数代际 |
| `device_monotonic_us` | us/integer | 设备探针的单调时间，不是 UTC |
| `task_cycle_us`, `task_peak_us` | us/number | 整任务已观测数据 |
| `increment_probe_peak_us` | us/number | 新增工作的版本化探针，单列报告 |
| `task_overrun_total`, `watchdog_violation_total` | count/integer | 累计诊断计数 |
| `release_total` | count/integer | 已定义计数器；其业务唯一释放语义需三方另验 |

整任务峰值和增量探针分别输出，不用两份任务峰值相减伪造新增工作。
无原工程同 profile 基线时 baseline_comparison=unknown；最大观测值也不是最坏路径证明。

## 一致性、重置与缺样

boot、配置或 reset generation 改变时整段 evidence invalidated，不拼接为同一次运行。
计数下降报告 reset/wrap unknown，不自动推断绕回；缺代际字段时不出具计数差或吞吐率。
缺字段、错误类型、探针版本变化、部分返回和失效的观察单独列入 issues。

仅当相同 boot/配置/计数代际、设备单调时间递增、计数有效时，才计算该探针计数的观测速率。
这仍不证明它等于唯一真实 STORED 释放事件数。无设备单调探针时不使用 RPC 窗口替代分母。
采样间隔超过计划间隔的 1.5 倍时报告孔洞，不裁掉缺样窗口后假装连续。

报告的 `monitoring_impact_on_plc_task_verified=false` 保留监视开销尚未在 PLC 上测量的事实。
主机的 bytes/调用次数/窗口是监视负荷证据，不是 PLC 任务 CPU 增量。

`p06_acceptance.status=not_evaluated` 始终保留。≤1ms、≥90条/秒、资源限制和完整最坏路径
由三方后续同 profile 取证，本模块不替验收器宣告通过，也不恢复暂停的 P06。

## 验证

[test_runtime_evidence.py](../tests/test_runtime_evidence.py) 覆盖 9 项：无探针、整任务/增量分离、
boot/config/reset 改变、计数下降、缺字段/类型/版本错误、设备时间重置/孔洞、超限/越权/跨目标拒绝，
以及精确收据和零网络适配器。正向数据是 PUBLIC 合成探针，不来自真实性能测试。

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -m unittest discover -s 'D:\work\code\PLCnext-Engineer-mcp\tests' -p test_runtime_evidence.py -v
```
