# 从 61 POU 冷构建生成完整离线 PCWE

2026-10-25，本机注册的 `plcnext-project` 已实际调用 `project_generate_pcwe`，从 NativeGateway 副本的新冷构建生成完整 **48 文件 PCWE 目录**。运行配置、原生库、HMI、OPC UA、Profinet 和清单均在本轮生成；没有用旧 GUI 包替换其中的运行配置或页面。

仍依赖本机 Engineer 编译组件、原引用库和 Windows .NET Desktop 8.0.21。没有使用 ACI、Engineer 界面、computer use 或修改许可。没有建立控制器连接、下载、启动或停止 PLC。`package_complete: true` 表示此已验证配置的本地文件集完整；`deployable: false` 表示设备接受、签名策略、目标内存限制及实际执行尚未验证。

## 可复查结果

- [真实 MCP 端到端报告](../artifacts/pcwe-build-mcp-e2e/70830038fc1045bfbafd9b743d172bfd/result.json)
- [完整生成报告](../artifacts/pcwe-build-mcp-e2e/70830038fc1045bfbafd9b743d172bfd/package.json)
- [独立 MCP 回读检查](../artifacts/pcwe-build-mcp-e2e/70830038fc1045bfbafd9b743d172bfd/inspection.json)
- [最终文件集、HMI 字典和原生库独立审计](../artifacts/pcwe-build-research/final-package-audit.json)：48 项路径与基线集合一致；HMI 的 26 项 project.files 和 24 项 CRC 闭合；NG_Hmi 116 字段与本轮最终布局一致；SO 与本轮源 pcwlx 字节一致。
- 输出：`D:\PLCnext-MCP-Workspace\a431bdc32f2a4aa1812c94683db38395\deployments\5e4a155de2d8486ba6df5f0a019380a1\PCWE`
- 项目：`a431bdc32f2a4aa1812c94683db38395`；新冷构建：`54599b7ed9254ac6a61293152ce4ae08`。
- 当前副本 SHA-256：`e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0`，操作前后相同。
- 本轮重新冷编译的 IMG SHA-256：`e23d7fa98ffdb9885efab1a160827324ca2200178235985a8891d5ba657f297c`。

| 检查对象 | 实测结果 |
| --- | --- |
| 当前 POU | 61，重新构造 IEC 模型及生成 CIL/原生镜像，无旧工程 AST 种子 |
| 全局变量 | 77，源 ID、类型、间接地址、静态存储与 CIL/原生元数据一致 |
| 工程内 FB 实例 | 109，声明集、CIL 类型、原生偏移与存储属性一致；不包含库 FB 的逐字段布局校验 |
| 运行时类型 | 192，结构大小/对齐/字段偏移已在原生链接后补齐；53 个结构逐字段交叉核对 |
| 任务 | MainInstance → Main → Cyclic100，源周期为 20 ms，源 watchdog 为 500 ms |
| HMI | 10 个控制器映射，81 条页面引用；Gateway 494 对象、Login 10 对象 |
| 页面脚本 | Gateway 462 函数、Login 2 函数，JSON 引用和 JS 声明集合一致 |
| 文件完整性 | 48 文件，47 项 SHA-512 及按同一排序构造的整体哈希通过 |

33 个 HMI 文件包括当前页面、脚本、504 条静态语言资源、类型/数据字典、工程元数据、源图片、安装目录静态客户端资源和校验清单。旧 GUI 样本仅用于独立对照：未修改 Login 的三个文件逐字节相同；旧数据/类型字典重建后语义完全相同；CRC 规则与原厂样本完全相同。当前 HMI 的 LocalRevision、HubBaselineVersion、UiMaintenance 等新增字段取自当前源和最终布局，未沿用旧字典。

## 调用方法

本机已注册，无需再次配置。重载 MCP 后，其他项目会话也可调用同一服务。通用流程：

1. `project_inspect(project_id)` 取得当前 `project_sha256`。
2. `project_compile(project_id, expected_project_sha256)` 取得成功结果的 `job_id`，作为下一步的 `build_job_id`。旧构建若缺少源绑定的 analyzed AST 收据，必须重新冷编译。
3. `project_generate_pcwe(project_id, expected_project_sha256, build_job_id)` 在新 `deployments/<id>/PCWE` 下生成文件。
4. `deployment_inspect_pcwe(source_path=返回的pcwe_path)` 独立回读文件清单。

当前已验证调用参数：

```json
{
  "project_id": "a431bdc32f2a4aa1812c94683db38395",
  "expected_project_sha256": "e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0",
  "build_job_id": "54599b7ed9254ac6a61293152ce4ae08"
}
```

可复跑 `tools/pcwe_build_mcp_e2e.py`。脚本从 Codex 读取现有 command/args/env，不改变注册；从仓库外目录启动真实 MCP，验证新工具、旧源哈希拒绝、未绑定旧模型拒绝、生成和回读。每次生成独立目录。

最终回归：`.venv\Scripts\python.exe -m unittest discover -s tests -v` 共 **190 项，189 通过、1 跳过**，耗时 22.265 秒。跳过项受 Windows 符号链接创建权限限制，不计为通过。[完整日志](../artifacts/pcwe-build-research/full-tests.log)。新增负例覆盖源收据遗漏、目录/载荷篡改、错误 HMI 前缀、页面引用与订阅清单不一致、变量类型和偏移变化、构建记录竞态及不同最终类型表混用。模拟负例不冒充真实编译；真实编译和打包证据见上方 MCP 收据。

## REA 到实现的证据链

- 运行配置：从 PCWEX 的工程身份、设备、数据列表和任务 XML 重建 Domain/ESM/GDS/PLM。当前无外部 GDS 连线、无用户 PLM 组件；不是无条件输出空配置。详见 [运行配置研究](pcwe-runtime-research.md)。
- 最终类型：`Ade.Compiler.Eclr.Tasks.GenerateEclrCompileResultInfo.ExecuteCore`（`0x06000510`）调用 `TypeInformationHelper.FinishTypeInformation`（`0x06000482`）。先前冷构建 JSON 只是中间类型表，结构大小/偏移为零；新增宿主读取本轮 IMG 的元数据补齐布局，使用 CIL 补充原生接口未能解析的复杂字段类型。证据在 `artifacts/pcwe-build-research/type-information-il.json` 和 `eclr-finalization-il.json`。
- 原生库：源绑定的 pcwlx 内选择非仿真 AXCF2152/2026 profile，版本匹配规则按原方法只比较 major/minor。选择 `2026.0.2/libIIoT_Library.so`，不从旧 PCWE 复制。Libraries.crc 用归档 CRC 排序后按原厂 CombineChecksum 规则生成。
- HMI：用源页面、当前 analyzed AST、DataList 最小模型托管原厂解析/语义/JSON/JS/本地化入口。未知服务调用直接失败。详见 [HMI 离线生成](hmi-offline-generation.md)。
- OPC UA/Profinet：当前硬件/服务投影被明确限定并绑定源哈希，未知设置拒绝。OPC UA XML 经原厂 XSD 核验；Profinet SQLite 新建并比对 schema/行，未声称数据库逐字节相等。证据在 `artifacts/pcwe-auxiliary-research/`。
- REA evidence：工程身份 `ev_ab237d96c3653597ac806b0e0844623e45f479f6490df9b8c8a8c0028de7d975`；运行编译器 `ev_0f54b4e4dcfae5a4d81a5a3945996f41a3e3b009135f48af8f7f07e657eeb22d`。完整静态证据与实跑收据分别保留，静态发现不冒充执行证据。

心跳 `ESM_DATA.ESM_INFOS[1].TICK_COUNT` 特别保留原厂 HMI 的 DINT 视图：源字段实际为 UDINT，均为 4 字节，当前结构内偏移 12。报告明确记录该原厂常量视图，不声称逻辑类型相同。偏移是离线镜像元数据，不是在线 PLC 内存地址。

HMI 使用的 Windows 字体指标组件要求 WINDIR。MCP SDK 默认继承 SYSTEMROOT 而不继承 WINDIR；首次集成失败后，通过最小环境 A/B 重现，生产宿主仅对子进程补该路径。两条 XmlSerializers 预生成程序集缺失异常属于正常 fallback。CLR 还可能自动加载 Ade.Online 接口元数据，收据记录实际程序集列表；没有实例化在线服务或调用通信接口，不声称“零 Online 程序集加载”。

## 支持边界

IEC 编辑/冷构建可按能力检查服务其他工程；完整 PCWE 打包当前仅支持已验证的 NativeGateway AXCF2152/2026 硬件/服务与 Gateway/Login HMI。未知硬件设置、显式 authsettings、用户 PLM/外部 GDS、未支持 HMI 符号或资源等会拒绝，不填占位成功文件。包目录仅在所有阶段成功后创建；失败日志保留在独立作业目录。

这次没有生成 DAuM ZIP，没有签名或验证设备许可/签名策略，没有实现认证后的 PLC 文件传输及配置加载，也没有进行实际控制器运行测试。后续若实现下载，需单独实现并验证这些环节。
