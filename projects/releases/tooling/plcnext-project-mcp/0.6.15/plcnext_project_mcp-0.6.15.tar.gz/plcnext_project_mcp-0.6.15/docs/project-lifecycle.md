# 独立工程、新建与 FB 生命周期验证

日期：2026-10-23。版本：MCP 0.2.0；本机 Engineer 2026.0.4 / 9.0.373.0。

## 支持范围

普通冷编译入口 `project_compile` 不再要求 NativeGateway 的原始 SHA、工程名、31 个
POU 或固定资源 ID。它检查当前工程的设备、资源、任务和源代码能力，从当前源文件
重建 IEC 模型。旧 `project_compile_nativegateway` 名称保留兼容；旧缓存模式仍有固定
样例限制。

当前编译组合为 **AXC F 2152 / 00/2026.0.0、单 eCLR 资源、一个周期任务、标准 ST
POU**。其他设备、图形或混合工作表等返回具体不支持的原因。编译仍依赖已安装的
厂商编译器、设备运行库和工程引用库，不依赖 ACI、GUI 或项目 AST 种子。

## 新增入口

| 工具 | 用途 |
|---|---|
| `project_create` | 指定 `name`，可选 `template_path`；创建独立受管工程 |
| `project_add_fb` | 当前工程哈希、`pou_name`、可选完整 `code` / `variables`；增加 ST FB |
| `project_delete_fb` | 当前工程哈希和 FB 名；删除未引用的标准 ST FB |
| `project_change_fbs` | `add_fbs`、`delete_fbs`、`updates`；原子增删 FB 并更新调用处 |
| `project_compile` | 当前 `project_id` 和 `expected_project_sha256`；能力检查及冷编译 |

默认新建使用本机官方 `Templates/AXCF215200260.pxctx` 空设备模板，刷新工程、配置、
资源、设备实例和 Main 等对象身份，添加标准 ST Main，并清理模板专属记录和旧模型
引用。`template_path` 仅接受同一受支持结构的空设备模板。

`add_fbs` 每项为 `{"pou_name":"PumpGate","code":"...","variables":"..."}`；
`updates` 沿用 `project_update_pous` 格式，要求当前代码和变量的两个哈希。删除操作
检查事务最终状态中的类型、声明、代码与已知文本映射引用；仍有引用就拒绝提交。
遇到图形工作表时保守拒绝删除。成功编辑生成新修订，冻结原件不变。

FB 新建/删除只改其成员、`PROJECT.proj` 及必要的 `[Content_Types].xml` 登记；调用方
代码和变量只按显式更新修改。其余原有 payload、对象 ID、DataList、ESM 和 I/O 文件
按字节保留。结构变更记录准确的成员哈希，支持并发保护与失败回滚。

## 实际验证

74 项单元与并发/失败回滚测试通过。真实 MCP stdio 生命周期验证共 7 次成功冷编译
及 1 次预期语义失败，见
[完整报告](../artifacts/project-lifecycle-e2e/717384ffbd62456094cf9d3ac0b72555/result.json)。

| 用例 | 结果 |
|---|---|
| 从官方空模板创建 Alpha 工程，Main 为 ST | 冷编译成功，独立资源 ID |
| 新增 PumpGate、UnusedBlock，更新 Main 实例及调用 | 3 个 POU 全部解析/语义检查，冷编译成功 |
| 检查新增 FB 的 CIL | BOOL 输入、UINT 输出和常量 12345 均存在；没有执行 PLC 代码 |
| 未引用的 UnusedBlock | SEM2005 警告，编译器合理省略其 DLL，仍编译成功 |
| BOOL 参数错误传为 UINT | SEM1117，未启动原生后端，未产生镜像 |
| 删除仍被引用的 FB、重复名称、旧哈希 | 拒绝，当前版本不变 |
| 同一事务移除调用和实例并删除两个 FB | 回到 1 个 POU，冷编译成功 |
| 生成的 PCWEX 重新导入为另一副本 | 冷编译成功 |
| 创建第二个 Beta 工程 | 独立资源 ID，冷编译成功 |
| NativeGateway 副本新增并删除第 15 个 FB | 31→32→31 个 POU，两个版本均冷编译成功 |

NativeGateway 增删往返只留下 `PROJECT.proj` 序列化变化和新增 `st` 内容类型登记，
原有源码、POU 元数据及映射成员均逐字节一致；冻结原件 SHA 未变。默认模板文件也
始终只读。未使用 ACI、computer use、Engineer GUI，没有连接或下载到 PLC。

方便直接检查的工程副本已另存为
[含新增 FB 的 Alpha](../artifacts/offline-project-demo/OfflinePlantAlpha.with-fbs.pcwex) 和
[删除后的 Alpha](../artifacts/offline-project-demo/OfflinePlantAlpha.after-delete.pcwex)。
这两份文件与各自成功编译的输入完全同哈希，来源见
[副本清单](../artifacts/offline-project-demo/manifest.json)。

库包复制进独立构建目录，按原工程目录解析相对 `HintPath`，记录输入哈希。设备运行
库来自已选 profile；包的显式 `PrecompiledLibrary` 输出优先于其他包附带的旧依赖。
NativeGateway 所选 IecEngineering 与既有 GUI 产物哈希一致，见
[选择证据](../artifacts/generic-cold-regression/9f2f390d1ed94005bca1807868666939/library-selection-evidence.json)。
未知冲突会失败；此规则不代表恢复了 IDE 的全部依赖解析算法。

## 安装包和跨项目使用

[0.2.0 wheel](../dist/plcnext_project_mcp-0.2.0-py3-none-any.whl) 已安装到全新环境，
从 `C:\Users\windssea` 使用 `-I -m plcnext_mcp.server` 启动，发现 19 个工具，完成
中文/含空格名称的新建工程、原子新增 FB 与 Main 调用、构建计划及真实冷编译。
包内所有代码和宿主文件与当前源码一致，见
[独立安装证明](../artifacts/package-0.2.0-proof/result.json)。

其他项目无需复制服务源码：安装一次、注册一次，以工程绝对路径导入不同副本，
后续通过独立 `project_id` 操作。命令和通用客户端 JSON 见
[跨项目接入](use-in-other-projects.md)。2026-10-23 的验证没有改用户全局 MCP 配置；
2026-10-24 已按用户要求完成本机全局注册，并通过注册配置完成跨目录复测，
见 [注册验证记录](../artifacts/codex-registration/ff442212ebbf47039c9d370d25634d16/verification.md)。

## 验证边界

`compiled: true` 指 IEC 语义检查、新 CIL 和新离线原生镜像生成成功；产物仍为
`deployable: false`。本轮没有执行新工程的 GUI 打开/保存回读、PLC 运行行为、真实
物理 I/O 映射或完整硬件/HMI/签名/部署包验证。映射文件保留不等于运行映射验证。
独立工程的 EN/ENO 使用报告列出的项目选项或该 profile 的显式默认值，未声明与
GUI 编译逐模块等价。
