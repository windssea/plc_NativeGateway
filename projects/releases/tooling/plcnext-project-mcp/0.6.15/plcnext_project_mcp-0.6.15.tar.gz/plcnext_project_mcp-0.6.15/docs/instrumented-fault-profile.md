# M07：显式自 TTL 故障工程与固定字段 RSC 后端

2026-10-26。新增 [fault_profile.py](../src/plcnext_mcp/fault_profile.py)、
[instrumented_fault.py](../src/plcnext_mcp/instrumented_fault.py)、
[固定 WriteSingle codec](../src/plcnext_mcp/rsc_fault_write_codec.py) 和
[本机 TLS/扫描模型](../src/plcnext_mcp/fault_profile_test_peer.py)。不依赖 ACI 或 computer use。

**原 32 POU 恢复归档仍不支持真实故障开关，也没有被修改。** 本功能另建一份 33 POU 工程，
加入明确的监督 FB 和两个窄门。它必须单独构建、打包、审阅并部署后才可能使用；本轮没有部署、
启动或在真实 PLC 上启用该工程。当前证据为原厂序列化、实际冷编译及本机 TCP/扫描模型，非真机验收。

## 精确源与改动范围

唯一支持的源归档 SHA-256 为
`7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154`：
`D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex`。

`create_fault_profile(store, source_path, expected_source_sha256=...)` 先导入新副本，
以一次原子编辑新增 `MCP_FaultLease`、Main 内的 `McpFault` 实例和一个阻断 ACK 计数，
只插入以下路径：

- 最终 `NG_Mqtt` 实例调用的 Enable 加 `NOT McpFault.BlockConnection`；不停止其他连接、Hub、broker 或 mock。
- `data/ack` 的 AckReader/业务 ACK 应用分支加 `NOT McpFault.BlockBusinessAck`。
  阻断时仍消费该收到的 ACK，不释放 Outbox、不伪造 STORED，不改配置 Topic 或 DATA 发布路径。

源锚点必须唯一且精确匹配，其他版本拒绝自动套用。加载 profile 时重新对照冻结原件重构 Main
及 FB 文本，连同当前工程 SHA、符号/类型、唯一 profile ID 和 profile SHA 一起校验；
改代码后旧 profile 不再有效。业务 Main.NowMs 的原逻辑保留。

## 独立内核单调时钟

故障 FB 专用时间输入为：

```text
GET_MICROSECONDS(TRUE) / ULINT#1000
```

本机官方 `PLCnext Controller.pcwlx` 的 `LibraryDescription.xml` 明确声明该函数的 OUT 是
**CLOCK_MONOTONIC、系统启动以来的微秒时间戳**，不是依赖 Main 的 TON 累积时间。
[合同及原件哈希](../artifacts/fault-write-research/clock-contract.json) 记录库 SHA
`6871db126a070a324c427cafefa5c7c88d2d12ff00c6049d346ec543d304079d` 和 XML 成员 SHA。
最终工程已用该真实库完成冷编译；执行故障前还要求两个只读窗口之间的内核时间前进，冻结时钟则零写拒绝。

PLC 任务停止期间不执行 Agent 或故障 FB；内核单调时钟继续作为绝对期限的基准。
恢复扫描后，已有 Active 在第一个监督扫描遇到到期即解除；尚未执行的过期 Commit 不得重新开始一轮 TTL。
boot 变化、Ready=false 或单调时间回退也解除已激活故障。实际设备 Stop/Start、输出、调度延迟与
内核函数运行效果仍需单独真机验证；这不是硬实时调度保证，也不授权停止 PLC。

## 分阶段提交与一次性能力

`IDataAccessService.WriteSingle` 在厂商 SDK 中声明为非 task-consistent，不能把多字段写当作原子操作。
本实现只对固定 profile 使用 method ID 3，按以下顺序写一次：

1. `RequestBootId`（STRING）、`RequestKind`（UINT）、`RequestTtlMs`（UDINT）。
2. `RequestDeadlineMs`（ULINT）、`RequestId`（UDINT）。
3. 回读前述字段、boot/profile/Ready/SeenId/Active，核验相同内容、无其他活动租约、PLC 仍 Running。
4. 最后写唯一 `CommitId=RequestId`，绝不自动重发 Commit。

RequestId 从已读 SeenId+1 产生，禁止回绕；绝对 deadline 从首次稳定设备时钟 + 审阅 TTL 产生，
不是每次重连重算。FB 要求字段跨两个扫描保持一致、boot 匹配、序号递增、类型/动作/期限有效，
且绝对到期点在当前时间之后、距离不大于本次 TTL。准备太慢导致过期时拒绝 Commit，不延长期限。

故障白名单只有 `agent_connection_offline` 与 `business_ack_blocked`，期限 100…300000 ms。
没有任意地址写、任意符号写或 Force。作用于本 Agent 的状态和外部真实业务是否受影响分别报告。

原厂 [WriteItem/WriteSingle/Write oracle](../artifacts/fault-write-research/oracle-02/report.json)
提供 16 个请求/应答向量，由真实原厂 formatter 在 MemoryStream 生成/消费；未创建 provider 或网络连接。
实际后端只实现该固定 profile 的 WriteSingle，不暴露通用 Write API。

## 审阅、审批、取消与状态

`prepare_instrumented_fault_review(store, project_id, expected_project_sha256,
expected_profile_sha256, package_job_id, address, expected_certificate_sha256,
expected_boot_id, fault, ttl_ms, port=41100)` 创建本地精确审阅。

`load_instrumented_fault_review` 重新校验源/profile/包/目标/固定策略。
`approval_contract` 为独立 CLI 提供 kind=`instrumented_fault`，收据目录为
`controller-instrumented-fault-approvals`，schema 为
`plcnext-instrumented-fault-operator-approval/v1`。旧下载、控制、恢复收据均不扩权。

`execute_reviewed_instrumented_fault(..., cancel_event=None)` 在连接前消费独立人工收据并持有固定端点租约。
普通 MCP 不签发批准。没有收据为零 socket 拒绝；源、目标、动作、profile、boot、有效期或一次性 claim
不匹配会拒绝。每次 RPC 复核持有租约，变更请求前复核源修订，逐步 fsync 动作日志。

开始前必须观察到正确 profile ID/version、预期 boot、Ready、Running、内核时钟前进和已连接 Agent。
profile marker 是部署识别证据，不是设备内存镜像的密码学哈希证明。

可取消的持久操作 job 将同一个 Event 传到后端：

- Commit 前取消：不激活故障，已经暂存的输入可能改变，但不会提交。
- Commit 后取消：可能已经激活；只对同一 request 最多写一次 CancelId，然后继续只读核验解除。
- 客户进程退出或回复丢失：不重复 Commit、不发送 PLC 反向控制；PLC 自己按绝对期限处理。
- 解除未证实、时钟/boot/profile 改变或 Commit 结果不明：保留不确定事实与端点隔离，不能删 claim 后重跑。

结果区分 `activation_committed`、`commit_request_attempted`、`activation_observed`、`release_verified`、
`outcome_unknown`、`cancel_requested`、`cancel_same_request_sent` 和脏暂存输入；
`agent_disconnect_observed`、`business_ack_gate_observed`、本地发布/阻断 ACK 计数变化也单列。
解除监督开关不等于 MQTT 已重连；真实 DATA/STORED、Hub 收据和业务恢复由三方另外取证。
此功能不开始 P06，也不证明新增工作 ≤1ms。

## 最终离线候选与证据

以下是单独的故障测试候选，**不是本轮应下载的原恢复工程**：

| 字段 | 值 |
|---|---|
| project_id | `9b2bc85d4b2944db92be9d9be58cadd0` |
| source SHA-256 | `476b0a0fba16a71712ff30ac5120e1d5e0e3825478f377e277d5e12ea91cbff0` |
| profile SHA-256 | `dae4c5dd0f0004669539e5977389784eff47c5b2b4315c4461c614bf6ae05e37` |
| cold build | `0cc55527d15d438c853841102a801f20`，33 POU，`compiled=true` |
| package_job_id | `8590a98b4afa40f08407af77c7929d57`，49 文件，`package_complete=true` |
| inventory SHA-256 | `09734fead2ddfbe873b902eb05443cbea38beb89e48914dcff71a5d38376a237` |

[生成记录](../artifacts/fault-profile-generation/kernel-profile.json)、
[实际冷编译](../artifacts/fault-profile-generation/kernel-cold-build.json)、
[完整包](../artifacts/fault-profile-generation/kernel-package.json)、
[公开本机入口矩阵](../artifacts/fault-profile-generation/kernel-public-tests.json)。
早期 TON 候选 `231d...` / `5cdd...` 已被 kernel-clock profile 校验拒绝，不应使用。

`test_instrumented_fault(store, project_id, expected_project_sha256,
expected_profile_sha256, package_job_id, fault='none', kind='business_ack_blocked')`
只创建 127.0.0.1 TLS peer 和独立扫描线程，不接受外部地址，也不发行真实收据。
case 包括 none、cancel、client_exit、wrong_profile、wrong_boot、plc_stopped、clock_frozen、
stage_mismatch、commit_reply_lost、release_failure。

client_exit 真的启动客户进程，Commit 应答后直接退出；随后用新的只读 RSC 会话取证。
原执行仍保留 outcome_unknown；`release_reconciled_readonly=true` 是后续解除观察，不把丢失的原应答补写成成功。
release_failure 明确失败，不伪造解除。

[17 项单元/本机测试](../tests/test_instrumented_fault.py) 覆盖原厂字节和截断拒绝、Source 原件保留、
精确注入、跨两扫描提交、绝对期限、boot/Ready/时钟回退/取消、Stop 后过期请求、冻结时钟零写、
Commit 丢回复/客户进程退出、固定字段边界、旧源拒绝和无收据零 socket。
扫描模型不是 IEC 运行器；原厂帧匹配、真实冷编译和本机模型效果是三种不同证据，均不冒充真机运行。
