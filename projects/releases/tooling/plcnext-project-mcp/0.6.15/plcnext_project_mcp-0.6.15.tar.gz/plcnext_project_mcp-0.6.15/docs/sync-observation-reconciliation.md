# 同步启动观察失败核销与交接观察预算

版本 0.6.13 / 89 工具；2026-10-28，Asia/Shanghai。对应 S01、S02。

## 修复

新增公开入口 `project_prepare_sync_observation_reconciliation`，接收真实 execution_id，不伪造后台 operation_id。要求显式绑定当前项目/源码、读计划、BootId、配置摘要和外部证据文件哈希。核销继续使用既有 inspect、kind=lease_reconciliation 精确一次授权与 execute。

准入限于已完成控制、同步 `recovery_failed / verify_runtime / recovery_observation_failed`：执行锁已释放、旧授权已消费、49文件回读完整、Reset/Load/Start均确认、所有请求闭合、无未知结果或清理异常。保持旧失败结果和 claimed，不把启动早期观察改写成成功。当前存活的 MCP 服务进程不会被当作仍在执行。

合法 skip-Stop 必须同时满足：`control_already_complete`、action=stop、action_sent=false、ack_received=false、terminal_state_verified=true；计划初态、当时初始/最终读回均为稳定 Stop，日志完全没有 Stop 调用。实际发送的 Stop 则仍需确认。不会为通过校验补发 Stop。

交接恢复的旧租约归档和 handoff 关联文件也被核验并纳入核销证据哈希。最终核销只读取当前 Running、准确 boot/配置摘要和全部 GOOD，再原子归档本次租约；不发 Stop、Reset、Load、Start 或文件写入。内存镜像证明、DATA/STORED/入库仍保持外部验收范围。

`project_prepare_stopped_recovery` 新增 `maximum_runtime_observations`（默认12）和 `runtime_observation_interval_seconds`（默认5），直接透传到底层恢复计划并进入计划哈希。沿用原限制：次数1..24、间隔5..10秒、乘积不超过240秒，整体恢复期限仍为300秒。可显式选择，GOOD判据与禁止自动补发Start均不变。普通恢复入口默认值不改变，旧计划不修改；0.8新计划应显式传12和5，并优先用后台作业。

## 本次绑定及公开调用

工具 `project_prepare_sync_observation_reconciliation`：

```json
{
  "project_id": "17ae4361baa846868b14775bf1de15ea",
  "execution_id": "6a0c9cb6865146a189538b80e2508bbe",
  "expected_review_sha256": "dc43ec1746a63e0a0e3abd62672cb9f2481fd3b36b9d5fb7ff5b638f4762fddb",
  "expected_certificate_sha256": "3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863",
  "current_project_id": "17ae4361baa846868b14775bf1de15ea",
  "current_project_sha256": "7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154",
  "current_read_plan_id": "1d480ec59dbb44bbb20c63996b8098a9",
  "current_read_plan_sha256": "a21ac2ca95fb704ce39315b9ed6658e54bbb4f7462707d3d6d7ec8fe2135a8dd",
  "expected_boot_id": "ng-d4f61b3085b97c5e3831983b-82",
  "expected_configuration": {
    "version": 19,
    "device_count": 50,
    "point_count": 250,
    "enabled": true
  },
  "expected_configuration_sha256": "bf6f827b4a321061bc7dc2f9275ff32bacc1b2db9d320a059136cdf75cd94c3b",
  "external_evidence_path": "D:\\work\\code\\PLCnext-Engineer\\output\\mainline-accept-20261028\\stable-current-runtime.json",
  "external_evidence_sha256": "4ba9750b74980a5615c0c75be1d5dd02126e7af1cbad9e11624bcc3af725e71b",
  "description": "Historical public runtime receipt after synchronous startup observation failure; business ingestion acceptance remains external. Fresh read required."
}
```

这次绑定的外部文件是历史公开运行读收据，不能替代数据库验收。prepare另执行新鲜读取，已经确认boot82、配置19、250 GOOD。

工具 `project_inspect_lease_reconciliation`：

```json
{
  "project_id": "17ae4361baa846868b14775bf1de15ea",
  "plan_id": "6358f89e31c44d3b9c53f738d6898853",
  "expected_plan_sha256": "99a8c44a2c2718b9329cfc92e9fa64a209b5d8f0e2919fe15b9d01b77a2bde31"
}
```

工具 `project_authorize_controller_operation`：

```json
{
  "project_id": "17ae4361baa846868b14775bf1de15ea",
  "review_id": "6358f89e31c44d3b9c53f738d6898853",
  "expected_review_sha256": "99a8c44a2c2718b9329cfc92e9fa64a209b5d8f0e2919fe15b9d01b77a2bde31",
  "kind": "lease_reconciliation",
  "reason": "Archive exact synchronous observation failure lease after fresh boot82 Running configuration19 and all250 GOOD"
}
```

工具 `project_execute_lease_reconciliation`（会再次只读核验）：

```json
{
  "project_id": "17ae4361baa846868b14775bf1de15ea",
  "plan_id": "6358f89e31c44d3b9c53f738d6898853",
  "expected_plan_sha256": "99a8c44a2c2718b9329cfc92e9fa64a209b5d8f0e2919fe15b9d01b77a2bde31"
}
```

已完成的计划不要重新签发授权；execute 的重放只返回原核销结果，不删除其他操作的新租约。

## 验证

新增本机用例覆盖：同步服务存活而执行结束、合法skip-Stop、早期超时后稍晚就绪、纯只读核销、旧证据不变；错误boot、活跃执行、证据篡改、skip与日志冲突、未知结果、回读不完整拒绝；交接预算透传、默认12×5、边界24×10及越界拒绝。

新进程公开入口及现场只读 prepare/inspect 证据：`artifacts/sync-observation-research/public-result.json`。本轮不重复下载0.5、不发送Start、不下载0.8、不修改数据库或Hub。

## 本轮实际完成结果

2026-10-28 15:04（Asia/Shanghai），公开 MCP 精确授权并执行核销成功，返回 `reconciled`。执行时再次只读确认 boot82、Running、配置19、250/250 GOOD、配置摘要一致。没有PLC设备写入/Stop/Reset/Load/Start，没有再次恢复0.5，也没有下载0.8。

已归档精确旧租约；本机随后验证旧执行 result/journal、handoff 文件哈希均未改变，原端点租约文件已不存在。该旧租约不再阻止后续独立操作；新的0.8下载仍应独立准备、预检和授权，使用12×5及后台作业。

最终回归630项：629通过、1跳过，181.270秒。工具schema/参考一致。实际核销收据：`artifacts/sync-observation-research/execution-result.json`；汇总：`artifacts/sync-observation-research/verification-summary.json`。上述JSON调用记录保留用于审计，已完成计划无需再次授权。
