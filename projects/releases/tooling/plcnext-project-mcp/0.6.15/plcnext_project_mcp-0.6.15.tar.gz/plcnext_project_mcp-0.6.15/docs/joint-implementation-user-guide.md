> 2026-10-26 更新（0.6.1）：用户已取消独立人工签发限制。MCP 可调用 `project_authorize_controller_operation`，自行决定并授权 download/control/recovery/instrumented_fault；无需人工终端。精确哈希、目标、有效期、一次性领取及审计仍有效。下文旧终端流程为可选方式。 [MCP自主授权及本次真机结果](mcp-managed-authorization.md)。

# M01～M10 独立 MCP 联调操作指南

源码版本0.6.1；日期2026-10-26。本文按实际工具和已保存证据编写，Schema见 [工具参考](mcp-tool-reference.md) / [JSON](mcp-tool-schema.json)。本地、本机网络、真实设备分别验收；工具数量不代表清单完成率。

所有例子的tool/arguments为展示格式，尖括号需换成实际返回值。本文不执行这些示例、不签发真实确认，不把历史观察写为当前PLC状态。首次物理操作仍优先恢复指定32POU原工程，不上传多任务/故障/性能测试副本。

## 当前交付证据

| 项 | 当前有证据的范围 | 仍未等同于 |
|---|---|---|
| M01 | OFFLINE_PASS；22项发行/撤销/并发与旧消费者兼容测试 | 实际人工终端操作、强账号隔离 |
| M02 | LOOPBACK_PASS；独立控制25项测试和实际生产TLS客户端本机状态机 | 真机输出/保持/启动效果 |
| M03/M04 | LOOPBACK_PASS；本机运行读取正反例、源/类型/身份窗口守卫 | 原子快照、设备内存模块哈希认证、真机250点/负荷取证 |
| M05 | LOOPBACK_PASS；原工程副本冷编译/包与本机传输；明确dlc.bin选择 | 真机权限、固件接受、运行兼容 |
| M06 | LOOPBACK_PASS（MCP部分）；整体恢复本机正常/异常路线及审批拒绝 | 原工程真实恢复和三方业务验收 |
| M07 | LOOPBACK_PASS；监督进程8项，最终核钟profile17项单测/TLS和10个公开入口场景 | 无自TTL原工程可以真实故障；额外profile真实期限/效果须另验 |
| M08 | LOOPBACK_PASS（固定ESM）；5项单测/4本机场景；9项收据取证OFFLINE_PASS | 真机ESM实测、P06、≤1ms或≥90条/秒通过 |
| M09 | OFFLINE_PASS；实际Schema生成器、分层报告与本指南 | 新工具自动继承旧验收结论 |
| M10 | LOOPBACK_PASS；33POU/2任务完整包及48文件真实本机TCP分块回读 | 改变原32POU恢复源、选择实际多任务架构或实机调度通过 |

证据入口：

- [M01报告](../artifacts/operator-approval/verification.json)
- [M02报告](../artifacts/controller-control/verification.json)
- [M07监督报告](../artifacts/fault-supervision/verification.json)
- [M07最终核钟profile报告](../artifacts/instrumented-fault/verification.json)
- [M08报告](../artifacts/runtime-evidence/verification.json)
- [M08固定ESM本机报告](../artifacts/esm-monitor-research/verification.json)
- [M10报告](../artifacts/multitask-native-e2e/f95519debbc04016b43c23c3500cd7b9/verification.json)
- [真实MCP本机联调报告](../artifacts/joint-mcp-e2e/42f6fb383a544928a5f3684c860bbcee/result.json)

这些文件是特定源码/样例/测试窗口的记录。交付后新增功能或真机结果由最新报告补充，不改写旧失败/未验记录。

## 一、M01 操作者审批

MCP 先准备精确审阅，再调用 project_authorize_controller_operation(kind/review_id/expected_review_sha256/reason)，自行决定并签发一次性授权，然后调用对应执行工具。无需人工终端；收据使用独立的 mcp-approval/v1 schema，confirmed_by=mcp_policy。project_inspect_operator_approval 同时检查两种来源。

可选人工模式：操作者在自己的 PowerShell7 交互终端运行 [Operator-Approval.ps1](../tools/Operator-Approval.ps1)：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\tools\Operator-Approval.ps1' `
  -Command inspect -Kind recovery `
  -ProjectId '<PROJECT_ID>' -ReviewId '<PLAN_ID>' -ReviewSha256 '<PLAN_SHA256>'
```

核对完整源/包/目标/pin/动作/影响后，操作者本人改为 `-Command issue`。需要输入完整APPROVE+hash、人工来源、接受所展示动作/影响。没有yes开关，非交互输入/输出拒绝；AI不代输入。download/control/recovery是不同合同，不能以下载收据授予Stop/Start。

有效期1…3600秒，默认900秒；精确收据原子不覆盖发布、一次领取。withdraw用于拒绝未发审阅或撤销未领收据；先占用与消费者相同的claimed文件。已领不能宣称取消在途动作，过期/撤销/已领不能覆盖后盲重试。

MCP检查示例：

```json
{"tool":"project_inspect_operator_approval","arguments":{"project_id":"<PROJECT_ID>","review_id":"<PLAN_ID>","expected_review_sha256":"<PLAN_SHA256>","kind":"recovery"}}
```

正例为PUBLIC夹具交互替身发行后旧消费者仅可领取一次；反例为非TTY、缩短/错误hash、未接受影响、错target/action/policy、过期和并发重复消费。详见 [操作者说明](operator-approval.md)。TTY/human label不构成密码学人类身份；如同账号AI能任意写收据/私钥/验证器，需受控宿主或独立权限才能提供更强边界。

## 二、M02 受控 Stop / Start

准备控制审阅不连接设备：

```json
{"tool":"project_prepare_controller_control","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","package_job_id":"<PACKAGE_JOB_ID>","address":"192.168.0.8","expected_certificate_sha256":"3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863","action":"stop","expected_initial_state":3,"timeout_seconds":30}}
```

用 project_inspect_controller_control 重验，由 project_authorize_controller_operation(kind=control) 自主授权，再执行 project_execute_controller_control。

Start另需start_kind（cold/warm/hot/restore_warm）、前态和已加载包身份。单独Start不能拿软件名或盘上manifest代替加载证明；缺身份拒绝。整体恢复路线在连续租约内使用自己全文件回读及Load完成的因果证据；仍不是内存模块哈希读取或排除外部工程师修改。

本机正例：

```json
{"tool":"project_test_controller_control","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","package_job_id":"<PACKAGE_JOB_ID>","action":"stop","fault":"none"}}
```

再测start及reply_lost、state_delayed、state_timeout、state_error、disconnect_after_ack、rpc_error、already_stopped、initial_wrong、missing_identity、wrong_identity。完成判定必须读取精确终态，ACK不等于完成；已Stop可报告无需发送，丢回复保留action_sent/outcome_unknown，不自动重发或做逆动作。

## 三、M03/M04 身份、配置和250点只读窗口

先解析归档实际符号：

```json
{"tool":"project_inspect_runtime_symbols","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>"}}
```

准备计划仍是本地操作：

```json
{"tool":"project_prepare_runtime_read","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","address":"192.168.0.8","expected_certificate_sha256":"3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863","point_count":250,"include_samples":true,"include_configuration":true,"chunk_size":64,"timeout_seconds":5,"maximum_bytes":1048576,"minimum_interval_seconds":5}}
```

随后project_read_runtime(project_id, plan_id, expected_plan_sha256)会访问真实目标。只请求计划内源路径/类型；不允许任意地址、文件、Write/Force或控制RPC。缺符号在准备/读取结果中保留unsupported/错误，不返回假0，也不自动修改原程序。

边界：最多2048符号，每块1…64项，响应上限1024…1048576字节，单次RPC超时1…30秒，整个观察最长30秒，同端点观察间隔5…3600秒。不要用高频循环绕过限速；这些软件边界不等于真实PLC监视负荷已测。

默认NativeGateway预设按源中实际Main实例选择gateway/boot、Active版本/数量/enabled、批次参数、采集/队列、HMI通信与计数，另加Samples[1..250]质量/值/时间。include_configuration增加可重算的点配置字段；该摘要只覆盖返回字段，不冒充全部原采样配置。agentVersion若只是源码字面量而非可读变量，应标来源/unsupported，不能假装运行时实读。

每项检查返回数量、实际类型、值/错误与时间；分块前后boot/config守卫变化则snapshot_invalidated。没有快照序号的成功结果是guarded_window_observation，不能叫原子250点快照。质量报告必须完整覆盖请求点，单有good=250而缺覆盖证明不能通过。

本机正反例：

```json
{"tool":"project_test_runtime_read","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","fault":"none","point_count":250}}
```

反例fault为missing_field、bad_quality、wrong_type、short_results、boot_change、config_change、disconnect、oversized_string；还应验证数量/字节/间隔超限拒绝。源符号、设备ProjectName观察、远端清单声明、盘上文件回读、因果Load证据分别报告；不能合并成内存已加载模块认证。

## 四、M05 包兼容与下载报告

使用指定32POU归档的新副本冷编译和打包。固定源/构建/包/逐文件哈希；显式download_memento_policy选择omit或empty_capability_v1。后者是原厂空dlc.bin能力历史格式，丢弃既有Engineer下载能力历史，不是随意复制旧dlc.bin；影响必须展示并确认。

prepare_download_review→inspect_download_review是本地审阅，preflight_controller_download才读取真实状态/空间/固定元数据。历史49/48文件观察不能当今天新鲜状态；严格路径集合检查仍保留，不能忽略所有额外文件、伪造清单或自动删除。

### 显式逐文件只读与现场磁盘冻结

默认预检仍只有两份元数据。需要实际远端字节证据时，显式设置verify_package_files；只有同时capture_package_files才保存新完整本地快照：

```json
{"tool":"project_preflight_controller_download","arguments":{"project_id":"<PROJECT_ID>","review_id":"<DOWNLOAD_REVIEW_ID>","expected_review_sha256":"<DOWNLOAD_REVIEW_SHA256>","verify_package_files":true,"capture_package_files":true,"maximum_package_read_bytes":33554432}}
```

这会真实只读访问设备，但不写、Stop/Start/Reset/Load或发行许可。capture=true而verify=false在连接前拒绝；响应总预算默认32MiB、范围1…64MiB，不足时明确失败，不能自动无限扩大。

预算统计为解密后的RSC响应字节，不含TLS握手流量；RSC各批/滴流共享30秒截止，本地写盘/检查耗时另计，不作整个调用硬实时30秒保证。[5项本机TLS测试](../artifacts/controller-package-read/tests.log)覆盖限定读取与快照保护，不能替代真实现场冻结。

允许路径仅来自不可变本地review的精确包路径；远端manifest不能增加读取权限。逐文件结果分别比较review候选字节与远端manifest声明，且检查manifest和状态前后稳定。远端与候选不同不等于读取失败，必须保留实际差异；但缺文件、声明哈希不符、路径集合不同、响应/预算问题或窗口不稳不能报告完整一致快照。

仅完整核验后capture才保存新PCWE目录，返回snapshot_path/inventory及逐文件哈希；仍不是完整远端目录枚举，不证明boot、内存loaded、原32POU恢复源匹配、厂商签名或可执行回滚镜像。不要把捕获的现场磁盘包直接当成已验证恢复包。源/包在读取期间改变也须使关联失效。

保存使用新临时目录，源/包在capture前后再核对并完成本地包检查后才发布正式快照；失败不把半成品当完整冻结。默认返回metadata预检状态，启用文件审计后分别报告preflight_file_audit_completed/incomplete及remote_package_audit，仍应读取逐项结果和remote_file_contents_verified。

本机正例project_test_controller_download fault=none/chunked_readback；反例write_error、short_results、readback_corrupt、write_reply_lost、reset_reply_lost、load_reply_lost、reset_timeout、load_timeout、initial_running、permission_denied、insufficient_space、rpc_error。逐项检查文件回读、manifest最后写入、Reset精确Ready、Load精确Stop，不把ACK当完成。

结果区分未连接、未变更、可能部分写入、全回读、Reset/Load尝试/完成和终态不确定。journal、files_may_have_changed、outcome_unknown、receipt_persisted和端点隔离租约比顶层success更重要。真实设备兼容必须在单独确认窗口验收。

## 五、M06 显式恢复原工程

先具备当前源绑定的完整恢复包，再创建整体计划；仅有旧PCWEX或manifest不是可执行回滚镜像。

```json
{"tool":"project_prepare_recovery","arguments":{"project_id":"<RESTORE_PROJECT_ID>","expected_project_sha256":"<RESTORE_SOURCE_SHA256>","package_job_id":"<RESTORE_PACKAGE_JOB_ID>","address":"192.168.0.8","expected_certificate_sha256":"3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863","volatile_data_policy":"require_drain","expected_configuration":{"version":13,"device_count":50,"point_count":250,"enabled":true},"start_kind":"cold","expected_initial_state":3}}
```

expected_configuration是届时明确的期望，不是手册替设备声明当前配置。require_drain默认要求排空证据；无法证明排空时不能声称零损失，需另行明确选择record_unknown_loss并在精确确认中记录RAM易失范围。Start模式会影响初始化/保持状态，不能自动改为另一个模式。

project_inspect_recovery重验整体及子审阅，操作者CLI kind=recovery确认完整计划。执行：

```json
{"tool":"project_execute_recovery","arguments":{"project_id":"<RESTORE_PROJECT_ID>","plan_id":"<RECOVERY_PLAN_ID>","expected_plan_sha256":"<RECOVERY_PLAN_SHA256>"}}
```

该调用会真实操作设备。整体收据明确observe_before、stop、write_package_paths、sha512_readback、reset、load、start、verify_runtime，连续端点租约贯穿全程；不暗扩原下载收据。一次明确恢复失败不自动触发另一次下载或回滚。

本机验证：

```json
{"tool":"project_test_recovery","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","package_job_id":"<PACKAGE_JOB_ID>","fault":"none"}}
```

反例fault含baseline_disconnect、initial_wrong、stop_reply_lost、write_reply_lost、readback_corrupt、reset_reply_lost、load_reply_lost、start_reply_lost、configuration_mismatch、runtime_disconnect、wrong_project_name。测试工具只建立自己拥有的loopback端和明确PUBLIC夹具收据，不能发行真实目标许可。

恢复结果分别检查original_package_loaded、运行配置/250GOOD窗口、原程序恢复观察、original_project_restored和collection_verified。当前外部DATA/STORED、原采样摘要完整匹配、mock及RAM损失证据未齐时，整体业务恢复必须保持未验，不能用Running或Owned=0替代。

### 后台执行、进度与取消

需要可查询/可请求取消的运行方式时，用project_start_recovery_job或project_start_controller_control_job启动同一精确消费者；得到operation_id后用project_controller_operation_status读取本地进度/可选最终结果，project_cancel_controller_operation写入精确operation/review绑定的协作取消标记。

这些入口不发行批准，也不绕过原执行器；queued/running不代表已完成。取消仅在检查边界生效，不能撤回已经发送的Stop/Write/Load/Start，不自动做逆动作。宿主进程死亡、状态无法证明或客户端超时需保留worker_outcome_unknown/needs_attention及租约，不能自动重启旧作业。进度查询本身不访问PLC。

```json
{"tool":"project_controller_operation_status","arguments":{"project_id":"<PROJECT_ID>","operation_id":"<OPERATION_ID>","expected_review_sha256":"<BOUND_RECOVERY_OR_CONTROL_REVIEW_SHA256>","include_result":true}}
```

```json
{"tool":"project_cancel_controller_operation","arguments":{"project_id":"<PROJECT_ID>","operation_id":"<OPERATION_ID>","expected_review_sha256":"<BOUND_RECOVERY_OR_CONTROL_REVIEW_SHA256>","reason":"operator_requested"}}
```

## 六、M07 故障控制

原32POU恢复工程不含独立硬TTL故障后端。project_prepare_fault_control可绑定boot、包、故障种类和100…300000ms期限，但普通原工程会标unsupported_real_backend；project_execute_fault_control必须拒绝，不能改用私有变量写/Force绕过。

本机独立监督测试：

```json
{"tool":"project_test_fault_supervision","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","package_job_id":"<PACKAGE_JOB_ID>","fault":"client_exit"}}
```

可选none、client_exit、cancel、boot_change、release_failure；客户端真实退出后监督仍须按时解除并读回，解除失败报告失败。单靠宿主finally不够。通信故障只针对受测Agent连接；业务ACK故障保持真实DATA/Hub提交，不伪造STORED，不停共享Hub/broker/mock。

另行生成的自TTL插桩profile属于不同源/包，必须额外审阅、单独验证才可用于故障测试；它不改写本轮原工程恢复身份。系统时钟修改、物理断电和P06不在此入口自动授权内。

### 独立插桩 profile 路线

project_create_fault_profile只从精确支持的原归档生成另一份33POU测试副本，不覆盖原32POU文件。它应先冷编译、打包，记录profile/source/inventory身份；不能把profile元数据套给未插桩原工程。

顺序为project_prepare_instrumented_fault→project_inspect_instrumented_fault→独立人工CLI kind=instrumented_fault→project_execute_instrumented_fault。本机profile验证先按独立测试报告复核；公开工具以实际参考为准，不把模块测试函数当成已注册MCP入口。不能以猜测字段或私有RSC脚本补齐。

最终已注册的独立profile本机入口：

```json
{"tool":"project_test_instrumented_fault","arguments":{"project_id":"<INSTRUMENTED_PROJECT_ID>","expected_project_sha256":"<INSTRUMENTED_SOURCE_SHA256>","expected_profile_sha256":"<PROFILE_SHA256>","package_job_id":"<INSTRUMENTED_PACKAGE_JOB_ID>","fault":"none","kind":"business_ack_blocked"}}
```

必须是独立profile和对应完整包，不可传本轮未改32POU恢复包冒充。该工具只使用自身本机夹具；故障种类与模拟异常分别为kind/fault，不能混用。

需要进度/取消时可用project_start_instrumented_fault_job启动同一固定消费者；复用operation状态/取消工具。它不开放任意变量写，不能借取消刷新PLC硬截止或假定已解除。

该路线额外绑定明确boot、请求代次、窄白名单、最大TTL及绝对到期；Commit后宿主退出仍由独立扫描期限解除，过期请求在晚Start后也不能重新激活。它与普通原工程unsupported路线保持分开。新profile完整冷编译/包/本机扫描和真实PLC期限须分别给证据，不因测试夹具TTL通过就宣称现场已经具有相同效果。

操作者收据仍有效也不能刷新故障请求的绝对期限；过期后应准备新审阅并重新确认，不把原请求改时间后重发。PLC停机、任务被阻塞和实际扫描/输出行为的边界仍需对应profile单独验收。

### 最终核内时钟 profile

故障专用时基已使用原厂 `GET_MICROSECONDS(TRUE)/1000`：随系统启动以来推进的CLOCK_MONOTONIC微秒转毫秒，替代先前故障专用Main TON时钟，不改变业务Main.NowMs。公开真实execute在staging前必须实读并观察核钟推进；模块存在或本地文件中的时间值不能替代该前置检查。

证据：[原厂库时钟契约](../artifacts/fault-write-research/clock-contract.json)、[最终profile](../artifacts/fault-profile-generation/kernel-profile.json)、[真实本机冷编译](../artifacts/fault-profile-generation/kernel-cold-build.json)、[完整本地包](../artifacts/fault-profile-generation/kernel-package.json)。最终测试副本project_id为 `9b2bc85d4b2944db92be9d9be58cadd0`，源SHA为 `476b0a0fba16a71712ff30ac5120e1d5e0e3825478f377e277d5e12ea91cbff0`，profile SHA为 `dae4c5dd0f0004669539e5977389784eff47c5b2b4315c4461c614bf6ae05e37`，49文件包身份以包报告为准。

旧231d/5cdd开头测试profile已被完整源重构比对拒绝；不能复用旧profile或审阅，也不能通过改profile JSON把旧时钟声明成核钟。上述证据为交付库契约、离线编译和本机测试范围；没有部署该33POU候选，尚未验证真机Stop/Start、扫描期限或物理输出行为。真实恢复继续使用原32POU源及其独立包/计划。

最终核内版 [17项测试与10个公开入口场景](../artifacts/instrumented-fault/verification.json)已绑定上述源/profile/构建/49文件包，原厂时钟和字节向量单列；不拿旧profile摘要替代，也不将本机结果升级为真机故障通过。实现细节见 [独立故障profile说明](instrumented-fault-profile.md)。

## 七、M08 固定系统时序读取和收据证据

固定系统变量路线是project_prepare_esm_read→project_read_esm；本机验证用project_test_esm_read。计划绑定源、AXC F2152/2026 profile、真实任务名称映射及明确端点/pin，限定ESM[1..2]和TASK[1..16]，不开放任意路径，不改原程序或启动P06。具体索引参数及fault集合以实际Schema/实现为准；精确类型证据、统计语义和重置限制见 [ESM说明](esm-monitor.md)。

```json
{"tool":"project_test_esm_read","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","fault":"none"}}
```

负例fault为missing_field、boot_change、wrong_task_name。真实只读计划可按需要显式选择esm_indices/task_indices，但索引须在固定profile范围内，不能猜测任意路径。

字段类型以本机官方模板和当前冷编译CIL核对：EXEC_TIME_THRESHOLD_CNT是UDINT/uint32；INTERVAL、WATCHDOG及LAST/MIN/MAX执行历时等为LINT，单位和语义附在观测报告；PRIORITY为INT，NAME按源STRING及实际布局处理。不能照搬其他版本网页类型。缺字段/固件不导出时保持unknown/unsupported，不以默认0填补。

报告要保留设备boot/程序切换、计数重置/覆盖、观测窗口、分辨率和监视负荷。LAST/MAX含调度抢占，不能推算新增业务CPU≤1ms，系统计数也不证明业务吞吐≥90或性能profile通过。固定系统变量实际可读与真机量测仍按对应报告单独验收。

project_runtime_timing_evidence另用于精确普通运行读取计划和已保存的1…32份观测身份：

```json
{"tool":"project_runtime_timing_evidence","arguments":{"project_id":"<PROJECT_ID>","read_plan_id":"<READ_PLAN_ID>","expected_read_plan_sha256":"<READ_PLAN_SHA256>","observations":[{"observation_id":"<OBSERVATION_ID>","observation_sha256":"<OBSERVATION_SHA256>"}],"probe_contract":null}}
```

有现存源探针时，probe_contract须绑定精确源SHA、probe_version、resolution_us及已读白名单字段/角色。没有探针返回unknown/unsupported；不临时给原工程加字段冒充原有能力。跨boot、计数复位/覆盖、采样空洞和分辨率均需要保留。

UTC只是标签，单调测量不跨设备相减；RPC历时不能当任务CPU执行时间。新增工作与整任务需同profile原工程对照；MCP不据此宣布≤1ms、≥90条/秒或P06通过。本项不启动新的性能测试。

## 八、M10 多任务

project_clone_program、project_change_cyclic_tasks、project_declare_task_ownership新增独立Program、周期任务和source/closure-hash独占合同。限定单eCLR、1…16周期任务；名称/ID/实例唯一，跨任务同Program类型及共享可变数据拒绝。原任务拥有既有global/nativeIO时，额外任务只能locals-only，禁止外部/地址/指针/共享状态调用。

源码改变后合同失效；明确重新声明检查，不能删门禁。运行配置/CIL/原生字段逐项验证，不宣称任意内存形式化安全、库内部线程安全或共享FIFO所有权交接已经解决。具体参数和真实本机证据见 [多任务说明](independent-multitask.md)。当前真实恢复仍使用未改32POU单任务包。

## 九、M09 一致性与交付记录

实际工具目录由export_mcp_reference.py生成，--check只比较不写入；没有PLC网络、收据发行或编译行为。新增工具原始描述和Schema总会导出，缺中文范围批注会列待核对，不固定断言55等数量。

交付逐项记录：ID、版本/工具、实现状态、离线/loopback/真机证据、精确输入/源/构建/包/审阅身份、已发动作、不确定标记、report_path、限制。首次真正设备操作前，最终精确包/计划hash、文件差异和停启/RAM影响由维护方另列；本指南不预先代签。

本机通过以后再进入获准真机窗口；遇到无法核查、无法解除或无法恢复，保留journal/claimed/租约，报告具体阶段和未完成项。不得删证据、缩分母、以单一PASS隐藏真机未验或用Running代替业务恢复。
