# M14 逐事件时钟与漏槽原始事实导出（0.6.9）

## 调用

新审计v2候选：project `82123e07e30b4ad195c8fd5b69544eeb`，源码 SHA256 `d403231d283d60d0e12f8dbdc7db38dd79c10d23490d1d8dd6c63eabfb1a65f4`，离线包 `9ccf64a8e3824990bd738a19f70dd550`。

在 `project_prepare_recovery` 原有精确参数上增加：

```json
{
  "audit_duration_seconds": 30,
  "audit_closure_mode": "source_cohort",
  "audit_tail_seconds": 30,
  "audit_fact_mode": "decision_clock_slots_v2"
}
```

独立 `project_prepare_audit_export` 使用 `fact_mode="decision_clock_slots_v2"`；其余参数如 `closure_mode="source_cohort"` 仍按M13。prepare/inspect只作本地审阅，不授权、不连接设备。模式进入子policy/哈希，父哈希引用子哈希。默认仍为legacy_v1；旧计划不补字段、不升级旧证据。

## 原始记录与守卫

源解析器解析全部标量，不使用硬编码地址或偏移。v2白名单20148项，严格检查新字段wire类型：AuditFactSchema/DecisionFlags/RevisionDelta/DelayHi/ReportSkipped为byte，DelayLo为uint16，PollSkippedBefore为uint32，AuditFactsComplete为bool。任何缺字段或错类型拒绝v2准备；运行中schema必须为整数2，字段类型不匹配拒绝读取。

capture.event原样保存Event.PollSkippedBefore与五个Decision/Report标量，原采集UTC不改写。读取开始先保存sampleSeq和Decision，读取全部标量/字典后再复读完整事件；核对发布提交、boot、配置代际与环界。Pending不确认；发生变化（包括同一终态下事实改写）则失败，不确认该批。始终先fsync再使用原四个审计ACK字段。

start与end/sourceCohortEnd写audit_fact_schema=2，终态audit_facts_complete是PLC AuditFactsComplete原值。另写audit_fact_encoding_complete（导出原始前缀的编码检查）和v2_facts_complete（原标志且编码检查通过）。未知/越界编码不升级完整声明，但已经发布、稳定、可完整保存的原始UNKNOWN记录仍可确认审计副本；原始环损失与业务UNKNOWN独立保留。

位0未发布、非法类型/范围、schema混用或读取变化不ACK。位3/4/5不齐、ReportSkipped=255、安全整数超界、质量/物理编码混用会使编码完整性为false。质量位6保留原始偏移字节，不将它写成漏报告槽计数，也不推算缺失原点。位2当前失效或版本差非零本身可以是精确事实，不自动将其判为编码损失。

## 验证范围与限额

本导出器不声明独立选择器或物理网格核验通过，decisionTimeClockSeparatelyAttested、missedSlotsIndependentlyVerified、trailingUncompletedPollWindowProven保持false。外部核验器根据完整原始记录、首次UNKNOWN原点及配置独立计算；缺首UNKNOWN、重复槽、采样代际变化等由该核验器拒绝证明。源N与窗口外计数、混合整批、业务STORED/DB及全局UNKNOWN口径保持M13。

单次DataAccess读取仍至多64标量；固定每轮64capture/16association。v2额外前后复读会增加RPC量，但原网络操作20000、网络字节67108864、记录100000/字节67108864默认限额不放大，所有限额进入审阅。父总期限300秒，tail 1..120秒，运行+tail+业务观察预算不超过240秒。没有以RPC耗时证明扫描成本或吞吐。

本地接收包括固定候选源hash、错类型/缺字段、标量边界、UNKNOWN、同终态字段变化、Pending、fsync失败、父共享租约下v2+source_cohort首尾版本，以及已有取消/额度/核销回归。外部受约束核验器89项纯测试通过（数据库与网络调用被禁止）。IEC20项断言依然只有编译证据，本轮未执行。

公开适配记录：artifacts/audit-export-research/public-m14-verification.json。本轮没有连接真实PLC、签发真实执行授权、下载或性能复测。
