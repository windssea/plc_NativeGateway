# Independent device toolchains (MCP 0.6.15)

Device models are data in `src/plcnext_mcp/profiles/eclr-2026.json`, not branches in the compiler host. Each immutable profile declares a compiler family, package family, device/revision, template, backend, runtime reference package/prefix, image ABI, native ELF ABI, product identity, source hardware fingerprint and HMI authentication mode.

| Profile | Native backend | Image processor/model | Native SO | HMI authentication |
|---|---|---|---|---|
| AXCF2152-2026-v1 | cilc-armthumb2-arm-v3.0.0.dll | 2306 / 81 | ELF32 ARM (40) | 0 |
| AXCF1252-2026-v1 | cilc-a64-gcc3-v3.0.0.dll | 515 / 34 | ELF64 AArch64 (183) | 2 |

Both currently use the installed eCLR Core `Copy/3.4.0/` metadata, copied independently into each job. Sharing a read-only vendor input does not share mutable build output or queues. Every managed project, revision, native build and deployment package has its own directory and hash-bound receipt.

## Adding a model or hardware variant

1. Import the real engineering source using `project_import_copy`.
2. Call `project_inspect_device_profile` for its exact source hardware fingerprint and selection. No device access occurs.
3. Call `project_device_profiles` to inspect existing families and installed backends/templates.
4. Register a new immutable specification with `project_register_device_profile`. Only implemented families are accepted. Unknown models never fall back to 2152. A profile ID and an exact model/revision/hardware fingerprint cannot be overwritten. Multiple hardware variants of one model/revision are supported and selected by exact fingerprint.
5. Use `project_release_register_target` to register the independent IP and gateway identity of another instance. Existing IP/gateway bindings cannot be replaced, including `.8` and `.10`.
6. Prepare a dev release, compile the returned managed copy, generate its PCWE and bind the package. Match source hardware/service/HMI settings, compiled image ABI, native SO architecture, all runtime offsets and package product identification.
7. Independently verify the new model on hardware when authorized. Registration and successful offline builds do not certify device execution.

Registered specifications live in `PLCNEXT_MCP_DEVICE_PROFILES_DIRECTORY`, defaulting to `~/PLCnext-MCP-DeviceProfiles`. They are capped, schema checked, immutable and cannot inject shell commands or arbitrary backend paths. A new runtime/compiler family needs a new tested family adapter; registration alone does not implement one.

The current family `eclr_2026_st_cyclic` supports one eCLR resource and bounded independent cyclic ST tasks. The package family `nativegateway_hmi_2026` supports the examined hardware/services and Gateway/Login application. Empty I/O, native-library compatibility, namespaces, unimplemented HMI authentication modes and other existing guards remain explicit. There is no claim to support arbitrary PLC vendors, I/O topologies or firmware generations.

## Binding and isolation

- Before invoking the vendor host, the job freezes `device-profile.xml`, the selected runtime package and all project/library inputs. The C# model builder verifies the device/revision against this descriptor rather than a model-name whitelist.
- Receipts bind profile ID/hash, compiler backend hash, runtime package hash, source hashes and output hashes. A changed profile requires rebuilding before packaging.
- Native image metadata is inspected as data, using `deployment_inspect_native_image`; PLC instructions are not executed on the host.
- Native `.so` files must match the exact target ELF class/machine/little-endian ABI. Wrong-architecture payloads fail before a package can be published.
- ESM array lengths and offsets come from source and finalized image metadata. They are not fixed to the 2152 layout.
- HMI authentication is retained: the 1252 source AccessRights=2 generates protocol 2. HMI must not be omitted or downgraded to protocol 0 to bypass a guard.
- Device instance release bindings and immutable version hashes remain separate from business configuration versions and observed boot identities.
- `project_release_block` appends a withdrawal record, preserves every original byte and blocks real download/recovery. A corrected candidate gets a new dev version.

## Acceptance evidence

Real stdio MCP clients compiled and generated complete PCWE packages for 1252 and 2152, validated the native image ABI, and passed tagged in-memory download simulations. A synthetic future model exercised MCP registration, selection, instance binding and rejection rules; no hardware support is claimed for that synthetic model.

See the Hub backend report `docs/verification/2026-11-20-axcf1252-mcp-cold-build.md`. Hardware download/reboot and business recovery are separate acceptance steps and were not performed in this change.
