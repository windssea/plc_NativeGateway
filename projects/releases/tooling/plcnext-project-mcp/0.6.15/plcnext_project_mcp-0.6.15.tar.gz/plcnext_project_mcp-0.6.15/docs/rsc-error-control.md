# Tagged RSC 错误帧与 Stop：独立 codec 证据

2026-10-26。新增 [rsc_error_codec.py](../src/plcnext_mcp/rsc_error_codec.py) 和 [rsc_plc_control.py](../src/plcnext_mcp/rsc_plc_control.py)，用于真实 TCP/TLS 下载客户端及本机测试控制器。本模块没有 socket、设备端点或 ACI 依赖；本轮仅执行原厂 formatter 对合成 MemoryStream 的读写。没有调用任何真实服务，没有连接 `192.168.0.8`。

## 观察到的 ERROR(4) 格式

源方法 `RemotingFormatter.ReadError2` token `0x060000bb`；外层 `RemotingFormatter4.DeserializeMessage` token `0x060000ce`。

| 分支 | 方法头后面的值体 |
| --- | --- |
| 普通错误（code 最高位为 0） | `09 + UInt32LE code`；`1A + UInt16LE 字节长度 + UTF8 文本及 NUL`；`14 1C + Int32LE Object[] 长度 + 各项的实际类型 tag/value`；`FF` |
| fatal（code 最高位为 1） | 只有 `09 + UInt32LE code`。没有 message、arguments 或 `FF` |

普通 ERROR 的 message/arguments 在 CIL 中使用 `AdeMarshalType` 数值 1。**本机 .NET 8 实测的文本为 UTF8 字节，不是 UTF16LE**。现有较早 untagged 辅助 codec 把该数值解释为 UTF16，不能直接用于本构建 tagged 客户端。示例中文两个字符在原厂输出中为 `e6b58be8af95`。本实现的 profile 限定于当前原厂构建和本轮验证的文本语义，不推广到旧 .NET/其他 marshal 类型。

原厂 fatal 路径 `ReadError2` 返回 false，外层直接构造错误响应对象，跳过 `ReadEndDataTag`；因此不能无条件等一个 FF，否则实际流会等待不存在的数据，或误消费下一条帧。

`receive_error(read_exact)` 在调用者已经解析并检查 header 后读取一个 error body，支持短片段并保留下一帧。`decode_error(packet)` 则检查完整 ERROR header、checksum、flags、body 和尾随字节。返回原始 code、fatal、message 和 arguments，不进行 .NET 格式化、反射或异常类型实例化。

边界是 64 KiB body、4096 字节/文本、16 个 Object[] 参数。参数支持本轮测过的 string、Bool、Int32、UInt32 和 Int64 wire 标签；编码器仅按测过的 Python 数值区间选择类型。未知/null/CLR 对象、嵌套数组、其他 profile、带 token 的 error response、未知 tag 和过长/截断数据拒绝。调用者仍必须验证动态 service/provider/method 是否对应当前请求，并决定 fatal/普通错误后的连接和不确定操作恢复；codec 不做重试。

## Stop(bool async) 格式

原厂 `IPlcManagerService.Stop` token `0x060000bd`，RSC method ID **3**，参数为 Boolean `async`，返回 void。原厂 `SerializeMessage` 产生：

| 参数 | tagged 方法值体 |
| --- | --- |
| false | `02 00 FF` |
| true | `02 01 FF` |
| 正常回复 | `FF` |

完整 header 使用动态 service/provider 句柄；已有 token header codec 可在正常调用中加 UInt32 安全 token，包括 0。`encode_stop_request/decode_stop_request` 只提供该值/调用框架，`encode_stop_response/decode_stop_response` 只处理正常 ACK。**ACK 不证明程序停止，真实客户端必须继续 GetPlcState 并验证错误标志和期望状态。** 本轮没有执行真实 Stop，也没有新增可绕过人工确认的设备控制入口。

## 原厂 oracle 与验证

宿主：[Invoke-RscErrorControlOracle.ps1](../tools/Invoke-RscErrorControlOracle.ps1)。[11 个完整原厂向量](../artifacts/rsc-error-control/oracle-02/report.json)包括：

- Stop(false/true) 的 2 个真实 `SerializeMessage` 请求；2 个由原厂 `DeserializeMessage` 完整消费的正常回复。
- 普通错误的空文本、ASCII、中文、字符串参数、Bool/Int32/UInt32/Int64 参数 5 个帧。
- `0x80000000` 和 `0xffffffff` 两种 fatal code-only 帧。

普通/致命错误的值由真实 `SerializeValue` 生成，header 由真实 `CommandHeader.Write` 写入，然后由真实 `RemotingFormatter4.DeserializeMessage` 检查并消费全部字节。没有仅靠自有编码/解码往返自洽来认定原厂兼容。

[test_rsc_error_codec.py](../tests/test_rsc_error_codec.py) 的 6 项测试通过：原厂逐字节匹配、全部截断位置、尾随字节拒绝、1/2/7 字节碎片和后续帧保留、未知 Object/错误 tag/范围拒绝、header/校验/token/profile 拒绝，以及 Stop ACK 的方法校验。测试不加载厂商代码也不联网。

## 文件清理接口的静态边界

沿用 [rsc-file-contracts.json](../artifacts/plc-download-research/files/rsc-file-contracts.json) 的准确服务声明：

- `IFileService2.DeleteMany` method **10**，`String[] filePaths → FileSystemError[]`。
- `IDirectoryService.EnumerateFileSystemEntries` method **7**，`path, searchPattern, recursive → IEnumerator<FileSystemEntry>`。
- `IDirectoryService.EnumerateFileSystemTraitsEntries` method **8**，`path, searchPattern, traits, recursive → IEnumerator<FileSystemTraitsEntry>`。
- `IDirectoryService2.DeleteMany` method **11**，`String[] paths → FileSystemError[]`。

这些是准确元数据，不是已实现/已实测的下载客户端功能。枚举返回 IEnumerator，其 remoting 流/远程枚举生命周期尚未在本轮恢复，不能把普通 DTO 数组编码冒充完整目录发现。生产链路应先明确旧文件清单/删除范围并验证后续行为，不能拿内存 simulator 的 reconcile 当成真实远端清理协议。

## 文件身份与覆盖

| 程序集 | SHA-256 | MVID |
| --- | --- | --- |
| Ade.CommonRemoting.Commons.dll | `ab1382d433254d8694bf53c265e29b16445c323528a7ed2389a23068c6f3246e` | `25aefcf5-ce5b-4e77-820c-46bb5192515a` |
| Arp.System.Rsc.Services.dll | `214e68d812d65a374b6085232f88cfd574a9a80f28e1e91b07eb01abb9af98cb` | `0efae051-468d-4aac-97a3-1df3e929ee07` |
| Arp.Base.Rsc.Commons.dll | `2ee2402786ad430883cd48d905bcad4bd301e3dcdb783ea7f6daf9ddf1bf0c77` | `d2b5b256-a201-4907-9387-e2450838f3f1` |

Commons 的本轮 REA artifact Evidence：`ev_3f26ab9ee4007bbd50387873091341ec5872813352215beeb2d082445a8158a7`，保存于 [rea-evidence.json](../artifacts/rsc-error-control/rea-evidence.json)。方法 CIL 复用 [rpc-formatters-il.json](../artifacts/plc-download-research/auth/rpc-formatters-il.json)；Stop 和目录元数据复用 source-bound 服务清单。补充坐标及来源摘要在 [static-anchors.json](../artifacts/rsc-error-control/static-anchors.json)。

静态观察、纯内存序列化执行和真实设备测试是不同证据：这里完成前两类，没有设备下载、错误返回、权限或停机效果的真机验证。
