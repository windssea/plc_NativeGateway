# 独立真实下载客户端：0.5.0 验证与只读设备检查

2026-10-26（Asia/Shanghai）。本轮补齐了使用 **真实 TCP socket + TLS 1.2** 的独立 RSC 下载客户端，并用 NativeGateway 副本在本机测试设备上完成文件写入、SHA-512 回读和 Reset/Load。客户端不调用 ACI、不启动 Engineer，也不使用 computer use。

**尚未向真实 PLC 下载。** `192.168.0.8` 保持只读，没有为它创建写入授权，没有发送 WriteMany、Stop、Start、Reset 或 Load。实际下载仍须用户先确认具体版本和影响；审阅记录本身没有写权限。

## 已完成的链路

[生产客户端](../src/plcnext_mcp/controller_transport.py)通过明确的证书 SHA-256 pin 建立 TLS，再协商 RSC v4 tagged/no-datagram、动态服务/provider 句柄。正常方法返回和 ERROR 帧按已验证 schema 读取，支持短片段，不把一次 `recv()` 当作完整消息。

[传输编排](../src/plcnext_mcp/controller_transfer.py)使用同一客户端完成：

1. 核对精确授权范围和包字节，连接并验证 peer pin。
2. 新鲜读取 PLC 状态，要求原始状态恰为 Stop（2），不带错误/忙标志；不会自动停机。
3. 解析符号工程根、查询空间，核对原有 PCWE manifest 声明的文件路径。
4. 整文件 WriteMany；数据文件先写，`PCWE.manifest.config` 最后写。逐项错误、缺项和部分结果均拒绝。
5. 回读全部包文件，核对长度和 SHA-512，全部通过才能继续。
6. Reset(true) 后等待 Ready（1），Load(true) 后等待 Stop（2）。ACK 只表示回复已收到，不能替代状态完成检查。
7. 关闭连接、持久化结果和恢复诊断，不自动重试、Start、删除旧文件或回滚。

匿名模式和测试凭据模式在客户端中分开处理；当前实际候选审阅为匿名模式，不保存密码或 token。真实设备能匿名读取状态，不证明匿名写入或 Load 有权限。

## 真实 socket 验证，不是 MemoryBIO 模拟

主证据：[真实 MCP stdio 全链结果](../artifacts/controller-download-client-mcp/eb338eaa013b4a9aa7c69f64c9284144/result.json)。该轮从新管理副本重新冷编译、生成包，再由生产 socket 客户端连接仅绑定 `127.0.0.1` 随机端口的 [TLS 测试控制器](../src/plcnext_mcp/controller_test_peer.py)。测试控制器将数据写入作业目录中的真实本地文件，随后由同一网络会话回读；不接受外部目标地址。

| 验证项 | 结果 |
| --- | --- |
| 输入 | NativeGateway 冻结副本，61 POU；没有为本次测试修改逻辑、任务或接口 |
| 构建 | 新冷构建，无项目 AST 种子；新完整 PCWE |
| 文件 | 48 文件、9,370,814 字节，经实际本地 TCP/TLS 写入并回读相同 |
| 配置 | 本机测试设备 Reset/Load 各执行，加载后 Stop 状态验证通过，没有 Start |
| 写回复丢失 | `transfer_failed`、`outcome_unknown=true`，不自动补写，不 Load |
| 回读损坏 | `readback_failed`，阻止 Load |
| Load 回复丢失 | 48 文件已验证，但加载结果未知，不能声称设备未改变 |
| Load 超时 | 明确配置超时及不确定后果，不自动再次 Load |
| 初始 Running | 文件写入前拒绝，不自动 Stop |
| RSC ERROR | 解析原始错误码并中断，不能当作正常 ACK |
| 未授权执行 | 真实执行入口缺少独立人类确认收据时，在 socket 创建前拒绝 |

此前 0.4 的 MemoryBIO 结果继续作为字节格式/模拟证据；这里新增的是操作系统 socket、TLS 会话、独立测试设备和真实本地文件。**本机测试设备的成功不等于 PLC 固件已接受写入或运行。**

独立发行包验证：[0.5.0 wheel 新环境结果](../artifacts/controller-client-wheel/37a4cf8bdb494bdc946fc1432a9d626b/result.json)。从仓库外使用安装包而非源码 import，实际发现 34 个工具，并对同一 48 文件集完成本地 TCP/TLS 写入、回读和配置状态验证；没有连接真实 PLC或创建真实授权。这是该次证据记录的工具数量，后续新增只读预检单独列证。

## `192.168.0.8` 的只读结果

同一次 MCP 验证使用生产 socket 客户端读取目标，结果为 **Running**，原始状态 3。发送清单限定为 Connect、固定 IPlcManagerService 发现及 GetPlcState；没有登录会话、文件写入或配置控制。具体记录见 [只读结果](../artifacts/controller-download-client-mcp/eb338eaa013b4a9aa7c69f64c9284144/05-device-readonly.json)。

peer 使用明确 pin `3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863`。pin 匹配不被描述为系统 PKI 链或当前 IP 主机名校验通过；证书变化会在 RSC 应用请求发送前拒绝。

### 额外只读预检

`project_preflight_controller_download` 已通过真实 MCP 调用，最终服务有 **35 个工具**。[实机只读结果](../artifacts/controller-readonly-preflight/42addf0b137c4c228ae1914c5a0bc6c5/result.json)记录 Running、可用空间 202,657,792 字节，以及固定两个 metadata 文件的读取。没有认证、写入、Stop/Start/Reset/Load 或删除。

该次观察的设备版本名为 `NativeGateway.pipeline-cost-candidate-v3`，声明 49 文件；冻结回归样例为 48 文件，设备多出 `dlc.bin`，13 个共同声明哈希不同。它是元数据声明比较，不是完整远端目录/文件回读证明。用户已说明设备正在持续调试修改：**这类版本差异作为正常调试状态记录，不为追齐实时版本反复生成候选，也不作为本轮客户端验证失败。** 正式下载时仍需重新冻结并确认当次版本、影响和文件处理策略。

真实读取还揭示原先未覆盖的 chunked stream：首 Int32 是 buffer hint，并非总长度。已用 [原厂 38 个 oracle 案例](../artifacts/rsc-read-errors/oracle-04/report.json)及静态 CIL确认并修复，随后实机两份 metadata 成功读取；保留失败阶段报告，不把失败当作成功。接收端按长度读块到 -1，限制实际总字节与块数；不按巨大 hint 分配内存。见 [分块流检查](../tests/test_rsc_stream_chunks.py)。

## 本轮冻结的 NativeGateway 回归样例

本轮为回归和审阅机制验证生成了全新的管理副本。它保留冻结输入的逻辑、任务和接口；不是此前 0.4 调整过任务周期的测试副本。用户尚未选定正式部署版本，此样例不代表应覆盖正在调试的设备程序。

| 项目 | 精确值 |
| --- | --- |
| 工程 | NativeGateway，61 POU，managed revision 0 |
| 工程 ID | `a2512e4f551645e4acd00fae07f003cd` |
| 源 SHA-256 | `e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0` |
| 冷构建 ID | `e69048fafa80468595aaf99825b12d89` |
| 包 ID | `345799d58da449ef86866865021a3806` |
| 软件 revision | `1792989210734055000` |
| 包生成时间 | 2026-10-26 12:33:30.734055（Asia/Shanghai） |
| 包 inventory SHA-256 | `0a9d10de630f115c8b9df4916dab17387a4fe5cac8c1d0c55115c2dfbc8c1c10` |
| IMG SHA-256 | `e0fbc44c72c00d85cc040fcac2abafe39698c6171f1ea1006f658e01e01a3d7b` |
| 文件/字节数 | 48 / 9,370,814 |
| 审阅 ID | `29a6e79b0b984dc399f7b595d8216daa` |
| 审阅 SHA-256 | `69af4f624198c2c1a4b2cf408576ec158495059f9eb13f402d42408f24773244` |
| 目标 | `192.168.0.8:41100`，上述明确证书 pin，匿名模式 |

[精确审阅记录](/D:/PLCnext-MCP-Workspace/a2512e4f551645e4acd00fae07f003cd/controller-download-reviews/29a6e79b0b984dc399f7b595d8216daa/review.json)包含每个文件的字节数、SHA-256/SHA-512、源/构建/包身份、目标及影响，当前始终为 `awaiting_user_confirmation`、`write_authorized=false`。

包内声明 target product `2404267`、target firmware `26.0.0`，不等于已经核实真实 PLC 当前固件兼容。当前仍未验证包签名接受、实际控制器加载和物理程序行为。77 全局变量、109 工程内 FB 实例、10 HMI 映射已经通过离线绑定核验；库 FB 不计入 109 项逐字段布局检查。

## 下载影响与当前阻塞项

- **必须先停机。** 当前只读结果为 Running，下载器会在新鲜状态不是 Stop 时拒绝；该审阅不包含 Stop 许可，也没有自动停机动作。确认文件版本不会绕过这个前置条件。
- **会覆盖包内文件并重置、重新加载配置。** 连接可能断开，期间可能没有已加载工程；不是原子切换，没有自动回滚，停机时输出与物理行为未验证。
- **不发送 Start 不等于固件一定不自动运行。** Load 后的实际运行行为尚未真机验证；若读到非预期 Running，客户端记录异常并保留事实，不偷偷 Stop。
- **不删除旧文件。** 真机写前要求原有 PCWE manifest 声明的路径集合与候选一致。manifest 不证明目录没有未列出文件，因此独立人类确认还须明确知晓保留未列出文件；客户端不声称远端目录逐项完全等价，也不调用模拟器 reconcile 冒充远端清理。
- **不确定结果不能自动重试。** 写入或 Load 已发出而回复丢失时，设备可能已改变；保留作业、日志和目标隔离锁，等待恢复处理。

上述影响是需要用户确认的具体内容；本轮没有替用户确认、生成授权或操作设备程序。

## 工具使用顺序

| 工具 | 行为 |
| --- | --- |
| `project_prepare_download_review` | 从当前源绑定包生成版本/目标/影响审阅，不联系设备、不授予权限 |
| `project_preflight_controller_download` | 审阅绑定的匿名只读状态/空间/固定元数据核对；不授予写权限 |
| `project_inspect_download_review` | 读取并默认重验本地源/包/目标/哈希，保持未授权状态 |
| `project_test_controller_download` | 用生产 socket 客户端和仅本机随机端口 TLS 设备测试副本，不接受外部地址 |
| `project_execute_controller_download` | 仅消费独立、精确、有效期内的一次性人类确认收据；没有收据则零 socket 拒绝 |
| `controller_read_state` | 真实设备的明确 pin、固定服务状态读取；不触及文件或配置 |

已生成审阅的检查参数：

```json
{
  "project_id": "a2512e4f551645e4acd00fae07f003cd",
  "review_id": "29a6e79b0b984dc399f7b595d8216daa",
  "expected_review_sha256": "69af4f624198c2c1a4b2cf408576ec158495059f9eb13f402d42408f24773244"
}
```

把上述参数传给 `project_inspect_download_review`；`revalidate_package` 默认 true。本地 socket 验证使用：

```json
{
  "project_id": "a2512e4f551645e4acd00fae07f003cd",
  "expected_project_sha256": "e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0",
  "package_job_id": "345799d58da449ef86866865021a3806",
  "fault": "none"
}
```

将其传给 `project_test_controller_download`。该工具新建测试作业，不修改候选，也不会把真实目标地址传给测试设备。可改 `fault` 为 `write_reply_lost`、`readback_corrupt`、`load_reply_lost`、`initial_running`、`rpc_error`、`load_timeout` 等，核对拒绝和不确定状态。

实际执行使用同一审阅 ID/hash，但必须先有受控宿主在收到真实用户确认后独立创建的有效收据。MCP 没有批准工具，也没有自动发行收据脚本；知道 review ID/hash、调用 prepare/inspect/test 都不能获得设备写权限。源码、包、目标或策略变化需要新的审阅和确认。

## 审批、日志与恢复边界

批准收据绑定精确 review/source/inventory/target/policy/actions，含确认来源和不超过一小时的有效窗口，使用排他 claim 一次性消费。claim 在任何连接前 flush/fsync；接收端会检查 claim 期间收据是否改变。有效窗口用于准入，不提供超时重发权限。

`confirmed_by="human_user"` 和确认 reference 是**本地受信发行者约定**，不是密码学人类身份证明。收据目录只能由受控操作者/宿主在收到真实确认后写入，不应把任意本地文件写者视为可信；MCP 仅消费，不能自签发。

同一用户 profile 下固定的 `~/.plcnext-mcp/controller-endpoint-leases` 按 IP/port 互斥，跨 MCP workspace 和不同 pin 也不能同时操作同一端点；不依赖各进程的 TMP/TEMP。出现失败或不确定的设备变更时保留隔离锁，新的未消费收据也不能绕过它。这里不承诺跨用户、跨机器分布式锁。

首个 socket 之前 fsync 的 ExecutionBinding 记录 review、源、inventory、目标及作业，后续 mutation 意图先写日志再发送。加载已完成后若本地 result 落盘失败，返回结果保留已加载/可能写入的事实，标 `receipt_persisted=false` 并保留目标隔离；清理锁失败不会遮蔽原始错误或设备效果，尽量追加恢复日志。[17 项审批边界测试](../tests/test_download_approval_guards.py)均使用临时 PUBLIC 收据、RFC5737 地址且禁止 socket；[审查记录](../artifacts/controller-download-review/approval-guard-audit.json)列出验证范围。

调用 flush/fsync 不等于已做实际断电恢复测试。进程/网络中断不能被报告成已撤销远端动作；MCP 等待取消也不等于设备任务取消。需要按留存的版本绑定、动作日志、peer 状态和文件回读决定恢复，不能删除隔离文件后直接盲重试。

本轮协议错误/Stop 的原厂纯字节证据见 [RSC ERROR/控制格式](rsc-error-control.md)，其中 Stop 的恢复仅证明格式，不意味着本轮真实执行过 Stop 或审阅已批准停机。开发主线继续保持独立实现，不需要 ACI 或 computer use。

最终回归 **374 项：373 通过、1 项因 Windows 符号链接权限跳过**，耗时 35.784 秒。[日志](../artifacts/controller-download-client-full-tests.log)。新增 35 工具的 [独立 wheel 检查](../artifacts/controller-client-wheel/28157ffd0d894f8f81e83953e7831914/result.json)再次完成 48 文件真实本机 TCP/TLS 写入、分块回读和 Reset/Load，使用 Int32Max buffer hint 与多个 chunk，未从源码树 import，也没有访问真实 PLC。

[0.5.0 wheel](../dist/plcnext_project_mcp-0.5.0-py3-none-any.whl)有 57 条目，SHA-256 `a68515ef38f6506a9b6add2c8f41d3234bcdd1eaf29637f8d6cd19a0943abef9`。此前 34 工具记录保留为准确阶段证据；[发布验证](../artifacts/controller-download-client/release-verification.json)绑定最终源码、wheel、测试及只读范围。
