# 本机 TLS/TCP 控制器测试设备

2026-10-26。实现：[controller_test_peer.py](../src/plcnext_mcp/controller_test_peer.py)。它是供独立生产下载客户端连接的**测试设备**，不是真实 PLC 后端，也不调用 ACI、Engineer 或 computer use。

本轮将传输从此前 `MemoryBIO` 的进程内循环推进为实际 TCP socket / TLS 1.2：测试设备在 `127.0.0.1` 随机端口监听，客户端经过 TCP、OpenSSL TLS、RSC 协商、动态服务发现和已知 tagged 方法格式，真正将字节写入指定测试目录并回读。业务文件/状态模型没有复用 `InMemoryController`。

## 边界和 API

```python
from pathlib import Path
from plcnext_mcp.controller_test_peer import LocalTlsController

with LocalTlsController(Path('new-empty-job/device-files'),
                        anonymous=True,
                        allowed_files={'Plc/Eclr/eCLR.img'}) as peer:
    address = peer.address                 # fixed 127.0.0.1, no setter
    port = peer.port                       # OS-selected ephemeral port
    pin = peer.certificate_sha256           # PUBLIC fixture certificate
    # Connect the same production TLS/RSC client to address/port with this pin.
    # It must receive proper approval separately before any non-fixture write.
    files = peer.snapshot()                # actual local file bytes
```

- 构造器没有外部 bind 地址或固定端口参数，监听位置在实现中固定为 loopback。
- `root` 必须是新目录或空目录，拒绝已有非空目录、符号链接或 junction 根。文件路径必须在固定远端根 `/emulated/projects/PCWE/` 下，禁止绝对路径、`..`、反斜杠、NUL 及冒号；可选 `allowed_files` 精确限定文件清单。
- fixture 使用包中的**公开测试** CA/证书/私钥，只供本机测试。证书 pin 是 normal `server.pem` DER 的 SHA-256；`tls_error` 故障换用另一个公开测试证书，使正常 pin 校验失败。
- 接收器按 schema 消费被 TLS/TCP 任意切分的数据，不扫描二进制文件中的 `FF`，不假定单次 recv 是一帧。可用 `response_fragment_bytes=7` 强制细碎返回。
- 线程、连接及监听 socket 由 context manager 释放，`thread_alive` 可核验后台线程已结束。错误不记录请求原文、密码、安全 token 或文件明文。

`anonymous=False` 使用固定的公开 fixture 用户名 `fixture-user` 和密码 `PUBLIC-fixture-password`，实现正常 CreateSession、错误凭据、token 保护和 CloseSession；不能把这个授权策略解释成真实设备一定允许匿名写入或可使用该密码。

## 支持的测试服务

四服务声明与已测 tagged schema 对应：Password 的 CreateSession/CloseSession；File 的 WriteMany/ReadMany；FS 的 GetSupportedTraits、符号根解析和 GetSpace；PLC 的 GetPlcState、Stop(bool)、Reset(bool) 和 Load(bool)。服务/provider 句柄在每条连接动态分配。

WriteMany 写到真实测试文件，ReadMany 读取真实文件。Permissions 作为 fixture 元数据保存，**不表示实现 Windows 主机 ACL 的等价语义**；空间查询使用本机测试根的磁盘可用容量。没有发明远程目录枚举或删除接口，也不自动清理旧文件；新/空目录要求把这个未实现范围保持明确。

状态模型是明确的测试选择：初始 Stop(raw2)，Stop→raw2，Reset→Ready(raw1)，Load→Stop(raw2) 并记 `loaded=true`。它没有执行 PLC 程序、验证控制器镜像或保证实际设备加载后的行为。Stop 参数及正常/致命 ERROR 格式来自 [纯内存原厂 oracle](../artifacts/rsc-error-control/oracle-02/report.json)，不是按名字猜测。

## 故障场景

`none`、`write_reply_lost`、`readback_corrupt`、`write_error`、`short_results`、`load_error`、`load_timeout`、`reset_timeout`、`initial_running`、`tls_error`、`permission_denied`、`insufficient_space`、`load_reply_lost`、`reset_reply_lost`、`rpc_error`、`fatal_error`。

其中 `write_reply_lost` 在实际文件写入之后关闭连接；`load_reply_lost` 在 fixture 已加载后关闭；测试客户端必须保留不确定副作用，不能自动重试或宣称未发生。`rpc_error/fatal_error` 在空间预检时返回已测 ERROR 结构，fixture 自选错误码用于测试诊断，不能当作厂商实际权限枚举。

## 验证

[8 项独立 socket 测试](../tests/test_controller_test_peer.py)通过：匿名和密码会话、真实目录写读、7 字节 TLS 碎片、超过 2 MiB 多 TLS record 文件、写后丢响应、路径/清单隔离、Running→Stop、Load 错误状态、正常和致命 ERROR 精确定界，以及资源清理。测试从不连接 `192.168.0.8` 或任何外部地址。

[结构化检查记录](../artifacts/tcp-controller-fixture/verification.json)。完整 NativeGateway PCWE 以及同一个生产客户端的端到端结果由主下载链路报告另列；这些 fixture 测试不能替代真实 PLC 的证书、认证、文件系统、配置接受或运行验证。
