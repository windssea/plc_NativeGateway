# PLC 配置加载及下载顺序的静态证据

2026-10-25，读取本机 Engineer 2026.0 的托管程序集和已保存的 REA 证据。此研究未执行在线服务、建立网络连接、访问 PLC 或修改任何工程/部署物。结论是原厂代码的静态调用契约，不能视为设备实测。

## 完整加载与启动分别处理

`Ade.Internal.Online.PlcNext.DeviceControlServiceAdapter.LoadConfigurationCore`，token `0x06000043`，严格按以下顺序调用：

1. `OnInvalidating()`。
2. `IPlcManagerService.Reset(true)`；参数名为 `async`。
3. 轮询 `GetPlcState()` 转换后的 `DeviceState == On (0)`。
4. `IPlcManagerService.Load(true)`。
5. 轮询转换后的 `DeviceState > 0`。
6. `OnPoll()`。

该方法没有 `Start`。`ColdStartCore`（`0x0600003c`）单独调用 `Start(PlcStartKind.Cold=1, true)`，轮询 Running 或 Halt，然后通知 `OnStarted`。因此离线模拟应默认在 Load 后结束，不能把文件传输/配置加载成功报告成程序已运行。

原厂完成加载条件为转换后的状态大于 0，范围比仅 Stop 更宽；但错误处理在每次谓词判断之前进行。不能跳过错误检查，仅凭数字大小宣布成功。

## 原始状态、错误和轮询

`Arp.Plc.Domain.Services.PlcState` 是 UInt32。低 6 位（`StateMask=63`）为 None=0、Ready=1、Stop=2、Running=3、Halt=4。原厂转换到 Ade 的状态为 Ready→On=0、Stop→Stop=7、Running→Running=3、Halt→Halt=5；未知基本值默认 NotConnected=9。SystemError/FatalError 分别覆盖为 11/10。

| 标志 | 值 |
| --- | --- |
| Loading | 0x1000 |
| Starting | 0x2000 |
| Stopping | 0x4000 |
| Resetting | 0x8000 |
| Changing | 0x10000 |
| Hot | 0x20000 |

`GetError`（`0x06000049`）按优先级检查 SystemError 0x800、FatalError 0x200、DcgRealTimeViolation 0x80000000、DcgNotPossible 0x40000000、Suspended 0x100、Error 0x80、Blocked/SystemWatchdog 0x400。对应内部 DeviceError=6/5/4/3/2/1/1。

`WaitForDesiredState`（`0x06000047`）读取状态、检查允许错误、按实际错误抛异常、检查 timeout、等待 100 ms，再判断期望谓词并循环。默认 timeout 为 300 秒（静态构造器 `0x06000051`）。完整 Load 的两段等待仅显式允许 Suspended=2；其余非零错误会失败。超时及非法状态使用 `AdeServerCommunicationException`，代码 536870921；实时错误使用代码 769。离线测试可使用虚拟时钟，不必实际等待 300 秒。

服务声明取自 `Arp.System.Rsc.Services.dll`：IPlcManagerService 方法 ID Load=1、Start=2、Stop=3、Reset=4、GetPlcState=5。IPlcManagerService2 的 Change=6、Restart=7。所有控制方法返回 void，bool 参数 `async`。这些是 RSC 元数据方法 ID，不是 HTTP 路径或已验证网络帧。

## 上传和配置加载的外层顺序

`EclrDownloadHelper.Download`（`0x06000064`）先调用 DownloadCore 完成文件传输；只有文件阶段成功，才执行 LoadConfiguration，或者在另一个 change 模式执行 ChangeConfiguration。完整路径的加载适配器随后才进行上述 Reset→Load。

`ExecuteDownload`（`0x06000053`）另有 `ResetBeforeDownload` 条件分支：根据断点/强制变量和原 GUI 交互策略准备，在运行时调用 StopExecution，调用 retain BeforeDownload、Reset、文件清理后再 Download。未启用此选项时，不是每次下载都先 Stop；Halt 或断点等另有处理。不能把这个条件分支概括成所有下载的无条件顺序。

`DownloadToFileSystem`（`0x0600006c`）通过有权限检查的 GetFileSystemAsync 取得虚拟文件系统，PopulateImmediately=true；在虚拟目录里写当前文件、删除不属于目标文件集合的旧文件、删除空目录，最后 `SaveAsync(progress).Wait()`。这不能证明实际设备写入原子性，也不能假设传输中断会自动恢复旧工程。

根目录由 `IDownloadItemTargetSelector.GetFileSystemRootForCategory` 动态决定；本研究没有把某个 Linux 绝对路径认定为全部目标的固定根。只支持内存模拟时可使用显式虚拟根，不能悄悄将模拟根转换成真实控制器目录。

## 在线变更单独保留

`ChangeConfigurationCore`（`0x06000045`）要求 IPlcManagerService2，否则以 536870921 报 Online change not possible。支持时执行 OnInvalidating→Change(true)→轮询 Changing=false→OnStarted→OnPoll。其状态条件和完整 Reset→Load 不同；离线最小实现可以明确拒绝 Change，不把普通完整下载伪装成在线变更。

## 离线实现建议及尚未验证项

内存模拟初始状态设为 Stop，认证/授权、完整文件传输和读回检查成功后，模拟 Reset(true)→Ready→Load(true)→Stop，默认不执行 Start。将“读回全部哈希后才允许加载”标记为本实现的额外保护设计；目前静态观察的原下载链路不等于证明其每次都会逐文件读回。

故障验证应覆盖 reset/load 超时、Suspended、Fatal/SystemError、传输失败后不得 Reset/Load，以及 Load 失败不得 Start。模拟成功只证明状态机和失败路径实现，不证明真实 RSC 编码、设备鉴权、PLC 接受、目标内存或物理 I/O 行为。

## 身份与完整证据

- [本轮发现汇总](../artifacts/plc-download-research/load/findings.json)
- [完整适配器 IL](../artifacts/plc-download-research/load/device-control-il.json)
- [下载顺序 IL](../artifacts/plc-download-research/load/download-order-il.json)
- [枚举常量、服务/方法属性及参数名](../artifacts/plc-download-research/load/state-and-service-metadata.json)
- `Ade.Online.PlcNextImpl.dll` SHA-256 `7bbd75c0853220ccd262b9e9fdbec2b2d046e9a34e11bc1a405e94b22091d7ed`，MVID `f21f585b-05d7-44ad-81a3-4fbc40079661`；复用 REA members evidence `ev_927a702fc75e2a499c6519b5a8cbe857342f4e405c8fba85de507f6a10615352`。
- `Arp.System.Rsc.Services.dll` SHA-256 `214e68d812d65a374b6085232f88cfd574a9a80f28e1e91b07eb01abb9af98cb`；新 REA artifact evidence `ev_0479c64423afd09d67262110893bfd5681013a7e8d523e225992bd29a2634743`，members evidence `ev_1ace8f1e5a9c969e8fd6221c7dce0c1a73e08d4729c33b866a376ba54bc6acd6`，完整 JSON 保留在同一目录。
- `Ade.Plc.EclrImpl.dll` 下载 IL 复用 REA evidence `ev_5ebb602aa8547162eb32d3bd487b3d68595f9443411f231c267bd3ee6c229e88`；SHA/MVID 保留在下载顺序 JSON。

上述静态证据读取使用 Mono.Cecil 将程序集作为数据解析，没有在该阶段执行被检方法。未打开 native 会话，无需关闭目标。查询范围为这些方法、声明和条件分支；认证及文件协议的完整网络编码需结合另外的研究，不能从接口名推断成功。下方后续的值体 oracle 明确另行执行纯内存 formatter。

## 离线实现的独立审查

新增 `tests/test_download_simulation.py`，15 项通过（0.712 秒）。主模块保持由父线程修改，测试独立维护。覆盖正例操作顺序、FAULTS 全部失败场景、失败不得加载、300 秒虚拟超时、零值 UInt32 token、会话和密码/token 清理、未认证/错误 token、路径边界、超过 8 MiB 后整文件批次刷新、逐文件写入结果/读回、错误优先级及 Load 时 Suspended 容忍。执行模拟时 socket 和 create_connection 被测试替换为直接抛错；本实现路径没有调用它们。该检查不证明操作系统级全流量监控或原生库完全断网。

另将当前 61 POU 归档和 48 文件包复制到测试临时目录，核对计划返回的 77 变量、109 FB 实例、10 HMI 映射，并拒绝陈旧源、路径/身份替换、最终类型或构建收据篡改、镜像篡改。即使将篡改镜像重新写入自洽的 PCWE 清单和 inventory，也因不匹配源绑定冷构建 image SHA-256 而拒绝。上述负例只修改临时副本，未修改真实 managed 包或用户原始项目。

审查发现的未知状态映射、会话 token 清除和包内 IMG 到冷构建的绑定缺口，已由父线程补齐，测试复核通过。模拟通过依然只证明本地服务契约编排，不证明真实控制器下载链路已能连接使用。

## 原厂值体 oracle 与有界编解码

后续新增 `src/plcnext_mcp/rsc_plc_codec.py` 和 `tests/test_rsc_plc_codec.py`，8 项测试通过。接口声明来自原厂 `IPlcManagerService`，以声明的参数/返回类型构造 TagInfo[] 和 CallMessage，再执行原厂 `RemotingFormatter.SerializeParameters`（`0x060000a6`）、`SerializeValue`（`0x060000a7`）、`DeserializeReturnValues`（`0x060000ad`）。所有数据在 MemoryStream 内处理，没有构造 RemotingProxy、RemotingClient、在线服务、socket 或通信流。

原厂 39 个向量覆盖 RemotingVersion 3/4/5 且 tagging=false。Python 实现只开放本轮外围协议选定的 Version4，以免把标量字节一致推广成其他版本的完整调用兼容性。

| 方法 | 参数值体 | 返回值体 |
| --- | --- | --- |
| Reset / Load | bool true=`01`、false=`00`，参数名 async | void 且没有 out 参数，空字节；原厂返回反序列化器接受并不消费字节 |
| GetPlcState | 无参数，空字节 | 4 字节小端 UInt32 枚举；`0x80000002`=`02000080`，`0xffffffff`=`ffffffff` |

Python 解码拒绝未知方法、其他版本、非 bytes、截断、尾随字节、非规范 bool 及 UInt32 越界。Start、Stop、Change、Restart 的方法 ID 保留为元数据，但没有提供这些方法的调用值体实现。

原接口 provider 为 `Arp`，名称为 `.NET FullName` `Arp.Plc.Domain.Services.IPlcManagerService`；独立服务版本没有声明。Service2 是另一接口后缀，不能当作 RemotingVersion2。该常量与方法表已对照原厂接口属性；真实服务发现的句柄/名称映射还需要外围发现协议的独立验证，模块明确 `wire_service_discovery_verified=false`。不把这里的值体实现称为完整 RPC 请求或设备实测。

Oracle 宿主：[Invoke-PlcValuesOracle.ps1](../artifacts/plc-download-research/load/Invoke-PlcValuesOracle.ps1)；完整 39 向量及程序集哈希：[plc-value-oracle.json](../artifacts/plc-download-research/load/plc-value-oracle.json)。这是有意执行的纯序列化入口，与静态 IL 观察分别记录。

## 二进制 TLS loopback 的独立复核

父线程随后将这些值体与原厂向量验证过的 RSC 外围头、认证/文件体拼接，在持久 MemoryBIO/SSLObject TLS 连接的两端传递真实字节。四个服务及 provider 的句柄由内存服务注册表动态分配，再经 TLS 中的发现请求取回；这是明确的模拟注册表，不是扫描目标设备。

独立新增 `tests/test_binary_download.py`，12 项通过（0.360 秒）：测试 CA/hostname 的实际 TLS1.2 握手、Connect、四服务动态发现、零 token、文件/FSInfo/读回/Reset/Load/Close、所有 FAULTS、超过 2 MiB 数据在多 TLS record 间传输、请求/响应头与 token 篡改、发现句柄错误、路径越界及 Close 的终态清理。全过程测试替换 socket/create_connection 为直接抛错，未使用真实网络。

审查指出响应 token 原先被忽略，父线程已按本有界服务只发无 token confirmation 的规则拒绝带 token 响应，并清除 Close 后遗留的句柄及 TLS 对象引用；负例验证通过。另检查 trace 不含临时密码、用户名或测试文件内容。

这组测试验证二进制编排与失败处理；各值体原厂 oracle 的证据仍单独保留。两端本地自洽不能证明真实 PLC 的 TLS、认证、服务注册、设备权限、签名策略或执行兼容性。完整复核范围见 [binary-loopback-review.json](../artifacts/plc-download-research/load/binary-loopback-review.json)。
