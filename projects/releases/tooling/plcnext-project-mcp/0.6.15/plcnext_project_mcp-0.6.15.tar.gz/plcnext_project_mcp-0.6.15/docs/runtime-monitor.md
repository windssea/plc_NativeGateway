# M03/M04：有界在线只读监视

2026-10-26。实现不使用 ACI、CodeMeter、Engineer 进程或 computer use。

## 实现与证据

`runtime_monitor.py` 从精确受管源修订的类型、POU 声明、全局变量和 ESM 程序实例建立符号模型。只允许显式标量路径及已声明的数组元素；不读取任意地址，不读密码/秘密字段，不展开大缓冲，不写变量或 Force。

厂商声明为 `Arp.Plc.Gds.Services.IDataAccessService.Read(string[])`，RSC 方法 ID 2，返回 `ReadItem[]`；每项为 byte 枚举 Error 和携带实际类型标签的 Value。`IPlcInfoService.GetInfo(PlcInfoId.ProjectName)` 为方法 ID 1、参数 int32 值 1，只给出有限的实际项目名。

REA 静态证据：`ev_06c48ccafd27ce8a09b2c62c2c256dc4d16c306a2199eb9a403ac2d1612eec97`，厂商 `Arp.System.Rsc.Services.dll` SHA-256 `214e68d812d65a374b6085232f88cfd574a9a80f28e1e91b07eb01abb9af98cb`，MVID `0efae051-468d-4aac-97a3-1df3e929ee07`。该静态工具的完整元数据覆盖为 partial（部分泛型签名不支持）；上述具体读取方法、DTO 与附加 Cecil 属性读取已单独核对。

[32 个原厂纯 MemoryStream 字节向量](../artifacts/runtime-monitor-research/oracle-01/report.json)覆盖所有受支持标量、null、ReadItem[] 及 ProjectName；没有 provider、socket 或设备调用。生成工具为 [Invoke-RuntimeReadOracle.ps1](../tools/Invoke-RuntimeReadOracle.ps1)。

## 内部 API（由 MCP server 包装）

- `project_runtime_symbols(store, project_id, expected_project_sha256)`：返回源程序实例、root、类型和 POU 字段。不宣称远端符号存在。
- `prepare_runtime_read_plan(store, project_id, expected_project_sha256, address, expected_certificate_sha256, symbols=None, *, port=41100, chunk_size=64, timeout_seconds=5, maximum_bytes=1048576, minimum_interval_seconds=5, point_count=250, include_samples=True, include_configuration=False)`：生成源/目标/pin/类型/限制绑定的不可变只读计划，不连接 PLC，不批准写入。返回 `plan_id`、`plan_sha256`、`plan_path`。
- `read_runtime_plan(store, project_id, plan_id, expected_plan_sha256)`：执行一次有限观测，返回报告路径及 `observation_id` / `observation_sha256`。
- `test_runtime_monitor(store, project_id, expected_project_sha256, *, fault='none', point_count=250)`：仅启动自身 `127.0.0.1` 随机端口 TLS 测试设备，返回实际状态、预期状态及 `test_passed`。

文件路径在 `<project>/runtime-read-plans/<id>/plan.json`、`runtime-observations/<id>/result.json`、`runtime-read-tests/<id>/result.json`。MCP 公开工具名以新会话实际 Schema 为准。

## 读取与一致性

每计划最多 2048 个显式字段；每块最多 64；响应累计最多 1 MiB；单次 I/O 1～30 秒；整次观测最多 30 秒。同一 OS 用户、同一 IP/端口跨 workspace 限制并发和观测频率，间隔至少 5 秒。响应项数必须精确匹配请求，超限/截断/未知类型/不合法 UTF-8 拒绝；不自动重试。

默认 NativeGateway 计划读取 gateway、boot、Active 配置、通信计数和 250 点的 Quality/Value/Timestamp，共 767 项；字段缺失时返回明确的 unsupported 或设备错误，不返回默认零。源文件为本次指定的 32 POU 恢复归档；不改该归档来增加观察字段。

在数据块前后读取 BootId、Active.Version、DeviceCount、PointCount，并读取状态前后值。发生变化标 `snapshot_invalidated`；没有程序快照序号时最多报告 `guarded_window_observation`，`atomic_snapshot=false`。没有足够 guard 时明确为 `unguarded_window_observation`。

每项返回符号、源声明类型、实际 wire type、值或精确错误、来源、host 接收 UTC 和本次观测内的单调时刻。报告还含每块读窗口，不能把 RPC 往返耗时解释成 PLC CPU 执行时间。有限读取已实现；对真实主任务的开销尚未测量，`monitoring_impact_on_plc_task_verified=false`。

配置摘要只哈希实际返回的白名单 Active 字段，明确列出覆盖字段数；不冒充完整采样配置相同。250 GOOD 检查同时给出请求/读取/GOOD 数、期望点数与索引覆盖；仍不能代替真实 DATA/STORED 或 mock 业务验收。

## 身份边界

源 SHA、磁盘清单、设备 ProjectName、boot 和实际内存加载模块身份分开。当前只读服务没有可核验的完整 loaded-image hash，因此 `loaded_identity.status=unknown`、`package_sha256=null`。即使项目名相同、全部变量类型匹配、250 点 GOOD，也不提高该字段为 verified。

显式恢复的连续租约与自身完整 Load 日志可以形成独立的因果证据；它应由恢复计划报告，不改写这里的设备 loaded-hash 未知事实。

## 验证范围

[test_runtime_monitor.py](../tests/test_runtime_monitor.py)的 10 项测试覆盖原厂字节、类型/路径/秘密字段拒绝、source/plan 旧哈希与重新签摘要的超限计划、最终 RPC 边界、250 点真实本机 TLS、坏点/缺字段/类型错、boot/config 变化、短返回、断连和频率限制。详细本机矩阵见 [verification.json](../artifacts/runtime-monitor-research/verification.json)。本机模拟不证明真实 PLC 符号可用、读取开销或业务运行通过。
