# 独立替代 ACI：0.4.0 实现进展

2026-10-26。目标是 **自有 MCP 覆盖 ACI 的有用行为，开发、构建、打包和设备操作无需 computer use，也不调用 ACI**。本轮按该目标修改了生产 MCP，而不只是增加调用官方 ACI 的适配样例。**完整替代尚未完成；真实下载、在线变量、库和硬件等仍有明确缺口。**

## 已交付的工具和实现

当前版本 **0.4.0 / 30 个工具**，本机现有启动环境已升级；原全局服务的 command/args/env 不变，新进程即可加载。独立安装的其他项目可使用 [0.4.0 wheel](../dist/plcnext_project_mcp-0.4.0-py3-none-any.whl)，接入方式见 [跨项目使用](use-in-other-projects.md)。

| 新增 / 扩展 | 实际行为 |
| --- | --- |
| `aci_replacement_status` | 按域汇总 56 接口 / 201 方法的真实替代状态、依赖及优先级 |
| `aci_replacement_methods` | 分页查询完整方法、重载、token、工具对应、证据及验收条件 |
| `controller_read_state` | 独立 TLS/RSC、明确证书 SHA-256 pin、动态服务句柄，仅连接/服务查找/GetPlcState |
| `project_inspect_tasks` | 独立读取 ESM v2 任务/程序实例、ID、周期/看门狗/优先级 |
| `project_update_cyclic_task` | 新 revision 修改现有单周期任务参数，逐字节保留其他 ESM 内容与实例映射 |
| `project_simulate_download` 扩展 | `protocol_profile="v4_tagged"` 或旧 `"v4_untagged"`，在持久内存 TLS 中传输实际 typed 编码、文件和配置调用 |

没有把 193 个 RPC 的发现数量当作功能完成数量。方法账本当前为 11 项限定范围已验证、49 部分、95 缺失、23 研究、4 官方占位、19 特有契约；这不表示完成率。[逐域范围与剩余验收](aci-replacement-coverage.md)是完整替代的工作清单。

## 真实 MCP 全链验证

[完整结果](../artifacts/independent-aci-mcp/88aca674c55b444cad806d12a69583d8/result.json)，通过 Python MCP SDK、真实 stdio、新进程和仓库外工作目录执行：

1. 导入冻结的 NativeGateway 61 POU 副本，原输入 SHA-256 `e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0`。
2. 周期 20→25 ms、看门狗 500→750 ms、优先级 0→2。只有 ESM 数字属性变化，任务 ID、MainInstance 和程序分配保持不变；旧哈希更新被拒绝。
3. 对新源执行独立冷编译：61 POU、无项目 AST 种子，生成新 CIL 和原生镜像。
4. 生成完整离线 PCWE：48 文件，核验 77 全局变量、109 工程内 FB 实例、10 HMI 映射。工程/源/构建/最终类型及包清单绑定有效。
5. tagged 模拟中完成 20 次 TLS 往返，含 4 次服务发现和 15 次方法调用；48 文件共 9,370,814 字节回读相同，模拟 Reset/Load 完成，未 Start。
6. 对相同包注入回读损坏，返回 `readback_failed`，没有加载配置。

这是离线测试变更，未应用到运行设备。源副本未覆盖，未启动 Engineer、调用 ACI 或使用 computer use。新的测试副本 ID `ce032291ef3c4ea3b3271dbd07d35c30`，包 ID `622256dca31d44c4b3de0a3b76e335a5`；它不是用户选定的真机部署版本。

任务代码/单位/历史校验见 [任务配置报告](independent-task-configuration.md)。库 FB 不包含在 109 项工程内 FB 的逐字段布局检查中，完整文件集也不代表控制器已接受或签名/运行已验证。

## 真实设备只读验证

[MCP 实测报告](../artifacts/controller-readonly-mcp/4d159ee2b094406f95f0157274f0eb8e/result.json)：连接已授权的 `192.168.0.8:41100`，TLS 1.2，RSC v4 tagged/no-datagram，动态服务/provider 句柄，状态 **Running**。

仅发送 `Connect`、`GetServiceHandles(IPlcManagerService)`、`GetPlcState(5)`。没有账号密码、文件服务、Reset/Load/Start/Stop 或下载。此前观测的公开证书 SHA-256 被作为明确 pin；不做首次连接自动信任，也不宣称 PKI 链和主机名验证通过。pin 不匹配时不发送 RSC 应用请求。

工具要求地址是 literal IP、证书 pin 为 64 位十六进制；端口和总期限有边界。不接受任意服务、方法、参数字节或凭据。报告记录实际发送清单，失败后不自动重试。[实现](../src/plcnext_mcp/controller_readonly.py)及 [8 项无网络边界测试](../tests/test_controller_readonly.py)。

## tagged 协议已补到哪里

新增 [tagged codec](rsc-tagged-implementation.md)和 [tagged 内存下载后端](tagged-download-simulation.md)。值标签、数组元素 schema、结构字段、SecureString、SecurityToken、文件流和调用终止符都实际编码；没有以改一个 header flag 冒充协议支持。

与本机原厂纯 MemoryStream oracle 对比的新增支持向量为 53 个，另复用既有只读 31 向量；不支持的 UTF16 profile 单独记录并拒绝。schema 流读取支持任意短片段、总量限制和下一帧保留，不搜索文件内容中的 FF。

这些仍不是完整设备写入通道。远端 ERROR 返回、匿名/鉴权写权限、真实文件清单与旧文件处理、配置接受、断线后的副作用收据和恢复还需要实现/验证。模拟器中的权限与旧文件 reconcile 保留为本地应用策略，没有伪装成已恢复的远端 RPC。Full、OnlyChanges、IncludeSources 也尚未各自完成真机验收。

## 质量与安装包

- 全量 [312 项回归](../artifacts/aci-replacement-full-tests.log)：311 通过、1 项因 Windows 符号链接权限跳过，44.615 秒。
- [独立 wheel 环境](../artifacts/aci-replacement-wheel/1fe776dffb514630a89ce82bfa8938a8/result.json)：从仓库外实际发现 30 工具，读取 201 方法账本，编辑任务/验证保留，并完成 tagged 内存 TLS 模拟；无源码树 import。
- wheel SHA-256：`946a62b878335b809f430b3a2f571808406c0b877ba713ad2f9898ffc574a393`，50 个条目，包含完整能力清单及新模块。

工程编辑、任务配置、编译、打包不经过 ACI；编译仍依赖本机厂商编译库、设备模板和工程引用包。可选 ACI 参考样例不计入上述独立成果。当前 `full_aci_replacement=false`、`controller_write_access=false`，下载候选的 `deployable=false` 保留。

后续优先把已验证的 tagged 格式、包绑定和设备只读通道连接为真实写入/加载客户端，先完成错误、权限、文件生命周期及中断语义，再对明确选定的版本和设备执行下载验收；同时按 201 方法账本扩展工程交换、库、变量、任务实例、硬件和在线操作。无需恢复 computer use 路线。
