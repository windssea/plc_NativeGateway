# 本机 ACI 最小验证：已通过

更新：2026-10-23 15:37（北京时间）。在 Engineer **2026.0.4 / 9.0.373.0** 上，已完成真实 ACI 离线调用闭环：打开 NativeGateway 副本 → 全量重编译 → IEC 61131-10 导出 → 修改一个现有 FB → ACI 导入 → 全量重编译 → 保存、关闭、重开 → 再次全量重编译。

## 最终结果

| 项目 | 实测结果 |
|---|---|
| ACI 试用 | 使用厂商 CodeMeter `cmu --import --file` 成功导入安装包随附的 ACI 试用许可；CodeMeter 显示使用期 14 天，激活时间 2026-10-23 07:21:18 UTC |
| 接口启用 | 用户在管理员 Engineer 中启用后，厂商 ACI 客户端初始化可用性检查通过 |
| 后端 | 本轮独立启动 `/NOUI /NOSPLASHSCREEN`，PID 53060；完成后通过 ACI 关闭工程并 Shutdown，进程已退出 |
| 测试对象 | `NativeGateway.aci-test.pcwex` 中的 `NG_ReadAck`，由 `Main.AckReader` 实例调用 |
| 修改内容 | 仅在现有 ST 主体前增加一条说明注释；接口、变量名和类型不变 |
| 编译 | 原基线、修改后、保存并重开后三次 Rebuild 均为 `Succeeded`，返回消息集合均为空 |
| 程序结构 | 31 个 POU 保留，610 个 POU 变量的作用域、名称、类型、初值、其他 pragma 保留 |
| 实例与连接 | `Main.AckReader` 及 `GatewayId:=Bootstrap.GatewayId, Doc:=Doc` 参数连接保留 |
| 映射 | ESM 任务/程序实例及 DataList 文件逐字节相同；全局变量、设备、类型、HMI 相关保护文件检查通过 |
| 比较 | 98 项保留检查全部通过；目标 FB 代码确实变化，并断言移除新增注释后与原始代码完全相同 |
| PLC 操作 | 未调用连接、下载、PLC 启停、在线变量读写；此适配器没有这些操作入口 |

## 重要发现与适用边界

1. **本机 ACI 的 `IProject.ImportIec61131_10` 实际能更新同名 FB。** 本次没有先删除 FB，也没有重建 Main 实例。GUI 导入帮助页的“同名类型不导入”描述不能直接套用到本次 ACI 方法上。
2. 导入文件是从真实 ACI 导出中提取的**单个 FunctionBlock**，保留厂商附加元数据，并清空其他类型和实例配置；没有把整个工程交换文件回灌。
3. **POU 对象 ID 保持不变，目标 FB 的代码/变量工作表 ID 被重新生成。** 不能据此保证依赖工作表 ID 的断点或编辑器状态保留。
4. Engineer 给其他变量工作表补写了内部 `{Id('...')}`，并格式化数组初值。原始文本哈希因此改变。快照 v2 在保留原始文件差异的同时，按 IEC token 比较类型和初值，将生成 ID 单独检查；不会把 ID 当成数据类型。针对连线、变量类型和初值改变的负例均能检出。
5. 该样例没有现成物理 I/O 连接，不能证明真实物理 I/O 工程的保真；本轮也未测试添加变量、改变 FB 接口、功能行为、在线变更、HMI 编辑或安全程序。

## 证据与复用

- [最终结构化结果](../artifacts/aci-poc/result.json)
- [原基线编译](../artifacts/aci-poc/baseline-compile.json)、[修改后编译](../artifacts/aci-poc/modified-compile.json)、[重开后编译](../artifacts/aci-poc/reopened-compile.json)
- [98 项比较](../artifacts/aci-poc/roundtrip-comparison-v2.json)、[比较器正负例](../artifacts/aci-poc/semantic-comparator-tests.json)
- [原始 ACI 导出](../artifacts/aci-poc/baseline-export.xml)、[单 FB 修改导入文件](../artifacts/aci-poc/NG_ReadAck.modified.iec.xml)、[修改后重新导出](../artifacts/aci-poc/modified-export.xml)
- [修改后的工程副本](../artifacts/aci-poc/NativeGateway.aci-test.pcwex)、[最初冻结副本](../artifacts/aci-poc/NativeGateway.frozen.pcwex)
- 调用适配层：`tools/AciOfflineSession.cs` 与 `tools/Invoke-AciOffline.ps1`。只有离线动作，绑定指定后端 PID，输入输出限制在 `artifacts/aci-poc`。
- 导入文件准备：`tools/prepare_fb_roundtrip.py`。结构快照：`tools/project_snapshot.py`。结果核验：`tools/summarize_aci_roundtrip.py`。

冻结副本 SHA-256：`b78ba0efd0f8f79558143d58f3eb141512876690b2eda2a641e96ba3a3cbaddf`。

修改后副本 SHA-256：`623610acb763a49d5ac694b18a6739301586c98619a9fc575f9051779b998621`。

本轮只操作验证副本。原工程在复制后存在其他活动的更新，不把活动源工程当成此次比较基线。下方保留首次未激活时的调查记录；其中 not_run 状态已由本节结果取代。

---

# 早前记录：激活前的许可阻塞

日期：2026-10-23。目标：在 NativeGateway 工程副本上验证已有 FB 的导出、修改、导入、编译以及实例/变量映射保留。禁止 PLC 连接和下载。

## 当前结果：前置检查发现阻塞，尚未执行往返或编译

已通过安装目录中的厂商 ACI 客户端正常完成本地握手并读取可用性，返回：

```text
Available=False; States=NoLicenseAvailable, NotEnabledInOptions
```

这不是仅根据配置缓存推测，也不是网络连接失败。无界面 Engineer 已启动并监听 loopback 31172；厂商客户端实际读到了许可和选项两项阻塞状态。没有绕过许可、修改认证或自动激活试用。

本轮启动的是 `/NOUI /NOSPLASHSCREEN` 的空后端，没有调用 OpenProject，验证后已停止本轮启动的该进程。没有连接 PLC、下载程序、启动/停止 PLC 或写入在线变量。

## 已准备的验证材料

- 冻结工程副本：`artifacts/aci-poc/NativeGateway.aci-test.pcwex`。
- 复制时源与副本 SHA-256 都是 `b78ba0efd0f8f79558143d58f3eb141512876690b2eda2a641e96ba3a3cbaddf`。
- 该副本包含 31 个 POU。现有目标 FB 为 `NG_ReadAck`，对象 ID 为 `c07faeaa-a1b7-5fe2-b2e1-0bf2e46a7ee4`。
- Main 中已有 `AckReader : NG_ReadAck` 实例，并通过 `GatewayId:=Bootstrap.GatewayId, Doc:=Doc` 调用。
- 基线记录 ESM 任务/程序实例、POU 对象身份和变量声明、DataList 映射及相关设备/全局变量/HMI/类型内容。
- `NG_ReadAck.proposed.st` 仅预备增加一行说明注释。它来自冻结 ZIP 成员，不是 ACI 导出结果，也未导入或写入工程。

原工程文件在复制后发生了变化，后续读取出现不同哈希与 POU 数量；本轮没有对源工程执行写操作。验证必须沿用本次冻结副本和它的 `baseline-snapshot.json`，不能以活动源工程替代基线。

工程中没有已配置的物理 I/O 连接。后续通过本样例可验证已有程序实例、FB 调用参数连接和 DataList 关系；不能据此证明真实物理 I/O 映射保留。

## 工具和证据

- `tools/AciOfflineProbe.cs`：继承厂商 AttachToLocalServerClient，只提供可用性探测；不暴露 PLC 操作。
- `tools/Invoke-AciProbe.ps1`：加载本机程序集并使用正常认证读取 ACI 状态，输出结构化 JSON。状态不可用时脚本退出码为 2；调用环境可能将非零码统一报告为 1。
- `tools/project_snapshot.py`：Python 标准库的只读 ZIP 快照/比较器；只证明保存结构差异，不能替代真实编译。自检通过也不是 ACI 往返通过。
- `artifacts/aci-poc/aci-status.json`：真实 ACI 返回值。
- `artifacts/aci-poc/result.json`：各阶段 completed/not_run 状态，明确没有编译或往返成功结果。
- `artifacts/aci-poc/source-manifest.json`、`baseline-snapshot.json`：复制时身份和冻结基线。
- `artifacts/aci-poc/engineer-process.json`：本轮启动/停止的进程记录。
- `artifacts/aci-poc/tool-selfcheck/results.json`：真实临时 ZIP 的比较工具正负例。Main 的 AckReader 实例改名能检出且返回非零；目标 FB 仅加注释能检出代码变化且保留检查通过。临时 ZIP 已由临时目录自动清理，冻结副本哈希未变化。这些是比较器测试，不是 ACI 测试。

探针在本机 PowerShell 7.6 / .NET 10 宿主中加载厂商 .NET 8 客户端；编译时仅抑制引用统一提示 CS1701，未修改厂商程序集。实际请求返回上述服务器状态。正式适配器仍建议按厂商 .NET 8 运行环境构建。

## 解除阻塞后继续

1. 在厂商授权工具中安装/激活有效 ACI 许可。若采用试用，需由用户决定是否开始试用期。
2. 以管理员身份启动 Engineer，关闭工程，在 Extras → Options → Administration → Application Control Interface 中启用 ACI，并按界面要求重启。
3. 重跑可用性探针，必须得到 Available=True 才进入工程操作。
4. 打开冻结副本，先编译原基线并记录全部消息；通过 ACI 导出 IEC 61131-10，检查实际导出结构与目标 FB 身份。
5. 仅修改目标 FB 代码注释，保留名称、接口和对象标识，使用真实 ACI 导入并保存。导入参数与替换行为以实际 SDK 和导出内容为准，不提前杜撰。
6. 再次编译并记录消息，生成 after 快照，核对目标代码确实变化、实例/调用参数/变量/任务/DataList 映射全部保留。任何变化都要报告具体路径。

本轮没有完成的事项仍是：ACI 导出、导入、基线编译、修改后编译，以及导入后的映射比较。
