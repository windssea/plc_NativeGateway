# NativeGateway 无界面编译验证

> 本页保留单 FB 缓存阶段的实验。后续已实现全部 POU/变量接口和无工程 AST 种子的 IEC 冷构建，见 [当前能力与验证](nativegateway-cold-build.md)。

2026-10-23。本机 Engineer 2026.0.4 / 9.0.373.0。目标是在 NativeGateway 副本上，不使用 ACI、Engineer GUI 或 computer use，编译修改后的既有 FB；不连接、下载或运行 PLC 程序。

## 已验证的结果

**自有 MCP 的 `project_compile_cached` 已真实完成：修改后的 `NG_ReadAck` ST → 语法检查 → 强制语义分析 → 新 CIL → ARM Thumb-2 原生镜像。** 普通 Engineer 留下的 AST 和外部库被固定为种子；每次请求重新解析当前代码、重新生成所有应用 CIL，再调用原生后端。种子不包含旧的 Main/NG/RES 应用程序集或镜像。

这是一条**缓存辅助的既有 FB 主体编译路径**，不是从 PCWEX 冷启动重建所有工程对象的通用编译器。现阶段只接受固定 NativeGateway 原件派生的副本，且只允许 `NG_ReadAck/Code.st` 改变；变量接口、其他 POU、任务、I/O、HMI 等任一成员变化都会被拒绝。

| 检查 | 真实结果 | 证据 |
|---|---|---|
| 通过真实 MCP 检查全部 31 个 ST 工作表 | 0 语法错误 | [工作表检查](../artifacts/headless-project-syntax/result.json) |
| 原始 FB 经 MCP 编译 | 新 CIL、后端退出 0、新 `.img` | [端到端 MCP](../artifacts/cached-compile-mcp-e2e/result.json) 中 `baseline` |
| `count=0` 改成 `count=1` 后编译 | 0 语义错误；新 829664 字节 `.img` | 同报告 `modified_count_one` |
| 给新代码加入未定义变量 | `SEM1036`，停止于语义阶段，无镜像 | 同报告 `undefined_symbol_rejected` |
| 给新代码加入 `IF THEN END_IF;` | 语法错误，停止生成，无镜像 | 同报告 `invalid_syntax_rejected` |
| 使用旧工程哈希发起编译 | 工具错误，拒绝请求 | 同报告 `stale_hash_rejected` |
| 新代码是否实际进入 CIL | 目标方法 1415 条 IL 中，比较常量由 `ldc.i4.0` 变为 `ldc.i4.1` | [IL 对照](../artifacts/headless-research/cil-frontend/readack-il-comparison.json) |

上述错误结果来自本次输入重新计算。AST 内 86 条历史消息单独计数，不会被当作本次编译结果。

## 调用方式

现有 MCP 增加两个工具：

- `project_check_st(project_id, pou_name)`：检查 ST 工作表语法，支持本样例全部 31 个 POU；始终返回 `compiled: false`。
- `project_compile_cached(project_id, expected_project_sha256)`：对上述限定样例重新生成代码和镜像。成功时 `compiled: true`，同时明确返回 `cache_assisted: true`、`whole_project_rebuilt_from_pcwex: false`、`deployable: false`。

典型流程：`project_import_copy → project_read_pou → project_patch_st → project_compile_cached`。编译使用当前工程哈希，结果固定到这一次输入版本；后续编辑不会改变已经创建的编译任务输入。

本机种子已创建于 `artifacts/nativegateway-compile-seed`。服务配置可用 `PLCNEXT_NATIVEGATEWAY_SEED` 指定它，`PLCNEXT_ENGINEER_DIRECTORY` 指定已安装 Engineer；服务自身不创建或延长授权。`server_capabilities.cache_assisted_compile` 返回实际可用性；旧的 `headless_compile: false` 表示通用的完整 PCWEX 无界面构建仍未实现。

重新制作种子使用 [prepare_nativegateway_seed.py](../tools/prepare_nativegateway_seed.py)，它校验原始工程、GUI 编译副本和 AST 的固定哈希，拒绝覆盖既有种子。没有合适种子的另一工程不能直接沿用本样例。

## 独立托管的调用链

1. 原生 ZIP/XML 模块验证 PCWEX 中除目标 ST 外的所有成员载荷与冻结原件完全相同，复制当前代码和种子到新的任务目录。
2. 独立 PowerShell 子进程加载已安装的编译库。`StructuredTextParser.Parse` 生成新工作表 AST，替换对应方法体。
3. `SemanticAnalyzer.Analyze` 使用 `ForceCheck=True`，读取分析返回的 `CompilerProject`，而非继续使用旧的语义结果；错误会阻止后续生成。
4. 真实 `CilGeneratorFactory` 配合 Cecil 类型管理器、表达式处理器、字面量和变量引用解析器生成新应用 CIL。外部引用中明确排除旧 Main/NG/RES 应用模块。
5. 在全新生成目录运行安装包后端：

```text
CilCompilerLoader.exe -optfile cilc.opt -cilc <安装目录>\CIL-Compiler\cilc-armthumb2-arm-v3.0.0.dll
```

工作目录只含本次新应用 CIL 与经哈希校验的运行库。此前不存在 `.img`；退出码为 0 且新镜像存在才报告成功。未执行生成的 `.exe` 或 `.img`。

AXC F 2152 v2026 的设备链 `AXCF2152 → PLCNEXT_ARMTHUMB2_ARM → PLCNEXT_BASE` 明确配置 `NamespacesSupport=true`。托管生成器必须设置 `Ade.Compiler.Eclr.NamespacesSupported=true`；省略它会产生不同的 `ProConOS_eCLR` 类型前缀。修正后，GUI 与无界面基线的全部 33 个应用模块共 202 个方法，在签名、逐条 IL、局部变量及异常区域上均一致；已检查的 CLR header、类型/字段布局、初始数据及非调试自定义属性也一致。具体比较见 [GUI→无界面基线](../artifacts/headless-research/cil-frontend/gui-to-headless-baseline-il-comparison.json) 与 [CIL 实验报告](../artifacts/headless-research/cil-frontend/README.md)。这没有覆盖所有元数据、PDB 或完整原生镜像，不能代替目标运行和部署验证。

## 授权和边界

运行链不调用 ACI，也不启动 Engineer、访问其窗口、连接 PLC 或改动 CodeMeter/许可。它仍需要本机已安装的厂商编译库；它不是重新实现 IEC 编译器，也不是官方支持的外部 API。当前 ACI 试用仍处于有效期；本轮没有通过修改时钟或许可模拟试用到期。证据支持“调用路径不依赖 ACI”，不宣称验证了所有未来版本的授权行为。

未初始化目标限制服务、IDE 项目管理器或在线服务；历史 IDE 警告不会重放。网络、I/O、HMI、完整打包、工程签名及下载一致性未重新生成或验证。因此镜像只作为离线实验产物保留，不能据此认定可下载或可直接替换运行程序。

本轮没有完全解决的部分：无种子的任意工程冷构建、变量/类型/FB 接口变更、新增 POU、硬件/HMI 配置重建、部署包签名和目标运行验证。

## 可复现检查与来源

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe tools\headless_parser_e2e.py
.\.venv\Scripts\python.exe tools\headless_project_syntax.py
.\.venv\Scripts\python.exe tools\cached_compile_e2e.py
```

输入身份：冻结原件 SHA-256 `b78ba0efd0f8f79558143d58f3eb141512876690b2eda2a641e96ba3a3cbaddf`；GUI 副本 `b58151316681f1c53d2b9a29c35bff2ee6f8fcbe53918b3bd1406cd784dbb884`；种子 AST `4355612c1c7518299e1c378bb826836a2bb3cf937e24119c074dcd345a5bd008`。种子清单还记录外部库和 590 个本机安装文件的哈希。

前期有限负搜索与实际后续运行分开记录：

- [公开接口调查](headless-public-interfaces.md)：未发现完整 ST 工程官方免费 CLI；PLCnCLI 的 C++ 工具链不能直接替代现有 IEC 工程。
- [MSBuild 失败探针](../artifacts/headless-research/msbuild/README.md)：`MSB4066`，厂商 targets 配合自有 `Ade.Build` 契约。
- [语法、语义与新 AST](../artifacts/headless-research/managed/research-notes.md)：包含 REA/Cecil 静态证据、API 和正负例。
- [CIL 生成](../artifacts/headless-research/cil-frontend/README.md)、[原生后端](../artifacts/headless-research/cil-backend/README.md)：独立实验的输入、命令、退出码和输出身份。

REA 身份证据包括 `ev_d2d5d2f2ef86239d12ad8ed086a033c13ec16305ded5f2aec4432f56319ed7c1`（BuildImpl 成员）、`ev_1e7debabec144ad7695c9c3491797ac0556a98c72303bbc72d0f133b5a350e78`（CompilerImpl 身份）、`ev_124a0d7da22d87f463778d1ed92544c486b0a5c4aa71d445d6d07076028e0a55`（Domain.Platform.Build 身份）。大程序集的部分 REA 成员查询受到预算限制；具体调用关系由保留的 Cecil 静态记录补充，运行结论以上述子进程及 MCP 结果为准。
