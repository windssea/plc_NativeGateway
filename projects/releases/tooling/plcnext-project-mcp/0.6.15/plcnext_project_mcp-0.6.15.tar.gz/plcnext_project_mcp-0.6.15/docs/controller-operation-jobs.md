# 异步控制作业与可查询取消

2026-10-26。同步函数内部支持 cancel_event 不代表 MCP 客户端能取消设备操作；新增 `operation_jobs.py` 将固定 recovery/control/instrumented_fault 执行放入有限后台线程，并提供持久状态及取消请求。

## API

- `start_recovery_operation(store, project_id, plan_id, expected_plan_sha256)`。
- `start_control_operation(store, project_id, review_id, expected_review_sha256)`。
- `start_instrumented_fault_operation(store, project_id, review_id, expected_review_sha256)`，对应公开工具 `project_start_instrumented_fault_job`，仅运行 M07 精确审阅和审批 consumer。
- `controller_operation_status(store, project_id, operation_id, expected_review_sha256, include_result=False)`。
- `cancel_controller_operation(store, project_id, operation_id, expected_review_sha256, reason='operator_requested')`。

启动返回 operation_id 和操作文件路径。所有查询/取消同时绑定 project_id、operation_id、精确 review SHA，拒绝错目标、旧 ID 或哈希。公开输入没有任意 callable、命令、RPC、文件路径或签发审批参数。固定执行器仍调用原有人工审批 consumer；后台启动不授予写权限，不绕过一次性 claim。

作业路径为 `<project>/controller-operation-jobs/<operation_id>/operation.json`、`result.json`、`cancel-request.json`。元数据记录宿主 PID、创建身份、阶段、输入 hash 和目标；结果独立 hash 绑定。恢复执行在每个 RPC 边界记录阶段；控制作业至少记录进入 control、终态和原执行报告。

## 取消与宿主退出

另一个 MCP 进程也能按精确身份创建持久取消 marker。worker 的 FileCancelEvent 在下一协作边界观察到它。取消只停止后续动作/等待，**不撤销已经发出的 Stop、写入、Reset/Load 或 Start**；回复丢失和未到达终态仍按原执行器报告 unknown、保留隔离。

已完成作业取消返回 already_terminal，不发反向动作。错误/损坏的取消 marker 使下一边界 fail closed。客户端超时、关闭聊天或退出 MCP 宿主本身不是已完成取消的证明。

宿主身份以 PID 加创建时刻绑定；Windows 使用只读进程查询，不使用可能产生副作用的 os.kill(pid,0)。宿主退出、PID 复用或本地 worker 已不再可证实时，状态返回 worker_outcome_unknown；不会自动恢复线程、重新消费收据或重新发送设备动作。作业层不删除 claimed 或 endpoint lease，操作员需检查已有执行 journal 和隔离状态。

每个 MCP 宿主最多四个活动作业。线程是 daemon，宿主结束不会悄悄建立另一个常驻服务；重启后旧作业只可查询、取证和请求取消，不自动重跑。独立 Start 作业仍需要 loaded identity 证据，没有证据会拒绝；连续恢复中的 Start 使用其自身验证链。instrumented_fault 作业仍受 M07 的独立 TTL/身份/解除证明门禁；后台线程不提供宿主退出后的独立解除保证，旧恢复归档缺少该能力时拒绝场景，不因增加异步入口就获得写权限或解除保证。

[test_operation_jobs.py](../tests/test_operation_jobs.py)覆盖另一个真实 Python 进程发出取消、实际本机 TLS Stop 后取消不逆向/不重发、精确身份拒绝、损坏 marker、PID 身份变化、结果篡改和 worker 异常。测试没有真实 PLC 连接或真实审批签发。
