# PLC 文件传输：静态契约与离线字节验证

2026-10-25，仅分析本机安装的 PLCnext Engineer 2026.0 组件与 NativeGateway 副本。没有创建在线通道、连接 PLC、运行 Engineer/ACI、修改许可或写入部署物。

本轮已确定文件服务的方法、DTO、结果码、批次规则与当前设备 profile 的符号根，并实现一个经原厂序列化器逐字节验证的有限 `WriteFileData[]` 值编解码器。它只处理 RPC 参数中的值体；认证、服务发现、服务句柄、命令头和实际传输须由其他层处理。离线模拟不能证明真实 PLC 接受文件。

## 已观察的接口

`Arp.System.Rsc.Services.dll` 中的声明与 `Ade.Online.PlcNextImpl.dll` 实际适配层一致：

| 服务 | RscMethod | 契约 |
| --- | --- | --- |
| `IFileService.Write` | 2 | `(String path, Boolean overwrite, TraitItem[], Stream)` → FileSystemError |
| `IFileService.Read` | 3 | `(Traits, String, out Stream, out TraitItem[])` → FileSystemError |
| `IFileService2.WriteMany` | 8 | `WriteFileData[]` → 每文件 FileSystemError[] |
| `IFileService2.ReadMany` | 9 | `ReadFileInfo[]` → out ReadFileData[] |
| `IFileSystemInfoService.GetSupportedTraits` | 1 | 返回 Traits 标志 |
| `IFileSystemInfoService.GetFileSystemTraitsEntry` | 5 | `(Traits, path, out FileSystemTraitsEntry)` → FileSystemError |
| `IFileSystemInfoService.GetSpaceInfo` | 6 | `(path, out SpaceInfo)` → FileSystemError |

FileService2 的 7..10 是派生接口新方法编号；不能错当为新接口从 1 开始。RscServiceAttribute 的 provider 是 `Arp`，不包含连接后协商得到的服务句柄，因此仅知道这些编号还不能组装完整 RPC。

`WriteFileData` 按声明字段顺序为 `FilePath: String`、`Overwrite: Boolean`、`TraitItems: TraitItem[]`、`Data: Stream`；`ReadFileInfo` 为 `FilePath`、`FileTraits`；`ReadFileData` 为 `Result`、`TraitItems`、`Data`。路径参数带 `MaxStringSize(512)` 注解。字段与方法特征完整保存于 `artifacts/plc-download-research/files/rsc-file-contracts.json`。

这条已观察到的适配层使用整文件 Stream 值，没有公开的 Open/WriteChunk/Close 会话；不能把自定义分块 API 描述成这里的原厂接口。

## 批次、属性和错误

`FileAccessServiceAdapter.WriteRemoteFilesCore`，token `0x0600018a`：

1. 读取并缓存 `GetSupportedTraits`，取需要的 Permissions/LastWriteTime 交集。
2. 每个输入转成 `WriteFileData`，Overwrite 固定 true。
3. 如果存在 `IFileService2`，顺序累加整文件长度。加入文件后累计 **大于 8388608** 才结束本批；这不是 8 MiB 的严格上限，一个大文件会完整包含在批中。剩余文件构成末批。
4. 对每批调用 WriteMany，使用 `WithTimeoutHandling(false)` 及 `Execute(..., false)`。此处只记录实际布尔参数，不凭参数名推断完整重试政策。
5. 返回逐文件结果并最终释放所有创建的 Stream。没有 FileService2 时逐文件调用旧 Write。

`CreateWriteFileData`，token `0x0600018b`：若支持 LastWriteTime 且输入确有值，写 `Trait=2, Value=DateTime`；若支持 Permissions 且输入有 Attributes，权限从十进制 **420（0644）** 开始，如果未设置 VirtualFileAttributes.ReadOnly，再 OR 十进制 16，成为 **436（0664）**。这不是凭文件扩展名赋可执行位。

Traits：None=0、Permissions=1、LastWriteTime=2、Length=4、Crc32=8、TotalPermissions=16。FileSystemError：None=0、Unknown=1、InvalidPath=2、NotExist=3、AlreadyExists=4、AccessDenied=5、OutOfSpace=6。适配层将非零视为失败，不能把批量 RPC 正常返回等同于每个文件成功。

`CreateRemoteDirectoriesCore`（`0x0600017f`）在允许既有目录时先查询 Exists/ExistsMany，仅创建缺失项；Create/CreateMany 的结果依原索引回填。`GetRemoteFreeSpaceCore`（`0x0600017e`）使用 SpaceInfo.Free，错误时返回 0。自有实现可将查询错误和真正零空间区别报告，而不延续该歧义。

## 当前工程的目标路径

`Ade.PCWorxNextImpl.dll / DownloadItemTargetSelector`：

- `GetRootFolders`（`0x060002c4`）从设备 profile 读取 ConfigurationRootPath。
- `Unescape`（`0x060002c5`）把 `$$` 还原为 `$`。
- `GetDestinationFileName`（`0x060002c3`）对 PlcNext 类别剥除本地 `Configuration/Projects/PCWE/` 前缀，留下 PCWE 相对文件名。

当前 profile 继承链已经逐份归档文本核对：

```text
AXCF2152 / 2026.0.0
  → PLCNEXT_ARMTHUMB2_ARM / 2026.0.0
  → PLCNEXT_BASE / 2026.0.0
  → PlcNext / 3.2.0
```

PlcNext profile 中 `ConfigurationRootPath := '$$ARP_PROJECTS_DIR$$/PCWE/'`，因此有效符号根为 **`$ARP_PROJECTS_DIR$/PCWE/`**。

`FileAccessServiceAdapter.ResolveSymbolicPathCore`（`0x0600017d`）再调用 `GetFileSystemTraitsEntry`，取返回的 `Path`。没有证据支持在客户端固定拼成某个 Linux 绝对路径。模拟器应提供一个明确的虚拟根；真正的绝对路径仍需经远端查询，而且自有实现应检查结果码、根路径归属和相对路径安全。

证据：`download-target-selector-il.json`、`device-profile-roots-index.json`、`device-profile-2026-chain.json`。所有归档均只读，保存了 archive/member SHA-256。

## 回读

`ReadRemoteFilesCore`（`0x06000189`）的 FileService2 分支调用 ReadMany，逐项检查 ReadFileData.Result，复制 Data 到本地 byte[] 并释放输入 Stream。旧分支单文件 Read。`GetRemoteFileCrcCore`（`0x0600018e`）只有在设备支持 Crc32 trait 时才查询，查询失败/不可转换/未支持时返回 0。因此 CRC=0 不能独立证明传输失败或成功。

自有离线下载流程可以在每文件写结果为成功后回读完整字节，按本地受检查包的 SHA-256 比对；这是本实现选择的验证策略，不能声称原适配层必然做相同的 SHA-256 检查。

## 原厂值序列化实跑和新 codec

新增 `src/plcnext_mcp/rsc_file_codec.py`：

```python
encode_write_many(files: list[dict], version: int = 3) -> bytes
decode_write_many(payload: bytes, version: int = 3) -> list[dict]

# canonical item:
{"path": str, "overwrite": bool,
 "traits": [{"trait": 1, "value": 0o664}], "data": bytes}
```

只支持 **Remoting 3、4、5，useTagging=false，Permissions trait，seekable MemoryStream 的已知布局**。其他版本、trait 或分帧明确拒绝。服务注解 MaxStringSize(512) 的全部字符语义没有单独恢复，当前 codec 采取更保守限制：UTF-8 路径加 NUL 总共不超过 512 字节；最多 4096 文件、每文件 64 MiB、总值体 128 MiB。限制是自有实现的支持范围。

原厂 `Ade.CommonRemoting.Internal.RemotingFormatter.SerializeValue`（`0x060000a7`）及 DeserializeValue 仅在 MemoryStream 上运行，TagInfo 和 DTO 均使用原始类型。没有创建在线 provider、channel、TLS stream 或 socket。

确认的字段布局，所有多字节整数为 little endian：

```text
Int32 文件数
对每文件：
  UInt16 UTF-8字节数加1；UTF-8字节；NUL
  Byte overwrite (0/1)
  Int32 TraitItem数
  对 Permissions TraitItem：Int32 trait=1；Byte动态值类型=8；Int32权限
  Int32 Stream总长度
  若非空：Int32本段长度=总长度；全部原始字节
  Int32 -1 结束符
```

虽然 untagged，TraitItem.Value 是 System.Object，仍带动态 Int32 类型 tag 8。seekable stream 内部使用 65536 字节缓冲读取，但其 wire 值只写一次总段长度；不能在每次缓冲读取前添加自定义长度。非 seekable stream 使用不同形式，本 codec 未实现。

`oracle-vectors-01/report.json` 保存 **15 个**原厂序列化/反序列化实测：5 组输入跨版本 3/4/5，包括空数组、空文件、二进制+权限、含中文和 emoji 的双文件，以及跨 64 KiB 缓冲边界的 70 KiB 文件。每个原厂 typed roundtrip 完整消费值体，路径、overwrite、traits、data 均一致。Python codec 对每个 `.bin` 逐字节相同并解回相同 canonical item。另有 6 项测试覆盖所有截断位置、尾随字节、非法计数/UTF-8/bool、未知 trait、错误长度/结束符等。

原始探索 `oracle-01/report.json` 还记录：版本 1/2 的原厂 formatter 明确拒绝 Stream；tagging=true 的字节不同。没有把这两种情况纳入已支持范围。

## 扩展：ReadMany、错误数组和文件系统信息值体

后续补充了 30 个原厂服务值体向量，最终有效目录是 **`oracle-services-03/`**，使用真代理默认 marshalling。跨 Remoting 3/4/5 的全部向量逐字节匹配，原厂反序列化后重序列化也完全一致。结合之前 15 个 WriteMany 向量，共 45 个原厂值体向量，`test_rsc_file_codec.py` 共 9 项测试通过。

新增 API 不包含命令头：

| API（均有 decode 对应方法） | canonical 值 |
| --- | --- |
| `encode_read_many_request(files, version=3)` | `[{path, traits: int}]` |
| `encode_read_many_response(files, version=3)` | `[{result: 0..6, traits: [], data: bytes}]`；traits 也可为一个 Permissions 项 |
| `encode_file_errors(results, version=3)` | `list[int]`，WriteMany 返回的逐文件错误码 |
| `encode_supported_traits_response(traits, version=3)` | Traits 标志 Int32；此方法请求体为空 |
| `encode_traits_entry_request(path, traits=0, version=3)` | request 先 Traits Int32，后路径 UTF-8 字符串 |
| `encode_traits_entry_response(entry, result=0, version=3)` | entry=`{path,is_file,is_directory,traits}`；先 out entry，后返回错误码 |
| `encode_space_request(path, version=3)` | UTF-8 路径 |
| `encode_space_response(space, result=0, version=3)` | space=`{capacity,free,available}`；三个 UInt64，然后错误码 Int32 |

ReadMany 请求为 Int32 数量，然后每项 UTF-8 路径和 Traits Int32。响应仅有 out ReadFileData[]，返回类型为 void，因此是 Int32 数量，再逐项错误码 Int32、TraitItem[]、Stream；没有多余的返回值。错误数组为 Int32 数量和每项错误码 Int32。

`RemotingFormatter.DeserializeReturnValues`（`0x060000ad`）明确先按原参数顺序解码所有 out 参数，再解码非 void 返回值。以文件系统信息接口为例，响应不能把错误码提前放到 out 结构之前。

特别纠正了一个容易误复现的细节：直接构造 root `TagInfo(String, AdeMarshalType=0)` 会序列化 UTF-16LE，不能把它当真实 RPC 参数的默认值。原始代理 `Ade.CommonRemoting.Internal.RemotingProxy.Init`（`0x060001aa`）对每个 ParameterInfo/ReturnParameter 的 attributes 调用 `RemotingFormatter.GetMarshalType`（`0x060000a4`）；该函数无显式 AdeMarshalAs 覆盖时返回 **2（UTF-8）**。当前文件服务参数没有该覆盖，因此最终 FSInfo root 路径按 UTF-8 编码。此处由原厂 GetMarshalType(empty attributes) 动态取得枚举值后再运行 oracle。早期 `oracle-services-02/` 的 root-string-0 探索向量留作调查过程，不用于真实默认参数证明。

ReadMany 返回的 vendor Stream 可能不可 seek。Oracle 将它复制到新的 MemoryStream 后做第二次序列化，证明已消费数据后重编码一致，未擅自调用该响应 Stream 的 Position。测试同时覆盖空数组、UTF-8 路径、成功和 AccessDenied 结果、空数据、权限项目、UInt64 超 32 位空间值，以及每个字节位置的截断拒绝。

## 身份、证据和未确定项

- REA：`ev_1c141e205ca7933c3afbe93518fad17df7d3b84c44b1901710a21a1bb7e39688`；完整 `rea-online-inventory.json` 保留在本研究目录。
- Ade.Online.PlcNextImpl.dll SHA-256 `7bbd75c0853220ccd262b9e9fdbec2b2d046e9a34e11bc1a405e94b22091d7ed`，MVID `f21f585b-05d7-44ad-81a3-4fbc40079661`。
- Arp.System.Rsc.Services.dll SHA-256 `214e68d812d65a374b6085232f88cfd574a9a80f28e1e91b07eb01abb9af98cb`，MVID `0efae051-468d-4aac-97a3-1df3e929ee07`。
- 静态提取只加载 Mono.Cecil，把目标 assembly 当数据解析。只有上述纯 formatter oracle 执行原厂值处理代码；静态观察与实跑收据分别记录。

本文件研究没有独立恢复完整认证后 provider/service 发现和 handle 协商、完整 RPC 包与网络分帧及断线恢复政策；这些不能由成功的 DTO roundtrip 推导。ReadMany/文件系统信息现已恢复上述有限 schema 的请求/响应值体，但非 seekable stream 编码、时间/Crc32 等额外 TraitItem.Value 动态类型仍不支持。没有真实 PLC 连接、下载、权限评估或运行验证。完整 loopback RPC/认证进展由父层集成报告另记。
