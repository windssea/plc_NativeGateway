# 独立 Stop / Start 控制与集成契约

2026-10-26。对应 M02。实现不调用 ACI、Engineer GUI 或 computer use。新增模块：
[controller_control.py](../src/plcnext_mcp/controller_control.py)、
[rsc_start_control.py](../src/plcnext_mcp/rsc_start_control.py)、
[本机 TLS 控制设备](../src/plcnext_mcp/controller_control_test_peer.py)。

当前证据为 OFFLINE / LOOPBACK；没有真实 PLC Stop、Start 或物理输出行为验收。
工具注册和整体恢复计划由根集成层提供；本文中的 Python 函数不自动成为 MCP 工具。

## 底层证据

复用原服务元数据 [state-and-service-metadata.json](../artifacts/plc-download-research/load/state-and-service-metadata.json)：
`Arp.System.Rsc.Services.dll` SHA-256 `214e68d812d65a374b6085232f88cfd574a9a80f28e1e91b07eb01abb9af98cb`，
MVID `0efae051-468d-4aac-97a3-1df3e929ee07`。

- `IPlcManagerService.Start` token `0x060000bc`、method ID 2：`PlcStartKind, bool async -> void`。
- `PlcStartKind` 的底层类型为 Byte：Cold=1、Warm=2、Hot=3、RestoreWarm=4；None=0 不作为有效启动模式暴露。
- `Stop` token `0x060000bd`、method ID 3：`bool async -> void`。

这些 RSC 数值与 ACI 的 StartType 不同。新增 [原厂纯内存 oracle](../tools/Invoke-RscStartControlOracle.ps1)
调用真实 `RemotingFormatter4.SerializeMessage`，在合成 MemoryStream 中产生四种模式 × 两种 async 的
[8 个原厂完整帧](../artifacts/rsc-control-start/oracle-01/report.json)。例如 Cold/async=true 的值体为
`05 01 02 01 FF`。未创建 provider、在线服务、ACI 或网络连接。

codec 的逐字节匹配证明该构建序列化格式，不证明真实固件支持每一种启动模式。

## 精确审阅与独立审批

`prepare_control_review(store, project_id, expected_project_sha256, package_job_id,
address, expected_certificate_sha256, action, port=41100, start_kind=None,
timeout_seconds=30, expected_initial_state=None, plan_id=None)` 创建本地审阅：

- action 只能为 `stop` 或 `start`；Start 必须明确提供 `cold/warm/hot/restore_warm`。
- Stop 默认前态为精确 Running(3)、终态精确 Stop(2)；明确审阅初态 Stop(2) 时可只读确认已完成。
- Start 前态固定为精确 Stop(2)、终态精确 Running(3)。带 busy/error 标志的状态不是成功终态。
- timeout 为整数 1…300 秒；plan_id 为可选 32 位小写十六进制 ID。
- 绑定当前源码、构建、包 inventory/逐文件身份、IP/端口/pin、动作、前/终态和影响。
- `write_authorized=false`，准备/读取审阅不连接 PLC、不签发确认。

`load_control_review` 检查审阅摘要、固定策略及目标；`revalidate_control_review` 进一步验证
当前源/构建/包字节。源码变更后旧控制审阅也会失效。

`approval_contract` 与独立 `operator_approval` CLI 对接。控制收据使用独立 schema
`plcnext-controller-control-operator-approval/v1` 和目录 `controller-control-approvals`；
固定动作只有本次 `["stop"]` 或 `["start"]`，不扩大旧下载收据。检查人工来源 reference、
有效期 ≤3600 秒、精确绑定和撤销/拒绝标记；O_EXCL `.claimed.json` 在 socket 前创建并 fsync。
并发消费只允许一方取得能力；已领取记录保留，不提供自动重发。

操作者 CLI 是受信发行者约定，同用户任意文件写入者不因此获得密码学人类认证。
真实人工确认和收据目录权限由宿主维护；普通 MCP 不提供批准入口。

## 执行与完成判定

`execute_reviewed_control(..., verify_loaded_identity=None, held_lease=None, cancel_event=None)`
校验审阅、持有端点租约、消费独立控制收据，然后调用 `execute_control`。
控制专用客户端只允许 PLC manager GetPlcState 和 **一条** 对应 Stop 或 Start，
不接受任意 RPC、文件写入、Reset/Load、变量写入、反向动作或第二次发送。

Start 必须由根集成层内部 verifier 返回已加载身份。独立历史 manifest、ProjectName、
本地候选文件名或单个布尔参数不满足要求。目前接受的证据来源：

1. `device_loaded_module_hash`：设备提供的直接已加载身份；当前实际 PLC 服务是否可供仍需核实。
2. `same_plan_verified_load`：同一连续端点租约和计划内的完整回读/Reset/Load 因果证据。

第二种来源必须绑定精确 inventory、target 和 plan_id，并包含 load execution ID、
load receipt/journal SHA-256、`lease_held_continuously`、`journal_binding_verified`、
`readback_all_files_verified`、`load_state_verified`、`fresh_project_name_matches` 全部为 true，
以及 `fresh_plc_state_raw=2`。verifier 由根集成层读取实际日志/收据并做新鲜设备读取，
不能让 MCP 调用者提交这些布尔字段。它是因果证据，**不是设备直接返回的内存模块哈希**；
单用户 MCP 端点租约也不能排除其他主机或官方工具的并发变更。

实际动作只发送一次。RPC ACK 后继续有界状态轮询；精确终态才是完成。
取消或超时不发送反向 Start/Stop，不声明已撤销动作。回复丢失或终态未证实返回
`action_sent=true`、`outcome_unknown=true`、最后观测状态；应先只读核查，不自动重发。
`action_sent` 表示开始尝试写入该请求，不能保证所有字节送达设备。

结果保留 `action_sent`、`ack_received`、`terminal_state_verified`、`final_state_raw`、
`last_state_raw`、`outcome_unknown`、单调耗时、请求次数、报告和 journal 路径。
Running 从不等同于采集/业务验证通过。

## 整体恢复计划集成

`ControlEndpointLease(review, job_directory)` 使用原下载客户端同一固定用户目录端点锁，
防止其他 MCP workspace/进程并发操作同一 IP/port。具有共同非空 plan_id 的控制审阅可共享
同一个 lease 对象；不确定结果调用 `quarantine()` 保留磁盘锁，正常结束调用 `release()`。

整体计划消费其自己的人工确认后，可由受信内部代码创建
`ControlScope(child_review, 'operator_confirmed', authority=_CONTROL_AUTHORITY)`，
再构造 `ControllerControlClient` 调 `execute_control`。这样不重复消费独立 control 收据。
此私有工厂不注册为 MCP 工具，不把 authority 或 scope 作为用户 JSON 参数。

`execute_control` 关闭单次 TLS 连接，但不释放外部计划租约；因此根层可以在
Stop → 文件传输/Load → Start → 运行验证期间连续持锁。

## 本机验证入口

`test_controller_control(store, project_id, expected_project_sha256, package_job_id,
action='stop', fault='none', start_kind='cold')` 验证当前包身份，创建自己拥有的
127.0.0.1 随机端口测试设备，不接受外部端点、密码或批准记录。测试设备的状态效果是模拟的。

fault：`none`、`reply_lost`、`state_delayed`、`state_timeout`、`state_error`、
`disconnect_after_ack`、`rpc_error`、`already_stopped`（Stop 专用）、`initial_wrong`、
`missing_identity`、`wrong_identity`。成功为 `loopback_control_passed`；注入失败保留
`control_failed` 和真实的模拟端效果，不把失败包装为下载成功。Start 的本机身份来源明确为
`loopback_fixture_loaded_package`，不声称真实设备哈希读取。

回归命令：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -m unittest discover -s 'D:\work\code\PLCnext-Engineer-mcp\tests' -p test_controller_control.py -v
```

测试覆盖原厂字节、截断/错误模式拒绝、Running→Stop、已 Stop、Stop→Start、迟到状态、
ACK 后未完成、断连、丢回复、取消、pin 错误、缺失/错误 loaded identity、范围越权、
单次发送、并发消费、过期/撤销/拒绝、旧版本绑定、跨作业租约以及结果落盘失败后的隔离。
所有设备请求都只到本机；审批测试用 PUBLIC 临时收据和 RFC5737 地址且禁止 socket。
