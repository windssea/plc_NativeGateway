# dlc.bin 的明确生成策略

核对日期：2026-10-26。关联 M05。只操作工程副本和本地 MemoryStream；本证据不证明真实 PLC 接受。

本机厂商 `Ade.PlcImpl.dll` 的 `TargetDeviceFacade.ReadMemento` / `StoreMemento` / `get_DownloadFilePath` 明确将 `dlc.bin` 用作下载能力历史。`DownloadCapabilityContext.Prepare` 从该文件加载 `DownloadCapabilityStateMemento`，`Complete` 保存状态并交给 StoreMemento。它不能被当成当前内存已加载程序的 hash 或恢复镜像。

目标身份：SHA256 `ee537d92540ff4f6270f0b2a34121d971abab993fc481319a90bd1bb80508298`，MVID `1669d53f-7ef8-4452-812c-defedab484c3`。REA Evidence：`ev_ee23764f0da9393aaf8c03b43497589f01fce90a6989b488850be65bba6614d0`。静态方法 token：ReadMemento `0x0600017a`、StoreMemento `0x0600017b`、Save `0x0600015b`、Load `0x0600015a`。

独立构造一个空的原厂 memento 并对纯 MemoryStream 执行 Save，输出恰好为 **0 bytes**；新对象 Load 此流成功。没有启动 Engineer、ACI、CodeMeter 或网络。它代表“无历史”，并不代表任何先前工程可在线变更。

## MCP 策略

`project_generate_pcwe` 新参数 `download_memento_policy`：

| 值 | 行为 | 影响 |
|---|---|---|
| `omit`（兼容默认） | 不生成 dlc.bin | 远端多出此路径时继续严格拒绝下载 |
| `empty_capability_v1` | 按原厂空格式生成 dlc.bin，纳入 SHA-512 manifest | 以无历史状态替换旧 Engineer 下载能力历史，不伪造旧版本匹配 |

新策略不会忽略任意额外文件，不读取或沿用旧性能候选的历史，也不自动删除远端文件。未知路径集合仍拒绝。新包、审阅及操作者确认须包含该策略和覆盖影响；原 v1 下载收据的授权动作未增加 Stop/Start。

本轮指定恢复源的 49 文件候选使用 `empty_capability_v1`。实际 TCP/TLS 本机验证中，49 文件（包括空文件）的写入和 SHA-512 回读、Reset/Load 均通过；分块回读通过，损坏及 Load 丢回复被正确拒绝/标记不确定。记录在 [当前实施数据](../artifacts/joint-implementation/current.json) 的 `m05_loopback`。

## 证据

- [字符串所在方法](../artifacts/joint-implementation/dlc/literal-locations.json)
- [静态方法体与完整身份](../artifacts/joint-implementation/dlc/memento-il.json)
- [调用者](../artifacts/joint-implementation/dlc/memento-callers.json)
- [memento 序列化方法体](../artifacts/joint-implementation/dlc/capability-memento-il.json)
- [原厂空格式 Save/Load oracle](../artifacts/joint-implementation/dlc/empty-oracle.json)
- [独立实现](../src/plcnext_mcp/download_memento.py)

仍未验证真实设备写权限、完整性/签名接受、固件加载行为以及清空下载历史对后续 Engineer 增量工作的完整影响；这些限制必须保留在实际操作审阅中。
