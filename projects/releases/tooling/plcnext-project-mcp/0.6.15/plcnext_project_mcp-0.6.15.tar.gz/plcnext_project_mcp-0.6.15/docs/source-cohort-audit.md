# M13：固定源窗口关联闭合（0.6.8）

用于保存当前 boot 的有限源窗口及其后形成的批次关联。关联齐全不是 DATA/STORED/数据库入库证明，不替代外部选择器、名义槽或决策时钟核验。

## 调用

父恢复 `project_prepare_recovery` 新增：

```json
{
  "audit_duration_seconds": 30,
  "audit_closure_mode": "source_cohort",
  "audit_tail_seconds": 30
}
```

仍须传入原有精确 project/source/package/target/pin 等参数，再 inspect、精确授权、execute；prepare 不连接设备。独立 `project_prepare_audit_export` 使用 `closure_mode="source_cohort"`、`tail_seconds=30`，其余参数保持原样。默认 `raw_tail` 保持原有双尾界语义。

模式、duration、tail 和所有已有记录/字节/网络限额都保存在子 policy 内并进入子哈希；父哈希包含子哈希。父 duration + tail + 业务观察预算不得超过240秒，父执行总期限仍300秒。tail 为1..120秒，默认10秒；不延长、不重试。独立执行总预算为 duration + tail + 40秒；父子标注 maximum_total_seconds=300。实际进程退出后仍按已有终态/未知结果核销规范处理。

默认记录上限100000、字节67108864、网络字节67108864、网络操作20000，固定512/32环与每次64/16条读取。达到任一上限不补造关联；失败结果保留固定N及已知未关联序号，若源决策尚未导出齐全，source_decisions_complete=false，不能把当前已知集合当作全部分母。

## 行为和证据

运行窗口结束只冻结源 N。以 N 内实际 Decision=2 的序号集合为关联目标；独立外部核验器仍须重算应该接纳的集合。尾阶段继续导出 N 后的 capture 和后来形成的 association，使审计环持续得到持久副本确认；不等待全局业务队列清空。

关联整条保存，不拆批、不修改 Digest 或 SampleSeq 列表。混合批次可覆盖 N 内外序号；只对 N 内目标计数。通过源序号、原配置 slot/generation 匹配，不按值或 UTC 合并事件。重复关联、重复批次身份、非接纳或外来引用、配置变化均拒绝。引用尚未导出的已存在源记录时推迟该关联确认，先保存原始记录。仍先 fsync 后四字段审计 ACK，不写业务 FIFO、业务 ACK 或采集参数。

结果新增 source_boundary、exported_capture_end、exported_association_end、admitted_source_count、associated_source_count、unassociated_source_seqs、raw_prefix_complete、source_decisions_complete、source_cohort_associations_complete、outside_source_capture_range、closure_failure_reason。尾阶段 capture 追加 within_source_window；前面记录可依照冻结N判断。

新模式写 sourceBoundary/sourceCohortEnd，tail 返回 null，不复用或改变旧 end.complete_through_tail 字段。业务 globalAccountingComplete/restartLossUnknown/gapDetailTruncated 保留原口径，business_delivery_verified 始终false。报告的关联唯一性限于已观察的原始记录，不能保证停止观察后不会出现异常。

## 验证

本地 TLS 验证延迟组包、跨N混合批、继续输入、固定N、同值同UTC独立序号、缺关联超时、错误generation、重复引用、真实溢出、落盘失败、取消、记录上限、未知ACK，以及父恢复共享租约闭合。已有核销/恢复回归保留。

冻结负例 tests/fixtures/boot69-source-cohort.json 保存原capture/association行及事件文件SHA256。旧文件的关联可能先于相应capture行出现，离线统计先建立完整源索引再计算关联；没有改写旧日志。结果仍为 N=1758、A=1050、已关联1044、缺6，不能把旧运行升级为闭合。

本轮只做本机与离线验证，没有连接、下载、恢复真实PLC，没有启动P06。
