> 0.6.5 新增父恢复Start协作及共享租约，[见M12-S](recovery-start-audit.md)。下文独立导出入口仍适用于已知boot。

# M12 原生事件与批次关联审计导出（0.6.4）

当前共有 78 个公开 MCP 工具。新增 5 个审计入口，使用独立 TLS/RSC 客户端，不依赖 ACI、Engineer 界面或外部 Python 私有传输。

## 范围与前提

只支持源中具备完整审计字段的候选：512 capture 环、32 association 环、4 槽配置字典、最多320点/50设备、诊断及四个审计 ACK 字段。固定白名单包含17074个源解析标量字段；读取仍分64项，不是任意变量读取或写入。原 native-0.5.0 的32 POU恢复工程没有这些环，明确返回 `audit_profile_unsupported`，不会被修改。

完整源码、冷构建和 PCWE 包必须先存在；准备阶段绑定工程 SHA、包清单、目标IP/pin、预期 BootId、符号/类型白名单、输出和限额。执行前重新检查本地绑定、设备 Running/boot、远端包全部审阅文件及实际字节匹配。磁盘包校验不冒充内存镜像哈希证明；boot/源符号也不能单独证明内存镜像身份。

## 公开调用

1. `project_prepare_audit_export(project_id, expected_project_sha256, package_job_id, address, expected_certificate_sha256, expected_boot_id, ...)`
2. `project_inspect_audit_export(project_id, plan_id, expected_plan_sha256)`
3. `project_authorize_controller_operation(project_id, review_id=plan_id, expected_review_sha256=plan_sha256, kind="audit_export", reason=...)`
4. `project_execute_audit_export(project_id, plan_id, expected_plan_sha256)`
5. 执行中可调用 `project_audit_export_status` / `project_cancel_audit_export`，参数同第4步。

执行是有总时限的同步工具调用，调用器需保持同一 MCP 宿主会话直到终态，设置足够的工具等待时间。导出时长1..300秒，默认30秒；另有10秒尾界排空和40秒包校验/初始化预算。轮询间隔20..1000ms，默认100ms。默认事件文件上限64MiB、100000条；最大256MiB/1000000条。每次最多64条capture及16条association；运行时网络预算64MiB，另外包核验预算64MiB，操作数上限20000。

输出固定为托管工程的 `audit-exports/<plan_id>/events.jsonl`，由准备结果返回，不接受任意输出路径。全新文件、一次授权和全新计划；已尝试的计划不可重新执行。源变化后仍可查看状态或取消，不通过失效源来阻止取消。

## 落盘与 ACK

事件文件顺序包含 start 前缀边界、generation围栏后的配置字典、原始capture事件/Decision/Reason、batch Ordinal/MessageId/Digest/sampleSeqs/Category、诊断、tailBoundary和end。使用sampleSeq关联，UTC相同不会合并记录。审计内容不替代三方独立计算的选择/过滤期望。

批次数据必须连续 append、flush、fsync 成功，才能发 ACK。ACK intent 先记录持久字节数及SHA256。允许写入仅：

- `MainInstance.CaptureBuffer.AuditAckBootId`
- `MainInstance.CaptureBuffer.AuditAckSeq`
- `MainInstance.CaptureBuffer.AssociationAckBootId`
- `MainInstance.CaptureBuffer.AssociationAckSeq`

每个游标严格执行 BootId清空 → Seq清零 → 精确BootId → 已持久化连续Seq，写入前再次检查 boot、配置和读游标，提交后回读。没有任意地址、Force、DATA/STORED、业务FIFO、采样配置或控制器启停写入。

## 完整性与失败

要求从本 boot 的第1条开始证明完整前缀；若旧消费者已释放记录，拒绝伪造完整性。环溢出、丢记录、未知generation、读中覆盖、配置/boot变化、诊断不完整、文件或网络限额、取消、超时都返回不完整。固定尾界后只确认到该边界；后续产生的事件不包含在该结果的完整性声明中。全量诊断未稳定读到时不能报告完成。

同一 OS 用户的 MCP 端点租约提供排他消费者，且阻止同时下载/启停。外部 Engineer 或其他用户不受本机锁控制；检测到外部读游标前移则停止。ACK部分写入、丢回复或回读失败均停止，保留审计与隔离租约，不自动重发。宿主退出保留文件/租约，状态报告 `host_outcome_unknown`，不能通过重启同一计划续传。宿主仍存在但无终态只报告 `active_host_no_terminal_result`，不把PID存在当作执行正常证明。M11/M11-S不会核销未知审计 ACK；这种情况需要后续单独核对，不自动删锁。

取消在下次I/O边界生效，不证明已发ACK撤销。原始输出、ACK日志、传输日志、结果与哈希均保留；完成结果报告导出速率、积压高水位和网络量。速率是观察量，不是PLC任务监视负荷验证，也不是P06性能通过。

## 本轮验证与未验证项

- 本机拥有的loopback TLS服务器，使用生产RSC编码/读取/ACK路径验证。
- 覆盖前缀/尾界、相同UTC多事件、回绕/溢出、配置/boot/generation变化、并发消费者、fsync失败、ACK丢回复/回读失败、取消、宿主退出、记录/字节上限以及禁止重放。
- 对冻结完整候选本地验证17074个符号；公开MCP新会话确认0.6.4/78工具，并验证原32 POU工程明确unsupported。[公开验证](../artifacts/audit-export-research/public-verification.json)。
- **本轮没有连接真实PLC，没有下载候选，没有改采样/任务/缓冲容量，没有启动P06。真实50事件/秒持续导出、监视负荷及现场全链路仍待单独明确候选和恢复方案后验证。**

测试记录：全量555项中554通过、1跳过，[全量日志](../artifacts/joint-implementation/full-tests-m12.log)；最终审计专项18项全部通过，[专项日志](../artifacts/audit-export-research/final-audit-tests.log)。
