# 0.3.0 整体核验

2026-10-25，对当前声明的 25 个 MCP 工具执行源码审查、单元/异常输入测试、真实 stdio 集成和独立 wheel 安装验证。**发现并修复 6 类代码问题，另修正旧分发包和能力范围说明。当前支持的离线范围未再发现阻断问题。** 这不是“所有工程或真 PLC 均兼容”的保证。

全程只修改源码、测试、诊断报告和新工程副本；未连接、下载或启动真实 PLC，未使用 ACI/Engineer GUI/computer use，也未修改许可。

## 已修复的问题

| 问题 | 修复和回归 |
| --- | --- |
| 冷编译扫描归档 POU，却未核对 PROJECT.proj 注册集合和 ID | 核对每个注册路径、metadata ID、重复 ID/注册、缺失及孤立 POU；异常源在启动编译器前拒绝 |
| `a,b : FB` 的引用检索只返回 b | 提取完整逗号实例列表并分别检索调用；真实 61→62→61 MCP 流程验证两实例都被发现 |
| CloseSession 再次失败时覆盖主传输错误，或丢失已加载事实 | 分离操作结果与清理结果；保留主错误及 loaded 状态，记录 cleanup_failed；未知 codec/TLS 异常也返回失败收据 |
| 非 ASCII 用户名/密码触发 compare_digest 的 Python TypeError | 按 UTF8 字节比较，错误凭证通过二进制 RPC 正常返回 InvalidCredentials |
| IMG 先验证磁盘、后读取打包，实际消费字节未再对哈希 | 对实际加入 PCWE 的 IMG bytes 重新核对冷构建 SHA-256 |
| HMI 输出先验证文件、后读取内容，同长度瞬时替换可能绕过 | 对实际消费 bytes 同时核对长度和 receipt SHA-256；两项竞态以单次读快照替换复现，未改原文件 |

旧 dist/0.2.0 wheel 仅包含 19 工具，缺少后续 PCWE、HMI、二进制下载及 TLS 资源，不能作为当前全功能安装包。已更新版本和 uv.lock 至 **0.3.0**，重建 wheel，更新安装说明；旧包仅作历史保留。

额外收紧：非空 IOConfiguration.ioc 尚未支持，现明确拒绝，避免落到原厂解析依赖异常；空 I/O 当前配置正常。109 个逐项核验的实例明确限定为**工程内 FB**，当前至少四个库 FB 的独立布局不包含在该计数中。HMI 别名探测会失败关闭，未误报完整包成功。

## 验证结果

| 范围 | 实测 |
| --- | --- |
| 全套回归 | **273 项，272 通过、1 跳过**，17.207 秒；跳过项需 Windows 符号链接创建权限 |
| 全新 61 POU 副本 | 真实注册 MCP：读取/patch/差异/语法/恢复、原子新增 FB 和双实例调用、引用删除保护、61→62→61 冷编译 |
| 源及映射 | 原 61 POU 快照不变；新副本未编辑的 metadata、DataList、ESM、IOC、HMI 页面均逐字节保留 |
| 包及模拟 | 新冷构建生成新 48 文件 PCWE，完整清单检查及暂存回读通过，16 个二进制 TLS 模拟场景全部符合预期 |
| 工程创建及跨项目 | 官方模板副本 1→2→1 的三次冷编译通过；第二个仓库外客户端进程可重新读取同一 managed project |
| 全接口修改 | 31 POU 全量代码/变量与 FB 输入联动，冷模式及旧 expanded cached 模式正例、参数改名/类型/语法三负例及恢复均通过 |
| 旧单 FB cached 工具 | baseline/修改编译通过，未声明符号和语法错误正确拒绝，旧哈希拒绝 |
| 新 wheel | 独立 site-packages 导入，25 工具、实际语法检查、61 POU 冷编译、48 文件 HMI/运行包及二进制 TLS 模拟通过 |

源审查另实际编译了一个未被 Main 引用的错误 FB：32 POU 均重解析，返回 SEM1036 / semantic_failed，未启动 native backend。这确认不可达 POU 也受语义检查，而非只对被调用 POU 生效。

25 工具覆盖由真实注册综合流程的 22 个工具，加工程创建/单独 add_fb 流程及 cached 工具组成。兼容入口的 cold 和 cached 两模式均复测。当前全新副本及新包：

- 工程：`D:\PLCnext-MCP-Workspace\24230ab9954e4bafbbc4510ad7b2b813`。
- PCWE：`D:\PLCnext-MCP-Workspace\24230ab9954e4bafbbc4510ad7b2b813\deployments\db12b9f244a7417984c1f02f3bd72f1b\PCWE`。
- 原 61 POU 源快照 SHA-256：`e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0`，前后相同。
- wheel：`dist/plcnext_project_mcp-0.3.0-py3-none-any.whl`，SHA-256 `91bdbef49e7f9ec60e9962fe9c2e85922431bc1aa6f73dea211f5185e4fb5898`。

## 证据

- [完整单元测试日志](../artifacts/final-audit-full-tests.log)
- [全新 61→62→61 / 打包 / 16 场景 MCP 结果](../artifacts/final-audit-e2e/54086508fc07409f8571c1ee24540fcf/result.json)
- [新工程及跨项目注册验证](../artifacts/codex-registration/1448b81b96bf4709a2f28178984c03e1/result.json)
- [全 POU/接口冷编译验证](../artifacts/cold-compile-mcp-e2e/1bd4056b36054ce2b13394d2fb622515/result.json)
- [全 POU/接口 cached 验证](../artifacts/expanded-compile-mcp-e2e/316af8f237204549a50c32e060b6797d/result.json)
- [单 FB cached 验证日志](../artifacts/final-audit-cached-e2e.log)
- [0.3.0 wheel 独立安装实跑](../artifacts/final-audit-wheel/c7fd56bd0158477cbdda536c50bdd493/result.json)
- [编辑/编译独立审查](../artifacts/final-edit-audit/review.json) · [包独立审查](../artifacts/final-package-audit/review.json)

独立审查报告保留发现时状态，新增回归测试及最终日志证明修复结果。合成故障不冒充真实编译；真实编译产物只读取元数据，没有执行 PLC 应用。

## 仍然存在的范围限制

当前未发现已支持流程中的未修复阻断故障，但真实 PLC 通道、实际签名/设备接受/实时执行、其他设备架构及通用 RSC profiles 仍未验证或实现。完整 PCWE 打包仅限已验证 NativeGateway 硬件/服务和 Gateway/Login HMI，I/O 和 HMI 编辑不作通用支持承诺。所有工具仍保持 controller_access=false / deployable=false。

安装当前 wheel 或保留本机已更新的 editable 服务即可；重载 MCP 进程后加载 0.3.0。无需重新注册 Codex，也无需向工具提供 PLC 地址或真实凭证。
