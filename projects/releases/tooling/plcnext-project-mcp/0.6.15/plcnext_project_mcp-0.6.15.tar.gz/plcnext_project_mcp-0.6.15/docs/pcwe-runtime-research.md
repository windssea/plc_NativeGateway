# 当前 NativeGateway 的运行配置重建

2026-10-25。限定本地 61 POU 工程副本及冻结的 31 POU 样本；没有连接 PLC、执行镜像或操作 GUI。

已实现 `src/plcnext_mcp/runtime_configuration.py`：

```python
files, report = generate_runtime_configuration(members, project_title=None)
verification = validate_runtime_configuration(files, report)
```

`members` 是经过构建调用方校验的当前 PCWEX 成员字节字典。`files` 返回四个相对 PCWE 路径及新生成 bytes：
Domain、ESM、GDS、PLM。完全不读取 GUI XML 作为生成输入。`report` 包含源/生成哈希、运行任务、程序实例、
实例顺序、77 个全局变量身份/名称/类型/地址、10 个 HMI 映射、20 个未连接的端口，以及验证结果。
HMI 映射在此模块中仅核验并报告；HMI 的工程包文件应由外层组包模块处理，不能宣称空 GDS 就是没有 HMI 映射。

## 结果

- 当前 61 POU 工程来源：`D:/PLCnext-MCP-Workspace/a431bdc32f2a4aa1812c94683db38395/revision-0000.pcwex`。
- 四项配置成功从源码生成，运行语义与冻结 31 POU 工程生成结果一致。
- 对冻结 GUI 的四项输出进行了独立 XML 语义比较：相同的 namespace、schemaVersion、元素、属性和子元素顺序。
  比较 Domain 时显式使用 GUI 的 solution title `revision-0001`；日常默认读取 Core.xml 的 title `NativeGateway`。
- Domain ID 是 `ec4bcef4-d7ab-474c-80d7-b5dfda91b45d`，不是 PROJECT.proj 的 ProjectId `5370a173-...`。
- ESM 为 ESM1/Cyclic100，周期 20000000 ns，看门狗 500000000 ns；MainInstance/Main/Arp.Plc.Eclr，order=0。
- 77 个 DataList Variable 全部与 GlobalVariables.var 的持久 Id、名称、类型、地址对应。
- 10 个 HmiTag+Variable 映射保留在报告中；InPort 与 OutPort 各 10 个，均单独位于 Datum，没有外部 GDS 配对。
- `.ds` 中 8 项 `SysVarUpdateTask`/`DeviceSysVarUpdateTask` 均为 `[UTF-8;]`，因此 ComponentTaskRelations 为空。
- PLM 源中的 7 个 component 均 `isReadOnly=true`；厂商生成器明确跳过这些系统组件。

本模块 11 项测试通过：真实 61 工程与冻结样本、四文档 GUI 对照、周期变化、实例改名、缺失实例/ESM、
变量 ID/类型变化、GDS 配对、用户 PLM 组件、任务绑定篡改、系统地址不一致和系统变量更新任务变化。
非空外部 GDS、用户组件、其他任务类型、多任务/多程序实例或未观察到的地址/源结构均拒绝，不静默丢弃。

## 底层规则与证据

REA `Ade.Network.Compiler.PlcNextImpl.dll` 成员证据：
`ev_0f54b4e4dcfae5a4d81a5a3945996f41a3e3b009135f48af8f7f07e657eeb22d`，
[完整文件](../artifacts/pcwe-runtime-research/rea-network-compiler-members.json)。
静态选定 CIL 方法体保存为 [runtime-builders-il.json](../artifacts/pcwe-runtime-research/runtime-builders-il.json)
和 [runtime-config-il.json](../artifacts/pcwe-runtime-research/runtime-config-il.json)，包含 DLL SHA-256、MVID、token 和指令偏移。

| 方法 | token | 已观察规则 |
| --- | --- | --- |
| PlcDomainConfiguration.Evaluate | 0x060001b2 | 从 ISolution.Id/Title 和项目 AdeProductVersion 获取 identity |
| PlcDomainConfiguration.GetPlcNextVersion | 0x060001b0 | 版本输出 Major.Minor.Revision.Build，最后两段与 .NET Version 顺序交换 |
| CompilableEsm.CompileCyclicTask | 0x060002f2 | IntervalTime→cycleTime，复制 priority/watchdogTime/executionTimeThreshold |
| CompilableEsm.CompileToCore | 0x060002f4 | 复制 name、stackSize，显式写 stackSize |
| CompilableEsm.CompileProgramList | 0x060002f5 | 复制 name/componentName/programType，逐任务从 0 计算实例 order |
| EsmConfigurationDocumentBuilder.TaskRelation | 0x0600037b | programName 为 componentName/name，component 为空则只 name |
| GdsConfigurationBuilder.Build | 0x0600023f | 分别筛选 ConnectedPort、ConnectedVariable、ConnectedSafetyVariable、ExchangeVariable |
| GdsConfigurationBuilder.CreateConnectorDefinitions | 0x06000243 | 起点/终点使用端口 Description 或 ExtendedDescription，不能只拼变量名字 |
| SystemVariablesUpdateMapBuilder.Build | 0x060002e8 | 从拓扑层的 SysVarUpdateTask/DeviceSysVarUpdateTask 构造组件任务关系 |
| PlmConfiguration.Load | 0x06000140 | 跳过 IsReadOnly=true 组件；仅对其余组件计算需要的程序库 |

REA `Ade.DataList.dll` 成员证据：
`ev_a4003acb68e282e27dbe760fc6fd25580a41a6420c216c2a593383bab74fedfb`，
[完整文件](../artifacts/pcwe-runtime-research/rea-datalist-members.json)。首次传输超出 MCP 限制，按技能要求导出
[完整证据包](../artifacts/pcwe-runtime-research/rea-runtime-bundle.json)，未重复分析。
SHA-256 `af6ddeac75216681ae1f44a5b47e68fd872c47765f22aac268d542012abaf081`。

`Spec..cctor` token 0x0600020f、`ConnectedRolesSpecification.IsSatisfiedBy` token 0x06000198：
必须是同一个 Datum 中的多个 Role，ConnectedPort=InPort+OutPort；ConnectedVariable=Variable+ProcessDatum；
ConnectedSafetyVariable=SafetyVariable+ProcessDatum；ExchangeVariable=Variable+SafetyVariable 且无 ProcessDatum。
DataList RoleGroup 是显示分组，不能当作连线。完整方法体见
[datalist-spec-il.json](../artifacts/pcwe-runtime-research/datalist-spec-il.json)。

## 使用边界

调用方仍需核验目标设备/版本及成功 cold build，并负责 eCLR 镜像、原生库、I/O、HMI、OPC UA、软件清单和整体完整性。
本模块不是所有 PLCnext 设备的通用配置编译器。当前 `.ds` 八项为空、固定三项系统地址的范围来自已观察的 AXC F 2152/2026 样本。
当前 61 POU 工程无真实非空 GDS 连线；新增此类连线的负例证明会被拒绝，不能作为已实现非空 GDS 的证据。
通过离线 XML 和源变量检查不等于在控制器上验证了运行时执行或物理 I/O 行为。
