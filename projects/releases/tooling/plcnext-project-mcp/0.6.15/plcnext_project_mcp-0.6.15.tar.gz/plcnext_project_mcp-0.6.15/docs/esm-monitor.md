# M08：现有 ESM 系统变量的固定只读 profile

2026-10-26。`esm_monitor.py` 使用原工程已经声明的 `ESM_DATA`，通过独立 DataAccess.Read 读取；不创建新探针、不改恢复源码、不调用 ACI/Engineer/computer use，也不恢复 P06 性能测试。

## 来源与类型

官方安装模板 `AXCF215200260.pxctx` SHA-256 为 `dedd33bfab3a7de4a3ecb08f7b47281b63d7980be84c15179dda50ce86cb9657`；其中 `GeneratedDataTypes.dt` SHA-256 为 `8739c35b6d76e20248e95952198eb9ea7ea9253368560ef80047946a1e3ec796`。指定恢复归档的同名工作表完全匹配；profile 以该精确 member hash 为门禁，拒绝未经核对的系统类型。

当前 ESM 数组范围 1…2，任务数组 1…16。`INTERVAL`、`WATCHDOG`、各 EXEC_DURATION / ACTIVATION_DELAY、EXEC_TIME_THRESHOLD 为 LINT；PRIORITY 为 INT；**EXEC_TIME_THRESHOLD_CNT 为 UDINT / uint32**；NAME 裸 STRING 在当前成功冷构建中是 IecString80。

[官方 2025 系统变量说明](https://engineer.plcnext.help/2025.0_en/UI_PLANT_Devices_Controller_iC9226EC_Node.htm)用于时间单位与统计语义：周期、看门狗和耗时以微秒描述，执行耗时包含高优先级任务抢占。该页的 counter 类型写为 ULINT，与本机 2026 模板不同；实现按本机类型校验，不把网页套成目标固件已验证。`device_timing_units_verified=false` 保留未做真实目标单位验收的事实。

静态证据：[模板与 REA 类型记录](../artifacts/esm-monitor-research/rea-system-types.json)、[Cecil 完整字段类型/数组常量](../artifacts/esm-monitor-research/cecil-system-types.json)。Common.dll 是本次成功冷构建生成物，不冒充原厂交付二进制。REA Evidence `ev_6d01582ca73f24499cbd5a179777bb283838b886c154a2f3576e7471248707bb` 的覆盖 complete。

## 使用

- `prepare_esm_read_plan(store, project_id, expected_project_sha256, address, expected_certificate_sha256, port=41100, esm_indices=None, task_indices=None)` 创建本地只读计划，返回 plan_id / plan_sha256。默认检查源任务所在 ESM 的 16 个任务槽，必要时显式选择例如 `esm_indices=[1], task_indices=[1]`。
- `read_esm_plan(store, project_id, plan_id, expected_plan_sha256, previous_observation_id=None, expected_previous_sha256=None)` 执行一次有限读取，按实际任务 NAME、源 ESM、周期、看门狗及优先级核对映射。
- `test_esm_read_plan(store, project_id, expected_project_sha256, fault='none')` 仅向新建的 own 127.0.0.1 TLS peer 读取。故障可选 missing_field、boot_change、wrong_task_name。

公开 MCP 名称为 `project_prepare_esm_read`、`project_read_esm`、`project_test_esm_read`。确切 Schema 以新会话工具发现为准。源类型、计划、目标和监视子计划都重新校验；不开放任意系统路径、索引、内存地址、变量写或统计重置操作。

## 结果与限制

每个任务槽返回实读字段、缺失字段和与源任务绑定结果。不存在、未导出或实际类型不匹配保持 unsupported/partial，不能补零。读取前后仍用 boot/config/state guard，跨窗口变化标无效；窗口不是原子快照。

计数比较只在同源、同目标、同 boot/config guard 的有效窗口中进行。counter 或峰值下降时区分不了复位与回绕，delta 返回 unknown；不同 boot/config 不跨代相减。读取窗口的主机单调时钟区间单列，跨进程时钟域不可比则采样间隙 unknown。报告采样空洞不能当作每个 PLC 周期均已观测。

`EXEC_TIME_THRESHOLD_CNT` 不自动等同于周期超期或看门狗触发次数；看门狗历史计数没有可证实字段时返回 null。LAST/MAX 含抢占，不能当作新增工作 CPU 成本。新工作≤1ms、吞吐≥90 条/秒与整体性能结论均不由 RPC 耗时或这些字段推算，`performance_pass=false`。

[5 项测试](../tests/test_esm_monitor.py)覆盖精确 profile、默认 STRING/实际32位 counter、非法索引、只读规划、真实本机 TLS、未导出字段、boot变化、错误任务名、counter下降与跨boot。另有 M04 的响应/频率/超时门禁。真实 PLC 字段可读性及读取负荷尚未在本页测试，详见[验证汇总](../artifacts/esm-monitor-research/verification.json)。
