# PCWE 组包与 HMI 映射的独立复核

2026-10-25。审查 `pcwe_build.py` 与 `hmi_output.py`；只读源码与冻结输出，不执行原厂 helper、GUI 或 PLC 操作。

## 实际 HMI 证据

使用 `artifacts/pcwe-aux-research/probe-36`、`artifacts/pcwe-build-research/fresh-61-build.json` 和
`fresh-61-runtime/TypeInformation.json`，对应当前 61 POU NativeGateway 的新 cold build。

- Gateway 有 494 个页面对象，Login 有 10 个页面对象。
- Gateway 的 `gateway.json` 中所有 `Variable` 与 `DestinationVariable` 字符串去重后是 81 项。
  这个独立集合与 `gateway.variables.json` 中 `variablePathPrefix + name` 的集合完全相同，两方向差集为空。
- Login 页面引用为 `@loginErrorString`、`@loginStatusCode` 及系统引用 `@@SystemUseNotification`。
  前两项必须与 Login 的变量清单匹配，系统引用单独限定。
- Runtime 类型和结构字段 offset 对照产生 81 个 HMI binding，根级 controller tags 是源 DataList 的 10 个 HMI 映射。

## 发现并由主代理修复的问题

1. HMI source receipt 最初只校验非空子集，删除一条仍会通过。现在要求与构建清单中实际 HMI 源筛选集合完整一致。
2. `.variables.json` 的前缀原来不参与验证，错误前缀仍通过。现在 Gateway/Login 前缀均严格核验。
3. 只让 `.variables.json` 与 runtime binding receipt 相互比较，可同时删除两者全部内容而通过。
   现在从实际页面 JSON 独立提取引用集合，并检查对象计数、重复变量以及 Login 系统引用范围。
4. `deployment_plan` 与锁内重新读取 build receipt 之间存在身份/字节绑定缺口。
   现在锁内核验计划返回的 receipt SHA-256，并再次核对 project ID、job ID、project SHA-256。
5. Finalizer 返回的类型文件/报告哈希与组包后来读入的 JSON 原来未绑定。
   现在读取前校验两个输出哈希，HMI receipt 必须消费同一个 finalized type hash，HMI 后再次回读确认输出未变化。

## 独立测试

[test_hmi_output.py](../tests/test_hmi_output.py)：**21 项通过**（0.443 秒）。
包括真实正例、stale type/host/model receipt、source 清单缺失/重复/越界/错误哈希、output 缺失/重复/越界/篡改/大小错误、
生成诊断与完成状态、controller 路径、前缀、变量类型/根名称、协调删除/重复映射、offset、页面对象数和 Login 映射。

[test_pcwe_build.py](../tests/test_pcwe_build.py)：**5 项通过**（0.163 秒）。
包括 plan 后 receipt 变化、receipt 身份不匹配、revision 变化、finalized 输出哈希变化以及 HMI/runtime 使用不同布局。
这些组包负例全部 mock 原厂 helper，不把合成 receipt/IMG/AST 当作真实编译证据。

测试仅在内存或新临时目录修改副本，没有修改 probe-36、cold build、类型文件或原始工程。
上述结论验证离线来源、文件和映射一致性，不构成浏览器动态交互、控制器接受度或 PLC 执行验证。
