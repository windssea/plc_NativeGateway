# 独立多周期任务与 Program 生命周期（M10）

2026-10-26。只支持 AXC F 2152 / 2026、单 eCLR 资源、1…16 个标准周期任务；不调用 ACI、computer use 或设备。任务事件类型、任意核亲和/任务缓冲、外部组件和任意共享数据架构均不在该范围。

本项实现不选择或部署独立遥测架构。真实恢复继续使用用户指定的未改动 **32 POU、单任务归档**；以下新增任务只存在于额外本机测试副本。

## 工具与参数

注册入口由 server.py 集成，核心函数在 task_configuration.py：

| 入口 | 参数 | 结果 |
|---|---|---|
| `project_clone_program` | `project_id`、当前 `expected_project_sha256`、`source_pou_name`、`new_pou_name`，可选完整 `code` / `variables` | 克隆标准 Program，刷新 POU/工作表 ID，保持既有 ID；不自动分配任务 |
| `project_change_cyclic_tasks` | `project_id`、当前 SHA，`add_tasks` / `delete_task_ids`，可选明确 `ownership_contract` 请求 | 原子新增/删除任务、程序实例和绑定，生成新修订 |
| `project_declare_task_ownership` | `project_id`、当前 SHA、`ownership_contract` 请求 | 源改变后重新检查、绑定并记录独占所有权合同；不访问设备 |
| `project_update_cyclic_task` | 原工具，当前 SHA、精确 `task_id`、`updates` | 现支持从多个周期任务中选择一个；其余任务字节不变 |

`add_tasks` 每项必须含 `name`、`program_type`、`instance_name`、`interval_ns`、`watchdog_ns`、`priority`，可选 `esm_id`，默认继承既有任务 ESM。新增任务和程序实例获得新 GUID；任务名、实例名及身份在资源内唯一，不允许一个 Program 类型跨任务共用。

时间单位仍是纳秒，范围 1…86400000000000；优先级 0…99，均为整数。删除要求精确既有任务 ID，不能删除到零任务。任务删除会移除该任务的程序实例映射，但不会偷偷删除 Program 源码。

建议先创建独立 Program：

```json
{
  "source_pou_name":"Main",
  "new_pou_name":"IndependentProbe",
  "code":"Counter := Counter + 1;\n",
  "variables":"VAR\n Counter : UDINT;\nEND_VAR\n"
}
```

随后添加任务的条目：

```json
{
  "name":"IndependentTask",
  "program_type":"IndependentProbe",
  "instance_name":"IndependentInstance",
  "interval_ns":100000000,
  "watchdog_ns":1000000000,
  "priority":30
}
```

每一步都必须使用实际返回的新工程 SHA。先保留原有任务和实例，冷编译及运行配置检查成功后再进行其他结构变更。

## 并发与所有权边界

无所有权合同的多任务工程，保守拒绝调用闭包中的外部变量、地址/指针存储及跨任务共享的可变全局变量。单纯降低任务周期或复制一个任务节点，不等于具有安全的多任务映射。

NativeGateway 的主任务闭包已有地址/外部访问，不能静默放宽门禁。要在**额外副本**中添加纯本地任务，必须明确提供下列请求：

```json
{
  "schema":"plcnext-multitask-ownership-request/v1",
  "exclusive_owner_task":"Cyclic100",
  "independent_local_tasks":["IndependentTask"],
  "no_cross_task_data_handoff":true,
  "primary_owns_existing_globals_and_native_io":true,
  "arbitrary_memory_safety_proven":false
}
```

主任务名称必须取自实际任务检查，不照搬示例。请求精确列出全部额外任务；主任务独占既有全局变量/native I/O，额外任务仅使用自己独立 Program 的局部存储及通过源闭包检查的本地 FB/纯操作。全局访问、外部/地址/指针、跨资源实例引用、未知原生/共享状态调用和未检查的库类型均拒绝。没有跨任务 FIFO 或缓冲交接实现，也不假装该机制已经存在。

实现按最终任务/实例 ID、映射、全部源成员哈希和调用闭包哈希生成 `plcnext-multitask-ownership-contract/v1`，记录于受管 manifest。它是显式开发决策与有界源检查，不是对主任务任意指针行为的形式化内存安全证明；厂商库内部线程安全、运行调度和性能仍未验。

POU/变量等源码改变后，合同失效，构建会拒绝；必须用 `project_declare_task_ownership` 对新源重新检查并记录。仅修改周期/看门狗/优先级时，原独占决策不变，编辑器会重算相同请求并重新检查绑定，不能暗中扩大所有权。

## 结构、编译与打包

- 任务历史通过明确操作重放验证，伪造实例映射及 after-hash 不能绕过重放。
- Program 克隆有独立历史和可编辑工作表允许集，与既有 FB 增删事务按实际修订顺序合并注册成员，防止历史交错错误。
- C# 冷模型构建器生成多个 CyclicTask，独立检验任务名、实例名和跨任务 Program 所有者；无项目 AST 种子。
- 运行 ESM 配置按每个任务/实例产生完整关系；最终 CIL、原生资源/任务字段和运行配置逐项核对。
- HMI 和下载包复核也传递并重新验证精确 ownership contract，不使用调用者随意提供的旧映射报告。

## 本机证据

新建空工程：2 POU / 2 周期任务真实冷编译通过，报告：

`artifacts/multitask-e2e/ec021c435d154e458d6d4b4c47d8e64d/compile.json`

原恢复归档额外导入副本：主任务代码原样保留，只增加本地计数 Program 和独立任务。33 POU 冷编译 0 语法/语义错误，完整 48 文件 PCWE 生成、2 任务/2 Program/2 关系及原生字段校验通过；同一生产客户端的本机 TCP/TLS 分块回读通过全部 48 文件并完成测试 Reset/Load。证据目录：

`artifacts/multitask-native-e2e/f95519debbc04016b43c23c3500cd7b9/`

候选包清单 SHA-256：`9088e3d6cdd32ce8e1909173f1baa9dad176a17d356af2a074a1b8705ab8b2ed`。该多任务候选**未写入真实 PLC，也不是本次原工程恢复包**。

首次 NativeGateway 包检查发现 HMI 重建未传递 ownership contract，按相同源和冷编译输出修复传递后重新生成并通过；失败作业保留。新建空模板的完整 PCWE 仍被既有硬件/服务 profile 拒绝，不将其冷编译成功宣称为任意工程完整打包支持。

`tests/test_multitask_configuration.py` 覆盖新增/删除、精确 ID/时序、独占合同、源改变失效、共享/原生调用拒绝、跨历史注册和失败回滚。真实任务调度、时序、看门狗和物理 I/O 均未做本项实机测试。
