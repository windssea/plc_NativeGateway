# 无 ACI、无 UI 的公开工程编译入口调查

> 本页保留前期公开接口静态调查。后续通过独立托管已验证 NativeGateway 的缓存辅助编译，见 [当前结果与限制](headless-compile-research.md)；这不改变“未找到公开通用 CLI”的有限搜索结论。

调查日期：2026-10-23。范围：本机 PLCnext Engineer 2026.0.4 / 9.0.373.0 安装文件和 Phoenix Contact / PLCnext 官方资料。安装根目录为 `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0`。本轮没有启动厂商程序、调用 ACI、操作 UI、连接 PLC、执行编译、修改安装文件或更改许可；仅新增本报告。

## 结论

**本轮没有找到公开、无需 ACI、能够以 `.pcwex` 或标准 ST 工程为输入完成全量构建的命令行工具。** 这是一项有明确边界的负搜索，不能证明所有内部程序集均无法另行托管。官方随安装帮助仍把 ACI 作为 Engineer 无 UI 运行途径。

进一步静态观察发现：安装包的 `.targets` 虽采用 MSBuild XML 命名空间，但存在厂商自己的 `Ade.Build.BuildEngine`、配置解析器及构建项模型；相关核心程序集没有直接引用 Microsoft.Build。**因此 `dotnet msbuild Ade.Compiler.targets` 不能当作已经可用的完整工程编译命令。** 下一步若研究无 ACI 托管，真正需要恢复的是私有构建上下文及工程对象转换契约，而不只是找到一个 targets 文件。

## 已完成的问题清单

| 问题 | 结果 | 证据边界 |
|---|---|---|
| 官方公开 CLI 是否说明能构建 IEC/ST 工程 | 未找到 | 官方 CLI README 明确定位 C++；官网检索及本机帮助未给出 ST 工程 CLI |
| 本机是否附带独立标准工程 build host | 未发现 | 递归盘点本安装目录的全部 8 个 exe；未覆盖其他磁盘或另行购买的软件包 |
| `.targets` 是否证明可直接使用 Microsoft MSBuild | 否 | 私有构建类型、程序集引用及合成配置；未执行兼容性实验 |
| ST 解析任务是否存在 | 是，静态声明 | Parsing targets 明确分离 ST、变量、类型与 I/O；不代表可独立调用成功 |
| CIL 编译器是否是完整工程前端 | 未证实 | 既有调查支持其为后端；未找到 pcwex 输入契约 |
| 能否提供已验证可复现的 headless 全工程成功命令 | 不能 | 本轮未执行任何厂商程序 |

## 官方公开路径与 PLCnext CLI 边界

1. [2026.0 官方安全指南](https://engineer.plcnext.help/2026.0_LTS_en/SecurityGuidelines.htm) 与本机 `en/Help/SecurityGuidelines.htm:321` 的说明一致：无 UI 运行 Engineer 使用 ACI。该说明是官方产品边界，不是对全部二进制不存在其他机制的数学证明。
2. [官方全量 Rebuild 文档](https://engineer.plcnext.help/2026.0_LTS_en/BuildProject.htm) 描述 `Project > Rebuild`，可构建而不传送到控制器。本机 `en/Help/BuildProject.htm:62` 起有相同说明。F5 属于写入并启动，不是本轮可接受的构建候选。
3. [官方 PLCnext_CLI 仓库](https://github.com/PLCnext/PLCnext_CLI) 说明 CLI 提供 C++ 编程工具链、模板、SDK 管理、CMake、metadata 生成及 Engineer 库生成。当前仓库说明的 .NET 8 是构建 CLI 自身的依赖，不能推导出它能编译 `.pcwex` 或 IEC/ST。
4. [官方 CLI 模板说明](https://www.plcnext-community.net/makersblog/plcnext-cli-templates/) 针对 CLI 22.0.0 LTS，介绍 `project` / `acfproject` 等 C++ 模板。它可作为把逻辑迁移为 C++ 的另一条工程路线，不是现有 IEC 工程的无损替代。
5. 官方社区 2026 年的 [ST 项目无 IDE 构建讨论](https://forum.plcnext-community.net/t/building-plcnext-engineer-st-projects-without-ide-ci-cd-integration/12877) 中，回复建议询问 ACI。它只是论坛建议，不能当成完整 API 文档或独立的“不存在 CLI”证明。

本机 `Get-Command plcncli` 未发现 PATH 命令，本安装目录递归文件名中也未找到 plcncli。未进行全磁盘扫描，不声明机器其他位置一定没有 SDK/CLI。

## 本机文档和可执行文件搜索

对 `en/Help` 的 2243 个 `.htm` 检索 `command.?line`、`headless`、`/noui`、`msbuild`、`compilerloader`、`plcncli`、`toolchain`。相关命中是 ChecksumCalculator 校验、HMI Native Client 执行命令、外部工具链库生成；未见完整 ST 工程编译命令。检查了安装目录下配置、全部 targets/props 和可执行文件名。仅英文安装帮助纳入全文负搜索，不含所有语言资源及嵌入帮助。

递归 exe 清单：

```text
PLCNENG64.exe
PDDataBuilder.exe
cpseventsnet.exe
ProfinetServiceHost.exe
SafetyCompiler2.exe
CIL-Compiler/CilCompilerLoader.exe
EasySimSafety/EasySim.exe
HMI/HmiDebuggerClient/PLCNHMIRE64.exe
```

文件名只用来筛选，不据此宣称程序行为。补充检查：

- `PDDataBuilder.exe`：REA 识别为 x86 C++/CLI / .NET Framework 4.0 混合程序集，引用 System.Data/System.Xml。成员中有 `PDDataGenerator`、`ReadScheduleOutput.BuildSchedule` 和 PNIO 相关声明；原始 UTF-16 字符串包含 `Use: PDDataBuilder.exe OutputXML.xml IPPNIO.xml` 和 `PDDataBuilder for IRT`。这些观察指向 PROFINET IRT 数据生成，不支持把它当标准 ST 全工程编译器；未执行其参数。
- `SafetyCompiler2.exe`：REA 识别为无 CLI 元数据的 native PE；原始 UTF-16 字符串包含 `Usage: cmp2 [path to hardwareinfo.xml]` 及 second safety compiler 描述。仅有字符串证据，不将其扩大为完整行为恢复，也没有执行该程序。
- `cpseventsnet.dll`：REA 识别为 .NET 8 / WPF 相关程序集。没有得到标准工程编译入口证据；未继续把其许可证事件相关内容作为构建方案研究。
- `CilCompilerLoader` 的既有静态证据、身份及限制见 [前一轮调查](free-build-routes.md)。本轮复用结论，没有重复分析或执行加载器。

## 新增观察：`.targets` 由私有构建引擎消费

安装 XML 的可复查位置：

- `Build/Ade.Compiler.Parsing.targets:7–10` 声明 `ParseDataTypeWorksheet`、`ParseVariableWorksheet`、`ParseStructuredTextCodeWorksheet` 和 `ParseIOConfigurationWorksheet`。
- 同文件 `:50–51` 的 ST 任务接收 `@(CodeWorksheet)`，按元数据 `Type == .st` 筛选，且依赖 `BuildDomain`。这不是“输入一个 ST 文件就编译工程”的公开契约。
- `Ade.Compiler.targets:327` 起 `AssembleCompilerProject` 接收 CompiledLibrary、编译后的类型/变量/代码工作表、POU、配置、资源、任务、程序实例和 I/O 组；`:351` 再进入语义分析。这显示完整工程构建需要丰富的前端对象关系。
- `PLCNENG64.exe.config:374–375` 和 `PLCNENG64.exe.Merged.config:14460–14461` 将 `Ade.BuildImpl` 中 `Ade.Build.IBuildEngine` 作为可组合部件列入白名单。

REA 执行无关的元数据/CIL 观察：

| 组件 | 观察 | Evidence |
|---|---|---|
| Ade.CompilerImpl.dll | 完整程序集引用清单含 Ade.Build/Ade.Project/Ade.Plc/MEF 等，没有直接 Microsoft.Build 引用 | `ev_1e7debabec144ad7695c9c3491797ac0556a98c72303bbc72d0f133b5a350e78` |
| Ade.Build.dll | BuildTaskBase、IBuildEngine、IBuildContext、IBuildSourceContainer、BuildParameters、BuildItem 等私有模型；IBuildSourceContainer 有 PrepareBuildItems/GetBuildItems/ReleaseBuildItems | `ev_d37bdc9c5dfe41ed50cb38cf038fd20b013dc61aebfe3cd96c72e417255d9ba7` |
| Ade.BuildImpl.dll 身份 | 完整引用清单无 Microsoft.Build，含 Ade.Build、Ade.Components、MEF、XML 等 | `ev_ab6834b4b5720771828271f224bb72bb7d8660be5e5500c606ee7c8ef8f731f4` |
| Ade.BuildImpl.dll 成员 | 私有 BuildEngineConfigurationParser 有 ParseImports/ReadProjectFile/ReadProjectFileCore/ReadPropertyGroup/ReadItemGroup/ReadTarget/ReadTask；另有 BuildEngine.ExecuteBuild、MefBuildTaskWrapper | `ev_d2d5d2f2ef86239d12ad8ed086a033c13ec16305ded5f2aec4432f56319ed7c1` |

身份：Ade.CompilerImpl SHA-256 `99dfed2dc6183c8d157b9a3975ed79c8502e0d7f3fc3ca4a53c417fe0a40c0f2`，MVID `6b0e8513-c27b-49f2-a1fb-be4822292738`；Ade.BuildImpl SHA-256 `6304d8afe1bc45d808cdd2a81a345d7447ab5d286c332e8b790fb20de1f92048`，MVID `5679ba60-9dfe-4746-b37c-7d7faedd02e5`。

限制：成员解析 coverage 为 partial，多个泛型签名 unsupported。对 Ade.CompilerImpl 全成员的一次检查因 64 MiB representation budget 返回 unavailable，不能把它视为完整成员搜索。以上仅引用成功的身份/引用记录和较小组件成员记录。没有把任何方法名当成实际调用成功。

辅助 exe Evidence：PDDataBuilder 身份 `ev_afba32cad12d88eebf6b8f42bee55bc5d7580fdac2503d391f7489642f92c1f2`，成员 `ev_40e58404498d7b7719e3ff9304c014791cdbeca0415e7f925ad4287486c10b51`（partial）；SafetyCompiler2 分类 `ev_9ef0d120d6be1f33cb94ef91e6f41220317aa1d572cdd06b0ffa1a2596512b70`；cpseventsnet 身份 `ev_e3a8e3359dbfc694b2acc3e3b2e77ad06bad418f7637ed551abc23a2efec036c`。字符串摘录来自原始文件字节，不冒充 REA 已恢复的语义。

## 可复现实验候选及通过标准

本节是后续研究设计，本轮均未运行。没有现成成功命令可交付。

1. **私有构建宿主的静态契约恢复**：针对上述固定哈希的 Ade.Build.dll / Ade.BuildImpl.dll，恢复 BuildParameters 所需属性、IBuildSourceContainer 的来源和 `ReadProjectFileCore` 的实际 XML 处理分支；再追踪工程对象如何生成 BuildItem。成功标准是得到明确输入契约及可构造最小上下文；只有 new BuildEngine() 或枚举 target 名称不算完成。它是内部接口研究，公开支持性和独立调用许可条件仍未知。
2. **隔离的工具自描述实验**：若后续允许执行，仅在空白临时目录调用独立 `CilCompilerLoader.exe` 的文档确认帮助参数，完整捕获进程退出码/标准输出/文件变化。若参数实际要求已有 CIL 或编译资源，只能证明后端存在，不能宣称支持 ST/pcwex。不可用 `/NOUI` 启动 Engineer 并把它当无 ACI 编译验证。
3. **真正的工程构建验收**：必须从冻结 pcwex 副本开始，明确输入哈希、无缓存全量构建、错误计数与产物身份；再用故意破坏 ST 的副本验证非零失败或等价失败结果。没有失败样例控制，不能把“无报错”当厂商编译成功。任何宿主实验先使用本机正常许可条件，不修改许可模块、配置黑名单或认证。
4. **公开工具链替代**：官方 PLCnext CLI 可单独验证 C++ 组件构建。即使成功，也单独标为 C++ 路线；它不能结清“现有 IEC/ST 工程的无 ACI 无 UI 构建”目标。

当前最准确的能力声明是：原生工程编辑 MCP 已有独立价值；本轮仍未证实可以通过公开免费接口补齐无 UI 厂商构建。私有构建引擎值得进一步研究，但不是已完成替代品。
