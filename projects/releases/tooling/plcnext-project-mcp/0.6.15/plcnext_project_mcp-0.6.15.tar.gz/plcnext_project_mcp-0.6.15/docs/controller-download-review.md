# 真实下载前的版本与影响审阅

2026-10-26。新增 [controller_download_plan.py](../src/plcnext_mcp/controller_download_plan.py)，将 NativeGateway 管理副本的具体源码、冷编译、PCWE 文件和设备目标写成可重验的审阅记录。此模块不导入 socket/HTTP、不调用 ACI/Engineer，不读取凭据，也没有授予设备写入权限的函数。

用户当前只授权 `192.168.0.8` 的只读测试，要求实际下载前先确认版本和影响。故生成结果固定为 `authorization_status="awaiting_user_confirmation"`、`write_authorized=false`。**review ID 和 SHA-256 用于选定审阅版本，均不是可执行下载的 capability token。**

## 接口

```python
prepare_download_review(store, project_id, expected_project_sha256,
                        package_job_id, address, expected_certificate_sha256,
                        port=41100)
load_download_review(store, project_id, review_id,
                     expected_review_sha256=None)
revalidate_download_review(store, project_id, review_id,
                           expected_review_sha256)
```

内部 `review_package_snapshot(...) -> (review, files)` 可供后续下载客户端取得与审阅绑定的文件字节。返回的 review 仍然未授权；调用者必须另外验证真实的人类确认，不得因为已经收到文件字节或 SHA-256 就允许设备写入。MCP 当前只应暴露 prepare/inspect/revalidate，不能暴露自批准入口。

每个审阅写入管理工程的 `controller-download-reviews/<UUID>/review.json`，不覆盖现有记录。load 读取既有记录；revalidate 重新使用 `_package_snapshot` 检查当前源和包，并比较全部字节身份。

## 版本绑定

创建和重验时复用已有完整检查：当前 revision 哈希、成功冷编译收据、生成的 PCWE 收据、inventory、运行配置、CIL/原生类型和镜像绑定。审阅明确包含：

- 项目名称、项目 GUID、managed revision、完整源码 SHA-256、原始副本来源路径。
- 包的软件 revision、生成时间、目标 product/firmware 元数据。这些只是该包声明的版本标签，不是实际设备兼容性证明。
- build/package job ID、二者收据哈希、inventory SHA-256、镜像 SHA-256。
- 全部文件路径、字节数、SHA-256 和 SHA-512，文件总数与字节数，以及变量/FB/HMI 绑定数量。
- 设备 literal IP、端口和明确的证书 SHA-256 pin；不接受 URL/主机名或缺失 pin，不做首次连接自动信任。

JSON 有界读取，拒绝重复字段、非有限数和路径逃逸。`review_sha256` 计算规范化完整记录（只排除自身 hash 字段），因此源码、包、目标、影响或策略变动都需要重新审阅。load 即使发现记录被改成 approved 并重新计算自哈希，也会拒绝；该记录类型只能表示待确认。

## 当前 full-load 策略与影响

当前固定为匿名模式，不在计划里保存用户名、密码或安全 token。匿名状态读取成功并不证明匿名文件写入/配置加载有权限；执行前仍须单独验证并保留实际返回。

1. 精确 pin 验证和 tagged/no-datagram 协商，动态服务句柄。
2. 新鲜读取实际状态，**要求已经 Stop**。计划不包含自动 Stop，也不允许自动 Start。
3. 解析并审阅远端 PCWE 目录/清单，再对包内路径逐文件覆盖写入。
4. 全量回读并核对 SHA-512，全部通过后才能 Reset/Load。
5. Reset 后等待 Ready，再 Load 后等待已停止；关闭连接。断线或不确定的写入结果不会自动重试。

审阅明确说明运行程序需要停机、现有包文件会覆盖、配置会重置并重新加载、连接可能断开、期间可能没有已加载工程。客户端不发送 Start/Stop，并不证明固件在 Load 后一定不会自动运行；该行为明确标为未验证，加载后必须核对状态。物理输出和停机期间的控制行为未验证，没有自动回滚，发生不确定写入后需要恢复处理。

**远端旧文件删除尚未实现。** 计划不声称远端 inventory 与包完全相等，不将模拟器的 reconcile 当成远端 RPC。远端清单与旧文件处理未核验时是执行前阻塞项。实际配置/签名接受和物理程序行为属于后验验收，分别标为未知，不伪装为本地打包已经证明。

## 只读状态证据

模块可以读取同一 MCP workspace 下的 `controller-reads/<UUID>/result.json`。只纳入 IP、port、证书 pin 和成功状态匹配的本地记录，标记 `fresh_read_performed=false`、`used_to_authorize_writes=false`。它不会为了准备审阅连接设备。

此前目标 `192.168.0.8` 的只读结果为 Running；如果该记录在同一 workspace，审阅会显示该历史上下文。即使历史记录为 Stop，也不能跳过执行时的新鲜状态检查。不同证书或不同目标的缓存不适用。

## 验证

[6 项单元测试](../tests/test_controller_download_plan.py)通过，测试中 socket/create_connection/subprocess.run 均被阻断。覆盖版本/文件哈希与影响、无自授权 token、错误输入不创建计划、目标改写、伪造 approved/策略、自哈希损坏/重复字段/超长 JSON/路径逃逸、源码或包字节变更，以及历史 Running 状态不授予权限。

这里的单元 fixture 对 `_package_snapshot` 做可控替换，以验证审批边界和 stale 检测；不将其当作实际 PCWE 或真实设备部署的证明。实际 NativeGateway 包验证应由主链调用同一模块并保存其准备/重验结果。

另已对既有 0.4 离线测试副本 `ce032291ef3c4ea3b3271dbd07d35c30`（含先前的任务调度测试变更）的真实 48 文件包执行 prepare/revalidate，完整 `_package_snapshot` 检查通过。[结果](../artifacts/controller-download-review/nativegateway-result.json)。它仅是审阅模块的真实文件集测试，不是用户选定的真机部署版本，仍未授权写入；正式候选应由主流程从本轮选定的 NativeGateway 冻结输入产生。
