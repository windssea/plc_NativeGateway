# M12-S：恢复启动与审计共享租约（0.6.7）

当前79个公开工具。`project_prepare_recovery` 新增可选 `audit_duration_seconds`（1..120秒）；默认None保留原恢复流程。它创建一个绑定父恢复ID的审计子计划，父计划包含子计划哈希和固定审计ACK动作。父恢复授权即覆盖该精确子计划，不单独申请第二份端点租约。

## 使用顺序

1. 准备完整候选的恢复计划，传 `audit_duration_seconds=10`（示例短窗口）及已有source/package/target/pin和RAM策略。
2. `project_inspect_recovery` 检查父计划；用返回的 `children.audit` 调用 `project_inspect_audit_export` 检查子计划及限额。
3. 用 `project_authorize_controller_operation(kind="recovery", review_id=父plan_id, expected_review_sha256=父plan_sha256, reason=...)` 授权父计划。
4. 使用 `project_execute_recovery` 同步执行，或 `project_start_recovery_job` 后持续同一MCP宿主会话轮询终态。现有后台取消入口仍有效；子审计取消也可用 `project_cancel_audit_export`。

父绑定子审计禁止独立调用 `project_execute_audit_export`，不能通过同IP或同OS账号借用另一项作业的租约。

## 执行时序

Stop → 文件传输/全量SHA512回读 → Reset/Load → 审计输出文件与连接预备 → 因果Load核验 → Start → 立即观察新BootId并审计 → 固定尾界排空 → 业务运行验证 → 父终态。

所有必要的本地类型/包核验、审计文件建立、TLS连接和DataAccess服务发现安排在Start前。Start后不重复全包读取；使用父下载的完整回读及Load证据。新boot必须来自同一已确认Start后的真实读取，且不同于Start前值；在父总执行期限内等待应用身份就绪；期间持续读取审计头，读游标或溢出表明前缀已丢时立即失败。有效boot出现后仍通过完整前缀检查，不猜boot、不提前提交ACK。完整父哈希、子哈希、源/包/目标及Stop子审阅必须与连续持有的父租约匹配。

审计在父业务验证之前同步运行，父函数和后台宿主不会在审计仍运行时返回。没有后台脱离的审计线程。审计时长、尾界和业务观察共同受父300秒总期限限制；配置时要求审计+尾界+业务观察预算不超过240秒，预留传输时间。耗时超限如实失败，不修改PLC采样/任务/环容量。

通过启动前缀和序号复核证明sampleSeq1实际存在并被导出；若设备Start响应延迟、网络/磁盘负载或生产速度导致首条已丢失，仍报告不完整，不能仅凭执行顺序声称真机前缀一定保住。

## 返回与失败处理

父结果分别保留 `steps`（控制/传输）、`audit_result`（boot、首条/尾界、持久文件hash、ACK未知标志）及业务验证结果。审计complete仅表示该原始前缀到尾界，不证明独立选择、Hub真实入库或业务FIFO释放。

失败、取消或未知ACK不会自动恢复原工程。父租约保留，对应文件和审计不覆盖。

新增 `project_prepare_parent_audit_reconciliation(project_id, execution_id, expected_review_sha256, expected_certificate_sha256)`：

- 只处理父恢复已经结束、Stop/Load/Start结果明确、失败限定在审计阶段的情况。
- 验证父授权已被对应执行领取、闭合控制日志、父子审计结果一致、持久文件hash及连续序号。
- 要求同boot Running、配置和全部GOOD，并只读双次回查四个ACK字段与两个读游标；ACK boot只能为空或该审计boot，序号不能超过真实fsync范围。
- 成功后仍需现有 reconciliation inspect → `kind="lease_reconciliation"`精确授权 → execute 才归档旧租约。失败审计始终保持incomplete。
- 然后另行准备、授权、执行原工程恢复计划。不得重用旧动作或自动恢复。

若宿主中断而没有闭合父终态、Start本身未知、持久证据缺失/变化、外部消费者已推进超过持久范围或回读不稳定，拒绝核销；这些情况不属于“只有审计ACK回复丢失”的可核销范围。

## 0.6.5 验证记录

本机TLS模拟覆盖启动250条突发、sampleSeq1、错误父hash/Start引用、boot不变化、ACK丢回复，以及只读回查不超出持久序号。旧恢复/租约/独立审计回归继续通过。

全新公开MCP会话显示0.6.5/79工具；对指定完整候选 f40a214f…、source b585662a…、package d8ffa5d9…完成父恢复+审计prepare和双方inspect，父子绑定一致。[公开接收记录](../artifacts/audit-export-research/public-start-verification.json)。本轮未签发执行授权，未连接真实PLC、未下载、未恢复或改采样。真机短窗口、50事件/秒持续能力及恢复原工程的设备联调尚待安排，P06未启动。

最终全量回归：564项中563通过、1跳过。[日志](../artifacts/joint-implementation/full-tests-m12-start-final.log)。当前79工具Schema与源码一致。


## 0.6.6 零 ACK 启动失败分支

同一个 `project_prepare_parent_audit_reconciliation` 入口现支持没有历史 `observed_boot_id` 的终态，但必须同时满足：父 Stop/Load/Start 明确闭合、授权已消费、父子结果一致、ACK 次数为整数 0、无未知写入、两条持久游标为 0、原始文件哈希一致、transport 无任何审计 ACK/其他写入、无持久 ACK intent。旧审计、日志和失败结论不作任何改写。

当前只读核验 Running、配置和全部 GOOD，以及稳定非空 BootId、四 ACK 字段为空/0。两次读窗分别以 Dropped 前后夹住 ReadSeq，允许环因自淘汰前移；不要求游标一直为 0，也不把非原子读窗包装成原子快照。无法用溢出解释的读游标、外部 ACK 或 boot/config 变化均拒绝。prepare 的当前 boot/config 在 execute 再核验；这不是历史 boot 证明。

流程仍为 prepare → inspect → 精确授权 → execute，仅归档精确旧租约，不 Stop、不下载、不恢复、不宣称审计完整。原工程恢复需要另外执行恢复计划。


## 0.6.7：部分持久化零 ACK 与完整性口径

零 ACK 核销不再局限于未取得 boot、durable=0。已取得历史 boot 且保存连续部分前缀时，仍必须验证原始父终态/授权/文件、零实际 ACK 与零 intent、无未知写入，并读取相同 boot/config、Running 和全部 GOOD。旧 partial 记录不改为 complete。

源模型 NG_AuditCapture/NG_AuditAssociation 每次自淘汰同时增加 ReadSeq 与 Dropped；NG_AuditDrain 确认只推进 ReadSeq。因而在前后 Dropped 夹读窗中：零 ACK 要求 `Dropped_before <= ReadSeq <= Dropped_after`；已有 ACK 要求 `Dropped_before <= ReadSeq <= Dropped_after + durable_cursor`，同时当前 AckSeq 不得超过 durable、AckBoot 必须为空或历史 boot。两次观察之间 boot/config/ACK 必须稳定。该守卫限制可解释的累计释放量，不宣称能从读窗辨认所有外部写入者。

导出器将原始审计完整性和全局业务记账分开。连续序号、字典/generation、boot/config 围栏、fsync、AuditDropped/AssociationDropped、EvidenceComplete 和 CounterOverflow 仍决定能否 ACK；AccountingComplete、RestartLossUnknown、DetailTruncated 原样保存，并在成功结果分别报告 globalAccountingComplete、restartLossUnknown、gapDetailTruncated。审计完整不表示全局业务历史完整，不修改 PLC 标志或业务 FIFO。

冻结真机诊断：tests/fixtures/boot67-local-diagnostics.json，附原事件文件 SHA256。测试仅将诊断身份适配到本地 TLS 样例的 boot，业务状态不改写。
