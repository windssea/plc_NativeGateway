# ACI 公共 API 全量矩阵（本机 2026.0.4）

由静态 Cecil 元数据及 CIL 调用边生成；没有加载或执行被分析程序集。接口继承的 IReadOnlyList/IEnumerable 成员保留在 JSON 的 interfaces 中。下面列出公共类型的全部公开声明方法（包括属性访问器/事件 add/remove），并关联直接可解析的客户端 gRPC 调用。

统计：{'public_types': 85, 'public_interfaces': 56, 'public_enums': 19, 'public_methods': 222, 'interface_methods': 201, 'public_events': 4, 'descriptors': 26, 'services': 23, 'rpcs': 193, 'server_streaming': 4, 'client_streaming': 0}。

机器清单：[public-client-api-map.json](../../artifacts/aci-analysis/public-client-api-map.json)。

## Ade.ApplicationControl.ApplicationControlVersionAttribute `0x02000004`

基类：`System.Attribute`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000001` | `System.Void Ade.ApplicationControl.ApplicationControlVersionAttribute::.ctor(System.String)` | 本地/继承/辅助路径，见 JSON |
| `0x06000002` | `System.String Ade.ApplicationControl.ApplicationControlVersionAttribute::get_Version()` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.ApplicationControlCommunicationException `0x02000005`

基类：`Ade.ApplicationControl.ApplicationControlException`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000004` | `System.Void Ade.ApplicationControl.ApplicationControlCommunicationException::.ctor()` | 本地/继承/辅助路径，见 JSON |
| `0x06000005` | `System.Void Ade.ApplicationControl.ApplicationControlCommunicationException::.ctor(System.String)` | 本地/继承/辅助路径，见 JSON |
| `0x06000006` | `System.Void Ade.ApplicationControl.ApplicationControlCommunicationException::.ctor(System.String,System.Exception)` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.ApplicationControlException `0x02000006`

基类：`System.Exception`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000008` | `System.Void Ade.ApplicationControl.ApplicationControlException::.ctor()` | 本地/继承/辅助路径，见 JSON |
| `0x06000009` | `System.Void Ade.ApplicationControl.ApplicationControlException::.ctor(System.String)` | 本地/继承/辅助路径，见 JSON |
| `0x0600000a` | `System.Void Ade.ApplicationControl.ApplicationControlException::.ctor(System.String,System.Exception)` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.ApplicationControlServerException `0x02000007`

基类：`Ade.ApplicationControl.ApplicationControlException`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600000c` | `System.Void Ade.ApplicationControl.ApplicationControlServerException::.ctor()` | 本地/继承/辅助路径，见 JSON |
| `0x0600000d` | `System.Void Ade.ApplicationControl.ApplicationControlServerException::.ctor(System.String)` | 本地/继承/辅助路径，见 JSON |
| `0x0600000e` | `System.Void Ade.ApplicationControl.ApplicationControlServerException::.ctor(System.String,System.Exception)` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.ExceptionHelper `0x02000008`

基类：`System.Object`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000010` | `System.String Ade.ApplicationControl.ExceptionHelper::ComposeExceptionMessage(System.Exception)` | 本地/继承/辅助路径，见 JSON |
| `0x06000011` | `System.String Ade.ApplicationControl.ExceptionHelper::ComposeSingleLineExceptionMessage(System.Exception)` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.ApplicationExtensions `0x02000009`

基类：`System.Object`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000015` | `System.Threading.Tasks.Task`1<Ade.ApplicationControl.IProject> Ade.ApplicationControl.ApplicationExtensions::OpenProjectAsync(Ade.ApplicationControl.IApplication,System.String)` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.OnlineChannelExtensions `0x0200000a`

基类：`System.Object`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000016` | `System.Threading.Tasks.Task`1<Ade.ApplicationControl.Iec.DownloadResult> Ade.ApplicationControl.OnlineChannelExtensions::DownloadAsync(Ade.ApplicationControl.Iec.IOnlineChannel,Ade.ApplicationControl.Iec.DownloadTypes)` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.ProjectExtensions `0x0200000c`

基类：`System.Object`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600001b` | `System.Threading.Tasks.Task`1<Ade.ApplicationControl.CompileResult> Ade.ApplicationControl.ProjectExtensions::CompileAsync(Ade.ApplicationControl.IProject,Ade.ApplicationControl.CompileType,System.Collections.Generic.IList`1<Ade.ApplicationControl.IMessage>)` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.CompileEventArgs `0x0200000d`

基类：`System.EventArgs`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600001d` | `System.Void Ade.ApplicationControl.CompileEventArgs::.ctor(Ade.ApplicationControl.CompileResult,System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.IMessage>)` | 本地/继承/辅助路径，见 JSON |
| `0x0600001e` | `Ade.ApplicationControl.CompileResult Ade.ApplicationControl.CompileEventArgs::get_Result()` | 本地/继承/辅助路径，见 JSON |
| `0x06000020` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IMessage> Ade.ApplicationControl.CompileEventArgs::get_Messages()` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.CompileResult `0x0200000e`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Succeeded` | 1 |
| `Failed` | 2 |
| `Canceled` | 3 |

## Ade.ApplicationControl.DomainKind `0x0200000f`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Iec` | 1 |
| `Network` | 2 |
| `Common` | 3 |

## Ade.ApplicationControl.IApplication `0x02000010`

基类：``；接口：``。

事件：`ProjectOpened: System.EventHandler`1<System.EventArgs>`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000021` | `Ade.ApplicationControl.IProject Ade.ApplicationControl.IApplication::get_Project()` | `ProjectService.GetActiveProject` |
| `0x06000022` | `Ade.ApplicationControl.IApplicationCompilerOptions Ade.ApplicationControl.IApplication::get_CompilerOptions()` | `ApplicationService.GetApplicationCompilerOptions` |
| `0x06000023` | `System.Boolean Ade.ApplicationControl.IApplication::get_IsProjectOpen()` | `ProjectService.IsProjectOpen` |
| `0x06000024` | `Ade.ApplicationControl.IProject Ade.ApplicationControl.IApplication::OpenProject(System.String)` | `ProjectService.OpenProject` |
| `0x06000025` | `Ade.ApplicationControl.IProject Ade.ApplicationControl.IApplication::NewProject()` | `ProjectService.NewProject` |
| `0x06000026` | `System.Void Ade.ApplicationControl.IApplication::add_ProjectOpened(System.EventHandler`1<System.EventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x06000027` | `System.Void Ade.ApplicationControl.IApplication::remove_ProjectOpened(System.EventHandler`1<System.EventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x06000028` | `System.String Ade.ApplicationControl.IApplication::get_BuildPath()` | `ProjectService.GetBuildPath` |
| `0x06000029` | `System.Void Ade.ApplicationControl.IApplication::Shutdown()` | `ApplicationControlService.GetProcessId`, `ApplicationControlService.Shutdown` |

## Ade.ApplicationControl.IApplicationCompilerOptions `0x02000011`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600002a` | `System.Boolean Ade.ApplicationControl.IApplicationCompilerOptions::get_AllowExtendedIdentifier()` | `ApplicationService.GetCompilerOptionAllowExtendedIdentifier` |
| `0x0600002b` | `System.Void Ade.ApplicationControl.IApplicationCompilerOptions::set_AllowExtendedIdentifier(System.Boolean)` | `ApplicationService.SetCompilerOptionAllowExtendedIdentifier` |
| `0x0600002c` | `System.Boolean Ade.ApplicationControl.IApplicationCompilerOptions::get_AllowWritingVarInputInFunction()` | `ApplicationService.GetCompilerOptionAllowWritingVarInputInFunction` |
| `0x0600002d` | `System.Void Ade.ApplicationControl.IApplicationCompilerOptions::set_AllowWritingVarInputInFunction(System.Boolean)` | `ApplicationService.SetCompilerOptionAllowWritingVarInputInFunction` |
| `0x0600002e` | `System.Boolean Ade.ApplicationControl.IApplicationCompilerOptions::get_UseDynamicSfcInfoArrays()` | `ApplicationService.GetCompilerOptionUseDynamicSfcInfoArrays` |
| `0x0600002f` | `System.Void Ade.ApplicationControl.IApplicationCompilerOptions::set_UseDynamicSfcInfoArrays(System.Boolean)` | `ApplicationService.SetCompilerOptionUseDynamicSfcInfoArrays` |

## Ade.ApplicationControl.IApplicationControlManager `0x02000012`

基类：``；接口：`System.IDisposable`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000030` | `Ade.ApplicationControl.IApplication Ade.ApplicationControl.IApplicationControlManager::get_Application()` | 本地/继承/辅助路径，见 JSON |
| `0x06000031` | `System.Boolean Ade.ApplicationControl.IApplicationControlManager::get_IsAvailable()` | 本地/继承/辅助路径，见 JSON |
| `0x06000032` | `Ade.ApplicationControl.IApplicationInfo Ade.ApplicationControl.IApplicationControlManager::get_ApplicationInfo()` | 本地/继承/辅助路径，见 JSON |
| `0x06000033` | `Ade.ApplicationControl.ApplicationControlStates Ade.ApplicationControl.IApplicationControlManager::get_States()` | `ApplicationControlService.GetStates` |

## Ade.ApplicationControl.ApplicationControlStates `0x02000013`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Okay` | 0 |
| `NotAvailableInUserInterfaceMode` | 1 |
| `NoLicenseAvailable` | 2 |
| `NotEnabledInOptions` | 4 |
| `AlreadyInUseByAnotherInstance` | 8 |

## Ade.ApplicationControl.IApplicationInfo `0x02000014`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000034` | `System.String Ade.ApplicationControl.IApplicationInfo::get_ProductName()` | `ApplicationControlService.GetProductName` |
| `0x06000035` | `System.String Ade.ApplicationControl.IApplicationInfo::get_ProductVersion()` | `ApplicationControlService.GetProductVersion` |
| `0x06000036` | `System.String Ade.ApplicationControl.IApplicationInfo::get_ProductBuild()` | `ApplicationControlService.GetProductBuild` |
| `0x06000037` | `System.String Ade.ApplicationControl.IApplicationInfo::get_ExecutablePath()` | `ApplicationControlService.GetExecutablePath` |
| `0x06000038` | `System.String Ade.ApplicationControl.IApplicationInfo::get_ApplicationControlVersion()` | `ApplicationControlService.GetApplicationControlVersion` |
| `0x06000039` | `System.Int32 Ade.ApplicationControl.IApplicationInfo::get_ProcessId()` | `ApplicationControlService.GetProcessId` |

## Ade.ApplicationControl.ICommonComponentCategory `0x02000015`

基类：``；接口：`Ade.ApplicationControl.IComponentCategory`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600003a` | `Ade.ApplicationControl.IControllerTypeCollection Ade.ApplicationControl.ICommonComponentCategory::get_ControllerTypes()` | `CommonComponentCategoryService.GetControllerTypes` |

## Ade.ApplicationControl.IComponentCategory `0x02000016`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600003b` | `Ade.ApplicationControl.DomainKind Ade.ApplicationControl.IComponentCategory::get_Kind()` | `ProjectService.GetComponentCategoryKind` |

## Ade.ApplicationControl.IComponentCategoryCollection `0x02000017`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.IComponentCategory>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.IComponentCategory>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IComponentCategory>`。

## Ade.ApplicationControl.IController `0x02000018`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600003c` | `Ade.ApplicationControl.IControllerPartCollection Ade.ApplicationControl.IController::get_ControllerParts()` | `ControllerService.GetControllerParts` |
| `0x0600003d` | `System.String Ade.ApplicationControl.IController::get_Name()` | `ControllerService.GetName` |
| `0x0600003e` | `System.String Ade.ApplicationControl.IController::get_TypeName()` | `ControllerService.GetTypeName` |
| `0x0600003f` | `System.Boolean Ade.ApplicationControl.IController::ExportDataList(System.String,Ade.ApplicationControl.ExportDataListViewType)` | `ControllerService.ExportDataList` |
| `0x06000040` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IMessage> Ade.ApplicationControl.IController::ImportDataList(System.String)` | `ControllerService.ImportDataList` |
| `0x06000041` | `System.Void Ade.ApplicationControl.IController::Replace(Ade.ApplicationControl.IControllerType)` | `ControllerService.Replace` |

## Ade.ApplicationControl.ExportDataListViewType `0x02000019`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `GlobalDataList` | 1 |
| `PlcDataList` | 2 |
| `SafetyPlcDataList` | 3 |
| `PortList` | 4 |

## Ade.ApplicationControl.IControllerCollection `0x0200001a`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.IController>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.IController>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IController>`。

## Ade.ApplicationControl.IControllerPart `0x0200001b`

基类：``；接口：`Ade.ApplicationControl.IInstance`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000042` | `System.String Ade.ApplicationControl.IControllerPart::get_DisplayName()` | `ControllerPartService.GetDisplayName` |
| `0x06000043` | `Ade.ApplicationControl.DomainKind Ade.ApplicationControl.IControllerPart::get_Kind()` | `ControllerPartService.GetKind` |
| `0x06000044` | `System.String Ade.ApplicationControl.IControllerPart::get_TypeName()` | `ControllerPartService.GetTypeName` |

## Ade.ApplicationControl.IControllerPartCollection `0x0200001c`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.IControllerPart>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.IControllerPart>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IControllerPart>`。

## Ade.ApplicationControl.IControllerType `0x0200001d`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000045` | `System.String Ade.ApplicationControl.IControllerType::get_ArticleNumber()` | `ControllerTypeService.GetArticleNumber` |
| `0x06000046` | `System.String Ade.ApplicationControl.IControllerType::get_ProductFamily()` | `ControllerTypeService.GetProductFamily` |
| `0x06000047` | `System.String Ade.ApplicationControl.IControllerType::get_ProductName()` | `ControllerTypeService.GetProductName` |
| `0x06000048` | `System.String Ade.ApplicationControl.IControllerType::get_Vendor()` | `ControllerTypeService.GetVendor` |
| `0x06000049` | `System.String Ade.ApplicationControl.IControllerType::get_Version()` | `ControllerTypeService.GetVersion` |

## Ade.ApplicationControl.IControllerTypeCollection `0x0200001e`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.IControllerType>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.IControllerType>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IControllerType>`。

## Ade.ApplicationControl.IInstance `0x0200001f`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600004a` | `System.String Ade.ApplicationControl.IInstance::get_Name()` | `ControllerPartService.GetName`, `FunctionBlockInstanceService.GetName`, `ProgramInstanceService.GetName` |

## Ade.ApplicationControl.ILibrary `0x02000020`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600004b` | `System.String Ade.ApplicationControl.ILibrary::get_Name()` | `LibraryService.GetLibraryName` |
| `0x0600004c` | `System.String Ade.ApplicationControl.ILibrary::get_Path()` | `LibraryService.GetLibraryPath` |
| `0x0600004d` | `Ade.ApplicationControl.LibraryType Ade.ApplicationControl.ILibrary::get_LibraryType()` | `LibraryService.GetLibraryType` |
| `0x0600004e` | `Ade.ApplicationControl.LibraryLoadStatus Ade.ApplicationControl.ILibrary::get_LoadStatus()` | `LibraryService.GetLibraryLoadStatus` |
| `0x0600004f` | `Ade.ApplicationControl.IComponentCategoryCollection Ade.ApplicationControl.ILibrary::get_ComponentCategories()` | `LibraryService.GetLibraryComponentCategories` |
| `0x06000050` | `System.Void Ade.ApplicationControl.ILibrary::Accept()` | `LibraryService.AcceptLibrary` |
| `0x06000051` | `System.Boolean Ade.ApplicationControl.ILibrary::Remove()` | `LibraryService.RemoveLibrary` |
| `0x06000052` | `System.Void Ade.ApplicationControl.ILibrary::Replace(System.String)` | `LibraryService.ReplaceLibrary` |

## Ade.ApplicationControl.ILibraryCollection `0x02000021`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.ILibrary>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.ILibrary>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.ILibrary>`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000053` | `Ade.ApplicationControl.ILibrary Ade.ApplicationControl.ILibraryCollection::Add(System.String,Ade.ApplicationControl.LibraryType)` | `LibraryService.AddLibrary` |

## Ade.ApplicationControl.IMessage `0x02000022`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000054` | `Ade.ApplicationControl.MessageType Ade.ApplicationControl.IMessage::get_MessageType()` | 本地/继承/辅助路径，见 JSON |
| `0x06000055` | `System.String Ade.ApplicationControl.IMessage::get_Text()` | 本地/继承/辅助路径，见 JSON |
| `0x06000056` | `System.String Ade.ApplicationControl.IMessage::get_TypeId()` | 本地/继承/辅助路径，见 JSON |
| `0x06000057` | `System.Guid Ade.ApplicationControl.IMessage::get_Id()` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.MessageType `0x02000023`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `None` | 0 |
| `Information` | 1 |
| `Warning` | 2 |
| `Error` | 3 |

## Ade.ApplicationControl.IProject `0x02000024`

基类：``；接口：``。

事件：`Closed: System.EventHandler`1<System.EventArgs>`, `CompileFinished: System.EventHandler`1<Ade.ApplicationControl.CompileEventArgs>`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000058` | `Ade.ApplicationControl.IControllerCollection Ade.ApplicationControl.IProject::get_Controllers()` | `ProjectService.GetControllers` |
| `0x06000059` | `Ade.ApplicationControl.ILibraryCollection Ade.ApplicationControl.IProject::get_Libraries()` | `LibraryService.GetLibraries` |
| `0x0600005a` | `Ade.ApplicationControl.IComponentCategoryCollection Ade.ApplicationControl.IProject::get_ComponentCategories()` | `ProjectService.GetComponentCategories` |
| `0x0600005b` | `System.Void Ade.ApplicationControl.IProject::Close()` | `ProjectService.CloseProject` |
| `0x0600005c` | `System.Void Ade.ApplicationControl.IProject::add_Closed(System.EventHandler`1<System.EventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x0600005d` | `System.Void Ade.ApplicationControl.IProject::remove_Closed(System.EventHandler`1<System.EventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x0600005e` | `System.Void Ade.ApplicationControl.IProject::Save()` | `ProjectService.SaveProject` |
| `0x0600005f` | `System.Boolean Ade.ApplicationControl.IProject::SaveAs(System.String,System.Boolean)` | `ProjectService.SaveProjectAs` |
| `0x06000060` | `System.Boolean Ade.ApplicationControl.IProject::SaveAs(System.String,System.Boolean,Ade.ApplicationControl.ProjectType)` | `ProjectService.SaveProjectAsWithProjectType` |
| `0x06000061` | `System.Void Ade.ApplicationControl.IProject::Compile(Ade.ApplicationControl.CompileType)` | `ProjectService.CompileProject` |
| `0x06000062` | `System.Void Ade.ApplicationControl.IProject::add_CompileFinished(System.EventHandler`1<Ade.ApplicationControl.CompileEventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x06000063` | `System.Void Ade.ApplicationControl.IProject::remove_CompileFinished(System.EventHandler`1<Ade.ApplicationControl.CompileEventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x06000064` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IMessage> Ade.ApplicationControl.IProject::ImportProgramOrganizationUnits(System.String,System.String[])` | `ProjectService.ImportProgramOrganizationUnits` |
| `0x06000065` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IMessage> Ade.ApplicationControl.IProject::ImportDataTypeWorksheets(System.String,System.String[])` | `ProjectService.ImportDataTypeWorksheets` |
| `0x06000066` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IMessage> Ade.ApplicationControl.IProject::ImportAutomationML(System.String,Ade.ApplicationControl.ImportAutomationMLStrategy)` | `ProjectService.ImportAutomationML` |
| `0x06000067` | `System.Boolean Ade.ApplicationControl.IProject::ExportAutomationML(System.String)` | `ProjectService.ExportAutomationML` |
| `0x06000068` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IMessage> Ade.ApplicationControl.IProject::ImportIec61131_10(System.String)` | `ProjectService.ImportIec61131_10` |
| `0x06000069` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IMessage> Ade.ApplicationControl.IProject::ExportIec61131_10(System.String)` | `ProjectService.ExportIec61131_10` |

## Ade.ApplicationControl.CompileType `0x02000025`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Build` | 1 |
| `Rebuild` | 2 |
| `Prepare` | 3 |

## Ade.ApplicationControl.ProjectType `0x02000026`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Compressed` | 1 |
| `Uncompressed` | 2 |

## Ade.ApplicationControl.ImportAutomationMLStrategy `0x02000027`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `None` | 0 |
| `FirstTypeDefinition` | 1 |
| `LastTypeDefinition` | 2 |
| `NewestRevision` | 4 |
| `OldestRevision` | 8 |

## Ade.ApplicationControl.IProperty `0x02000028`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600006a` | `System.String Ade.ApplicationControl.IProperty::get_Name()` | `PropertyService.GetPropertyName` |
| `0x0600006b` | `System.Object Ade.ApplicationControl.IProperty::get_Value()` | `PropertyService.GetPropertyType`, `PropertyService.GetPropertyValue` |

## Ade.ApplicationControl.IPropertyDictionary `0x02000029`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600006c` | `System.Int32 Ade.ApplicationControl.IPropertyDictionary::get_Count()` | `PropertyService.GetCount` |
| `0x0600006d` | `System.Collections.Generic.IReadOnlyCollection`1<System.String> Ade.ApplicationControl.IPropertyDictionary::get_Names()` | `PropertyService.GetNames` |
| `0x0600006e` | `System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.IProperty> Ade.ApplicationControl.IPropertyDictionary::get_Properties()` | `PropertyService.GetProperties` |
| `0x0600006f` | `Ade.ApplicationControl.IProperty Ade.ApplicationControl.IPropertyDictionary::get_Item(System.String)` | `PropertyService.GetProperty` |
| `0x06000070` | `System.Boolean Ade.ApplicationControl.IPropertyDictionary::get_IsReadOnly()` | `PropertyService.IsDictionaryReadOnly` |
| `0x06000071` | `Ade.ApplicationControl.IProperty Ade.ApplicationControl.IPropertyDictionary::Add(System.String,System.Object)` | `PropertyService.AddProperty` |
| `0x06000072` | `System.Boolean Ade.ApplicationControl.IPropertyDictionary::Contains(System.String)` | `PropertyService.ContainsProperty` |
| `0x06000073` | `System.Boolean Ade.ApplicationControl.IPropertyDictionary::Remove(System.String)` | `PropertyService.RemoveProperty` |
| `0x06000074` | `System.Void Ade.ApplicationControl.IPropertyDictionary::Clear()` | `PropertyService.ClearDictionary` |
| `0x06000075` | `System.Boolean Ade.ApplicationControl.IPropertyDictionary::TryGetProperty(System.String,Ade.ApplicationControl.IProperty&)` | `PropertyService.GetProperty` |

## Ade.ApplicationControl.LibraryLoadStatus `0x0200002a`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Valid` | 1 |
| `Invalid` | 2 |
| `Tampered` | 3 |
| `Corrupted` | 4 |
| `AmbiguousIds` | 5 |
| `AmbiguousNames` | 6 |
| `NotExist` | 7 |
| `IdMismatch` | 8 |
| `SignatureMismatch` | 9 |
| `UnableToConvert` | 10 |
| `MissingComponent` | 11 |
| `ApplicationComponentBreach` | 12 |
| `CannotVerifyLibrary` | 13 |
| `IncompatibleVersion` | 14 |

## Ade.ApplicationControl.LibraryType `0x0200002b`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `System` | 1 |
| `User` | 2 |

## Ade.ApplicationControl.Network.DeviceKind `0x0200002c`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Device` | 1 |
| `Module` | 2 |
| `Submodule` | 3 |

## Ade.ApplicationControl.Network.IDeviceParameter `0x0200002d`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000076` | `System.String Ade.ApplicationControl.Network.IDeviceParameter::get_Id()` | `DeviceParameterService.GetParameterId` |
| `0x06000077` | `System.String Ade.ApplicationControl.Network.IDeviceParameter::get_Label()` | `DeviceParameterService.GetParameterLabel` |
| `0x06000078` | `System.String Ade.ApplicationControl.Network.IDeviceParameter::get_Value()` | `DeviceParameterService.GetParameterValue` |
| `0x06000079` | `System.Void Ade.ApplicationControl.Network.IDeviceParameter::set_Value(System.String)` | `DeviceParameterService.SetParameterValue` |
| `0x0600007a` | `System.String Ade.ApplicationControl.Network.IDeviceParameter::get_Help()` | `DeviceParameterService.GetParameterHelp` |
| `0x0600007b` | `System.Boolean Ade.ApplicationControl.Network.IDeviceParameter::get_IsReadOnly()` | `DeviceParameterService.IsReadOnly` |

## Ade.ApplicationControl.Network.ISelectableDeviceParameter `0x0200002e`

基类：``；接口：`Ade.ApplicationControl.Network.IDeviceParameter`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600007c` | `Ade.ApplicationControl.Network.ISelectableDeviceParameterOptionCollection Ade.ApplicationControl.Network.ISelectableDeviceParameter::get_Options()` | `DeviceParameterService.GetOptions` |

## Ade.ApplicationControl.Network.ISelectableDeviceParameterOption `0x0200002f`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600007d` | `System.String Ade.ApplicationControl.Network.ISelectableDeviceParameterOption::get_Label()` | `DeviceParameterService.GetOptionLabel` |
| `0x0600007e` | `System.String Ade.ApplicationControl.Network.ISelectableDeviceParameterOption::get_Value()` | `DeviceParameterService.GetOptionValue` |

## Ade.ApplicationControl.Network.ISelectableDeviceParameterOptionCollection `0x02000030`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Network.ISelectableDeviceParameterOption>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Network.ISelectableDeviceParameterOption>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Network.ISelectableDeviceParameterOption>`。

## Ade.ApplicationControl.Network.IDeviceSetting `0x02000031`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600007f` | `System.String Ade.ApplicationControl.Network.IDeviceSetting::get_Id()` | `DeviceSettingService.GetSettingId` |
| `0x06000080` | `System.String Ade.ApplicationControl.Network.IDeviceSetting::get_Label()` | `DeviceSettingService.GetSettingLabel` |
| `0x06000081` | `System.String Ade.ApplicationControl.Network.IDeviceSetting::get_Value()` | `DeviceSettingService.GetSettingValue` |
| `0x06000082` | `System.Void Ade.ApplicationControl.Network.IDeviceSetting::set_Value(System.String)` | `DeviceSettingService.SetSettingValue` |
| `0x06000083` | `System.String Ade.ApplicationControl.Network.IDeviceSetting::get_Help()` | `DeviceSettingService.GetSettingHelp` |
| `0x06000084` | `System.Boolean Ade.ApplicationControl.Network.IDeviceSetting::get_IsReadOnly()` | `DeviceSettingService.IsReadOnly` |

## Ade.ApplicationControl.Network.ISelectableDeviceSetting `0x02000032`

基类：``；接口：`Ade.ApplicationControl.Network.IDeviceSetting`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000085` | `Ade.ApplicationControl.Network.ISelectableDeviceSettingOptionCollection Ade.ApplicationControl.Network.ISelectableDeviceSetting::get_Options()` | `DeviceSettingService.GetOptions` |

## Ade.ApplicationControl.Network.ISelectableDeviceSettingOption `0x02000033`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000086` | `System.String Ade.ApplicationControl.Network.ISelectableDeviceSettingOption::get_Label()` | `DeviceSettingService.GetOptionLabel` |
| `0x06000087` | `System.String Ade.ApplicationControl.Network.ISelectableDeviceSettingOption::get_Value()` | `DeviceSettingService.GetOptionValue` |

## Ade.ApplicationControl.Network.ISelectableDeviceSettingOptionCollection `0x02000034`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Network.ISelectableDeviceSettingOption>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Network.ISelectableDeviceSettingOption>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Network.ISelectableDeviceSettingOption>`。

## Ade.ApplicationControl.Network.IDeviceInstance `0x02000035`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000088` | `Ade.ApplicationControl.Network.IDeviceInstanceCollection Ade.ApplicationControl.Network.IDeviceInstance::get_DeviceInstances()` | `DeviceInstanceService.GetDeviceInstances` |
| `0x06000089` | `Ade.ApplicationControl.Network.DeviceKind Ade.ApplicationControl.Network.IDeviceInstance::get_Kind()` | `DeviceInstanceService.GetKind` |
| `0x0600008a` | `System.String Ade.ApplicationControl.Network.IDeviceInstance::get_Name()` | `DeviceInstanceService.GetName` |
| `0x0600008b` | `Ade.ApplicationControl.IPropertyDictionary Ade.ApplicationControl.Network.IDeviceInstance::get_Settings()` | `DeviceInstanceService.GetSettings` |
| `0x0600008c` | `Ade.ApplicationControl.IPropertyDictionary Ade.ApplicationControl.Network.IDeviceInstance::get_Parameters()` | `DeviceInstanceService.GetParameters` |
| `0x0600008d` | `System.String Ade.ApplicationControl.Network.IDeviceInstance::get_TypeName()` | `DeviceInstanceService.GetTypeName` |

## Ade.ApplicationControl.Network.IDeviceInstanceCollection `0x02000036`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Network.IDeviceInstance>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Network.IDeviceInstance>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Network.IDeviceInstance>`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600008e` | `System.Int32 Ade.ApplicationControl.Network.IDeviceInstanceCollection::GetNextFreePosition()` | `DeviceInstanceService.GetNextFreePosition` |
| `0x0600008f` | `Ade.ApplicationControl.Network.IDeviceTypeCollection Ade.ApplicationControl.Network.IDeviceInstanceCollection::GetDeviceTypes(System.Int32)` | `DeviceInstanceService.GetDeviceTypes` |
| `0x06000090` | `Ade.ApplicationControl.Network.IDeviceInstance Ade.ApplicationControl.Network.IDeviceInstanceCollection::Create(Ade.ApplicationControl.Network.IDeviceType)` | `DeviceInstanceService.Create` |
| `0x06000091` | `System.Void Ade.ApplicationControl.Network.IDeviceInstanceCollection::Insert(Ade.ApplicationControl.Network.IDeviceInstance,System.Int32)` | `DeviceInstanceService.Insert` |
| `0x06000092` | `System.Void Ade.ApplicationControl.Network.IDeviceInstanceCollection::Delete(Ade.ApplicationControl.Network.IDeviceInstance)` | `DeviceInstanceService.Delete` |

## Ade.ApplicationControl.Network.IDeviceType `0x02000037`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000093` | `System.String Ade.ApplicationControl.Network.IDeviceType::get_Name()` | `DeviceTypeService.GetName` |
| `0x06000094` | `Ade.ApplicationControl.Network.NetworkProtocol Ade.ApplicationControl.Network.IDeviceType::get_Protocol()` | `DeviceTypeService.GetProtocol` |

## Ade.ApplicationControl.Network.IDeviceTypeCollection `0x02000038`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Network.IDeviceType>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Network.IDeviceType>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Network.IDeviceType>`。

## Ade.ApplicationControl.Network.INetworkComponentCategory `0x02000039`

基类：``；接口：`Ade.ApplicationControl.IComponentCategory`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000095` | `Ade.ApplicationControl.Network.IDeviceTypeCollection Ade.ApplicationControl.Network.INetworkComponentCategory::get_DeviceTypes()` | `NetworkComponentCategoryService.GetDeviceTypes` |

## Ade.ApplicationControl.Network.INetworkControllerPart `0x0200003a`

基类：``；接口：`Ade.ApplicationControl.IControllerPart, Ade.ApplicationControl.IInstance`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x06000096` | `Ade.ApplicationControl.Network.IDeviceInstanceCollection Ade.ApplicationControl.Network.INetworkControllerPart::get_DeviceInstances()` | `NetworkControllerPartService.GetDeviceInstances` |
| `0x06000097` | `Ade.ApplicationControl.IPropertyDictionary Ade.ApplicationControl.Network.INetworkControllerPart::get_Settings()` | `NetworkControllerPartService.GetSettings` |
| `0x06000098` | `Ade.ApplicationControl.IPropertyDictionary Ade.ApplicationControl.Network.INetworkControllerPart::get_Parameters()` | `NetworkControllerPartService.GetParameters` |
| `0x06000099` | `Ade.ApplicationControl.Network.NetworkProtocol Ade.ApplicationControl.Network.INetworkControllerPart::get_Protocol()` | `NetworkControllerPartService.GetProtocol` |

## Ade.ApplicationControl.Network.NetworkProtocol `0x0200003b`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Profinet` | 1 |
| `Axioline` | 2 |
| `Interbus` | 3 |

## Ade.ApplicationControl.Iec.IConnectionEndpoint `0x0200003c`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600009a` | `Ade.ApplicationControl.Iec.ConnectionEndpointKind Ade.ApplicationControl.Iec.IConnectionEndpoint::get_Kind()` | `OnlineChannelService.GetConnectionEndpointKind` |
| `0x0600009b` | `System.String Ade.ApplicationControl.Iec.IConnectionEndpoint::get_Name()` | `OnlineChannelService.GetConnectionEndpointName` |

## Ade.ApplicationControl.Iec.ConnectionEndpointKind `0x0200003d`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Simulation` | 1 |
| `TcpIP` | 2 |

## Ade.ApplicationControl.Iec.ISimulationConnectionEndpoint `0x0200003e`

基类：``；接口：`Ade.ApplicationControl.Iec.IConnectionEndpoint`。

## Ade.ApplicationControl.Iec.ITcpIPConnectionEndpoint `0x0200003f`

基类：``；接口：`Ade.ApplicationControl.Iec.IConnectionEndpoint`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x0600009c` | `System.Net.IPAddress Ade.ApplicationControl.Iec.ITcpIPConnectionEndpoint::get_IPAddress()` | `OnlineChannelService.GetConnectionEndpointIPAddress` |
| `0x0600009d` | `System.Void Ade.ApplicationControl.Iec.ITcpIPConnectionEndpoint::set_IPAddress(System.Net.IPAddress)` | `OnlineChannelService.SetConnectionEndpointIPAddress` |
| `0x0600009e` | `System.Net.IPAddress Ade.ApplicationControl.Iec.ITcpIPConnectionEndpoint::get_SubnetMask()` | `OnlineChannelService.GetConnectionEndpointSubnetMask` |
| `0x0600009f` | `System.Void Ade.ApplicationControl.Iec.ITcpIPConnectionEndpoint::set_SubnetMask(System.Net.IPAddress)` | `OnlineChannelService.SetConnectionEndpointSubnetMask` |
| `0x060000a0` | `System.Net.IPAddress Ade.ApplicationControl.Iec.ITcpIPConnectionEndpoint::get_Gateway()` | `OnlineChannelService.GetConnectionEndpointGateway` |
| `0x060000a1` | `System.Void Ade.ApplicationControl.Iec.ITcpIPConnectionEndpoint::set_Gateway(System.Net.IPAddress)` | `OnlineChannelService.SetConnectionEndpointGateway` |

## Ade.ApplicationControl.Iec.DownloadEventArgs `0x02000040`

基类：`System.EventArgs`；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000a2` | `System.Void Ade.ApplicationControl.Iec.DownloadEventArgs::.ctor(Ade.ApplicationControl.Iec.DownloadResult)` | 本地/继承/辅助路径，见 JSON |
| `0x060000a3` | `Ade.ApplicationControl.Iec.DownloadResult Ade.ApplicationControl.Iec.DownloadEventArgs::get_Result()` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.Iec.DownloadResult `0x02000041`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Succeeded` | 1 |
| `Failed` | 2 |
| `Canceled` | 3 |

## Ade.ApplicationControl.Iec.IConnectionEndpointCollection `0x02000042`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Iec.IConnectionEndpoint>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Iec.IConnectionEndpoint>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Iec.IConnectionEndpoint>`。

## Ade.ApplicationControl.Iec.IFunctionBlockInstance `0x02000043`

基类：``；接口：`Ade.ApplicationControl.IInstance`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000a5` | `System.String Ade.ApplicationControl.Iec.IFunctionBlockInstance::get_FunctionBlockType()` | `FunctionBlockInstanceService.GetFunctionBlockType` |
| `0x060000a6` | `System.String Ade.ApplicationControl.Iec.IFunctionBlockInstance::get_Comment()` | `FunctionBlockInstanceService.GetComment` |
| `0x060000a7` | `Ade.ApplicationControl.Iec.IVariableCollection Ade.ApplicationControl.Iec.IFunctionBlockInstance::get_Variables()` | `FunctionBlockInstanceService.GetVariables` |
| `0x060000a8` | `Ade.ApplicationControl.Iec.IFunctionBlockInstanceCollection Ade.ApplicationControl.Iec.IFunctionBlockInstance::get_FunctionBlockInstances()` | `FunctionBlockInstanceService.GetFunctionBlockInstances` |
| `0x060000a9` | `Ade.ApplicationControl.IInstance Ade.ApplicationControl.Iec.IFunctionBlockInstance::get_ParentInstance()` | `FunctionBlockInstanceService.GetParentInstanceId` |

## Ade.ApplicationControl.Iec.IFunctionBlockInstanceCollection `0x02000044`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Iec.IFunctionBlockInstance>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Iec.IFunctionBlockInstance>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Iec.IFunctionBlockInstance>`。

## Ade.ApplicationControl.Iec.IIecComponentCategory `0x02000045`

基类：``；接口：`Ade.ApplicationControl.IComponentCategory`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000aa` | `Ade.ApplicationControl.Iec.IProgramOrganizationUnitCollection Ade.ApplicationControl.Iec.IIecComponentCategory::get_ProgramOrganizationUnits()` | `IecTypeService.GetProgramOrganizationUnits` |

## Ade.ApplicationControl.Iec.IIecControllerPart `0x02000046`

基类：``；接口：`Ade.ApplicationControl.IControllerPart, Ade.ApplicationControl.IInstance`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000ab` | `System.Boolean Ade.ApplicationControl.Iec.IIecControllerPart::get_IsSafety()` | `IecControllerPartService.IsSafety` |
| `0x060000ac` | `Ade.ApplicationControl.Iec.IVariableCollection Ade.ApplicationControl.Iec.IIecControllerPart::get_Variables()` | `IecControllerPartService.GetVariables` |
| `0x060000ad` | `Ade.ApplicationControl.Iec.IOnlineChannel Ade.ApplicationControl.Iec.IIecControllerPart::get_OnlineChannel()` | `IecControllerPartService.GetOnlineChannel` |
| `0x060000ae` | `Ade.ApplicationControl.Iec.ITaskCollection Ade.ApplicationControl.Iec.IIecControllerPart::get_Tasks()` | `IecControllerPartService.GetTasks` |

## Ade.ApplicationControl.Iec.IIecType `0x02000047`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000af` | `Ade.ApplicationControl.Iec.IecTypeKind Ade.ApplicationControl.Iec.IIecType::get_Kind()` | `IecTypeService.GetKind` |
| `0x060000b0` | `System.String Ade.ApplicationControl.Iec.IIecType::get_Name()` | `IecTypeService.GetName` |

## Ade.ApplicationControl.Iec.IecTypeKind `0x02000048`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Function` | 1 |
| `FunctionBlock` | 2 |
| `Program` | 3 |

## Ade.ApplicationControl.Iec.IOnlineChannel `0x02000049`

基类：``；接口：``。

事件：`DownloadFinished: System.EventHandler`1<Ade.ApplicationControl.Iec.DownloadEventArgs>`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000b1` | `System.Boolean Ade.ApplicationControl.Iec.IOnlineChannel::Connect()` | `OnlineChannelService.Connect` |
| `0x060000b2` | `System.Boolean Ade.ApplicationControl.Iec.IOnlineChannel::Connect(System.String,System.Security.SecureString)` | `OnlineChannelService.ConnectWithUserNameAndSecret` |
| `0x060000b3` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::Disconnect()` | `OnlineChannelService.Disconnect` |
| `0x060000b4` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::Download(Ade.ApplicationControl.Iec.DownloadTypes)` | `OnlineChannelService.Download` |
| `0x060000b5` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::add_DownloadFinished(System.EventHandler`1<Ade.ApplicationControl.Iec.DownloadEventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x060000b6` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::remove_DownloadFinished(System.EventHandler`1<Ade.ApplicationControl.Iec.DownloadEventArgs>)` | 本地/继承/辅助路径，见 JSON |
| `0x060000b7` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::Start(Ade.ApplicationControl.Iec.StartType)` | `OnlineChannelService.Start` |
| `0x060000b8` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::Stop()` | `OnlineChannelService.Stop` |
| `0x060000b9` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::Reset()` | `OnlineChannelService.Reset` |
| `0x060000ba` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::Restart()` | `OnlineChannelService.Restart` |
| `0x060000bb` | `Ade.ApplicationControl.Iec.ControllerState Ade.ApplicationControl.Iec.IOnlineChannel::GetControllerState()` | `OnlineChannelService.GetControllerState` |
| `0x060000bc` | `System.Object Ade.ApplicationControl.Iec.IOnlineChannel::ReadVariable(Ade.ApplicationControl.Iec.IVariable)` | `OnlineChannelService.ReadVariable` |
| `0x060000bd` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::WriteVariable(Ade.ApplicationControl.Iec.IVariable,System.Object)` | `OnlineChannelService.WriteVariable` |
| `0x060000be` | `Ade.ApplicationControl.Iec.IConnectionEndpointCollection Ade.ApplicationControl.Iec.IOnlineChannel::get_ConnectionEndpoints()` | `OnlineChannelService.GetConnectionEndpoints` |
| `0x060000bf` | `Ade.ApplicationControl.Iec.IConnectionEndpoint Ade.ApplicationControl.Iec.IOnlineChannel::get_ActiveConnectionEndpoint()` | `OnlineChannelService.GetActiveConnectionEndpoint` |
| `0x060000c0` | `System.Void Ade.ApplicationControl.Iec.IOnlineChannel::set_ActiveConnectionEndpoint(Ade.ApplicationControl.Iec.IConnectionEndpoint)` | `OnlineChannelService.SetActiveConnectionEndpoint` |
| `0x060000c1` | `System.Object Ade.ApplicationControl.Iec.IOnlineChannel::GetDeviceInfoAttribute(System.String)` | `OnlineChannelService.GetDeviceInfoAttribute` |
| `0x060000c2` | `System.Object Ade.ApplicationControl.Iec.IOnlineChannel::GetDeviceStatusAttribute(System.String)` | `OnlineChannelService.GetDeviceStatusAttribute` |

## Ade.ApplicationControl.Iec.DownloadTypes `0x0200004a`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `None` | 0 |
| `Full` | 1 |
| `OnlyChanges` | 2 |
| `IncludeSources` | 4 |

## Ade.ApplicationControl.Iec.StartType `0x0200004b`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Cold` | 0 |
| `Warm` | 1 |
| `Hot` | 2 |

## Ade.ApplicationControl.Iec.ControllerState `0x0200004c`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `NotConnected` | 0 |
| `Ready` | 1 |
| `Stop` | 2 |
| `Running` | 3 |
| `Halt` | 4 |

## Ade.ApplicationControl.Iec.IProgramInstance `0x0200004d`

基类：``；接口：`Ade.ApplicationControl.IInstance`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000c3` | `System.String Ade.ApplicationControl.Iec.IProgramInstance::get_ProgramType()` | `ProgramInstanceService.GetProgramType` |
| `0x060000c4` | `System.String Ade.ApplicationControl.Iec.IProgramInstance::get_Comment()` | `ProgramInstanceService.GetComment` |
| `0x060000c5` | `Ade.ApplicationControl.Iec.IVariableCollection Ade.ApplicationControl.Iec.IProgramInstance::get_Variables()` | `ProgramInstanceService.GetVariables` |
| `0x060000c6` | `Ade.ApplicationControl.Iec.IFunctionBlockInstanceCollection Ade.ApplicationControl.Iec.IProgramInstance::get_FunctionBlockInstances()` | `ProgramInstanceService.GetFunctionBlockInstances` |
| `0x060000c7` | `Ade.ApplicationControl.Iec.IIecControllerPart Ade.ApplicationControl.Iec.IProgramInstance::get_ParentInstance()` | `ProgramInstanceService.GetParentInstanceId` |

## Ade.ApplicationControl.Iec.IProgramInstanceCollection `0x0200004e`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Iec.IProgramInstance>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Iec.IProgramInstance>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Iec.IProgramInstance>`。

## Ade.ApplicationControl.Iec.IProgramOrganizationUnit `0x0200004f`

基类：``；接口：`Ade.ApplicationControl.Iec.IIecType`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000c8` | `System.Boolean Ade.ApplicationControl.Iec.IProgramOrganizationUnit::Delete()` | `IecTypeService.DeleteProgramOrganizationUnit` |

## Ade.ApplicationControl.Iec.IProgramOrganizationUnitCollection `0x02000050`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Iec.IProgramOrganizationUnit>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Iec.IProgramOrganizationUnit>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Iec.IProgramOrganizationUnit>`。

## Ade.ApplicationControl.Iec.ITask `0x02000051`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000c9` | `System.String Ade.ApplicationControl.Iec.ITask::get_Name()` | `TaskService.GetName` |
| `0x060000ca` | `Ade.ApplicationControl.Iec.TaskType Ade.ApplicationControl.Iec.ITask::get_TaskType()` | `TaskService.GetTaskType` |
| `0x060000cb` | `System.String Ade.ApplicationControl.Iec.ITask::get_EventName()` | `TaskService.GetEventName` |
| `0x060000cc` | `System.Int32 Ade.ApplicationControl.Iec.ITask::get_Interval()` | `TaskService.GetInterval` |
| `0x060000cd` | `System.Int32 Ade.ApplicationControl.Iec.ITask::get_Priority()` | `TaskService.GetPriority` |
| `0x060000ce` | `System.Int32 Ade.ApplicationControl.Iec.ITask::get_Watchdog()` | `TaskService.GetWatchdog` |
| `0x060000cf` | `System.String Ade.ApplicationControl.Iec.ITask::get_Comment()` | `TaskService.GetComment` |
| `0x060000d0` | `Ade.ApplicationControl.Iec.IProgramInstanceCollection Ade.ApplicationControl.Iec.ITask::get_ProgramInstances()` | `TaskService.GetProgramInstances` |
| `0x060000d1` | `System.Void Ade.ApplicationControl.Iec.ITask::Delete()` | `TaskService.Delete` |

## Ade.ApplicationControl.Iec.TaskType `0x02000052`

基类：`System.Enum`；接口：``。

| 名称 | 值 |
| --- | --- |
| `Unknown` | 0 |
| `Cyclic` | 1 |
| `Event` | 2 |
| `Idle` | 3 |

## Ade.ApplicationControl.Iec.ITaskCollection `0x02000053`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Iec.ITask>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Iec.ITask>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Iec.ITask>`。

## Ade.ApplicationControl.Iec.IVariable `0x02000054`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000d2` | `System.String Ade.ApplicationControl.Iec.IVariable::get_Name()` | `VariableService.GetName` |
| `0x060000d3` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_Name(System.String)` | `VariableService.SetName` |
| `0x060000d4` | `System.String Ade.ApplicationControl.Iec.IVariable::get_DataType()` | `VariableService.GetDataType` |
| `0x060000d5` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_DataType(System.String)` | `VariableService.SetDataType` |
| `0x060000d6` | `System.String Ade.ApplicationControl.Iec.IVariable::get_InitValue()` | `VariableService.GetInitValue` |
| `0x060000d7` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_InitValue(System.String)` | `VariableService.SetInitValue` |
| `0x060000d8` | `System.Boolean Ade.ApplicationControl.Iec.IVariable::get_IsRetain()` | `VariableService.IsRetain` |
| `0x060000d9` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_IsRetain(System.Boolean)` | `VariableService.SetIsRetain` |
| `0x060000da` | `System.Boolean Ade.ApplicationControl.Iec.IVariable::get_IsSystemVariable()` | `VariableService.IsSystemVariable` |
| `0x060000db` | `System.Boolean Ade.ApplicationControl.Iec.IVariable::get_IsOpc()` | `VariableService.IsOpc` |
| `0x060000dc` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_IsOpc(System.Boolean)` | `VariableService.SetIsOpc` |
| `0x060000dd` | `System.Boolean Ade.ApplicationControl.Iec.IVariable::get_IsProficloud()` | `VariableService.IsProficloud` |
| `0x060000de` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_IsProficloud(System.Boolean)` | `VariableService.SetIsProficloud` |
| `0x060000df` | `System.Boolean Ade.ApplicationControl.Iec.IVariable::get_IsRedundant()` | `VariableService.IsRedundant` |
| `0x060000e0` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_IsRedundant(System.Boolean)` | `VariableService.SetIsRedundant` |
| `0x060000e1` | `System.String Ade.ApplicationControl.Iec.IVariable::get_Comment()` | `VariableService.GetComment` |
| `0x060000e2` | `System.Void Ade.ApplicationControl.Iec.IVariable::set_Comment(System.String)` | `VariableService.SetComment` |
| `0x060000e3` | `Ade.ApplicationControl.IInstance Ade.ApplicationControl.Iec.IVariable::get_ParentInstance()` | `VariableService.GetParentInstanceId` |
| `0x060000e4` | `System.Void Ade.ApplicationControl.Iec.IVariable::MoveToGroup(Ade.ApplicationControl.Iec.IVariableGroup)` | `VariableService.MoveToGroup` |

## Ade.ApplicationControl.Iec.IVariableCollection `0x02000055`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Iec.IVariable>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Iec.IVariable>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Iec.IVariable>`。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000e5` | `Ade.ApplicationControl.Iec.IVariableGroupCollection Ade.ApplicationControl.Iec.IVariableCollection::get_Groups()` | `VariableService.GetGroups` |

## Ade.ApplicationControl.Iec.IVariableGroup `0x02000056`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000e6` | `System.String Ade.ApplicationControl.Iec.IVariableGroup::get_Name()` | `VariableService.GetGroupName` |
| `0x060000e7` | `Ade.ApplicationControl.Iec.IVariableCollection Ade.ApplicationControl.Iec.IVariableGroup::get_Variables()` | `VariableService.GetGroupVariables` |

## Ade.ApplicationControl.Iec.IVariableGroupCollection `0x02000057`

基类：``；接口：`System.Collections.Generic.IReadOnlyList`1<Ade.ApplicationControl.Iec.IVariableGroup>, System.Collections.Generic.IEnumerable`1<Ade.ApplicationControl.Iec.IVariableGroup>, System.Collections.IEnumerable, System.Collections.Generic.IReadOnlyCollection`1<Ade.ApplicationControl.Iec.IVariableGroup>`。

## Ade.ApplicationControl.Iec.IHmiTag `0x02000058`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000e8` | `System.String Ade.ApplicationControl.Iec.IHmiTag::get_Name()` | 本地/继承/辅助路径，见 JSON |
| `0x060000e9` | `Ade.ApplicationControl.Iec.IVariable Ade.ApplicationControl.Iec.IHmiTag::get_Variable()` | 本地/继承/辅助路径，见 JSON |

## Ade.ApplicationControl.Iec.IProcessDatum `0x02000059`

基类：``；接口：``。

| Token | 完整签名 | 客户端直接 RPC |
| --- | --- | --- |
| `0x060000ea` | `System.String Ade.ApplicationControl.Iec.IProcessDatum::get_Label()` | 本地/继承/辅助路径，见 JSON |
| `0x060000eb` | `System.Guid Ade.ApplicationControl.Iec.IProcessDatum::get_DeviceId()` | 本地/继承/辅助路径，见 JSON |
| `0x060000ec` | `Ade.ApplicationControl.Iec.IVariable Ade.ApplicationControl.Iec.IProcessDatum::get_Variable()` | 本地/继承/辅助路径，见 JSON |
