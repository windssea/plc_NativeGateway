# M06：显式原工程恢复计划

2026-10-26。执行器不调用 ACI、Engineer、CodeMeter 或 computer use。首次真实恢复必须使用届时精确版本/影响的操作者确认，本页不授权任何设备动作。

## 计划与审批

`prepare_recovery_plan` 将同一恢复源、成功冷构建、完整 PCWE、目标 IP/端口/pin 及 Stop/下载/Start/只读监视子计划绑定成不可变 `plcnext-controller-recovery-plan/v1`。默认期望配置为 version=13、50 台、250 点、enabled=true，可显式指定范围内的精确值。

整体动作表为 `observe_before, stop, write_package_paths, sha512_readback, reset, load, start, verify_runtime`，单独的 recovery 收据批准该版本化整体动作，不扩展既有 download 收据的权限。发行端为独立操作者 CLI 的 `kind=recovery`；普通 MCP 没有签发真实审批的工具。

`approval_contract`、`load_recovery_plan` 会重新验证源/构建/包、各子计划的动作/前态/启动模式/目标、监视源和点数。无收据、过期、目标或动作不符、撤销、拒绝及已消费均在 socket 建立前拒绝并给出失败报告。

收据在 `<workspace>/controller-recovery-approvals/<review_sha256>.json`，排他 `.claimed.json` 在网络动作前创建并 fsync。拒绝、过期或已消费不是重发许可。一次失败不会删 claim 或自动下载旧包。

## 易失数据策略

默认 `volatile_data_policy=require_drain`。在没有外部三方完整排空证据接入的当前实现中，该策略在只读 baseline 后以 `drain_evidence_required` 拒绝，不发 Stop。`Owned=0`、部分队列计数或运行状态不构成完整排空证据。

若现场无法证明排空，可生成精确 `record_unknown_loss` 计划。它必须由操作者明确确认风险后才执行；报告列出全部未持久程序实例 RAM（采样、队列/Outbox 所有权、在途 ACK）可能损失，数量 unknown，不伪造零损失。

## 连续执行过程

1. 重新验证全部本地绑定、取得 IP/端口端点租约、消费独立审批，持久化 RecoveryBinding。
2. 从同一 pin 的设备读取有限 baseline，要求状态与审阅前态一致；读取失败或窗口发生身份变化，不进入 Stop。
3. 显式 Stop，轮询精确终态。应答与完成分开；回复丢失不自动重发。
4. 同一租约下检查远端 manifest 路径集合、空间，写审阅文件；manifest 最后写，逐文件长度与 SHA-512 回读通过才 Reset/Load。
5. 等待 Reset Ready、Load Stop；保存绑定 plan/source/inventory/执行 ID 的 Load 结果。
6. 新鲜只读 ProjectName/状态与刚才 Load 的成功事件、完整回读、Load 收据和 journal 追加前缀形成因果证据；Start 入口重新检查它们。
7. 显式 Start，等待精确 Running；随后按既定频率做最多三次有限只读窗口，检查精确配置和 250 点完整 GOOD 覆盖。
8. 保存结果。失败/不确定设备变更、加载后验证不完整或结果保存失败时保留端点隔离。

所有 session 共用同一端点租约，每次实际 RPC 前重新验证租约、取消和操作期限。整次恢复期限 300 秒。取消在边界协作生效；已经发出的请求不能被本地取消撤销。真实写入没有原子覆盖、自动回滚、旧文件删除或自动重试。

## 身份与完成状态

`same_plan_verified_load` 是自身完整传输/加载的因果证据，不是直接读取设备内存模块 SHA。设备 ProjectName、磁盘清单、源符号和完整内存加载身份保持区分；本地租约也不能排除其他 OS 用户或外部 Engineer 的动作。

结果字段分开：

| 字段 | 含义 |
|---|---|
| `original_package_loaded` | 精确包的全部回读及 Load 终态已验证 |
| `original_configuration_verified` | 支持字段的精确配置与期望匹配 |
| `original_program_restored` | 本次 MCP 范围内已加载、Running、配置匹配且完整点质量窗口通过 |
| `original_project_restored` | 当前保持 false；完整恢复还需外部三方验收 |
| `collection_verified` / `joint_acceptance_complete` | 当前保持 false；不能以 Running 或 GOOD 代替真实 DATA/STORED/mock/原采样摘要 |
| `controller_changed` | 至少一个设备变更请求可能已经发出，失败不表示撤销 |
| `outcome_unknown` | 已发请求缺回复或完成状态不可证实 |
| `receipt_persisted` | 本地结果是否可靠保存；false 不撤销已经发生的 Load/Start |

`original_loaded_runtime_observed` 表示 MCP 部分完成；`original_loaded_verification_incomplete` 表示包可能已经加载、程序可能已启动，但检查未完整通过；`recovery_failed` 要结合步骤与影响事实判断。原采样摘要一致、真实 DATA/STORED、确认推进和 mock 业务结果由外部三方验收器提供，当前不自动把它们升级为通过。

## 同一端点本机验证

`test_recovery_plan(store, project_id, expected_project_sha256, package_job_id, fault='none')` 创建自身随机端口的 `LocalRecoveryPeer`，使用实际生产控制/传输/只读客户端，在同一个 TLS 端点完成多 session 闭环。它不接受外部 IP；内部 PUBLIC fixture 收据只允许该已启动、尚未连接且 pin 精确匹配的 own peer，不能签发真实设备许可。

已有真实恢复源（32 POU）及实际生成的 49 文件包，完成六个 session 的 baseline→Stop→传输/回读→Reset/Load→ProjectName→Start→1767 字段/250 GOOD 窗口，所有 session 均观察到同一租约。

可选故障：`baseline_disconnect`、`initial_wrong`、`stop_reply_lost`、`write_reply_lost`、`readback_corrupt`、`reset_reply_lost`、`load_reply_lost`、`start_reply_lost`、`configuration_mismatch`、`runtime_disconnect`、`wrong_project_name`。注入故障的预期返回是失败或验证不完整；查看 `test_passed` 是否与预期一致。

[test_controller_recovery.py](../tests/test_controller_recovery.py)以 PUBLIC 不可执行的 49 文件 payload 检查正反例、连续租约、并发、取消、日志及结果落盘失败；只加速观测调度，不替代 M04 的真实频率门禁测试。实际 49 文件冷构建包的正例单独记录，不把不可执行 fixture 当成厂商包兼容证明。[验证汇总](../artifacts/controller-recovery-research/verification.json)和[单测日志](../artifacts/controller-recovery-research/unit-tests.log)列出证据范围。

没有向真实 PLC 发送任何本页控制/下载动作。真实固件接受、输出保持行为、恢复后业务验收仍需独立实际确认和窗口。
