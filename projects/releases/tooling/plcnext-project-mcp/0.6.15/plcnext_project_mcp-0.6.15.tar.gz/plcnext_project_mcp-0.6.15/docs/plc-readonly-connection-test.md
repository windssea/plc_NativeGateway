# 192.168.0.8 只读真机连接测试

2026-10-25 22:47（Asia/Shanghai），用户明确授权对此 IP 测试连接，说明无需账号密码。本次测试没有将该授权扩展为下载、文件传输、配置加载、停止或启动程序。

**TLS/RSC 连接及匿名状态读取成功。** [实际报告](../artifacts/plc-connection-test/0f6663384a824799a35ef91255445cdf/result.json)。

| 项目 | 实测 |
| --- | --- |
| 控制器 | 192.168.0.8，以太网本机地址 192.168.0.5；设备证书 CN=AXC F 2152，issuer=PLCnext Device Signing CA |
| 工程源参数 | NativeGateway 副本 ResourceSettings.set 指定 socomm.dll / IP192.168.0.8 / port41100 / timeout2000ms |
| TCP | 80、443、41100 可连接；ping 无响应不代表设备不可达 |
| 实际 RSC 通道 | 41100，TLS 1.2，ECDHE-RSA-AES256-GCM-SHA384；明文握手被关闭 |
| 协商 | RSC v4，data tagging=true，datagramming=false |
| 动态服务 | provider Arp，IPlcManagerService；本次协商得到 service handle1 / provider handle9，不能作为固定值使用 |
| 状态 | 匿名调用 GetPlcState method5 成功，raw=3，Running，额外状态 flags=0 |
| 公开 HMI | 工程名 NativeGateway.p06-performance-v26，project ID 与当前副本同为 ec4bcef4-d7ab-474c-80d7-b5dfda91b45d |

单次状态读取的发送清单只有 Connect、GetServiceHandles(IPlcManagerService)、GetPlcState。没有调用 CreateSession，没有提交账号密码或 token；没有文件方法、Reset/Load/Start/Stop/Change/Restart。

在发出 tagged 请求之前，原厂纯 MemoryStream oracle 验证了 31 组向量：发现服务的 header flags=0x40，raw 名称值体不带 FF；GetPlcState 空参数请求带 FF 尾标；返回为 tag09 + UInt32LE + FF。[原厂格式证据](../artifacts/plc-connection-test/tagged-oracle/vectors-01/report.json)。实际状态值体为 `0903000000ff`。

诊断脚本 [plc_readonly_connection_probe.py](../tools/plc_readonly_connection_probe.py) 固定目标 IP、端口和 PLC 服务，只允许上述三种请求，并对动态 handle、响应命令、校验和和 UInt32 标记核验。[离线发送护栏检查](../artifacts/plc-connection-test/request-guard-check.json)确认 Load、Start、Stop、Reset、WriteMany 被拒绝，检查本身未联网。

证书信任尚未完成：系统默认验证 41100 证书链失败，当前 IP 也不在该证书的 IP SAN 中。本次只读诊断在首次观察后固定精确 SHA-256 指纹 `3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863`，没有加入系统信任、修改证书或把它描述为完成 PKI 身份验证。443 的 Web 自签证书另有过期/名称问题，与 41100 的厂家证书不是同一张。[41100 证书记录](../artifacts/plc-connection-test/rsc-certificate.json)。

这证明当前设备允许匿名读取 PLC 状态，不证明匿名文件写入、下载或运行控制权限。主 MCP 0.3.0 的产品连接边界保持不变：其下载工具仍是离线模拟。此次新增的是限定目标的诊断脚本与真机证据，未把整个 tagged 协议或真实下载通道自动启用为 MCP 工具。
