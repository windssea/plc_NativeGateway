# ACI 公共 API、客户端和通信实现

分析对象是本机 PLCnext Engineer 2026.0 安装目录的 ACI 程序集。下面的“观察”均指文件中的元数据、CIL 和嵌入 descriptor；本轮没有启动 Engineer、初始化 ACI、读取认证材料或连接 PLC。历史离线实测另见 [aci-poc.md](../aci-poc.md)。

## 覆盖与身份

| 程序集 | SHA-256 | MVID | 静态枚举 |
| --- | --- | --- | --- |
| Ade.ApplicationControl.dll | `80f3e5df6dcc8ffc22c0cf0a566c2693b1b59037bb62e29ab8ec1ec31fb7fc11` | `f252f828-6184-4a72-9e22-d6f25af03846` | 98 类型、269 方法，68 个有 CIL body |
| Ade.ApplicationControl.ClientImpl.dll | `f0191c438eb6a48a31a1dc3d62859e382e87f9577395176cc447d752e01ecf42` | `909b5c50-ea98-4eaf-be66-d45d4ccf79a6` | 78 类型、391 方法，386 个有 body |
| Ade.ApplicationControl.Communication.dll | `cf5f7620d4b4fb973f587bba098ec1c6305c71828a4782b9a14a6c5ab0853bfd` | `a242a5cf-3a8b-4306-b12a-d74b3b52b721` | 867 类型、9312 方法，9308 个有 body |

三个程序集均面向 `.NETCoreApp,Version=v8.0`。Communication 中 828 个类型属于 `Grpc.Protos` 生成代码；其余 39 个类型包括对象仓库、证书、类型转换和编译器元数据类型。文件枚举完整不等于逐条 CIL 都已经进行语义验证。

公共契约 DLL 共 85 个 public 类型，其中 56 个接口、19 个枚举、222 个公开声明方法（含 getter/setter/add/remove）、201 个接口声明方法和 4 个事件。196/201 个接口方法可关联到 ClientImpl 实现；181 个直接包含可解析的业务 RPC 调用，其余经本地状态或辅助方法处理。未找到客户端实现的是 `IHmiTag` 和 `IProcessDatum` 的 5 个 getter；两接口标有 `EditorBrowsable(Never)`。不能把它们当作已可用的 HMI/物理 I/O 操作 API。

全量公共接口、完整签名、枚举值、事件及代理对应见 [public-api.md](public-api.md)，不是只选出的示例。所有方法的原始静态清单与 CIL 位于 `artifacts/aci-analysis/public-client-Ade.ApplicationControl*.json`。

REA 证据：

- 三份 artifact inventory：`ev_b4657922295cab50f1059bb85ff68ae12825e42524913df02c3fe78dc2021a4e`、`ev_98d8889feedd449bd8303ad4e608b99bf338e57e39f5c1e39f4085da31309de4`、`ev_93bbe0b63617d50f3771437dfc20d03ff5a91def9435ee37f77182e6c30a388d`，coverage complete。
- 公共 DLL members：`ev_3d5a4ee9d2cfdc61753472813989edd7c7dd8f10a180df8b97adad5d5529311c`；ClientImpl members：`ev_b14be58071ce0d6c374e0a31f3e72a7f2ea141bbcbc06719742973ade5fa8e38`。REA metadata 完整，但成员解析 partial：32/18 个泛型签名不支持 element type `0x15`。使用 Mono.Cecil 静态解析补全完整签名与 CIL，没有执行目标程序集。
- Communication members：`ev_b2b6ad274500eb99211ac08f634eba39772655f46372d1006a421f24a404fdf0` 明确 unavailable，原因是 metadata representation 超过 64 MiB 预算；本报告使用已保存的 Cecil 清单和直接解码的嵌入 descriptor 补足，未重复调用失败分析。
- 可移植证据包：[public-client-rea-complete.json](../../artifacts/aci-analysis/public-client-rea-complete.json)。

## 客户端的结构

调用路径为：应用自有子类 → `AttachToLocalServerClient` / `StartServerClient` → `ClientBase.Init()` → `ApplicationControlManager` → `ApplicationProxy` 和各类 `*Proxy` → `ServiceManager` 中的生成式 gRPC stub → Engineer 服务端。

`AttachToLocalServerClient` 的构造器是 protected，供应用派生自己的客户端类，默认地址为 `https://localhost:31172`。`StartServerClient` 同样通过继承使用；其 `Init()` 先 `Process.Start(serverFileName, arguments)` 再调用基类初始化。它不会自动替调用者补上 `/NOUI`。可参考已有的 [AciOfflineSession.cs](../../tools/AciOfflineSession.cs)。

ClientImpl `ApplicationControlManager::.ctor(Uri)` 的 Token 为 `0x06000002`：初始化仓库与 ServiceManager，轮询 `IsAvailable`；遇到 RPC `Unavailable(14)` 时立即重试，没有 sleep、次数上限或取消。只有 `IsAvailable=true` 才构造 ApplicationProxy。这个构造器不能直接占住长期运行的 MCP 请求线程；参考实现应放到独立进程，加外层启动时限与进程清理。

各 Proxy 使用 `ObjectModelItem.Id : Guid` 作为对象身份；`ProxyItemBase.get_ProtoId`（ClientImpl `0x06000141`）将 Guid 转成字符串放进请求的 `project_id` / `variable_id` 等字段。`ObjectModelItemRepository` 按 Guid 缓存对象包装，collection 通过 `GetItem` / `GetCount` / `GetItems` RPC 枚举对象身份。GUID 不是跨会话稳定的工程路径，MCP 不应把对象仓库当作可持久化工程数据库。

`IProject` 没有公开 Name/Path/Id 属性；实现类 ProjectProxy 额外有 `get_Name`（`0x060000eb` → `ProjectService.GetProjectName`），但不属于公共接口。MCP 应自己记录明确打开的副本路径，并核验专属 Engineer PID；不能通过公共 API 读取当前工程文件路径来弥补“误接管已打开工程”的风险。

## 全部功能边界

| 能力域 | 已观察的公共 API | 对 MCP 的意义与限制 |
| --- | --- | --- |
| 进程与应用 | 可用性/状态/版本/build/executable/PID，NewProject、OpenProject、BuildPath、Shutdown | 适合会话与环境诊断。Shutdown 是进程操作，应绑定自建 PID。 |
| 工程生命周期 | Save、两种 SaveAs、Close；压缩/非压缩工程枚举 | 可以创建并保存工程；NewProject 不带模板/设备参数，不应推断它自动产生特定控制器。 |
| 编译 | Compile(Build/Rebuild/Prepare)、CompileFinished、CompileAsync、消息类型/文本/typeId/Guid | MCP 必须等待结果事件并返回诊断，不能把 unary ACK 当编译成功。 |
| 源码与类型交换 | 导入 POU、DataTypeWorksheet、AutomationML；导出 AutomationML；导入/导出 IEC61131-10 | FB/ST 修改适合导出→变更→导入。未暴露“直接打开任意 code worksheet 并 set_text”接口。 |
| POU 与实例树 | POU 名称/类型/删除；controller→task→program instance→nested FB instance→variables | 能核对实例树与映射。POU collection 无 Add；新增内容需要导入。 |
| 变量离线属性 | Name/DataType/InitValue/Retain/OPC/Proficloud/Redundant/Comment 可设；system标志只读；MoveToGroup | 这些是实例变量/声明属性编辑，不等于任意 POU 接口和连接表达式的 AST 编辑。没有公开变量 collection Add/Delete。 |
| 任务 | 类型/event/周期/优先级/watchdog/comment/program实例读取、Delete | 当前公共 API 无 Create 或 setter。新增/修改调度需要其他工程交换路径。 |
| 控制器及 DataList | 控制器型号/名称/部件枚举，Replace，ImportDataList/ExportDataList | 可借助官方导入导出维护数据映射。完整支持的内容需按实际控制器验证。 |
| 库 | Add/Accept/Remove/Replace、路径、状态、组件类别 | 可复用 Engineer 的库验证和加载状态；带缺失/篡改/签名/版本等状态值。 |
| 设备树 | 网络协议、设备/模块/子模块，GetDeviceTypes/GetNextFreePosition/Create/Insert/Delete | 可配置硬件拓扑；Create 与 Insert 分开，不应把创建包装对象视为已插入网络。 |
| 设备参数与设置 | 字典/参数/可选值/帮助/只读标志，值 setter；TCP/IP 地址/掩码/网关 setter | 应遵循 IsReadOnly 和选项值，且把工程配置与设备实时属性区分。 |
| 在线连接 | Connect() 或 Connect(username, SecureString)、Disconnect、端点选择、状态、设备属性 | 凭据形式已存在。无需为参考实现暴露密码到日志。 |
| 在线变量 | ReadVariable/WriteVariable | 接受 IVariable 对象身份；不是任意字符串 PLC 地址读写 API。 |
| 控制与下载 | Download(flags)、Start(Cold/Warm/Hot)、Stop、Reset、Restart、DownloadFinished | 官方 ACI 确有代码下载和设备控制能力；本次仅静态观察，未对真实 PLC 使用。 |

`DownloadTypes` 为 Flags：None=0、Full=1、OnlyChanges=2、IncludeSources=4；Communication 转换器逐位复制这三个标志（`0x06000070/71`），不能把任意数字透传当成受支持操作。具体下载语义由 Engineer 服务端和控制器通道决定。

## gRPC 协议恢复

Communication 的反射类静态构造器将常量 Base64 块拼接，再传给 `FileDescriptor.FromGeneratedCode`。我们直接读取这些 CIL 常量并解码，得到 26 份原始 FileDescriptorProto，含 23 服务、193 RPC、334 顶层 message 和 19 enum。四个 server-stream 分别是工程打开、工程关闭、编译完成和下载完成；没有 client-stream 方法。

全部 service/path/request/response/streaming 见 [grpc-api.md](grpc-api.md)。机器清单 [public-client-protobuf-descriptors.json](../../artifacts/aci-analysis/public-client-protobuf-descriptors.json) 保存字段名、字段号、标量类型或 type_name、oneof；嵌入原始字节另保存在 `artifacts/aci-analysis/public-client-descriptors/*.bin`，包括本报告未解释的 protobuf options。无需猜测消息字段即可编写其他语言客户端，但直接 gRPC 依然依赖 Engineer 服务端及其许可和认证。

`Generic` 不是 protobuf Any：字段 1 是 `.NET type_name` 字符串，字段 2 是 JSON UTF-8 bytes。`GenericMessageTypeConverter`（Communication `0x06000074/75`）在写入时使用 `object.GetType().ToString()` 和 `System.Text.Json.JsonSerializer.SerializeToUtf8Bytes`；读取时 `Type.GetType(type_name)` 再按对应类型 Deserialize。空类型名表示 null。MCP 面向 JSON 时应采用有限 scalar 类型映射，保留数值宽度，不应接受 AI 提供的任意 .NET 类型名。

## 异步与错误处理

`Compile` 与 `Download` 的 unary RPC 返回 Empty，代表请求返回，不能代表操作完成。公开扩展 `CompileAsync` / `DownloadAsync` 通过 `OperationHandler` 把事件变成 Task。`OperationHandler.StartOperation`（公共 DLL `0x06000018`）先订阅事件，再 `Task.Run(startAction)`，但丢弃这个启动 Task；若启动动作直接失败，完成 Task 可能一直等待。这是静态发现的异常路径风险，未在本轮主动触发。

参考包装应明确自己的请求超时、在 finally 解除事件订阅、保留启动异常，并避免同一个工程同时编译/导入/关闭。外层超时只说明等待结束，不能声称底层编译已取消；下一次写操作前要重新确认会话状态。

`ProxyItemBase.CreateApplicationControlException`（ClientImpl `0x06000142`）对 gRPC Internal(13) 且 trailer `ade.servererror.message` 非空的响应抛 `ApplicationControlServerException`，其余抛 `ApplicationControlCommunicationException`。MCP 应分别返回业务/编译诊断、服务端异常、传输故障与超时，避免一律显示“编译失败”。

## MCP 参考实施选择

第一版优先复用厂商公共 C# 接口作为可选后端：会话创建、工程副本打开/新建、实例读取、IEC61131-10导入导出、POU删除、DataList导入导出、库操作与编译，按任务封装成少量工具；不把 193 个底层 RPC 原样展示给模型。Python MCP 到自有 C# 子进程使用 JSON 行通信，工程路径/专属 PID/超时在边界处绑定。

现有独立后端继续负责不依赖 ACI 的离线编辑/冷编译；新增 ACI 后端仅在合法许可及启用条件满足时提供官方工程语义与硬件配置验证。原生 gRPC 客户端可以作为第二阶段的跨语言实现，须实现证书/认证、对象身份缓存、四种通知与 .NET Generic 类型转换，不会因此消除 ACI 许可要求。

本轮没有逐项执行 193 RPC，没有重测任何硬件写操作，也没有证明设备树/安全 PLC/HMI 的全部型号和配置均可自动重建。已经完成的是公共契约与通信 schema 全量静态清单、客户端对应关系及关键路径审查；待验证部分应保留在总报告覆盖表中。
