# ACI 实现分析与 MCP 参考

2026-10-26；本机 PLCnext Engineer **2026.0.4 / 9.0.373.0**。使用 REA 的 PE/CLI 静态证据、Mono.Cecil CIL 解析和嵌入 protobuf descriptor 交叉核对。**ACI 可以作为无界面 MCP 的官方后端，仍依赖 Engineer 和有效 ACI 许可；其公开对象模型不是完整的工程编辑 API。**

本轮完成四个核心 ACI 程序集的全量类型/方法索引、公共契约和通信 schema 恢复、全部 RPC 的服务端入口绑定，以及工程、编译、编辑、认证、下载等关键路径审查。没有恢复原厂源代码，也没有逐一运行全部方法或穷尽所有下游 Engineer 子系统。全部结论限定于下列文件身份对应的构建。

## 阅读入口

| 内容 | 文档 / 机器数据 |
| --- | --- |
| 公共 API、客户端、对象身份、初始化和异常 | [客户端分析](public-client.md)、[全部 API 签名/枚举/事件](public-api.md)、[机器映射](../../artifacts/aci-analysis/public-client-api-map.json) |
| protobuf 字段和全部服务 | [23 服务 / 193 RPC](grpc-api.md)、[334 消息及字段](../../artifacts/aci-analysis/public-client-protobuf-descriptors.json) |
| 每条 RPC 的服务端入口 | [193/193 绑定表](server-rpc-coverage.md)、[方法 token / 直接调用锚点](../../artifacts/aci-analysis/implementation-coverage.json) |
| 工程、IEC 交换、编译、库、DataList、设备及缓存 | [服务端实现](server-project.md)、[1,292 方法索引](../../artifacts/aci-analysis/server-project-method-index.json) |
| 许可、启用、mTLS、连接、下载、变量、设备控制 | [安全与在线实现](security-online.md)、[结构化证据](../../artifacts/aci-analysis/security-online-ledger.json) |
| 未实现及静默不执行路径 | [完整扫描结果](../../artifacts/aci-analysis/server-project-stubs.json) |
| 可运行的可选 MCP 样例 | [使用说明](../../examples/aci_mcp/README.md)、[Python 服务](../../examples/aci_mcp/reference_server.py)、[离线宿主](../../examples/aci_mcp/Invoke-AciReference.ps1) |

## 实现结构

```mermaid
flowchart LR
    AI[AI / MCP 客户端] --> MCP[自有 MCP：副本、作业、哈希、串行执行]
    MCP --> SDK[自有子进程 + 官方 C# 公共 API]
    SDK --> Proxy[ClientImpl：对象代理 / 通知]
    Proxy --> Wire[Communication：protobuf + mTLS]
    Wire --> Server[ServerImpl：GUID 仓库 / Facade]
    Server --> Engineer[Engineer 无界面后端服务]
    Engineer --> Project[工程 / IEC 交换 / 编译 / 运行配置]
    Engineer -. 官方具备，本轮未调用 .-> PLC[PLC 通道 / 下载 / 状态]
```

源码交换委派给 `IIecXmlService`，编译委派给 `IPlcService`，实例枚举来自 `IEsmInstanceTreeProvider`，映射由 DataList 导入导出处理。大部分写操作会切换到 Engineer 服务线程。直接改用 gRPC 只会替换客户端层，仍会进入同一业务服务注册和许可边界。

当前安装中的本地 ACI 使用 **mTLS**：证书库由 Windows DPAPI `CurrentUser` 保护。此结论来自当前 DLL，不能直接用较早安全说明中的 cookie 描述代替。未读取实际证书库或私钥。

## 与现有独立 MCP 对照

下面的 ACI 能力来自静态实现，历史实测单列。建议的 MCP 工具是设计参考，不代表已加入当前注册服务。

| 能力 | ACI 实际入口/限制 | 现有独立 MCP / 参考方案 |
| --- | --- | --- |
| 新建、打开、保存 | NewProject 使用 Empty 模板；Open 后还要等初始化编译事件；SaveAs 有文件格式规则 | 独立 `project_create/import_copy` 已支持限定设备模板；ACI 后端可另封装工程会话 |
| FB 代码和接口 | 无直接 ST worksheet getter/setter；通过 IEC61131-10 / 指定 POU 导入 | 保留独立 ST/变量原子编辑；ACI 用导出→修改→导入→重编译→重开核验 |
| 新增/删除 FB | collection 无 Add；导入新增，Delete 委派通用工程命令；ACI 层无完整引用修复事务 | 独立 `project_change_fbs` 有有界引用保护；ACI 删除前仍需扫描引用并核验实例 |
| 现有变量 | 可改名、类型、初值、若干标志、备注和组；无公共 collection Add/Delete | 独立声明编辑适合成批接口更新；ACI setter 要编译和回读 |
| 实例与映射 | 任务/程序/嵌套 FB 实例树、变量、DataList 导入导出 | 结构修改后保存重开，重建句柄，并比较 ESM/DataList/调用连接 |
| 任务 | 可读任务类型、程序实例和 Delete；无创建/调度 setter；部分读取属性未实现 | 调度编辑仍是缺口，不能把 API 中的 Interval 等 getter 当作可用 |
| 库 | Add / Accept / Remove / Replace，包含状态和签名/版本约束 | 可作为官方库校验后端；当前独立编译读取已有引用 |
| 硬件 | 替换控制器类型，设备 Create / Insert / Delete、参数和设置 | 是独立 MCP 尚未泛化的方向；需真实副本正反例，不能直接承诺全部型号 |
| 槽位查询 | GetNextFreePosition 恒返回 0 | 不用于自动选槽；需要拓扑上下文和明确位置校验 |
| 编译 | Build / Rebuild / Prepare + 完成事件及消息 | 独立 `project_compile` 已有源重建；ACI 可承担更广工程类型的官方验证 |
| 编译选项 | 只有三个公开选项，写入应用配置服务 | 不作为无提示的工程局部设置变更 |
| PLC 下载 | Full / OnlyChanges / IncludeSources；委派 Engineer 下载服务 | 官方路径确实存在；本轮参考代码没有可执行设备入口 |
| PLC 状态和变量 | Connect / 状态 / 变量读写 / 设备属性 / 启停复位重启 | 后续需单独的设备会话、权限和效果回读；不是本轮执行范围 |
| HMI / 物理 I/O | IHmiTag / IProcessDatum 有隐藏接口但缺对应客户端实现 | 不构成完整公开 HMI / I/O 编辑 API；现有 NativeGateway 打包保持限定配置边界 |

## 必须修补的适配行为

1. **公开方法不等于已实现。** 本构建 7 个公开属性直接抛 `NotImplementedException`：程序/FB 实例 Comment、Task 的 EventName/Interval/Priority/Watchdog/Comment。另有 3 个条件异常分支。参考目录已逐项标记；普通快照应对这些字段返回 unsupported。
2. **返回不等于完成。** Compile / Download 的 unary 回复是 Empty；完成由事件流报告。服务端通知使用共享响应槽和 `ManualResetEvent`，没有 job correlation ID。每 Engineer PID 串行，先订阅再触发，MCP 自行维护唯一活动 job。
3. **超时不等于取消。** 客户端初始化存在无延迟、无上限重试路径；公开 Async 扩展可能遗漏启动 Task 的异常。参考样例把调用放进独立宿主进程，外加期限；不确定失败保留 PID 租约，阻止自动重试。
4. **旧对象不一定是实时视图。** POU/实例集合含缓存，POU 来源于 LastBuildResult。结构改变后保存→关闭→重开→重新枚举；不跨会话保存 ACI GUID。
5. **无异常不等于修改有效。** 参数字符串转换失败、在线服务缺失或 CanExecute=false 可能静默返回。写后读回并核对预期差异；下载必须等待结果，设备控制还需验证最终状态。
6. **实例映射必须验收。** ACI 未提供完整的删除/接口变更引用修复事务。既有注释修改的 98 项保留检查不能证明任意 FB 删除或变量变更都安全。

## 覆盖和验证

| 对象 | 覆盖 | 尚不能宣称 |
| --- | --- | --- |
| 四个核心 DLL | 1,217 类型 / 11,264 方法静态索引，带 SHA-256/MVID/token | 已还原原始源代码或全部下游产品实现 |
| 公共契约 | 85 公共类型 / 56 接口 / 19 枚举 / 222 公开声明方法，含访问器 | 所有声明均已实现；其中 5 个隐藏接口 getter 缺客户端对应 |
| 客户端对应 | 201 个接口声明方法中 196 个有实现关联 | 所有关联路径已运行 |
| 通信 | 26 descriptor / 23 服务 / 193 RPC / 4 通知流 / 334 顶层消息 | 与其他版本兼容或所有设备可用 |
| 服务端 | 193/193 RPC 唯一入口绑定，1,292 方法索引，关键流程审查 | 全部 193 RPC 实测成功 |
| descriptor 交叉检查 | [451/451 通过](../../artifacts/aci-analysis/public-client-descriptor-checks.json) | 线上协议/认证实测 |
| 新 MCP 参考 | [stdio 发现、目录查询和禁用执行检查通过](../../artifacts/aci-analysis/reference-mcp-check.json)；4 个单元测试含成功/失败/超时/无结果模拟；PowerShell 仅语法解析 | 新宿主已通过真实 ACI 往返；实例/映射保留已自动核验 |
| 历史 ACI 实测 | [2026-10-23：31 POU 副本，一个 FB 注释改动，三次 Rebuild，98 项保留检查](../aci-poc.md) | 任意结构/接口修改、物理 I/O、下载均已验证 |

REA canonical 成员解析的限制保留在子报告中：公共/客户端/服务端存在不支持的泛型签名；Communication 成员解析超出 64 MiB 表示预算。Cecil 补足人读签名与全量 CIL，descriptor 直接静态解码；没有将 REA 的 partial/unavailable 改写为 complete。

剩余问题包括：许可管理器内部到期策略；结构导入后缓存的全部刷新条件；更广设备/图形语言/安全工程往返；异常和并发通知的运行行为；真实设备下载、在线变更及状态控制。本轮没有启动 Engineer、更改许可、连接或下载到 PLC，也没有改动 NativeGateway 原工程。
