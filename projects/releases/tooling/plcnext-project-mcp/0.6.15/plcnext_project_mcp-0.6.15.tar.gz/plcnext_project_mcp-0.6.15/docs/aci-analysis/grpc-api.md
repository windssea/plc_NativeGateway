# ACI gRPC 全量服务矩阵

静态解码 Communication 的 26 份 FileDescriptorProto，共 23 服务、193 RPC；4 个服务端流、0 个客户端流。服务路径和字段号来自程序集嵌入 descriptor 原始字节，无需执行 .cctor。

JSON 保留每条消息的字段名、字段号、scalar/type_name、oneof 和 RPC 请求/响应类型；`.bin` 文件是嵌入的原始 descriptor。不是从名称推测的协议。

## aci.variable_service.VariableService

来源 `Grpc/protos/variable_service.proto`；反射初始化 Token `0x060000d3`，descriptor SHA-256 `b4a783e1951950eabe367ed0a15d4cb6b348aebed72af9a29aae0fe54fdf305a`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetName` | `.aci.variable_service.GetNameRequest` | `.aci.variable_service.GetNameResponse` | Unary |
| `SetName` | `.aci.variable_service.SetNameRequest` | `.google.protobuf.Empty` | Unary |
| `GetDataType` | `.aci.variable_service.GetDataTypeRequest` | `.aci.variable_service.GetDataTypeResponse` | Unary |
| `SetDataType` | `.aci.variable_service.SetDataTypeRequest` | `.google.protobuf.Empty` | Unary |
| `GetInitValue` | `.aci.variable_service.GetInitValueRequest` | `.aci.variable_service.GetInitValueResponse` | Unary |
| `SetInitValue` | `.aci.variable_service.SetInitValueRequest` | `.google.protobuf.Empty` | Unary |
| `IsRetain` | `.aci.variable_service.IsRetainRequest` | `.aci.variable_service.IsRetainResponse` | Unary |
| `SetIsRetain` | `.aci.variable_service.SetIsRetainRequest` | `.google.protobuf.Empty` | Unary |
| `IsSystemVariable` | `.aci.variable_service.IsSystemVariableRequest` | `.aci.variable_service.IsSystemVariableResponse` | Unary |
| `IsOpc` | `.aci.variable_service.IsOpcRequest` | `.aci.variable_service.IsOpcResponse` | Unary |
| `SetIsOpc` | `.aci.variable_service.SetIsOpcRequest` | `.google.protobuf.Empty` | Unary |
| `IsProficloud` | `.aci.variable_service.IsProficloudRequest` | `.aci.variable_service.IsProficloudResponse` | Unary |
| `SetIsProficloud` | `.aci.variable_service.SetIsProficloudRequest` | `.google.protobuf.Empty` | Unary |
| `IsRedundant` | `.aci.variable_service.IsRedundantRequest` | `.aci.variable_service.IsRedundantResponse` | Unary |
| `SetIsRedundant` | `.aci.variable_service.SetIsRedundantRequest` | `.google.protobuf.Empty` | Unary |
| `GetComment` | `.aci.variable_service.GetCommentRequest` | `.aci.variable_service.GetCommentResponse` | Unary |
| `SetComment` | `.aci.variable_service.SetCommentRequest` | `.google.protobuf.Empty` | Unary |
| `GetParentInstanceId` | `.aci.variable_service.GetParentInstanceIdRequest` | `.aci.variable_service.GetParentInstanceIdResponse` | Unary |
| `MoveToGroup` | `.aci.variable_service.MoveToGroupRequest` | `.google.protobuf.Empty` | Unary |
| `GetGroups` | `.aci.variable_service.GetGroupsRequest` | `.aci.variable_service.GetGroupsResponse` | Unary |
| `GetGroupName` | `.aci.variable_service.GetGroupNameRequest` | `.aci.variable_service.GetGroupNameResponse` | Unary |
| `GetGroupVariables` | `.aci.variable_service.GetGroupVariablesRequest` | `.aci.variable_service.GetGroupVariablesResponse` | Unary |

## aci.program_instance_service.ProgramInstanceService

来源 `Grpc/protos/program_instance_service.proto`；反射初始化 Token `0x06000386`，descriptor SHA-256 `7c0e01e9e26846a291a9fb754b3eb3f6e85182ce68af7eaf441fbc4436406132`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetName` | `.aci.program_instance_service.GetNameRequest` | `.aci.program_instance_service.GetNameResponse` | Unary |
| `GetProgramType` | `.aci.program_instance_service.GetProgramTypeRequest` | `.aci.program_instance_service.GetProgramTypeResponse` | Unary |
| `GetComment` | `.aci.program_instance_service.GetCommentRequest` | `.aci.program_instance_service.GetCommentResponse` | Unary |
| `GetVariables` | `.aci.program_instance_service.GetVariablesRequest` | `.aci.program_instance_service.GetVariablesResponse` | Unary |
| `GetFunctionBlockInstances` | `.aci.program_instance_service.GetFunctionBlockInstancesRequest` | `.aci.program_instance_service.GetFunctionBlockInstancesResponse` | Unary |
| `GetParentInstanceId` | `.aci.program_instance_service.GetParentInstanceIdRequest` | `.aci.program_instance_service.GetParentInstanceIdResponse` | Unary |

## aci.network_component_category_service.NetworkComponentCategoryService

来源 `Grpc/protos/Network/network_component_category_service.proto`；反射初始化 Token `0x06000472`，descriptor SHA-256 `f03f97ca059133f082231b0fe96cb8ef40a2ec454fbb31db3f1006aae3d821f6`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetDeviceTypes` | `.aci.network_component_category_service.GetDeviceTypesRequest` | `.aci.network_component_category_service.GetDeviceTypesResponse` | Unary |

## aci.device_setting_service.DeviceSettingService

来源 `Grpc/protos/Network/device_setting_service.proto`；反射初始化 Token `0x060004a0`，descriptor SHA-256 `6e252950ded47f5dcb07d762e0efb335fe66fbc6a2a7bb84801ad913c8be471f`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetSettingId` | `.aci.device_setting_service.GetSettingIdRequest` | `.aci.device_setting_service.GetSettingIdResponse` | Unary |
| `GetSettingLabel` | `.aci.device_setting_service.GetSettingLabelRequest` | `.aci.device_setting_service.GetSettingLabelResponse` | Unary |
| `GetSettingValue` | `.aci.device_setting_service.GetSettingValueRequest` | `.aci.device_setting_service.GetSettingValueResponse` | Unary |
| `SetSettingValue` | `.aci.device_setting_service.SetSettingValueRequest` | `.google.protobuf.Empty` | Unary |
| `GetSettingHelp` | `.aci.device_setting_service.GetSettingHelpRequest` | `.aci.device_setting_service.GetSettingHelpResponse` | Unary |
| `IsReadOnly` | `.aci.device_setting_service.IsReadOnlyRequest` | `.aci.device_setting_service.IsReadOnlyResponse` | Unary |
| `GetOptions` | `.aci.device_setting_service.GetOptionsRequest` | `.aci.device_setting_service.GetOptionsResponse` | Unary |
| `GetOptionLabel` | `.aci.device_setting_service.GetOptionLabelRequest` | `.aci.device_setting_service.GetOptionLabelResponse` | Unary |
| `GetOptionValue` | `.aci.device_setting_service.GetOptionValueRequest` | `.aci.device_setting_service.GetOptionValueResponse` | Unary |

## aci.device_parameter_service.DeviceParameterService

来源 `Grpc/protos/Network/device_parameter_service.proto`；反射初始化 Token `0x060005ed`，descriptor SHA-256 `b20c059062c1c14423f21180563b0d6e79f403eaa4c55a973d71ab546ef610ba`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetParameterId` | `.aci.device_parameter_service.GetParameterIdRequest` | `.aci.device_parameter_service.GetParameterIdResponse` | Unary |
| `GetParameterLabel` | `.aci.device_parameter_service.GetParameterLabelRequest` | `.aci.device_parameter_service.GetParameterLabelResponse` | Unary |
| `GetParameterValue` | `.aci.device_parameter_service.GetParameterValueRequest` | `.aci.device_parameter_service.GetParameterValueResponse` | Unary |
| `SetParameterValue` | `.aci.device_parameter_service.SetParameterValueRequest` | `.google.protobuf.Empty` | Unary |
| `GetParameterHelp` | `.aci.device_parameter_service.GetParameterHelpRequest` | `.aci.device_parameter_service.GetParameterHelpResponse` | Unary |
| `IsReadOnly` | `.aci.device_parameter_service.IsReadOnlyRequest` | `.aci.device_parameter_service.IsReadOnlyResponse` | Unary |
| `GetOptions` | `.aci.device_parameter_service.GetOptionsRequest` | `.aci.device_parameter_service.GetOptionsResponse` | Unary |
| `GetOptionLabel` | `.aci.device_parameter_service.GetOptionLabelRequest` | `.aci.device_parameter_service.GetOptionLabelResponse` | Unary |
| `GetOptionValue` | `.aci.device_parameter_service.GetOptionValueRequest` | `.aci.device_parameter_service.GetOptionValueResponse` | Unary |

## aci.iec_controller_part_service.IecControllerPartService

来源 `Grpc/protos/iec_controller_part_service.proto`；反射初始化 Token `0x0600073a`，descriptor SHA-256 `62cd0baa7b171bec1b129b7d3605679926c452e008c9f40124c39f18a3b5b725`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `IsSafety` | `.aci.iec_controller_part_service.IsSafetyRequest` | `.aci.iec_controller_part_service.IsSafetyResponse` | Unary |
| `GetVariables` | `.aci.iec_controller_part_service.GetVariablesRequest` | `.aci.iec_controller_part_service.GetVariablesResponse` | Unary |
| `GetTasks` | `.aci.iec_controller_part_service.GetTasksRequest` | `.aci.iec_controller_part_service.GetTasksResponse` | Unary |
| `GetOnlineChannel` | `.aci.iec_controller_part_service.GetOnlineChannelRequest` | `.aci.iec_controller_part_service.GetOnlineChannelResponse` | Unary |

## aci.function_block_instance_service.FunctionBlockInstanceService

来源 `Grpc/protos/function_block_instance_service.proto`；反射初始化 Token `0x060007da`，descriptor SHA-256 `974d60b570fe45a0ecd262709722ad6cf8a2b49b4cd72dcc59f2d44323442330`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetName` | `.aci.function_block_instance_service.GetNameRequest` | `.aci.function_block_instance_service.GetNameResponse` | Unary |
| `GetFunctionBlockType` | `.aci.function_block_instance_service.GetFunctionBlockTypeRequest` | `.aci.function_block_instance_service.GetFunctionBlockTypeResponse` | Unary |
| `GetComment` | `.aci.function_block_instance_service.GetCommentRequest` | `.aci.function_block_instance_service.GetCommentResponse` | Unary |
| `GetVariables` | `.aci.function_block_instance_service.GetVariablesRequest` | `.aci.function_block_instance_service.GetVariablesResponse` | Unary |
| `GetFunctionBlockInstances` | `.aci.function_block_instance_service.GetFunctionBlockInstancesRequest` | `.aci.function_block_instance_service.GetFunctionBlockInstancesResponse` | Unary |
| `GetParentInstanceId` | `.aci.function_block_instance_service.GetParentInstanceIdRequest` | `.aci.function_block_instance_service.GetParentInstanceIdResponse` | Unary |

## aci.common_component_category_service.CommonComponentCategoryService

来源 `Grpc/protos/common_component_category_service.proto`；反射初始化 Token `0x060008c6`，descriptor SHA-256 `8e7aad7207965cc8a62e0531d4aee2dd3c0913f08362ef98918d08ba6c94d5b4`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetControllerTypes` | `.aci.common_component_category_service.GetControllerTypesRequest` | `.aci.common_component_category_service.GetControllerTypesResponse` | Unary |

## aci.collection_service.CollectionService

来源 `Grpc/protos/collection_service.proto`；反射初始化 Token `0x060008f4`，descriptor SHA-256 `0617b9399b241e1bf2f5bc5d5d96d4cbfd7b67d492520d9117ceb526354f0f2b`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetItem` | `.aci.collection_service.GetItemRequest` | `.aci.collection_service.GetItemResponse` | Unary |
| `GetCount` | `.aci.collection_service.GetCountRequest` | `.aci.collection_service.GetCountResponse` | Unary |
| `GetItems` | `.aci.collection_service.GetItemsRequest` | `.aci.collection_service.GetItemsResponse` | Unary |

## aci.application_service.ApplicationService

来源 `Grpc/protos/application_service.proto`；反射初始化 Token `0x0600096f`，descriptor SHA-256 `b5183c30d6b4c257eca18df2eff7b8340ec8e314a463ec077d4ae026a62c554d`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetApplicationCompilerOptions` | `.google.protobuf.Empty` | `.aci.application_service.GetApplicationCompilerOptionsResponse` | Unary |
| `GetCompilerOptionAllowExtendedIdentifier` | `.aci.application_service.GetCompilerOptionAllowExtendedIdentifierRequest` | `.aci.application_service.GetCompilerOptionAllowExtendedIdentifierResponse` | Unary |
| `SetCompilerOptionAllowExtendedIdentifier` | `.aci.application_service.SetCompilerOptionAllowExtendedIdentifierRequest` | `.google.protobuf.Empty` | Unary |
| `GetCompilerOptionAllowWritingVarInputInFunction` | `.aci.application_service.GetCompilerOptionAllowWritingVarInputInFunctionRequest` | `.aci.application_service.GetCompilerOptionAllowWritingVarInputInFunctionResponse` | Unary |
| `SetCompilerOptionAllowWritingVarInputInFunction` | `.aci.application_service.SetCompilerOptionAllowWritingVarInputInFunctionRequest` | `.google.protobuf.Empty` | Unary |
| `GetCompilerOptionUseDynamicSfcInfoArrays` | `.aci.application_service.GetCompilerOptionUseDynamicSfcInfoArraysRequest` | `.aci.application_service.GetCompilerOptionUseDynamicSfcInfoArraysResponse` | Unary |
| `SetCompilerOptionUseDynamicSfcInfoArrays` | `.aci.application_service.SetCompilerOptionUseDynamicSfcInfoArraysRequest` | `.google.protobuf.Empty` | Unary |

## aci.task_service.TaskService

来源 `task_service.proto`；反射初始化 Token `0x06000a3b`，descriptor SHA-256 `c089f030ce81707b63f155e7dd8a98895091a17f04e87dfd54478da7b33049ef`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetName` | `.aci.task_service.GetNameRequest` | `.aci.task_service.GetNameResponse` | Unary |
| `GetTaskType` | `.aci.task_service.GetTaskTypeRequest` | `.aci.task_service.GetTaskTypeResponse` | Unary |
| `GetEventName` | `.aci.task_service.GetEventNameRequest` | `.aci.task_service.GetEventNameResponse` | Unary |
| `GetInterval` | `.aci.task_service.GetIntervalRequest` | `.aci.task_service.GetIntervalResponse` | Unary |
| `GetPriority` | `.aci.task_service.GetPriorityRequest` | `.aci.task_service.GetPriorityResponse` | Unary |
| `GetWatchdog` | `.aci.task_service.GetWatchdogRequest` | `.aci.task_service.GetWatchdogResponse` | Unary |
| `GetComment` | `.aci.task_service.GetCommentRequest` | `.aci.task_service.GetCommentResponse` | Unary |
| `GetProgramInstances` | `.aci.task_service.GetProgramInstancesRequest` | `.aci.task_service.GetProgramInstancesResponse` | Unary |
| `Delete` | `.aci.task_service.DeleteRequest` | `.google.protobuf.Empty` | Unary |

## aci.property_service.PropertyService

来源 `property_service.proto`；反射初始化 Token `0x06000b86`，descriptor SHA-256 `1df694d3e26d8b2a80c6cb923476c9f571df05486084b6cc39ee184cd65f7d89`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetPropertyName` | `.aci.property_service.GetPropertyNameRequest` | `.aci.property_service.GetPropertyNameResponse` | Unary |
| `GetPropertyType` | `.aci.property_service.GetPropertyTypeRequest` | `.aci.property_service.GetPropertyTypeResponse` | Unary |
| `GetPropertyValue` | `.aci.property_service.GetPropertyValueRequest` | `.aci.property_service.GetPropertyValueResponse` | Unary |
| `GetCount` | `.aci.property_service.GetCountRequest` | `.aci.property_service.GetCountResponse` | Unary |
| `ContainsProperty` | `.aci.property_service.ContainsPropertyRequest` | `.aci.property_service.ContainsPropertyResponse` | Unary |
| `GetNames` | `.aci.property_service.GetNamesRequest` | `.aci.property_service.GetNamesResponse` | Unary |
| `GetProperties` | `.aci.property_service.GetPropertiesRequest` | `.aci.property_service.GetPropertiesResponse` | Unary |
| `IsDictionaryReadOnly` | `.aci.property_service.IsDictionaryReadOnlyRequest` | `.aci.property_service.IsDictionaryReadOnlyResponse` | Unary |
| `AddProperty` | `.aci.property_service.AddPropertyRequest` | `.aci.property_service.AddPropertyResponse` | Unary |
| `GetProperty` | `.aci.property_service.GetPropertyRequest` | `.aci.property_service.GetPropertyResponse` | Unary |
| `RemoveProperty` | `.aci.property_service.RemovePropertyRequest` | `.aci.property_service.RemovePropertyResponse` | Unary |
| `ClearDictionary` | `.aci.property_service.ClearDictionaryRequest` | `.google.protobuf.Empty` | Unary |

## aci.project_service.ProjectService

来源 `project_service.proto`；反射初始化 Token `0x06000d4d`，descriptor SHA-256 `75fe2c84f37435edf095f32c9a5b35880096a95edff3cd4219cd242144a67ee7`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `IsProjectOpen` | `.google.protobuf.Empty` | `.aci.project_service.IsProjectOpenResponse` | Unary |
| `GetActiveProject` | `.google.protobuf.Empty` | `.aci.project_service.GetActiveProjectResponse` | Unary |
| `GetProjectName` | `.aci.project_service.GetProjectNameRequest` | `.aci.project_service.GetProjectNameResponse` | Unary |
| `GetBuildPath` | `.google.protobuf.Empty` | `.aci.project_service.GetBuildPathResponse` | Unary |
| `GetControllers` | `.aci.project_service.GetControllersRequest` | `.aci.project_service.GetControllersResponse` | Unary |
| `GetComponentCategories` | `.aci.project_service.GetComponentCategoriesRequest` | `.aci.project_service.GetComponentCategoriesResponse` | Unary |
| `GetComponentCategoryKind` | `.aci.project_service.GetComponentCategoryKindRequest` | `.aci.project_service.GetComponentCategoryKindResponse` | Unary |
| `OpenProject` | `.aci.project_service.OpenProjectRequest` | `.aci.project_service.OpenProjectResponse` | Unary |
| `NewProject` | `.google.protobuf.Empty` | `.aci.project_service.NewProjectResponse` | Unary |
| `SaveProject` | `.aci.project_service.SaveProjectRequest` | `.google.protobuf.Empty` | Unary |
| `SaveProjectAs` | `.aci.project_service.SaveProjectAsRequest` | `.aci.project_service.SaveProjectAsResponse` | Unary |
| `SaveProjectAsWithProjectType` | `.aci.project_service.SaveProjectAsWithProjectTypeRequest` | `.aci.project_service.SaveProjectAsWithProjectTypeResponse` | Unary |
| `CloseProject` | `.aci.project_service.CloseProjectRequest` | `.google.protobuf.Empty` | Unary |
| `CompileProject` | `.aci.project_service.CompileProjectRequest` | `.google.protobuf.Empty` | Unary |
| `ImportProgramOrganizationUnits` | `.aci.project_service.ImportProgramOrganizationUnitsRequest` | `.aci.project_service.ImportProgramOrganizationUnitsResponse` | Unary |
| `ImportDataTypeWorksheets` | `.aci.project_service.ImportDataTypeWorksheetsRequest` | `.aci.project_service.ImportDataTypeWorksheetsResponse` | Unary |
| `ImportAutomationML` | `.aci.project_service.ImportAutomationMLRequest` | `.aci.project_service.ImportAutomationMLResponse` | Unary |
| `ExportAutomationML` | `.aci.project_service.ExportAutomationMLRequest` | `.aci.project_service.ExportAutomationMLResponse` | Unary |
| `ImportIec61131_10` | `.aci.project_service.ImportIec61131_10Request` | `.aci.project_service.ImportIec61131_10Response` | Unary |
| `ExportIec61131_10` | `.aci.project_service.ExportIec61131_10Request` | `.aci.project_service.ExportIec61131_10Response` | Unary |
| `ProvideProjectOpenedNotifications` | `.google.protobuf.Empty` | `.aci.project_service.ProvideProjectOpenedNotificationsResponse` | 服务端流 |
| `ProvideProjectClosedNotifications` | `.google.protobuf.Empty` | `.aci.project_service.ProvideProjectClosedNotificationsResponse` | 服务端流 |
| `ProvideCompileFinishedNotifications` | `.google.protobuf.Empty` | `.aci.project_service.ProvideCompileFinishedNotificationsResponse` | 服务端流 |

## aci.online_channel_service.OnlineChannelService

来源 `online_channel_service.proto`；反射初始化 Token `0x0600101d`，descriptor SHA-256 `740ceeb340445e36012a35c249341bedab99d364238f8e18b9a513fc46e779f1`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `Connect` | `.aci.online_channel_service.ConnectRequest` | `.aci.online_channel_service.ConnectResponse` | Unary |
| `ConnectWithUserNameAndSecret` | `.aci.online_channel_service.ConnectWithUserNameAndSecretRequest` | `.aci.online_channel_service.ConnectWithUserNameAndSecretResponse` | Unary |
| `Disconnect` | `.aci.online_channel_service.DisconnectRequest` | `.google.protobuf.Empty` | Unary |
| `Download` | `.aci.online_channel_service.DownloadRequest` | `.google.protobuf.Empty` | Unary |
| `Start` | `.aci.online_channel_service.StartRequest` | `.google.protobuf.Empty` | Unary |
| `Stop` | `.aci.online_channel_service.StopRequest` | `.google.protobuf.Empty` | Unary |
| `Reset` | `.aci.online_channel_service.ResetRequest` | `.google.protobuf.Empty` | Unary |
| `Restart` | `.aci.online_channel_service.RestartRequest` | `.google.protobuf.Empty` | Unary |
| `GetControllerState` | `.aci.online_channel_service.GetControllerStateRequest` | `.aci.online_channel_service.GetControllerStateResponse` | Unary |
| `ReadVariable` | `.aci.online_channel_service.ReadVariableRequest` | `.aci.online_channel_service.ReadVariableResponse` | Unary |
| `WriteVariable` | `.aci.online_channel_service.WriteVariableRequest` | `.google.protobuf.Empty` | Unary |
| `GetConnectionEndpoints` | `.aci.online_channel_service.GetConnectionEndpointsRequest` | `.aci.online_channel_service.GetConnectionEndpointsResponse` | Unary |
| `GetActiveConnectionEndpoint` | `.aci.online_channel_service.GetActiveConnectionEndpointRequest` | `.aci.online_channel_service.GetActiveConnectionEndpointResponse` | Unary |
| `SetActiveConnectionEndpoint` | `.aci.online_channel_service.SetActiveConnectionEndpointRequest` | `.google.protobuf.Empty` | Unary |
| `GetDeviceInfoAttribute` | `.aci.online_channel_service.GetDeviceInfoAttributeRequest` | `.aci.online_channel_service.GetDeviceInfoAttributeResponse` | Unary |
| `GetDeviceStatusAttribute` | `.aci.online_channel_service.GetDeviceStatusAttributeRequest` | `.aci.online_channel_service.GetDeviceStatusAttributeResponse` | Unary |
| `GetConnectionEndpointKind` | `.aci.online_channel_service.GetConnectionEndpointKindRequest` | `.aci.online_channel_service.GetConnectionEndpointKindResponse` | Unary |
| `GetConnectionEndpointName` | `.aci.online_channel_service.GetConnectionEndpointNameRequest` | `.aci.online_channel_service.GetConnectionEndpointNameResponse` | Unary |
| `GetConnectionEndpointIPAddress` | `.aci.online_channel_service.GetConnectionEndpointIPAddressRequest` | `.aci.online_channel_service.GetConnectionEndpointIPAddressResponse` | Unary |
| `SetConnectionEndpointIPAddress` | `.aci.online_channel_service.SetConnectionEndpointIPAddressRequest` | `.google.protobuf.Empty` | Unary |
| `GetConnectionEndpointSubnetMask` | `.aci.online_channel_service.GetConnectionEndpointSubnetMaskRequest` | `.aci.online_channel_service.GetConnectionEndpointSubnetMaskResponse` | Unary |
| `SetConnectionEndpointSubnetMask` | `.aci.online_channel_service.SetConnectionEndpointSubnetMaskRequest` | `.google.protobuf.Empty` | Unary |
| `GetConnectionEndpointGateway` | `.aci.online_channel_service.GetConnectionEndpointGatewayRequest` | `.aci.online_channel_service.GetConnectionEndpointGatewayResponse` | Unary |
| `SetConnectionEndpointGateway` | `.aci.online_channel_service.SetConnectionEndpointGatewayRequest` | `.google.protobuf.Empty` | Unary |
| `ProvideDownloadFinishedNotifications` | `.google.protobuf.Empty` | `.aci.online_channel_service.ProvideDownloadFinishedNotificationsResponse` | 服务端流 |

## aci.network_controller_part_service.NetworkControllerPartService

来源 `Network/network_controller_part_service.proto`；反射初始化 Token `0x06001311`，descriptor SHA-256 `207e159d640b9c5fb51f56e959f267a9698a9f9392371bca2444ffffc1399d80`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetProtocol` | `.aci.network_controller_part_service.GetProtocolRequest` | `.aci.network_controller_part_service.GetProtocolResponse` | Unary |
| `GetSettings` | `.aci.network_controller_part_service.GetSettingsRequest` | `.aci.network_controller_part_service.GetSettingsResponse` | Unary |
| `GetParameters` | `.aci.network_controller_part_service.GetParametersRequest` | `.aci.network_controller_part_service.GetParametersResponse` | Unary |
| `GetDeviceInstances` | `.aci.network_controller_part_service.GetDeviceInstancesRequest` | `.aci.network_controller_part_service.GetDeviceInstancesResponse` | Unary |

## aci.device_type_service.DeviceTypeService

来源 `Network/device_type_service.proto`；反射初始化 Token `0x060013b1`，descriptor SHA-256 `2ceaa7f99afa1ce77a7f774b8cbaac989455bd460b8cfbdfabfec8f93f5dd638`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetName` | `.aci.device_type_service.GetNameRequest` | `.aci.device_type_service.GetNameResponse` | Unary |
| `GetProtocol` | `.aci.device_type_service.GetProtocolRequest` | `.aci.device_type_service.GetProtocolResponse` | Unary |

## aci.device_instance_service.DeviceInstanceService

来源 `Network/device_instance_service.proto`；反射初始化 Token `0x06001405`，descriptor SHA-256 `4d91e0931f14ce2ed460e4e35da0079a0f3eed1d7d94d3974da45b3fd457853c`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetDeviceInstances` | `.aci.device_instance_service.GetDeviceInstancesRequest` | `.aci.device_instance_service.GetDeviceInstancesResponse` | Unary |
| `GetKind` | `.aci.device_instance_service.GetKindRequest` | `.aci.device_instance_service.GetKindResponse` | Unary |
| `GetName` | `.aci.device_instance_service.GetNameRequest` | `.aci.device_instance_service.GetNameResponse` | Unary |
| `GetSettings` | `.aci.device_instance_service.GetSettingsRequest` | `.aci.device_instance_service.GetSettingsResponse` | Unary |
| `GetParameters` | `.aci.device_instance_service.GetParametersRequest` | `.aci.device_instance_service.GetParametersResponse` | Unary |
| `GetTypeName` | `.aci.device_instance_service.GetTypeNameRequest` | `.aci.device_instance_service.GetTypeNameResponse` | Unary |
| `GetNextFreePosition` | `.aci.device_instance_service.GetNextFreePositionRequest` | `.aci.device_instance_service.GetNextFreePositionResponse` | Unary |
| `GetDeviceTypes` | `.aci.device_instance_service.GetDeviceTypesRequest` | `.aci.device_instance_service.GetDeviceTypesResponse` | Unary |
| `Create` | `.aci.device_instance_service.CreateRequest` | `.aci.device_instance_service.CreateResponse` | Unary |
| `Insert` | `.aci.device_instance_service.InsertRequest` | `.google.protobuf.Empty` | Unary |
| `Delete` | `.aci.device_instance_service.DeleteRequest` | `.google.protobuf.Empty` | Unary |

## aci.library_service.LibraryService

来源 `library_service.proto`；反射初始化 Token `0x06001593`，descriptor SHA-256 `f53d422eb86c28747fd3aee47ed377b4ce468fba7ab3f96b2bdf8bb1a0fd4df6`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetLibraries` | `.aci.library_service.GetLibrariesRequest` | `.aci.library_service.GetLibrariesResponse` | Unary |
| `GetLibraryName` | `.aci.library_service.GetLibraryNameRequest` | `.aci.library_service.GetLibraryNameResponse` | Unary |
| `GetLibraryPath` | `.aci.library_service.GetLibraryPathRequest` | `.aci.library_service.GetLibraryPathResponse` | Unary |
| `GetLibraryType` | `.aci.library_service.GetLibraryTypeRequest` | `.aci.library_service.GetLibraryTypeResponse` | Unary |
| `GetLibraryLoadStatus` | `.aci.library_service.GetLibraryLoadStatusRequest` | `.aci.library_service.GetLibraryLoadStatusResponse` | Unary |
| `GetLibraryComponentCategories` | `.aci.library_service.GetLibraryComponentCategoriesRequest` | `.aci.library_service.GetLibraryComponentCategoriesResponse` | Unary |
| `AddLibrary` | `.aci.library_service.AddLibraryRequest` | `.aci.library_service.AddLibraryResponse` | Unary |
| `AcceptLibrary` | `.aci.library_service.AcceptLibraryRequest` | `.google.protobuf.Empty` | Unary |
| `RemoveLibrary` | `.aci.library_service.RemoveLibraryRequest` | `.aci.library_service.RemoveLibraryResponse` | Unary |
| `ReplaceLibrary` | `.aci.library_service.ReplaceLibraryRequest` | `.google.protobuf.Empty` | Unary |

## aci.iec_type_service.IecTypeService

来源 `iec_type_service.proto`；反射初始化 Token `0x060016f7`，descriptor SHA-256 `54e1421f9bb8800a284ff5af17bcc1d4de8c211cc5e2d7dffe07d64b1c07971c`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetName` | `.aci.iec_type_service.GetNameRequest` | `.aci.iec_type_service.GetNameResponse` | Unary |
| `GetKind` | `.aci.iec_type_service.GetKindRequest` | `.aci.iec_type_service.GetKindResponse` | Unary |
| `GetProgramOrganizationUnits` | `.aci.iec_type_service.GetProgramOrganizationUnitsRequest` | `.aci.iec_type_service.GetProgramOrganizationUnitsResponse` | Unary |
| `DeleteProgramOrganizationUnit` | `.aci.iec_type_service.DeleteProgramOrganizationUnitRequest` | `.aci.iec_type_service.DeleteProgramOrganizationUnitResponse` | Unary |

## aci.controller_type_service.ControllerTypeService

来源 `controller_type_service.proto`；反射初始化 Token `0x06001797`，descriptor SHA-256 `1263fc87972ff3ec0f869e37b9a367096a8407a04ab13eecc4c0e30475445a39`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetArticleNumber` | `.aci.controller_type_service.GetArticleNumberRequest` | `.aci.controller_type_service.GetArticleNumberResponse` | Unary |
| `GetProductFamily` | `.aci.controller_type_service.GetProductFamilyRequest` | `.aci.controller_type_service.GetProductFamilyResponse` | Unary |
| `GetProductName` | `.aci.controller_type_service.GetProductNameRequest` | `.aci.controller_type_service.GetProductNameResponse` | Unary |
| `GetVendor` | `.aci.controller_type_service.GetVendorRequest` | `.aci.controller_type_service.GetVendorResponse` | Unary |
| `GetVersion` | `.aci.controller_type_service.GetVersionRequest` | `.aci.controller_type_service.GetVersionResponse` | Unary |

## aci.controller_service.ControllerService

来源 `controller_service.proto`；反射初始化 Token `0x0600185d`，descriptor SHA-256 `1d7d4db6381888fff86d7147ee41c10d8fc3953875c46c80daef64f9ee3b23d2`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetName` | `.aci.controller_service.GetNameRequest` | `.aci.controller_service.GetNameResponse` | Unary |
| `GetTypeName` | `.aci.controller_service.GetTypeNameRequest` | `.aci.controller_service.GetTypeNameResponse` | Unary |
| `GetControllerParts` | `.aci.controller_service.GetControllerPartsRequest` | `.aci.controller_service.GetControllerPartsResponse` | Unary |
| `ExportDataList` | `.aci.controller_service.ExportDataListRequest` | `.aci.controller_service.ExportDataListResponse` | Unary |
| `ImportDataList` | `.aci.controller_service.ImportDataListRequest` | `.aci.controller_service.ImportDataListResponse` | Unary |
| `Replace` | `.aci.controller_service.ReplaceRequest` | `.google.protobuf.Empty` | Unary |

## aci.controller_part_service.ControllerPartService

来源 `controller_part_service.proto`；反射初始化 Token `0x0600193d`，descriptor SHA-256 `637ecb2f25f176beb5e2e63dacef68f50b9a65ee5dc9025f47bb9646d7d3e80e`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `GetKind` | `.aci.controller_part_service.GetKindRequest` | `.aci.controller_part_service.GetKindResponse` | Unary |
| `GetDisplayName` | `.aci.controller_part_service.GetDisplayNameRequest` | `.aci.controller_part_service.GetDisplayNameResponse` | Unary |
| `GetName` | `.aci.controller_part_service.GetNameRequest` | `.aci.controller_part_service.GetNameResponse` | Unary |
| `GetTypeName` | `.aci.controller_part_service.GetTypeNameRequest` | `.aci.controller_part_service.GetTypeNameResponse` | Unary |

## aci.application_control_service.ApplicationControlService

来源 `application_control_service.proto`；反射初始化 Token `0x060019dd`，descriptor SHA-256 `098075c1b467104309c91cbad64b059da08da7e1b107330ff945f856bcd208ff`。

| RPC | 请求 | 响应 | 模式 |
| --- | --- | --- | --- |
| `IsInitialized` | `.google.protobuf.Empty` | `.aci.application_control_service.IsInitializedResponse` | Unary |
| `IsAvailable` | `.google.protobuf.Empty` | `.aci.application_control_service.IsAvailableResponse` | Unary |
| `Shutdown` | `.google.protobuf.Empty` | `.google.protobuf.Empty` | Unary |
| `GetProductName` | `.google.protobuf.Empty` | `.aci.application_control_service.GetProductNameResponse` | Unary |
| `GetProductVersion` | `.google.protobuf.Empty` | `.aci.application_control_service.GetProductVersionResponse` | Unary |
| `GetProductBuild` | `.google.protobuf.Empty` | `.aci.application_control_service.GetProductBuildResponse` | Unary |
| `GetExecutablePath` | `.google.protobuf.Empty` | `.aci.application_control_service.GetExecutablePathResponse` | Unary |
| `GetApplicationControlVersion` | `.google.protobuf.Empty` | `.aci.application_control_service.GetApplicationControlVersionResponse` | Unary |
| `GetStates` | `.google.protobuf.Empty` | `.aci.application_control_service.GetStatesResponse` | Unary |
| `GetProcessId` | `.google.protobuf.Empty` | `.aci.application_control_service.GetProcessIdResponse` | Unary |
