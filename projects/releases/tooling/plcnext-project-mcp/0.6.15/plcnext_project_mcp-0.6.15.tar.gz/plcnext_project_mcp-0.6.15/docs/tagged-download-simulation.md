# Tagged RSC 下载链路：持久内存 TLS 验证

2026-10-26。本轮新增 [binary_download_tagged.py](../src/plcnext_mcp/binary_download_tagged.py)，与旧 untagged loopback 分开。`TaggedBinaryLoopbackController` 复用 `execute_download` 的服务接口，在同一个 `MemoryTlsPair` 上实际交换 **RSC v4 data-tagging / no-datagram** 消息。没有 socket、目标地址或真实设备写入入口。

## 已完成的二进制链路

1. Connect 广告 tagging/datagramming，模拟服务端只确认 tagging；客户端拒绝 untagged 或其他未知协商。
2. 通过 TLS 发送四个固定服务名的 GetServiceHandles，动态获取每个服务 handle 和 provider handle，不硬编码真实设备观测值。
3. CreateSession 使用 `utf8 / secure_utf8` 标签，读取 boxed UInt32 security token、penalty 和错误码；零 token 保留为有效 token。
4. 文件和 PLC 调用携带 `0x48` authenticated-tagged header；参数和返回值均由固定 schema 编解码，并验证 invocation `FF` 终止。不是给旧 untagged 值体简单设置标志位。
5. GetSupportedTraits、符号工程根目录解析、空间查询、WriteMany、ReadMany、Reset(true)、Load(true)、GetPlcState 和 CloseSession 全部走该持久 TLS 通道。
6. WriteMany 后以 SHA-512 核对回读，再按模拟策略清理旧文件、Reset/Load 并轮询状态；没有 Start。

| 服务方法 | 请求 schema | 返回 schema |
| --- | --- | --- |
| Password.CreateSession(1) | utf8, secure_utf8 | security_token, int32 penalty, int32 error |
| Password.CloseSession(2) | security_token | 空值序列 + FF |
| File.WriteMany(8) | write_file[] | int32[] |
| File.ReadMany(9) | read_file_info[] | read_file_data[] |
| FS.GetSupportedTraits(1) | 空值序列 + FF | int32 |
| FS.GetFileSystemTraitsEntry(5) | int32 traits, utf8 path | filesystem_traits_entry, int32 result |
| FS.GetSpaceInfo(6) | utf8 path | space_info, int32 result |
| PLC.Load(1)/Reset(4) | bool | 空值序列 + FF |
| PLC.GetPlcState(5) | 空值序列 + FF | uint32 |

固定类型/DTO 的原厂纯 MemoryStream 字节证据和范围见 [tagged codec 报告](rsc-tagged-implementation.md)。服务发现保留原始名称字符串编码，不是 typed invocation；其确认 header 仍为 data-tagging=true。

## 实际已生成 61 POU 包的离线验证

复用之前生成且与当前源/冷构建/运行映射绑定的 NativeGateway 包，并由 `_package_snapshot` 重新核验收据、逐文件哈希、运行配置、CIL/原生类型绑定和镜像。没有重新冷编译，也未修改包。

- 工程副本：`24230ab9954e4bafbbc4510ad7b2b813`，source SHA-256 `21ad11250eed27b5fd0a1fe594f27a1949dcedf1d33c6af661f416cf25bf7230`。
- 包：`db12b9f244a7417984c1f02f3bd72f1b`，48 文件，9,370,814 字节。
- 真实内存 TLS 1.2 交换：20/20 次完成，其中 4 次 tagged 服务发现、15 次 tagged 方法调用。
- 整文件写入、回读和最终模拟文件集合与包逐字节相同；模拟配置加载完成，程序未启动。
- 证据：[result.json](../artifacts/tagged-download-simulation/result.json)。报告不保存密码、用户名、安全 token 或文件明文。

## 测试

[test_binary_download_tagged.py](../tests/test_binary_download_tagged.py) 的 8 项测试通过。测试期间 Python socket 创建和连接函数被显式阻断。

- 捕获实际 TLS 前后的完整消息，在内存中核验 `0x40/0x48` header、typed array/struct/tag、SecureString tag `0x24`、SecurityToken `0x27/0x09`、bool/UInt32 和 FF；拒绝旧 untagged 消息。
- 完整成功顺序和零 token；随机动态服务及 provider handle。
- 大于 2 MiB、超过 128 个 TLS 明文 record、包含全部 0..255 字节的文件实际写入和回读，不靠搜索 FF 定界。
- 15 个既有故障场景，含认证/会话过期/权限/空间/部分结果/不确定写入/回读损坏/Reset 或 Load 超时和 TLS 证书错误，均保留失败及不重试语义。
- 错标签、缺终止、错 provider/service/method、错 token、坏 checksum、datagram、返回类型/额外值、未知 error profile 和不安全路径均拒绝。
- 正常或不确定 CloseSession 后清理本地凭据、token、句柄及 TLS 对象；失败不会宣称未发生过写入。

运行：`python -m unittest discover -s tests -p test_binary_download_tagged.py -v`。

## 保留的边界

`get_permissions` 和旧文件集合 reconcile 是明确的模拟应用策略，未伪装为恢复了对应远程 RPC。服务端失败时 boxed UInt32(0) 是模拟器选择，不代表真实固件所有失败返回；权限值仅支持一个可选 Permissions trait。真实 RSC ERROR 命令(4)、通用流式定界、任意 DTO/null/multidimensional array/datagram 均未实现，遇到这些情况拒绝处理。

MemoryBIO TLS 使用公开测试 CA/证书，验证的是持久本地 TLS 中的 tagged 字节和编排；不是实际 PLC 的 TLS、权限、文件写入、配置接受或运行实测。此前 `192.168.0.8` 的 tagged GetPlcState 只读成功不能扩展为下载兼容性已验证。`controller_connected`、`controller_downloaded`、`deployable` 和 `program_started` 继续为 false。
