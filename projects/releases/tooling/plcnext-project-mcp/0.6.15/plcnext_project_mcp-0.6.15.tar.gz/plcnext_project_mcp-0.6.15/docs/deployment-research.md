# PLC 下载链路的 REA 分析与离线实现

> 最新进展：认证、文件传输和配置加载的离线模拟已实现，新增两个工具，服务现有 25 工具。RSC 固定头/文件值 codec 与原厂字节向量匹配，并通过内存 TLS 和 16 场景 MCP 验证。完整网络协议/真实 PLC 通道尚未启用，详见 [下载链路离线验证](plc-download-simulation.md)。

> 后续进展：已完成当前 61 POU 副本的完整离线 PCWE 生成，新增 `project_generate_pcwe`，本机注册服务现有 23 个工具。见 [当前验证记录](pcwe-cold-build.md)。下面保留此前部署准备阶段的证据；其中“未实现完整包”的描述仅指该历史阶段。控制器传输仍未实现。

2026-10-25；安装版本 PLCnext Engineer 2026.0.4 / 9.0.373.0。

本轮定位了文件部署、配置加载、原生库和完整性清单的底层实现，并新增三个可调用的 MCP 工具。
**目前实现的是部署准备；尚未实现从冷编译直接生成完整运行工程，也未实现控制器传输。**
所有实际操作限于本地副本、冻结产物和已安装 DLL 的静态读取。没有连接、停止、启动或写入 PLC，
没有调用 ACI、修改许可或运行 Engineer 界面。

## 本轮可调用能力

| 工具 | 输入 | 实际结果 |
| --- | --- | --- |
| `project_deployment_plan` | 工程 ID、当前工程 SHA-256、冷构建 job ID | 核对工程、编译源清单、输入和输出哈希，报告缺失的 PCWE 文件及原生库候选 |
| `deployment_inspect_pcwe` | 已有完整 PCWE 本地目录 | 检查基本配置、清单路径与逐文件 SHA-512，分别报告整体哈希和签名验证状态 |
| `deployment_stage_pcwe` | PCWE 目录、检查返回的 inventory SHA-256 | 在 MCP workspace 下建立新的完整目录副本，回读验证所有文件字节 |

`project_deployment_plan` 同时核对工程归档成员与编译器真正读取的 `sources/`、`sources.xml`，
避免两个来源不同的工程树被当作同一次构建。工具不会选择未验证兼容性的原生库版本。
暂存工具保留原 manifest 和签名字节，不用新 IMG 覆盖旧工程包、不重签名、不生成 DAuM ZIP。
三项工具均不能证明目标设备接受此包；`deployable` 保持 `false`。

已注册的全局 MCP 使用 editable 安装，重启该 MCP 进程或新建加载它的会话后会发现新增工具。
本轮未改动 Codex 注册配置；使用原注册的 command、args、env 从仓库外目录启动真实 stdio 客户端，
已发现全部 **22** 个工具。

## 实测证据

[真实 MCP 结果](../artifacts/deployment-mcp-e2e/d0fd84eb554943c3ba6f5bf9c735cee6/result.json)：

- 当前 61 POU 工程副本：`a431bdc32f2a4aa1812c94683db38395`，构建 `21ecd6da142147329a4053e1363a6adb`。
- 工程 SHA-256：`e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0`。
- 452 项构建输入和 170 项输出哈希通过核对；这是对既有成功冷构建的复核，本轮没有再次编译。
- 该构建仍缺 7 个基本 PCWE 文件，包括运行目录中的镜像、Domain/ESM/GDS/PLM 配置和两个清单。
- 引用库内发现 AXCF2152 的 `2025.0.3`、`2026.0.2` 两个原生 SO 候选，均未自动选用。
- 冻结 GUI 包的 47 项 manifest 文件哈希通过，含 manifest 共 48 个文件逐字节暂存成功。
- 暂存位置：`D:\PLCnext-MCP-Workspace\deployment-staging\pcwe-stage-f5bc61309a914323a867b7ea9faab712\PCWE`。
- 拒绝把冷构建的 `generated` 目录当成完整 PCWE；拒绝旧 inventory 哈希；原冻结包未变。

详细记录：[61 POU 缺口](../artifacts/deployment-mcp-e2e/d0fd84eb554943c3ba6f5bf9c735cee6/61-pou-plan.json)、
[完整包检查](../artifacts/deployment-mcp-e2e/d0fd84eb554943c3ba6f5bf9c735cee6/pcwe-inspection.json)、
[暂存结果](../artifacts/deployment-mcp-e2e/d0fd84eb554943c3ba6f5bf9c735cee6/pcwe-stage.json)。

运行 `.venv\Scripts\python.exe -m unittest discover -s tests -q`：97 项，96 通过，1 跳过，18.328 秒。
跳过项需要 Windows 创建符号链接权限；不能将它记为已经通过。新增测试覆盖载荷篡改、源树不一致、
清单缺项、重复输出、路径穿越、旧哈希及嵌套设备 profile。合成测试数据只测试校验逻辑，不作为真实编译证据。

## 已观察到的底层调用

静态方法体说明 Engineer 的实现路径，尚不等于我们已经完成可用的协议客户端。

| 模块和方法 | token | 观察 |
| --- | --- | --- |
| `Ade.Online.PlcNextImpl / FileAccessServiceAdapter.WriteRemoteFilesCore` | `0x0600018a` | 使用 RSC `IFileService2` 和 `WriteFileData`，另有旧 `IFileService` 路径 |
| 同模块 `ResolveSymbolicPathCore` | `0x0600017d` | 查询文件系统 traits，不能假定所有符号路径都可按 Linux 路径直接拼接 |
| 同模块 `DeviceControlServiceAdapter.LoadConfigurationCore` | `0x06000043` | 调用 `IPlcManagerService.Reset(Boolean)`，随后 `Load(Boolean)` |
| 同模块 `ChangeConfigurationCore` | `0x06000045` | 另有 `IPlcManagerService2.Change(Boolean)` 路径，不能和普通完整下载混用 |
| `Ade.Plc.EclrImpl / EclrDownloadHelper.PrepareForDownload` | `0x0600007c` | 准备镜像及下载条目、扩展清单，包含条件化的最终链接和签名处理 |
| 同模块 `DownloadToFileSystem` | `0x0600006c` | 经安全服务上下文取得虚拟文件系统，写文件后 SaveAsync；正常权限仍参与流程 |
| 同模块 `FinalizeImage` | `0x06000062` | 某些 in-flash 分支读取目标 NativeLibs 并检查原生签名；不能推广成所有目标均需要此步骤 |
| `Ade.Compiler.PlcNextImpl / GenerateConfigurationFolder` | `0x0600002d` 等 | 收集 eCLR、原生库、PLCnext 库、控制器、I/O、OPC UA、HMI 等配置，不只是复制 IMG |

因此复现部署至少包含三个相互独立的部分：从当前工程生成完整 PCWE；建立经过认证的传输；
按设备状态选择加载/切换流程并回读确认。当前只完成了第一部分的检查和已有包暂存。
还没有确定 RSC 的完整连接、认证、协商和错误恢复契约，不能把已找到的接口名称当成协议已仿写成功。

## 已复现的哈希规则及边界

`Ade.Security.Project.ProjectIntegrity.ComputeOverallHash`，token `0x06000028`：
按照调用方提供的顺序，将每个文件哈希的十六进制文本按 ASCII 追加到增量哈希中。
样本 manifest 使用 SHA-512，本实现也仅支持这个已观察到的算法。

`CreateManifestConfigFile`，token `0x06000023`：XML File 元素按路径排序，但整体哈希取原字典的 Values 顺序。
部署文件收集使用 `ConcurrentDictionary`，所以 XML 中的顺序未必能还原原始整体哈希输入顺序。
新 Python `overall_hash` 实现了顺序敏感的计算规则，使用独立已知 SHA-512 向量检查。
实际冻结包逐文件哈希匹配，但按 XML 顺序无法复核其整体哈希，报告为 `unknown_order`。
这也不能排除整体哈希字段本身被改动；工具不会据此标记包的完整性或签名全部有效。

## 原生库和映射缺口

GUI 包中的 `libIIoT_Library.so` 有 4,320,156 字节，对应库包的 AXCF2152/2026.0.2 成员，
SHA-256 为 `12b5d548fe20ddef4ef709bfac998f076efde206a7e264da930e5a46f452b44d`。
工程设备 profile 为 2026.0.0；这说明原生库兼容选择不能简单要求版本字符串相等。
目前仅报告候选，尚未重写厂商的兼容选择规则。

已有冻结包的 GDS Connectors、ComponentTaskRelations 和 PLM Libraries、Components 为空。
它足以验证文件格式和传输准备，不足以验证非空 I/O/GDS 映射生成。
工程源 DataList/ESM/I/O 的字节保留，也不能证明新变量对应的运行时映射已更新。
更多目录内容和证据见 [部署包审计](deployment-package-audit.md)。

## 证据定位与复核方法

通过 REA `inspect_managed_artifact`、`inspect_managed_members` 获取元数据和方法证据；
补充工具 [Inspect-ManagedIl.ps1](../tools/Inspect-ManagedIl.ps1) 用 Mono.Cecil 静态读取选定方法体。
目标 DLL 没有被执行；JSON 保留输入 SHA-256、MVID、方法 token 和指令偏移。
REA 成员枚举整体标记为 partial，结论限定到已检查的方法，不能解释为审计了整个产品。

| 证据 | REA evidence ID |
| --- | --- |
| [Online 元数据](../artifacts/deployment-research/rea-online-inventory.json) | `ev_1c141e205ca7933c3afbe93518fad17df7d3b84c44b1901710a21a1bb7e39688` |
| [Online 成员](../artifacts/deployment-research/rea-online-members.json) | `ev_927a702fc75e2a499c6519b5a8cbe857342f4e405c8fba85de507f6a10615352` |
| [Compiler 成员](../artifacts/deployment-research/rea-compiler-members.json) | `ev_3a0447c0b59b19aee5c214f77385144e1af9e7fa368212c6fc317bc09cc8c86f` |
| [完整性成员](../artifacts/deployment-research/rea-integrity-members.json) | `ev_052996f186783df43bdb9dd9d06ab01dda9b5d61b59f084847e63f657054f550` |
| [eCLR 下载成员](../artifacts/deployment-research/rea-eclr-download-members.json) | `ev_5ebb602aa8547162eb32d3bd487b3d68595f9443411f231c267bd3ee6c229e88` |

补充完整选定方法体：
[Online](../artifacts/deployment-research/online-selected-il.json)、
[Compiler](../artifacts/deployment-research/compiler-selected-il.json)、
[完整性](../artifacts/deployment-research/integrity-selected-il.json)、
[eCLR 下载](../artifacts/deployment-research/eclr-download-il.json)。
例如 Online DLL SHA-256 为 `7bbd75c0853220ccd262b9e9fdbec2b2d046e9a34e11bc1a405e94b22091d7ed`，
MVID `f21f585b-05d7-44ad-81a3-4fbc40079661`，可将 REA 元数据与补充指令文件绑定。

## 外部资料与后续实现顺序

[官方软件更新导出文档](https://engineer.plcnext.help/latest/DAuM_Export.htm)说明软件包包含元数据和构建内容，
尚不能据此推断完整 ZIP 布局；应补充真实导出包作为独立样本。
[官方论坛 2023 年回复](https://forum.plcnext-community.net/t/downloading-plcnext-engineer-project-without-affecting-already-existing-tic-and-gds-files/10008)
描述复制整个 PCWE 目录的方式；
[2024 年回复](https://forum.plcnext-community.net/t/uploading-pcwex-files-from-linux-computer/9051)
仍将 Engineer/DAuM 作为支持路径。因此没有把简单 SFTP 复制包装成已受支持、已验证的通用下载。

下一步优先复现同一版本工程的 Domain/ESM/GDS/PLM 配置生成、原生库选择和清单生成，
以完整 GUI 包逐文件及语义对照；非空映射必须有对应样本。随后实现认证传输和状态机，先用本地协议模拟器验证。
真实设备验收需另行明确授权和目标设备信息；当前没有执行该阶段。
