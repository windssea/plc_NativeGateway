# 离线运行布局的独立审查与负例

2026-10-25。只读取当前 NativeGateway 管理副本和已冻结的离线布局结果；所有篡改仅在 Python 内存或新临时目录进行。

审查入口：`runtime_layout.validate_runtime_layout`、`finalize_runtime_types`，以及
`compile_host/FinalizeRuntimeTypes.cs`、`Invoke-FinalizeRuntime.ps1`。

独立测试文件 `tests/test_runtime_layout.py` 共 **23 项全部通过**。真实正例确认 192 个类型、77 个全局变量、
10 个 HMI 映射、109 个 FB 实例和 MainInstance 的资源/任务字段绑定。最终记录见
[测试报告](../artifacts/pcwe-runtime-research/runtime-layout-test-report.json)及
[逐项日志](../artifacts/pcwe-runtime-research/runtime-layout-tests.log)。报告同时记录被测源码与输入证据 SHA-256。

## 审查发现并由主代理修复的问题

1. 变量 Id、HMI 映射清单和 ESM task/program 报告最初仅被当作输入事实，缺少与 PCWEX 的重新绑定。
   现已从当前成员重建运行配置，并核对变量、HMI、程序、任务和关系五项语义。
2. 结构体只比较字段 offset，字段类型/集合遗漏能够通过。现已交叉核对 CIL 字段集合、FieldType/FieldRuntimeType、
   native 非空字段类型、结构大小以及字段存储范围。
3. FB 实例只检查非负 offset，native 类型或 static 标志变化未被拒绝。现已与 CIL 对照，
   非 static 字段起点超出 native class size 也会拒绝。
4. 任务实例只查 CIL type，未检查 static 或 native 实例字段。现已同时检查 resource/task 的 CIL 与 native 字段。
5. 元数据辅助进程原来只绑定 IMG 与 TypeInformation，而 Cecil 还读取目录内 DLL/EXE。
   现已要求与 cold-build 的完整 CIL 输出清单一致，并在辅助进程前后复核所有真实输入哈希。

对应测试覆盖：结构 offset/type/field-set/size，global type/offset/Id，HMI Id/遗漏，任务关系遗漏、周期报告篡改、
static 标志和 native 实例缺失，FB native 类型/storage/负 offset/正越界 offset、CIL 实例遗漏及源声明变化。
额外三个测试确认过期 CIL、未列出的 EXE 均在启动 host 前拒绝，读取期间 CIL 改动也能被回读发现。

## 能证明的范围

这证明源身份、静态 CIL 字段和该本地 IMG 的解析布局在已检查范围内一致；地址是本地镜像元数据的 offset，
不是连接控制器后取得的实时地址。测试不证明 PLC 执行结果、实时调度、物理 I/O 或网络行为。
本次审查没有独立重跑 vendor 元数据辅助进程；真实正例使用主代理已生成的
`artifacts/pcwe-build-research/finalized-types-06` 冻结证据。辅助进程输入绑定负例以模拟返回值测试，
没有执行这些合成 IMG/DLL 字节，也未修改原始冻结证据。
