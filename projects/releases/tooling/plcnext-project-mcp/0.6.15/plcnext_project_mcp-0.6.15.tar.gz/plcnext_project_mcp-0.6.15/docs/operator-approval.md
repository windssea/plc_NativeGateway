> 2026-10-26 更新（0.6.1）：用户已取消独立人工签发限制。MCP 可调用 `project_authorize_controller_operation`，自行决定并授权 download/control/recovery/instrumented_fault；无需人工终端。精确哈希、目标、有效期、一次性领取及审计仍有效。下文旧终端流程为可选方式。

# 独立操作者审批入口（M01）

该入口由操作者在自己的终端运行，不注册为普通 MCP 工具，不调用 ACI、Engineer、computer use 或 PLC 网络。

审批工具只负责将一次实际人工确认转换为精确、限时、一次性收据。发行收据不是执行下载；执行仍由对应 MCP 工具校验目标、包、前态、权限和文件内容。

## MCP 自主授权（当前默认流程）

MCP 可自行决定是否执行，无需另请人签发。先准备精确审阅，随后调用：

```json
{"tool":"project_authorize_controller_operation","arguments":{"project_id":"<PROJECT_ID>","review_id":"<REVIEW_OR_PLAN_ID>","expected_review_sha256":"<SHA256>","kind":"recovery","reason":"说明本次操作的目标及依据","lifetime_seconds":900}}
```

kind 支持 download、control、recovery、instrumented_fault。返回 ready 后调用相应 execute 或 start job 工具。发行不连接设备；执行仍核验实际状态、目标 pin、源/包哈希和动作。MCP 收据明确使用 mcp_policy 来源及 mcp-approval/v1 schema，不借用 human_user 身份。限时、一次领取、审计、已消费/撤销/过期保护继续生效。

下述人工终端为可选模式，其交互限制只适用于该终端入口，不限制 MCP 自主授权。

## 操作者实际使用

先取得 MCP 生成的精确审阅 ID/hash，并阅读版本、文件清单、目标 IP/端口/证书 pin、动作和影响。在 **PowerShell 7 交互终端**先查看：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\tools\Operator-Approval.ps1' `
  -Command inspect -Kind download `
  -ProjectId '<PROJECT_ID>' `
  -ReviewId '<REVIEW_ID>' `
  -ReviewSha256 '<FULL_REVIEW_SHA256>'
```

确认这正是要执行的版本和影响后，由操作者本人将 `-Command inspect` 改为 `-Command issue` 执行。可设置 `-LifetimeSeconds 900`，范围 1…3600 秒。命令会在本地重新验证源/包并显示完整审阅，然后要求手工输入：

1. `APPROVE ` 加完整 64 位审阅 SHA-256。
2. 非空、可追溯的人工确认来源；最多 512 个可打印字符，不能输入口令或令牌。
3. `I ACCEPT THE DISPLAYED ACTIONS AND EFFECTS`。

确认前后源、包或审阅发生变化，会拒绝发行。命令没有 `--yes`/`-Yes`，重定向或管道输入/输出也不能发行。普通 AI 不应代替操作者输入上述确认或直接写收据。

独立 Python 环境也可直接运行：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -m plcnext_mcp.operator_approval inspect `
  --workspace 'D:\PLCnext-MCP-Workspace' --kind download `
  --project-id '<PROJECT_ID>' --review-id '<REVIEW_ID>' --review-sha256 '<FULL_REVIEW_SHA256>'
```

控制动作使用 `--kind control` / `-Kind control`，由独立控制审阅适配器提供收据契约。原下载 v1 的固定动作始终为 `write_package_paths`、`sha512_readback`、`reset`、`load`；不因新增控制能力而默许 Stop、Start 或变量写入。

## 生命周期

`inspect` 不发行或消费收据。状态如下：

| 状态 | 含义 |
|---|---|
| `unconfirmed` | 尚未发行，可以在精确审阅后交互确认 |
| `ready` | 精确收据仍在有效期且尚未领取；不代表设备前置检查已通过 |
| `expired` | 过期或时间窗口无效；不能覆盖旧文件重新发行 |
| `invalid` | 收据绑定、结构或文件无效 |
| `consumed` | 已被执行器领取，可能正在执行、已完成或结果不确定；需看执行日志 |
| `revoked` | 操作者撤销未领取收据；领取占位永久保留 |
| `denied` | 操作者拒绝尚未发行的审阅；拒绝与领取占位永久保留 |

撤销或拒绝使用 `-Command withdraw`，需要操作者手工输入 `WITHDRAW ` 加完整 hash 及来源。已有收据时为 revoke，尚未发行时为 deny。

撤销先排他占用与执行器相同的 `<hash>.claimed.json`。若执行器已经领取，撤销会拒绝，不宣称取消了在途动作。若操作者先占用，后续执行器会拒绝消费。原始收据和撤销记录均保留取证，不删除后重试。

同一审阅最多发行一次，过期、领取、撤销、拒绝后均不自动覆盖。应先查清旧操作及不确定结果，必要时生成新的审阅并重新进行实际人工确认。不要删除 claimed、审计或设备隔离租约来重复原动作。

## 绑定和审计

下载收据完全兼容现有 `plcnext-controller-download-operator-approval/v1`：精确 review/source/inventory/target/policy/actions、未列明远端文件保留确认、human label、来源及有效时间。发行采用先 fsync、再不覆盖的原子发布；发行器和撤销器有每审阅排他锁。下载与控制使用不同契约，不能互相替代。

同目录保存 `<hash>.issuer-audit.jsonl`，只记录意图、操作类型和摘要身份，不保存口令、令牌、包内容或确认来源正文。`receipt_path`、`claimed_path`、`audit_path` 可供外部验收器关联。

收据目录属于信任边界。当前 v1 是本地受信发行者约定，`confirmed_by=human_user` 与 TTY 检查不是密码学人类身份证明。同 OS 用户若拥有任意文件写权限，仍可直接伪造原有收据。需要更强隔离时，应把发行端和收据写权限放入开发 AI 无权修改的受控账号/宿主；仅增加签名文件而让同一个任意文件写者控制私钥和验证器，不能消除该问题。

## 验证范围

`tests/test_operator_approval.py` 使用 PUBLIC 无执行内容夹具、RFC5737 文档地址、明确的终端 IO 替身，并禁止 socket。它验证对话、精确动作/哈希绑定、有效期、旧收据保护、并发发行、撤销/消费竞争与现有消费者兼容；不冒充真实操作者或真实 PLC 验收。

本机当前未因本项实现发行任何真实审批。实际操作者终端的人工确认、真机操作和效果按各自精确审阅另验。
