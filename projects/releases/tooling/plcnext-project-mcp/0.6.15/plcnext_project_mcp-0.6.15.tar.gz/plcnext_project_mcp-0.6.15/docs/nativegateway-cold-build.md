# NativeGateway 全 POU、变量接口和冷构建

本文保留全 POU / 变量接口阶段的验证记录。后续已解除固定原件限制并加入新建工程、
FB 增删及通用冷编译，当前能力以 [工程生命周期验证](project-lifecycle.md) 为准。

日期：2026-10-23。已验证版本：Engineer 2026.0.4 / 9.0.373.0，AXC F 2152 v2026.0.0。

## 当前结果

**自有 MCP 已支持 NativeGateway 的全部 14 个 FB、16 个函数和 1 个主程序的代码与变量声明更新，并可从工程源文件冷构建 IEC 镜像，无需工程 AST 缓存种子、ACI、Engineer GUI 或 computer use。**

它仍使用本机厂商编译库、安装包中的标准库及工程引用的 IIoT 库。冷构建是重新建立本样例的 IEC 编译模型，不是重新实现编译器，也不包含完整硬件、HMI、签名及部署包构建。

## MCP 调用

推荐流程：

1. `project_import_copy` 导入本次冻结 NativeGateway 原件的副本。
2. `project_read_pou` 获取代码、变量及两份工作表 SHA-256。
3. `project_update_pous` 一次提交受影响 FB/函数/主程序的 `code`、`variables` 完整文本。接口和调用者可以同批提交；整个批次只生成一个版本。
4. `project_diff_pou` 查看代码和变量各自的差异，`project_validate` 检查其余成员载荷是否保留。
5. `project_compile_nativegateway(project_id, expected_project_sha256)` 执行冷构建，`mode` 默认 `cold`。

每个更新项的格式：

```json
{
  "pou_name": "NG_ReadAck",
  "expected_code_sha256": "读取结果中的当前代码哈希",
  "expected_variables_sha256": "读取结果中的当前变量哈希",
  "code": "完整的新 ST 代码",
  "variables": "完整的新变量声明"
}
```

`code`、`variables` 至少提供一个；两份旧哈希均必须提供。不要把示例中的占位文字作为实际哈希。修改命名参数后，需要同步更新调用处；编译器会拒绝遗漏或类型不匹配。

可修改现有变量工作表中的局部、输入、输出和 IN_OUT 声明。已有 POU 的种类、函数 ReturnType 元数据、根类型定义、任务、I/O 和 HMI 本轮仍保持不可修改。没有增加或删除 POU 的接口。

`mode="cached"` 保留较早的部分冷构建路线，它仍需要种子，但同样重新解析全部 POU 和声明。`project_compile_cached` 是更早的单 FB 验证工具；新开发应优先使用默认冷模式。

## 冷构建实际输入

冷分支不调用 `_verified_seed` 或 `ArchiveReader.ReadFile`，没有复制 `LastBuild.ast` 或旧应用 DLL。每次请求在独立目录中完成：

1. 从当前 PCWEX 副本复制工程源文件，校验原件身份和本次版本哈希。
2. 从安装目录的 IEC、Extended、Safety、PLCnext Controller、工程引用的 IIoT 库包以及 `eCLR Core.zip` 独立提取库 DLL。真实 `AssemblyParser` 重建库声明；没有反射执行这些库的 PLC 代码。
3. 用真实解析器重新解析根 `.dt` 类型、资源全局变量、I/O 声明；从工程 XML 重建配置、资源、`Cyclic100` 和 `MainInstance`。
4. 从全部 31 个 POU 的 Metadata、Variables.var、Code.st 创建新的 POU、接口、局部变量和代码 AST。基线包含 610 个源码变量、58 个匿名类型。
5. 执行 `ForceCheck=True` 的真实语义分析，使用其返回的新编译模型生成全新的 33 个应用 CIL 模块，再调用 ARM Thumb-2 后端生成 `.img/.dbg`。

安装和引用库的原始包路径、包 SHA-256、提取成员和 DLL SHA-256 都写入报告。当前依赖清单有 6 个包来源、54 个提取记录。预编译标准库是编译依赖；它们不是本工程以前的编译产物。

新分析模型会另存为当前任务的输出 AST，供检查使用；这不构成对旧 AST 的输入依赖。编译宿主最多运行 30 秒，原生后端最多 15 秒。任何阶段失败都不会报告成功；语法和语义失败不会启动原生后端。

## 实际验证

| 验证 | 结果 |
|---|---|
| 将种子环境变量指向不存在的路径，真实 MCP 调用省略 mode | 默认 cold，仍成功生成镜像；输入目录没有 AST |
| 基线 31 个 POU 全源重建 | 语法、语义均 0 错误、0 警告 |
| 同次修改全部 31 个 POU 的代码和局部变量 | 成功，62 个源成员变化，其他成员字节相同 |
| 为 NG_ReadAck 新增 BOOL 输入 McpGate，Main 同步传 TRUE | 成功，生成的 CIL 确实包含新字段和调用赋值 |
| 14 个 FB / Main 的新 UINT 字段；16 函数的新 UINT 局部及各自常量 | 对生成的 CIL 静态检查全部通过 |
| Main 为 BOOL 参数传入 NG_Document | `SEM1117`，无镜像、未启动后端 |
| FB 参数改名而调用处不改 | `SEM1115`，无镜像、未启动后端 |
| 变量声明缺冒号 | `VAR0007`，无镜像、未启动后端 |
| 旧版本哈希请求 | 拒绝，不编译错误版本 |
| 元数据、ID、DataList、ESM、I/O 文件 | 副本中载荷保持相同；原件没有覆盖 |

ESM 中周期 `20000000 ns`、看门狗 `500000000 ns` 分别转换为模型的 `20 ms`、`500 ms`。另以 GUI 旧产物作只读对照，验证单位一致；这些旧产物没有参与冷构建。

最终对同一 B581 工程副本冷构建与 GUI 输出进行独立静态比较：**33 个应用模块、202 个方法的签名、逐条 IL、局部变量、异常区域及已检查类型/字段布局一致**。没有应用命名空间规范化。文件哈希并不相同，MVID、PDB 和所有元数据不在该等价声明之内；更没有以此声明整个原生镜像或 PLC 运行行为完全相同。

结果与来源：

- [最终默认冷模式 MCP 验证](../artifacts/final-cold-proof/mcp-report.json)、[编译记录](../artifacts/final-cold-proof/build-result.json)、[GUI 与冷构建静态比较](../artifacts/final-cold-proof/gui-to-final-cold-il-comparison.json)。
- [全部 POU 与接口的冷模式正反验证](../artifacts/cold-compile-mcp-e2e/dcf8c4ec58c5493eb0007109bfd96188/result.json)。
- [缓存模式正反验证](../artifacts/expanded-compile-mcp-e2e/11dbc18bdf364b7893f11652cec5b47c/result.json)。
- [变量和 POU 重建证据](../artifacts/expanded-compile/variables-research/findings.md)、[无 AST 工程骨架、库及任务证据](../artifacts/cold-build-research/README.md)。

## 当前边界

只接受固定 NativeGateway 原件 SHA-256 `b78ba0efd0f8f79558143d58f3eb141512876690b2eda2a641e96ba3a3cbaddf` 派生的副本；项目结构和设备配置不可任意改动。冷路径已解除对工程缓存种子的依赖，但没有推广为任意 PCWEX / 任意设备的完整构建器。

仍未覆盖目标资源限制服务、完整硬件/网络配置生成、HMI 打包、签名和下载一致性验证。输出明确返回 `deployable: false`；`full_project_headless_compile: false` 表示这些完整工程步骤仍未实现。常规 POU 声明由厂商解析器处理；Retain/Persistent、在线变更兼容和各种特殊 pragma 未逐类验证。

全程只操作工程副本和独立构建目录，没有连接、下载或执行 PLC 程序，也没有修改 ACI、CodeMeter 或许可。本次没有关闭许可来模拟到期；结论基于实际调用链不使用 ACI。

## 复现

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe tools\expanded_compile_e2e.py --mode cold
```

后一条会自己导入冻结原件的副本，依次进行正常编译、变量/接口修改、三个负例及恢复编译；不会连接 PLC。主程序和源码见 [server.py](../src/plcnext_mcp/server.py)、[expanded_compile.py](../src/plcnext_mcp/expanded_compile.py)、[ProjectSourceBuilder.cs](../src/plcnext_mcp/compile_host/ProjectSourceBuilder.cs) 和 [ColdProjectBuilder.cs](../src/plcnext_mcp/compile_host/ColdProjectBuilder.cs)。
