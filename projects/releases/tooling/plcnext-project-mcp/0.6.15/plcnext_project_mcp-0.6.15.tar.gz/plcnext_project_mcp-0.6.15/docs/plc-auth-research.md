# PLC 认证、TLS 与 RSC token 的离线证据

2026-10-25；静态读取本机 Engineer 2026 组件，用原厂纯序列化方法写入 MemoryStream，并在 Python/OpenSSL 的 MemoryBIO 内执行 TLS 1.2。没有实例化原厂通信 provider、online channel 或 TLS client，没有建立 socket，也没有使用任何真实 PLC 凭证。

本轮能够准确复现 CommonRemoting 的固定命令头及四字节认证 token，并确定原厂认证服务与会话生命周期的托管契约。完整 TLS/RSC 客户端还涉及服务发现、参数序列化、协商、数据标签、错误包和设备证书策略，不能把离线模拟、OpenSSL 内存握手或头部字节一致当作已经完成原厂/设备协议兼容。

## 实现与验证

- `src/plcnext_mcp/rsc_codec.py`：无网络导入的独立 header codec、Arp 原始认证错误枚举。
- `tools/Invoke-RscHeaderOracle.ps1`：仅调用 `CommandHeader.Write`，向本地 `MemoryStream` 写六组向量。
- [原厂序列化实证](../artifacts/plc-download-research/auth/header-oracle.json)：普通头、token 0/1/UInt32.MaxValue、负 handle、禁用 checksum 六种情况。
- [9 项 codec 测试](../artifacts/plc-download-research/auth/codec-tests.log)：全部通过。包括原厂冻结字节向量、token 0 与无 token 的区别、损坏 checksum、截断、未知附加头和越界类型。

API：`encode_header(CommandHeader(...), token=None|int, checksum=True)` 返回仅含头部/可选 token 的 bytes；`decode_header(bytes, require_checksum=False)` 返回 `(CommandHeader, token)`。不接受 payload；不会验证 token 的会话有效性。

新增 `src/plcnext_mcp/offline_tls.py` 的 `offline_tls_probe(fault='none'|'untrusted_peer'|'hostname_mismatch')`：使用 stdlib `ssl.SSLObject`/`MemoryBIO` 完成真正 TLS 1.2 握手和双向加密应用数据传递，应用内容为上面测定的合成 RSC 头。默认使用固定保留名称 `offline-plc.invalid` 和公开离线测试 CA/服务器证书；没有 DNS、socket 或真实 endpoint 参数。运行时仅用 stdlib ssl；生成 fixture 才需要 cryptography。

[内存 TLS 实证](../artifacts/plc-download-research/auth/memory-tls-probes.json)中正常信任链/名称通过，换成不受信任 CA 会由真实 OpenSSL 证书验证器拒绝（code20），换成名称不符证书会拒绝（code62）。[8 项 TLS 测试](../artifacts/plc-download-research/auth/memory-tls-tests.log)全部通过；测试封禁 socket 构造，并验证未知 SSL 错误会抛出，不被伪装成预期拒绝。两个预期证书失败的 API 报告为 `passed:false` 和具体类别，而不是成功握手。持久 `MemoryTlsPair.exchange(request_bytes, handler)` 复用同次握手，9MiB 应用数据双向传输及第二次调用实测通过；按实际 payload 大小读取全部 TLS records。

`simulation_tls/` 中私钥明确是公开测试材料，CA 私钥未保留；固定证书有效期2020-01-01至2100-01-01，仅为可复现的本地测试。OpenSSL 对该测试 CA 的验证不证明原厂 BouncyCastle、真实 PLC 证书链或设备信任配置等价，也不证明完整 RSC 服务调用兼容。

## 准确的认证服务契约

安装的 `Arp.System.Security.Services.IPasswordAuthenticationService` 声明：

```text
AuthenticationError CreateSession(
    string userName,
    SecureString password,
    out Arp.Base.Rsc.Commons.Security.SecurityToken token,
    out int32 penaltyTimeout)
void CloseSession(SecurityToken token)
```

服务带 `RscServiceAttribute("Arp")`。CreateSession 的 `RscMethod` ID 为1，CloseSession为2；这是接口方法 ID，区别于每次协商分配的 provider/service handle。完整 binary 参数封包已针对下述有限 profile 恢复并用原厂 formatter 验证，没有把服务声明改写成 HTTP Basic、JWT 或 Cookie 登录。

| Arp 原始错误 | int32 |
| --- | ---: |
| None | 0 |
| InvalidCredentials | -1 |
| PenaltyDelayActive | -2 |
| DuplicateSession | -3 |
| SessionLimitReached | -4 |
| TryAgainLater | -5 |
| PasswordMustBeChanged | -6 |

另一 `Arp.System.Um.Services.IPasswordAuthenticationService` 使用不同参数及正数错误枚举，不能混用。原厂 `SecuritySessionServiceAdapter.Translate` 仅映射 Arp -5..0，其他值变成 unknown；其本地 timeout 又映射到 Ade 层 -6。`rsc_codec.AuthenticationError` 明确暴露 **Arp 原始值**，不声称它等同 Engineer UI 的错误码。

`Ade.Online.PlcNextImpl.dll` 中 `SecuritySessionServiceAdapter::<CreateSessionAsync>b__0`（`0x0600037f`）先将源 `SensitiveData` 拷入临时 `SecureString`，调用上述 CreateSession，然后销毁临时密码对象。成功才保存 token、调用 `remotingAdapter.EnableSecurity(token)`、清空权限缓存并建立安全上下文；失败记录服务返回的 penaltyTimeout。继续读取原接口参数元数据后确认该 out 参数原名为 `penaltyDelayMillis`，单位为毫秒，原接口参数分别带 MaxStringSize64/128。

`<CloseSessionAsync>b__16_0` 先关闭本地 remoting 安全状态并清权限缓存，再向服务关闭 token；finally 清掉本地 token/context。`AreAllServiceCallsAllowed` 和 `RequestAccessRights` 会向 `ISecuritySessionInfoService3` 查询具体服务方法权限，旧服务有单项 fallback。认证成功不等于具有文件写入和配置加载权限。`OnPoll` 查询 `ISecuritySessionInfoService2.IsUserAuthenticationRequired`；它不是本轮证实的 token TTL/续期机制。

## 固定命令头和 token

`Ade.CommonRemotingProvider.Authenticate`（`Ade.CommonRemoting.dll`，`0x06000028`）要求先处于 connected 状态；随后把 token 写入 `RemotingStream.AuthenticationToken`，本方法自身不发一个额外的“Authenticate RPC”。已认证时使用 `ChangeAuthentication`（`0x0600002a`）。

`Ade.CommonRemoting.CommandHeader.Write` 的顺序如下，全部多字节数值由 .NET BinaryWriter 以小端写出：

| 偏移 | 字段 | 编码 |
| --- | --- | --- |
| 0 | Version | UInt8 |
| 1 | Flags | UInt8 |
| 2 | CommandType | UInt16（源 enum 底层 Int16） |
| 4 | AdditionalHeaderSize | Int16 |
| 6 | DataLength | Int16 |
| 8 | ServiceHandle | Int16 |
| 10 | MethodHandle | Int16 |
| 12 | ServiceProviderHandle | Int16 |
| 14 | Checksum | 16 位位模式 |
| 16（仅认证头） | SecurityToken | UInt32 |

安全 token 重载（`Ade.CommonRemoting.Commons.dll`，`0x0600001f`）设置 flag `0x08`、AdditionalHeaderSize=4，先输出带 checksum 的 16 字节固定头，再输出 token。`HasDatagramming=0x80`，`HasDataTagging=0x40`。Checksum 是固定头 8 个 UInt16 字的折叠和取反；token 不参与 checksum。读取时（`0x06000020`）非零 checksum 必须令折叠和为 65535，checksum=0 作为不检查的 sentinel。codec 的 `require_checksum=True` 可额外要求校验。

`SecurityToken` 的 payload 为 boxed UInt32。默认结构的 Value=null 表示没有 token；显式构造 UInt32(0) 仍然 HasValue=true。构造器不能传 null（会在 GetType 处抛异常），也不能以 boxed Int32 替代。Python 层用 None 表示缺失，用 0..4294967295 表示值。

初始 ConnectCommand.SendRequest（`0x06000123`）发 CommandType=7、Version=4、DataLength=0、datagram/tagging 标志均开；响应期待 CommandType=8，取回实际版本和 datagram/tagging 要求。RemotingStream 还包含旧版本兼容分支。codec 只复现固定头，不把默认版本 4 等同“已经完成协商”。

## 完整有限 RPC profile

`rsc_rpc_codec.py` 支持 **v4、untagged、无 datagram、每次 exchange 一个已知 schema 的调用**。初始 ConnectRequest 仍按原厂广告 flags=0xC0，随后只接受 flags=0 的 v4 confirmation；其他协商结果明确拒绝。InvokeRequest/Confirmation 的 Header.DataLength 在原厂 v4 formatter 中固定为0，后面直接跟 typed-value 流，因此这里没有人为增加线上并不存在的总长度前缀，也不声称这是通用 TCP stream framer。调用方必须按实际已知方法 schema 消费全部 payload，拒绝尾随字节。

完整原厂实验由 `tools/Invoke-RscRpcOracle.ps1` 完成，使用 `RemotingStream` 包装 MemoryStream，未构造 provider 实例或 socket。最终 [11 组完整黄金向量](../artifacts/plc-download-research/auth/rpc-oracle-06/report.json)覆盖 ConnectRequest/Confirmation、GetServiceHandlesRequest/Confirmation、CreateSession 输入、成功/错误凭证/惩罚期间输出、带 token0 的 CloseSession 输入、void 输出和服务器异常输出。输入由原厂 command/RemotingFormatter4.SerializeMessage 直接写出；拼接的响应值体由原厂 DeserializeMessage/DeserializeReturnValues 读取且无剩余字节。[11 项 RPC 测试](../artifacts/plc-download-research/auth/rpc-codec-tests.log)全部通过，编码结果与这些原始二进制向量完全一致。

关键发现：`RemotingProxy.Init`（`Ade.CommonRemoting.dll`，`0x060001aa`）为真实参数及 return 收集属性，调用 `RemotingFormatter.GetMarshalType` 选择 marshal 类型；本版默认为2（UTF8）。早期人为填0的 CallMessage 实验得到 UTF16，不能作为真实参数契约，已由最终实验纠正。最终 oracle 直接复用原厂 GetMarshalType(attrs)，因此 CreateSession 用户名和 SecureString 密码均为 UInt16 字节数（含NUL）+UTF8+NUL。返回按声明顺序为 out SecurityToken、out Int32 penaltyDelayMillis，再 Int32 AuthenticationError；Token 的 Object 字段额外携带类型标签0x09和 UInt32 值，即使一般数据 tagging 关闭也保留该 Object 标签。CloseSession 返回 void，值体为空。

实际 `GetServiceInternal`（`0x0600002c`）使用 GetServiceHandlesCommand，而非猜测固定 handle。其 command15 输入是两个 `WriteStringRaw`：UInt16长度（含NUL）+UTF8+NUL，分别为 provider 和 service 名；command16 在头部返回 provider/service handle。原方法按字符串字符数计原始长度，因此本实现把发现名称明确限制为 ASCII，避免把未测试的多字节名错误推广。

原厂 `GetServiceTypeNames`（`0x06000033`）先加入 Type.FullName，再加入可选 AlternativeServiceTypeName 备用项；`GetServiceProviderName`（`0x06000032`）读取 RscServiceAttribute.Provider。最终 oracle 直接调用这些无网络静态方法，四个实际接口的结果均为 provider `Arp`，名称分别为自身完整名字：

- `Arp.System.Security.Services.IPasswordAuthenticationService`
- `Arp.System.Commons.Services.Io.IFileService2`
- `Arp.System.Commons.Services.Io.IFileSystemInfoService`
- `Arp.Plc.Domain.Services.IPlcManagerService`

没有去掉接口名的 `I`，也没有为实际 PLC 预设 service/provider 数字 handle。离线服务器分配自己的 handle，客户端通过上述真实发现消息获取。

2026-10-26 更正：早期手工 Error fixture 将 marshal1 当成 UTF16，该解释有误。直接执行原厂 ERROR Serialize/Deserialize 的 [untagged oracle](../artifacts/rsc-error-control/untagged-oracle-01/report.json) 确认本构建为 UInt32 code、UTF8 message 和 Object[]；`rsc_rpc_codec` 已修正，并保留非高位/空参数的限定范围。旧11向量中的手工错误项保留为历史数据，现由新3项原厂空串/ASCII/中文错误向量替代。tagged 普通与 fatal 错误的完整独立实现见 [新报告](rsc-error-control.md)。

一个仍然保留的窄边界：原厂 writer 对 default SecurityToken(Value=null) 的试验抛 NullReference，因此 codec 没有猜一个 null 标签。离线服务器在失败结果中选择可序列化 UInt32(0) out token；这是模拟器选择，不声称真实服务器失败必返回0。客户端必须先检查非零 error 并拒绝启用安全状态。Header层 None/0 的区别以及成功 token0 的往返均另有实证。

## TLS 证据及未完成部分

`Ade.Online.CommonRemoting.CommonRemotingSecurityProtocol` 中 None=0，Tls12=1。`CreateSecurityCommunicationChannel`（`0x0600001d`）要求非空 Certificates，接受协议 1，并将 targetHost、rootCertificates、manufacturerRootCertificates 交给 `SslCommunicationChannel`。

`SslCommunicationChannel.OnRemoteCertificateValidation`（`0x06000080`）调用原厂证书路径 validator，包含目标名称和根证书集合，返回校验结果的 IsSuccess。`CommonRemotingTlsClient.ValidateServerAuthentication.NotifyServerCertificate` 失败会抛 TLS fatal alert；GetClientCredentials 返回 null。本轮没有执行 TLS 握手，也没有证明所有目标策略、重连或自动证书接受行为。模拟器的证书成功/失败只能验证编排分支，不能代替真实证书链和密码学验证。

## 证据身份与复查边界

静态读取使用 Mono.Cecil 将目标当数据解析；只加载 Mono.Cecil 解析器。受控执行限定为纯 header、command、参数/响应 formatter、静态服务命名和 MemoryStream 包装；不构造 provider 实例、网络 channel 或 socket。OpenSSL MemoryBIO 是独立的本地 TLS 实验。

| 程序集 | SHA-256 | 方法/证据 |
| --- | --- | --- |
| Ade.Online.PlcNextImpl.dll | `7bbd75c0853220ccd262b9e9fdbec2b2d046e9a34e11bc1a405e94b22091d7ed` | 会话、权限、关闭；`online-auth-il.json` |
| Ade.Online.CommonRemotingImpl.dll | `405ac18d4995a65a441939eb891e3c6682343c61f34110c139f74ae237dde34e` | TLS 包装与证书校验；`common-remoting-il.json` |
| Ade.CommonRemoting.dll | `8f69842462937d116504ab19a2f684a76c7f5b9f955876ee796f8604b22a8735` | token 放入 stream；`remoting-core-il.json` |
| Ade.CommonRemoting.Commons.dll | `ab1382d433254d8694bf53c265e29b16445c323528a7ed2389a23068c6f3246e` | header/协商/checksum；`remoting-stream-il.json`、`remoting-connect-il.json` |
| Arp.Base.Rsc.Commons.dll | `2ee2402786ad430883cd48d905bcad4bd301e3dcdb783ea7f6daf9ddf1bf0c77` | SecurityToken；`rsc-commons-auth-il.json` |
| Arp.System.Rsc.Services.dll | `214e68d812d65a374b6085232f88cfd574a9a80f28e1e91b07eb01abb9af98cb` | 认证声明与错误；`rsc-auth-services-il.json`、`protocol-metadata.json` |

完整静态文件均在 `artifacts/plc-download-research/auth/`。REA canonical 身份证据：`ev_c252d00e070586ce938c59271bdc347a961dca75e2eed0386fd4107ce19aa722`，文件 `rea-commonremoting-artifact.json`；它明确不执行目标。复用的 PLCnext 成员证据为 `ev_927a702fc75e2a499c6519b5a8cbe857342f4e405c8fba85de507f6a10615352`，旧文件位于 `artifacts/deployment-research/rea-online-members.json`。元数据 token 只对表中确切 build 有效。

| 问题 | 状态 |
| --- | --- |
| 原厂认证服务及成功/失败/关闭托管调用序列 | 已由静态 IL 确定 |
| 固定头、token、checksum 字节兼容 | 原厂 MemoryStream oracle 已验证 |
| 原厂 TLS 类型、协议枚举及校验入口 | 静态确定；原厂握手未执行 |
| OpenSSL TLS1.2 信任链/名称/加密应用数据 | MemoryBIO 实跑通过正常及拒绝分支；不证明原厂/设备等价 |
| 实际端口、证书获取/选择及真实网络发现 | 本轮未确定，不能设默认真实 endpoint |
| 服务发现、Invoke、CreateSession/CloseSession 有限 v4 profile | 原厂纯 formatter 完整字节向量匹配；真实设备未验证 |
| datagram/tagging、其他版本、复杂 server-error 参数、default null token body | 不支持，未知输入明确拒绝 |
| 真 PLC 会话 TTL、并发、固件兼容及网络重试 | 未验证；惩罚毫秒单位由原接口参数名确定 |

这些缺口不阻止离线测试编排、权限拒绝、会话清理和错误恢复；应在 MCP 能力报告中明确将其描述为模拟验证，而不是生产设备下载已可用。
