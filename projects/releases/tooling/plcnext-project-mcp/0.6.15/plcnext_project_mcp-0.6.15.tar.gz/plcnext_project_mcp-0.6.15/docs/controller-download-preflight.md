# 下载审阅的真实只读预检

实现：[controller_preflight.py](../src/plcnext_mcp/controller_preflight.py)，入口 `preflight_download_review(store, project_id, review_id, expected_review_sha256)`。它给下载版本审阅补充实时上下文，**不签发批准，也不执行任何设备变更**。

预检先用 `review_package_snapshot` 重新核对工程源、冷构建、PCWE 全文件、审阅哈希及目标证书 pin。随后调用生产 `TlsControllerClient(..., preflight_readonly=True)`，允许 Running 状态，顺序读取：

1. PLC 状态；
2. 固定符号根 `$ARP_PROJECTS_DIR$/PCWE/` 的解析结果；
3. 该已解析根的可用空间；
4. 仅 `PCWE.manifest.config` 和 `PCWE.software-package-manifest.json`。

不建立密码会话，不读取任意路径，不调用文件写入、Stop、Start、Reset、Load 或删除。传输层在私有 `_call` 入口也检查这项范围，不能通过绕过公开路径方法扩大读取范围。实际网络读总期限为 30 秒；每个传输 exchange 仍有独立期限。

## 输出及结论边界

输出是新建 `controller-download-preflights/<uuid>/result.json`，包含版本审阅绑定、实时状态、目标 TLS pin 验证、可用空间、两份元数据的结果码/长度/哈希、软件 identification 以及声明路径/哈希与审阅包的差异。原始 XML/JSON payload 不返回给模型，也不写入报告。

远端 XML 必须是已观察的 ProjectManifestDocument 1.0 / Sha512 结构，拒绝 DTD/entity、危险路径、大小/数量过界、重复路径和不合法文件哈希。软件 JSON 要求 manifestVersion 1.0、无重复字段，只提取有界白名单 identification 字段；其他任意 tags 不传播。两份元数据各限制 4 MiB。完整声明路径单独保存在 `remote-manifest-paths.json`，返回中的差异列表最多 128 项。

`preflight_read_completed` 表示所需只读数据按已知结构读取完成；`preflight_incomplete` 表示文件不存在、无读权限或结构未知等；`preflight_failed` 表示审阅过时、连接/传输或收尾失败。已知工程目录内的失败也保存报告，未知工程 ID 在生成路径/网络之前拒绝。

读完后再次检查审阅和当前工程/包，期间修改会让本次结果失败，不能把旧版本观察当作最新版本。预检始终保留：

- `write_authorized=false`、`write_permissions_verified=false`；
- 不证明 manifest 中声明的实际文件内容，也不验证签名；
- 不证明未列出的文件不存在，没有远端完整目录枚举；
- 不以匿名可读推断匿名可写；
- Running 不阻止只读检查，但会列出“未观测到精确 Stop”的下载阻塞项。

真实写入仍需用户对明确版本和影响的单独确认，及后续执行时的所有绑定/状态/权限检查。

## 本机验证

[6 项测试](../tests/test_controller_preflight.py)通过生产客户端和 `LocalTlsController` 的实际 localhost TCP/TLS 检查 Running 状态读取、固定两文件、版本/声明路径差异、缺失/恶意元数据、读前和读后的过时审阅，以及 `_call` 私有入口的路径/traits/密码/写/控制越界拒绝。业务文件与状态均未修改。

这些测试使用 fake review snapshot 隔离审阅器本身；实际审阅/包绑定由独立的审阅模块测试及主 MCP 端到端验证覆盖。子任务测试没有连接 `192.168.0.8` 或其他外部网络。[测试记录](../artifacts/controller-download-preflight/local-tests.json)。
