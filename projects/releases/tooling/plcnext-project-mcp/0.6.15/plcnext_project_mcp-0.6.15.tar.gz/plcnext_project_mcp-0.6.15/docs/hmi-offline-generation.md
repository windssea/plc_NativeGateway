# NativeGateway offline HMI generation

Validated on 2026-10-25 against the current 61-POU **copy**. This pass generates current HMI source through installed vendor parsers/semantic analysis/JSON and JavaScript writers. It does not reuse compiled HMI pages, instantiate online services, connect to a controller, invoke ACI, or operate a GUI.

## Reproducible result

- Host: `tools/HmiOutputProbe.cs`; runner: `tools/Invoke-HmiOutputProbe.ps1`.
- Final positive receipt: `artifacts/pcwe-aux-research/probe-36/result.json`.
- Build job: `54599b7ed9254ac6a61293152ce4ae08` under workspace copy `a431bdc32f2a4aa1812c94683db38395`.
- Analyzed AST SHA-256: `b2cd81131fbc083ebd1db7f68030eef0145d5a5b1cd7cdb4c98b8c3806e7478f`.
- Final runtime type JSON SHA-256: `c9cea290d45250ade60484777a6376a35461ed5a0587b74f9b574bd0b58f7f64`.
- Input source hashes are checked before and after the host; the positive and negative runs both preserved their input source files.

| Generated file | Bytes |
|---|---:|
| gateway.json | 601442 |
| gateway.variables.json | 3669 |
| gatewayModule.js | 117060 |
| login.json | 9643 |
| login.variables.json | 152 |
| loginModule.js | 472 |
| languages-static.dictionary.json | 34000 |

Gateway has 494 top-level/layer objects and Login has 10. Gateway JSON references 462 JavaScript functions; Login references 2. Each reference set exactly matches its generated module's declared functions. Node syntax checks pass for both modules without executing their JavaScript. All three unchanged Login output files match the independent GUI baseline byte for byte. This comparison caught and corrected an early probe's module naming error; only probe-35 and later include that correction.

The static language dictionary is generated from the current models plus their current `.locres` files, contains 504 entries, and uses `Default`, the source language with ID 0. Source Chinese text is retained as UTF-8.

## Source and runtime bindings

The host loads the analyzed AST with `ArchiveReader.ReadFile` and indexes it through the original `CompilerProjectManagerState`. Real `ScriptAnalyzer`, `HmiPageDataTypeService`, IEC scanner/parser, literal parser, and semantic analysis resolve expressions and types.

Ten controller HMI tags are read from the source `DataList.dl`. Each must have an explicit Variable role and matching GDS OutPort. Page/application client variables come from source `Variables.hmivar`; controller, page, and application scopes remain distinct. Source `Navigation.hminav` is loaded and evaluated by the original navigation serializer/model.

All 81 Gateway subscription bindings are checked against the finalized native runtime type information, including exact field names, IEC type, field offset, size, and containment. The earlier zero-size intermediate type information is rejected. Examples added since the old GUI package:

| Binding | Type | Offset in HMI | Size |
|---|---|---:|---:|
| HMI.LocalRevision | STRING_24 | 4 | 30 |
| HMI.HubBaselineVersion | STRING_24 | 34 | 30 |
| HMI.UiMaintenance | NG_UiLabel | 64 | 518 |

The source device `.ds` must have HMI AccessRights 0; its HTTP port 443 is read into the settings model. No `.authsettings` payload exists in the current source. Vendor `HmiClientApplicationSettings` leaves AuthenticationProtocol zero-initialized; this is recorded explicitly. A future explicit authsettings payload or different access-rights profile is rejected until implemented. The packaging layer additionally verifies absence across the entire PCWEX archive, not just the extracted project tree.

## Vendor entry points

1. `Ade.Hmi.Persistence.PersistHmiPageDefinition.Load(Stream)` loads the current XML page model.
2. `JsonHmiWriter.SerializeRoot(HmiBuildContext, page, pageName)` performs original HMI object/dynamic/action checks. Context display name is the actual page name, which controls module names.
3. `PageOrSymbolOutputBuilder.CreatePageOutput(...)` collects variable lists and JavaScript.
4. `HmiJsonSerializer.OutputHmiPage(...)` writes JSON, variables JSON, and module JavaScript.
5. `ResourcesDocumentSerializationService.ReadFromStream` loads current `.locres`; `HmiLocalizerFactory.CreateHmiLocalizer(page)` and `LocalizerDocumentUpdater.UpdateResourcesDocumentForPageOrSymbol(...)` extract the current model's default text.
6. `HmiBuildLocalResources.WriteLocalResources(...)` merges and writes the static dictionary.

Original resources, type lookup, parsing, navigation, localization, and output logic are used. The narrow service adapters provide source-backed controller/client variables, project references, and build-item data. Unknown interface calls throw; they do not silently return empty success. The current supported profile is exactly Gateway/Login with their current service needs.

## Negative verification

`artifacts/pcwe-aux-research/negative-unknown-field-job` is a separate test copy. Only that copy replaces `HubBaselineVersion` with `MCP_NonexistentField` in Gateway's source page.

Final negative receipt: `artifacts/pcwe-aux-research/probe-negative-unknown-field-final/result.json`. The original semantic analyzer emits an Error stating that `NG_Hmi` has no such field. Status is `failed`; no successful `page_files` receipt is issued. The production packager must always gate on status and receipt hashes, because partial files can exist from a failed attempt.

## Receipt contract and boundary

Mandatory runner parameters: `-WorkRoot`, `-RuntimeTypesPath`, `-OutputDirectory` (new directory). Optional: `-InstallDirectory`, `-DesktopDirectory`. Exit code 0 and `status=pages_generated` require both pages, static localization, no compiler Error diagnostics, no unsupported service calls, complete output files, matching script references, unchanged inputs, and valid runtime bindings.

The receipt includes `page_files[{path,sha256,size}]`, `source_files[{path,sha256}]`, `analyzed_ast_sha256`, `runtime_types_sha256`, `device_settings_sha256`, `vendor_assemblies[{name,sha256}]`, `host_source_sha256`, `runtime_bindings`, `function_checks`, diagnostics, and source-preservation state. The outer package layer must authenticate the AST/runtime JSON against the same cold compilation job and image; this host does not independently prove their ancestry.

The CLR automatically loads `Ade.Online` to resolve DataList interface metadata. The host does **not** instantiate an online service or invoke a communication operation; it must not be described as loading zero Online assemblies. ACI/CodeMeter/Wibu resolution is rejected. Two captured first-chance FileNotFound exceptions for optional pre-generated localization XmlSerializers are normal .NET serializer fallback; original serialization succeeds. They are retained in the evidence, distinct from semantic errors.

Remaining full-HMI duties belong to the package support generator: project/application variables, data/type dictionaries, dynamic localization, browser assets, CRCs, image copying, and outer PCWE manifest. Passing this page receipt alone does not establish controller acceptance or authorize a download.

## MCP child-process environment

The MCP Python SDK's Windows environment whitelist includes `SYSTEMROOT` but omits `WINDIR`. WPF `MS.Internal.FontCache.Util..cctor` in `PresentationCore.dll` directly reads `windir`, appends `\Fonts\`, and constructs an absolute URI. With the SDK's minimal environment this becomes a relative `\Fonts\` path and fails during `ObjectWithShape.FontLineSpacing` serialization.

The child-process wrapper should supply only the missing standard value: `WINDIR = current WINDIR or SYSTEMROOT`, checking that it is an existing absolute directory. It need not inherit unrelated environment variables or launch a GUI. Evidence: `wpf-fontcache-util-il.json` and `wpf-environment-ab.json`. Actual A/B runs with the same host, job, and finalized types reproduce failure without WINDIR and succeed with 81 bindings when only WINDIR is restored.

## REA evidence

`hmi-compiler-rea.json`: evidence `ev_91d7099b74b091d7d1213eee3b14897d148e8228302a0f5f98c3623928500a36`, vendor `Ade.Hmi.CompilerImpl.dll` SHA-256 `ca08b8e504ea03db6ead7de033a15c2e7a3fd4bcd34895fec504d4987bf55a3e`, MVID `723c6e04-8acf-4a28-9c0a-217ed1dce8e5`.

Static selected IL under `artifacts/pcwe-aux-research/`: `hmi-page-loader-il.json`, `hmi-page-checker-il.json`, `hmi-compiler-selected-il.json`, `hmi-find-variable-il.json`, `hmi-resolve-name-il.json`, `hmi-instance-path-il.json`, `compiler-findtype-state-il.json`, `localizer-update-il.json`, `local-json-generator-il.json`, and `hmi-client-settings-il.json`. These contain exact method tokens, signatures, and CIL with binary identity.
