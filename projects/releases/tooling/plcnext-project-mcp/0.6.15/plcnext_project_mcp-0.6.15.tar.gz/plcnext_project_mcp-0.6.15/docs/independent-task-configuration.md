# 独立任务配置：读取和单周期任务参数修改

2026-10-26。实现不调用 ACI、Engineer 进程或 computer use，不打开网络连接。输入只使用 `ProjectStore` 管理的 PCWEX 副本，原工程不写入。

## 本轮实现

- `inspect_task_configuration(store, project_id)`：读取 ESM v2 的 ESM、任务、备注、原始属性和程序实例；返回任务/程序实例 ID、名称、Program POU 身份、组件归属、周期/看门狗 ns 和优先级。
- `update_cyclic_task(store, project_id, expected_project_sha256, task_id, updates)`：为当前受支持 AXC F 2152 / 2026、单 eCLR 资源、单周期任务修改 `interval_ns`、`watchdog_ns`、`priority`，创建新 revision。
- 修改前复用现有冷构建源/设备能力检查，拒绝旧哈希、未知任务、只读任务、未知字段、布尔/浮点/字符串数值、超范围和无变化更新。
- 仅替换现有 Task 起始标签中的数字属性字节，保留 ESM 的 BOM/换行/格式、ESM/task/program ID、程序分配和其他属性；所有其他 ZIP member payload 与 ZIP entry 元数据保持原样。
- `ProjectStore.validate` 增加有界任务历史重放：从冻结 ESM 按允许属性重新计算每次更改的 before/after hash，不接受仅伪造 after-hash 的映射修改授权。POU 编辑、FB 结构编辑和任务编辑可混合。

服务器入口由主代理接入上述函数；模块路径是 [task_configuration.py](../src/plcnext_mcp/task_configuration.py)。

## 单位及范围证据

源为 `.../PLCnext/EsmConfiguration.esmc`，`EsmConfiguration version="2"`，Task 类型 `CyclicTask`。已有独立冷构建器 [ColdProjectBuilder.cs](../src/plcnext_mcp/compile_host/ColdProjectBuilder.cs) 明确将 `intervalTime` 和 `watchdogTime` 除以 1,000,000 写入编译模型的毫秒值，同时保留源 ns 值。运行配置生成器将源 ns 写入 `PCWE.esm.config` 的 `cycleTime/watchdogTime`。

范围和现有冷构建门禁一致：时间为整数 `1..86400000000000 ns`，优先级 `0..99`。这是本实现可接受的源/编译范围，**不是对全部硬件调度能力、负载或实时行为的保证**。

本机官方 ACI 的 Task.Interval/Priority/Watchdog/Comment/EventName getter 是直接抛 `NotImplementedException` 的接口，本模块从工程副本直接读取源定义，不复制该空实现。静态证据见 [ACI 服务端报告](aci-analysis/server-project.md)。

## 实际 61 POU 副本验证

输入来自先前冻结的 NativeGateway 管理副本：

`D:\PLCnext-MCP-Workspace\a431bdc32f2a4aa1812c94683db38395\revision-0000.pcwex`

该输入哈希：`e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0`。先复制到本轮新管理工程 `6a0e05ef8a30441ba3c2a7c8af574a2b`，再修改：

| 项目 | 原值 | 新值 |
| --- | --- | --- |
| 任务 | Cyclic100 | Cyclic100（ID 不变） |
| 周期 | 20,000,000 ns / 20 ms | 25,000,000 ns / 25 ms |
| 看门狗 | 500,000,000 ns / 500 ms | 750,000,000 ns / 750 ms |
| 优先级 | 0 | 2 |
| 程序实例 | MainInstance → Main | 保留原 ID 和绑定 |

实际结果：

1. 只有 ESM member 中三个数值变化，其他 member payload 不变，结构保留验证通过。
2. 当前 61 个 POU 的真实独立冷编译成功，`cache_assisted=false`、`ast_seed_used=false`，新 CIL 和本机原生镜像生成；编译宿主记录新 ns 值、priority=2 和 MainInstance。
3. 新生成的运行 ESM 文件包含 `cycleTime="25000000" watchdogTime="750000000" priority="2"`；运行配置检查的任务时序、实例及绑定均通过，同时报告 10 项 HMI 映射保留。
4. 旧源哈希在构建输入检查中被拒绝；现有构建/打包绑定机制要求 exact project hash，任务修改不会继续沿用旧 revision 的构建结果。
5. 输入副本哈希未变，未读取/修改活动原工程，未启动 Engineer、连接或下载到 PLC。

证据：[本轮完整结果](../artifacts/task-configuration/result.json)、[冷编译结果](../artifacts/task-configuration/managed/6a0e05ef8a30441ba3c2a7c8af574a2b/builds/a463c66cee1447cb93603a2000d01208/result.json)、[生成的 ESM 运行配置](../artifacts/task-configuration/generated-runtime/Plc/Esm/PCWE.esm.config)。

## 测试与未覆盖

[test_task_configuration.py](../tests/test_task_configuration.py) 的 6 项测试通过，覆盖准确属性字节/ZIP 保留、实例映射、混合编辑历史、旧哈希/错误参数、伪造映射授权拒绝及 manifest 写失败回滚。既有工程生命周期 15 项测试同时通过。

没有实现任务/程序实例的新增、删除、重命名、重新分配、事件任务、多任务或其他设备模型；也没有把编译及运行 XML 检查当作控制器调度实测。`runtime_effect_verified` 和 `controller_connected` 保持 false。
