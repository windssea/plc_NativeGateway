> 历史文档：以下保留 0.5.0 / 35 工具阶段的说明和证据。当前操作请读 [0.6.0 使用手册](mcp-user-guide.md)，不要将旧的单任务、无变量读取或无操作者入口限制当作当前能力。

# PLCnext 独立 MCP 使用与测试手册

> 三方联调所需后续能力及逐项验收见[MCP-JOINT-GAPS/1修复清单](三方联调MCP修复清单-20261026.md)。清单是待实现需求，不表示本文所列工具已新增；当前下载审批/Stop/Start及恢复限制继续生效。

版本：0.5.0 · 工具数：35 · 核对日期：2026-10-26。

本手册面向本机 Codex 和其他 MCP 客户端的实际测试。所有工程编辑均生成副本修订；离线开发、冷编译和本机下载测试不需要启动 Engineer 界面、ACI 或 computer use。编译仍使用已安装的厂商编译器及引用库。

**当前真实下载客户端已实现，本机 TCP/TLS 传输已验证；真实 PLC 写入、配置加载与运行效果尚未验收。`192.168.0.8` 当前仅授权只读。阅读本手册、执行离线测试或生成审阅均不授权真实下载。**

入口：

- [1. 最快开始](#1-最快开始)
- [2. 能力与限制](#2-能力与限制)
- [3. 安装、注册与刷新](#3-安装注册与刷新)
- [4. 工程、修订和哈希](#4-工程修订和哈希)
- [5. NativeGateway 副本的离线测试](#5-nativegateway-副本的离线测试)
- [6. 新建工程、增删 FB 和接口修改](#6-新建工程增删-fb-和接口修改)
- [7. 任务配置](#7-任务配置)
- [8. 完整 PCWE 生成与检查](#8-完整-pcwe-生成与检查)
- [9. 下载模拟与本机 TCP 测试](#9-下载模拟与本机-tcp-测试)
- [10. 真机只读检查](#10-真机只读检查)
- [11. 真实下载的确认与执行](#11-真实下载的确认与执行)
- [12. 失败处理与恢复](#12-失败处理与恢复)
- [13. 测试清单与问题反馈](#13-测试清单与问题反馈)
- [14. 全部工具与参考资料](#14-全部工具与参考资料)

## 1. 最快开始

本机已注册服务 `plcnext-project`，不需要重新注册。先重载 MCP 服务；若当前会话仍只有旧工具，重启 Codex 并在新会话中测试。源码版 0.5.0 应发现 35 个工具，包括 `project_test_controller_download`、`project_preflight_controller_download`、`project_execute_controller_download`。

在 Codex 中先发送：

```text
使用 plcnext-project MCP，先调用 server_capabilities，确认当前工具支持冷编译、
本机 TCP 下载测试和审阅绑定的只读预检。
整个测试只编辑工程副本，不启动 Engineer、ACI 或 computer use，不连接或下载到真实 PLC。
不要创建 controller-download-approvals 下的任何确认收据。
```

随后可直接发送以下测试指令。这里选用已经冻结的 NativeGateway 副本，避免追逐正在调试的源码版本：

```text
通过 MCP 导入这个文件为一份新的受管副本：
D:\PLCnext-MCP-Workspace\a431bdc32f2a4aa1812c94683db38395\revision-0000.pcwex
预期文件 SHA256 为 e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0。
保存新 project_id，检查 61 个 POU、实例引用和任务配置；运行 project_validate、
project_build_plan 和 project_compile。编译成功后生成 PCWE 并验证文件 SHA512。
随后调用 project_test_controller_download，依次测试 fault=none、chunked_readback、
readback_corrupt、write_reply_lost、load_reply_lost、initial_running。
逐项报告实际结果、是否发生测试端写入、是否允许继续加载以及日志路径。
仅允许工具自己的 127.0.0.1 测试设备，不访问真实 PLC，不创建实际下载确认收据。
```

这条指令覆盖现有工程冷编译、打包和下载客户端，**不覆盖新建、FB 增删与接口修改**；这些按第 6 节另建一个测试工程。冻结文件如果不存在，选择另一份明确的 `.pcwex` 用 `project_import_copy` 导入；不要凭旧 `project_id` 推断其当前修订。

## 2. 能力与限制

| 范围 | 当前能力 | 测试时的边界 |
|---|---|---|
| 工程 | 导入副本；从官方设备模板新建 | 默认 AXC F 2152；不覆盖原文件 |
| ST / FB | 读取、精确替换、批量代码和变量接口修改；新增、删除标准 ST FB | 不提供完整图形编辑、通用 POU 类型转换、函数返回类型或任意元数据修改 |
| 实例与变量 | 查找已知 ST 声明/调用；事务内同步修改 FB 与调用方 | 引用搜索不是完整编译器符号表；改变量名不自动迁移所有外部映射 |
| 任务 | 检查任务/程序实例；改现有单周期任务的周期、看门狗、优先级 | 只改源副本；不新增/删除任务，不支持所有调度类型 |
| 冷编译 | 重建支持范围内的源模型、语义分析、CIL 和原生镜像 | AXC F 2152 / 2026、单 eCLR 资源、一个周期任务、标准 ST；依赖本机编译器和库 |
| 完整 PCWE | 生成运行配置、原生库、HMI/服务配置和完整性清单 | 仅已验证的 NativeGateway 硬件/服务及 Gateway/Login HMI 配置；其他工程不承诺完整打包 |
| 只读设备 | 固定服务读取状态；按审阅读取固定两份元数据和空间信息 | 明确 IP、端口和证书 pin；不读取任意文件或任意变量 |
| 下载测试 | 内存 TLS 模拟；生产客户端的 127.0.0.1 TCP/TLS 全流程测试 | 本机设备模拟状态、权限与加载行为，不能证明真实固件接受包 |
| 实际下载 | 精确审阅 + 外部人工确认收据 + TLS pin + 文件写入/回读 + Reset/Load | 先要求 PLC 已 Stop；无自动 Stop/Start、旧文件删除、自动回滚或不确定写入重试 |
| 完整 ACI 替代 | 可查 201 个公开方法的替代账本 | 尚未完全覆盖；不能以工具数当作 ACI 完成率 |

各类“成功”的含义：

| 返回或检查 | 能说明什么 | 后续仍需检查 |
|---|---|---|
| `project_validate` 成功 | 支持范围内结构和非目标成员 payload 保留 | ST 语法、类型、运行行为 |
| `project_check_st` 成功 | 单个 ST 工作表语法通过 | 全工程语义和代码生成 |
| `compiled=true` | 当前源修订完成离线 IEC 编译和镜像生成 | 完整部署配置、签名、设备接受、物理 I/O |
| `package_complete=true` | 支持配置下的本地 PCWE 候选生成完整并通过本地检查 | 真机兼容和运行效果 |
| `loopback_download_passed` | 生产客户端完成本机文件传输、回读、测试 Reset/Load | 真实 PLC 权限、状态与加载语义 |
| `controller_download_completed` | 真机传输/回读及所检查的加载后状态完成 | 功能验收、任务时序、通信、I/O 与业务逻辑 |

当前产物的 `deployable=false` 保留真实设备尚未验收的事实，不能把它手动改成 true 充当通过。

## 3. 安装、注册与刷新

### 3.1 本机位置

| 项目 | 当前路径或值 |
|---|---|
| 仓库 | `D:\work\code\PLCnext-Engineer-mcp` |
| MCP Python | `D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe` |
| 版本 | `plcnext-project-mcp 0.5.0` |
| 工程与作业数据 | `D:\PLCnext-MCP-Workspace` |
| Engineer 安装 | `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0` |
| 本机已验证安装版本 | Engineer 2026.0.4 / build 9.0.373.0 |
| Codex 配置 | `C:\Users\windssea\.codex\config.toml` |
| 服务名 | `plcnext-project` |

运行条件：Python 3.11+；编译主机为 Windows，安装匹配的 Engineer 编译组件、设备模板和工程引用库。仓库配置脚本要求 PowerShell 7。普通工程文件编辑不调用 ACI 或 CodeMeter；本项目没有实现独立 IEC 编译器，也不修改厂商许可。

### 3.2 检查已注册配置

以下命令只检查本机服务配置，不连接 PLC：

```powershell
codex mcp get plcnext-project --json
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -c "import importlib.metadata as m; print(m.version('plcnext-project-mcp'))"
```

预期为 enabled、stdio、上述 Python 绝对路径、`-I -m plcnext_mcp.server`，以及正确的两个环境变量。

本机已经注册。仅在另一台主机或尚未注册的环境执行：

```powershell
codex mcp add plcnext-project `
  --env 'PLCNEXT_MCP_WORKSPACE=D:\PLCnext-MCP-Workspace' `
  --env 'PLCNEXT_ENGINEER_DIRECTORY=D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0' `
  -- 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -m plcnext_mcp.server
```

全局注册一次即可在其他项目使用；每个项目通过绝对 `source_path` 导入副本并取得自己的 `project_id`。不要为每个项目复制 MCP 源码。Codex 的 stdio、环境变量、用户配置与超时字段见 [OpenAI 官方 MCP 说明](https://learn.chatgpt.com/docs/extend/mcp?surface=cli)；上面 CLI 语法也按本机 `codex mcp add --help` 核对。

如客户端默认工具超时不够，可在现有 `[mcp_servers.plcnext-project]` 表内设置 `tool_timeout_sec = 300`，然后重载服务。不要重复创建同名 TOML 表。客户端超时或取消不等于后台操作/设备操作已经撤销；真实下载超时必须按第 12 节处置。

### 3.3 其他 MCP 客户端

在支持 `mcpServers` 格式的客户端合并：

```json
{
  "mcpServers": {
    "plcnext-project": {
      "command": "D:\\work\\code\\PLCnext-Engineer-mcp\\.venv\\Scripts\\python.exe",
      "args": ["-I", "-m", "plcnext_mcp.server"],
      "env": {
        "PLCNEXT_MCP_WORKSPACE": "D:\\PLCnext-MCP-Workspace",
        "PLCNEXT_ENGINEER_DIRECTORY": "D:\\Program Files\\PHOENIX CONTACT\\PLCnext Engineer 2026.0"
      }
    }
  }
}
```

不同客户端外层格式可能不同。仓库的 `.mcp.example.json` 是通用示例，其 workspace 默认在仓库内；要复用本机已有副本，请使用上面的 `D:\PLCnext-MCP-Workspace`。

可在 PowerShell 7 生成适合自己路径的配置：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\tools\Configure-Mcp.ps1' `
  -Workspace 'D:\PLCnext-MCP-Workspace' `
  -EngineerDirectory 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
```

默认只打印 JSON；加 `-OutputPath 'D:\MyProject\.mcp.json'` 只会新建文件，父目录须存在，已有文件会被拒绝。脚本不会修改 Codex 全局配置。

### 3.4 独立环境安装或升级

本机现有 `.venv` 可直接用。需要独立安装时：

```powershell
py -3.11 -m venv 'D:\tools\plcnext-mcp-env'
& 'D:\tools\plcnext-mcp-env\Scripts\python.exe' -m pip install 'D:\work\code\PLCnext-Engineer-mcp\dist\plcnext_project_mcp-0.5.0-py3-none-any.whl'
```

已有独立环境升级时使用同一解释器和 `pip install --upgrade`，并把客户端 `command` 指向该环境。也可以安装当前仓库目录。安装后必须重启 MCP 进程；版本号正确但工具仍旧时检查实际启动路径、是否为旧 wheel，以及客户端是否过滤工具。

不要在终端单独启动 stdio 服务后等待出现网页；它由 MCP 客户端启动并通过标准输入输出通信。

## 4. 工程、修订和哈希

以下示例使用 `{"tool":"工具名","arguments":{...}}` 展示一次工具调用，**这是手册的展示格式，不是原始 MCP JSON-RPC 报文**。在 Codex 中可让 AI 按此调用；程序调用应通过 MCP SDK 的 `call_tool(name, arguments)`。

示例中的 `<PROJECT_ID>`、`<PROJECT_SHA256>` 等必须换成前一步真实返回值，不能原样提交。不要复制其他项目的 ID，也不要重新打包一次 ZIP 后继续使用旧哈希。

| 值 | 来源与用途 |
|---|---|
| `project_id` | 导入/新建返回；标识同一个受管工程 |
| `project_sha256` | 当前修订整个 PCWEX 的 SHA-256；编辑、构建、打包的前置条件 |
| `code_sha256` | `project_read_pou` 返回；按字节绑定当前 `Code.st` |
| `variables_sha256` | 同上；绑定当前 `Variables.var` |
| `job_id` | `project_compile` 返回的构建作业 ID；下一步参数名是 `build_job_id` |
| `package_job_id` | `project_generate_pcwe` 返回；绑定生成包 |
| `inventory_sha256` | PCWE 文件清单及其哈希的身份；不等于 PCWEX 哈希 |
| `review_id` / `review_sha256` | 精确版本、包、目标和影响的审阅身份；不授予写权限 |

每次编辑成功都读取返回的新 `project_sha256`。同一事务修改多个 POU 前，先读取各自的两个工作表哈希，保证它们来自同一当前修订。源码或任务改变后，旧构建、旧包和旧审阅不能用于新修订。

受管目录示意（具体报告路径以工具返回为准）：

```text
D:\PLCnext-MCP-Workspace\
  <project_id>\
    original.pcwex
    revision-0000.pcwex
    revision-0001.pcwex
    manifest.json
    deployments\<package_job_id>\PCWE\...
    controller-download-reviews\<review_id>\review.json
    controller-download-preflights\<preflight_id>\result.json
    controller-transfers\<execution_id>\journal.jsonl / result.json
  controller-reads\<read_id>\result.json
  controller-download-approvals\...     # 真实下载的外部确认目录，普通测试不创建
```

不要从外部编辑受管 `revision-*.pcwex`、`manifest.json` 或包文件。若要测试外部修改后的工程，另存一个用户文件并重新导入。要交给 Engineer 或其他人，复制返回的 `project_path` 为一个新文件；本手册的自动测试不打开 Engineer。

## 5. NativeGateway 副本的离线测试

### 5.1 导入、检查和基线

```json
{
  "tool": "project_import_copy",
  "arguments": {
    "source_path": "D:\\PLCnext-MCP-Workspace\\a431bdc32f2a4aa1812c94683db38395\\revision-0000.pcwex"
  }
}
```

保存新 ID 和 SHA。调用：

```json
{"tool":"project_inspect","arguments":{"project_id":"<PROJECT_ID>"}}
```

读取需要检查的 FB：

```json
{"tool":"project_read_pou","arguments":{"project_id":"<PROJECT_ID>","pou_name":"NG_ReadAck"}}
```

POU 名必须来自 `project_inspect`；如果所选工程没有该名称，换为实际 FB。读取结果包含完整 ST、变量声明、工作表哈希和对象身份。需要“导出 FB 源码”时，可将返回的 `code` 与 `variables` 分别保存为新 `.st` / `.var` 文件；这不等同于官方所有格式的 FB 库包导出。

随后调用 `project_find_references`、`project_inspect_tasks` 和 `project_validate`。记录 POU 数量、已有 ID、程序实例绑定和映射成员清单。冻结基线为 61 POU；用户自己正在修改的工程不要求恰好 61。

### 5.2 修改与导入文本

仅改一个已有 ST 片段：

```json
{
  "tool":"project_patch_st",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "pou_name":"<EXISTING_POU_NAME>",
    "expected_project_sha256":"<PROJECT_SHA256>",
    "expected_code_sha256":"<CODE_SHA256>",
    "old_text":"<EXACT_EXISTING_FRAGMENT>",
    "new_text":"<REPLACEMENT_FRAGMENT>"
  }
}
```

`old_text` 必须恰好出现一次。第一次可插入一个明确的测试注释，验证编辑/差异/哈希保护；这只测试编辑链路。需要验证逻辑变化和接口修改时，用第 6 节的小工程，避免改变 NativeGateway 的业务逻辑。

已有 FB 的代码/变量文本导入使用 `project_update_pous`，字段是完整 `code` / `variables` 文本，不是文件路径。要修改接口及调用方，放进同一事务。工具不提供任意 FB 归档包导入和自动合并。

### 5.3 结构、映射与冷编译

编辑后运行 `project_validate`、`project_diff_pou`，检查只有预期成员变化、既有元数据 ID 与非目标映射成员保持。映射文件按字节保留不证明变量改名后映射仍正确；编译诊断、PCWE 绑定和最终设备行为仍需分别验收。

先调用：

```json
{"tool":"project_build_plan","arguments":{"project_id":"<PROJECT_ID>"}}
```

支持时返回 `status=mcp_cold_compile_available` 及准确的 `project_compile` 参数；不支持时读取 `unsupported_reason`，不要强行套用其他 profile。

```json
{
  "tool":"project_compile",
  "arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<LATEST_PROJECT_SHA256>"}
}
```

检查 `compiled=true`、`ast_seed_used=false`、语法/语义诊断、原生镜像输出以及输入哈希绑定。构建返回的 `job_id` 留给打包。未引用 FB 可能被编译器省略 DLL 或产生警告；先看诊断，不以 DLL 数量等于 POU 数量作为通过条件。

`project_compile_cached` 与 `project_compile_nativegateway(mode="cached")` 是保留的旧实验入口，有固定样例/缓存限制。日常测试统一用 `project_compile`；不要用缓存成功替代冷编译验收。

## 6. 新建工程、增删 FB 和接口修改

本节创建完全独立的小工程，不把测试代码混入 NativeGateway。测试前后各冷编译一次，并保存新建 Main 的原始代码、变量文本和 SHA。

### 6.1 新建与基线

```json
{"tool":"project_create","arguments":{"name":"MCP_Offline_Test_20261026"}}
```

记录新 ID，调用 `project_inspect`，默认模板含标准 ST `Main`。读取 `Main`、检查任务，先完成一次冷编译。新建名字不代表新设备 profile；`template_path` 可选，但只接受受支持的空设备模板结构。

### 6.2 原子新增 FB 和调用实例

下例只适用于本节新建的空工程。若 Main 已有声明或代码，必须保留并合并，不能直接覆盖为下面的测试文本。

```json
{
  "tool":"project_change_fbs",
  "arguments":{
    "project_id":"<TEST_PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "add_fbs":[{
      "pou_name":"MCP_Probe",
      "variables":"VAR_INPUT\n Enable : BOOL;\nEND_VAR\nVAR_OUTPUT\n Value : UINT;\nEND_VAR\n",
      "code":"IF Enable THEN\n Value := UINT#12345;\nELSE\n Value := UINT#0;\nEND_IF;\n"
    }],
    "updates":[{
      "pou_name":"Main",
      "expected_code_sha256":"<MAIN_CODE_SHA256>",
      "expected_variables_sha256":"<MAIN_VARIABLES_SHA256>",
      "variables":"VAR\n probe : MCP_Probe;\nEND_VAR\n",
      "code":"probe(Enable := TRUE);\n"
    }]
  }
}
```

通过条件：POU 1→2；新 FB 获得新对象/工作表 ID；`Main` 原有 ID 不变；引用查询能找到实例和调用；`project_validate` 通过；新修订冷编译成功。不宣称测试逻辑在 PLC 执行过。

若只增加一个无调用 FB，可用 `project_add_fb`；后续单独更新调用方时，仍使用那一步返回的最新工程 SHA。

### 6.3 修改 FB 接口并同步调用方

重新读取 `MCP_Probe` 和 `Main`，用当前两个工作表哈希替换下面占位符。本例把 `Enable` 改名为 `Run`，同时更新调用：

```json
{
  "tool":"project_update_pous",
  "arguments":{
    "project_id":"<TEST_PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "updates":[
      {
        "pou_name":"MCP_Probe",
        "expected_code_sha256":"<FB_CODE_SHA256>",
        "expected_variables_sha256":"<FB_VARIABLES_SHA256>",
        "variables":"VAR_INPUT\n Run : BOOL;\nEND_VAR\nVAR_OUTPUT\n Value : UINT;\nEND_VAR\n",
        "code":"IF Run THEN\n Value := UINT#12345;\nELSE\n Value := UINT#0;\nEND_IF;\n"
      },
      {
        "pou_name":"Main",
        "expected_code_sha256":"<MAIN_CODE_SHA256>",
        "expected_variables_sha256":"<MAIN_VARIABLES_SHA256>",
        "code":"probe(Run := TRUE);\n"
      }
    ]
  }
}
```

`updates` 每项都需要两个工作表哈希，并至少提供 `code` 或 `variables`；省略的文本保持原样，重复 POU、未知字段、旧哈希会拒绝提交。通过条件：接口/调用都变更，原有实例和元数据 ID 保留，非目标成员不变，冷编译成功。

### 6.4 删除保护与原子删除

先直接用 `project_delete_fb` 删除仍被 Main 引用的 `MCP_Probe`，**预期拒绝**，当前修订不变。随后读取 Main，在同一个 `project_change_fbs` 事务里恢复其原始代码/变量并删除 FB：

```json
{
  "tool":"project_change_fbs",
  "arguments":{
    "project_id":"<TEST_PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "delete_fbs":["MCP_Probe"],
    "updates":[{
      "pou_name":"Main",
      "expected_code_sha256":"<MAIN_CODE_SHA256>",
      "expected_variables_sha256":"<MAIN_VARIABLES_SHA256>",
      "code":"<SAVED_ORIGINAL_MAIN_CODE>",
      "variables":"<SAVED_ORIGINAL_MAIN_VARIABLES>"
    }]
  }
}
```

通过条件：POU 2→1；无残留调用或实例声明；任务绑定和既有 ID 不变；冷编译成功。新增再删除后 ZIP 整体哈希不保证回到最初值，结构登记序列化可能改变；应检查成员差异和行为，不以整个文件完全相同作为唯一条件。

### 6.5 建议的负向测试

只在这个小工程副本中测试：

- 提交旧工程 SHA 或旧工作表 SHA：应拒绝，不产生新修订。
- 添加重名 FB、删除仍被引用的 FB：应拒绝，原修订不变。
- 接口改名而遗漏调用方：编辑可能通过，随后冷编译应报告相应语义错误，不能报告编译成功。
- `BOOL` 形参传入不兼容类型：检查实际编译器诊断，不能跳过错误继续打包。

负向编译测试会留下一个有错误的副本修订；按当前 SHA 修复为正确源码后重新编译，不要回填旧 manifest。

## 7. 任务配置

`project_inspect_tasks` 读取源 ESM 配置、任务 ID、周期和程序实例绑定；它不是运行时测量。

```json
{
  "tool":"project_update_cyclic_task",
  "arguments":{
    "project_id":"<TEST_PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "task_id":"<TASK_ID_FROM_INSPECTION>",
    "updates":{"interval_ns":10000000,"watchdog_ns":100000000,"priority":20}
  }
}
```

单位是纳秒：10 ms = `10000000` ns，100 ms = `100000000` ns。两个时间字段范围为 1…86400000000000 ns，优先级 0…99，必须为整数。不要把毫秒数直接填入纳秒字段。

只支持已存在的单周期任务；可只提供其中一个字段。记录原值并在测试后用新 SHA 恢复。检查任务/程序实例 ID、绑定和其他配置保持，冷编译成功；不会改变真实 PLC 的运行周期。

## 8. 完整 PCWE 生成与检查

回到 NativeGateway 的受管副本，确认没有混用第 6 节小工程的 ID。完整打包的输入必须是**该工程当前修订的一次成功冷构建**。

可先检查缺口：

```json
{
  "tool":"project_deployment_plan",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "build_job_id":"<JOB_ID_FROM_COMPILE>"
  }
}
```

然后生成：

```json
{
  "tool":"project_generate_pcwe",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "build_job_id":"<JOB_ID_FROM_COMPILE>"
  }
}
```

检查 `package_complete`、`package_job_id`、`pcwe_path`、文件清单、输入/输出哈希和运行绑定报告。对返回的目录执行：

```json
{"tool":"deployment_inspect_pcwe","arguments":{"source_path":"<PCWE_PATH_FROM_GENERATION>"}}
```

它检查清单内文件的 SHA-512，不证明厂商签名或真实固件可加载。`deployment_stage_pcwe(source_path, expected_inventory_sha256)` 可以将完整现有 PCWE 创建为另一个本地冻结快照；**不是上传工具**，其结果也不能冒充当前工程的 `package_job_id`。

本轮冻结 61 POU 样例的基线为 48 个文件、77 个全局变量、109 个工程内 FB 实例、10 项 HMI 映射、81 个页面绑定。109 不包含库 FB 布局的逐字段验证；工程变更后这些数量可能合理变化。检查变量名、类型、实例/任务关系和映射内容，不能只比较数量。

新建的通用小工程可以冷编译，但完整 PCWE 生成可能按 profile 拒绝。这属于当前已声明限制，不表示编辑/IEC 编译失败。物理 I/O 完整映射、其他硬件/HMI 配置及厂商签名均未泛化支持。

## 9. 下载模拟与本机 TCP 测试

两个工具都只接受受管工程和生成包，不接受真实 PLC IP。先用 `project_download_plan` 检查包与流程计划；该计划自身不连接设备。

### 9.1 内存协议模拟

```json
{
  "tool":"project_simulate_download",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "package_job_id":"<PACKAGE_JOB_ID>",
    "fault":"none",
    "protocol_profile":"v4_tagged"
  }
}
```

使用 MemoryBIO 内存 TLS，模拟密码认证/令牌、文件写入、SHA-512 回读和 Reset/Load，不建立 socket。默认 profile 为旧 `v4_untagged`；也可显式测 `v4_tagged`。密码和权限测试仅证明本地模拟契约，真实下载当前是匿名模式。

可选 `fault`：`none`、`bad_credentials`、`penalty_active`、`permission_denied`、`session_expired`、`insufficient_space`、`write_error`、`short_results`、`transport_interrupted`、`readback_corrupt`、`reset_timeout`、`load_timeout`、`load_error`、`initial_running`、`untrusted_peer`、`hostname_mismatch`。注入失败应得到 `simulation_failed`；不应声称真实控制器已下载。

### 9.2 生产下载客户端的本机 TCP/TLS 测试

```json
{
  "tool":"project_test_controller_download",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "package_job_id":"<PACKAGE_JOB_ID>",
    "fault":"none"
  }
}
```

该工具自行启动 `127.0.0.1` 随机端口的测试设备，使用公开测试证书，生产客户端经真实 TLS/socket 写入新的本地测试目录；不允许改成外部地址。它不修改候选包，也不签发任何真实下载确认。

`none` 的通过条件：`status=loopback_download_passed`、全部文件 SHA-512 回读通过、`loopback_download_completed=true`、`controller_downloaded=false`、Reset/Load 测试状态完成、manifest 最后写入。`chunked_readback` 是另一种**成功用例**，用于检查多块流和大 buffer hint。

建议再测以下失败：

| `fault` | 应检查的行为 |
|---|---|
| `initial_running` | 要求已 Stop；不自动停机，不写文件 |
| `tls_error` | TLS/pin 失败；不进入文件写入 |
| `permission_denied` / `insufficient_space` | 失败并停止；不把只读能力当成写权限 |
| `write_error` / `short_results` | 检查每个结果及数量，拒绝继续 Reset/Load |
| `readback_corrupt` | SHA-512 不匹配，不能加载 |
| `write_reply_lost` | 写入可能发生，`outcome_unknown=true`，无自动重发 |
| `reset_reply_lost` / `load_reply_lost` | 配置动作可能发生，保留不确定事实，无自动重试 |
| `reset_timeout` / `load_timeout` | ACK 不等于动作完成；不能报下载通过 |
| `load_error` | 配置加载失败 |
| `rpc_error` / `fatal_error` | 解析远端协议错误，不能误当成功值 |

注入失败的正常测试结果是 `status=transfer_failed`，不是整个功能无效。必须结合 `files_may_have_changed`、`outcome_unknown`、`configuration_load_attempted`、`load_state_verified` 和操作日志判断失败位置；部分文件写入后报错不代表远端已回滚。

### 9.3 可直接复用的本机回归样例

以下是已经生成的**回归候选**，不是用户选定的真实部署版本；先检查其当前身份是否仍匹配：

| 字段 | 值 |
|---|---|
| `project_id` | `a2512e4f551645e4acd00fae07f003cd` |
| `project_sha256` | `e3c4c20638c83e22e3b15e1c541e86004d3be0a3e7dd8e7b73453692f29ad0b0` |
| `package_job_id` | `345799d58da449ef86866865021a3806` |
| `inventory_sha256` | `0a9d10de630f115c8b9df4916dab17387a4fe5cac8c1d0c55115c2dfbc8c1c10` |
| `review_id` | `29a6e79b0b984dc399f7b595d8216daa` |
| `review_sha256` | `69af4f624198c2c1a4b2cf408576ec158495059f9eb13f402d42408f24773244` |

若对象不存在或已变更，从第 5 节重新导入、冷编译、打包；不要更改账本绕过不匹配。

## 10. 真机只读检查

本节会连接真实设备；前面的离线/本机测试不需要执行它。本次已授权 `192.168.0.8` 只读，可先检查状态：

```json
{
  "tool":"controller_read_state",
  "arguments":{
    "address":"192.168.0.8",
    "port":41100,
    "expected_certificate_sha256":"3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863",
    "timeout_seconds":5
  }
}
```

IP 必须是字面 IPv4/IPv6，不是 URL 或主机名；pin 为证书 DER 的 SHA-256，当前值来自本设备已观察证书。若 pin 变化，先独立核对设备身份，不自动信任新证书或关闭校验。读取超时参数为整数 1…30 秒。

该工具只发 Connect、固定 PLC 服务发现和 GetPlcState；没有文件读取、认证会话、程序写入、Stop、Start、Reset 或 Load。匿名状态读取成功不代表匿名写入和配置加载可用。

### 10.1 准备本地审阅

只有在已经生成包后才能创建审阅；此步**不连接 PLC**：

```json
{
  "tool":"project_prepare_download_review",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "expected_project_sha256":"<LATEST_PROJECT_SHA256>",
    "package_job_id":"<PACKAGE_JOB_ID>",
    "address":"192.168.0.8",
    "port":41100,
    "expected_certificate_sha256":"3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863"
  }
}
```

输出绑定源版本、构建、包的逐文件哈希、目标和影响。应为 `authorization_status=awaiting_user_confirmation`、`write_authorized=false`。

`project_inspect_download_review` 默认 `revalidate_package=true`，再次检查本地身份与字节；关闭该参数仅用于读取历史审阅，不能代替执行前校验。

### 10.2 审阅绑定的设备预检

```json
{
  "tool":"project_preflight_controller_download",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "review_id":"<REVIEW_ID>",
    "expected_review_sha256":"<REVIEW_SHA256>"
  }
}
```

它按审阅中固定的目标/pin，匿名读取新鲜状态、固定 PCWE 根目录/空间信息，以及 `PCWE.manifest.config`、`PCWE.software-package-manifest.json` 两份元数据。Running 状态可做这些只读检查。返回提取的允许字段、哈希及清单差异，不返回或保存原始远端元数据内容，不支持任意路径读取。

完整读取应为 `preflight_read_completed`；缺一份元数据可能为 `preflight_incomplete`，异常为 `preflight_failed`。检查具体错误和报告，而不是把部分读取当成通过。

上一次只读观察中，设备正运行 `NativeGateway.pipeline-cost-candidate-v3`，远端清单声明 49 文件，冻结候选为 48，远端额外声明 `dlc.bin`，13 个共同文件的声明哈希不同。它们是历史观察，不是当前设备状态。用户正在持续调试，这些差异无需追赶；实际下载时再冻结要下装的版本。

**当前真实执行路线要求远端 manifest 声明的路径集合与候选一致。** 因而若仍是上述 49/48 差异，真实执行会在写入前拒绝；不会自动删除 `dlc.bin` 或放宽集合检查。先明确文件归属并制定单独的变更方案，不能修改审阅/哈希伪装一致。manifest 也不代表完整目录列表，未声明旧文件仍可能存在。

## 11. 真实下载的确认与执行

### 11.1 确认前应展示的具体内容

实际下载前应向操作者展示：所选源文件/修订/SHA、编译作业、软件名/版本、包清单 SHA、文件数/大小、目标 IP/端口/pin、当前新鲜状态、元数据差异、计划动作和预计影响。不能用“当前最新版”代替准确身份。

本轮版本仍由用户届时选择。确认必须包括覆盖包路径、逐文件回读、Reset/Load、程序配置中断、可能暂时无已加载工程、连接断开、加载后意外启动风险、保留未知旧文件以及无自动回滚。Stop 时的实际输出/保持行为和加载自动启动策略尚未验证。

客户端要求执行开始时 PLC 已为精确 Stop 状态。**当前审阅既不授权也不自动发送 Stop。** 若设备仍 Running，需另行安排明确授权的停机方式和窗口，不能仅因确认了包版本就停止设备。

### 11.2 当前确认门禁的实际接入方式

`project_execute_controller_download` 已有执行实现，但 **MCP 没有“批准下载”工具，也没有自动创建人工确认收据的脚本或界面**。实际测试需要受控操作者/宿主在收到真实人工确认后，独立落下精确收据；只在聊天里说“同意”不会由本 MCP 自动转换成收据。

收据路径：`<workspace>\controller-download-approvals\<review_sha256>.json`。它必须绑定全部以下字段：

| 字段 | 要求 |
|---|---|
| `schema` | `plcnext-controller-download-operator-approval/v1` |
| `review_sha256` | 当前精确审阅 SHA |
| `confirmed_by` | `human_user` |
| `target` | 原样匹配 `review.json` 的整个 `target` 对象 |
| `project_sha256` | 原样匹配 `review.source.project_sha256` |
| `inventory_sha256` | 原样匹配 `review.package.inventory_sha256` |
| `policy` | 原样匹配审阅中的固定策略对象，不能只选部分字段 |
| `approved_actions` | 有序数组：`write_package_paths`、`sha512_readback`、`reset`、`load` |
| `preserved_unlisted_remote_files_acknowledged` | `true`；人工已了解未列入清单文件可能保留 |
| `confirmation_reference` | 非空、可追溯的真实人工确认来源 |
| `confirmed_utc` / `expires_utc` | 带时区 ISO 时间；确认时间≤当前时间<到期时间，有效窗口≤3600 秒 |

`confirmed_by` 与 reference 是本地受信发行者约定，不是密码学人类身份证明。收据目录的文件写权限是信任边界；普通测试不要让 AI 自行伪造确认。准确契约见 [controller_transfer.py](../src/plcnext_mcp/controller_transfer.py)，策略见 [controller_download_plan.py](../src/plcnext_mcp/controller_download_plan.py)。本手册不生成收据，也不提供默认目标的一键批准命令。

执行前会排他创建 `<review_sha256>.claimed.json` 并 fsync，一次性消费；失败后也不会自动恢复为未使用。源码、包、目标或影响策略变更都需要重新审阅和真实确认。

### 11.3 经确认后执行

只有前述条件全部满足，才调用：

```json
{
  "tool":"project_execute_controller_download",
  "arguments":{
    "project_id":"<PROJECT_ID>",
    "review_id":"<REVIEW_ID>",
    "expected_review_sha256":"<REVIEW_SHA256>"
  }
}
```

没有收据时预期 `user_confirmation_required`，在 socket 建立前拒绝。**不要为了测试拒绝路径而在可能已有有效收据的真实目标审阅上调用执行工具**；先确认外部发行状态，或使用自动化测试里的无 socket fixture。

通过准入后的执行顺序：

1. 重新校验源、构建、包、审阅及收据；取得该端点排他租约；记录版本绑定日志。
2. 固定证书 pin 建立 TLS/RSC，动态发现服务句柄；读取新鲜状态，要求 Stop。
3. 检查固定 PCWE 根、空间及远端 manifest 路径集合；不一致则拒绝写入。
4. 写审阅中的包文件，`PCWE.manifest.config` 最后；不删除其他远端文件。
5. 回读全部文件，比较长度与 SHA-512；任何失败都不继续配置加载。
6. `Reset(true)` 后轮询精确 Ready；`Load(true)` 后轮询精确 Stop。ACK 只表示请求被接收，不代表完成。
7. 保存动作日志和结果；不发送 Start，不自动重试。

这是一条全包写入/配置重载路线，不是在线无中断增量修改。文件逐个覆盖也不是远端原子提交；manifest 最后写入不能提供断电回滚保证。

最终同时检查 `status`、`files_verified`、`load_state_verified`、`final_state_raw`、`receipt_persisted`、`endpoint_lease_retained` 和日志。即使看到加载完成，后续通信、变量值、任务时序、HMI、I/O 和业务效果仍需单独验收；当前 MCP 不提供完整运行变量监视、强制、断点或自动功能验收。

## 12. 失败处理与恢复

| 情况 | 处理 |
|---|---|
| 工具不存在 / 只有 23、30 或 34 个工具 | 核对启动解释器、安装版本和过滤设置；重启 MCP/客户端，重新发现 35 工具 |
| `Stale project revision` / 工作表哈希过期 | 重新读取当前工程与 POU，重新组织事务，不覆盖旧版本 |
| `Managed artifact changed outside MCP` | 保留证据，将外部修改文件重新导入为新副本，不手改 manifest |
| 不支持设备、任务、工作表或 PCWE profile | 阅读具体拒绝原因；使用受支持的输入，不能以改设备字符串绕过检查 |
| 编译器/库找不到 | 核对 `PLCNEXT_ENGINEER_DIRECTORY`、设备版本及工程引用库/相对 HintPath |
| 语法/语义错误 | 修复当前副本并重新冷编译；不要拿旧成功作业给新源码打包 |
| TLS pin 不同 / 网络超时 | 独立核对设备与网络；不自动换 pin，不自动重试有副作用动作 |
| 无确认、确认过期或已消费 | 保持拒绝；真正需要执行时重新审阅/确认，不伪造或复用收据 |
| 远端路径集合不同 | 在写入前解决具体差异；本工具不删旧文件，不把本地测试通过视为集合一致 |
| 回读不一致、配置错误、连接中断 | 保留日志并停止后续动作；先判断已发生的写入和设备状态 |
| 客户端超时、进程退出、`outcome_unknown=true` | 不能假设未发生；核实设备状态/文件和最后发送的动作，禁止盲重发 |
| `receipt_persisted=false` | 本地结果写盘失败不撤销已发生的设备动作；按已返回事实和 journal 恢复 |

失败后先保存 `report_path`、`journal_path`、审阅、源/清单 SHA 和 endpoint lease。`files_may_have_changed=true` 表示至少存在写入可能；`configuration_load_attempted=true` 表示 Load 可能已经生效；不能只凭最外层 error 判断“没有下载”。

端点租约在同一用户 profile 的固定目录 `C:\Users\windssea\.plcnext-mcp\controller-endpoint-leases`，按 IP/端口互斥，跨 MCP workspace 也生效。出现失败/不确定变更或结果保存失败可能保留租约。它不是跨用户、跨主机的分布式锁。

**不要删除 `.claimed.json` 或 endpoint lease 后直接重跑。** 先核实远端实际状态、对应 execution 的写入/加载记录和文件内容，完成明确的人工恢复，再安排新审阅/确认。当前没有自动回滚或通用恢复工具；只读 MCP 预检也不能回读任意文件来完成所有恢复检查。需要时使用另行授权的工程维护手段。

## 13. 测试清单与问题反馈

按顺序记录，通过一层再进入下一层；真机写入单列，不能因前面通过而自动执行。

| 编号 | 测试 | 通过条件 | 是否访问真实 PLC |
|---|---|---|---|
| T01 | 接入/发现 | 新进程 35 工具，环境路径正确 | 否 |
| T02 | 导入副本 | 新 ID、原文件哈希不变、POU/映射可检查 | 否 |
| T03 | ST 修改/差异 | 仅目标文本变化，旧哈希拒绝，非目标 payload 保留 | 否 |
| T04 | 新建工程 | 独立 Main/资源身份，基线冷编译成功 | 否 |
| T05 | 新增 FB+实例 | 1→2 POU、引用可见、冷编译成功 | 否 |
| T06 | 接口与调用方变更 | 同事务完成，已有实例 ID 保留，冷编译成功 | 否 |
| T07 | 删除保护与删除 | 有引用拒绝；原子移除调用后 2→1，冷编译成功 | 否 |
| T08 | 任务编辑/恢复 | 纳秒值正确，绑定/ID 保留，重新冷编译成功 | 否 |
| T09 | NativeGateway 冷编译 | 当前修订全部受支持 POU 重新解析，无项目 AST 种子 | 否 |
| T10 | PCWE 生成/校验 | 支持 profile 完整生成，逐文件哈希和运行绑定检查通过 | 否 |
| T11 | 内存模拟 | tagged/untagged 成功及注入失败符合预期 | 否 |
| T12 | TCP/TLS 测试 | none/chunked 成功，失败场景不越过相应阶段、不盲重试 | 否，仅 127.0.0.1 |
| T13 | 状态读取 | pin 固定，状态新鲜，报告没有控制或写入请求 | 是，只读 |
| T14 | 审阅/只读预检 | 版本绑定正确，差异报告明确，仍未授权写入 | 是，预检只读 |
| T15 | 确认门禁 | 无收据/过期/已消费/绑定错误均拒绝；用 fixture 验证 | 否 |
| T16 | 真机传输与加载 | 单独确认版本/影响、已 Stop、逐文件回读与加载状态通过 | 是，需单独授权 |
| T17 | 运行/业务验收 | 通信、变量、任务、HMI、I/O 及业务行为符合现场要求 | 是，另行安排 |

手工测试记录可以复制以下模板，保存为自己选定的新文件：

```text
日期 / 操作者：
MCP 版本 / Python / Engineer 版本：
测试编号：
源文件绝对路径 / 原文件 SHA256：
project_id / revision / project_sha256：
构建 job_id / package_job_id / inventory_sha256：
review_id / review_sha256（如有）：
目标 / pin / 操作范围（离线、loopback、只读、经确认写入）：
工具名 / 输入参数（不含密码等秘密）：
预期结果：
实际 status / failure_code / diagnostics：
files_may_have_changed / outcome_unknown / load_state_verified：
report_path / journal_path / endpoint_lease_path：
通过或失败 / 已知影响 / 后续处理：
```

仓库开发者回归命令（不连接真实 PLC，测试设备仅使用本机或禁止 socket 的 fixture）：

```powershell
Set-Location -LiteralPath 'D:\work\code\PLCnext-Engineer-mcp'
& '.\.venv\Scripts\python.exe' -I -m unittest discover -s tests -v
```

上一轮完整回归为 374 项：373 通过，1 项因 Windows 符号链接权限跳过；这是已有证据，不等同于读手册时又运行了一遍。

`tools/controller_download_client_mcp_e2e.py` 内含对 `192.168.0.8` 的只读访问，**不是完全离线脚本**；若只测试本机，使用本节 T01…T12 的 MCP 流程。历史自动化脚本有固定样例、版本或数量断言，不能一概当作任意工程的通用测试器。

## 14. 全部工具与参考资料

完整参数、默认值、影响范围和工具分组见 [35 工具参考](mcp-tool-reference.md)。机器可读的实际 FastMCP `inputSchema` 见 [mcp-tool-schema.json](mcp-tool-schema.json)，核对来源为当前已安装 0.5.0，不依赖当前聊天缓存的旧工具目录。

- [跨项目接入与配置](use-in-other-projects.md)
- [工程生命周期与冷编译范围](project-lifecycle.md)
- [变量接口与冷编译证据](nativegateway-cold-build.md)
- [独立任务配置](independent-task-configuration.md)
- [完整 PCWE 冷构建](pcwe-cold-build.md)
- [真实客户端、只读观察与发布验证](controller-download-client.md)
- [审阅门禁](controller-download-review.md) / [只读预检](controller-download-preflight.md)
- [ACI 替代覆盖账本](aci-replacement-coverage.md) / [官方实现静态分析](aci-analysis/README.md)

历史文档保留各阶段版本和工具数量；本手册与 0.5.0 工具 schema 是本次使用入口。真实设备的当前状态、源码版本和许可政策不从历史报告推断。
