# 三方联调 MCP 实施记录

开始日期：2026-10-26。用户本轮已授权实现全部 M01～M10，并允许把指定恢复归档下载至 PLC；真实变更仍经过精确版本/影响审阅和独立操作者确认。历史“只改文档”的计划保留为历史记录，不作为本轮授权。

始终不调用 ACI、CodeMeter 或 computer use。不改变原恢复源码。P06 性能场景不自动恢复；M07 故障只在本机测试，物理故障另行审阅。

## 冻结恢复输入

- 源：`D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex`
- SHA256：`7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154`，187545 bytes，32 POU。
- 新受管副本：`00e019b0b46d4834b384d868b50ec6b7`，revision 0，源未修改。
- 成功冷构建：`e6ae34ad870149468dc9a8d8957ce86a`，未使用工程 AST 种子。
- 初始 48 文件 PCWE：`a9b3c9f2d3034b2aa4e091d0d3d5ea2e`。
- 新 49 文件候选：`e359af6ff55549a8b9331478b58d5b93`；inventory SHA256 `8a3c240aa2080911d304ccc2f1dd1b6839a03f62f49090f009294fa784002483`。
- 新包使用显式 `empty_capability_v1` 策略，生成原厂有效的空 `dlc.bin`（0 bytes），清除旧下载能力历史而不伪造旧工程匹配。原厂纯 MemoryStream Save/Load 已通过，真机兼容尚未验证。

## 当前证据与边界

2026-10-26T06:08:19Z 只读预检：192.168.0.8 Running，远端软件声明 NativeGateway.p06-performance-v32-group2，49 个声明文件；旧 48 文件候选缺 dlc.bin。当前 pin 沿用已确认值。没有真实 Stop/Start/写/Reset/Load，未签发真实收据。

机器记录：[current.json](../artifacts/joint-implementation/current.json)。

## 0.6.0 集成验证更新

新 stdio MCP 从仓库外目录启动，55 工具发现、全部新增主要入口调用通过。记录：
[集成结果](../artifacts/joint-mcp-e2e/42f6fb383a544928a5f3684c860bbcee/result.json)。

同一未修改恢复源新副本 `17ae4361baa846868b14775bf1de15ea` 冷编译/49 文件 PCWE 通过。
候选包 `f7fc619d55ba42c091f4ca0efed23e73`，inventory SHA256
`c83ee20636924cfb29d9459127d77a88f4cbdbe444613a092f0bf373ec69a4cf`。
这是发布集成测试生成的候选，尚无真实操作者确认，不因本段记录获得写权限。

同一 loopback TLS peer 的恢复正例包括 6 个 session、连续端点租约、Stop、49 文件
写入/SHA-512、Reset/Load、ProjectName、Start、1767 字段/250 GOOD 窗口读取。
Running/GOOD 不替代真实 DATA/STORED/mock 及原采样摘要最终验收。

M10 额外副本（非恢复候选）33 POU / 2 周期任务的冷编译、完整包、运行关系及本机
分块传输验证通过：[证据](../artifacts/multitask-native-e2e/f95519debbc04016b43c23c3500cd7b9/verification.json)。
原恢复源仍为 32 POU / 单任务、原 SHA 不变。

## 并行文件责任

- operator_approval：M01 新交互发行端和测试已交付，继续 M10 任务/编译/运行配置/程序克隆，含 project.py 必要验证改动。
- control_chain：M02 精确控制协议、独立控制审阅/执行及 loopback。
- runtime_monitor：M03/M04 符号/类型白名单、只读 RSC 变量和快照。
- root：M05 原生空 DLC 与恢复包；M06 整体恢复计划和连续租约；M07/M08 后续集成；server/CLI 注册、版本、文档及最终实际验收。

所有真实操作前先完成可审阅包、状态/文件差异与影响。M01 CLI 不允许 AI 代签；当前本地受信发行者约定不被描述为密码学人类认证。
