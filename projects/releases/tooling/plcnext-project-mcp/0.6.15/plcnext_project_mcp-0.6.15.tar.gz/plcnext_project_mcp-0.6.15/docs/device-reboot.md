# 整机 reboot → 等待重连 → 确认自动运行

版本：0.6.11。独立 RSC/TLS 实现，不依赖 ACI、SSH 或 computer use。当前已实现本地协议验证；尚未进行真实 PLC reboot 验收。

## 入口与顺序

1. 使用已有 `project_prepare_runtime_read` / `project_read_runtime` 获取当前源绑定的读计划、BootId、配置摘要。NativeGateway 读计划应包含完整配置及全部点位 Quality。
2. `project_prepare_reboot`：传入 `project_id`、`expected_project_sha256`、`package_job_id`、`address`、`expected_certificate_sha256`、`read_plan_id`、`read_plan_sha256`、`expected_boot_id`、`expected_configuration`、`configuration_sha256`。配置格式为 `{"version":15,"device_count":50,"point_count":250,"enabled":true}`（示例；必须使用当前实际值）。摘要取运行读取报告的 `configuration_digest.sha256`。默认端口 41100，等待 240 秒，每 5 秒读取一次；允许等待 30–300 秒、间隔 5–30 秒。
3. `project_inspect_reboot` 检查返回的计划。之后调用 `project_authorize_controller_operation`，`kind="reboot"`、`review_id=plan_id`、`expected_review_sha256=plan_sha256`，沿用已有精确操作授权参数。MCP 可以签发，不要求独立人工终端。
4. `project_execute_reboot(project_id, plan_id, expected_plan_sha256)` 执行。同步调用，客户端超时应大于计划时限并留出本地收尾时间。
5. 另一个客户端可以用 `project_reboot_status` 查询本地结果，或 `project_cancel_reboot_wait` 取消后续等待。均使用相同三个标识参数。

成功状态为 `reboot_auto_run_verified`：固定整机 RestartDevice 已尝试一次，随后观察到新应用 BootId，且连续两次 BootId 稳定、PLC Running、配置及摘要一致、全部预期点位 GOOD。不会补发 PLC Start，也不会执行 Reset/Load、文件传输或变量写入。

## 异常与续查

发出前检查当前 boot、配置、运行状态、源及包绑定、证书和端点租约。检查不符则不重启。

重启指令的回复可能随设备断线丢失。执行器只重试读连接，不重发重启。超时、取消或运行验证失败后保留端点租约和证据。使用同一 `project_execute_reboot` 加 `resume_read_only=true` 可在新一轮同等有界时限内继续只读确认；不得借续查发送第二次 reboot。每次续查都重验已消费授权、原始基线、计划及租约字节。若设备没有自动运行，续查不会启动它。

已完成操作重复调用只返回原结果，不再次连接或重启；不会删除其他操作的新租约。状态查询只读本地证据，不代表实时设备状态。取消不撤销已经发出的设备重启。

## 影响与证明范围

整机和 PLC 程序会中断；易失 RAM 损失范围为 unknown，输出保持行为未经实测。包绑定防止调用错项目，但不构成内存中运行镜像哈希证明。BootId 是 NativeGateway 应用的启动标识，不是操作系统 boot ID，结果明确返回 `os_boot_id_verified=false`。当前确认规则依赖 NativeGateway 的 BootId/Active/Quality 模型，不承诺任意工程都能直接通过验证。

使用固定服务 `Arp.Device.Interface.Services.IDeviceControlService.RestartDevice()`，方法 1、无参数。官方接口说明：https://api.plcnext.help/api_docs_2025-9/classArp_1_1Device_1_1Interface_1_1Services_1_1IDeviceControlService.html 。本机托管程序集的 REA 元数据证据在 `evidence/reboot-service-20261027.json`。仅重建该方法，不开放任意设备 RPC、恢复出厂或固件更新。

本地记录位于托管项目 `controller-reboots/<plan_id>/`，包含 plan、started、baseline、send-intent、journal、result；运行读取的独立报告继续由原读计划保存。整次执行持有跨进程端点租约，防止下载/恢复交错。

## 本轮验证记录（2026-10-27）

- `tests/test_controller_reboot.py`：10 项通过。实际本机 TLS/RSC 编解码与独立连接，覆盖正常返回、回复丢失、非自动运行、旧 BootId、未授权、基线变化、取消、篡改基线、租约重放及配置/证书异常。
- 全套 `unittest discover`：614 项，613 通过、1 跳过，用时 120.265 秒；记录 `artifacts/reboot-research/full-tests.log`。
- `tools/verify_reboot_public.py`：隔离新进程确认 0.6.11 / 85 工具，reboot 授权种类可发现；指定 NativeGateway 副本本地 prepare/inspect/status 成功。使用历史基线仅验证本地接口，未授权、未连接 PLC、未发送重启。证据 `artifacts/reboot-research/public-verification.json`。
- 工具参考与实际 schema 一致，无遗漏中文范围说明。已运行的旧 MCP 进程需重连加载新版；不必为此重启 PLC。
