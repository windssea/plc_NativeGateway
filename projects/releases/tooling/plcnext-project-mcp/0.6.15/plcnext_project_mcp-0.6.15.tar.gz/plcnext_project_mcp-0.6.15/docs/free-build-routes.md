# 不依赖 ACI 的本机编译路线调查

> 后续研究已跑通 NativeGateway 固定种子的无界面编译，见 [当前结果与限制](headless-compile-research.md)。本页保留前期入口调查，其“未验证”状态只描述当时的调查范围。

日期：2026-10-23（北京时间）。目标：在 PLCnext Engineer 2026.0.4 / 9.0.373.0 上，为自有 MCP 找到不使用 ACI 的工程编译入口。下文静态调查只读检查安装文件、已有 PoC 和官方资料，没有调用内部构建组件或修改许可、CodeMeter、厂商文件。

后续运行验证：自有 MCP 生成的 NativeGateway 副本通过普通 Engineer 的 `项目 → 重建`，结果为 **0 个错误、0 个警告（MSG_GEN0024）**；没有调用 ACI、连接或下载到 PLC。见 [GUI 编译记录](../artifacts/native-mcp-e2e/gui-build-validation.json)。该结果验证了正常 GUI 路线，不代表已实现无界面编译；以下未验证项仍按各自调查范围记录。

## 结论

**目前有证据支持的替代路线是：MCP 自行读取/修改工程副本，普通 Engineer 界面负责 Rebuild，再采集编译结果。尚未发现可直接替代付费 ACI 的公开免费无界面 ST/IEC 工程编译 API 或 CLI。**

本机帮助明确把 ACI 描述为无用户界面运行 Engineer 的唯一方式。内部 MSBuild targets、CIL 后端加载器及命令系统确实存在，但这不证明它们是独立可用或受支持的外部 API。本轮未调用这些内部组件，也未研究绕过许可判断。

| 问题 | 状态 | 结论依据 |
|---|---|---|
| 是否有不下载的正常编译命令 | 已回答 | `Project > Rebuild`；本机帮助与官网一致 |
| 是否有公开免费无界面 ST 工程 CLI | 未发现；有限搜索 | 本机帮助把无界面操作归于 ACI；检索的帮助、配置和启动参数未给出完整入口 |
| 内部构建文件是否存在 | 已回答 | `.targets`、托管程序集和 CIL 加载器存在 |
| 内部构建文件能否直接编译 `.pcwex` | 未验证 | 没有完整公开输入契约或实测成功结果 |
| 编译结果能否从普通界面导出 | 部分回答 | 错误列表支持复制；日志支持 CSV；本机配置另有错误列表 CSV 命令，待运行验证 |
| 是否可以完全摆脱任何 GUI 编译步骤 | 未回答 | 没有支持该承诺的已验证入口 |

## 公开可用的正常 GUI 编译

观察：本机 `en/Help/BuildProject.htm` 的 62–76 行说明 `Project > Rebuild` 编译整个工程但不会自动传送到控制器；IEC 61131-3 节点还有单独重编译标准程序的菜单。`Project_Menu.htm` 的 84 行起有相同说明，且 Rebuild 默认快捷键一栏为 `-`。因此，不应编造 F5 为编译快捷键。F5 属于会写入并启动的命令，不能用于本轮约束。

来源：

- `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\en\Help\BuildProject.htm:62`
- `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\en\Help\Project_Menu.htm:84`
- [官方 Rebuild 说明](https://engineer.plcnext.help/2026.0_LTS_en/BuildProject.htm)

观察：`PLCNENG64.exe.Merged.config:4869` 定义 `Project.BuildAll`，显示名资源为 `Project.Rebuild@CommonResources.MenuStrings`，组件为 `Ade.Plc.PlcMediator`；`:12727` 将其加入 Project 菜单。这是正常菜单与内部命令名之间的静态映射，并不是对外可调用的 IPC 接口。

推断：如果之后验证 Windows UI Automation 能定位并 Invoke 该菜单，可把编译压缩为一次语义化 UI 操作，避免 AI 每次截图找菜单。这仍依赖已打开的正常 GUI 会话。本轮没有验证可访问性树，也没有启动程序，不能把此推断标为已经实现。

## 结果采集入口

观察：本机 `en/Help/MessageOutput.htm:163` 起说明 Error List 收集编译/解析消息，自动后台检查结束后才更新；`:299` 说明可以选择所有消息并复制到 Windows 剪贴板；`:303` 起说明日志可通过菜单导出 CSV。日志 CSV 与错误列表复制是不同能力，不能仅凭文档推导两者相同。

来源：

- `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\en\Help\MessageOutput.htm:163`
- `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\en\Help\MessageOutput.htm:299`
- [官方消息窗口说明](https://engineer.plcnext.help/2026.0_LTS_en/MessageOutput.htm)

补充静态观察：`PLCNENG64.exe.Merged.config:3870` 定义 `MessageWindow.CSVExport`；`:3874` 另定义 `MessageWindow.LogCSVExport`；`:8613` 起 `OutputWindow_Base` 上挂前者，`:8622` 起 `LogWindow_Base` 上挂后者。这支持本机可能具备错误列表 CSV 导出，但需要正常 GUI 验证实际启用条件、格式和完成时机。

建议结果记录包含：本次输入工程 SHA-256、开始/完成时间、Rebuild 完成状态、错误/警告条数、消息文件及输出文件身份。仅“未见错误”或“输出目录已有文件”不能证明此次全量编译成功；可能采到后台检查、旧日志或旧产物。

## 无界面 CLI 的搜索边界

观察：本机 `en/Help/SecurityGuidelines.htm:321` 明确写出 ACI 是无 UI 运行 Engineer 的唯一途径。对应 [官方安全指南](https://engineer.plcnext.help/2026.0_LTS_en/SecurityGuidelines.htm) 可用于复查产品说明。

对本机 `en/Help/*.htm` 检索 `command.line`、`commandline`、`headless`、`/NOUI`、`/BUILD`、`/REBUILD`，没有找到用于编译 `.pcwex` 的完整官方命令。命令行相关命中包括安装校验工具及其他设备/HMI 场景，不能据此充当工程编译 CLI。

REA 对 `Ade.ApplicationImpl.dll` 的静态元数据/CIL 检查：

- 文件 SHA-256：`52a36e96a39efd6f2409b9ef07ca04ebd0de87bf6908c658555c08d201e79cc8`
- MVID：`34979606-4874-47bb-b7b0-dddb0a1074a0`
- 身份 Evidence：`ev_6489af7ffdf6904b7f80e143b314e9c84e52e8af96280885f786bfd7095a269f`
- 成员 Evidence：`ev_432238ae12eca3086dcda37e396e0bc9c6a60daa41d509461c74f8f7affe8f17`（总体 coverage 为 partial；选取方法的 CIL 指令完整解码）
- `Ade.Application.StartupParameters.Parse`（token `0x06000089`）观察到 Restart、Splash、UI、CrashReport、Culture 及 UserStoryFile 相关分支，没有该方法内的 Build/Compile 参数。
- 对 REA 报告的 `ldstr` token 使用 .NET `PEReader` / `MetadataReader` 只读解码 `#US`，未加载目标程序集。字符串为 `/RESTART:`、`/NOSPLASHSCREEN`、`/NOUI`、`/CRASHREPORT:`、`/CULTURE:`、`.pcustx`、`.feature`。
- `Ade.Application.ApplicationStarter.ExecuteUserStory`（token `0x0600002a`）在此基类中的方法体仅 `ret`。这不能排除其他类覆写，但不能把方法名当成已可用脚本接口。

额外观察：`PLCNENG64.exe.UserStories.config` 配置了 `Ade.UserStories`、`Ade.UserStoryStepsImpl` 的 `BlackList` 项。本轮未更改配置、解除黑名单或试图利用该内部入口。帮助中未检索到用户脚本的公开契约。

以上是有限负搜索，不是对全部程序集、所有启动阶段和未来版本的不存在证明。没有因字符串 `/NOUI` 存在就宣称无 ACI 编译已可行。

## 内部编译文件为何不足以承诺独立替代

观察：安装目录的 `Ade.Compiler.targets` 是 MSBuild XML，注册了 `Ade.CompilerImpl.dll` 中的 `SemanticAnalysis`、`AssembleCompilerProject`、`GenerateCompiledResources` 等任务；构建项包括 `CompilerProject`、`CompiledResource`、设备描述及引用。`Build/Ade.Compiler.Eclr.targets` 定义了 CIL 生成、原生代码生成和镜像收尾等不同阶段；`Build/Ade.Compiler.PlcNext.targets` 还生成运行配置目录及软件包清单。

精确来源：

- `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\Ade.Compiler.targets:7`
- 同文件 `:327`（组装编译工程）、`:351`（语义分析）
- `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\Build\Ade.Compiler.Eclr.targets:7`
- 同文件 `:78`（GenerateCilCode）、`:82`（GenerateNativeCode）、`:94`（FinishEclrApplicationImage）
- `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\Build\Ade.Compiler.PlcNext.targets:7`

REA 静态检查 `CIL-Compiler/CilCompilerLoader.dll` 观察到 `Program.Main(string[])`、`CommandLineParser`、`RunCilCompiler(string[])`、原生库加载及文件回调，表明它确实有独立进程入口。没有证据表明这个入口承担完整的 ST 解析、工程对象加载、任务/实例配置、I/O/HMI 生成等全部步骤。

- 文件 SHA-256：`df0269553138ef3c84ef145e844a81281ab0ddfa6795cecedaaafcb0a4b7f281`
- MVID：`bef5488f-a29a-416a-816e-01fd0ca19aac`
- Evidence：`ev_22fd7b4f59678df159d35643be5448512285456341e1a734207043133338827e`（coverage partial）
- 相邻 `cilc-a64-*`、`cilc-arm7-*`、`cilc-x64-*` 文件和 MSBuild 阶段共同支持“机器码后端加载器”的推断，而非“`.pcwex` 整工程 CLI”实测结论。

未知：任务宿主服务、内存对象依赖、输入与缓存契约、版本稳定性、厂商支持边界及独立调用许可条件。没有这些结果，就不能把 `msbuild *.targets` 或直接反射内部 DLL 作为已完成方案。

## PLCnext CLI 的真实定位

观察：[官方 PLCnext_CLI 仓库](https://github.com/PLCnext/PLCnext_CLI) 将其描述为 C++ 工具链，管理 SDK/CMake、生成元数据并创建 Engineer 库。这是独立开发 C++ 组件的可行基础，不能据此认定它能编译现有 NativeGateway 的全部 IEC/ST 工程。若长期接受将业务逻辑移至 C++，可独立评估这一架构迁移；它不是现有 FB 编译的直接替换。

## 对自有 MCP 的建议边界

1. 工程清单、现有 FB/ST 读取、源代码替换、保存新副本、实例/变量映射比较：由自有代码完成，复用现有冻结工程与比较器。
2. 构建先提供正常 GUI 的小型适配器或构建请求文件；只有真正拿到本次 Rebuild 完成状态才能返回 `succeeded`。如果未运行，就明确 `not_run` / `manual_required`，不能用语法检查冒充厂商编译。
3. 优先验证错误列表的 CSV 导出或稳定的可访问性读取；在没有完整消息内容时不要让 AI 自动判定工程无错误。
4. 当前阶段不提供 PLC 连接、下载、启动、停止、在线变量写入等操作。

本报告只完成路线调查。它没有证明无需 ACI 的实际 GUI Rebuild 自动化、错误 CSV 格式或独立编译器已实现。
