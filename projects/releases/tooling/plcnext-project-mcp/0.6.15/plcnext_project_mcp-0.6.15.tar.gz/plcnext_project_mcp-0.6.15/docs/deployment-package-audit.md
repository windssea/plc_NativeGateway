# 冷编译到 PLC 部署包的离线审计

日期：2026-10-25。范围：已有工程副本、既有 GUI 产物和冷构建产物的只读比较。
本审计没有启动或控制 Engineer，没有连接、停止、写入或启动 PLC。

当前冷编译成功证明标准 ST 及声明能够生成 eCLR 镜像；还不等于完整运行工程包已生成。
`expanded_compile.py` 仍返回 `deployable=false`、`whole_project_rebuilt_from_pcwex=false`。
要把新镜像送到控制器，除传输和状态机外，还需补齐下列部署文件及其一致性验证。

## 样本及复核结果

使用仓库内已有的 GUI 冻结产物，避免读取正在变化的工程作为比较基准：

`artifacts/headless-research/cil-frontend/input/RES_23CA7F267545404C9FED5DC977A6399F/Configuration/Projects/PCWE`

完整逐文件大小与 SHA-256 见 [离线清单](../artifacts/deployment-package-audit/inventory.json)。
本机真实 GUI 缓存根为 `C:\Users\windssea\Documents\PLCnext Engineer\Binaries`；
常见文档中的 Public Documents 路径在本机不存在。缓存根只作定位核对，没有修改。

- PCWE 样本含 48 个文件；`PCWE.manifest.config` 登记另外 47 个文件。
- 47 个文件的 SHA-512 与 manifest 完全匹配。
- 资源目录的 `RES_….img`、`RES_…_complete.img` 与
  `PCWE/Plc/Eclr/eCLR.img` 在该样本中字节相同，均为 829664 字节，
  SHA-256 为 `5d22d1ed49915a40023c52664ad0786010bb01c28eda927a31f77c6f3dfb4e49`。
  这只证明该样本的镜像落盘关系，不证明任意控制器或增量写入均可这样处理。
- `Configuration/fileinfo.json` 有 46 条记录，恰好是 manifest 清单减去 `Libraries.crc`。
- 样本中 GDS 的 `Connectors`、`ComponentTaskRelations` 均为空，PLM 的
  `Libraries`、`Components` 也为空。因此该样本不能验证实际非空 GDS/I/O 映射的重建。

## 已观察到的部署目录

| 文件或目录 | 作用与当前缺口 |
| --- | --- |
| `Plc/Eclr/eCLR.img` | IEC 本机镜像。冷构建已有对应资源 `.img`，需绑定当前源版本及目标。 |
| `Plc/Eclr/SharedLibraries/IIoT_Library/libIIoT_Library.so` | 目标平台原生库。当前冷构建只提取托管 DLL，尚未生成这部分部署目录。 |
| `Plc/Esm/PCWE.esm.config` | 任务周期、看门狗、ESM 归属、MainInstance 和程序次序。必须与新 IEC 模型一致。 |
| `Plc/Gds/PCWE.gds.config` | GDS 连接配置。源 DataList 字节保留不等于已重新生成运行时连接。 |
| `Plc/Plm/pcwe.plm.config` | 程序库及组件实例配置。外部组件需要额外覆盖。 |
| `Plc/Domain/pcwe.plc.config` | 工程名称、工程 ID 和版本。不能保留不相干工程的身份。 |
| `Io/Arp.Io.PnC/*` | Profinet TIC、链接、诊断数据库及 CRC。需由本工程配置生成或有可证明的原样复用条件。 |
| `Services/Ehmi/*` | HMI 页面、变量与类型字典、脚本、校验数据。FB/变量接口变化可能影响其绑定。 |
| `Services/OpcUA/*` | OPC UA 服务器及客户端模块配置。应与发布变量及目标环境相容。 |
| `Libraries.crc` | 此样本为 8 字节库校验记录；不能用旧记录替代新库版本。 |
| `PCWE.software-package-manifest.json` | 设备产品代码、固件目标、软件版本与更新行为元数据。 |
| `PCWE.manifest.config` | 47 个文件的 SHA-512 和整体哈希；修改任一载荷后需重新计算。 |

上述是这个 GUI 样本实际包含的内容，不是已经确定适用于所有工程的最小必需文件集合。
标准控制器软件更新 ZIP 的完整外层布局尚未从“实际导出的 ZIP”验证；不能把单独 PCWE
文件夹直接压缩后就声明它是厂商兼容的软件更新包。

## 两个容易忽略的缺口

### 原生库不是托管 DLL

完整 GUI 包的 `libIIoT_Library.so` 为 4320156 字节。当前最终冷构建示例
`artifacts/final-cold-proof/.../builds/058c9f41edfd4f0eadda1522df5a8228`
里没有任何 `.so`；其中的 `IIoT_Library.dll` 只提供编译所需的托管声明部分。

已有较新 32-POU 冷构建任务的固定库输入
`artifacts/project-lifecycle-e2e/717384ffbd62456094cf9d3ac0b72555/workspace/8efdcb5864404d2595fa74bfbe767fdb/builds/bf68cd2d2931438e936b785e305bd52b/libraries/0001.pcwlx`
包含多个目标平台的 SO。库 `PROJECT.proj` 的 `FolderType=NativeLibrary` 节点记录
`AssemblyName`、`DeviceProfileType` 和 `DeviceProfileVersion`。

其中 `AXCF2152_26.0.2/libIIoT_Library.so` 与 GUI 包的 SO 完全相同，SHA-256 为
`12b5d548fe20ddef4ef709bfac998f076efde206a7e264da930e5a46f452b44d`。
同包另有不同的 `AXCF2152_25.0.3` 版本。工程 profile 是 2026.0.0，选中库却标为
2026.0.2，所以库选择不能仅用“版本字符串相等”实现；需要确认 Engineer 的版本兼容规则。
最小可行实现可先要求显式的、经过验证的设备 profile 与库成员映射，未知组合直接拒绝。

### 整体哈希还包含输入顺序

主代理通过 REA 确认 `Ade.SecurityImpl.dll` 的 `ProjectIntegrity.ComputeOverallHash`
（token `0x06000028`）按传入顺序将每个哈希十六进制字符串编码为 ASCII，增量计算 SHA-512。
`CreateManifestConfigFile`（token `0x06000023`）对原字典 Values 计算整体哈希，而输出 XML
中的 File 元素另按路径排序。因此读取现有 manifest 后，按 XML 顺序简单重算可能不匹配。

证据：`artifacts/deployment-research/rea-integrity-members.json` 和
`artifacts/deployment-research/integrity-selected-il.json`。
本审计尝试按 fileinfo 的 46 项顺序，在任意一个位置插入 `Libraries.crc`，均不能恢复样本
整体哈希。现有样本的 47 项文件哈希已验证，整体哈希的原始输入顺序仍未知，应分别报告。
自有新清单可以把输入顺序和 XML 顺序统一为确定的排序，并在离线测试中验证整体哈希算法。

## 可离线实现的最小方案

先实现部署审计和候选包，不向控制器开放未验证的“写入并启动”功能：

1. 接收确切 `project_id`、源工程 SHA-256、编译 job ID、镜像 SHA-256；确认冷构建报告
   成功、输入未变化、当前工程版本与编译版本相同，禁止自动选目录里“最新的 IMG”。
2. 对一份显式指定的完整 PCWE 基线做独立快照，验证所有 manifest 文件哈希和路径归属；
   记录该基线对应的工程、硬件、库与接口指纹，旧 GUI 产物只作为待验证的部署资产来源。
3. 比较非 IEC 源成员、任务、映射及外部库身份。所有未实现的变化必须列为阻止项。
   对新增/删除 FB 或接口变更，不能单靠“非目标 XML 未变化”认定运行时映射仍兼容。
4. 在全新目录中生成候选 PCWE：置入固定的新镜像、从固定库输入提取选定的原生库，
   生成一致的 ESM/Domain/清单，其余未重建模块明确记录来源和适用条件。
5. 生成本地部署计划，列出目标设备 profile、文件哈希、更新行为以及未验证项。
   保持 `deployable=false`，并明确区分“包结构/哈希通过”与“控制器实际接受并运行”。
6. 将文件暂存、校验、切换和回滚状态机接到本地文件系统替身，验证失败后的目录与日志，
   不把模拟成功解释为实际 PLC 传输或运行成功。

建议离线测试覆盖路径穿越/链接、缺文件/损坏 SHA、陈旧 job、源码变化、目标 profile
不匹配、原生库缺失/多候选、任务和映射变化、故障注入后保留原基线，以及重复请求的幂等性。
完整的有 I/O 映射工程、带 HMI 绑定的接口变化、Retain/Persistent、签名启用的目标和
在线变更兼容性，都需要单独样本或后续授权设备验证。

## 已落实的离线模块

配套实现为 `src/plcnext_mcp/deployment_package.py`：

- `inspect_pcwe(source_path)` 检查现成完整 PCWE 目录、逐文件 SHA-512、必需配置、
  路径和清单覆盖；整体哈希状态单独报告为 `verified` 或 `unknown_order`。
- `stage_pcwe(source_path, output_parent, expected_inventory_sha256)` 把固定清单版本
  复制到唯一新子目录，回读每个文件，并确认源目录仍为相同清单版本。
- 复制保留原 manifest 和所有签名字节，不重新签名，不创建 DAuM ZIP，不包含网络调用。

`tests/test_deployment_package.py` 的 15 个测试中 14 个通过，实际创建 symlink 的测试因
本机 Windows 账户缺少该权限而跳过。已通过真实 GUI 47/48 文件正例、字节篡改、缺失、
未列出、路径穿越、重复、旧清单哈希、只 IMG 拒绝、签名字节保留，以及独立 SHA-512
标准向量验证。所有返回仍为 `deployable=false`；这一步完成现成包的离线审计与暂存，
尚未把当前冷编译镜像重新组合成可用于真实控制器的部署包。
