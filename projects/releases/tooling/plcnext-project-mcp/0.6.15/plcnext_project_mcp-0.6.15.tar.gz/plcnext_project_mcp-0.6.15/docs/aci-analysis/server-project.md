# ACI 服务端：工程、IEC、编译与对象模型

分析日期：2026-10-26。目标为本机 PLCnext Engineer 2026.0.4 / 9.0.373.0 的 `Ade.ApplicationControl.ServerImpl.dll`。本轮只解析磁盘上的元数据与 CIL，没有启动 Engineer、操作许可、连接或下载到 PLC。

结论：ACI 是 Engineer 内部服务的门面。工程打开、创建、保存、IEC 交换、DataList、库和编译均委派给 Engineer 服务；它不是独立编译器，也不是完整可编辑的项目 AST。若用 ACI 实现 MCP，应保留有效 ACI 许可和 Engineer 后端，用任务状态、串行执行和结果回读包装这些接口。

## 身份与覆盖

| 项目 | 值 |
|---|---|
| DLL SHA-256 | `2472a11f283c04abae006b27ab883d435e9c0eb6dabb5c8e935977e37d05e628` |
| MVID | `21257623-89d2-4006-abde-ab3108addefe` |
| REA artifact Evidence | `ev_239d56757e0a410d25c7ed6b367100601bac3a80f4d9262f3598e1a1a9c4c6d0` |
| REA members Evidence | `ev_670357749e9e03c5dbb6ced106222bdaeb512f8082a26a9e3afdac609d9bbad4` |
| 元数据范围 | 174 个类型、1,292 个方法、475 个字段、5,944 条调用边 |
| 方法体范围 | 1,292 个 file-backed CIL 方法体，全部 present，无截断 |
| 签名范围 | REA 解码 915 个方法签名，377 个 unsupported；Cecil 静态补充可读签名 |
| 语义范围 | 全量索引；下文功能路径人工核查。没有逐一动态验证全部方法，也没有展开全部被依赖的 Engineer 子系统 |

REA 对该成员结果标记为 **partial**。这个标签必须保留：不能把“全部方法体已索引”写成“全部功能已验证”。下文 token 仅在上述 SHA-256 与 MVID 下成立。

完整材料：

- [REA 原始完整证据](../../artifacts/aci-analysis/server-project-rea-evidence.json)
- [Cecil 全量 CIL](../../artifacts/aci-analysis/server-project-il.json)
- [逐方法签名与调用索引](../../artifacts/aci-analysis/server-project-method-index.json)
- [空实现、条件异常和静默不执行清单](../../artifacts/aci-analysis/server-project-stubs.json)

## 分层调用关系

`gRPC *Service → ObjectModelManager / ObjectModelItemRepository → Project、Controller、Variable 等对象包装 → Facade* → Engineer 内部服务`。

gRPC 请求主要携带 GUID 字符串。`ServiceHelper.GetItemFromId<T>`（`0x06000399`）先解析 GUID，再查询对象仓库；对象不存在时抛 `ApplicationControlException`。这些 GUID 是当前后端对象句柄，不能当作跨 Engineer 重启或工程重开的永久标识。

不少改变工程状态的 Facade 方法经 `InvokeHelper.Invoke`（`0x0600015a`）切换至 `ISynchronizeInvoke` 所属线程。若无需切换则直接调用委托。Facade 将异常放入 `InvokeResult.Exception`，InvokeHelper 再抛出。这里存在 Engineer 的线程与生命周期约束，不能通过多线程批量 RPC 绕过。

## 功能与真实下游实现

下表是静态调用观察；不表示本轮运行了这些操作。

| 功能入口 | 服务端执行路径 | 关键 token 与边界 |
|---|---|---|
| 打开工程 | `ProjectService.OpenProject → Application.OpenProject → FacadeApplication.InvokableOpenProject → IProjectService.OpenAsActiveSolution` | `0x0600043c`、`0x0600003e`；工程已打开时拒绝替换 |
| 新建工程 | `ITemplateService.GetNewProjectTemplate("Empty") → IProjectService.CreateNewActiveSolution` | `0x0600003f`；使用安装内 Empty 模板，之后需要 SaveAs |
| 保存 / 另存为 | `IProjectService.SaveEditorsAndActiveSolution / SaveActiveSolutionAs` | `0x06000115`..`117`；带 ProjectType 的 SaveAs 要求输入文件名不含扩展名，再补 `.pcwex` 或 `.pcwef` |
| 关闭工程 | `IProjectService.CloseActiveSolution` | `0x06000118`；关闭后仓库对象进入 disposed 状态 |
| 普通编译 | `IPlcService.StartBuild(callback)` | `0x06000119`，异步完成 |
| 全量重编译 | `IPlcService.StartRebuild(callback)` | `0x0600011a`，异步完成 |
| 准备编译 | `IPlcService.StartPreparationBuild(callback)` | `0x0600011b`，不能把它自动等同于完整可部署产物 |
| 指定 POU 导入 | `IPlcOpenXmlImporter.Import`，过滤 `"POUs"` 分组与名称列表 | `0x0600011c`、`120`、`0x060004b0`..`4b5`；与 IEC 61131-10 全工程交换走不同服务 |
| 指定数据类型工作表导入 | 同上，过滤 `"DataTypeWorksheets"` | `0x0600011d`、`120`；范围由过滤器选择 |
| IEC 61131-10 导入 | `IIecXmlService.ImportService.ImportProjectWithoutUi` | `0x06000121`；没有在 ACI 层自行解析/重写 ST |
| IEC 61131-10 导出 | `IIecXmlService.ExportService.ExportProjectWithoutUi` | `0x06000122`；返回转换后的消息集合 |
| AutomationML 导入 | `IAutomationMLImportService.ImportAmlFile(uri,strategy)` | `0x0600011e`；异常可转换为错误消息，不只看 RPC 是否成功 |
| AutomationML 导出 | `IAutomationMLExportService.Export(uri,solutionDisplayName)` | `0x0600011f`；结果结合 `ConfigurableMessageRecorder.HasError` |
| DataList 导出 | `IDataListRepository.GetDataList → IDataListConfiguration.GetViewConfiguration → IDataListImportExport.ExportCsv` | `0x06000068`；选择 `.dl`、`.dlr4var`、`.dlr4svar`、`.dlr2pl` 视图配置 |
| DataList 导入 | `IDataListImportExport.ImportCsv(CommandParameters.AndAwaitExecution())` | `0x06000069`；这是映射编辑入口，不能只比较 ST 判断保真 |
| 添加库 | `ICommandManager` 的 `Edit.AddSystemLibrary` 或 `Edit.AddUserLibrary`，上下文 `ACIContext / TypeHierarchy` | `0x06000124`；ACI 仍复用 Engineer 命令机制 |
| 接受、删除、替换库 | `Edit.AcceptLibrary / Edit.RemoveLibrary / Edit.ReplaceLibrary` | `0x060000ae`..`b0`；Accept 受 IdMismatch/SignatureMismatch 状态约束 |
| 枚举控制器与部件 | 工程 ContentNode、拓扑节点及设备类型元数据 | `0x06000108`；IEC、Network 和 Unknown 分支 |
| 替换控制器类型 | `ContentNode.CanBeReplacedBy → ReplaceBy` | `0x0600006a`；设备与插入上下文必须合法，不是字符串改型号 |
| 枚举任务 / 程序 / FB 实例 | `IEsmInstanceTreeProvider.GetInstanceTree` 和 `TaskInstance / PouInstance` | `0x06000091`、`81`..`84`、`ec`..`ef`；实例树来自工程服务 |
| 读取变量、变量组 | 由工作表 URI 调用 `IVariableRepository.Fetch` | `0x06000156`、`157`；变量对象不是在线过程值 |
| 修改现有变量 | `IVariableElementBase.Rename`、`IVariable.DataType / InitValue / IsRetain / IsOpc / IsProficloud / IsRedundant / Comment` | `0x06000315`..`324`；需要另行编译确认类型和引用仍有效 |
| 变量移组 | 从原集合解绑、调用模型 Delete，再把同一模型加到目标组 | `0x06000327`、`33a`；内部 AddVariable 不是公共新增变量 API |
| 删除 POU | 按显示名找逻辑 POU 节点，`ISolutionManager.ExecuteCommand("Delete",node,null)` | `0x060000f7`、`f8`；ACI 层未显式进行调用引用保护或实例重映射 |
| 删除任务 | 操作 ESM 配置树 builder、创建 Remove 变更并交给 updater | `0x06000151`；不是简单从返回列表删除 |
| 新建/插入/删除设备实例 | `INetworkConfiguratorService.Composer`、拓扑类型、槽位合法性判断 | `0x06000192`..`198`；Create 与 Insert 分开，创建对象不代表已插入工程 |
| 设备 Setting/Parameter | 将字符串经 `FdcmlCoreType` 转换后写拓扑属性 | `0x06000168`、`177`；类型不存在或转换失败时可能静默不写 |
| 编译器选项 | `ApplicationCompilerOptions → FacadeApplicationCompilerOptions → IConfigurationService` | 允许扩展标识符、写 Function 的 VAR_INPUT、动态 SFC 信息数组；并非所有编译选项 |

POU 列表由 `LastBuildResult.CompilerProject.ProgramOrganizationUnits` 创建；公共 POU 对象提供名称、种类和删除入口。**没有发现 ACI 公共 POU 对象直接提供 ST 主体 getter/setter。** 对源代码和 FB 定义接口的修改，应使用 IEC 交换或独立工程编辑后重开验证，不能假装是直接 AST 编辑 API。

## 打开、编译与通知时序

`FacadeApplication.InvokableOpenProject`（`0x0600003e`）先 SuspendBuildQueue、ClearBuildQueue，打开后在 finally 中 ResumeBuildQueue。若存在活动工程，则订阅 CompilerManager.CompileFinished，再启动 Build；之后才触发 ACI 的 ProjectOpened。新建工程（`0x0600003f`）类似。因此“Open RPC 返回”与“已完成初始化编译并可枚举”是两件事。

`Project.Compile`（`0x060002df`）只选择 Build / Rebuild / PreparationBuild 并启动。完成后 `ReportCompileResult`（`0x0600010e`）读取 `IMessageService.Messages`，`OnCompileFinished`（`0x0600010f`）构造 `CompileEventArgs`，包含转换后的状态、消息文本、类型 ID 和消息 GUID。这里读取的是当时消息服务的集合，并非一个由 ACI 请求 ID 标识的独立编译日志。

`ProjectService` 的三个通知流：

| 通知 | 生产者 | 流状态机 |
|---|---|---|
| ProjectOpened | `0x0600044e` | `0x06000506` |
| ProjectClosed | `0x0600044f` | `0x06000504` |
| CompileFinished | `0x06000450` | `0x06000502` |

观察到它们各使用服务对象字段保存一个响应对象，再通过 `ManualResetEvent` 唤醒 `WriteAsync`；写完置空并 Reset，然后 WaitOne。完成通知没有独立 job ID。**推断：并发编译、多个订阅者或短时间多次事件可能发生关联不清或共享槽覆盖，不能从静态代码证明它是可靠多消费者队列。** MCP 应每个 Engineer PID 只有一个会话执行器，订阅完成事件后再启动操作，并把 MCP 侧 job ID 关联到当前唯一活动操作。

超时表示等待方未在期限内收到完成，不证明 Engineer 已停止处理，也不证明导入/保存未发生。应记录 uncertain 状态、检查工程和消息后决定下一步，避免自动重发写操作。

## 明确的未实现和静默边界

全 DLL 扫描得到 10 个显式构造 `NotImplementedException` 的方法，其中 7 个属性访问直接抛异常：

| 属性 | token |
|---|---|
| `FunctionBlockInstance.Comment` | `0x06000217` |
| `ProgramInstance.Comment` | `0x060002be` |
| `Task.EventName` | `0x06000302` |
| `Task.Interval` | `0x06000303` |
| `Task.Priority` | `0x06000304` |
| `Task.Watchdog` | `0x06000305` |
| `Task.Comment` | `0x06000306` |

这些属性虽在 API 和 RPC 中存在，但本机服务端没有实现。MCP 列工具或序列化实例树时必须排除它们，或者逐字段返回 unsupported，避免一次读取拖垮整个快照。

另 3 个是条件分支：

- `DeviceTypeProvider.OnOpenSolutionsChanged`（`0x06000006`）：Add / Remove / Reset 有实现，Replace / Move / 未知枚举值走 NotImplemented。
- `ConnectionEndpointCollection` 构造（`0x060001d9`）：已知 Unknown / Simulation / TCP/IP 有实现，超出这些枚举值才抛出。
- `ControllerPartCollection` 构造（`0x06000200`）：已知 Unknown / IEC / Network 有实现，超出枚举值才抛出。

还有一个不能当作真实检索结果的保留实现：`FacadeDeviceInstances.GetNextFreePosition`（`0x06000190`）CIL 只有 `ldc.i4.0; ret`，总是返回 0。`ApplicationControlServerComponent.IsEnabledForUI`（`0x06000395`）同样恒 false，但属于服务策略，应结合安全/启用分析理解，不能机械标成缺陷。

没有找到直接构造 `NotSupportedException` 的方法，也没有只有 `ret` 的空 void 方法。这些是本 DLL 的有界扫描结果；**不证明其余方法全部支持所有设备或调用场景。**

静默不执行的例子包括设备 Setting/Parameter 无匹配类型或无法转换时直接返回，IPv4 属性不存在时直接返回，以及在线 service 缺失/CanExecute=false 时返回默认值或结束。在线部分见配套安全/在线报告。仿真端点只有在 `CommunicationSettingsHelper.SimulationSupported` 为 true 时才被加入端点列表；枚举到仿真端点不意味着自动改为仿真运行。

## 缓存与实例/映射保留

`FacadeIecComponentCategory` 构造（`0x0600008a`）保存当时的 `LastBuildResult.CompilerProject`；`get_ProgramOrganizationUnits`（`0x0600008c`）首次构造并缓存 POU 列表；`IecComponentCategory.get_ProgramOrganizationUnits`（`0x06000225`）再次缓存对象集合。Project、ControllerPart、变量和实例集合也含惰性缓存。

在所核查的导入完成和 CompileFinished 路径中，未见刷新上述 POU 快照的逻辑。**推断：结构修改后旧句柄/枚举可能陈旧，具体刷新行为仍需动态验证。** 最稳妥的验证顺序是保存副本、关闭、重开、等待初始化完成，然后重新枚举工程/任务/实例/变量；不要跨重开复用 ACI GUID。

既有真实离线证据可以复用：[2026-10-23 ACI 往返验证](../aci-poc.md)。当时 31 POU 的副本仅修改一个现有 FB 注释；三次 Rebuild 成功，98 项保留检查通过，POU ID 保留，目标工作表 ID 重建，任务/实例和 DataList 字节保留。本轮静态分析补充“为什么该路径能调用”，没有重新运行该验证，也不能把注释往返结果扩大为任意变量接口修改或删除引用中 FB 后均保留实例。

ACI 层没有暴露一套完整“FB 删除后修复引用与端口映射”的事务。MCP 应先执行引用扫描和预期差异检查，再修改副本，以 IEC 导出、ESM/DataList/变量快照、编译结果、保存重开后的结果共同验收。

## MCP 参考实现要求

1. **保持后端边界。** ACI 适配器调用厂商客户端和已授权后端；独立冷编译后端单列能力，不把 ACI 的编译/硬件支持宣称为自有实现。
2. **能力来自真实可用路径。** 暴露工程创建/副本打开、保存、导入导出、编译、实例与现有变量读取/修改、库和 DataList；为显式 stub 标注 unsupported。新增 FB/变量定义通过交换文件流程实现。
3. **每 PID 串行。** 一个 gate、一个事件订阅器、一个当前操作；MCP 自有 job ID/进度/超时状态。RPC 返回后仍需等待对应完成事件。
4. **结构更改后重建视图。** 对比代码、变量接口、调用引用、任务/程序实例、DataList 和必要设备文件；保存重开后重查，不复用旧仓库对象。
5. **成功有后验条件。** Import/Export 检查全部消息及文件；SaveAs 检查 bool 和实际文件；变量/设备属性写后读回；编译检查完成事件结果。不能把没有 RPC 异常等同于工程更新成功。
6. **错误保持层次。** `ServiceHelper.CreateRpcException`（`0x0600039a`、`39b`）把 ACI 异常转换为 gRPC Internal(13)，原消息放 `ade.servererror.message` trailer；普通异常再包为 Internal server exception。适配器应保留该错误文本和操作阶段，不只输出笼统 Internal。

剩余未知：全部依赖服务内部的约束与错误恢复、其他设备/安全工程/图形语言的真实往返保真、任意接口变更后的编译与映射、并发通知的动态行为、结构修改后所有缓存的刷新条件。完成这些验证之前，不应宣称对全部 Engineer 功能实现了 MCP 等价替代。
