# 在其他项目中使用 PLCnext MCP

本轮开发版本已推进到 **0.6.0**，新增精确控制、运行变量监视、整体恢复与独立多任务入口；工具数由实际 schema 导出，不沿用历史计数。当前入口见 [使用手册](mcp-user-guide.md) 和 [三方清单实施说明](joint-implementation-user-guide.md)。下文有日期的 0.5/0.4/0.3 记录均保留为历史证据。

当前测试入口见 [0.5.0 完整使用与测试手册](mcp-user-guide.md)；全部参数见 [35 工具参考](mcp-tool-reference.md)。本页保留安装与跨项目使用记录。

MCP 服务安装一次，多个项目共用。客户端通过 stdio 启动服务；项目文件用
`source_path` 导入副本，每个副本分配独立 `project_id`。不需要在每个工程目录
重新安装服务，也不需要把服务代码复制过去。

2026-10-26 更新：原注册配置不变，0.5.0 已有 **35 个工具**。新增真实 TLS/TCP 下载客户端本机验证、审阅绑定只读预检及人工确认门禁；真实目标仍未写入。[本轮证据](controller-download-client.md)。0.4 阶段新增的任务配置、替代账本和 tagged 模拟保留在 [历史记录](independent-aci-replacement.md)。

以下保留 2026-10-25 的功能推进记录：新增 `project_generate_pcwe` 时真实 MCP 有 23 个工具。
工程编辑和 IEC 冷编译可按设备/源特性检查用于其他项目；完整 PCWE 生成目前仅支持已验证的
NativeGateway 硬件/服务及 Gateway/Login HMI 配置。调用步骤和边界见 [PCWE 冷构建](pcwe-cold-build.md)。
已开启的 MCP 进程需重载才会发现新增工具，不需重复注册。

同日又新增下载离线模拟工具，当时为 **25 个工具**。可调用 `project_download_plan` 和
`project_simulate_download` 验证生成包的认证/写入/加载流程，输入仍是 managed project_id 与
package_job_id；不接受 PLC 地址或真实凭证。见 [调用参数和完整边界](plc-download-simulation.md)。

## 1. 准备固定的服务环境

当前仓库的 `.venv` 已可使用。后续请保持仓库和该环境路径稳定。也可以把服务
安装进自己管理的 Python 3.11+ 环境，例如：

```powershell
py -3.11 -m venv 'D:\tools\plcnext-mcp-env'
& 'D:\tools\plcnext-mcp-env\Scripts\python.exe' -m pip install 'D:\work\code\PLCnext-Engineer-mcp'
```

独立环境安装后，下面生成配置时加上
`-PythonPath 'D:\tools\plcnext-mcp-env\Scripts\python.exe'`。使用独立安装的包时，
仓库不必是客户端的当前目录。

升级时使用同一解释器安装当前 0.6.0 wheel（旧包不含本轮新增能力）：

```powershell
& 'D:\tools\plcnext-mcp-env\Scripts\python.exe' -m pip install --upgrade 'D:\work\code\PLCnext-Engineer-mcp\dist\plcnext_project_mcp-0.6.0-py3-none-any.whl'
```

也可以直接从更新后的仓库安装，二选一：

```powershell
& 'D:\tools\plcnext-mcp-env\Scripts\python.exe' -m pip install --upgrade 'D:\work\code\PLCnext-Engineer-mcp'
```

安装完成后，在客户端重启 MCP 服务，让新进程加载更新后的包。

## 2. 生成客户端配置

本机 Codex 可以一次注册后供不同项目使用。以下命令按本机 `codex mcp add --help`
核对，语法与 [OpenAI Docs 的 MCP 配置说明](https://learn.chatgpt.com/docs/extend/mcp?surface=cli)
一致；默认配置存于用户级 `~/.codex/config.toml`。在 PowerShell 中执行：

```powershell
codex mcp add plcnext-project `
  --env 'PLCNEXT_MCP_WORKSPACE=D:\PLCnext-MCP-Workspace' `
  --env 'PLCNEXT_ENGINEER_DIRECTORY=D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0' `
  -- 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -m plcnext_mcp.server
codex mcp list
```

重新加载 MCP 服务后，在其他项目对话里直接指定要导入的 `.pcwex` 绝对路径即可。
2026-10-24 已在本机执行上述注册，服务名为 `plcnext-project`，状态为 enabled。
配置位于 `C:\Users\windssea\.codex\config.toml`，副本及编译数据存于
`D:\PLCnext-MCP-Workspace`。本机无需重复注册；已打开的会话如未发现工具，
请重载 MCP 服务（必要时重启 Codex），再在其他项目会话中使用。

已直接读取 `codex mcp get plcnext-project --json` 返回的启动配置，以真实 MCP
stdio 会话验证 19 个工具可发现。启动命令、参数和环境变量保持注册值，从两个
仓库外目录分别启动服务；第二个服务进程成功读取第一个创建的工程。
新建工程、添加 FB 并调用、移除调用及删除 FB 三个阶段的冷编译全部通过，
耗时分别为 5.45、4.70、4.16 秒；未使用工程 AST 缓存种子。官方模板哈希不变，
对象 ID 和映射数据检查通过。此次只验证离线文件及生成物，未连接或下载到 PLC。
详见 [本机注册验证记录](../artifacts/codex-registration/ff442212ebbf47039c9d370d25634d16/verification.md)。

需要复测时，可以从任意目录运行下面的脚本；每次都会创建新的工程副本及报告：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I 'D:\work\code\PLCnext-Engineer-mcp\tools\registered_mcp_e2e.py'
```

其他支持通用 JSON 的 MCP 客户端，可以使用下面的配置生成脚本。

在任意目录运行以下命令，脚本会打印可复制的 JSON：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\tools\Configure-Mcp.ps1' `
  -Workspace 'D:\PLCnext-MCP-Workspace' `
  -EngineerDirectory 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
```

`Workspace` 是服务管理副本、修订和编译结果的目录，可以共用，也可以为不同工作
指定不同目录。`EngineerDirectory` 指向已经安装的 Engineer；编译仍依赖其中的
编译器、设备配置和库。脚本默认使用仓库 `.venv`，并验证该解释器能导入服务包。

输出格式如下。将 `mcpServers` 下的 `plcnext-project` 项合并进客户端支持的 MCP
配置位置；不同客户端的外层配置格式可能不同。

```json
{
  "mcpServers": {
    "plcnext-project": {
      "command": "D:\\work\\code\\PLCnext-Engineer-mcp\\.venv\\Scripts\\python.exe",
      "args": ["-I", "-m", "plcnext_mcp.server"],
      "env": {
        "PLCNEXT_MCP_WORKSPACE": "D:\\PLCnext-MCP-Workspace",
        "PLCNEXT_ENGINEER_DIRECTORY": "D:\\Program Files\\PHOENIX CONTACT\\PLCnext Engineer 2026.0"
      }
    }
  }
}
```

解释器和数据目录均为绝对路径；Python 的 `-I` 模式使模块加载不受客户端当前目录
或 `PYTHONPATH` 影响。需要先安装服务包，不能仅依靠进入源码目录来导入。

如果客户端支持项目内 `.mcp.json`，可显式指定输出路径：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\tools\Configure-Mcp.ps1' `
  -Workspace 'D:\PLCnext-MCP-Workspace' `
  -EngineerDirectory 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0' `
  -OutputPath 'D:\MyPlcProject\.mcp.json'
```

脚本只在提供 `OutputPath` 时写文件，父目录须已存在；已有配置会报错并保留原文件。
脚本不会修改用户全局配置。完成后按客户端的方式重新加载 MCP 服务。

## 3. 在 AI 对话中选择工程

先让 AI 调用 `server_capabilities` 查看当前安装和编译能力，再选择一个入口：

- 继续已有工程：`project_import_copy(source_path="D:\\Projects\\Example.pcwex")`。
  原文件保留，后续操作针对服务管理的副本。
- 新建工程：`project_create(name="Example")`。默认从官方 AXC F 2152 设备空模板
  创建包含 ST Main 的工程；可用 `template_path` 指定支持的模板。

保存返回的 `project_id`，后续工具都使用它选择工程。多个工程可以使用同一个
MCP 服务；不要把另一个工程的 ID 或旧修订哈希用于当前工程。

常见工作顺序：

1. 用 `project_inspect`、`project_read_pou` 查看当前工程和源代码。
2. 修改已有 ST 用 `project_patch_st`；同时调整变量接口和调用方用
   `project_update_pous`。
3. 添加或删除 FB 用 `project_add_fb`、`project_delete_fb`。需要把 FB 增删及调用方
   修改作为一次操作时用 `project_change_fbs`。
4. 用返回的最新工程哈希调用
   `project_compile(project_id=..., expected_project_sha256=...)`，查看新的语法、语义
   及代码生成结果。涉及编辑的工具要求对应的最新源代码/变量哈希，以避免覆盖旧版本。

可以直接对 AI 说：“导入 `D:\Projects\Example.pcwex` 的副本，读取 Main，新增一个
指定接口的 FB 并更新调用方，然后编译，把诊断和输出路径告诉我。”

当前服务处理离线工程副本；不会连接 PLC、下载或运行生成程序。冷构建仍有设备、
工程结构和库支持范围，成功生成离线镜像不代表已完成硬件/HMI部署包验证；以工具
返回的能力和 `deployable` 字段为准。
