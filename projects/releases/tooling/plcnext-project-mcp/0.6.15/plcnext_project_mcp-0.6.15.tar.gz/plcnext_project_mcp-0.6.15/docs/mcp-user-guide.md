> 0.6.10 / 80 工具：补齐启动观测失败与外部恢复后的精确租约交接，并支持预算内初始化只读重试。

> 0.6.9 / 79 工具：新增显式 decision_clock_slots_v2 原始事实导出，兼容旧v1；详见 decision-clock-slots-audit.md。

> 0.6.8 / 79 工具：新增可选 source_cohort 有限源窗口关联闭合；raw_tail 默认语义不变。

> 0.6.7 / 79 工具：补齐 partial 零 ACK 核销、自淘汰读游标解释，以及原始审计/业务 UNKNOWN 的独立完整性口径。

> 0.6.6：补齐启动超时零 ACK 的受控租约核销；应用 BootId 按父期限等待并验证启动前缀。仍为 79 个工具，详见 [恢复与审计](recovery-start-audit.md)。

> 2026-10-26 更新（0.6.5）：恢复流程支持Start前预备、Start后立即审计，共享精确父租约；新增父审计失败受控核销。79工具。[调用与边界](recovery-start-audit.md)。

> 2026-10-26 更新（0.6.4）：新增 M12 原生审计导出，78个工具；先fsync再确认固定审计游标，已完成本机TLS验证，真机吞吐待验。[调用与边界](audit-export.md)。

> 2026-10-26 更新（0.6.3）：新增同步 execution_id 核销与审阅绑定的观察窗口，73工具；当前同步旧租约已通过公开接口核销。未恢复原工程。[M11-S说明](lease-reconciliation.md)。

> 2026-10-26 更新（0.6.2）：新增 M11 受控租约核销，72 个公开工具；当前旧租约已通过公开工具核销，PLC Running、250 GOOD，无设备写入。[调用与验收](lease-reconciliation.md)。

> 2026-10-26 更新（0.6.1）：用户已取消独立人工签发限制。MCP 可调用 `project_authorize_controller_operation`，自行决定并授权 download/control/recovery/instrumented_fault；无需人工终端。精确哈希、目标、有效期、一次性领取及审计仍有效。下文旧终端流程为可选方式。 [MCP自主授权及本次真机结果](mcp-managed-authorization.md)。

# PLCnext 独立 MCP 使用与测试手册

当前源码 **0.6.5**。工具数量/参数/枚举见 [实际工具参考](mcp-tool-reference.md) / [Schema](mcp-tool-schema.json)，完整新增流程见 [M01～M10联调指南](joint-implementation-user-guide.md)。[0.5.0历史手册](mcp-user-guide-0.5.0.md)已归档；其单任务、无变量读或无操作者入口等限制不作为当前说明。

不调用ACI、CodeMeter、Engineer界面或computer use；编译仍使用本机厂商组件和引用库。所有工程编辑生成副本，源文件只读。

## 1. 恢复对象与边界

```text
D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex
SHA256: 7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154
32 POU，单周期任务
```

旧61POU候选、多任务副本和故障插桩副本不替代该恢复源。实际操作重新取源/包哈希，不复用旧审阅。用户允许准备并下载，设备变更前仍须展示精确包版本、目标及停启影响，由 MCP 自主授权并记录 mcp_policy 来源；独立终端可选。

## 2. 接入、安装与刷新

本机已注册 `plcnext-project`，Python为 `D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe`，参数 `-I -m plcnext_mcp.server`；工作区 `D:\PLCnext-MCP-Workspace`，安装组件 `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0`，用户配置 `C:\Users\windssea\.codex\config.toml`。

```powershell
codex mcp get plcnext-project --json
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -c "import plcnext_mcp; print(plcnext_mcp.__version__)"
```

更新后重启MCP；仍见旧目录时重启客户端并在新会话发现工具。核对实际解释器、源码版本与Schema；editable源码和旧distribution metadata可能暂时不同，安装升级后重新核对。本机无需重复注册。用户配置/超时字段见 [OpenAI官方MCP说明](https://learn.chatgpt.com/docs/extend/mcp?surface=cli)。其他项目共用服务，以绝对路径导入独立project_id。

```json
{"mcpServers":{"plcnext-project":{"command":"D:\\work\\code\\PLCnext-Engineer-mcp\\.venv\\Scripts\\python.exe","args":["-I","-m","plcnext_mcp.server"],"env":{"PLCNEXT_MCP_WORKSPACE":"D:\\PLCnext-MCP-Workspace","PLCNEXT_ENGINEER_DIRECTORY":"D:\\Program Files\\PHOENIX CONTACT\\PLCnext Engineer 2026.0"}}}}
```

客户端外层格式可能不同。[Configure-Mcp.ps1](../tools/Configure-Mcp.ps1)默认打印配置，指定新OutputPath才写文件且拒绝覆盖。Python3.11+；编译/配置脚本使用Windows、PowerShell7、匹配安装和库。独立环境安装当前仓库后将客户端command指向相应Python：

```powershell
py -3.11 -m venv 'D:\tools\plcnext-mcp-env'
& 'D:\tools\plcnext-mcp-env\Scripts\python.exe' -m pip install 'D:\work\code\PLCnext-Engineer-mcp'
```

stdio由客户端启动，没有服务网页。历史注册命令见 [跨项目使用](use-in-other-projects.md)。

## 3. 身份链和调用格式

| 返回身份 | 下步用途 |
|---|---|
| project_id / project_sha256 | 同一受管工程；编辑后取新SHA |
| code_sha256 / variables_sha256 | read_pou返回；批量接口编辑都要提供 |
| 编译job_id | 下一步参数名build_job_id |
| package_job_id / inventory_sha256 | 当前成功生成包及清单 |
| review_id / review_sha256 | 下载/控制审阅，不是授权 |
| plan_id / plan_sha256 | 有限读或整体恢复计划，不是授权 |

源码变更后重新构建、打包、审阅，不跨项目/修订混用。不从外部改受管revision/manifest；外部另存文件重新导入。示例tool/arguments是展示格式，程序通过MCP SDK call_tool调用；尖括号占位符须换实际值。

## 4. 离线恢复包准备

可直接对AI说：

```text
导入指定32POU恢复归档的新副本，重新核对SHA，保持代码/接口/任务/配置源原样。
检查Main、任务、结构和冷编译计划，再全POU冷编译。成功后明确dlc.bin策略，
生成完整PCWE并逐文件校验。先只做离线和本机测试，不创建真实收据，不接真实PLC。
```

```json
{"tool":"project_import_copy","arguments":{"source_path":"D:\\work\\code\\PLCnext-Engineer\\tmp\\p01-p02\\NativeGateway.restore-native-0.5.0.pcwex"}}
```

```json
{"tool":"project_inspect","arguments":{"project_id":"<PROJECT_ID>"}}
```

```json
{"tool":"project_read_pou","arguments":{"project_id":"<PROJECT_ID>","pou_name":"Main"}}
```

```json
{"tool":"project_build_plan","arguments":{"project_id":"<PROJECT_ID>"}}
```

```json
{"tool":"project_compile","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>"}}
```

检查compiled、ast_seed_used、全部POU解析和语法/语义诊断。未引用FB可能省略模块，不以DLL数量等于POU数量验收。

```json
{"tool":"project_generate_pcwe","arguments":{"project_id":"<PROJECT_ID>","expected_project_sha256":"<SOURCE_SHA256>","build_job_id":"<COMPILE_JOB_ID>","download_memento_policy":"omit"}}
```

```json
{"tool":"deployment_inspect_pcwe","arguments":{"source_path":"<PCWE_PATH>"}}
```

默认omit不生成dlc.bin；显式empty_capability_v1生成原厂空下载能力历史格式，清空既有Engineer下载能力历史，不能仅为凑数量自动选择。策略须进入精确影响审阅。package_complete/哈希通过不证明签名、设备接受或业务正常；完整PCWE仍限NativeGateway硬件/HMI profile。

## 5. 编辑、任务和本机测试

在另一新建工程测试新增FB/实例/调用、接口及调用方原子变更、有引用删除拒绝、原子移除调用后删除；每阶段用新SHA冷编译。updates每项要求pou_name、两个工作表SHA及至少一个完整code/variables文本。patch_st只替换唯一正文；保存read_pou文本再update_pous不等于所有官方FB归档格式导入导出。

负例包括旧SHA、重名、残余引用、接口改名漏调用、类型错误；编译失败不能给新源套旧构建。完整编辑事务示例保留在历史手册，实际参数取当前工具参考。

周期/看门狗单位纳秒，10ms=10000000ns。支持单eCLR、1…16独立周期任务；新增Program/任务和显式所有权见 [M10](independent-multitask.md)。源/闭包变化使合同失效，需重新检查。原任务ADR/外部存储不能静默放宽；没有共享FIFO交接实现。

project_test_controller_download只使用工具自建127.0.0.1：none/chunked_readback为成功，readback_corrupt/write_reply_lost/load_reply_lost/initial_running等核对失败阶段和不确定事实。无socket的simulate与真实本机TCP不同，两者均不证明实机兼容。

## 6. 真机只读、控制和恢复

目标192.168.0.8:41100既有证书pin：`3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863`。变化时独立核实，不关闭检查或自动学习；匿名只读不证明写权限。

controller_read_state、固定元数据预检、有界变量读分别有范围。prepare_runtime_read不连接设备，read_runtime会连接目标。正式恢复链为prepare_recovery→inspect_recovery→project_authorize_controller_operation(kind=recovery)→execute_recovery；完整示例、RAM政策、Start身份及失败处置见 [联调指南](joint-implementation-user-guide.md)。单独下载仍要求已Stop，原下载收据没有Stop/Start。

project_preflight_controller_download默认仍只两份元数据；显式verify_package_files=true按review既有路径回读并检查SHA-512及前后manifest/状态。capture_package_files=true必须同时verify=true，才在完整一致时保存新本地包快照；maximum_package_read_bytes默认33554432、允许1…64MiB响应预算。不会扩大到远端清单额外文件；快照不证明内存loaded、恢复源匹配或可直接回滚。完整例子见联调指南M05。

分别记录包Load、Running、配置、250GOOD、真实DATA/STORED、采样摘要和mock；缺字段返回unknown/unsupported，不偷偷加探针或借旧快照。外部验收器提供真实Hub证据；MCP不伪造STORED、不把RPC耗时当PLC性能，也不自动恢复P06或故障场景。

## 7. 失败与报告

旧hash、错误目标/pin、无效/过期/已消费收据、文件策略冲突应在相应变更前拒绝。已发写/控制后超时、取消、进程退出或丢回复，保留action_sent、files_may_have_changed、outcome_unknown和终态结果，不盲重发。

保留journal、claimed、结果和用户级端点租约；客户端取消不证明设备取消，落盘失败不撤销Load/Start。不要删锁后复用旧动作；恢复是新的显式操作，不是自动失败回调。

## 8. 文档一致性

```powershell
Set-Location -LiteralPath 'D:\work\code\PLCnext-Engineer-mcp'
& '.\.venv\Scripts\python.exe' -I 'tools\export_mcp_reference.py'
& '.\.venv\Scripts\python.exe' -I 'tools\export_mcp_reference.py' --check
```

生成器不连接PLC、不发行收据、不运行编译器。单元回归用python -I -m unittest discover -s tests -v；历史e2e可能含固定样例/版本或真实只读访问，先查范围。

参考：[操作者入口](operator-approval.md)、[多任务](independent-multitask.md)、[ACI分析](aci-analysis/README.md)、[联调清单](三方联调MCP修复清单-20261026.md)、[0.5证据](controller-download-client.md)。
