# RSC v4 tagged 协议独立实现

2026-10-26。新增 [rsc_tagged_codec.py](../src/plcnext_mcp/rsc_tagged_codec.py)，供不使用 ACI/Engineer 界面的设备客户端和离线模拟复用。本模块只有字节编解码，没有 socket、TLS、工程后端或设备操作。0.5.0 进一步按原厂 oracle 修正 buffer-hint/chunk 解码，见文末更新。

真实设备先前确认的 profile 为 v4、data tagging=true、datagramming=false。本轮在该范围补齐下载所需的值和调用框架：不是把 untagged 字节改一个 header flag。

## 已验证格式

| 范围 | 实现 |
| --- | --- |
| 标量 | Bool、Int8/UInt8、Int16/UInt16、Int32/UInt32、Int64/UInt64、有限 Single/Double、UTF8 字符串 |
| 特殊值 | synthetic SecureString UTF8 字节形式、SecurityToken UInt32 包装 |
| 数组 | Byte[]、Int32[]、Boolean[]、UTF8 String[] 及下表 DTO 一维数组；数组头含元素 schema，元素本体不重复外层 tag |
| DTO | TraitItem、WriteFileData、ReadFileInfo、ReadFileData、FileSystemTraitsEntry、SpaceInfo |
| 文件内容 | 非负 buffer hint、多个长度/内容数据块、`-1` 终止；实际内容上限 64 MiB / 流、65,536 块 |
| 调用 | Invoke4 请求/正常返回，schema 定界值序列及最终 `FF`；动态 service/provider/method handle；可选 UInt32 token header |
| 服务发现 | tagged header，但 provider/service 名称仍为原始 length+NUL，没有普通值 tag 或最终 FF |
| 协商 | tagged/no-datagram Connect 确认解析和编码；原连接请求继续使用既有能力协商请求 |
| 流读取 | `receive_values(read_exact, schemas)` 接收短片段，按长度/schema 读完当前方法值和终止符，不扫描文件内容中的 FF，不消费下一帧 |

支持 schema 为封闭注册表，不接受任意 CLR 类型名、任意 object、自动类型反射或反序列化指令。`security_token` 的值为 UInt32；`secure_utf8` 是原厂 SecureString 的 wire tag **0x24** 与有界 UTF8 数据，不等同于普通字符串 tag **0x13**，也不代表 Python 内存中的字符串获得了 SecureString 保护。

上限：128 MiB 方法值体、64 MiB 单个流/byte[]、65,536 stream chunks、4,096 普通数组元素、64 个顶层值。只有已知字段数/顺序有效；Permissions 之外的 Trait、未知 tag、负 hint、非法负 chunk、超长或截断输入、缺失终止符均拒绝。Unicode/ANSI 的其他 marshal、任意 Object/自定义 DTO、嵌套任意数组、datagram、非 v4 和设备实际权限仍不在范围。ERROR 返回现由独立 [error codec](rsc-error-control.md)覆盖限定 profile。

## 0.5.0 stream 更正

真实只读元数据回读揭示，stream 首 Int32 不能当作总长度。原厂 [38 个内存 oracle 案例](../artifacts/rsc-read-errors/oracle-04/report.json)和 [静态规则](../artifacts/rsc-read-errors/stream-rules.json)确认它是 buffer hint；0、1、65536、Int32Max 都可与不同长度/数量的 chunk 配合，最后以 -1 终止。接收端限制实际累计数据及 chunk 数，不分配 hint 大小的内存，也不要求累计长度等于 hint。

默认 bytes 编码保留原 seekable 单块格式；`ChunkedStream` 是本机测试使用的封闭 producer。Null Data 在原厂 writer 中直接异常，不编造 null-stream；Stream.Null 与空 MemoryStream 均为空流，NotExist/AccessDenied 的非零结果仍是失败。[新增检查](../tests/test_rsc_stream_chunks.py)覆盖原厂字节、短片段、下一帧保留、总量/块数和截断；真实只读预检已成功读取元数据。

`decode_values(bytes,schemas)` 拒绝尾随字节；`receive_values` 为持久流只消费当前 schema，不会通过试读来判断下一帧。注入读取器和传输期限由调用者提供；本模块不负责网络超时、重连或状态恢复。

## 原厂证据与运行边界

本轮仅执行本机原厂 DTO、TagInfo、CallMessage 和 formatter 对 **MemoryStream** 的序列化/反序列化。未实例化 remoting provider/在线适配器，未构造 socket，未启动 Engineer 或 ACI，也未读取实际凭据或联系设备。所有鉴权值是固定的离线 fixture。

| 证据 | 数量 / 范围 |
| --- | --- |
| [值 oracle](../artifacts/rsc-tagged-values/oracle-02/report.json) | 26 原厂 roundtrip，其中 25 属于模块支持的 profile；另一个 UTF16 marshal tag 仅记录，模块拒绝使用 |
| [文件服务 oracle](../artifacts/rsc-tagged-values/file-oracle-01/report.json) | 10 原厂 DTO/OUT-then-return 序列，含中文路径、二进制流、空数组、错误码和 64 位空间值 |
| [完整调用 oracle](../artifacts/rsc-tagged-values/call-oracle-03/report.json) | 18 完整请求/正常响应；Reset/Load、GetPlcState、CreateSession/CloseSession；真实 SerializeMessage 生成请求，真实 DeserializeMessage 消费响应全部字节；handles 均为 synthetic |
| [既有只读 oracle](../artifacts/plc-connection-test/tagged-oracle/vectors-01/report.json) | 31 个既有服务发现/状态向量复用，逐字节匹配 |
| [独立 codec 复核](../artifacts/rsc-tagged-values/verification.json) | 7 项单元测试通过，包括所有上述支持向量、每个截断位置、短片段及后续帧保留 |

程序集身份在各 oracle report 中保留。核心 formatter：`Ade.CommonRemoting.Commons.dll` SHA-256 `ab1382d433254d8694bf53c265e29b16445c323528a7ed2389a23068c6f3246e`，MVID `25aefcf5-ce5b-4e77-820c-46bb5192515a`。静态 CIL 复用 [remoting-values-il.json](../artifacts/plc-download-research/files/remoting-values-il.json) 和 [remoting-format-il.json](../artifacts/plc-download-research/files/remoting-format-il.json)，包括 `TagInfo.Write` token `0x06000115`、`SerializeParameters` `0x060000a6` 和 `DeserializeReturnValues` `0x060000ad`。这些 token 只绑定该构建。

## 给下载后端的 schema

每个 `encode_request/encode_response` 自动添加 Invoke 的 FF 终止符；`encode_value` 只编码单个值，不添加终止符。方法的 OUT 值在 RETURN 值之前。

| 服务 / 方法 | 输入 schema | OUT + RETURN schema |
| --- | --- | --- |
| IPasswordAuthenticationService.CreateSession | utf8, secure_utf8 | security_token, int32, int32 |
| IPasswordAuthenticationService.CloseSession | security_token | 无 |
| IFileService2.WriteMany | write_file[] | int32[] |
| IFileService2.ReadMany | read_file_info[] | read_file_data[] |
| IFileSystemInfoService.GetSupportedTraits | 无 | int32 |
| IFileSystemInfoService.GetTraitsEntry | int32, utf8 | filesystem_traits_entry, int32 |
| IFileSystemInfoService.GetSpace | utf8 | space_info, int32 |
| IPlcManagerService.Reset / Load | bool | 无 |
| IPlcManagerService.GetPlcState | 无 | uint32 |

文件 DTO dict 字段沿用现有 codec：`write_file={path,overwrite,traits,data}`、`read_file_info={path,traits}`、`read_file_data={result,traits,data}`；其中 traits 只支持 `[{trait:1,value:POSIX_BITS}]` 或空数组。

以上证明 wire 编码与本机构建匹配，不证明真实 PLC 接受写入/下载/配置加载。真实服务句柄、证书信任、匿名或鉴权权限、停止/加载/启动行为、错误响应和部署后的运行状态仍需各自验证，不能因为 codec 通过而宣称已完成设备部署。

复核：

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -p test_rsc_tagged_codec.py -v
```
