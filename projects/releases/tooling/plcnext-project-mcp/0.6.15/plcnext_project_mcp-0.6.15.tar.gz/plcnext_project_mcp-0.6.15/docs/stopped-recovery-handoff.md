# Stop 前完整预检与停止零写入恢复交接

版本：0.6.12；日期：2026-10-28（Asia/Shanghai）。对应 R01 / R02 / R03。独立 MCP 实现，不使用 ACI、SSH 或 computer use。

## 分析结论

旧执行确实先 Stop 再校验远端清单。`omit` 候选少 `dlc.bin`，严格清单策略拒绝传输，但设备已停止。该故障不是加载成功后的观测失败，不能复用业务验收或审计核销。打包应继续使用已有 `empty_capability_v1`，不增加删除旧文件权限。

修复后恢复链路为：精确授权与端点互斥 → 运行基线 → 完整只读预检 → Stop → 复核清单与逐文件比较 → 写入/回读 → Reset/Load → 因果校验 → Start → 配置/Running/GOOD 验证。只读预检不消除外部工具修改设备的竞态。

## R01：显式交接到新的完整恢复

新增 `project_prepare_stopped_recovery`，输入旧执行、完整恢复 review、证书，以及显式选择的恢复工程/源/包/配置/RAM策略。同步用 execution_id；异步可额外传真实 operation_id，必须匹配同一结束执行。服务 PID 存活不代表执行活跃：检查的是执行 OS 锁、终态结果、闭合请求日志与已消费授权。

准入限于：Stop 已确认，传输子步骤停在 preflight/comparing_files，mutation=0，Reset/Load 未发送，状态已知为 Stop、无清理错误、无未闭合请求。部分写入、未知结果、审计分支和活跃执行均拒绝。

准备返回恢复工程下的普通 recovery 计划；调用 `project_inspect_stopped_recovery` 独立检查，再沿用 `project_authorize_controller_operation(kind="recovery")` 与 `project_execute_recovery`。每个计划独立一次授权。旧候选不会默认为恢复目标，不提供没有加载因果证明的“仅补发 Start”。

执行先保存旧租约字节和新旧关联，再在端点转换锁内原子替换租约所有者，整个过程不存在先删除租约的空窗。旧失败 result/journal/claimed 均不改动；新执行目录包含 `previous-endpoint-lease.json`、`handoff.json`。交接后的恢复仍需自身完整回读、Reset/Load 和因果证据才能 Start。

相同交接执行重放返回原终态，不再次发控制。如果成功落盘后、租约释放前中断，重放只释放字节完全一致的本次租约；其他操作的新所有者不受影响。进程中断且缺少闭合终态时拒绝自动重放，保留端点排他和恢复责任；不会通过删锁处理不确定状态。新恢复失败或取消时，即使尚未发送新设备变更，也保留已接管的停止恢复责任。该入口不宣称能够自动处理所有进程崩溃或部分写入故障。

## R02/R03：同一预检策略与可操作结果

新增 `project_preflight_recovery_download(project_id, review_id, expected_review_sha256)`：传入恢复计划 `children.download` 的 ID/哈希，不是父恢复哈希。它与实际传输共用 `_check_old_manifest` 和 `_compare_files`，包括路径集合、允许保留的源归档、原生共享库更新限制。还检查包/源码绑定、证书、稳定状态、空间，以及窗口前后的清单与状态。精确只读文件客户端限制为审阅包路径，最多 64 MiB RSC 响应，单次预检最长 60 秒（整体恢复期限可更短）。不保存远端文件内容。

主线恢复自动在 Stop 前调用此完整预检；Stop 后保留相同传输校验。原有 metadata 预检保留兼容用途，其 `preflight_read_completed` 不代表完整下载预检通过。

冲突返回 `preflight_rejected` 和 `download_preflight`；`action_counts` 分别统计 Stop、WriteMany 请求、Reset、Load、Start。`file_write` 是写请求次数，不是文件数；准确文件数见传输子结果。

路径差异定义：
- `missing_on_target`：候选包有、远端 manifest 声明没有。
- `preserved_remote`：远端额外声明、现策略允许保留的源归档。
- `unsupported_remote_extras`：远端额外声明、现策略不允许的路径。

每类最多 128 条、8192 UTF-8 字节，包含完整 count 与 truncated 标记。`dlc.bin` 冲突附离线重打包提示，不自动改策略或删文件。报告绑定源码 SHA、包清单 SHA、目标/pin、远端 manifest SHA；预检不授权写入，也不证明未列出的文件不存在。

若 Stop 后复核才失败，顶层直接给出 `transfer_failure`、动作计数及 `recovery_handoff` 工具参数提示，不能再只读到笼统的“transfer did not complete”。

## 本次真实记录的本地验收与完整调用示例

本地核验接收旧执行 `0e3b27da8b504c4bb0dce005d38149d0`：最后确认状态 raw=131074（Stop，含元数据标志）。这是历史证据，不是当前设备状态声明。已用新 MCP 子进程完成以下 prepare/inspect；未签发授权、未联网、未恢复 PLC。

### 1. 准备

工具：`project_prepare_stopped_recovery`

```json
{
  "project_id": "8266573fcadd4e118cb2b86995335dc6",
  "execution_id": "0e3b27da8b504c4bb0dce005d38149d0",
  "expected_review_sha256": "92d4b2b254e1ca380861122f07d78f22ec8d8f428f111ff396a223ab69db6330",
  "expected_certificate_sha256": "3c7b256b25712d045396c61ecaf919700af43b7daaf9f36787438491f9caf863",
  "restore_project_id": "17ae4361baa846868b14775bf1de15ea",
  "restore_project_sha256": "7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154",
  "restore_package_job_id": "f7fc619d55ba42c091f4ca0efed23e73",
  "expected_configuration": {
    "version": 19,
    "device_count": 50,
    "point_count": 250,
    "enabled": true
  },
  "volatile_data_policy": "record_unknown_loss"
}
```

### 2. 检查

工具：`project_inspect_stopped_recovery`。本轮已生成的参数如下；如果旧证据、源包或端点所有者变化，检查会拒绝，应重新准备。

```json
{
  "project_id": "17ae4361baa846868b14775bf1de15ea",
  "plan_id": "818a1db2caf24cee941efc59a4f3f67d",
  "expected_plan_sha256": "342bcb7586bc4d2b2f38da070fc15fd6a1bb937384c5b163fee61e6a31bfb9f5"
}
```

### 3. 精确授权（以下尚未执行）

工具：`project_authorize_controller_operation`。此步骤明确接受完整冷加载、程序中断、未知 RAM 损失；输出保持行为仍未经实测。

```json
{
  "project_id": "17ae4361baa846868b14775bf1de15ea",
  "review_id": "818a1db2caf24cee941efc59a4f3f67d",
  "expected_review_sha256": "342bcb7586bc4d2b2f38da070fc15fd6a1bb937384c5b163fee61e6a31bfb9f5",
  "kind": "recovery",
  "reason": "Explicit native-0.5.0 recovery after confirmed Stop and zero transfer; RAM loss unknown"
}
```

### 4. 执行恢复（以下尚未执行）

工具：`project_execute_recovery`，使用恢复工程的 project_id：

```json
{
  "project_id": "17ae4361baa846868b14775bf1de15ea",
  "plan_id": "818a1db2caf24cee941efc59a4f3f67d",
  "expected_plan_sha256": "342bcb7586bc4d2b2f38da070fc15fd6a1bb937384c5b163fee61e6a31bfb9f5"
}
```

也可将同样参数交给已有后台恢复入口并用 operation_id 查询。MCP 的成功只确认完整加载、Running、指定配置和预期全部 GOOD；真实 DATA/STORED/入库需外部联调确认，不能把历史 GOOD 当作当前采集成功。

## 验证证据

- `tests/test_stopped_recovery.py`：新增 10 项本机测试，包含 omit/dlc 冲突零 Stop、清单竞态、跨执行恢复、同步/异步服务存活、重放、互斥、证据篡改、缺授权、部分写入拒绝和转换中断。
- `tools/verify_stopped_recovery_public.py`：新进程 0.6.12 / 88 工具，真实旧记录的本地 prepare/inspect；结果在 `artifacts/stopped-recovery-research/public-result.json`。
- 原始需求与证据副本不修改；本轮不下载 0.8，不操作数据库、不改变 Hub，也不执行真实 PLC Stop/Start/Reset/Load。

最终源码完整回归：624 项，623 通过、1 跳过，165.271 秒。日志：`artifacts/stopped-recovery-research/final-tests.log`。成功后残留租约收尾、其他所有者保护也已通过本机用例。
