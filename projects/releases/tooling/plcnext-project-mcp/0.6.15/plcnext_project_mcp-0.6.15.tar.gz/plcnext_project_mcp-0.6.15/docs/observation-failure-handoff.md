# 0.6.10：启动观测失败与外部恢复交接

新增公开工具 `project_prepare_observation_reconciliation`。仅接受后台恢复 operation 的精确 `recovery_failed / verify_runtime / recovery_observation_failed`、控制已确认且无未知写入终态。本分支不是任意失败清锁工具，也不是同步或审计失败的替代身份。

## 必须绑定

旧project/operation/完整恢复SHA/证书，以及当前project/source SHA、runtime-read plan/SHA、明确boot、expected_configuration（version/device_count/point_count/enabled）、当前读计划返回的configuration_digest.sha256、外部恢复记录绝对路径/SHA和描述。旧Stop子SHA只用于核对租约owner，不能代替完整恢复SHA。

即使仍运行原候选，也使用该入口显式绑定当前只读计划和预期；证据可为故障后的记录，不能只传reason。外部恢复时使用当前stable源布局，不强制恢复旧候选/v13。文件hash只证明记录未变，源码/读计划/Running也不是内存镜像认证。

prepare会检查旧后台终态、宿主创建身份、执行锁、父授权及消费claim、闭合journal和每个已确认控制/传输步骤，然后用当前计划进行新鲜只读核验。必须Running、全部期望GOOD、精确配置摘要、boot前后均等于显式预期；不会读取旧候选布局来替代当前布局。

其后沿用 `project_inspect_lease_reconciliation` → `project_authorize_controller_operation(kind="lease_reconciliation")` → `project_execute_lease_reconciliation`。execute再次核验全部原记录、外部文件、当前源/计划及新鲜boot/配置；成功仅原子归档精确旧租约。保留旧失败、授权claim与原始字节，结果明确 old_failure_preserved=true、business_acceptance=false、memory_loaded_image_attested=false。重复调用与中断续办复用已有原子归档规则，不重放设备动作、不动新owner。

## 启动读取重试

只在已完成Start后的verify_runtime阶段，BootId尚空、PLC前后Running，且guard差异限于配置从0变为审阅值时丢弃失效窗口，在原次数、间隔与总期限内继续读。失败窗口进入观察列表但不参与验收；没有再次Stop/Load/Start。首次已观察的非空boot之后若发生变化，或出现错误目标/证书、连接/清理故障、非初始化配置变化，仍失败。预算耗尽保留recovery_observation_failed，可使用新入口收尾。

## 本轮接收

固定输入 docs/evidence/lease-observation-20261027 下15份文件及manifest均未改写。测试以真实0→13且boot为空的窗口为输入，验证随后就绪和预算耗尽；本地TLS确认Stop/Load/Start各一次。核销测试覆盖外部stable/v15交接、原失败字节不变、外部证据/当前源变化拒绝、未知或未确认控制拒绝、原子归档后崩溃续办只做本地完成。既有活跃owner、PID身份、旧lease/journal变更和新owner保护测试继续适用。

本次现场接收只允许新鲜只读和精确本机核销；不重新恢复PLC，不把故障或工程身份改写为成功。后续PLC操作需要独立的新计划与授权。
