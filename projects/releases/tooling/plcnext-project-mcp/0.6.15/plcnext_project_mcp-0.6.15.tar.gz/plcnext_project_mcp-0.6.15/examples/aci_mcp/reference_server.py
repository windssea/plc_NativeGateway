"""Optional ACI MCP reference, separate from the independent production backend.

Catalog tools are static. The one executable tool is disabled by default and
uses a bounded, serialized offline transaction against an operator-selected
empty Engineer process. No online-channel method is exposed.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import uuid

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

REPO = Path(__file__).resolve().parents[2]
INVENTORY = REPO / 'artifacts/aci-analysis/public-client-Ade.ApplicationControl.json'
INSTALL = Path(r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')
READ = ToolAnnotations(readOnlyHint=True, openWorldHint=False)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=False)
_mutex = threading.Lock()
KNOWN_STUBS = {
    'Ade.ApplicationControl.Iec.IFunctionBlockInstance': {'get_Comment': '0x06000217'},
    'Ade.ApplicationControl.Iec.IProgramInstance': {'get_Comment': '0x060002be'},
    'Ade.ApplicationControl.Iec.ITask': {
        'get_EventName': '0x06000302', 'get_Interval': '0x06000303',
        'get_Priority': '0x06000304', 'get_Watchdog': '0x06000305', 'get_Comment': '0x06000306'},
}
mcp = FastMCP('PLCnext ACI Reference', instructions=(
    'Reference implementation for the locally analyzed Engineer 2026.0 ACI. '
    'Catalog is static metadata, not a claim that every member works. '
    'Offline execution is opt-in and requires a valid vendor ACI license, enabled '
    'interface and an explicitly selected empty dedicated /NOUI backend. '
    'The only execution workflow copies a PCWEX, rebuilds, exports IEC XML, '
    'optionally imports supplied XML, rebuilds, exports and saves the copy. '
    'It exposes no PLC connection, download, start/stop or variable operations. '
    'After an indeterminate failure its backend lease stays locked; do not retry.'))


def _digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


@mcp.tool(annotations=READ)
def aci_reference_info() -> dict:
    """Show reference scope and whether the operator enabled actual ACI calls."""
    return {
        'backend': 'official_aci_reference', 'license_required': True,
        'execution_enabled': os.environ.get('PLCNEXT_ACI_REFERENCE_ENABLE') == '1',
        'execution_runtime_verified_this_investigation': False,
        'historical_vendor_offline_roundtrip_verified': True,
        'controller_access': False, 'automatically_starts_engineer': False,
        'isolated_from_registered_independent_mcp': True,
        'workflow': ['copy', 'open', 'rebuild', 'export', 'optional_import',
                     'optional_rebuild', 'export', 'save', 'close'],
        'catalog_path': str(INVENTORY),
        'limitations': [
            'Public metadata includes server properties that throw NotImplementedException.',
            'Import success does not prove instance/variable/I/O mapping preservation.',
            'IProject has no public path getter; use only a dedicated empty backend.',
            'Timeout is not cancellation; inspect and restart the dedicated backend before recovery.',
        ],
    }


@mcp.tool(annotations=READ)
def aci_api_catalog(type_name: str = '', offset: int = 0, limit: int = 12) -> dict:
    """Page public ACI interfaces, enums, signatures and tokens from static evidence.

    type_name is an exact fully qualified name. An empty value pages public
    types. No target assembly is loaded and no service is contacted.
    """
    if offset < 0 or not 1 <= limit <= 25:
        raise ValueError('offset must be nonnegative; limit must be 1..25')
    data = json.loads(INVENTORY.read_text(encoding='utf-8-sig'))
    types = [item for item in data['types'] if item['public']]
    if type_name:
        types = [item for item in types if item['name'] == type_name]
    selected = []
    for item in types[offset:offset + limit]:
        selected.append({
            key: item[key] for key in ('name', 'token', 'is_interface', 'is_enum',
                                       'base_type', 'interfaces', 'properties', 'events')
        })
        selected[-1]['methods'] = [
            {key: method[key] for key in ('token', 'signature')}
            for method in item['methods'] if method['public']
        ]
        for entry, method in zip(selected[-1]['methods'],
                                  (method for method in item['methods'] if method['public'])):
            stub_token = KNOWN_STUBS.get(item['name'], {}).get(method['name'])
            if stub_token:
                entry['server_implementation'] = {
                    'status': 'unsupported_in_analyzed_build',
                    'reason': 'Unconditionally throws NotImplementedException',
                    'server_token': stub_token,
                }
            elif item['name'] == 'Ade.ApplicationControl.Network.IDeviceInstanceCollection' and method['name'] == 'GetNextFreePosition':
                entry['server_implementation'] = {
                    'status': 'constant_placeholder', 'constant': 0, 'server_token': '0x06000190'}
        if item['is_enum']:
            selected[-1]['values'] = {field['name']: field['constant']
                                      for field in item['fields'] if field['has_constant']}
    return {'static_only': True, 'assembly_sha256': data['sha256'],
            'mvid': data['mvid'], 'total': len(types), 'types': selected,
            'next_offset': offset + limit if offset + limit < len(types) else None,
            'warning': 'Declared API is not a guarantee of implemented or runtime-tested behavior.'}


def run_offline_roundtrip(source_path: str, import_xml_path: str | None = None,
                          timeout_seconds: int = 180) -> dict:
    """Execute only the fixed offline helper; never accept method names or commands."""
    if os.environ.get('PLCNEXT_ACI_REFERENCE_ENABLE') != '1':
        raise ValueError('ACI reference execution is disabled; see examples/aci_mcp/README.md')
    if not 10 <= timeout_seconds <= 600:
        raise ValueError('timeout_seconds must be 10..600')
    pid = int(os.environ.get('PLCNEXT_ACI_REFERENCE_PID', '0'))
    port = int(os.environ.get('PLCNEXT_ACI_REFERENCE_PORT', '31172'))
    if pid <= 0 or not 1 <= port <= 65535:
        raise ValueError('Configure the dedicated backend PID and local ACI port')
    source = Path(source_path).resolve(strict=True)
    if source.suffix.lower() != '.pcwex' or not source.is_file():
        raise ValueError('source_path must identify a PCWEX file')
    xml = Path(import_xml_path).resolve(strict=True) if import_xml_path else None
    if xml and (not xml.is_file() or xml.suffix.lower() != '.xml'):
        raise ValueError('import_xml_path must identify an IEC XML file')
    configured_root = os.environ.get('PLCNEXT_ACI_REFERENCE_WORKSPACE')
    root = (Path(configured_root) if configured_root else Path.home() / 'PLCnext-ACI-Reference').resolve()
    install = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', str(INSTALL))).resolve()
    lease_root = Path(tempfile.gettempdir()) / 'plcnext-aci-reference-leases'
    with _mutex:
        lease_root.mkdir(parents=True, exist_ok=True)
        lease = lease_root / f'{pid}.lock'
        try:
            descriptor = os.open(lease, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as exc:
            raise ValueError(f'Backend is leased or needs recovery: {lease}') from exc
        # Once the helper can contact ACI, every uncertain outcome retains this lease.
        helper_started = False
        completed = False
        job: Path | None = None
        try:
            job = root / uuid.uuid4().hex
            job.mkdir(parents=True, exist_ok=False)
            with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
                descriptor = -1
                json.dump({'pid': pid, 'job': str(job)}, stream)
            project = job / 'project-copy.pcwex'
            shutil.copyfile(source, project)
            source_hash = _digest(project)
            imported_hash = None
            if xml:
                shutil.copyfile(xml, job / 'import.xml')
                imported_hash = _digest(job / 'import.xml')
            request = {'pid': pid, 'port': port, 'install': str(install),
                       'timeout_seconds': timeout_seconds, 'import_xml': bool(xml),
                       'project_sha256': source_hash, 'import_sha256': imported_hash}
            request_path = job / 'request.json'
            request_path.write_text(json.dumps(request), encoding='utf-8')
            helper_started = True
            try:
                process = subprocess.run([
                    'pwsh', '-NoProfile', '-NonInteractive', '-File',
                    str(Path(__file__).with_name('Invoke-AciReference.ps1')),
                    '-RequestPath', str(request_path),
                ], capture_output=True, text=True, encoding='utf-8', errors='replace',
                    timeout=timeout_seconds * 4 + 90, check=False)
            except subprocess.TimeoutExpired:
                return {'status': 'outcome_unknown', 'job': str(job), 'pid': pid,
                        'lease': str(lease), 'retry_allowed': False,
                        'reason': 'Helper deadline expired; Engineer operations may still be running.'}
            result_path = job / 'result.json'
            if not result_path.is_file():
                return {'status': 'outcome_unknown', 'job': str(job), 'pid': pid,
                        'lease': str(lease), 'retry_allowed': False,
                        'helper_exit_code': process.returncode,
                        'reason': 'Helper did not produce its final result.'}
            result = json.loads(result_path.read_text(encoding='utf-8-sig'))
            completed = process.returncode == 0 and result.get('status') == 'completed'
            result.update({'job': str(job), 'pid': pid, 'source_snapshot_sha256': source_hash,
                           'source_path': str(source), 'lease_retained': not completed,
                           'retry_allowed': completed, 'controller_access': False,
                           'mapping_preservation_verified': False})
            if not completed:
                result['lease'] = str(lease)
            return result
        finally:
            if descriptor != -1:
                os.close(descriptor)
            if completed or not helper_started:
                lease.unlink(missing_ok=True)


@mcp.tool(annotations=WRITE)
def aci_offline_roundtrip(source_path: str, import_xml_path: str | None = None,
                          timeout_seconds: int = 180) -> dict:
    """Opt-in official ACI copy/rebuild/export/import/rebuild/save transaction.

    Requires operator-configured dedicated empty /NOUI backend and valid ACI.
    Always copies input files into a new job; optional import changes only that
    copy. No arbitrary commands, online channels, download or variable access.
    The new host has only mock/contract validation, not a live ACI run in this investigation.
    """
    return run_offline_roundtrip(source_path, import_xml_path, timeout_seconds)


if __name__ == '__main__':
    mcp.run(transport='stdio')
