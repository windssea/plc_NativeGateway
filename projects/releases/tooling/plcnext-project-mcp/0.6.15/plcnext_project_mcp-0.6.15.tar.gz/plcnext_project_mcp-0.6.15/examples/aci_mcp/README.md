# 可选 ACI MCP 参考样例

这是本机 ACI 静态分析对应的独立参考服务。现有注册的 `plcnext-project` 继续使用原有独立后端。本样例没有加入该服务、没有修改 Codex 配置或 wheel。

提供三个工具：

| 工具 | 行为 |
| --- | --- |
| `aci_reference_info` | 返回依赖、执行开关、范围和未验证项 |
| `aci_api_catalog` | 分页查询全量公共契约、签名、token、枚举和已知未实现属性；不加载厂商代码 |
| `aci_offline_roundtrip` | 默认禁用。显式启用后，仅在副本上执行 Open → Rebuild → IEC Export → 可选 Import/Rebuild → Export → Save/Close |

**本轮只通过了 stdio 工具发现/静态查询/禁用执行测试、4 个单元测试及 PowerShell 语法检查。新宿主未执行真实 ACI。** 它复用此前通过真实离线测试的 `tools/AciOfflineSession.cs`，不把该历史结果当作新宿主的实测。导入完成和编译成功均不会被标为“实例/变量/I/O 映射保留已验证”。

## 只读试用目录

在本机用现有 Python 环境运行：

```powershell
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I 'D:\work\code\PLCnext-Engineer-mcp\examples\aci_mcp\reference_server.py'
```

进程使用 MCP stdio。客户端参考配置如下；这里只展示配置，不自动注册：

```json
{
  "mcpServers": {
    "plcnext-aci-reference": {
      "command": "D:\\work\\code\\PLCnext-Engineer-mcp\\.venv\\Scripts\\python.exe",
      "args": ["-I", "D:\\work\\code\\PLCnext-Engineer-mcp\\examples\\aci_mcp\\reference_server.py"],
      "env": {"PLCNEXT_ACI_REFERENCE_ENABLE": "0"}
    }
  }
}
```

查询示例：`aci_api_catalog(type_name="Ade.ApplicationControl.Iec.IOnlineChannel")`。目录显示的是 API 定义，即使列出了 Download，它也没有对应的可执行工具。

## 启用离线参考宿主的条件

需要有效 ACI 许可、已启用接口、相同 Windows 用户、PowerShell 7、安装目录和本次分析一致的四个 ACI DLL。宿主在加载前检查四个 SHA-256，版本不符拒绝执行。不会修改许可或复制证书。**执行需要专属空的 `/NOUI` Engineer 进程**；不接管 GUI 或已打开的工程，也不会自动启动/关闭 Engineer。

由操作者准备专属进程的示例（本轮未运行）：

```powershell
$aciBackend = Start-Process -FilePath 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\PLCNENG64.exe' -ArgumentList '/NOUI','/NOSPLASHSCREEN' -PassThru -WindowStyle Hidden
$env:PLCNEXT_ACI_REFERENCE_ENABLE = '1'
$env:PLCNEXT_ACI_REFERENCE_PID = [string]$aciBackend.Id
$env:PLCNEXT_ACI_REFERENCE_PORT = '31172'
$env:PLCNEXT_ACI_REFERENCE_WORKSPACE = 'D:\PLCnext-ACI-Reference'
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I 'D:\work\code\PLCnext-Engineer-mcp\examples\aci_mcp\reference_server.py'
```

客户端若负责启动 MCP，则把以上环境值配置到该客户端的服务环境里。先不要传 `import_xml_path`，以副本完成基线编译/导出；检查输出后再准备 IEC XML 变更提案。输入始终复制到新的 UUID 作业目录，原始 PCWEX/XML 不写入。

作业目录保存请求快照、`project-copy.pcwex`、`before.xml`、`after.xml`、可选 `import.xml` 和 `result.json`。工程/导入快照在调用前重新核对哈希。宿主先验证正常 ACI 可用性和预期 PID，拒绝接管已打开工程；它只调用旧的离线适配类，没有在线通道入口。

## 超时与恢复

每个 PID 使用进程内互斥和临时目录下的排他租约文件。正常完成才释放租约。失败、宿主超时或未产出结果时保留租约，并报告 `failed_or_indeterminate` 或 `outcome_unknown`。**没有自动重试、强关 Engineer、失败时 Save/Close 或把等待取消当成底层取消。**

恢复前先检查输出和专属后端状态，必要时关闭并重新启动专属后端。确认旧 PID 不再执行工作、旧作业已归档后，才由操作者删除报告中的那个明确租约文件；不要在仍运行时解除锁。公开 IProject 没有文件路径 getter，因此不能把该参考宿主用于多人共享或外部程序也在操作的 Engineer 进程。

## 后续生产实现

生产版应自己维护事件→job 的关联、保留启动异常并解除订阅，替换公共 Async 扩展的异常遗漏路径；增加重开后的实例/声明/ESM/DataList 差异核验和编辑事务。当前样例通过宿主外层期限与失败后隔离控制这些边界，仍不具备完整恢复及映射验收能力。

更广能力的接口、未实现属性、mTLS、下载完成语义见 [ACI 总报告](../../docs/aci-analysis/README.md)。当前样例未暴露连接 PLC、下载、启停、复位或在线变量操作。直接 gRPC 仍依赖同一 ACI 许可和 Engineer 后端。

复核命令：

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -p test_aci_reference.py -v
.\.venv\Scripts\python.exe tools\aci_reference_mcp_check.py
.\.venv\Scripts\python.exe tools\summarize_aci_implementation.py
```
