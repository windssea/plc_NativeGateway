param([Parameter(Mandatory)][string]$RequestPath)
$ErrorActionPreference = 'Stop'
# This optional reference host is not used by the registered independent MCP.
if ($env:PLCNEXT_ACI_REFERENCE_ENABLE -ne '1') { throw 'ACI reference execution is disabled.' }
$requestFile = [IO.Path]::GetFullPath($RequestPath)
$job = [IO.Path]::GetDirectoryName($requestFile)
$request = Get-Content -LiteralPath $requestFile -Raw | ConvertFrom-Json
if ([int]$request.pid -ne [int]$env:PLCNEXT_ACI_REFERENCE_PID -or [int]$request.pid -le 0) { throw 'Backend PID mismatch.' }
$backend = Get-Process -Id ([int]$request.pid)
if ($backend.MainWindowHandle -ne 0) { throw 'Use a dedicated empty /NOUI backend, not a GUI session.' }
if ($request.timeout_seconds -lt 10 -or $request.timeout_seconds -gt 600) { throw 'Invalid deadline.' }
$project = Join-Path $job 'project-copy.pcwex'
$import = Join-Path $job 'import.xml'
if ((Get-FileHash -LiteralPath $project -Algorithm SHA256).Hash.ToLowerInvariant() -ne $request.project_sha256) { throw 'Project snapshot changed.' }
if ($request.import_xml -and (Get-FileHash -LiteralPath $import -Algorithm SHA256).Hash.ToLowerInvariant() -ne $request.import_sha256) { throw 'Import snapshot changed.' }
$install = [IO.Path]::GetFullPath($request.install)
$expectedAssemblies = @{
    'Ade.ApplicationControl.dll' = '80f3e5df6dcc8ffc22c0cf0a566c2693b1b59037bb62e29ab8ec1ec31fb7fc11'
    'Ade.ApplicationControl.ClientImpl.dll' = 'f0191c438eb6a48a31a1dc3d62859e382e87f9577395176cc447d752e01ecf42'
    'Ade.ApplicationControl.Communication.dll' = 'cf5f7620d4b4fb973f587bba098ec1c6305c71828a4782b9a14a6c5ab0853bfd'
    'Ade.ApplicationControl.ServerImpl.dll' = '2472a11f283c04abae006b27ab883d435e9c0eb6dabb5c8e935977e37d05e628'
}
foreach ($assemblyName in $expectedAssemblies.Keys) {
    if ((Get-FileHash -LiteralPath (Join-Path $install $assemblyName) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedAssemblies[$assemblyName]) {
        throw "Unanalyzed ACI assembly version: $assemblyName"
    }
}
$repository = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$result = [ordered]@{ status = 'started'; controller_access = $false; steps = @(); project_copy = $project }
$session = $null
$resolver = $null
try {
    Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Reflection;
public static class AciReferenceResolver {
    public static string DirectoryPath;
    public static Assembly Resolve(object sender, ResolveEventArgs args) {
        var file = Path.Combine(DirectoryPath, new AssemblyName(args.Name).Name + ".dll");
        return File.Exists(file) ? Assembly.LoadFrom(file) : null;
    }
}
'@
    [AciReferenceResolver]::DirectoryPath = $install
    $resolver = [ResolveEventHandler][AciReferenceResolver]::Resolve
    [AppDomain]::CurrentDomain.add_AssemblyResolve($resolver)
    $contract = Join-Path $install 'Ade.ApplicationControl.dll'
    $client = Join-Path $install 'Ade.ApplicationControl.ClientImpl.dll'
    [void][Reflection.Assembly]::LoadFrom($contract)
    [void][Reflection.Assembly]::LoadFrom($client)
    Add-Type -Path (Join-Path $repository 'tools\AciOfflineSession.cs') -ReferencedAssemblies @($contract, $client, 'System.Linq.dll', 'System.Collections.dll', 'System.Threading.Tasks.dll') -CompilerOptions '/nowarn:1701'
    $session = [AciOfflineSession]::new([int]$request.port)
    $session.Initialize([int]$request.pid)
    if ($session.IsProjectOpen) { throw 'Refusing to take over an open project.' }
    $result.version = $session.Version
    $result.build = $session.Build
    $session.Open($project, [int]$request.timeout_seconds)
    $result.steps += 'opened_copy'
    $result.baseline_compile = $session.Compile([int]$request.timeout_seconds)
    if ($result.baseline_compile.Result -ne 'Succeeded') { throw 'Baseline rebuild did not succeed.' }
    $result.before_export_messages = @($session.Export((Join-Path $job 'before.xml')))
    if (@($result.before_export_messages | Where-Object Type -eq 'Error').Count) { throw 'Baseline export returned errors.' }
    $result.steps += 'baseline_rebuilt_exported'
    if ($request.import_xml) {
        $result.import_messages = @($session.Import($import))
        if (@($result.import_messages | Where-Object Type -eq 'Error').Count) { throw 'Import returned errors; copy may be partially modified.' }
        $result.modified_compile = $session.Compile([int]$request.timeout_seconds)
        if ($result.modified_compile.Result -ne 'Succeeded') { throw 'Modified rebuild did not succeed.' }
        $result.steps += 'imported_rebuilt'
    }
    $result.after_export_messages = @($session.Export((Join-Path $job 'after.xml')))
    if (@($result.after_export_messages | Where-Object Type -eq 'Error').Count) { throw 'Final export returned errors.' }
    $session.Save()
    $session.Close()
    $result.steps += 'exported_saved_closed'
    $result.status = 'completed'
} catch {
    # A timed-out operation can still be active. Do not save/close/shutdown on failure.
    $result.status = 'failed_or_indeterminate'
    $result.error = $_.Exception.Message
    $result.retry_allowed = $false
} finally {
    try { if ($null -ne $session) { $session.Dispose() } } catch {
        $result.cleanup_error = $_.Exception.Message
        $result.status = 'failed_or_indeterminate'
    }
    try { if ($null -ne $resolver) { [AppDomain]::CurrentDomain.remove_AssemblyResolve($resolver) } } catch {
        $result.resolver_cleanup_error = $_.Exception.Message
        $result.status = 'failed_or_indeterminate'
    }
    $result | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath (Join-Path $job 'result.json') -Encoding utf8
}
if ($result.status -ne 'completed') { exit 1 }
