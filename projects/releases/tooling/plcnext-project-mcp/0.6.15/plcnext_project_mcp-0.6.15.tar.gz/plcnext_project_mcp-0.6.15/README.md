> 0.6.13 / 89 工具：新增同步启动观察失败核销（含合法 skip-Stop），交接观察预算默认12×5并可显式透传。[调用和证据](docs/sync-observation-reconciliation.md)。

> 0.6.12 / 88 工具：补齐 Stop 前完整预检、Stop 后零传输失败的受控恢复交接与明确差异输出。[调用及本次恢复参数](docs/stopped-recovery-handoff.md)。

> 0.6.11 / 85 工具：新增整机 reboot、等待重连、确认自动运行；重启仅发一次，支持只读续查及取消等待。本机 TLS 已验证，真实 PLC 重启待验。[调用说明](docs/device-reboot.md)。

> 0.6.10 / 80 工具：补齐启动观测失败与外部恢复后的精确租约交接，并支持预算内初始化只读重试。

> 0.6.9 / 79 工具：新增显式 decision_clock_slots_v2 原始事实导出，兼容旧v1；详见 decision-clock-slots-audit.md。

> 0.6.8 / 79 工具：新增可选 source_cohort 有限源窗口关联闭合；raw_tail 默认语义不变。

> 0.6.7 / 79 工具：补齐 partial 零 ACK 核销、自淘汰读游标解释，以及原始审计/业务 UNKNOWN 的独立完整性口径。

> 0.6.6：补齐启动超时零 ACK 的受控租约核销；应用 BootId 按父期限等待并验证启动前缀。仍为 79 个工具，详见 [恢复与审计](docs/recovery-start-audit.md)。

> 2026-10-26 更新（0.6.5）：恢复流程支持Start前预备、Start后立即审计，共享精确父租约；新增父审计失败受控核销。79工具。[调用与边界](docs/recovery-start-audit.md)。

> 2026-10-26 更新（0.6.4）：新增 M12 原生审计导出，78个工具；先fsync再确认固定审计游标，已完成本机TLS验证，真机吞吐待验。[调用与边界](docs/audit-export.md)。

> 2026-10-26 更新（0.6.3）：新增同步 execution_id 核销与审阅绑定的观察窗口，73工具；当前同步旧租约已通过公开接口核销。未恢复原工程。[M11-S说明](docs/lease-reconciliation.md)。

> 2026-10-26 更新（0.6.2）：新增 M11 受控租约核销，72 个公开工具；当前旧租约已通过公开工具核销，PLC Running、250 GOOD，无设备写入。[调用与验收](docs/lease-reconciliation.md)。

> 2026-10-26 更新（0.6.1）：用户已取消独立人工签发限制。MCP 可调用 `project_authorize_controller_operation`，自行决定并授权 download/control/recovery/instrumented_fault；无需人工终端。精确哈希、目标、有效期、一次性领取及审计仍有效。下文旧终端流程为可选方式。 [MCP自主授权及本次真机结果](docs/mcp-managed-authorization.md)。

# PLCnext Project MCP

当前源码 **0.6.5**：独立 PCWEX 编辑、IEC 冷编译、限定 PCWE 生成、有界在线只读、审批控制和显式恢复。不调用 ACI、CodeMeter、Engineer 界面或 computer use；编译仍依赖本机厂商组件和工程引用库。尚未完整替代 ACI。

**开始测试：[使用与测试手册](docs/mcp-user-guide.md)** · [M01～M10 联调指南](docs/joint-implementation-user-guide.md) · [实际全部工具/参数](docs/mcp-tool-reference.md) · [Schema](docs/mcp-tool-schema.json)。工具数量以生成参考为准，不代表验收完成率。

本轮恢复源是 `D:\work\code\PLCnext-Engineer\tmp\p01-p02\NativeGateway.restore-native-0.5.0.pcwex`，32 POU、单任务，SHA-256 `7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154`。源文件只读，均操作副本；多任务/故障插桩副本不替代该恢复归档。

## 能力与边界

| 范围 | 实现 | 未等同于 |
|---|---|---|
| 工程/ST/FB | 导入、新建、原子代码/变量接口及调用方修改、FB增删 | 全图形语言、任意类型/元数据修改 |
| 冷编译 | AXC F2152/2026、单eCLR、1…16受限独立周期任务，无项目AST种子 | 其他设备、任意共享并发架构或真实调度验收 |
| PCWE | 限定NativeGateway硬件/HMI，源/CIL/原生字段/映射/文件哈希检查 | 通用完整打包、签名和真机接受 |
| 在线只读 | 源符号/类型绑定、有限分块读、boot/config守卫、质量/配置窗口 | 原子快照、任意地址读或已加载模块哈希认证 |
| 审批/控制 | MCP自主授权或可选人工终端；精确限时一次性收据；Stop/Start审阅 | 广义授权自动扩大动作 |
| 下载/恢复 | 全包写回读、Reset/Load、显式恢复计划、连续租约、运行窗口 | 自动回滚/重试；DATA/STORED/mock等外部业务验收 |
| 故障/时序 | 有界审阅/本机监督；固定ESM、既有探针和收据取证 | 无自TTL后端的原工程可故障；P06/性能通过 |

真实设备变更前仍需对精确版本、包、目标、文件策略及停启影响由 MCP 自主授权。单独下载收据固定动作不含Stop/Start；整体恢复另有计划和收据。缺已加载身份的独立Start拒绝；结果不确定时不自动重发，不删除claimed/租约绕过恢复。

M07独立故障profile已改用原厂 `GET_MICROSECONDS(TRUE)/1000` 的核内CLOCK_MONOTONIC毫秒时基，故障时钟不再借用Main TON；业务Main.NowMs不变。新版33POU测试副本已离线冷编译/打包，真实执行还要求实读核钟推进；[时钟契约](artifacts/fault-write-research/clock-contract.json)与[新版profile](artifacts/fault-profile-generation/kernel-profile.json)均不代表已在PLC验证TTL，也不替代原32POU恢复源。

源码已实现、本机通过、真机通过分别报告。历史设备观察不能当本轮状态，当前文档不自发宣称任何新真机验收已通过。

只读预检默认仍读取两份固定元数据。明确选择verify_package_files才回读审阅内逐文件并核对远端SHA-512，capture_package_files进一步保存新本地磁盘包；清单/状态前后不稳或文件不全不能报告完整冻结。快照不证明设备内存已加载身份、与恢复源匹配或可执行回滚，也不读取远端清单额外路径。

## 本机接入

服务已注册为 `plcnext-project`，启动仓库 `.venv\Scripts\python.exe -I -m plcnext_mcp.server`。更新后重载MCP，必要时重启客户端并在新会话发现工具。

```powershell
codex mcp get plcnext-project --json
& 'D:\work\code\PLCnext-Engineer-mcp\.venv\Scripts\python.exe' -I -c "import plcnext_mcp; print(plcnext_mcp.__version__)"
```

工作区 `D:\PLCnext-MCP-Workspace`，厂商组件 `D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0`。Python3.11+，Windows/PowerShell7编译环境。其他项目共用服务，用绝对路径导入独立副本；通用配置见 [.mcp.example.json](.mcp.example.json) 和 [生成脚本](tools/Configure-Mcp.ps1)。安装/刷新见主手册，历史注册记录见 [跨项目使用](docs/use-in-other-projects.md)。

## 可复现文档

```powershell
Set-Location -LiteralPath 'D:\work\code\PLCnext-Engineer-mcp'
& '.\.venv\Scripts\python.exe' -I 'tools\export_mcp_reference.py'
& '.\.venv\Scripts\python.exe' -I 'tools\export_mcp_reference.py' --check
```

生成器从实际FastMCP读取工具，不连接PLC、不发行收据、不运行编译器；数量不硬编码，未知中文范围批注会明确列出。开发者回归使用 `python -I -m unittest discover -s tests -v`，历史e2e可能固定样例或含真实只读访问，先核对范围。

证据：[M01操作者入口](docs/operator-approval.md)、[M10独立多任务](docs/independent-multitask.md)、[0.5下载记录](docs/controller-download-client.md)、[0.5历史手册](docs/mcp-user-guide-0.5.0.md)、[ACI分析](docs/aci-analysis/README.md)。历史版本/限制保留原语境，不冒充当前能力。
