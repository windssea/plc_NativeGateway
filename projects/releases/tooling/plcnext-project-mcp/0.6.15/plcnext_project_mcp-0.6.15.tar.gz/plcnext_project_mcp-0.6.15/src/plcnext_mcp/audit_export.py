"""M12 fixed audit ring export. No arbitrary variable, business ACK or control writes."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import time
import uuid
from .project import ProjectError,sha
from .deployment_plan import _file
from .controller_download_plan import prepare_download_review,review_package_snapshot,_strict_json
from .runtime_monitor import _source,RuntimeReadClient,_checked_rows
from .controller_transport import ControllerEndpoint,ControllerFailure,TlsControllerClient
from .controller_control import ControlEndpointLease
from .operator_approval import OperatorApprovalContract,validate_operator_receipt,_paths,_issuer_lock,_new_file
from .operation_jobs import _bytes,_process_birth
from .rsc_runtime_codec import DATA_ACCESS
from .rsc_fault_write_codec import encode_fault_write,receive_write_error
from .rsc_codec import CommandType
from .audit_collector import Exporter,Journal,EvidenceError,EVENT_FIELDS,DIAGNOSTIC_FIELDS,GAP_FIELDS

SCHEMA='plcnext-audit-export-plan/v1'
_ACK={f'CaptureBuffer.{ring}Ack{suffix}':dtype for ring in ('Audit','Association') for suffix,dtype in [('BootId','utf8'),('Seq','uint64')]}
_AUTHORITY=object()

def names(fact_mode='legacy_v1'):
    result=['BootId','Active.Version']+['CaptureBuffer.'+n for n in
        'AuditEnabled AuditReadSeq AuditWriteSeq AssociationReadSeq AssociationWriteSeq AuditDropped AssociationDropped EvidenceComplete'.split()]+list(_ACK)
    result += [f'CaptureBuffer.AuditEvents[{i}].'+n for i in range(1,513) for n in [*('Event.'+f for f in EVENT_FIELDS),'Decision','Reason']]
    for i in range(1,33):
        result += [f'CaptureBuffer.Associations[{i}].'+n for n in ['Ordinal','MessageId','Digest','Count','ConfigSlot','ConfigGeneration','BatchGeneration','Category',*(f'SampleSeqs[{j}]' for j in range(1,65))]]
    for i in range(1,5):
        prefix=f'CaptureBuffer.Configs[{i}].'
        result += [prefix+n for n in ['Generation','GatewayId','CaptureBootId','Config.Version','Config.DeviceCount','Config.PointCount']]
        result += [prefix+f'Config.Devices[{j}].'+n for j in range(1,51) for n in ('deviceId','PointStart','PointCount')]
        result += [prefix+f'Config.Points[{j}].'+n for j in range(1,321) for n in ('pointId','dataType','reportMode','reportIntervalMs','deadband')]
    result += ['CaptureBuffer.Diagnostics.'+n for n in [*DIAGNOSTIC_FIELDS,*(f'Totals[{i}]' for i in range(1,17)),*('LastGap.'+f for f in GAP_FIELDS)]]
    if fact_mode=='decision_clock_slots_v2':
        from .audit_facts import FIELDS,HEAD
        result+=list(HEAD)+[f'CaptureBuffer.AuditEvents[{i}].'+n for i in range(1,513) for n in FIELDS]
    return result

def _symbols(store,pid,digest,fact_mode='legacy_v1'):
    _,_,model=_source(store,pid,digest)
    try:
        out={n:model.resolve('MainInstance.'+n) for n in names(fact_mode)}
        for path in ['CaptureBuffer.AuditEvents[513].Event.SampleSeq','CaptureBuffer.Associations[33].Ordinal','CaptureBuffer.Configs[5].Generation']:
            try:model.resolve('MainInstance.'+path)
            except ProjectError:pass
            else:raise EvidenceError('Unexpected audit ring capacity')
        if fact_mode=='decision_clock_slots_v2':
            from .audit_facts import FIELDS,HEAD
            expected=dict(HEAD)
            expected.update({f'CaptureBuffer.AuditEvents[{i}].'+n:t for i in range(1,513) for n,t in FIELDS.items()})
            for name,dtype in expected.items():
                if out[name]['wire_type']!=dtype:raise EvidenceError('Unexpected v2 fact type: '+name)
        for name,dtype in _ACK.items():
            if out[name]['wire_type']!=dtype:raise EvidenceError('Unexpected audit ACK type')
        if any(v['wire_type']=='utf8' and v['string_capacity']>256 for v in out.values()):raise EvidenceError('Oversized audit source string')
    except (ProjectError,EvidenceError) as exc:
        raise ProjectError('audit_profile_unsupported: full fixed audit rings/fields/types are required; original projects are not modified.') from exc
    return out

def prepare(store,project_id,expected_project_sha256,package_job_id,address,expected_certificate_sha256,expected_boot_id,
            *,port=41100,duration_seconds=30,poll_interval_ms=100,maximum_records=100000,maximum_bytes=67108864,parent_plan_id=None,closure_mode='raw_tail',tail_seconds=10,fact_mode='legacy_v1'):
    if type(expected_boot_id) is not str or not 1<=len(expected_boot_id)<=64:raise ProjectError('Exact nonempty boot ID required.')
    for value,low,high in [(duration_seconds,1,300),(poll_interval_ms,20,1000),(maximum_records,64,1000000),(maximum_bytes,4096,268435456)]:
        if type(value) is not int or not low<=value<=high:raise ProjectError('Audit bounds are outside supported limits.')
    if closure_mode not in ('raw_tail','source_cohort') or type(tail_seconds) is not int or not 1<=tail_seconds<=120:
        raise ProjectError('Invalid audit closure mode/tail bound')
    if fact_mode not in ('legacy_v1','decision_clock_slots_v2'):raise ProjectError('Unsupported fact mode')
    symbols=_symbols(store,project_id,expected_project_sha256,fact_mode)
    review=prepare_download_review(store,project_id,expected_project_sha256,package_job_id,address,expected_certificate_sha256,port)
    ident=uuid.uuid4().hex;folder=_file(store._folder(project_id),'audit-exports/'+ident);folder.mkdir(parents=True)
    symbol_bytes=_bytes(symbols);(folder/'symbols.json').write_bytes(symbol_bytes)
    plan={'schema':SCHEMA,'project_id':project_id,'plan_id':ident,'project_sha256':expected_project_sha256,
        'inventory_sha256':review['package']['inventory_sha256'],'target':review['target'],
        'package_review':{'review_id':review['review_id'],'review_sha256':review['review_sha256']},
        'symbols_sha256':sha(symbol_bytes),'symbol_count':len(symbols),'output_path':str(folder/'events.jsonl'),
        'policy':{'fact_mode':fact_mode,'expected_boot_id':expected_boot_id,'capture_capacity':512,'association_capacity':32,
            'maximum_total_seconds':300 if parent_plan_id else duration_seconds+tail_seconds+40,
            'capture_per_poll':64,'association_per_poll':16,'duration_seconds':duration_seconds,'tail_seconds':tail_seconds,'closure_mode':closure_mode,
            'poll_interval_ms':poll_interval_ms,'maximum_records':maximum_records,'maximum_bytes':maximum_bytes,
            'maximum_network_bytes':67108864,'maximum_package_read_bytes':67108864,'maximum_network_operations':20000,'chunk_size':64,
            'expected_capture_events_per_second':50,'physical_rate_verified':False,'require_startup_prefix':True,'automatic_retry':False,'task_or_sampling_changes':False,
            'ack_fields':_ACK,'ack_order':['invalidate_boot','clear_sequence','stage_boot','commit_sequence']},
        'approved_actions':['read_fixed_audit_rings','fsync_local_evidence','ack_only_durable_audit_cursors'],
        'memory_loaded_image_attested':False,'created_utc':datetime.now(timezone.utc).isoformat()}
    if parent_plan_id is not None:
        if re.fullmatch('[0-9a-f]{32}',parent_plan_id) is None:raise ProjectError('Invalid parent recovery identity')
        plan['policy']['parent_recovery_plan_id']=parent_plan_id
        plan['policy']['boot_binding']='observe_same_parent_start'
    plan['plan_sha256']=sha(_bytes(plan));_new_file(folder/'plan.json',plan);return plan

def _plan(store,pid,ident,digest):
    if re.fullmatch('[0-9a-f]{32}',ident or '') is None:raise ProjectError('Invalid audit plan ID.')
    folder=_file(store._folder(pid),'audit-exports/'+ident);plan=_strict_json((folder/'plan.json').read_bytes())
    payload=dict(plan);payload.pop('plan_sha256',None)
    if plan.get('schema')!=SCHEMA or plan.get('project_id')!=pid or plan.get('plan_id')!=ident or plan.get('plan_sha256')!=digest or sha(_bytes(payload))!=digest:
        raise ProjectError('Audit plan hash/identity changed.')
    if plan['output_path']!=str(folder/'events.jsonl'):raise ProjectError('Audit output path changed.')
    return folder,plan

def load(store,pid,ident,digest):
    folder,plan=_plan(store,pid,ident,digest)
    review,files=review_package_snapshot(store,pid,**{'review_id':plan['package_review']['review_id'],'expected_review_sha256':plan['package_review']['review_sha256']})
    if review['target']!=plan['target'] or review['source']['project_sha256']!=plan['project_sha256'] or review['package']['inventory_sha256']!=plan['inventory_sha256']:
        raise ProjectError('Audit source/package/target binding changed.')
    raw=(folder/'symbols.json').read_bytes()
    if len(raw)>16*1024*1024 or sha(raw)!=plan['symbols_sha256']:raise ProjectError('Audit whitelist changed.')
    symbols=_strict_json(raw)
    if symbols!=_symbols(store,pid,plan['project_sha256'],plan['policy'].get('fact_mode','legacy_v1')):raise ProjectError('Audit source symbols changed.')
    if plan['output_path']!=str(folder/'events.jsonl'):raise ProjectError('Audit output path changed.')
    return folder,plan,symbols

def approval_contract(store,pid,ident,digest):
    _,p,_=load(store,pid,ident,digest)
    return OperatorApprovalContract(kind='audit_export',review_sha256=digest,receipt_schema='plcnext-audit-export-operator-approval/v1',
        approval_directory='controller-audit-export-approvals',binding_fields={k:p[k] for k in ('target','project_sha256','inventory_sha256','policy','approved_actions','symbols_sha256','output_path')},display=p).checked()

class DurableJournal(Journal):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.durable={'Audit':0,'Association':0};self.hash=hashlib.sha256()
    def append(self,rows):
        prospective=dict(self.durable)
        for row in rows:
            ring='Audit' if row.get('kind')=='capture' else 'Association' if row.get('kind')=='association' else None
            if ring:
                seq=row['event']['Event.SampleSeq'] if ring=='Audit' else row['association']['Ordinal']
                if seq!=prospective[ring]+1:raise EvidenceError('Noncontiguous durable audit sequence')
                prospective[ring]=seq
        super().append(rows)
        raw=''.join(json.dumps(r,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n' for r in rows).encode()
        self.hash.update(raw);self.durable=prospective

def _audit(path,event):
    record={'observed_utc':datetime.now(timezone.utc).isoformat(),'observed_monotonic_ns':time.monotonic_ns(),**event}
    with path.open('ab') as f:f.write(_bytes(record)+b'\n');f.flush();os.fsync(f.fileno())

class AuditClient(RuntimeReadClient):
    def __init__(self,plan,symbols,authority,check,sink):
        if authority is not _AUTHORITY:raise ProjectError('Exact audit authorization required.')
        t=plan['target'];super().__init__(ControllerEndpoint(t['address'],t['port'],t['expected_certificate_sha256']),[],event_sink=sink)
        self.plan=plan;self.symbols=symbols;self.allowed_paths=frozenset(d['path'] for d in symbols.values())
        self.maximum_bytes=plan['policy']['maximum_network_bytes'];self.check=check;self.ack_unknown=False;self.ack_attempts=0
        self.config=None;self.last_ack={'Audit':0,'Association':0};self.write_queue=[]
    def _deadline(self):
        self.check()
        if len(self.trace)>self.plan['policy']['maximum_network_operations']:raise EvidenceError('Network operation limit')
        return super()._deadline()
    def read(self,names):
        if len(names)>4096 or any(n not in self.symbols for n in names):raise EvidenceError('Audit read outside fixed whitelist')
        result={}
        for at in range(0,len(names),64):
            chunk=names[at:at+64];desc=[self.symbols[n] for n in chunk]
            rows=_checked_rows(desc,self.read_variables([d['path'] for d in desc]),datetime.now(timezone.utc).isoformat())
            if any(row['status']!='read' for row in rows):raise EvidenceError('Audit runtime field/type unavailable')
            result.update((n,row['value']) for n,row in zip(chunk,rows))
        return result
    def _fixed_write(self,name,value):
        if not self.write_queue or self.write_queue[0]!=(name,value):raise EvidenceError('Audit ACK outside exact staged order')
        self.write_queue.pop(0)
        handle,provider=self._runtime_service(DATA_ACCESS)
        packet=encode_fault_write(handle,provider,self.symbols[name]['path'],_ACK[name],value)
        self._deadline();self.ack_unknown=True;self.ack_attempts+=1
        event={'operation':'AuditAckWrite','field':name,'value':value,'send_attempted':True,'response_received':False}
        self.trace.append(event);self._emit(event)
        self._send(packet);header,_=self._header();self._raise_remote_error(header)
        if header.command_type!=CommandType.INVOKE_CONFIRMATION or (header.service_handle,header.service_provider_handle,header.method_handle)!=(handle,provider,3):raise EvidenceError('Audit ACK response mismatch')
        if receive_write_error(self._receive)!=0:raise EvidenceError('Audit ACK rejected')
        event['response_received']=True;self._emit(event)
    def acknowledge(self,ring,boot,sequence,journal):
        if ring not in ('Audit','Association') or not isinstance(journal,DurableJournal) or sequence>journal.durable[ring] or sequence<=self.last_ack[ring]:raise EvidenceError('ACK lacks contiguous durable evidence')
        if boot!=self.plan['policy']['expected_boot_id']:raise EvidenceError('ACK boot differs from review')
        base='CaptureBuffer.'+ring
        _audit(Path(self.plan['output_path']).with_name('ack-journal.jsonl'),{'operation':'DurableAckIntent','ring':ring,'boot':boot,'sequence':sequence,'durable_bytes':journal.size,'durable_sha256':journal.hash.hexdigest()})
        stages=[('BootId',''),('Seq',0),('BootId',boot),('Seq',sequence)]
        if self.write_queue:raise EvidenceError('Previous ACK was not completed; no replay')
        self.write_queue=[(base+'Ack'+suffix,value) for suffix,value in stages]
        for suffix,value in stages:
            fence=self.read(['BootId','Active.Version',base+'ReadSeq'])
            if self.config is None:self.config=fence['Active.Version']
            if fence['BootId']!=boot or fence['Active.Version']!=self.config or fence[base+'ReadSeq']>self.last_ack[ring]:raise EvidenceError('Boot/config/cursor changed before ACK')
            self._fixed_write(base+'Ack'+suffix,value)
        seen=self.read(['BootId',base+'AckBootId',base+'AckSeq'])
        if seen['BootId']!=boot or seen[base+'AckBootId']!=boot or seen[base+'AckSeq']!=sequence:raise EvidenceError('ACK readback mismatch')
        self.last_ack[ring]=sequence;self.ack_unknown=False
        self._emit({'operation':'AuditAckVerified','ring':ring,'sequence':sequence})


def execute(store,pid,ident,digest):
    folder,plan,symbols=load(store,pid,ident,digest)
    if any((folder/name).exists() for name in ('started.json','result.json','events.jsonl')):
        raise ProjectError('Audit plan already attempted; never resume or replay its cursors. Prepare a new plan.')
    if plan['policy'].get('parent_recovery_plan_id'):raise ProjectError('Parent-bound audit must execute inside its exact recovery; standalone execution is forbidden.')
    contract=approval_contract(store,pid,ident,digest);paths=_paths(store.root,contract)
    lease_review={'target':plan['target'],'review_sha256':digest,'policy':{'plan_id':ident}}
    lease=ControlEndpointLease(lease_review,folder)
    journal=None;client=None;claimed=False
    result={'schema':'plcnext-audit-export-result/v1','plan_id':ident,'plan_sha256':digest,'status':'audit_failed',
        'endpoint_lease_path':str(lease.path),'ack_journal_path':str(folder/'ack-journal.jsonl'),
        'transport_journal_path':str(folder/'transport.jsonl'),'complete':False,'device_control_sent':False,'business_fifo_consumed':False,'p06_started':False,
        'automatic_retry':False,'outcome_unknown':False,'output_path':plan['output_path'],'physical_50_per_second_verified':False}
    started=time.monotonic();deadline=started+plan['policy'].get('maximum_total_seconds',plan['policy']['duration_seconds']+plan['policy']['tail_seconds']+40)
    def check():
        lease.validate(lease_review)
        if (folder/'cancel.json').exists():raise EvidenceError('Audit export cancelled')
        if time.monotonic()>deadline:raise EvidenceError('Audit total duration limit')
    try:
        with _issuer_lock(paths):
            if paths['revoked'].exists() or paths['denied'].exists():raise ProjectError('Audit authorization withdrawn')
            raw=paths['receipt'].read_bytes();validate_operator_receipt(_strict_json(raw),contract)
            _new_file(paths['claimed'],{'plan_sha256':digest,'approval_sha256':sha(raw)});claimed=True
        birth=_process_birth(os.getpid())
        if not birth:raise ProjectError('Cannot bind audit host process identity')
        _new_file(folder/'started.json',{'plan_sha256':digest,'host_pid':os.getpid(),'host_process_birth':birth})
        journal=DurableJournal(folder/'events.jsonl',max_bytes=plan['policy']['maximum_bytes'],max_records=plan['policy']['maximum_records'])
        client=AuditClient(plan,symbols,_AUTHORITY,check,lambda event:_audit(folder/'transport.jsonl',event));client.overall_end=deadline
        client.connect()
        from .plc_state import stable_state
        if not stable_state(client.get_state(),3):raise EvidenceError('Audit requires Running')
        first=client.read(['BootId','Active.Version']);client.config=first['Active.Version']
        if first['BootId']!=plan['policy']['expected_boot_id']:raise EvidenceError('Fresh boot differs from review')
        from .controller_package_read import read_reviewed_controller_package
        ref=plan['package_review'];package=read_reviewed_controller_package(store,pid,ref['review_id'],ref['review_sha256'],maximum_bytes=67108864)
        result['package_check_report']=package['report_path']
        if not package['remote_file_contents_verified'] or package.get('changed_from_reviewed_candidate') or package.get('cleanup_error_class'):raise EvidenceError('Actual disk package does not match reviewed candidate')
        check();load(store,pid,ident,digest)
        exporter=Exporter(client,journal);exporter.boot=plan['policy']['expected_boot_id'];exporter.expected_config=first['Active.Version']
        if plan['policy'].get('closure_mode')=='source_cohort':
            from .audit_cohort import SourceCohort
            exporter.cohort=SourceCohort()
        exporter.fact_mode=plan['policy'].get('fact_mode','legacy_v1')
        head=exporter.head();exporter.check(head)
        journal.append([{'kind':'start','bootId':exporter.boot,'head':head,'startup_prefix_from':1,'plan_sha256':digest,**exporter.fact_metadata()}])
        collect_started=time.monotonic();until=collect_started+plan['policy']['duration_seconds'];polls=0
        while time.monotonic()<until:
            exporter.poll();polls+=1;check();time.sleep(plan['policy']['poll_interval_ms']/1000)
        if exporter.cohort:
            from .audit_cohort import close_source_window
            result.update(close_source_window(exporter,plan['policy'],deadline,check))
        else:
            tail=exporter.head();exporter.check(tail);exporter.tail=(tail['CaptureBuffer.AuditWriteSeq'],tail['CaptureBuffer.AssociationWriteSeq'])
            journal.append([{'kind':'tailBoundary','bootId':exporter.boot,'head':tail}])
            end=time.monotonic()+plan['policy']['tail_seconds']
            while (exporter.capture,exporter.association)!=exporter.tail:
                if time.monotonic()>end:raise EvidenceError('Tail did not drain within reviewed bound')
                exporter.poll();polls+=1;check();time.sleep(plan['policy']['poll_interval_ms']/1000)
        exporter.check(exporter.head());load(store,pid,ident,digest)
        if not exporter.diagnostic_revision:raise EvidenceError('No stable diagnostic snapshot observed')
        if not stable_state(client.get_state(),3):raise EvidenceError('Controller state changed during export')
        if not exporter.cohort:journal.append([{'kind':'end','bootId':exporter.boot,'capture':exporter.capture,'association':exporter.association,'complete_through_tail':True,**exporter.fact_metadata()}])
        result.update(status='audit_export_completed',complete=True,**exporter.fact_metadata(),tail=list(exporter.tail) if exporter.tail else None,capture=exporter.capture,
            association=exporter.association,polls=polls,max_capture_backlog=exporter.max_capture_backlog,
            max_association_backlog=exporter.max_association_backlog,
            measured_export_events_per_second=exporter.capture/max(time.monotonic()-collect_started,0.001),
            **exporter.business_completeness,
            monitoring_impact_on_plc_task_verified=False,completeness_scope='fixed source denominator and observed associations; not business delivery' if exporter.cohort else 'startup prefix through recorded tail, not events captured afterward')
    except Exception as exc:
        if 'exporter' in locals():result.update(exporter.fact_metadata())
        if 'exporter' in locals() and exporter.cohort:
            exporter.cohort.reason=str(exc)[:512]
            result.update(exporter.cohort.report(journal.durable['Audit'],journal.durable['Association']))
        result.update(error_class=type(exc).__name__,error=str(exc)[:512],outcome_unknown=bool(client and client.ack_unknown))
        if journal:
            try:journal.append([{'kind':'failure','complete':False,'error':str(exc)[:512]}])
            except Exception:pass
    finally:
        if client:
            cleanup=client.close();result.update(ack_write_attempts=client.ack_attempts,network_bytes_received=client.bytes_received,
                network_bytes_sent=client.bytes_sent,network_operations=len(client.trace),cleanup_error_class=cleanup)
            if cleanup:result.update(complete=False,status='audit_failed')
        if journal:
            result.update(durable_bytes=journal.size,durable_records=journal.records,journal_sha256=journal.hash.hexdigest())
            journal.close();result['actual_file_sha256']=sha(Path(plan['output_path']).read_bytes())
        result['duration_seconds']=time.monotonic()-started
        if result['outcome_unknown']:lease.quarantine()
        result['endpoint_lease_retained']=lease.quarantined
        try:_new_file(folder/'result.json',result)
        except Exception:
            if claimed:lease.quarantine()
            raise
        finally:
            if not lease.quarantined:lease.release()
    return result

def status(store,pid,ident,digest):
    folder,plan=_plan(store,pid,ident,digest)
    if (folder/'result.json').exists():return _strict_json((folder/'result.json').read_bytes())
    if not (folder/'started.json').exists():return {'status':'prepared','plan':plan}
    owner=_strict_json((folder/'started.json').read_bytes())
    active=bool(owner.get('host_process_birth')) and _process_birth(owner['host_pid'])==owner['host_process_birth']
    return {'status':'active_host_no_terminal_result' if active else 'host_outcome_unknown','complete':False,'automatic_retry':False,'owner':owner,'output_path':plan['output_path']}

def cancel(store,pid,ident,digest):
    folder,_=_plan(store,pid,ident,digest)
    if not (folder/'cancel.json').exists():_new_file(folder/'cancel.json',{'plan_sha256':digest})
    return {'status':'cancel_requested','controller_changed':False,'cancellation_is_not_proof_of_ack_rollback':True}
