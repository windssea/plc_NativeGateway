"""Cross-check source identities, CIL types and native-image field offsets offline."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import subprocess

from .project import ProjectError, decode_code, masked_st, pou_index, sha


def finalize_runtime_types(image_path: Path, type_information: Path, output: Path, install: Path,
                           expected_generated_hashes: dict[str, str]) -> dict:
    shell = shutil.which('pwsh')
    if os.name != 'nt' or not shell:
        raise ProjectError('Native type layout extraction requires local Windows/PowerShell 7.')
    if output.exists():
        raise ProjectError('Runtime type output must be a fresh directory.')
    cil_files = sorted([*image_path.parent.glob('*.dll'), *image_path.parent.glob('*.exe')])
    expected_cil = {name for name in expected_generated_hashes if name.endswith(('.dll', '.exe'))}
    if {p.name for p in cil_files} != expected_cil:
        raise ProjectError('CIL directory differs from the bound build output inventory.')
    paths = [image_path, type_information, *cil_files]
    inputs = {str(p): sha(p.read_bytes()) for p in paths}
    if any(inputs[str(p)] != expected_generated_hashes.get(p.name) for p in paths):
        raise ProjectError('Runtime layout inputs differ from the bound cold build.')
    output.mkdir(parents=True)
    command = [shell, '-NoLogo', '-NoProfile', '-NonInteractive', '-File',
        str(Path(__file__).parent / 'compile_host/Invoke-FinalizeRuntime.ps1'),
        '-InputImage', str(image_path), '-InputTypeInformation', str(type_information),
        '-OutputDirectory', str(output), '-InstallDirectory', str(install)]
    try:
        result = subprocess.run(command, capture_output=True, timeout=45)
    except subprocess.TimeoutExpired as exc:
        raise ProjectError('Native type layout extraction timed out.') from exc
    (output / 'stdout.log').write_bytes(result.stdout)
    (output / 'stderr.log').write_bytes(result.stderr)
    report_path = output / 'runtime-types-report.json'
    report = json.loads(report_path.read_text(encoding='utf-8-sig')) if report_path.is_file() else {}
    if result.returncode or report.get('status') != 'runtime_types_finalized':
        raise ProjectError('Native type layout extraction failed; inspect ' + str(report_path))
    if any(sha(Path(p).read_bytes()) != value for p, value in inputs.items()):
        raise ProjectError('Native image/type input changed during layout extraction.')
    return {'input_hashes': inputs, 'type_information_sha256': sha((output / 'TypeInformation.json').read_bytes()),
            'report_sha256': sha(report_path.read_bytes()), 'output_directory': str(output),
            'controller_connected': False, 'plc_program_executed': False}


def _one(records, name):
    matches = [record for record in records if record['name'] == name]
    if len(matches) != 1:
        raise ProjectError('Missing or ambiguous compiled identity: ' + name)
    return matches[0]


def validate_runtime_layout(members: dict, source_report: dict, type_information: dict,
                            image_report: dict, resource_name: str) -> dict:
    from .runtime_configuration import generate_runtime_configuration
    _, rebuilt = generate_runtime_configuration(members, ownership_contract=source_report.get('ownership_contract'))
    for key in ('variables', 'hmi_mappings', 'programs', 'task_program_relations', 'tasks'):
        if source_report.get(key) != rebuilt[key]:
            raise ProjectError('Runtime source report differs from the current project: ' + key)
    if image_report.get('status') != 'runtime_types_finalized':
        raise ProjectError('Finalized native image metadata is required.')
    from .device_profiles import device_profile
    profile = device_profile(members)
    if image_report.get('processor_type') != profile['image_processor'] or image_report.get('program_model') != profile['program_model'] or image_report.get('little_endian') is not True:
        raise ProjectError('Unsupported native image processor/program model.')
    types = type_information.get('Types', [])
    if not types or len({t['Name'] for t in types}) != len(types):
        raise ProjectError('Missing or ambiguous runtime type information.')
    type_map = {t['Name']: t for t in types}
    native = image_report['native_layout']
    cil = image_report['cil_layout']
    structures = 0
    for t in types:
        if not isinstance(t.get('RuntimeSize'), int) or t['RuntimeSize'] <= 0 or t.get('RuntimeAlignment', 0) <= 0:
            raise ProjectError('Unfinalized runtime size/alignment: ' + t['Name'])
        if t['Kind'] != 'Structure':
            continue
        n = _one(native, t['RuntimeType'])
        c = _one(cil, t['RuntimeType'])
        if n['size'] != t['RuntimeSize']:
            raise ProjectError('Native structure size mismatch: ' + t['Name'])
        if {f['Name'] for f in t['Fields']} != {f['name'] for f in c['fields'] if not f['is_static']}:
            raise ProjectError('Native structure field set differs from CIL: ' + t['Name'])
        for f in t['Fields']:
            field = _one(n['fields'], f['Name'])
            cil_field = _one(c['fields'], f['Name'])
            child_type = type_map.get(f['FieldType'])
            if child_type is None or f['FieldRuntimeType'] != child_type['RuntimeType'] or cil_field['type'] != f['FieldRuntimeType']:
                raise ProjectError('Structure field runtime type mismatch: ' + t['Name'] + '.' + f['Name'])
            if field['offset'] != f['FieldOffset'] or field['is_static']:
                raise ProjectError('Native structure field offset mismatch: ' + t['Name'] + '.' + f['Name'])
            if field['type'] is not None and field['type'] != cil_field['type']:
                raise ProjectError('Native structure field type mismatch: ' + t['Name'] + '.' + f['Name'])
            if field['offset'] < 0 or field['offset'] + child_type['RuntimeSize'] > t['RuntimeSize']:
                raise ProjectError('Structure field is outside native storage: ' + t['Name'] + '.' + f['Name'])
        structures += 1
    ng = _one(native, 'ProConOS_eCLR.ResGlobalVars')
    cg = _one(cil, 'ProConOS_eCLR.ResGlobalVars')
    if {f['name'] for f in cg['fields']} != {v['name'] for v in source_report['variables']}:
        raise ProjectError('Compiled global variable set differs from source mappings.')
    variables = []
    for var in source_report['variables']:
        t = type_map.get(var['data_type'])
        if t is None:
            raise ProjectError('Unknown global runtime type: ' + var['data_type'])
        c = _one(cg['fields'], var['name'])
        n = _one(ng['fields'], var['name'])
        expected_type = t['RuntimeType'] + ('*' if var['address'] else '')
        if c['type'] != expected_type or not c['is_static'] or not n['is_static'] or n['offset'] < 0:
            raise ProjectError('Compiled global type/storage differs from source: ' + var['name'])
        if n['type'] is not None and n['type'] != expected_type:
            raise ProjectError('Native global type differs from CIL: ' + var['name'])
        variables.append(var | {'runtime_type': t['RuntimeType'], 'size': t['RuntimeSize'],
            'static_field_offset': n['offset'], 'indirect_address': bool(var['address'])})
    variable_map = {v['name']: v for v in variables}
    hmi = []
    for tag in source_report['hmi_mappings']:
        v = variable_map[tag['name']]
        if v['id'] != tag['id'] or v['data_type'] != tag['data_type']:
            raise ProjectError('HMI tag no longer identifies the same variable: ' + tag['tag_name'])
        hmi.append(tag | {k: v[k] for k in ('runtime_type', 'size', 'static_field_offset', 'indirect_address')})
    index = pou_index(members)
    fb_types = {name.casefold(): name for name, item in index.items() if item['kind'] == 'FunctionBlock'}
    instances = []
    for name, item in index.items():
        declared = {}
        source = masked_st(decode_code(members[item['prefix'] + 'Variables.var']))
        for declaration in re.finditer(r'\b([A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)*)\s*:\s*([^;]+);', source):
            expression = declaration.group(2).strip()
            found = [value for key, value in fb_types.items() if re.search(r'\b' + re.escape(key) + r'\b', expression, re.I)]
            if not found:
                continue
            if expression.casefold() not in fb_types:
                raise ProjectError('Unsupported complex FB instance declaration: ' + name + ': ' + expression)
            for variable in re.findall(r'[A-Za-z_]\w*', declaration.group(1)):
                declared[variable] = fb_types[expression.casefold()]
        c = _one(cil, name)
        actual = {f['name']: f['type'] for f in c['fields'] if f['type'].casefold() in fb_types}
        if declared != actual:
            raise ProjectError('Compiled FB instance declarations differ from source: ' + name)
        if declared:
            n = _one(native, name)
            for variable, typename in declared.items():
                field = _one(n['fields'], variable)
                cil_field = _one(c['fields'], variable)
                if field['offset'] < 0 or field['is_static'] != cil_field['is_static']:
                    raise ProjectError('Invalid native FB field offset: ' + name + '.' + variable)
                if not field['is_static'] and field['offset'] >= n['size']:
                    raise ProjectError('Native FB field offset is outside its instance: ' + name + '.' + variable)
                if field['type'] is not None and field['type'] != typename:
                    raise ProjectError('Native FB instance type mismatch: ' + name + '.' + variable)
                instances.append({'pou': name, 'instance': variable, 'type': typename,
                                  'native_field_offset': field['offset'], 'is_static': field['is_static']})
    # The ESM instance must also exist in both generated resource and task classes.
    program_bindings = []
    for program in source_report['programs']:
        instance = program['name']
        typename = program['programType']
        c = _one(cil, 'ProConOS_eCLR.__' + resource_name)
        f = _one(c['fields'], instance)
        if f['type'] != typename or not f['is_static']:
            raise ProjectError('ESM program instance differs from compiled resource: ' + instance)
        nf = _one(_one(native, c['name'])['fields'], instance)
        if not nf['is_static'] or nf['offset'] < 0 or (nf['type'] is not None and nf['type'] != typename):
            raise ProjectError('ESM instance differs from native resource: ' + instance)
        for relation in source_report['task_program_relations']:
            if relation['programName'] != program['componentName'] + '/' + instance:
                continue
            task = _one(cil, 'ProConOS_eCLR.__' + relation['taskName'])
            tf = _one(task['fields'], instance)
            if tf['type'] != typename or not tf['is_static']:
                raise ProjectError('ESM task binding differs from compiled task: ' + relation['taskName'])
            ntf = _one(_one(native, task['name'])['fields'], instance)
            if not ntf['is_static'] or ntf['offset'] < 0 or (ntf['type'] is not None and ntf['type'] != typename):
                raise ProjectError('ESM task binding differs from native task: ' + relation['taskName'])
        program_bindings.append({'instance': instance, 'type': typename, 'resource_field_verified': True})
    return {'passed': True, 'runtime_type_count': len(types), 'native_structure_count': structures,
            'variables': variables, 'variable_count': len(variables), 'hmi_mappings': hmi,
            'hmi_mapping_count': len(hmi), 'fb_instances': instances, 'fb_instance_count': len(instances),
            'fb_instance_scope': 'project-local function block types only; library FB layouts are not individually checked',
            'program_bindings': program_bindings, 'source_to_cil_and_native_offsets_verified': True,
            'offsets_are_local_image_metadata_not_live_addresses': True,
            'controller_execution_verified': False}
