"""Exact current-source handoff for a terminal read-only observation failure."""
from pathlib import Path
import re
from .project import ProjectError,sha
from .runtime_monitor import load_runtime_read_plan,read_runtime_plan
from .controller_recovery import verify_original_runtime

def bind_current(store,context,target):
    required={'project_id','project_sha256','plan_id','plan_sha256','expected_boot_id',
        'expected_configuration','expected_configuration_sha256','external_evidence_path','external_evidence_sha256','description'}
    if set(context)!=required or not context['description'].strip() or not context['expected_boot_id']:
        raise ProjectError('Explicit complete current-state binding required')
    if any(re.fullmatch('[0-9a-f]{64}',context[k] or '') is None for k in ('project_sha256','plan_sha256','expected_configuration_sha256','external_evidence_sha256')):
        raise ProjectError('Full current-state SHA256 values required')
    cfg=context['expected_configuration']
    if (set(cfg)!={'version','device_count','point_count','enabled'} or type(cfg['enabled']) is not bool
            or any(type(cfg[k]) is not int or cfg[k]<0 for k in ('version','device_count','point_count'))):
        raise ProjectError('Exact typed current configuration required')
    p=load_runtime_read_plan(store,context['project_id'],context['plan_id'],context['plan_sha256'])
    if any(p['target'].get(k)!=target.get(k) for k in ('address','port','expected_certificate_sha256')) or p['project_sha256']!=context['project_sha256']:
        raise ProjectError('Current read plan source/target differs from handoff')
    path=Path(context['external_evidence_path'])
    if not path.is_absolute() or not path.is_file() or not 0<path.stat().st_size<=16*1024*1024 or sha(path.read_bytes())!=context['external_evidence_sha256']:
        raise ProjectError('External handoff evidence missing or changed')
    return dict(context)

def observe_current(store,context):
    o=read_runtime_plan(store,context['project_id'],context['plan_id'],context['plan_sha256'])
    check=verify_original_runtime(o,context['expected_configuration'])
    if (o.get('status')!='monitor_read_completed' or o.get('cleanup_error_class')
            or not all(check[k] for k in ('configuration_matches','program_running_observed','all_points_good_observed'))):
        raise ProjectError('Current handoff did not verify exact Running/configuration/GOOD')
    for key in ('guards_before','guards_after'):
        rows=[r for r in o.get(key,[]) if r.get('symbol')=='MainInstance.BootId']
        if len(rows)!=1 or rows[0].get('status')!='read' or rows[0].get('value')!=context['expected_boot_id']:
            raise ProjectError('Current boot differs from explicit handoff')
    if (o.get('source_project_sha256')!=context['project_sha256']
            or o.get('configuration_digest',{}).get('sha256')!=context['expected_configuration_sha256']):
        raise ProjectError('Current source/configuration digest differs from handoff')
    return {k:o[k] for k in ('observation_id','observation_sha256','report_path','created_utc')}|{
        'verification':check,'current_boot_id':context['expected_boot_id'],'current_project_id':context['project_id'],
        'configuration_sha256':context['expected_configuration_sha256'],'memory_loaded_image_attested':False}
