"""Explicit independent device/ABI profiles; never infer an unknown fallback."""
import json
import os
from pathlib import Path
import re
from .project import ProjectError, xml, sha


def _validated(value):
    if not isinstance(value, dict) or value.get('schema') != 'plcnext-device-profile/v1':
        raise ProjectError('Invalid device profile schema.')
    checks = {'profile_id': r'[A-Za-z0-9][A-Za-z0-9_.-]{0,95}',
              'device_name': r'[A-Za-z0-9][A-Za-z0-9 _.-]{0,95}', 'device_type': r'[A-Za-z0-9_-]{1,80}',
              'device_version': r'\d+\.\d+\.\d+', 'profile_revision': r'\d+/\d+\.\d+\.\d+',
              'processor': r'[a-z0-9_-]{1,32}', 'template': r'[A-Za-z0-9_.-]+\.pxctx',
              'backend': r'CIL-Compiler/cilc-[A-Za-z0-9_.-]+\.dll',
              'runtime_package': r'Profiles/[A-Za-z0-9 _.+-]+\.zip',
              'runtime_copy_prefix': r'Copy/\d+\.\d+\.\d+/',
              'hardware_sha256': r'[0-9a-f]{64}', 'product_code': r'[0-9]{1,30}'}
    for key, pattern in checks.items():
        if not isinstance(value.get(key), str) or not re.fullmatch(pattern, value[key]) or '..' in value[key]:
            raise ProjectError('Invalid device profile field: ' + key)
    if (value.get('compile_family') != 'eclr_2026_st_cyclic' or value.get('package_family') != 'nativegateway_hmi_2026'
            or value.get('namespaces_supported') is not True):
        raise ProjectError('Unsupported toolchain family; implement and validate its adapter first.')
    for key in ('image_processor','program_model','elf_machine','empty_system_variable_task_count'):
        if type(value.get(key)) is not int or not 0 <= value[key] <= 65535:
            raise ProjectError('Invalid device ABI/profile integer: ' + key)
    if type(value.get('elf_class')) is not int or value.get('elf_class') not in (1,2):
        raise ProjectError('Unsupported device ELF class.')
    if (value.get('hmi_mode') != 'gateway_login' or (value.get('hmi_access_rights'),value.get('hmi_authentication_protocol')) not in (('0',0),('2',2))):
        raise ProjectError('Unsupported source HMI mode/access rights.')
    return dict(value)


PROFILES = {p['profile_id']: _validated(p) for p in json.loads(
    (Path(__file__).parent / 'profiles/eclr-2026.json').read_text(encoding='utf-8'))}


def profile_directory():
    return Path(os.environ.get('PLCNEXT_MCP_DEVICE_PROFILES_DIRECTORY', str(Path.home() / 'PLCnext-MCP-DeviceProfiles'))).resolve()


def all_profiles():
    profiles = list(PROFILES.values())
    directory = profile_directory()
    files = list(directory.glob('*.json')) if directory.is_dir() else []
    if len(files) > 256:
        raise ProjectError('Too many registered device profiles.')
    for path in sorted(files):
        if path.is_symlink() or path.stat().st_size > 32768:
            raise ProjectError('Linked or oversized device profile.')
        profiles.append(_validated(json.loads(path.read_text(encoding='utf-8'))))
    keys = [(p['device_name'], p['profile_revision'], p['hardware_sha256']) for p in profiles]
    if len(set(keys)) != len(keys) or len({p['profile_id'] for p in profiles}) != len(profiles):
        raise ProjectError('Ambiguous device profile identity; overriding an existing chain is forbidden.')
    return profiles


def register_profile(specification):
    profile = _validated(specification)
    profile['qualification'] = 'registered_not_hardware_validated'
    directory = profile_directory();directory.mkdir(parents=True, exist_ok=True)
    path = directory / (profile['profile_id'] + '.json')
    from .endpoint_guard import endpoint_guard
    with endpoint_guard(directory / 'registration'):
        if any(p['profile_id'] == profile['profile_id'] or (p['device_name'],p['profile_revision'],p['hardware_sha256']) ==
               (profile['device_name'],profile['profile_revision'],profile['hardware_sha256']) for p in all_profiles()):
            raise ProjectError('Device profile already registered; use a new supported revision, never overwrite.')
        with path.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(profile,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
            stream.flush();os.fsync(stream.fileno())
    return {'profile': profile, 'profile_path': str(path), 'controller_access': False,
            'requires_independent_compile_package_and_hardware_acceptance': True}


def device_profile(members):
    document = xml(members['PROJECT/PROJECT.proj'])
    configurations = []
    for node in document.iter():
        values = {c.tag.rsplit('}', 1)[-1]: c.text for c in node}
        if values.get('FolderType') == 'Configuration':
            configurations.append(values)
    if len(configurations) != 1:
        raise ProjectError('Exactly one supported controller configuration is required.')
    configuration = configurations[0]
    name = configuration.get('TypeName')
    matches = [p for p in all_profiles() if p['device_name'] == name and p['profile_revision'] == configuration.get('TypeRevision')]
    if len(matches) > 1:
        from .pcwe_auxiliary import _hardware_profile
        digest, _, _ = _hardware_profile(members)
        matches = [p for p in matches if p['hardware_sha256'] == digest]
    if len(matches) != 1:
        raise ProjectError('Unsupported device/profile: register an exact independent device toolchain first.')
    profile = matches[0]
    # Acceptance metadata is separate from the reproducible compiler settings.
    digest = sha(json.dumps({k:v for k,v in profile.items() if k!='qualification'},sort_keys=True,separators=(',',':')).encode())
    return {**profile, 'profile_sha256': digest,
            'scope': 'NativeGateway_' + profile['device_type'] + '_2026_verified_hardware_and_HMI_profile'}


def inspect_source_profile(store, project_id):
    _, manifest, members, _, _ = store._current(project_id)
    from .pcwe_auxiliary import _hardware_profile
    digest, _, _ = _hardware_profile(members)
    configurations=[]
    for node in xml(members['PROJECT/PROJECT.proj']).iter():
        values={c.tag.rsplit('}',1)[-1]:c.text for c in node}
        if values.get('FolderType')=='Configuration':
            configurations.append({'device_name':values.get('TypeName'),'profile_revision':values.get('TypeRevision')})
    try:
        selected=device_profile(members)
        selection={'supported':True,'profile_id':selected['profile_id'],'profile_sha256':selected['profile_sha256']}
    except ProjectError as exc:
        selection={'supported':False,'reason':str(exc)}
    return {'project_id':project_id,'project_sha256':manifest['current_sha256'],'hardware_sha256':digest,
            'configurations':configurations,'selection':selection,'controller_access':False}


def validate_elf(payload, profile):
    if (len(payload) < 20 or payload[:4] != b'\x7fELF' or payload[4] != profile['elf_class']
            or payload[5] != 1 or int.from_bytes(payload[18:20], 'little') != profile['elf_machine']):
        raise ProjectError('Native library ELF architecture differs from device profile: ' + profile['device_type'])
