"""Immutable, target-separated NativeGateway releases. No controller I/O.

An archive, a compiled package and a deployment attempt are different facts.
Missing terminal evidence is unknown, never successful or automatically retried.
"""
from __future__ import annotations

from datetime import datetime, timezone
import functools
import io
import ipaddress
import json
import os
from pathlib import Path
import re
import uuid
import zipfile

from .project import ProjectError, read_archive, sha
from .endpoint_guard import endpoint_guard

MAIN = 'PROJECT/Logical%20Elements/Main.pou/Code.st'
VERSION = re.compile(rb'"agentVersion":"([^"\r\n]+)"')
TARGETS = {'AXCF2152': ('192.168.0.8', 'NG-HUB-2152-01'),
           'AXCF1252': ('192.168.0.10', 'NG-HUB-1252-01')}
KNOWN_HISTORICAL = {
    'AXCF2152': {'ac9cfec98d592e6c14f074725176be572831335c39273ef666f468de34236dc0',
                '42d246435b950a8352e8dd2421319e546aff3fb8fb9cfb823070d4139279e4fb'},
    'AXCF1252': {'69e489001ff22bf2802d45dcfa67f35305cedef8725079b7a794d65cb51eea2c'},
}


def now():
    return datetime.now(timezone.utc).isoformat()


def root(store):
    return Path(os.environ.get('PLCNEXT_MCP_RELEASE_ROOT', str(store.root / 'releases'))).resolve()


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def read(path):
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ProjectError('Oversized release record.')
    return json.loads(path.read_text(encoding='utf-8'))


def hardware_types():
    from .device_profiles import all_profiles
    return sorted({p['device_type'] for p in all_profiles()})


def deployment_targets(store):
    records = [{'device_type': hardware, 'address': address, 'gateway_id': gateway}
               for hardware, (address, gateway) in TARGETS.items()]
    files = list((root(store) / 'targets').glob('*.json'))
    if len(files) > 1024:
        raise ProjectError('Too many release target bindings.')
    for path in files:
        if path.is_symlink():
            raise ProjectError('Linked release target binding.')
        record = read(path)
        if record.get('device_type') not in hardware_types():
            raise ProjectError('Release target has no registered device compiler profile.')
        records.append(record)
    if (len({r['address'] for r in records}) != len(records)
            or len({r['gateway_id'] for r in records}) != len(records)):
        raise ProjectError('Ambiguous release target identity.')
    return records


def register_target(store, device_type, address, gateway_id):
    if device_type not in hardware_types():
        raise ProjectError('Register the independent device compiler profile first.')
    try:
        address = str(ipaddress.ip_address(address))
    except ValueError as exc:
        raise ProjectError('Release target must use a literal IP.') from exc
    if not isinstance(gateway_id, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{3,63}', gateway_id):
        raise ProjectError('Invalid independent gateway identity.')
    directory = root(store) / 'targets';directory.mkdir(parents=True, exist_ok=True)
    with endpoint_guard(directory / 'registration'):
        if any(r['address'] == address or r['gateway_id'] == gateway_id for r in deployment_targets(store)):
            raise ProjectError('Target address or gateway identity already bound; cannot replace another device.')
        record = {'device_type': device_type, 'address': address, 'gateway_id': gateway_id,
                  'registered_utc': now(), 'device_contacted': False}
        write_new(directory / (sha(gateway_id.encode()) + '.json'), record)
    return record


def identity(members, store):
    from .device_profiles import device_profile
    hardware = device_profile(members)['device_type']
    versions = VERSION.findall(members.get(MAIN, b''))
    if len(versions) != 1:
        raise ProjectError('Release requires one supported controller and one heartbeat agentVersion.')
    literals = set(re.findall(rb"'([A-Za-z0-9][A-Za-z0-9._-]{3,63})'", members[MAIN]))
    matches = [r for r in deployment_targets(store) if r['gateway_id'].encode() in literals]
    if len(matches) != 1 or matches[0]['device_type'] != hardware:
        raise ProjectError('Release gateway identity does not match hardware target.')
    return hardware, versions[0].decode('ascii'), matches[0]['address'], matches[0]['gateway_id']


def folder(store, target, version):
    if target not in hardware_types() or re.fullmatch(r'native-\d+\.\d+\.\d+(?:-[A-Za-z0-9.-]+)?', version) is None:
        raise ProjectError('Invalid release target/version.')
    path = root(store) / target / version
    # Reject links/junctions rather than allowing a release directory to escape.
    for item in (root(store), path.parent, path):
        if item.is_symlink() or (hasattr(item, 'is_junction') and item.is_junction()):
            raise ProjectError('Linked release directories are unsupported.')
    return path


def save_source(store, raw, members, *, origin, note, source_input_sha256):
    target, version, address, gateway = identity(members, store)
    if not isinstance(note, str) or not note.strip() or len(note) > 2000:
        raise ProjectError('A bounded release change/provenance note is required.')
    directory = folder(store, target, version)
    with endpoint_guard(directory.parent / 'registry'):
        if directory.exists():
            record = inspect(store, target, version)
            if record['project_sha256'] != sha(raw):
                raise ProjectError('Release version already exists with different bytes; create a new dev version.')
            return record
        directory.mkdir(parents=True, exist_ok=False)
        with (directory / 'project.pcwex').open('xb') as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        record = {'schema': 'plcnext-release/v1', 'target': target, 'version': version,
                  'address': address, 'gateway_id': gateway, 'project_sha256': sha(raw),
                  'source_input_sha256': source_input_sha256, 'created_utc': now(),
                  'origin': origin, 'change_note': note, 'controller_downloaded_by_registration': False,
                  'current_device_version_verified': False,
                  'channel': 'dev' if '-dev.' in version else 'historical'}
        write_new(directory / 'release.json', record)
        return inspect(store, target, version)


def prepare_dev(store, project_id, expected_project_sha256, base_version, change_note, build_number=0):
    if re.fullmatch(r'\d+\.\d+\.\d+', base_version) is None:
        raise ProjectError('base_version must be X.Y.Z; new builds are always dev versions.')
    if type(build_number) is not int or not 0 <= build_number <= 999999:
        raise ProjectError('build_number must be 0..999999; increment it for a toolchain-only rebuild.')
    directory = store._folder(project_id)
    with store._lock(directory):
        _, manifest, members, infos, comment = store._current(project_id)
        if manifest['current_sha256'] != expected_project_sha256:
            raise ProjectError('Stale project revision.')
        identity(members, store)
        # Hash the actual complete input, not a mutable branch label or clock.
        suffix = (str(build_number) + '.') if build_number else ''
        version = 'native-' + base_version + '-dev.' + suffix + expected_project_sha256[:16]
        members[MAIN] = VERSION.sub(lambda _: ('"agentVersion":"' + version + '"').encode(), members[MAIN])
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w') as archive:
            archive.comment = comment
            for info in infos:
                archive.writestr(info, members[info.filename])
        record = save_source(store, buffer.getvalue(), members, origin='mcp_dev_build',
                             note=change_note, source_input_sha256=expected_project_sha256)
    managed = store.import_copy(str(Path(record['release_directory']) / 'project.pcwex'))
    return {'release': record, 'managed_project': managed, 'compiled': False, 'downloaded': False}


def archive_historical(store, source_path, expected_project_sha256, provenance_note):
    raw, members, _, _ = read_archive(Path(source_path).resolve(strict=True))
    if sha(raw) != expected_project_sha256:
        raise ProjectError('Historical archive SHA-256 mismatch.')
    target, _, _, _ = identity(members, store)
    if sha(raw) not in KNOWN_HISTORICAL.get(target, set()):
        raise ProjectError('Not a known frozen baseline; modified source must use prepare_dev.')
    return save_source(store, raw, members, origin='historical_byte_preserving_import',
                       note=provenance_note, source_input_sha256=sha(raw))


def inspect(store, target, version):
    directory = folder(store, target, version)
    record = read(directory / 'release.json')
    raw, members, _, _ = read_archive(directory / 'project.pcwex')
    actual_target, actual_version, address, gateway = identity(members, store)
    if (actual_target != target or actual_version != version or record['target'] != target
            or record['version'] != version or record['project_sha256'] != sha(raw)
            or record['address'] != address or record['gateway_id'] != gateway):
        raise ProjectError('Release archive/identity hash mismatch.')
    return {**record, 'release_directory': str(directory),
            'package_registered': (directory / 'package.json').is_file(),
            'blocked': any((directory / 'blocks').glob('*.json'))}


def block_release(store, target, version, reason):
    record = inspect(store, target, version)
    if not isinstance(reason, str) or not reason.strip() or len(reason) > 2000:
        raise ProjectError('A bounded release blocking reason is required.')
    decision = {'blocked_utc': now(), 'reason': reason, 'project_sha256': record['project_sha256'],
                'target': target, 'version': version, 'device_action_performed': False}
    path = folder(store, target, version) / 'blocks' / (uuid.uuid4().hex + '.json')
    write_new(path, decision)
    return {**decision, 'block_record': str(path), 'blocked': True}


def bind_package(store, project_id, expected_project_sha256, package_job_id):
    from .controller_download_plan import _binding
    directory = store._folder(project_id)
    with store._lock(directory):
        managed_folder, _, binding, files = _binding(store, project_id, expected_project_sha256, package_job_id)
        _, _, members, _, _ = store._current(project_id)
        target, version, _, _ = identity(members, store)
        release = inspect(store, target, version)
        if release['blocked']:
            raise ProjectError('Release is blocked; prepare a corrected new dev version.')
        if release['project_sha256'] != expected_project_sha256:
            raise ProjectError('Compile must use the exact registered, version-stamped project.')
        destination = folder(store, target, version)
        from .deployment_plan import _file
        receipts = {}
        for name, relative, expected in (
            ('build-receipt.json', 'builds/' + binding['package']['build_job_id'] + '/result.json',
             binding['package']['build_receipt_sha256']),
            ('package-receipt.json', 'deployments/' + package_job_id + '/result.json',
             binding['package']['package_receipt_sha256']),
        ):
            payload = _file(managed_folder, relative).read_bytes()
            if sha(payload) != expected:
                raise ProjectError('Build/package receipt hash mismatch.')
            receipts[name] = payload
        with endpoint_guard(destination / 'package-registration'):
            record = {'schema': 'plcnext-release-package/v1', 'project_sha256': expected_project_sha256,
                      'package': binding['package'], 'files': binding['files']}
            path = destination / 'package.json'
            if path.exists():
                if read(path) != record:
                    raise ProjectError('This version already has another binary package; prepare a new dev version.')
            else:
                package_dir = destination / 'PCWE'
                # An interrupted registration is preserved and blocks reuse.
                package_dir.mkdir(exist_ok=False)
                for name, payload in files.items():
                    file = _file(package_dir, name)
                    file.parent.mkdir(parents=True, exist_ok=True)
                    with file.open('xb') as stream:
                        stream.write(payload); stream.flush(); os.fsync(stream.fileno())
                write_new(path, record)
            for name, payload in receipts.items():
                receipt_path = destination / name
                if receipt_path.exists():
                    if receipt_path.read_bytes() != payload:
                        raise ProjectError('Frozen build/package receipt changed.')
                else:
                    with receipt_path.open('xb') as stream:
                        stream.write(payload); stream.flush(); os.fsync(stream.fileno())
        return {**inspect(store, target, version), 'package': record['package']}


def require_release(store, plan):
    source_hash = plan['source']['project_sha256']
    _, manifest, members, _, _ = store._current(plan['project_id'])
    target, version, address, _ = identity(members, store)
    record = inspect(store, target, version)
    if record['blocked']:
        raise ProjectError('Release is blocked and cannot be downloaded or recovered.')
    if (manifest['current_sha256'] != source_hash or record['project_sha256'] != source_hash
            or plan['target']['address'] != address):
        raise ProjectError('Release source/target mismatch; no device action allowed.')
    if '-dev.' not in version and record['origin'] != 'historical_byte_preserving_import':
        raise ProjectError('Modified source must use a dev release.')
    directory = folder(store, target, version)
    package = read(directory / 'package.json')
    if (package['project_sha256'] != source_hash or package['package'] != plan['package']
            or package['files'] != plan['files']):
        raise ProjectError('Release package binding mismatch; no device action allowed.')
    for name, key in (('build-receipt.json', 'build_receipt_sha256'),
                      ('package-receipt.json', 'package_receipt_sha256')):
        if sha((directory / name).read_bytes()) != package['package'][key]:
            raise ProjectError('Release build/package receipt changed.')
    from .deployment_plan import _file
    for file in package['files']:
        path = _file(directory / 'PCWE', file['path'])
        if path.stat().st_size != file['bytes'] or sha(path.read_bytes()) != file['sha256']:
            raise ProjectError('Frozen release package bytes changed.')
    return record


def release_operation(load_plan):
    """Guard all real downloads/recoveries, including background worker routes."""
    def decorate(function):
        @functools.wraps(function)
        def wrapped(store, project_id, selector, expected, **kwargs):
            plan = load_plan(store, project_id, selector, expected)
            if ipaddress.ip_address(plan['target']['address']).is_loopback:
                return function(store, project_id, selector, expected, **kwargs)
            release = require_release(store, plan)
            attempt = uuid.uuid4().hex
            directory = folder(store, release['target'], release['version']) / 'deployments' / attempt
            # Must durably record intent BEFORE calling anything that can Stop/write.
            write_new(directory / 'started.json', {
                'schema': 'plcnext-release-attempt/v1', 'attempt_id': attempt, 'started_utc': now(),
                'project_id': project_id, 'review_id': selector, 'review_sha256': expected,
                'project_sha256': release['project_sha256'], 'version': release['version'],
                'target': plan['target'], 'package': plan['package'],
                'operation': function.__name__, 'status': 'pending_outcome_unknown',
                'before_observation': plan.get('historical_observation'),
                'current_device_version_verified': False})
            try:
                result = function(store, project_id, selector, expected, **kwargs)
            except BaseException as exc:
                write_new(directory / 'terminal.json', {'status': 'interrupted_outcome_unknown',
                          'finished_utc': now(), 'error_class': type(exc).__name__,
                          'automatic_retry_allowed': False, 'current_device_version_verified': False})
                raise
            receipt = result.get('report_path')
            receipt_hash = sha(Path(receipt).read_bytes()) if receipt and Path(receipt).is_file() else None
            write_new(directory / 'terminal.json', {'status': 'operation_returned', 'finished_utc': now(),
                      'automatic_retry_allowed': False, 'current_device_version_verified': False,
                      'result': {key: result[key] for key in (
                          'status', 'stage', 'execution_id', 'controller_downloaded', 'program_started',
                          'outcome_unknown', 'failure_code', 'report_path', 'receipt_persisted', 'replayed',
                          'load_state_verified', 'endpoint_lease_retained') if key in result},
                      'execution_receipt_sha256': receipt_hash})
            return {**result, 'release_attempt_id': attempt, 'release_version': release['version'],
                    'release_attempt_directory': str(directory)}
        return wrapped
    return decorate


def inventory(store, target=None):
    if target is not None and target not in hardware_types():
        raise ProjectError('Unsupported release target.')
    records = []
    for hardware in ([target] if target else hardware_types()):
        parent = root(store) / hardware
        if not parent.exists():
            continue
        for entry in sorted(parent.iterdir()):
            if not entry.is_dir():
                continue
            record = inspect(store, hardware, entry.name)
            attempts = []
            for started in sorted(entry.glob('deployments/*/started.json')):
                terminal = started.parent / 'terminal.json'
                attempts.append({'started': read(started), 'terminal': read(terminal) if terminal.exists() else None,
                                 'status': 'recorded' if terminal.exists() else 'pending_outcome_unknown'})
            records.append({**record, 'deployment_attempts': attempts,
                            'blocks': [read(p) for p in sorted((entry / 'blocks').glob('*.json'))]})
    return {'schema': 'plcnext-release-inventory/v1', 'release_root': str(root(store)),
            'releases': records, 'device_version_requires_runtime_observation': True}
