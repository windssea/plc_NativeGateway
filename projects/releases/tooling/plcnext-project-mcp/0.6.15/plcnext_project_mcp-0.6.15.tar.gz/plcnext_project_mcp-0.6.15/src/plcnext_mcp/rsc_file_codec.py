"""Bounded raw file-service value codecs verified against the vendor formatter.

These are untagged value bodies for remoting versions 3..5. They are not RSC
RPC message: provider/service handles, header, authentication and transport are
outside this module. Only Permissions TraitItem values and seekable in-memory
streams are admitted. Other traits and stream encodings fail explicitly.
"""
from __future__ import annotations

import struct

from .project import ProjectError

MAX_FILES = 4096
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_BODY_BYTES = 128 * 1024 * 1024
MAX_PATH_BYTES = 511


def _require(condition, message):
    if not condition:
        raise ProjectError('RSC file value codec: ' + message)


def _version(version):
    _require(type(version) is int and version in (3, 4, 5), 'only untagged versions 3, 4 and 5 are supported.')


def _path(path, *, allow_empty=False):
    _require(isinstance(path, str) and (path or allow_empty) and '\x00' not in path, 'invalid path string.')
    try:
        encoded = path.encode('utf-8')
    except UnicodeError as exc:
        raise ProjectError('RSC file value codec: invalid UTF-8 path.') from exc
    _require(len(encoded) <= MAX_PATH_BYTES, 'path exceeds this codec\'s bounded UTF-8 profile.')
    return struct.pack('<H', len(encoded) + 1) + encoded + b'\x00'


def encode_write_many(files: list[dict], version: int = 3) -> bytes:
    """Encode canonical path/overwrite/traits/data dictionaries without networking.

    traits is [] or [{'trait': 1, 'value': POSIX_PERMISSION_BITS}]. data must be
    exact bytes. The service's annotation permits at most 512 string elements;
    this codec conservatively limits the entire UTF-8 path plus NUL to 512 bytes.
    """
    _version(version)
    _require(type(files) is list and len(files) <= MAX_FILES, 'invalid file array.')
    parts = [struct.pack('<i', len(files))]
    size = 4
    for file in files:
        _require(type(file) is dict and set(file) == {'path', 'overwrite', 'traits', 'data'}, 'invalid file fields.')
        _require(type(file['overwrite']) is bool, 'overwrite must be Boolean.')
        _require(type(file['data']) is bytes and len(file['data']) <= MAX_FILE_BYTES, 'invalid or oversized stream payload.')
        traits = file['traits']
        _require(type(traits) is list and len(traits) <= 1, 'only one optional Permissions trait is supported.')
        chunks = [_path(file['path']), bytes([file['overwrite']]), struct.pack('<i', len(traits))]
        for trait in traits:
            _require(type(trait) is dict and set(trait) == {'trait', 'value'} and
                     type(trait['trait']) is int and trait['trait'] == 1 and
                     type(trait['value']) is int and 0 <= trait['value'] <= 0o777,
                     'unsupported trait or permission bits.')
            # Trait is an enum (Int32); boxed Permissions emits an Int32 tag even
            # when the surrounding value body does not use general data tagging.
            chunks.append(struct.pack('<iBi', 1, 8, trait['value']))
        data = file['data']
        chunks.append(struct.pack('<i', len(data)))
        if data:
            chunks.extend([struct.pack('<i', len(data)), data])
        chunks.append(struct.pack('<i', -1))
        item = b''.join(chunks)
        size += len(item)
        _require(size <= MAX_BODY_BYTES, 'value body exceeds size limit.')
        parts.append(item)
    return b''.join(parts)


class _Reader:
    def __init__(self, data):
        _require(type(data) is bytes and len(data) <= MAX_BODY_BYTES, 'invalid or oversized value body.')
        self.data, self.position = data, 0

    def take(self, count):
        _require(type(count) is int and count >= 0 and self.position + count <= len(self.data), 'truncated value body.')
        result = self.data[self.position:self.position + count]
        self.position += count
        return result

    def integer(self):
        return struct.unpack('<i', self.take(4))[0]


def decode_write_many(payload: bytes, version: int = 3) -> list[dict]:
    """Decode only this module's bounded, seekable-stream value profile."""
    _version(version)
    reader = _Reader(payload)
    count = reader.integer()
    _require(0 <= count <= MAX_FILES, 'invalid file count.')
    files = []
    for _ in range(count):
        length = struct.unpack('<H', reader.take(2))[0]
        _require(1 <= length <= MAX_PATH_BYTES + 1, 'invalid path length.')
        raw_path = reader.take(length)
        _require(raw_path[-1:] == b'\x00' and b'\x00' not in raw_path[:-1], 'invalid path terminator.')
        try:
            path = raw_path[:-1].decode('utf-8')
        except UnicodeError as exc:
            raise ProjectError('RSC file value codec: invalid UTF-8 path.') from exc
        _path(path)
        overwrite = reader.take(1)[0]
        _require(overwrite in (0, 1), 'invalid Boolean encoding.')
        trait_count = reader.integer()
        _require(trait_count in (0, 1), 'unsupported trait count.')
        traits = []
        for _ in range(trait_count):
            trait = reader.integer()
            tag = reader.take(1)[0]
            value = reader.integer()
            _require(trait == 1 and tag == 8 and 0 <= value <= 0o777, 'unsupported trait/value encoding.')
            traits.append({'trait': trait, 'value': value})
        total = reader.integer()
        _require(0 <= total <= MAX_FILE_BYTES, 'unsupported stream length.')
        data = b''
        if total:
            _require(reader.integer() == total, 'only the verified seekable-stream framing is supported.')
            data = reader.take(total)
        _require(reader.integer() == -1, 'missing stream terminator.')
        files.append({'path': path, 'overwrite': bool(overwrite), 'traits': traits, 'data': data})
    _require(reader.position == len(payload), 'trailing value bytes.')
    return files


def _finish(reader):
    _require(reader.position == len(reader.data), 'trailing value bytes.')


def _string(reader, *, allow_empty=False):
    length = struct.unpack('<H', reader.take(2))[0]
    _require(1 <= length <= MAX_PATH_BYTES + 1, 'invalid path length.')
    raw = reader.take(length)
    _require(raw[-1:] == b'\x00' and b'\x00' not in raw[:-1], 'invalid path terminator.')
    try:
        path = raw[:-1].decode('utf-8')
    except UnicodeError as exc:
        raise ProjectError('RSC file value codec: invalid UTF-8 path.') from exc
    _path(path, allow_empty=allow_empty)
    return path


def _boolean(reader):
    value = reader.take(1)[0]
    _require(value in (0, 1), 'invalid Boolean encoding.')
    return bool(value)


def _traits_mask(value):
    _require(type(value) is int and 0 <= value <= 31, 'unsupported Traits mask.')
    return struct.pack('<i', value)


def _error(value):
    _require(type(value) is int and 0 <= value <= 6, 'unsupported FileSystemError.')
    return struct.pack('<i', value)


def _traits_bytes(traits):
    _require(type(traits) is list and len(traits) <= 1, 'only one optional Permissions trait is supported.')
    parts = [struct.pack('<i', len(traits))]
    for item in traits:
        _require(type(item) is dict and set(item) == {'trait', 'value'} and
                 type(item['trait']) is int and item['trait'] == 1 and
                 type(item['value']) is int and 0 <= item['value'] <= 0o777,
                 'unsupported trait or permission bits.')
        parts.append(struct.pack('<iBi', 1, 8, item['value']))
    return b''.join(parts)


def _read_traits(reader):
    count = reader.integer()
    _require(count in (0, 1), 'unsupported trait count.')
    items = []
    for _ in range(count):
        trait, tag, value = reader.integer(), reader.take(1)[0], reader.integer()
        _require(trait == 1 and tag == 8 and 0 <= value <= 0o777, 'unsupported trait/value encoding.')
        items.append({'trait': trait, 'value': value})
    return items


def _stream_bytes(data):
    _require(type(data) is bytes and len(data) <= MAX_FILE_BYTES, 'invalid or oversized stream payload.')
    return struct.pack('<i', len(data)) + (struct.pack('<i', len(data)) + data if data else b'') + struct.pack('<i', -1)


def _read_stream(reader):
    count = reader.integer()
    _require(0 <= count <= MAX_FILE_BYTES, 'unsupported stream length.')
    data = b''
    if count:
        _require(reader.integer() == count, 'only the verified seekable-stream framing is supported.')
        data = reader.take(count)
    _require(reader.integer() == -1, 'missing stream terminator.')
    return data


def encode_read_many_request(files: list[dict], version: int = 3) -> bytes:
    """IFileService2.ReadMany method 9: ReadFileInfo[] input values."""
    _version(version)
    _require(type(files) is list and len(files) <= MAX_FILES, 'invalid read-file array.')
    parts = [struct.pack('<i', len(files))]
    for item in files:
        _require(type(item) is dict and set(item) == {'path', 'traits'}, 'invalid ReadFileInfo fields.')
        parts.extend([_path(item['path']), _traits_mask(item['traits'])])
    return b''.join(parts)


def decode_read_many_request(payload: bytes, version: int = 3) -> list[dict]:
    _version(version)
    reader = _Reader(payload)
    count = reader.integer()
    _require(0 <= count <= MAX_FILES, 'invalid read-file count.')
    files = []
    for _ in range(count):
        path, mask = _string(reader), reader.integer()
        _traits_mask(mask)
        files.append({'path': path, 'traits': mask})
    _finish(reader)
    return files


def encode_read_many_response(files: list[dict], version: int = 3) -> bytes:
    """ReadMany's sole out ReadFileData[]; return type is void."""
    _version(version)
    _require(type(files) is list and len(files) <= MAX_FILES, 'invalid read-result array.')
    parts, size = [struct.pack('<i', len(files))], 4
    for item in files:
        _require(type(item) is dict and set(item) == {'result', 'traits', 'data'}, 'invalid ReadFileData fields.')
        data = _error(item['result']) + _traits_bytes(item['traits']) + _stream_bytes(item['data'])
        size += len(data)
        _require(size <= MAX_BODY_BYTES, 'value body exceeds size limit.')
        parts.append(data)
    return b''.join(parts)


def decode_read_many_response(payload: bytes, version: int = 3) -> list[dict]:
    _version(version)
    reader = _Reader(payload)
    count = reader.integer()
    _require(0 <= count <= MAX_FILES, 'invalid read-result count.')
    files = []
    for _ in range(count):
        result = reader.integer()
        _error(result)
        files.append({'result': result, 'traits': _read_traits(reader), 'data': _read_stream(reader)})
    _finish(reader)
    return files


def encode_file_errors(results: list[int], version: int = 3) -> bytes:
    """WriteMany's FileSystemError[] return value."""
    _version(version)
    _require(type(results) is list and len(results) <= MAX_FILES, 'invalid error array.')
    return struct.pack('<i', len(results)) + b''.join(_error(value) for value in results)


def decode_file_errors(payload: bytes, version: int = 3) -> list[int]:
    _version(version)
    reader = _Reader(payload)
    count = reader.integer()
    _require(0 <= count <= MAX_FILES, 'invalid error count.')
    results = []
    for _ in range(count):
        value = reader.integer()
        _error(value)
        results.append(value)
    _finish(reader)
    return results


def encode_supported_traits_response(traits: int, version: int = 3) -> bytes:
    _version(version)
    return _traits_mask(traits)


def decode_supported_traits_response(payload: bytes, version: int = 3) -> int:
    _version(version)
    reader = _Reader(payload)
    value = reader.integer()
    _traits_mask(value)
    _finish(reader)
    return value


def encode_traits_entry_request(path: str, traits: int = 0, version: int = 3) -> bytes:
    _version(version)
    return _traits_mask(traits) + _path(path)


def decode_traits_entry_request(payload: bytes, version: int = 3) -> dict:
    _version(version)
    reader = _Reader(payload)
    traits = reader.integer()
    _traits_mask(traits)
    path = _string(reader)
    _finish(reader)
    return {'path': path, 'traits': traits}


def encode_traits_entry_response(entry: dict, result: int = 0, version: int = 3) -> bytes:
    """Out FileSystemTraitsEntry first, then FileSystemError return value."""
    _version(version)
    _require(type(entry) is dict and set(entry) == {'path', 'is_file', 'is_directory', 'traits'}, 'invalid traits-entry fields.')
    _require(type(entry['is_file']) is bool and type(entry['is_directory']) is bool, 'invalid entry flags.')
    return (_path(entry['path'], allow_empty=True) + bytes([entry['is_file'], entry['is_directory']]) +
            _traits_bytes(entry['traits']) + _error(result))


def decode_traits_entry_response(payload: bytes, version: int = 3) -> dict:
    _version(version)
    reader = _Reader(payload)
    entry = {'path': _string(reader, allow_empty=True), 'is_file': _boolean(reader),
             'is_directory': _boolean(reader), 'traits': _read_traits(reader)}
    result = reader.integer()
    _error(result)
    _finish(reader)
    return {'entry': entry, 'result': result}


def encode_space_request(path: str, version: int = 3) -> bytes:
    _version(version)
    return _path(path)


def decode_space_request(payload: bytes, version: int = 3) -> str:
    _version(version)
    reader = _Reader(payload)
    value = _string(reader)
    _finish(reader)
    return value


def encode_space_response(space: dict, result: int = 0, version: int = 3) -> bytes:
    """Out SpaceInfo (Capacity, Free, Available UInt64), then result Int32."""
    _version(version)
    _require(type(space) is dict and set(space) == {'capacity', 'free', 'available'} and
             all(type(v) is int and 0 <= v < 2**64 for v in space.values()), 'invalid SpaceInfo fields.')
    return struct.pack('<QQQ', space['capacity'], space['free'], space['available']) + _error(result)


def decode_space_response(payload: bytes, version: int = 3) -> dict:
    _version(version)
    reader = _Reader(payload)
    values = struct.unpack('<QQQ', reader.take(24))
    result = reader.integer()
    _error(result)
    _finish(reader)
    return {'space': dict(zip(('capacity', 'free', 'available'), values)), 'result': result}
