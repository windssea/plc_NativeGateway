"""Schema-bounded RSC v4 tagged download calls over persistent MemoryBIO TLS.

Only the recovered tagged value schemas are admitted. Both peers are local
SSLObjects, service handles are negotiated dynamically, and no socket or real
controller endpoint exists. This is separate from the legacy untagged loopback.
"""
from __future__ import annotations

import hashlib
import secrets

from . import rsc_tagged_codec as tagged
from .download_services import FileSystemError, InMemoryController, ServiceFailure, WriteFileData, device_state
from .offline_tls import MemoryTlsPair
from .rsc_codec import (CommandHeader, CommandType, DATA_TAGGING, DATAGRAMMING, SECURE,
                        decode_header, encode_header)

PROVIDER = 'Arp'
PASSWORD_SERVICE = 'Arp.System.Security.Services.IPasswordAuthenticationService'
FILE_SERVICE = 'Arp.System.Commons.Services.Io.IFileService2'
FS_SERVICE = 'Arp.System.Commons.Services.Io.IFileSystemInfoService'
PLC_SERVICE = 'Arp.Plc.Domain.Services.IPlcManagerService'
SERVICES = (PASSWORD_SERVICE, FILE_SERVICE, FS_SERVICE, PLC_SERVICE)
SCHEMAS = {
    (PASSWORD_SERVICE, 1): (['utf8', 'secure_utf8'], ['security_token', 'int32', 'int32']),
    (PASSWORD_SERVICE, 2): (['security_token'], []),
    (FILE_SERVICE, 8): (['write_file[]'], ['int32[]']),
    (FILE_SERVICE, 9): (['read_file_info[]'], ['read_file_data[]']),
    (FS_SERVICE, 1): ([], ['int32']),
    (FS_SERVICE, 5): (['int32', 'utf8'], ['filesystem_traits_entry', 'int32']),
    (FS_SERVICE, 6): (['utf8'], ['space_info', 'int32']),
    (PLC_SERVICE, 1): (['bool'], []),
    (PLC_SERVICE, 4): (['bool'], []),
    (PLC_SERVICE, 5): ([], ['uint32']),
}


class _TaggedPolicyController(InMemoryController):
    """Reuse local filesystem/state policies with tagged-only internal checks."""
    def _check_header(self, token):
        packet = encode_header(CommandHeader(flags=DATA_TAGGING), token)
        header, decoded = decode_header(packet, require_checksum=True)
        if decoded != token or header.flags & ~SECURE != DATA_TAGGING:
            raise ServiceFailure('invalid_header', 'Offline tagged security header roundtrip failed.')
        self.header_roundtrips += 1

    def write_many(self, entries):
        self._authorize()
        canonical = [{'path': entry.file_path, 'overwrite': entry.overwrite,
                      'traits': [{'trait': 1, 'value': entry.permissions}] if self.supported_traits & 1 else [],
                      'data': entry.data} for entry in entries]
        encoded = tagged.encode_values(['write_file[]'], [canonical])
        decoded = tagged.decode_values(encoded, ['write_file[]'])[0]
        if decoded != canonical:
            raise ServiceFailure('file_value_codec_failed', 'Offline tagged file DTO roundtrip changed a value.')
        entries = [WriteFileData(item['path'], item['data'], item['overwrite'],
                                 item['traits'][0]['value'] if item['traits'] else 0) for item in decoded]
        self.file_value_roundtrips += 1
        self._write_calls += 1
        self.record('IFileService2.WriteMany', file_count=len(entries),
                    payload_bytes=sum(len(entry.data) for entry in entries),
                    value_encoding='observed tagged v4 WriteFileData[] with invocation FF',
                    encoded_bytes=len(encoded), encoded_sha256=hashlib.sha256(encoded).hexdigest(),
                    complete_rsc_rpc=False)
        if self.fault == 'session_expired':
            self._authenticated = False
            raise ServiceFailure('session_expired', 'Offline session expired before tagged file writes.')
        if self.fault == 'transport_interrupted':
            if entries:
                entry = entries[0]
                self._files[self._path(entry.file_path)] = entry.data
            raise ServiceFailure('transport_interrupted', 'Offline reply lost after a possible tagged file write.')
        results = []
        for index, entry in enumerate(entries):
            relative = self._path(entry.file_path)
            error = (FileSystemError.ACCESS_DENIED if self.fault == 'write_error' and index == 0 else
                     FileSystemError.ACCESS_DENIED if self.fault == 'permission_denied' else
                     FileSystemError.ALREADY_EXISTS if relative in self._files and not entry.overwrite else
                     FileSystemError.NONE)
            if error == FileSystemError.NONE:
                self._files[relative] = entry.data
                self._permissions[relative] = entry.permissions
            results.append(error)
        return results[:-1] if self.fault == 'short_results' else results


class TaggedBinaryLoopbackController:
    """Download service facade whose actual memory TLS wire is tagged RSC v4."""
    protocol_profile = 'v4_tagged'

    def __init__(self, fault='none', *, token_value=None):
        self._backend = _TaggedPolicyController(fault, token_value=token_value)
        self._pair = None
        self._connected = False
        self._closed = False
        self._client_token = None
        self._client_handles = {}
        self._server_handles = {}
        self._provider_handle = secrets.randbelow(20000) + 1
        self._next_handle = secrets.randbelow(10000) + 1
        self.rpc_exchanges = 0
        self.rpc_completed = 0
        self.rpc_cleanup_confirmed = False
        self.tagged_invocations = 0
        self.tagged_discoveries = 0

    def __getattr__(self, name):
        return getattr(self._backend, name)

    @property
    def loaded(self):
        return self._backend.loaded

    @loaded.setter
    def loaded(self, value):
        self._backend.loaded = value

    def check_peer_policy(self):
        if self._closed:
            raise ServiceFailure('session_closed', 'Offline tagged session is already disposed.')
        fault = self.fault if self.fault in ('untrusted_peer', 'hostname_mismatch') else 'none'
        self._pair = MemoryTlsPair(fault)
        self._backend.tls_report = dict(self._pair.report)
        self.record('Simulator.MemoryTlsHandshake', protocol_profile=self.protocol_profile, **self.tls_report)
        if not self.tls_report['passed']:
            raise ServiceFailure('peer_not_trusted', 'Memory TLS rejected the offline tagged peer certificate.')
        # Common Connect advertises both capabilities. The peer must select only
        # data tagging; no datagram profile or untagged fallback is accepted.
        connect = encode_header(CommandHeader(flags=DATA_TAGGING | DATAGRAMMING,
                                               command_type=CommandType.CONNECT_REQUEST))
        tagged.decode_connect_confirmation(self._exchange(connect))
        self._connected = True
        for service in SERVICES:
            handle, provider = tagged.decode_get_service_confirmation(
                self._exchange(tagged.encode_get_service(PROVIDER, service)))
            if provider != self._provider_handle or handle <= 0 or handle in self._client_handles.values():
                raise ServiceFailure('service_negotiation_failed', 'Invalid tagged service discovery response.')
            self._client_handles[service] = handle

    def _exchange(self, packet):
        if self._closed or self._pair is None:
            raise ServiceFailure('tls_not_ready', 'Offline tagged TLS is not initialized.')
        self.rpc_exchanges += 1
        answer = self._pair.exchange(packet, self._dispatch)
        self._backend.tls_report = dict(self._pair.report)
        self.rpc_completed += 1
        return answer

    @staticmethod
    def _header(packet):
        if type(packet) is not bytes or len(packet) < 16:
            raise ServiceFailure('rpc_truncated', 'Offline tagged request header is truncated.')
        size = 20 if packet[1] & SECURE else 16
        return decode_header(packet[:size], require_checksum=True)

    def _call(self, service, method, values, *, token_override=False):
        if not self._connected or service not in self._client_handles:
            raise ServiceFailure('service_not_ready', 'Tagged service negotiation is incomplete.')
        schemas = SCHEMAS.get((service, method))
        if schemas is None:
            raise ServiceFailure('rpc_method_unknown', 'Tagged method schema has not been recovered.')
        request_schema, response_schema = schemas
        packet = tagged.encode_request(self._client_handles[service], method, request_schema, values,
            token=None if token_override else self._client_token, provider_handle=self._provider_handle)
        answer = self._exchange(packet)
        header, token, result = tagged.decode_response(answer, response_schema)
        if (token is not None or header.service_handle != self._client_handles[service]
                or header.method_handle != method or header.service_provider_handle != self._provider_handle):
            raise ServiceFailure('rpc_response_mismatch', 'Tagged response header does not match its request.')
        return result

    def _dispatch(self, packet):
        if self._closed:
            raise ServiceFailure('session_closed', 'Offline tagged session is already disposed.')
        header, token = self._header(packet)
        if header.command_type == CommandType.CONNECT_REQUEST:
            if self._connected or token is not None or len(packet) != 16 or header.version != 4 or (
                    header.flags != DATA_TAGGING | DATAGRAMMING or any((header.data_length,
                    header.service_handle, header.method_handle, header.service_provider_handle))):
                raise ServiceFailure('rpc_state', 'Unsupported or duplicate tagged connect request.')
            self.record('Simulator.RscConnect', selected_version=4, data_tagging=True, datagramming=False)
            return tagged.encode_connect_confirmation()
        if header.command_type == CommandType.GET_SERVICE_HANDLES_REQUEST:
            if not self._connected:
                raise ServiceFailure('rpc_state', 'Tagged discovery preceded connect confirmation.')
            provider, service = tagged.decode_get_service(packet)
            if provider != PROVIDER or service not in SERVICES:
                raise ServiceFailure('service_unknown', 'Unknown tagged service discovery name.')
            if service not in self._server_handles:
                self._server_handles[service] = self._next_handle
                self._next_handle += 1
            self.tagged_discoveries += 1
            self.record('Simulator.RscGetServiceHandles', provider=provider, service=service,
                        data_tagging=True, raw_name_encoding=True)
            return tagged.encode_get_service_confirmation(self._server_handles[service], self._provider_handle)
        if not self._connected or header.service_provider_handle != self._provider_handle:
            raise ServiceFailure('rpc_provider_unknown', 'Unknown tagged provider handle.')
        service = next((name for name, value in self._server_handles.items() if value == header.service_handle), None)
        if service is None:
            raise ServiceFailure('rpc_service_unknown', 'Unknown tagged service handle.')
        schemas = SCHEMAS.get((service, header.method_handle))
        if schemas is None:
            raise ServiceFailure('rpc_method_unknown', 'Unsupported tagged method schema.')
        header, token, values = tagged.decode_request(packet, schemas[0])
        if service != PASSWORD_SERVICE and (token is None or token != self._backend._token):
            raise ServiceFailure('session_invalid', 'Tagged request carries no valid offline session token.')
        self.tagged_invocations += 1
        self.record('Simulator.RscTaggedInvoke', service=service, method_id=header.method_handle,
                    data_tagging=True, authenticated_header=token is not None,
                    argument_bytes=len(packet) - (20 if token is not None else 16),
                    invocation_end_marker_verified=True)
        result = self._invoke(service, header.method_handle, values)
        return tagged.encode_response(header.service_handle, header.method_handle, schemas[1], result,
                                      provider_handle=header.service_provider_handle)

    def _invoke(self, service, method, values):
        if service == PASSWORD_SERVICE:
            if method == 1:
                username, password = values
                error, token, penalty = self._backend.create_session(username, password)
                password = None
                if token is None and int(error) == 0:
                    raise ServiceFailure('session_invalid', 'Authentication returned no offline security token.')
                # Boxed UInt32(0) on failure is this simulator's explicit choice,
                # not a claim about a particular firmware failure payload.
                return [0 if token is None else token, penalty, int(error)]
            if method == 2:
                if values[0] != self._backend._token:
                    raise ServiceFailure('session_invalid', 'Tagged CloseSession token mismatch.')
                self._backend.close()
                return []
        elif service == FILE_SERVICE:
            if method == 8:
                entries = [WriteFileData(item['path'], item['data'], item['overwrite'],
                    item['traits'][0]['value'] if item['traits'] else 0) for item in values[0]]
                return [[int(error) for error in self._backend.write_many(entries)]]
            if method == 9:
                results = self._backend.read_many([item['path'] for item in values[0]])
                return [[{'result': int(error), 'traits': [], 'data': data} for error, data in results]]
        elif service == FS_SERVICE:
            if method == 1:
                self._backend._authorize()
                self.record('IFileSystemInfoService.GetSupportedTraits', traits=self.supported_traits)
                return [self.supported_traits]
            if method == 5:
                traits, path = values
                if traits != 0 or path != '$ARP_PROJECTS_DIR$/PCWE/':
                    raise ServiceFailure('unsafe_remote_path', 'Unexpected tagged symbolic project-root query.')
                error, root = self._backend.resolve_project_root()
                return [{'path': root, 'is_file': False, 'is_directory': True, 'traits': []}, int(error)]
            if method == 6:
                if values[0] != self.root:
                    raise ServiceFailure('unsafe_remote_path', 'Unexpected tagged free-space path.')
                free = self._backend.get_space()
                return [{'capacity': 2 * 1024**3, 'free': free, 'available': free}, 0]
        elif service == PLC_SERVICE:
            if method == 5:
                self._backend.get_state()
                return [self._backend.trace[-1]['raw']]
            if method == 4:
                self._backend.reset(async_=values[0])
                return []
            if method == 1:
                self._backend.load(async_=values[0])
                return []
        raise ServiceFailure('rpc_method_unknown', 'Unsupported tagged invocation.')

    def create_session(self, username, password):
        token, penalty, error = self._call(PASSWORD_SERVICE, 1, [username, password], token_override=True)
        return error, token, penalty

    def enable_security(self, token):
        self._backend.enable_security(token)
        self._client_token = token

    def get_permissions(self):
        # Explicit application policy double, not a recovered permission RPC.
        return self._backend.get_permissions()

    def resolve_project_root(self):
        entry, error = self._call(FS_SERVICE, 5, [0, '$ARP_PROJECTS_DIR$/PCWE/'])
        if not entry['is_directory'] or entry['is_file']:
            raise ServiceFailure('path_resolution_failed', 'Tagged root result is not a directory.')
        return FileSystemError(error), entry['path']

    def get_space(self):
        space, error = self._call(FS_SERVICE, 6, [self.root])
        if error != 0:
            raise ServiceFailure('space_query_failed', 'Tagged free-space query failed.')
        return space['available']

    def write_many(self, entries):
        supported = self._call(FS_SERVICE, 1, [])[0]
        values = [{'path': entry.file_path, 'overwrite': entry.overwrite,
                   'traits': [{'trait': 1, 'value': entry.permissions}] if supported & 1 else [],
                   'data': entry.data} for entry in entries]
        return [FileSystemError(error) for error in self._call(FILE_SERVICE, 8, [values])[0]]

    def read_many(self, paths):
        request = [{'path': path, 'traits': 0} for path in paths]
        values = self._call(FILE_SERVICE, 9, [request])[0]
        return [(FileSystemError(item['result']), item['data']) for item in values]

    def get_state(self):
        return device_state(self._call(PLC_SERVICE, 5, [])[0])

    def reset(self, async_=True):
        self._call(PLC_SERVICE, 4, [async_])

    def load(self, async_=True):
        self._call(PLC_SERVICE, 1, [async_])

    def advance(self, milliseconds):
        self._backend.advance(milliseconds)

    def snapshot(self):
        return self._backend.snapshot()

    def reconcile(self, files):
        # No directory-discovery/deletion wire methods are claimed.
        return self._backend.reconcile(files)

    def close(self):
        if self._closed:
            return
        token = self._client_token
        self._client_token = None
        try:
            if token is not None and self._connected:
                result = self._call(PASSWORD_SERVICE, 2, [token], token_override=True)
                if result:
                    raise ServiceFailure('rpc_extra_data', 'Unexpected tagged CloseSession return values.')
                self.rpc_cleanup_confirmed = True
        finally:
            try:
                if not self._backend.session_closed:
                    self._backend.close()
            finally:
                self._closed = True
                self._connected = False
                self._client_handles.clear()
                self._server_handles.clear()
                self._pair = None
