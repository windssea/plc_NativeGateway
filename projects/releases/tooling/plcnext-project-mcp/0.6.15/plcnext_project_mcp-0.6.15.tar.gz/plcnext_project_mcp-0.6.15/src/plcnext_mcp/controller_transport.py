"""Independent pinned TLS/TCP client for the measured tagged RSC profile.

There is no ACI, Engineer process, retry, arbitrary RPC or trust-on-first-use.
Read-only is the default. Mutations require either a literal-loopback fixture
scope or a separately issued operator approval, never a review ID alone.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import hmac
import ipaddress
import json
from pathlib import Path
import socket
import ssl
import time
import uuid

from . import rsc_tagged_codec as tagged
from .deployment_package import _relative_path, MANIFEST
from .project import ProjectError
from .rsc_codec import CommandType, DATA_TAGGING, decode_header
from .rsc_error_codec import receive_error
from .rsc_rpc_codec import encode_connect_request

PROVIDER = 'Arp'
PASSWORD = 'Arp.System.Security.Services.IPasswordAuthenticationService'
FILE = 'Arp.System.Commons.Services.Io.IFileService2'
FILESYSTEM = 'Arp.System.Commons.Services.Io.IFileSystemInfoService'
PLC = 'Arp.Plc.Domain.Services.IPlcManagerService'
SCHEMAS = {
    (PASSWORD, 1): (['utf8', 'secure_utf8'], ['security_token', 'int32', 'int32']),
    (PASSWORD, 2): (['security_token'], []),
    (FILE, 8): (['write_file[]'], ['int32[]']),
    (FILE, 9): (['read_file_info[]'], ['read_file_data[]']),
    (FILESYSTEM, 1): ([], ['int32']),
    (FILESYSTEM, 5): (['int32', 'utf8'], ['filesystem_traits_entry', 'int32']),
    (FILESYSTEM, 6): (['utf8'], ['space_info', 'int32']),
    (PLC, 1): (['bool'], []), (PLC, 3): (['bool'], []),
    (PLC, 4): (['bool'], []), (PLC, 5): ([], ['uint32']),
}
_MUTATIONS = {(FILE, 8), (PLC, 1), (PLC, 3), (PLC, 4)}
PREFLIGHT_PATHS = frozenset((MANIFEST, 'PCWE.software-package-manifest.json'))
_PREFLIGHT_CALLS = frozenset(((PLC, 5), (FILESYSTEM, 1), (FILESYSTEM, 5), (FILESYSTEM, 6), (FILE, 9)))
_AUTHORITY = object()


class ControllerFailure(ProjectError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


class RemoteControllerError(ControllerFailure):
    def __init__(self, code: int, fatal: bool):
        self.remote_code, self.fatal = code, fatal
        # Do not echo remote formatting/arguments that could reflect credentials.
        super().__init__('remote_rsc_error', f'Controller returned RSC error 0x{code:08x}; fatal={fatal}.')


@dataclass(frozen=True)
class ControllerEndpoint:
    address: str
    port: int
    certificate_sha256: str

    def __post_init__(self):
        if type(self.address) is not str:
            raise ProjectError('Controller address must be a literal IP.')
        try:
            normalized = str(ipaddress.ip_address(self.address))
        except ValueError as exc:
            raise ProjectError('Controller address must be a literal IP.') from exc
        if type(self.port) is not int or not 1 <= self.port <= 65535:
            raise ProjectError('Controller port must be 1..65535.')
        pin = self.certificate_sha256
        if type(pin) is not str or len(pin) != 64 or any(c not in '0123456789abcdefABCDEF' for c in pin):
            raise ProjectError('An explicit certificate SHA-256 pin is required.')
        object.__setattr__(self, 'address', normalized)
        object.__setattr__(self, 'certificate_sha256', pin.lower())


class DownloadScope:
    """Internal capability; production creation is confined to approval loading."""
    def __init__(self, endpoint, files, kind, *, authority=None, review_sha256=None):
        if authority is not _AUTHORITY:
            raise ProjectError('A review is not write authorization.')
        if not isinstance(endpoint, ControllerEndpoint) or not files:
            raise ProjectError('Invalid download scope.')
        if kind not in ('loopback_fixture', 'operator_confirmed', 'mcp_authorized'):
            raise ProjectError('Invalid download scope kind.')
        if kind == 'loopback_fixture' and not ipaddress.ip_address(endpoint.address).is_loopback:
            raise ProjectError('The fixture scope only admits literal loopback addresses.')
        self.endpoint, self.kind, self.review_sha256 = endpoint, kind, review_sha256
        self.hashes = {}
        for path, data in files.items():
            _relative_path(path)
            if type(data) is not bytes:
                raise ProjectError('Download scope must capture exact package bytes.')
            self.hashes[path] = hashlib.sha512(data).hexdigest()

    @classmethod
    def loopback_fixture(cls, endpoint, files):
        return cls(endpoint, files, 'loopback_fixture', authority=_AUTHORITY)

    def validate_files(self, files):
        actual = {path: hashlib.sha512(data).hexdigest() for path, data in files.items()}
        if actual != self.hashes:
            raise ProjectError('Package bytes differ from the exact download scope.')


class TlsControllerClient:
    """One persistent, serial, schema-delimited TLS/RSC session."""
    def __init__(self, endpoint: ControllerEndpoint, *, scope: DownloadScope | None = None,
                 timeout_seconds: int = 10, event_sink=None, preflight_readonly: bool = False):
        if not isinstance(endpoint, ControllerEndpoint) or type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 30:
            raise ProjectError('Invalid controller endpoint or I/O deadline.')
        if scope is not None and (not isinstance(scope, DownloadScope) or scope.endpoint != endpoint):
            raise ProjectError('Download scope does not match the exact controller endpoint.')
        if type(preflight_readonly) is not bool or (preflight_readonly and scope is not None):
            raise ProjectError('A read-only preflight cannot carry a mutation scope.')
        if scope is not None and scope.kind == 'loopback_fixture' and not ipaddress.ip_address(endpoint.address).is_loopback:
            raise ProjectError('Loopback fixture scope cannot connect to a real controller.')
        self.endpoint, self.scope, self.timeout_seconds = endpoint, scope, timeout_seconds
        self.preflight_readonly = preflight_readonly
        if event_sink is not None and not callable(event_sink):
            raise ProjectError('Controller event sink must be callable.')
        self.event_sink = event_sink
        self.channel = None
        self.handles = {}
        self.token = None
        self.connected = False
        self.broken = False
        self.root = None
        self.trace = []
        self.peer = {}
        self._end = 0.0
        self.overall_end = None
        self.bytes_sent = self.bytes_received = 0

    def _emit(self, event):
        if self.event_sink is not None:
            self.event_sink(dict(event))

    def _deadline(self):
        self._end = time.monotonic() + self.timeout_seconds
        if self.overall_end is not None:
            self._end = min(self._end, self.overall_end)

    def _remaining(self):
        result = self._end - time.monotonic()
        if result <= 0:
            raise TimeoutError('Controller exchange deadline expired.')
        return result

    def _receive(self, count):
        if self.channel is None or self.broken:
            raise ControllerFailure('session_closed', 'Controller transport is not usable.')
        self.channel.settimeout(self._remaining())
        data = self.channel.recv(count)
        if not data:
            raise ConnectionError('Controller closed the TLS stream.')
        self.bytes_received += len(data)
        return data

    def _exact(self, count):
        data = bytearray()
        while len(data) < count:
            data.extend(self._receive(count - len(data)))
        return bytes(data)

    def _header(self):
        raw = self._exact(16)
        header, token = decode_header(raw, require_checksum=True)
        if (header.version != 4 or header.flags != DATA_TAGGING or token is not None
                or header.data_length or header.additional_header_size):
            raise ControllerFailure('unsupported_response_profile', 'Expected tagged RSC v4/no-datagram response without token.')
        return header, raw

    def _send(self, packet):
        self.channel.settimeout(self._remaining())
        self.channel.sendall(packet)
        self.bytes_sent += len(packet)

    def _raise_remote_error(self, header):
        if header.command_type == CommandType.ERROR:
            error = receive_error(self._receive)
            raise RemoteControllerError(error['code'], error['fatal'])

    def connect(self):
        if self.channel is not None or self.connected or self.broken:
            raise ControllerFailure('session_state', 'Client instances cannot connect/reconnect twice.')
        self._deadline()
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        tcp = socket.create_connection((self.endpoint.address, self.endpoint.port), timeout=self._remaining())
        try:
            tcp.settimeout(self._remaining())
            self.channel = context.wrap_socket(tcp, server_hostname=self.endpoint.address)
            actual_pin = hashlib.sha256(self.channel.getpeercert(binary_form=True)).hexdigest()
            if not hmac.compare_digest(actual_pin, self.endpoint.certificate_sha256):
                raise ControllerFailure('certificate_pin_mismatch', 'Certificate pin mismatch; no RSC request was sent.')
            self.peer = {'tls_version': self.channel.version(), 'cipher': self.channel.cipher()[0],
                         'certificate_sha256': actual_pin, 'certificate_pin_verified': True,
                         'pki_chain_and_hostname_verified': False}
            self.trace.append({'operation': 'Connect', 'response_received': False})
            self._emit(self.trace[-1])
            self._send(encode_connect_request())
            header, raw = self._header()
            self._raise_remote_error(header)
            tagged.decode_connect_confirmation(raw)
            self.trace[-1]['response_received'] = True
            self._emit(self.trace[-1])
            self.connected = True
        except Exception:
            self.broken = True
            try:
                (self.channel if self.channel is not None else tcp).close()
            except OSError:
                pass
            raise
        return dict(self.peer)

    def _service(self, service):
        if service not in (PASSWORD, FILE, FILESYSTEM, PLC):
            raise ControllerFailure('unknown_service', 'Only fixed download services are admitted.')
        readonly_services = (PLC, FILESYSTEM, FILE) if self.preflight_readonly else (PLC,)
        if self.scope is None and service not in readonly_services:
            raise ControllerFailure('write_approval_required', 'Read-only connections admit only PLC-state service discovery.')
        if service in self.handles:
            return self.handles[service]
        self._deadline()
        event = {'operation': 'GetServiceHandles', 'service': service, 'response_received': False}
        self.trace.append(event)
        try:
            self._emit(event)
            self._send(tagged.encode_get_service(PROVIDER, service))
            header, raw = self._header()
            self._raise_remote_error(header)
            handle, provider = tagged.decode_get_service_confirmation(raw)
            if any((handle, provider) == existing for existing in self.handles.values()):
                raise ControllerFailure('duplicate_service_handle', 'Controller returned duplicate service handles.')
            self.handles[service] = handle, provider
            event['response_received'] = True
            self._emit(event)
            return handle, provider
        except Exception:
            self.broken = True
            raise

    def _call(self, service, method, values, *, omit_header_token=False):
        if not self.connected or self.broken:
            raise ControllerFailure('session_closed', 'No usable controller session.')
        schema = SCHEMAS.get((service, method))
        if schema is None:
            raise ControllerFailure('unknown_method', 'Only measured download method schemas are admitted.')
        readonly_calls = _PREFLIGHT_CALLS if self.preflight_readonly else frozenset(((PLC, 5),))
        if self.scope is None and (service, method) not in readonly_calls:
            raise ControllerFailure('write_approval_required', 'User confirmation is required before file, session or control requests.')
        if (service, method) == (PLC, 3) and self.scope is not None and self.scope.kind != 'loopback_fixture':
            raise ControllerFailure('stop_not_authorized', 'The reviewed full-load policy does not automatically stop the PLC.')
        self._validate_call_values(service, method, values)
        handle, provider = self._service(service)
        packet = tagged.encode_request(handle, method, schema[0], values, provider_handle=provider,
                                       token=None if omit_header_token else self.token)
        self._deadline()
        event = {'operation': 'Invoke', 'service': service, 'method': method,
                 'mutating': (service, method) in _MUTATIONS, 'send_attempted': False,
                 'response_received': False}
        self.trace.append(event)
        try:
            event['send_attempted'] = True
            # Persist intent before a mutation can reach the wire. The sink
            # receives only operation metadata, never credentials or payloads.
            self._emit(event)
            self._send(packet)
            header, _ = self._header()
            if (header.service_handle, header.service_provider_handle, header.method_handle) != (handle, provider, method):
                raise ControllerFailure('response_mismatch', 'Controller response does not match the invoked dynamic handles.')
            if header.command_type == CommandType.ERROR:
                error = receive_error(self._receive)
                event.update(remote_error_code=error['code'], fatal=error['fatal'], response_received=True)
                self._emit(event)
                raise RemoteControllerError(error['code'], error['fatal'])
            if header.command_type != CommandType.INVOKE_CONFIRMATION:
                raise ControllerFailure('unexpected_response', 'Unexpected controller response command.')
            result = tagged.receive_values(self._receive, schema[1])
            event['response_received'] = True
            self._emit(event)
            return result
        except Exception:
            # A partial frame or uncertain mutation must never be retried or
            # followed by a second request on a potentially desynchronized stream.
            self.broken = True
            raise

    def _validate_call_values(self, service, method, values):
        """Last application boundary, including calls made by internal helpers."""
        if type(values) is not list:
            raise ControllerFailure('unreviewed_request', 'Request values must match a fixed method schema.')
        if service == PASSWORD and self.scope is not None and self.scope.kind in ('operator_confirmed', 'mcp_authorized'):
            raise ControllerFailure('authentication_not_authorized', 'The reviewed policy is anonymous; no password session is authorized.')
        if service == PLC and method == 5 and values != []:
            raise ControllerFailure('unreviewed_request', 'GetPlcState takes no input values.')
        if service == PLC and method in (1, 3, 4) and (len(values) != 1 or values[0] is not True):
            raise ControllerFailure('unreviewed_request', 'Only the measured async control request is admitted.')
        if service == FILESYSTEM:
            expected = {1: [], 5: [0, '$ARP_PROJECTS_DIR$/PCWE/'], 6: [self.root]}[method]
            if values != expected or (method == 6 and self.root is None):
                raise ControllerFailure('unreviewed_request', 'Filesystem queries are confined to the fixed PCWE root.')
        if service == FILE:
            if (len(values) != 1 or type(values[0]) is not list or not 1 <= len(values[0]) <= 4096):
                raise ControllerFailure('unreviewed_request', 'A nonempty bounded file list is required.')
            seen = set()
            for item in values[0]:
                if type(item) is not dict:
                    raise ControllerFailure('unreviewed_request', 'File request must use the fixed DTO.')
                path = item.get('path')
                admitted = self.scope.hashes if self.scope is not None else PREFLIGHT_PATHS
                relative = next((name for name in admitted if self.root is not None
                                 and path == self.root + '/' + name), None)
                if relative is None or relative in seen:
                    raise ControllerFailure('path_not_authorized', 'File requests cannot leave the exact admitted package paths.')
                seen.add(relative)
                if method == 9:
                    if set(item) != {'path', 'traits'} or type(item['traits']) is not int or item['traits'] != 0:
                        raise ControllerFailure('unreviewed_request', 'ReadMany only requests file data with no traits.')
                elif method == 8:
                    if (self.scope is None or set(item) != {'path', 'overwrite', 'traits', 'data'}
                            or item['overwrite'] is not True or type(item['data']) is not bytes
                            or hashlib.sha512(item['data']).hexdigest() != self.scope.hashes[relative]):
                        raise ControllerFailure('package_changed', 'WriteMany differs from the exact reviewed file bytes.')

    def get_state(self):
        return self._call(PLC, 5, [])[0]

    def authenticate(self, username, password):
        if type(username) is not str or not username or len(username.encode('utf-8')) + 1 > 64:
            raise ProjectError('Invalid bounded controller username.')
        token, penalty, error = self._call(PASSWORD, 1, [username, password], omit_header_token=True)
        if error != 0:
            raise ControllerFailure('authentication_failed', f'Authentication rejected; code={error}; penalty_ms={penalty}.')
        self.token = token  # UInt32 zero remains a valid token.

    def resolve_root(self):
        entry, error = self._call(FILESYSTEM, 5, [0, '$ARP_PROJECTS_DIR$/PCWE/'])
        root = entry['path'].rstrip('/')
        if (error != 0 or not entry['is_directory'] or entry['is_file'] or not root.startswith('/')
                or not root.endswith('/PCWE') or '\\' in root or any(part in ('.', '..', '') for part in root.split('/')[1:])):
            raise ControllerFailure('remote_root_invalid', 'Symbolic PCWE root did not resolve to a bounded absolute PCWE directory.')
        self.root = root
        return root

    def get_space(self):
        if self.root is None:
            raise ControllerFailure('remote_root_unknown', 'Resolve the PCWE root before querying space.')
        space, error = self._call(FILESYSTEM, 6, [self.root])
        if error != 0:
            raise ControllerFailure('space_query_failed', 'Controller free-space query failed.')
        return space['available']

    def _path(self, relative):
        _relative_path(relative)
        admitted = self.scope.hashes if self.scope is not None else (PREFLIGHT_PATHS if self.preflight_readonly else ())
        if self.root is None or relative not in admitted:
            raise ControllerFailure('path_not_authorized', 'Path is outside the exact reviewed package.')
        return self.root + '/' + relative

    def write_many(self, batch):
        if self.scope is None:
            raise ControllerFailure('write_approval_required', 'File writes require a download scope.')
        supported = self._call(FILESYSTEM, 1, [])[0]
        values = []
        for path, data in batch:
            if hashlib.sha512(data).hexdigest() != self.scope.hashes.get(path):
                raise ControllerFailure('package_changed', 'File data differs from its approved SHA-512.')
            values.append({'path': self._path(path), 'overwrite': True,
                           'traits': [{'trait': 1, 'value': 0o664}] if supported & 1 else [], 'data': data})
        return self._call(FILE, 8, [values])[0]

    def read_many(self, paths):
        return self._call(FILE, 9, [[{'path': self._path(path), 'traits': 0} for path in paths]])[0]

    def reset(self):
        self._call(PLC, 4, [True])

    def load(self):
        self._call(PLC, 1, [True])

    def close(self):
        cleanup_error = None
        try:
            if self.token is not None and self.connected and not self.broken:
                self._call(PASSWORD, 2, [self.token], omit_header_token=True)
        except Exception as exc:
            cleanup_error = type(exc).__name__
        finally:
            self.token = None
            self.handles.clear()
            self.connected = False
            if self.channel is not None:
                try:
                    self.channel.close()
                except Exception as exc:
                    cleanup_error = cleanup_error or type(exc).__name__
                finally:
                    self.channel = None
        return cleanup_error


def read_controller_state(report_root: Path, address: str, expected_certificate_sha256: str,
                          port: int = 41100, timeout_seconds: int = 5) -> dict:
    """Use the same production transport in its strictly read-only default mode."""
    endpoint = ControllerEndpoint(address, port, expected_certificate_sha256)
    client = TlsControllerClient(endpoint, timeout_seconds=timeout_seconds)
    client.overall_end = time.monotonic() + timeout_seconds
    job = Path(report_root) / 'controller-reads' / uuid.uuid4().hex
    job.mkdir(parents=True, exist_ok=False)
    result = {'status': 'read_failed', 'state_read': False, 'address': endpoint.address, 'port': port,
        'observed_utc': datetime.now(timezone.utc).isoformat(), 'backend': 'independent_download_transport_readonly',
        'certificate_policy': 'explicit_sha256_pin', 'certificate_pin_verified': False,
        'pki_chain_and_hostname_verified': False, 'commands_sent': [],
        'credentials_sent': False, 'file_methods_sent': False, 'configuration_commands_sent': False,
        'program_started_or_stopped': False, 'downloaded': False,
        'aci_used': False, 'engineer_started': False, 'computer_use_used': False}
    try:
        peer = client.connect()
        raw = client.get_state()
        result.update(status='state_read', state_read=True, rsc_connected=True,
            rsc_version=4, data_tagging=True, datagramming=False,
            certificate_pin_verified=True, peer_certificate_sha256=peer['certificate_sha256'],
            tls_version=peer['tls_version'], cipher=peer['cipher'], plc_state_raw=raw,
            plc_base_state={0:'None', 1:'Ready', 2:'Stop', 3:'Running', 4:'Halt'}.get(raw & 63, 'Unknown'),
            plc_state_flags=raw & ~63)
    except (OSError, ValueError) as exc:
        result.update(error_class=type(exc).__name__, failure_code=getattr(exc, 'code', 'transport_or_codec_error'))
        if isinstance(exc, ControllerFailure):
            result['error'] = str(exc)
    finally:
        result['cleanup_error_class'] = client.close()
        for event in client.trace:
            if event['operation'] == 'Connect':
                result['commands_sent'].append('Connect')
            elif event['operation'] == 'GetServiceHandles':
                result['commands_sent'].append('GetServiceHandles(IPlcManagerService)')
            elif event['operation'] == 'Invoke':
                result['commands_sent'].append('GetPlcState(method=5)')
        result['trace'] = client.trace
        result['report_path'] = str(job / 'result.json')
        (job / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return result
