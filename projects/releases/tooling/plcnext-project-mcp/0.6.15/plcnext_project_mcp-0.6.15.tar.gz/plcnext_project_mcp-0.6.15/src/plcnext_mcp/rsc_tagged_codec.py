"""Bounded RSC v4 tagged values and invocation envelopes; no transport.

Measured against Engineer 2026 pure MemoryStream formatters. Schemas are a
closed registry, never arbitrary CLR names or dynamic type reconstruction.
Only non-null values, one-dimensional arrays and bounded buffer-hint/chunk
streams are supported. A trailing FF terminates an invocation, not each value.
"""
from __future__ import annotations

import math
import struct
from dataclasses import dataclass

from .rsc_codec import (CommandHeader, CommandType, DATA_TAGGING, SECURE,
                        decode_header, encode_header)
from . import rsc_rpc_codec as untagged

MAX_BODY_BYTES = 128 * 1024 * 1024
MAX_STREAM_BYTES = 64 * 1024 * 1024
MAX_ARRAY_ITEMS = 4096
MAX_VALUES = 64
MAX_STREAM_CHUNKS = 65536


@dataclass(frozen=True)
class ChunkedStream:
    """Own-code nonseekable stream producer for verified local format tests."""
    data: bytes
    buffer_hint: int = 65536
    chunk_bytes: int = 65536

_SCALARS = {
    'bool': (2, '?', 0, 1), 'sbyte': (4, 'b', -128, 127),
    'byte': (5, 'B', 0, 255), 'int16': (6, 'h', -32768, 32767),
    'uint16': (7, 'H', 0, 65535), 'int32': (8, 'i', -(2**31), 2**31 - 1),
    'uint32': (9, 'I', 0, 2**32 - 1), 'int64': (10, 'q', -(2**63), 2**63 - 1),
    'uint64': (11, 'Q', 0, 2**64 - 1),
    'float32': (12, 'f', None, None), 'float64': (13, 'd', None, None),
}
_ARRAYS = {
    'byte[]': 'byte', 'int32[]': 'int32', 'bool[]': 'bool', 'utf8[]': 'utf8',
    'trait_item[]': 'trait_item', 'write_file[]': 'write_file',
    'read_file_info[]': 'read_file_info', 'read_file_data[]': 'read_file_data',
}
_STRUCTS = {
    'trait_item': (('trait', 'int32'), ('value', 'int32')),
    'write_file': (('path', 'utf8'), ('overwrite', 'bool'),
                   ('traits', 'trait_item[]'), ('data', 'stream')),
    'read_file_info': (('path', 'utf8'), ('traits', 'int32')),
    'read_file_data': (('result', 'int32'), ('traits', 'trait_item[]'), ('data', 'stream')),
    'filesystem_traits_entry': (('path', 'utf8'), ('is_file', 'bool'),
                                ('is_directory', 'bool'), ('traits', 'trait_item[]')),
    'space_info': (('capacity', 'uint64'), ('free', 'uint64'), ('available', 'uint64')),
}
SUPPORTED_SCHEMAS = frozenset(_SCALARS) | frozenset(_ARRAYS) | frozenset(_STRUCTS) | {
    'utf8', 'secure_utf8', 'stream', 'security_token'}


def _require(condition, message):
    if not condition:
        raise ValueError('RSC tagged codec: ' + message)


def _integer(value, minimum, maximum):
    _require(type(value) is int and minimum <= value <= maximum, 'integer outside schema range.')
    return value


def _join_bounded(parts):
    data = bytearray()
    for part in parts:
        _require(len(data) + len(part) <= MAX_BODY_BYTES, 'encoded values exceed size bound.')
        data.extend(part)
    return bytes(data)


def _tag(schema):
    _require(type(schema) is str and schema in SUPPORTED_SCHEMAS, 'unsupported value schema.')
    if schema in _SCALARS:
        return bytes([_SCALARS[schema][0]])
    if schema in _ARRAYS:
        return b'\x14' + _tag(_ARRAYS[schema])
    if schema in _STRUCTS:
        return b'\x12' + struct.pack('<H', len(_STRUCTS[schema]))
    return {'utf8': b'\x13', 'secure_utf8': b'\x24',
            'stream': b'\x22', 'security_token': b'\x27'}[schema]


def _validate_struct(schema, value):
    _require(type(value) is dict and set(value) == {key for key, _ in _STRUCTS[schema]},
             'struct fields do not match the fixed schema.')
    if schema == 'trait_item':
        _require(type(value['trait']) is int and value['trait'] == 1, 'only Permissions trait supported.')
        _integer(value['value'], 0, 0o777)
    if schema in ('write_file', 'read_file_info', 'filesystem_traits_entry'):
        _require(type(value['path']) is str and len(value['path'].encode('utf-8')) <= 511,
                 'file path exceeds measured profile.')
    if schema in ('read_file_data',):
        _integer(value['result'], 0, 6)
    if schema == 'read_file_info':
        _integer(value['traits'], 0, 31)
    if 'traits' in value and schema != 'read_file_info':
        _require(type(value['traits']) is list and len(value['traits']) <= 1,
                 'only one optional Permissions trait supported.')


def _encode_payload(schema, value):
    if schema in _SCALARS:
        _, code, minimum, maximum = _SCALARS[schema]
        if schema == 'bool':
            _require(type(value) is bool, 'Boolean value required.')
        elif schema.startswith('float'):
            _require(type(value) in (int, float), 'finite floating value required.')
            try:
                finite = math.isfinite(value)
            except OverflowError as exc:
                raise ValueError('RSC tagged codec: floating value outside schema range.') from exc
            _require(finite, 'finite floating value required.')
        else:
            _integer(value, minimum, maximum)
        try:
            return struct.pack('<' + code, value)
        except (OverflowError, struct.error) as exc:
            raise ValueError('RSC tagged codec: value cannot fit its schema.') from exc
    if schema in ('utf8', 'secure_utf8'):
        _require(type(value) is str and '\0' not in value, 'non-null UTF8 string required.')
        try:
            data = value.encode('utf-8') + b'\0'
        except UnicodeError as exc:
            raise ValueError('RSC tagged codec: invalid UTF8 string.') from exc
        _require(len(data) <= (128 if schema == 'secure_utf8' else 65535),
                 'UTF8 value exceeds its bounded profile.')
        return struct.pack('<H', len(data)) + data
    if schema == 'stream':
        if isinstance(value, ChunkedStream):
            _require(type(value.data) is bytes and len(value.data) <= MAX_STREAM_BYTES, 'invalid chunked stream bytes.')
            _integer(value.buffer_hint, 0, 0x7fffffff)
            _integer(value.chunk_bytes, 1, 65536)
            _require((len(value.data) + value.chunk_bytes - 1) // value.chunk_bytes <= MAX_STREAM_CHUNKS,
                     'chunked stream exceeds chunk-count bound.')
            def parts():
                yield struct.pack('<i', value.buffer_hint)
                for offset in range(0, len(value.data), value.chunk_bytes):
                    block = value.data[offset:offset + value.chunk_bytes]
                    yield struct.pack('<i', len(block))
                    yield block
                yield struct.pack('<i', -1)
            return _join_bounded(parts())
        _require(type(value) is bytes and len(value) <= MAX_STREAM_BYTES, 'invalid seekable byte stream.')
        return (struct.pack('<i', len(value)) +
                (struct.pack('<i', len(value)) + value if value else b'') + b'\xff\xff\xff\xff')
    if schema == 'security_token':
        return encode_value('uint32', value)
    if schema in _ARRAYS:
        if schema == 'byte[]':
            _require(type(value) is bytes and len(value) <= MAX_STREAM_BYTES, 'byte array must be bounded bytes.')
            return struct.pack('<i', len(value)) + value
        _require(type(value) is list and len(value) <= MAX_ARRAY_ITEMS, 'invalid one-dimensional array.')
        return _join_bounded((struct.pack('<i', len(value)),
            _join_bounded(_encode_payload(_ARRAYS[schema], item) for item in value)))
    _validate_struct(schema, value)
    return _join_bounded(encode_value(field_schema, value[key]) for key, field_schema in _STRUCTS[schema])


def encode_value(schema: str, value) -> bytes:
    """Encode exactly one known tagged value; no invocation end marker."""
    result = _tag(schema) + _encode_payload(schema, value)
    _require(len(result) <= MAX_BODY_BYTES, 'value exceeds size bound.')
    return result


class _Reader:
    def __init__(self, data):
        _require(type(data) is bytes and len(data) <= MAX_BODY_BYTES, 'invalid value body.')
        self.data, self.position = data, 0

    def take(self, count):
        _require(type(count) is int and count >= 0 and self.position + count <= len(self.data),
                 'truncated value body.')
        value = self.data[self.position:self.position + count]
        self.position += count
        return value

    def number(self, code):
        return struct.unpack('<' + code, self.take(struct.calcsize('<' + code)))[0]


class _StreamReader:
    """Consume a finite schema over an injected reader, including short reads."""
    def __init__(self, read_exact):
        _require(callable(read_exact), 'a byte reader callable is required.')
        self.read_exact, self.position = read_exact, 0

    def take(self, count):
        _require(type(count) is int and count >= 0 and self.position + count <= MAX_BODY_BYTES,
                 'streamed values exceed bound.')
        data, remaining = bytearray(), count
        while remaining:
            chunk = self.read_exact(remaining)
            _require(type(chunk) is bytes and 0 < len(chunk) <= remaining,
                     'byte reader returned EOF, non-bytes or too much data.')
            data.extend(chunk)
            remaining -= len(chunk)
        self.position += count
        return bytes(data)

    def number(self, code):
        return struct.unpack('<' + code, self.take(struct.calcsize('<' + code)))[0]


def _decode_payload(reader, schema):
    if schema in _SCALARS:
        if schema == 'bool':
            value = reader.take(1)[0]
            _require(value in (0, 1), 'invalid Boolean byte.')
            return bool(value)
        value = reader.number(_SCALARS[schema][1])
        if schema.startswith('float'):
            _require(math.isfinite(value), 'non-finite floating value is unsupported.')
        return value
    if schema in ('utf8', 'secure_utf8'):
        count = reader.number('H')
        _require(count >= 1, 'UTF8 string has no NUL terminator.')
        _require(schema != 'secure_utf8' or count <= 128, 'authentication string exceeds bound.')
        raw = reader.take(count)
        _require(raw.endswith(b'\0') and b'\0' not in raw[:-1], 'invalid UTF8 string terminator.')
        try:
            return raw[:-1].decode('utf-8', errors='strict')
        except UnicodeError as exc:
            raise ValueError('RSC tagged codec: invalid UTF8 string.') from exc
    if schema == 'stream':
        # Original MarshalledStream.ReadStreamData treats this as a buffer
        # allocation hint, NOT the total data length. Native and nonseekable
        # producers may use 65536 or Int32Max for very small files.
        hint = reader.number('i')
        _require(hint >= 0, 'negative stream buffer hint is unsupported.')
        data = bytearray()
        for _ in range(MAX_STREAM_CHUNKS + 1):
            count = reader.number('i')
            if count == -1:
                return bytes(data)
            _require(count >= 0, 'negative stream chunk length is unsupported.')
            _require(len(data) + count <= MAX_STREAM_BYTES, 'stream content exceeds byte bound.')
            _require(_ < MAX_STREAM_CHUNKS, 'stream exceeds chunk-count bound.')
            data.extend(reader.take(count))
        raise ValueError('RSC tagged codec: stream terminator missing.')
    if schema == 'security_token':
        return _read_value(reader, 'uint32')
    if schema in _ARRAYS:
        count = reader.number('i')
        maximum = MAX_STREAM_BYTES if schema == 'byte[]' else MAX_ARRAY_ITEMS
        _require(0 <= count <= maximum, 'null or oversized array unsupported.')
        if schema == 'byte[]':
            return reader.take(count)
        return [_decode_payload(reader, _ARRAYS[schema]) for _ in range(count)]
    result = {key: _read_value(reader, field_schema) for key, field_schema in _STRUCTS[schema]}
    _validate_struct(schema, result)
    return result


def _read_value(reader, schema):
    tag = _tag(schema)
    observed = reader.take(len(tag))
    _require(observed == tag, 'value tag does not match schema ' + schema
             + '; expected ' + tag.hex() + ', observed ' + observed.hex() + '.')
    return _decode_payload(reader, schema)


def decode_value(data: bytes, schema: str):
    """Decode one exact known value; reject trailing, null and unknown tags."""
    reader = _Reader(data)
    result = _read_value(reader, schema)
    _require(reader.position == len(data), 'trailing value bytes.')
    return result


def encode_values(schemas: list[str], values: list, *, end_marker: bool = True) -> bytes:
    """Encode a fixed parameter/OUT/return sequence, optionally with FF terminator."""
    _require(type(schemas) is list and type(values) is list and len(schemas) == len(values)
             and len(schemas) <= MAX_VALUES and type(end_marker) is bool, 'invalid value sequence.')
    result = _join_bounded(encode_value(schema, value) for schema, value in zip(schemas, values))
    result += b'\xff' if end_marker else b''
    _require(len(result) <= MAX_BODY_BYTES, 'value sequence exceeds bound.')
    return result


def decode_values(data: bytes, schemas: list[str], *, end_marker: bool = True) -> list:
    """Schema-delimited parser; never search for FF inside binary payloads."""
    _require(type(schemas) is list and len(schemas) <= MAX_VALUES and type(end_marker) is bool,
             'invalid expected value sequence.')
    reader = _Reader(data)
    values = [_read_value(reader, schema) for schema in schemas]
    if end_marker:
        _require(reader.take(1) == b'\xff', 'invocation end marker missing.')
    _require(reader.position == len(data), 'trailing invocation values.')
    return values


def receive_values(read_exact, schemas: list[str], *, end_marker: bool = True) -> list:
    """Read one bounded schema sequence from an injected byte reader.

    The reader may return short fragments. This function performs no I/O of
    its own and sets no network deadlines; the caller owns transport/timeouts.
    It consumes only these values and the optional FF terminator, preserving
    any subsequent frame. Unlike decode_values it cannot reject future bytes
    without consuming a subsequent persistent-stream message.
    """
    _require(type(schemas) is list and len(schemas) <= MAX_VALUES and type(end_marker) is bool,
             'invalid expected value sequence.')
    for schema in schemas:
        _tag(schema)  # Reject unrecognized schema before invoking the reader.
    reader = _StreamReader(read_exact)
    values = [_read_value(reader, schema) for schema in schemas]
    if end_marker:
        _require(reader.take(1) == b'\xff', 'invocation end marker missing.')
    return values


def _invoke(command, service_handle, method_handle, provider_handle, schemas, values, token):
    _integer(service_handle, 1, 32767)
    _integer(method_handle, 1, 32767)
    _integer(provider_handle, 0, 32767)
    header = CommandHeader(version=4, flags=DATA_TAGGING, command_type=command,
                           service_handle=service_handle, method_handle=method_handle,
                           service_provider_handle=provider_handle)
    return encode_header(header, token) + encode_values(schemas, values)


def encode_request(service_handle: int, method_handle: int, schemas: list[str], values: list,
                   *, provider_handle: int = 0, token: int | None = None) -> bytes:
    return _invoke(CommandType.INVOKE_REQUEST, service_handle, method_handle, provider_handle, schemas, values, token)


def encode_response(service_handle: int, method_handle: int, schemas: list[str], values: list,
                    *, provider_handle: int = 0, token: int | None = None) -> bytes:
    return _invoke(CommandType.INVOKE_CONFIRMATION, service_handle, method_handle, provider_handle, schemas, values, token)


def _decode_invoke(data, schemas, command):
    _require(type(data) is bytes and 17 <= len(data) <= MAX_BODY_BYTES, 'invalid invocation size.')
    size = 20 if data[1] & SECURE else 16
    header, token = decode_header(data[:size], require_checksum=True)
    _require(header.version == 4 and header.command_type == command and
             header.flags & ~SECURE == DATA_TAGGING and header.data_length == 0 and
             min(header.service_handle, header.method_handle) > 0 and header.service_provider_handle >= 0,
             'unsupported tagged invocation profile.')
    return header, token, decode_values(data[size:], schemas)


def decode_request(data: bytes, schemas: list[str]):
    return _decode_invoke(data, schemas, CommandType.INVOKE_REQUEST)


def decode_response(data: bytes, schemas: list[str]):
    # Remote error framing is deliberately not guessed from normal returns.
    return _decode_invoke(data, schemas, CommandType.INVOKE_CONFIRMATION)


def encode_get_service(provider_name: str, service_name: str) -> bytes:
    """Discovery retains raw name encoding even in a tagged session; no FF."""
    data = untagged.encode_get_service(provider_name, service_name)
    header, _ = decode_header(data[:16], require_checksum=True)
    return encode_header(CommandHeader(version=4, flags=DATA_TAGGING, command_type=15,
                                        data_length=header.data_length)) + data[16:]


def decode_get_service(data: bytes) -> tuple[str, str]:
    _require(type(data) is bytes and len(data) >= 16, 'invalid service discovery message.')
    header, token = decode_header(data[:16], require_checksum=True)
    _require(header.flags == DATA_TAGGING and token is None, 'unsupported discovery flags.')
    plain = encode_header(CommandHeader(version=header.version, command_type=header.command_type,
        data_length=header.data_length, service_handle=header.service_handle,
        method_handle=header.method_handle, service_provider_handle=header.service_provider_handle))
    return untagged.decode_get_service(plain + data[16:])


def decode_get_service_confirmation(data: bytes) -> tuple[int, int]:
    _require(type(data) is bytes and len(data) == 16, 'invalid discovery confirmation.')
    header, token = decode_header(data, require_checksum=True)
    _require(header.version == 4 and header.flags == DATA_TAGGING and token is None and
             header.command_type == 16 and header.data_length == 0 and header.method_handle == 0 and
             min(header.service_handle, header.service_provider_handle) > 0,
             'unsupported discovery confirmation profile.')
    return header.service_handle, header.service_provider_handle


def encode_get_service_confirmation(service_handle: int, provider_handle: int) -> bytes:
    _integer(service_handle, 1, 32767)
    _integer(provider_handle, 1, 32767)
    return encode_header(CommandHeader(version=4, flags=DATA_TAGGING, command_type=16,
        service_handle=service_handle, service_provider_handle=provider_handle))


def encode_connect_confirmation() -> bytes:
    return encode_header(CommandHeader(version=4, flags=DATA_TAGGING, command_type=8))


def decode_connect_confirmation(data: bytes) -> CommandHeader:
    _require(type(data) is bytes and len(data) == 16, 'invalid connect confirmation.')
    header, token = decode_header(data, require_checksum=True)
    _require(header.version == 4 and header.flags == DATA_TAGGING and header.command_type == 8 and
             token is None and not any((header.data_length, header.service_handle, header.method_handle,
                                         header.service_provider_handle)), 'unsupported tagged negotiation.')
    return header
