"""M08 bounded evidence over existing read-only observation receipts.

No monitor RPC time is reinterpreted as PLC execution time. Missing ESM service
or a versioned probe produces unknown/unsupported measurements. This does not
start P06 or decide its <=1ms / >=90-per-second acceptance thresholds.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import math
from pathlib import Path
import re
import uuid

from .deployment_plan import _file
from .controller_download_plan import _strict_json
from .project import ProjectError, sha

PROBE_SCHEMA = 'plcnext-runtime-probe-contract/v1'
EVIDENCE_SCHEMA = 'plcnext-runtime-timing-evidence/v1'
MAX_OBSERVATIONS = 32
MAX_OBSERVATION_BYTES = 2 * 1024 * 1024
ROLES = {
    'boot_id': ('identity', 'string'), 'configuration_version': ('generation', 'integer'),
    'reset_generation': ('generation', 'integer'), 'probe_version': ('identity', 'string'),
    'device_monotonic_us': ('us', 'integer'), 'task_cycle_us': ('us', 'number'),
    'task_peak_us': ('us', 'number'), 'task_overrun_total': ('count', 'integer'),
    'watchdog_violation_total': ('count', 'integer'),
    'increment_probe_peak_us': ('us', 'number'), 'release_total': ('count', 'integer'),
}


def _canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')


def runtime_evidence_capabilities():
    return {'implemented':True,'backend':'reviewed_runtime_observation_receipts',
        'direct_esm_diagnostic_service_implemented':False,'versioned_probe_supported':True,
        'restore_archive_probe_profile_verified':False,'starts_performance_test':False,
        'rpc_time_is_plc_cpu':False,'p06_acceptance_implemented':False,
        'maximum_observations':MAX_OBSERVATIONS,'maximum_observation_bytes':MAX_OBSERVATION_BYTES}


def validate_probe_contract(contract, source_project_sha256, allowed_symbols):
    if contract is None:
        return None
    if (type(contract) is not dict or set(contract)!={'schema','source_project_sha256','probe_version','resolution_us','fields'}
            or contract.get('schema')!=PROBE_SCHEMA or contract.get('source_project_sha256')!=source_project_sha256
            or type(contract.get('probe_version')) is not str or not 1<=len(contract['probe_version'])<=128
            or type(contract.get('resolution_us')) not in (int,float)
            or not math.isfinite(contract['resolution_us']) or not 0<contract['resolution_us']<=1000000
            or type(contract.get('fields')) is not list or not 1<=len(contract['fields'])<=len(ROLES)):
        raise ProjectError('Invalid exact-source runtime probe contract.')
    seen=set()
    for field in contract['fields']:
        if (type(field) is not dict or set(field)!={'role','symbol','unit'} or field['role'] not in ROLES
                or field['role'] in seen or field['symbol'] not in allowed_symbols
                or field['unit']!=ROLES[field['role']][0]):
            raise ProjectError('Probe role/symbol/unit is unsupported, duplicate or outside the read plan.')
        seen.add(field['role'])
    if not {'boot_id','probe_version'}<=seen:
        raise ProjectError('Versioned probe evidence requires boot_id and probe_version fields.')
    return contract


def _value(item, kind):
    if item is None or item.get('status')!='read':
        return None,'field_missing_or_unread'
    value=item.get('value')
    if kind=='string':
        valid=type(value) is str and bool(value) and len(value)<=1024
    elif kind=='integer':
        valid=type(value) is int and 0<=value<=2**64-1
    else:
        try:valid=type(value) in (int,float) and math.isfinite(value) and value>=0
        except OverflowError:valid=False
    return (value,None) if valid else (None,'field_type_or_range_mismatch')


def analyze_observations(observations, probe_contract=None, *, source_project_sha256,
                          allowed_symbols, expected_interval_seconds=None):
    """Pure bounded analysis of authenticated-by-caller observation records."""
    if type(observations) is not list or not 1<=len(observations)<=MAX_OBSERVATIONS:
        raise ProjectError('Evidence requires 1..32 bounded runtime observations.')
    contract=validate_probe_contract(probe_contract,source_project_sha256,set(allowed_symbols))
    if expected_interval_seconds is not None and (type(expected_interval_seconds) not in (int,float)
            or not 0<expected_interval_seconds<=3600):
        raise ProjectError('Invalid expected evidence observation interval.')
    target=None
    windows=[];issues=[];rows=[];all_symbols=set(allowed_symbols)
    bindings={} if contract is None else {f['role']:f for f in contract['fields']}
    for index,observation in enumerate(observations):
        if (type(observation) is not dict or observation.get('schema')!='plcnext-runtime-observation/v1'
                or observation.get('source_project_sha256')!=source_project_sha256
                or observation.get('read_only') is not True or observation.get('control_requests_sent') is not False
                or observation.get('write_requests_sent') is not False or observation.get('force_requests_sent') is not False
                or type(observation.get('items')) is not list or len(observation['items'])>2048):
            raise ProjectError('Observation source, read-only guarantees or item bound is invalid.')
        if target is None:target=observation.get('target')
        if observation.get('target')!=target:
            raise ProjectError('Evidence cannot stitch different targets or certificate pins.')
        items={}
        for item in observation['items']:
            if type(item) is not dict or item.get('symbol') not in all_symbols or item['symbol'] in items:
                raise ProjectError('Observation has unknown or duplicate source symbols.')
            items[item['symbol']]=item
        row={};row_issues=[]
        for role,field in bindings.items():
            value,error=_value(items.get(field['symbol']),ROLES[role][1]);row[role]=value
            if error:row_issues.append({'role':role,'reason':error})
        if contract is not None and row.get('probe_version')!=contract['probe_version']:
            row_issues.append({'role':'probe_version','reason':'probe_version_changed_or_unread'})
        if observation.get('status') not in ('monitor_read_completed','monitor_read_partial'):
            row_issues.append({'reason':'observation_failed_or_invalidated'})
        if observation.get('consistency') not in ('guarded_window_observation','unguarded_window_observation'):
            row_issues.append({'reason':'observation_consistency_invalid'})
        start,end=observation.get('started_monotonic_ns'),observation.get('finished_monotonic_ns')
        duration=None
        if type(start) is int and type(end) is int and 0<=start<=end:
            duration=(end-start)/1e9
        else:row_issues.append({'reason':'host_observation_window_missing'})
        windows.append({'observation_index':index,'created_utc':observation.get('created_utc'),
            'finished_utc':observation.get('finished_utc'),'host_monotonic_clock_domain':observation.get('host_monotonic_clock_domain'),
            'started_monotonic_ns':start,'finished_monotonic_ns':end,
            'host_read_window_seconds':duration,'rpc_time_used_as_plc_cpu':False,
            'batch_count':len(observation.get('batch_windows',[])),
            'bytes_received':observation.get('bytes_received'), 'bytes_sent':observation.get('bytes_sent'),
            'network_operation_count':observation.get('network_operation_count'),
            'consistency':observation.get('consistency'),'issues':row_issues})
        rows.append(row);issues.extend({'observation_index':index,**item} for item in row_issues)
    boot_values={r.get('boot_id') for r in rows if r.get('boot_id') is not None}
    config_values={r.get('configuration_version') for r in rows if r.get('configuration_version') is not None}
    reset_values={r.get('reset_generation') for r in rows if r.get('reset_generation') is not None}
    invalidated=(len(boot_values)>1 or len(config_values)>1 or len(reset_values)>1
        or any(o.get('status')=='snapshot_invalidated' or o.get('consistency')=='snapshot_invalidated' for o in observations))
    guards_complete=bool(contract) and all(all(row.get(role) is not None for role in
        ('boot_id','configuration_version','reset_generation')) for row in rows)
    probe_version_valid=bool(contract) and all(row.get('probe_version')==contract['probe_version'] for row in rows)
    if invalidated:issues.append({'reason':'boot_configuration_or_reset_generation_changed'})
    result={'schema':EVIDENCE_SCHEMA,'created_utc':datetime.now(timezone.utc).isoformat(),
        'status':'timing_evidence_unsupported' if contract is None else 'timing_evidence_observed',
        'source_project_sha256':source_project_sha256,'target':target,'read_only':True,
        'observation_count':len(observations),'windows':windows,'probe_contract':contract,
        'probe_contract_sha256':None if contract is None else sha(_canonical(contract)),
        'measurement_resolution_us':None if contract is None else contract['resolution_us'],
        'measurement_resolution_source':'unknown' if contract is None else 'reviewed_probe_contract_declared',
        'boot_changed':len(boot_values)>1 if boot_values else None,
        'configuration_changed':len(config_values)>1 if config_values else None,
        'counter_generation_changed':len(reset_values)>1 if reset_values else None,
        'guard_fields_complete':guards_complete,'probe_version_verified':probe_version_valid,
        'snapshot_invalidated':invalidated,
        'atomic_snapshot':False,'monitoring_impact_on_plc_task_verified':False,
        'workload_profile_verified':False,'observation_sequence_contiguous':None,
        'loaded_image_identity_verified':False,'whole_task':{},'increment_probe':{},
        'counter_deltas':{},'release_throughput':{'status':'unknown','events_per_second':None},
        'baseline_comparison':{'status':'unknown','reason':'No matched original-program baseline supplied.'},
        'p06_acceptance':{'status':'not_evaluated','reason':'P06 is paused; no <=1ms or >=90/s decision is made.'},
        'sampling_gaps':[],'issues':issues}
    if contract is None:
        result['issues'].append({'reason':'No reviewed versioned probe or implemented ESM runtime diagnostic service.'})
        return result
    for role in ('task_cycle_us','task_peak_us'):
        values=[r.get(role) for r in rows]
        valid=[v for v in values if v is not None]
        result['whole_task'][role]={'status':'observed' if len(valid)==len(rows) and not invalidated and probe_version_valid else 'incomplete',
            'values':values,'maximum_observed':max(valid) if valid else None,'unit':'us',
            'worst_case_execution_proved':False}
    values=[r.get('increment_probe_peak_us') for r in rows]
    valid=[v for v in values if v is not None]
    result['increment_probe']={'status':'observed' if len(valid)==len(rows) and not invalidated and probe_version_valid else 'unknown_or_incomplete',
        'values_us':values,'maximum_observed_us':max(valid) if valid else None,
        'whole_task_values_subtracted':False,'worst_case_execution_proved':False}
    for role in ('task_overrun_total','watchdog_violation_total','release_total'):
        values=[r.get(role) for r in rows]
        complete=len(rows)>=2 and all(v is not None for v in values)
        decreases=complete and any(b<a for a,b in zip(values,values[1:]))
        if decreases:result['issues'].append({'role':role,'reason':'counter_decreased_reset_or_wrap_unknown'})
        valid_delta=complete and not invalidated and not decreases and guards_complete and probe_version_valid
        result['counter_deltas'][role]={'status':'observed_delta' if valid_delta else 'unknown',
            'delta':values[-1]-values[0] if valid_delta else None,
            'counter_reset_or_wrap_possible':bool(decreases) or not guards_complete,
            'counter_overwrite_or_wrap_verified':False}
    device_times=[r.get('device_monotonic_us') for r in rows]
    device_complete=len(rows)>=2 and all(t is not None for t in device_times)
    increasing=device_complete and all(b>a for a,b in zip(device_times,device_times[1:]))
    if device_complete and not increasing:result['issues'].append({'reason':'device_monotonic_reset_or_nonincrease'})
    if increasing and not invalidated:
        intervals=[(b-a)/1e6 for a,b in zip(device_times,device_times[1:])]
        if expected_interval_seconds is not None:
            result['sampling_gaps']=[{'after_observation':i,'device_interval_seconds':interval,
                'expected_seconds':expected_interval_seconds} for i,interval in enumerate(intervals) if interval>expected_interval_seconds*1.5]
            result['observation_sequence_contiguous']=not result['sampling_gaps']
            if result['sampling_gaps']:result['issues'].append({'reason':'observation_sampling_gap'})
        delta=result['counter_deltas']['release_total']['delta']
        if delta is not None:
            span=(device_times[-1]-device_times[0])/1e6
            result['release_throughput']={'status':'observed_probe_counter_rate','events_per_second':delta/span,
                'unique_stored_release_semantics_verified':False,'device_monotonic_window_seconds':span,
                'uses_rpc_duration':False,'acceptance_decision':None}
    if invalidated:result['status']='timing_evidence_invalidated'
    elif issues:result['status']='timing_evidence_incomplete'
    return result


def _load_observation(store,project_id,reference):
    if (type(reference) is not dict or set(reference)!={'observation_id','observation_sha256'}
            or re.fullmatch('[0-9a-f]{32}',str(reference['observation_id'])) is None
            or re.fullmatch('[0-9a-f]{64}',str(reference['observation_sha256'])) is None):
        raise ProjectError('Exact observation ID/hash is required.')
    path=_file(store._folder(project_id),'runtime-observations/'+reference['observation_id']+'/result.json')
    if not path.is_file() or path.stat().st_size>MAX_OBSERVATION_BYTES:
        raise ProjectError('Missing or oversized runtime observation.')
    raw=path.read_bytes()
    if len(raw)>MAX_OBSERVATION_BYTES:raise ProjectError('Oversized runtime observation.')
    item=_strict_json(raw)
    unsigned={k:v for k,v in item.items() if k!='observation_sha256'}
    if item.get('observation_id')!=reference['observation_id'] or item.get('observation_sha256')!=reference['observation_sha256'] or sha(_canonical(unsigned))!=reference['observation_sha256']:
        raise ProjectError('Runtime observation identity/hash mismatch.')
    return item


def runtime_timing_evidence(store,project_id,read_plan_id,expected_read_plan_sha256,
                            observations,probe_contract=None):
    """Analyze only exact existing receipts; no network or performance test."""
    from .runtime_monitor import load_runtime_read_plan
    plan=load_runtime_read_plan(store,project_id,read_plan_id,expected_read_plan_sha256)
    if type(observations) is not list or not 1<=len(observations)<=MAX_OBSERVATIONS:
        raise ProjectError('Provide 1..32 exact observation references.')
    if len({(r.get('observation_id'),r.get('observation_sha256')) for r in observations if isinstance(r,dict)})!=len(observations):
        raise ProjectError('Duplicate or malformed observation references.')
    records=[_load_observation(store,project_id,reference) for reference in observations]
    if any(r.get('plan_id')!=read_plan_id or r.get('plan_sha256')!=expected_read_plan_sha256 for r in records):
        raise ProjectError('Observation belongs to another read plan.')
    result=analyze_observations(records,probe_contract,source_project_sha256=plan['project_sha256'],
        allowed_symbols=[r['symbol'] for r in plan['requests']],
        expected_interval_seconds=plan['limits']['minimum_interval_seconds'])
    result.update(project_id=project_id,read_plan_id=read_plan_id,
        read_plan_sha256=expected_read_plan_sha256,observation_references=observations,
        device_contacted=False,performance_test_started=False)
    directory=_file(store._folder(project_id),'runtime-timing-evidence/'+uuid.uuid4().hex)
    directory.mkdir(parents=True,exist_ok=False)
    path=directory/'result.json';result['report_path']=str(path)
    path.write_bytes(_canonical(result)+b'\n')
    return result
