"""Original PlcState metadata: Hot/Warm are neither busy nor error flags."""
HOT = 0x20000
WARM = 0x100000
METADATA = HOT | WARM
BUSY = 0x1f000


def stable_state(raw: int, expected: int) -> bool:
    """Compare stable states, ignoring only the original Hot/Warm metadata bits."""
    return (type(raw) is int and type(expected) is int
        and raw & ~METADATA == expected & ~METADATA
        and raw & ~METADATA in (1, 2, 3, 4))
