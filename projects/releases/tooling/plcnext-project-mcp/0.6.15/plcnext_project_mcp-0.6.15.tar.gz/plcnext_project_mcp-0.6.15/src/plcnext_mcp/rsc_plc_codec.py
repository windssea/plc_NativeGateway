"""Bounded PLC-manager parameter/return values measured with vendor formatters.

Only RemotingVersion4, untagged scalar values are supported. These functions
do not encode a CommonRemoting header, authenticate, open a transport, call a
service, or turn a successful local roundtrip into controller verification.
"""
from __future__ import annotations

import struct

from .project import ProjectError

PLC_PROVIDER = 'Arp'
PLC_SERVICE = 'Arp.Plc.Domain.Services.IPlcManagerService'
PLC_SERVICE2 = 'Arp.Plc.Domain.Services.IPlcManagerService2'
# These IDs come from RscMethodAttribute; only the bounded subset below has a
# value codec. Interface suffix 2 is not a remoting-protocol version declaration.
PLC_METHODS = {'Load': 1, 'Start': 2, 'Stop': 3, 'Reset': 4, 'GetPlcState': 5}
PLC_METHODS2 = {'Change': 6, 'Restart': 7}
SUPPORTED_METHODS = frozenset({'Reset', 'Load', 'GetPlcState'})
PLC_SERVICE_METADATA = {
    'provider': PLC_PROVIDER,
    'interface_name': PLC_SERVICE,
    'declared_service_version': None,
    'remoting_version': 4,
    'method_ids': PLC_METHODS,
    'wire_service_discovery_verified': False,
}


def _require(condition, message):
    if not condition:
        raise ProjectError('RSC PLC value codec: ' + message)


def _profile(method, version):
    _require(type(method) is str and method in SUPPORTED_METHODS,
             'only Reset, Load and GetPlcState are supported.')
    _require(type(version) is int and version == 4,
             'only untagged RemotingVersion4 values are supported.')


def encode_plc_request(method: str, async_: bool | None = None, *, version: int = 4) -> bytes:
    """Encode the input values after an already separated Invoke4 header.

    Reset/Load default to async=True. GetPlcState has no input values and requires
    async_=None. This is a method value body, not a complete invocation frame.
    """
    _profile(method, version)
    if method == 'GetPlcState':
        _require(async_ is None, 'GetPlcState has no async input parameter.')
        return b''
    async_ = True if async_ is None else async_
    _require(type(async_) is bool, 'async must be Boolean.')
    return bytes([async_])


def decode_plc_request(method: str, payload: bytes, *, version: int = 4) -> dict:
    """Decode exactly one supported request value body; reject trailing bytes."""
    _profile(method, version)
    _require(type(payload) is bytes, 'request values must be exact bytes.')
    if method == 'GetPlcState':
        _require(payload == b'', 'GetPlcState input body must be empty.')
        return {}
    _require(payload in (b'\x00', b'\x01'), 'invalid/truncated Boolean request value.')
    return {'async_': payload == b'\x01'}


def encode_plc_response(method: str, raw_state: int | None = None, *, version: int = 4) -> bytes:
    """Encode no out arguments plus the return value of the original interface."""
    _profile(method, version)
    if method != 'GetPlcState':
        _require(raw_state is None, 'Reset/Load return void with no out values.')
        return b''
    _require(type(raw_state) is int and 0 <= raw_state <= 0xFFFFFFFF,
             'PlcState must fit its original UInt32 underlying type.')
    return struct.pack('<I', raw_state)


def decode_plc_response(method: str, payload: bytes, *, version: int = 4) -> int | None:
    """Return a raw UInt32 PlcState or None for a strictly empty void body."""
    _profile(method, version)
    _require(type(payload) is bytes, 'response values must be exact bytes.')
    if method != 'GetPlcState':
        _require(payload == b'', 'unexpected Reset/Load void response bytes.')
        return None
    _require(len(payload) == 4, 'PlcState response must contain exactly four bytes.')
    return struct.unpack('<I', payload)[0]
