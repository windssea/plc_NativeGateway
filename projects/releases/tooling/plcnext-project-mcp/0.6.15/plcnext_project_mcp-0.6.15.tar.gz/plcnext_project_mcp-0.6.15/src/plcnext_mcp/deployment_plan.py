"""Read-only deployment gap analysis bound to a managed revision and build.

No network imports, vendor execution, device discovery or controller writes.
An IEC image is not treated as a complete PCWE deployment directory.
"""
from __future__ import annotations

import json
import hashlib
from pathlib import Path, PurePosixPath
import re
from urllib.parse import unquote
import zipfile

from .deployment_package import REQUIRED_FILES
from .project import ProjectError, ProjectStore, pou_index, sha, xml


REQUIRED_PCWE = REQUIRED_FILES


def _file(root: Path, name: str) -> Path:
    if (not isinstance(name, str) or not name or '\\' in name or ':' in name or '\x00' in name
            or PurePosixPath(name).is_absolute() or any(p in ('', '.', '..') for p in name.split('/'))):
        raise ProjectError('Unsafe path in build evidence.')
    target = root.joinpath(*name.split('/'))
    for item in (target, *target.parents):
        if item.is_symlink() or (hasattr(item, 'is_junction') and item.is_junction()):
            raise ProjectError('Build evidence must not traverse links or junctions.')
        if item == root:
            break
    if not target.resolve().is_relative_to(root.resolve()):
        raise ProjectError('Build evidence escapes its job directory.')
    return target


def _verify(root: Path, name: str, expected: str) -> Path:
    if not isinstance(expected, str) or re.fullmatch(r'[0-9a-f]{64}', expected) is None:
        raise ProjectError('Invalid SHA256 in build evidence.')
    path = _file(root, name)
    if not path.is_file() or path.stat().st_size > 512 * 1024 * 1024:
        raise ProjectError('Missing or oversized build evidence: ' + name)
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            size += len(chunk)
            if size > 512 * 1024 * 1024:
                raise ProjectError('Oversized build evidence: ' + name)
            digest.update(chunk)
    if digest.hexdigest() != expected:
        raise ProjectError('Build input/output changed or is missing: ' + name)
    return path


def _library_candidates(path: Path, device_type: str) -> list[dict]:
    """Report source-bound native payload choices; never guess compatibility."""
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        if len(infos) > 10000 or sum(i.file_size for i in infos) > 256 * 1024 * 1024:
            raise ProjectError('Library package exceeds inspection limits.')
        if len({i.filename.casefold() for i in infos}) != len(infos):
            raise ProjectError('Library has ambiguous duplicate member names.')
        project_name = 'PROJECT/PROJECT.proj'
        project = xml(archive.read(project_name)) if project_name in archive.namelist() else None
        profiles = []
        if project is not None:
            for item in project.iter():
                if item.tag.rsplit('}', 1)[-1] != 'Folder' or not item.get('Include'):
                    continue
                prefix = item.get('Include').replace('\\', '/').rstrip('/')
                for node in item.iter():
                    if node.tag.rsplit('}', 1)[-1] == 'DeviceProfile':
                        values = {child.tag.rsplit('}', 1)[-1]: child.text for child in node}
                        if values.get('DeviceProfileType'):
                            profiles.append((prefix, values))
        result = []
        for item in infos:
            if not item.filename.lower().endswith('.so'):
                continue
            member = unquote(item.filename)
            matches = [value for key, value in profiles
                       if member.startswith('PROJECT/' + key + '/') or member.startswith(key + '/')]
            # Keep unidentified candidates, so unknown metadata never hides a dependency.
            relevant = [value for value in matches if value.get('DeviceProfileType') == device_type]
            if matches and device_type and not relevant:
                continue
            selected_profiles = relevant if device_type else matches
            profile = selected_profiles[0] if len(selected_profiles) == 1 else {}
            result.append({'member': item.filename, 'bytes': item.file_size,
                           'sha256': sha(archive.read(item)),
                           'device_profile_type': profile.get('DeviceProfileType'),
                           'device_profile_version': profile.get('DeviceProfileVersion'),
                           'device_profiles': selected_profiles,
                           'selected_for_deployment': False})
        return result


def deployment_plan(store: ProjectStore, project_id: str, expected_project_sha256: str,
                    build_job_id: str) -> dict:
    if not isinstance(build_job_id, str) or re.fullmatch(r'[0-9a-f]{32}', build_job_id) is None:
        raise ProjectError('Invalid build_job_id; use job_id returned by project_compile.')
    folder = store._folder(project_id)
    with store._lock(folder):
        folder, manifest, members, _, _ = store._current(project_id)
        if manifest['current_sha256'] != expected_project_sha256:
            raise ProjectError('Stale project hash; inspect the current revision again.')
        report_path = _file(folder, 'builds/' + build_job_id + '/result.json')
        if not report_path.is_file() or report_path.stat().st_size > 16 * 1024 * 1024:
            raise ProjectError('Build report missing or too large.')
        try:
            report_bytes = report_path.read_bytes()
            report = json.loads(report_bytes.decode('utf-8'))
        except (ValueError, UnicodeError) as exc:
            raise ProjectError('Invalid build report JSON.') from exc
        if not isinstance(report, dict):
            raise ProjectError('Invalid build report structure.')
        if any(report.get(key) != value for key, value in {
            'project_id': project_id, 'job_id': build_job_id,
            'project_sha256': expected_project_sha256,
        }.items()):
            raise ProjectError('Build report does not belong to this exact project revision/job.')
        if report.get('compiled') is not True or report.get('build_mode') != 'cold':
            raise ProjectError('A successful cold build is required before deployment planning.')
        resource = report.get('resource_name', '')
        if not isinstance(resource, str) or re.fullmatch(r'RES_[0-9A-Fa-f]{32}', resource) is None:
            raise ProjectError('Unsupported resource identity in build evidence.')
        job = report_path.parent
        inputs = report.get('input_hashes')
        outputs = report.get('generated_files')
        if not isinstance(inputs, dict) or not inputs or not isinstance(outputs, list) or not outputs:
            raise ProjectError('Build evidence has no source/output inventory.')
        if len(inputs) + len(outputs) > 20000:
            raise ProjectError('Build evidence inventory exceeds inspection limits.')
        for name, digest in inputs.items():
            _verify(job, name, digest)
        # Bind the build snapshot to every current source member, not only the report label.
        for name, payload in members.items():
            if name.endswith('/'):
                continue
            if inputs.get('project/' + name) != sha(payload):
                raise ProjectError('Build source snapshot differs from the managed revision: ' + name)
        index = pou_index(members)
        source_path = _verify(job, 'sources.xml', inputs.get('sources.xml'))
        if source_path.stat().st_size > 16 * 1024 * 1024:
            raise ProjectError('Oversized source manifest.')
        source_manifest = xml(source_path.read_bytes())
        nodes = source_manifest.findall('POU')
        if source_manifest.tag != 'Sources' or len(nodes) != len(index) or {n.get('name') for n in nodes} != set(index):
            raise ProjectError('Compiler source manifest does not match current POUs.')
        for node in nodes:
            name = node.get('name')
            pou = index[name]
            if node.get('prefix') != pou['prefix'] or node.get('kind') != pou['kind']:
                raise ProjectError('Compiler POU identity differs from current project: ' + name)
            for key, suffix in (('code', 'Code.st'), ('variables', 'Variables.var'), ('metadata', 'Metadata.meta')):
                relative = f'sources/{name}/{suffix}'
                digest = sha(members[pou['prefix'] + suffix])
                if inputs.get(relative) != digest or node.get(key) != relative or node.get(key + '_sha256') != digest:
                    raise ProjectError('Compiler POU source differs from current project: ' + relative)
        names = set()
        for item in outputs:
            if not isinstance(item, dict):
                raise ProjectError('Invalid generated output inventory.')
            name = item.get('name', '')
            if not isinstance(name, str) or '/' in name or name.casefold() in names:
                raise ProjectError('Ambiguous generated output inventory.')
            names.add(name.casefold())
            _verify(job, 'generated/' + name, item.get('sha256'))
        image_name = resource + '.img'
        if image_name.casefold() not in names:
            raise ProjectError('Build output inventory omits the compiled image.')
        image = _verify(job, 'generated/' + image_name, report.get('image_sha256'))
        libraries = []
        capability = report.get('capability')
        if not isinstance(capability, dict) or not isinstance(capability.get('device'), str):
            raise ProjectError('Build report lacks the target device capability.')
        device = capability['device'].replace(' ', '')
        for relative, digest in sorted(inputs.items()):
            if relative.startswith('libraries/') and relative.endswith(('.pcwlx', '.pxclx')):
                candidates = _library_candidates(_file(job, relative), device)
                if candidates:
                    libraries.append({'archive': relative, 'archive_sha256': digest,
                                      'native_candidates': candidates})
        missing = [name for name in REQUIRED_PCWE
                   if not _file(job, 'Configuration/Projects/PCWE/' + name).is_file()]
        mappings = [{'member': name, 'sha256': sha(payload)} for name, payload in sorted(members.items())
                    if name.endswith(('DataList.dl', 'EsmConfiguration.esmc', 'IOConfiguration.ioc'))]
        issues = []
        if missing:
            issues.append({'code': 'complete_pcwe_missing', 'missing_files': missing})
        if libraries:
            issues.append({'code': 'native_library_selection_and_staging_unverified',
                           'library_count': len(libraries)})
        issues.extend([
            {'code': 'source_to_runtime_mapping_generation_unverified'},
            {'code': 'device_compatibility_limits_and_integrity_policy_unverified'},
            {'code': 'controller_transport_not_implemented'},
        ])
        return store._identity(folder, manifest) | {
            'build_job_id': build_job_id, 'status': 'deployment_blocked',
            'build_receipt_sha256': sha(report_bytes),
            'compiled': True, 'pou_count': len(index),
            'source_and_generated_hashes_verified': True, 'checked_build_inputs': len(inputs),
            'checked_generated_outputs': len(outputs), 'image_path': str(image),
            'image_sha256': report['image_sha256'], 'missing_pcwe_files': missing,
            'native_libraries': libraries, 'source_mapping_members': mappings,
            'blocking_issues': issues, 'deployable': False,
            'controller_connected': False, 'controller_downloaded': False,
            'network_operations_performed': 0,
            'next_steps': [
                'Generate and verify complete PCWE configuration from this revision; do not overlay this image onto unrelated GUI binaries.',
                'Resolve native library device compatibility and preserve their exact package identity.',
                'Validate runtime task/GDS/I/O bindings, integrity manifests and applicable signatures.',
                'Implement authenticated controller transport and verify on an explicitly authorized test device.',
            ],
        }
