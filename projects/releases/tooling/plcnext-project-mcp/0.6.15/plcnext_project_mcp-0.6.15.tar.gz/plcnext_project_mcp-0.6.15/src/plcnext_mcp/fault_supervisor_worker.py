"""Owned-loopback fixture process. No PLC, MQTT, broker or Hub integration.

Its monotonic TTL runs independently of the fault client's lifetime. The two
synthetic fault states only affect this fixture's own booleans.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
from pathlib import Path
import socket
import sys
import time

MAX_REQUEST = 4096


def run(config):
    root = Path(config['root']).resolve(strict=True)
    token = config['token']
    identity = {'boot_id': config['boot_id'], 'inventory_sha256': config['inventory_sha256']}
    fault = config['fixture_fault']
    events = []
    state = {'schema': 'plcnext-owned-fault-supervisor-state/v1', **identity,
             'active': False, 'fault': None, 'request_id': None, 'deadline_monotonic_ns': None,
             'release_verified': True, 'release_failed': False, 'data_submission_enabled': True,
             'business_ack_enabled': True, 'network_scope': 'owned_loopback_fixture_only'}
    seen = set()
    started = time.monotonic_ns()
    lifetime_end = started + int(config['maximum_lifetime_seconds'] * 1e9)

    def persist():
        record = dict(state, events=list(events), observed_monotonic_ns=time.monotonic_ns(),
                      supervisor_pid=os.getpid(), clock_domain='this_supervisor_process_only',
                      tick_resolution_ns=10000000)
        path = root / 'state.json'
        temporary = root / 'state.next.json'
        temporary.write_text(json.dumps(record, ensure_ascii=False), encoding='utf-8')
        temporary.replace(path)
        return record

    def release(reason):
        if not state['active']:
            return
        now = time.monotonic_ns()
        if fault == 'release_failure':
            state.update(release_failed=True, release_verified=False)
            if not events or events[-1]['operation'] != 'release_failed':
                events.append({'operation': 'release_failed', 'reason': reason, 'monotonic_ns': now})
            return
        state.update(active=False, data_submission_enabled=True, business_ack_enabled=True,
                     release_verified=True, released_monotonic_ns=now, release_reason=reason)
        events.append({'operation': 'released', 'reason': reason, 'monotonic_ns': now})

    def check_deadline():
        if state['active'] and time.monotonic_ns() >= state['deadline_monotonic_ns']:
            release('hard_ttl')

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(('127.0.0.1', 0))
    listener.listen(4)
    listener.settimeout(0.01)
    address, port = listener.getsockname()
    print(json.dumps({'address': address, 'port': port, 'pid': os.getpid()}), flush=True)
    persist()
    try:
        while time.monotonic_ns() < lifetime_end:
            check_deadline()
            persist()
            try:
                channel, peer = listener.accept()
            except socket.timeout:
                continue
            with channel:
                if peer[0] != '127.0.0.1':
                    continue
                channel.settimeout(0.1)
                payload = bytearray()
                try:
                    while b'\n' not in payload and len(payload) <= MAX_REQUEST:
                        block = channel.recv(min(1024, MAX_REQUEST + 1-len(payload)))
                        if not block:
                            break
                        payload.extend(block)
                    check_deadline()
                    if len(payload) > MAX_REQUEST or not payload.endswith(b'\n'):
                        raise ValueError('bounded complete request required')
                    request = json.loads(payload)
                    supplied = request.pop('token', None)
                    if type(supplied) is not str or not hmac.compare_digest(supplied, token):
                        raise ValueError('fixture capability rejected')
                    operation = request.get('operation')
                    if operation == 'observe' and set(request) == {'operation'}:
                        response = persist()
                    elif operation == 'activate' and set(request) == {'operation','request_id','boot_id','inventory_sha256','fault','ttl_ms'}:
                        if (request['boot_id'] != identity['boot_id'] or request['inventory_sha256'] != identity['inventory_sha256']):
                            raise ValueError('boot or program identity changed')
                        if state['active'] or state['release_failed']:
                            raise ValueError('fault active or unresolved release failure')
                        if request['request_id'] in seen or len(seen) >= 32:
                            raise ValueError('duplicate or exhausted fixture lease identity')
                        if request['fault'] not in ('agent_connection_offline', 'business_ack_blocked'):
                            raise ValueError('fault outside fixed whitelist')
                        ttl = request['ttl_ms']
                        if type(ttl) is not int or not 100 <= ttl <= 300000:
                            raise ValueError('fault TTL must be 100..300000 ms')
                        now = time.monotonic_ns()
                        deadline = now + ttl * 1000000
                        if deadline > lifetime_end - 100000000:
                            raise ValueError('fixture lifetime cannot supervise the entire requested TTL')
                        seen.add(request['request_id'])
                        state.update(active=True, fault=request['fault'], request_id=request['request_id'],
                            started_monotonic_ns=now, deadline_monotonic_ns=deadline, release_verified=False,
                            data_submission_enabled=request['fault'] != 'agent_connection_offline',
                            business_ack_enabled=False)
                        events.append({'operation':'activated','fault':request['fault'],'request_id':request['request_id'],
                                       'monotonic_ns':now,'deadline_monotonic_ns':deadline})
                        response = persist()
                    elif operation == 'cancel' and set(request) == {'operation','request_id','boot_id'}:
                        if request['request_id'] != state['request_id'] or request['boot_id'] != identity['boot_id']:
                            raise ValueError('cancel belongs to another fault or boot')
                        release('explicit_cancel')
                        response = persist()
                    elif operation == 'fixture_boot_change' and set(request) == {'operation','new_boot_id'}:
                        release('boot_changed')
                        identity['boot_id'] = request['new_boot_id']
                        state['boot_id'] = identity['boot_id']
                        response = persist()
                    elif operation == 'shutdown' and set(request) == {'operation'}:
                        release('fixture_shutdown')
                        response = persist()
                        channel.sendall(json.dumps({'status':'ok','state':response}).encode()+b'\n')
                        break
                    else:
                        raise ValueError('unknown fixture operation or fields')
                    channel.sendall(json.dumps({'status':'ok','state':response}).encode()+b'\n')
                except (ValueError, TypeError, KeyError, OSError) as exc:
                    try:
                        channel.sendall(json.dumps({'status':'rejected','error':str(exc)}).encode()+b'\n')
                    except OSError:
                        pass
    finally:
        release('fixture_exit')
        persist()
        listener.close()


def main():
    # Configuration is a private, bounded parent-to-child pipe; never argv/logs.
    line = sys.stdin.buffer.readline(8193)
    if not line.endswith(b'\n') or len(line) > 8192:
        raise ValueError('Invalid fixture initialization.')
    config = json.loads(line)
    run(config)


if __name__ == '__main__':
    main()
