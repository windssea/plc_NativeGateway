"""M08 fixed system-variable reads, bound to the shipped AXCF2152/2026 types.

No separate ESM RPC is invented: the existing read-only DataAccess transport
reads ESM_DATA fields already declared in the reviewed source. Runtime export,
timing units and performance acceptance remain explicit evidence boundaries.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import time
import uuid

from .project import ProjectError,sha,xml
from .runtime_monitor import (_source,_canonical,prepare_runtime_read_plan,load_runtime_read_plan,
    read_runtime_plan,RuntimeReadClient,observe_runtime_plan)
from .controller_transport import ControllerEndpoint
from .operation_jobs import _process_birth

SCHEMA='plcnext-esm-system-read-plan/v1'
PROFILE={'id':'axcf2152-2026-existing-esm-data/v1',
    'template_name':'AXCF215200260.pxctx',
    'template_sha256':'dedd33bfab3a7de4a3ecb08f7b47281b63d7980be84c15179dda50ce86cb9657',
    'generated_types_sha256':'8739c35b6d76e20248e95952198eb9ea7ea9253368560ef80047946a1e3ec796',
    'esm_index_range':[1,2],'task_index_range':[1,16],
    'threshold_counter_wire_type':'uint32','default_string_capacity':80,
    'units_reference':'https://engineer.plcnext.help/2025.0_en/UI_PLANT_Devices_Controller_iC9226EC_Node.htm',
    'device_export_verified':False,'device_timing_units_verified':False}
FIELDS=['INTERVAL','PRIORITY','WATCHDOG','LAST_EXEC_DURATION','MIN_EXEC_DURATION','MAX_EXEC_DURATION',
    'LAST_ACTIVATION_DELAY','MIN_ACTIVATION_DELAY','MAX_ACTIVATION_DELAY','EXEC_TIME_THRESHOLD',
    'EXEC_TIME_THRESHOLD_CNT','NAME']


def _indices(esms,tasks):
    for values,maximum in ((esms,2),(tasks,16)):
        if (type(values) is not list or not values or len(values)>maximum or len(set(values))!=len(values)
                or any(type(v) is not int or not 1<=v<=maximum for v in values)):
            raise ProjectError('Explicit unique ESM 1..2 / task 1..16 indices are required.')


def _symbols(esms,tasks):
    symbols=['ESM_DATA.ESM_COUNT','ESM_DATA.EXCEPTION_COUNT']
    for esm in esms:
        symbols.append(f'ESM_DATA.ESM_INFOS[{esm}].TASK_COUNT')
        symbols += [f'ESM_DATA.ESM_INFOS[{esm}].TASK_INFOS[{task}].{field}' for task in tasks for field in FIELDS]
    return symbols


def _profile_source(store,project_id,digest):
    folder,manifest,model=_source(store,project_id,digest)
    _,_,members,_,_=store._current(project_id)
    generated=[v for n,v in members.items() if n.endswith('/GeneratedDataTypes.dt')]
    if len(generated)!=1 or sha(generated[0])!=PROFILE['generated_types_sha256']:
        raise ProjectError('ESM read profile requires the exact verified AXCF2152/2026 generated system types.')
    if model.roots.get('esm_data',{}).get('type')!='ESM_DAT':
        raise ProjectError('Reviewed source does not already declare ESM_DATA:ESM_DAT; no source injection is performed.')
    esm_files=[v for n,v in members.items() if n.endswith('/EsmConfiguration.esmc')]
    root=xml(esm_files[0]);esms={e.get('id'):e.get('name') for e in root.findall('./Esms/Esm')}
    tasks=[]
    for task in root.findall('./Tasks/Task'):
        esm_name=esms.get(task.get('esmId'),'')
        match=re.fullmatch('ESM([12])',esm_name)
        if not match:raise ProjectError('Unsupported ESM identity for this fixed system profile.')
        tasks.append({'name':task.get('name'),'id':task.get('id'),'esm_name':esm_name,'esm_index':int(match[1]),
            'interval_ns':int(task.get('intervalTime')),'watchdog_ns':int(task.get('watchdogTime')),
            'priority':int(task.get('priority'))})
    return folder,model,tasks


def prepare_esm_read_plan(store,project_id,expected_project_sha256,address,expected_certificate_sha256,
        *,port=41100,esm_indices=None,task_indices=None):
    folder,model,tasks=_profile_source(store,project_id,expected_project_sha256)
    esms=sorted({t['esm_index'] for t in tasks}) if esm_indices is None else esm_indices
    indices=list(range(1,17)) if task_indices is None else task_indices
    _indices(esms,indices)
    symbols=_symbols(esms,indices)
    for symbol in symbols:model.resolve(symbol)  # Every path/type is validated before planning.
    monitor=prepare_runtime_read_plan(store,project_id,expected_project_sha256,address,
        expected_certificate_sha256,symbols=symbols,port=port,point_count=250,include_samples=False)
    plan_id=uuid.uuid4().hex
    plan={'schema':SCHEMA,'plan_id':plan_id,'project_id':project_id,'project_sha256':expected_project_sha256,
        'target':monitor['target'],'profile':PROFILE,'source_tasks':tasks,'esm_indices':esms,
        'task_indices':indices,'monitor':{'plan_id':monitor['plan_id'],'plan_sha256':monitor['plan_sha256']},
        'system_symbols':symbols,'read_only':True,'source_modified':False,'p06_resumed':False}
    plan['plan_sha256']=sha(_canonical(plan))
    directory=folder/'esm-read-plans'/plan_id;directory.mkdir(parents=True,exist_ok=False)
    path=directory/'plan.json';path.write_bytes(_canonical(plan)+b'\n')
    return plan|{'plan_path':str(path),'controller_connected':False}


def load_esm_read_plan(store,project_id,plan_id,digest):
    if type(plan_id) is not str or re.fullmatch('[0-9a-f]{32}',plan_id) is None:raise ProjectError('Invalid ESM read plan ID.')
    path=store._folder(project_id)/'esm-read-plans'/plan_id/'plan.json'
    if not path.is_file() or path.stat().st_size>1024*1024:raise ProjectError('Missing or oversized ESM plan.')
    plan=json.loads(path.read_bytes())
    if (plan.get('schema')!=SCHEMA or plan.get('project_id')!=project_id or plan.get('plan_id')!=plan_id
            or plan.get('plan_sha256')!=digest or sha(_canonical({k:v for k,v in plan.items() if k!='plan_sha256'}))!=digest
            or plan.get('profile')!=PROFILE):raise ProjectError('ESM plan identity/profile changed.')
    _,_,tasks=_profile_source(store,project_id,plan['project_sha256'])
    if plan['source_tasks']!=tasks:raise ProjectError('ESM source task identities changed.')
    _indices(plan['esm_indices'],plan['task_indices'])
    if plan['system_symbols']!=_symbols(plan['esm_indices'],plan['task_indices']):
        raise ProjectError('ESM fixed system-variable path set changed.')
    ref=plan['monitor'];monitor=load_runtime_read_plan(store,project_id,ref['plan_id'],ref['plan_sha256'])
    if (monitor['target']!=plan['target'] or monitor['project_sha256']!=plan['project_sha256']
            or [item['symbol'] for item in monitor['requests']]!=plan['system_symbols']):
        raise ProjectError('ESM monitor target/source/symbol binding changed.')
    return plan


def analyze_esm_observation(plan,observation,*,previous=None):
    values={row['symbol']:row['value'] for row in observation.get('items',[]) if row.get('status')=='read'}
    rows=[];holes=[];source={(t['esm_index'],t['name']):t for t in plan['source_tasks']}
    coherent=observation.get('consistency')=='guarded_window_observation' and observation.get('status') in ('monitor_read_completed','monitor_read_partial')
    for esm in plan['esm_indices']:
        if values.get(f'ESM_DATA.ESM_INFOS[{esm}].TASK_COUNT') is None:
            holes.append({'esm_index':esm,'missing_fields':['TASK_COUNT']})
        for index in plan['task_indices']:
            prefix=f'ESM_DATA.ESM_INFOS[{esm}].TASK_INFOS[{index}].'
            item={'esm_index':esm,'task_index':index,'values':{f:values.get(prefix+f) for f in FIELDS}}
            name=item['values']['NAME'];expected=source.get((esm,name))
            missing=[field for field,value in item['values'].items() if value is None]
            if missing:holes.append({'esm_index':esm,'task_index':index,'missing_fields':missing})
            item.update(status='unsupported_or_partial' if missing else 'inactive_slot' if name=='' else 'read',
                source_task_name_matches=expected is not None,source_scheduling_matches=None)
            if expected is not None and not missing:
                representable=expected['interval_ns']%1000==0 and expected['watchdog_ns']%1000==0
                item['source_scheduling_matches']=representable and all(item['values'][field]==value for field,value in {
                    'INTERVAL':expected['interval_ns']//1000,'WATCHDOG':expected['watchdog_ns']//1000,'PRIORITY':expected['priority']}.items())
            rows.append(item)
    guard={x['symbol']:x.get('value') for x in observation.get('guards_after',[]) if x.get('status')=='read'}
    for name in ('ESM_COUNT','EXCEPTION_COUNT'):
        if values.get('ESM_DATA.'+name) is None:holes.append({'missing_fields':[name]})
    result={'schema':'plcnext-esm-system-observation/v1','status':'esm_read_completed' if coherent and not holes else
        'snapshot_invalidated' if observation.get('status')=='snapshot_invalidated' else 'esm_read_incomplete',
        'project_id':plan['project_id'],'source_project_sha256':plan['project_sha256'],
        'plan_id':plan['plan_id'],'plan_sha256':plan['plan_sha256'],'target':plan['target'],'profile':PROFILE,
        'runtime_observation':{k:observation.get(k) for k in ('observation_id','observation_sha256','report_path','status','consistency')},
        'task_rows':rows,'sampling_holes':holes,'guard_identity':guard,
        'esm_count':values.get('ESM_DATA.ESM_COUNT'),'exception_count':values.get('ESM_DATA.EXCEPTION_COUNT'),
        'expected_source_task_names':[x['name'] for x in plan['source_tasks']],
        'all_source_task_bindings_observed':coherent and all(sum(row['values']['NAME']==task['name'] and row['esm_index']==task['esm_index']
            and row['source_scheduling_matches'] is True for row in rows)==1 for task in plan['source_tasks']),
        'duration_units':'microseconds_per_documented_profile','duration_semantics':'elapsed_task_execution_including_preemption',
        'new_work_cpu_microseconds':None,'whole_task_cpu_microseconds':None,
        'watchdog_trigger_count':None,'threshold_count_is_watchdog_or_cycle_overrun_count':False,
        'counter_width_bits':32,'counter_epoch_comparison':'no_previous_observation','counter_deltas':[],
        'host_window':{'started_monotonic_ns':observation.get('started_monotonic_ns'),
            'finished_monotonic_ns':observation.get('finished_monotonic_ns'),'batch_windows':observation.get('batch_windows',[]),
            'clock_domain':{'pid':os.getpid(),'process_birth':_process_birth(os.getpid())}},
        'sampling_gap':{'status':'no_previous_window','gap_seconds':None,'every_task_cycle_observed':False},
        'performance_pass':False,'p06_resumed':False,'atomic_snapshot':False,
        'monitoring_impact_on_plc_task_verified':False,'device_connected':observation.get('controller_connected',False)}
    if previous is not None:
        comparable=(previous.get('target')==plan['target'] and previous.get('source_project_sha256')==plan['project_sha256']
            and previous.get('guard_identity')==guard and bool(guard) and coherent and previous.get('status')=='esm_read_completed')
        result['counter_epoch_comparison']='same_guarded_epoch_window' if comparable else 'unknown_boot_config_source_or_window_changed'
        old_window=previous.get('host_window',{});new_window=result['host_window']
        if (new_window['clock_domain']['process_birth'] is not None and old_window.get('clock_domain')==new_window['clock_domain']
                and type(old_window.get('finished_monotonic_ns')) is int and type(new_window['started_monotonic_ns']) is int):
            gap=(new_window['started_monotonic_ns']-old_window['finished_monotonic_ns'])/1000000000
            result['sampling_gap'].update(gap_seconds=gap if gap>=0 else None,
                status='overlapping_or_clock_mismatch' if gap<0 else 'gap_exceeds_30s' if gap>30 else 'observed_host_window_gap')
        else:result['sampling_gap']['status']='unknown_clock_domain'
        prior={(x['esm_index'],x['task_index']):x for x in previous.get('task_rows',[])}
        for row in rows:
            old=prior.get((row['esm_index'],row['task_index']))
            now=row['values']['EXEC_TIME_THRESHOLD_CNT'];before=old['values'].get('EXEC_TIME_THRESHOLD_CNT') if old else None
            valid=comparable and old and old['values'].get('NAME')==row['values']['NAME'] and type(now) is int and type(before) is int
            reset=valid and (now<before or type(old['values'].get('MAX_EXEC_DURATION')) is int
                and type(row['values']['MAX_EXEC_DURATION']) is int
                and row['values']['MAX_EXEC_DURATION']<old['values']['MAX_EXEC_DURATION'])
            result['counter_deltas'].append({'esm_index':row['esm_index'],'task_index':row['task_index'],
                'delta':now-before if valid and not reset else None,
                'status':'unknown_reset_or_wrap' if reset else 'observed_window_delta' if valid else 'unknown'})
    return result


def read_esm_plan(store,project_id,plan_id,expected_plan_sha256,*,previous_observation_id=None,expected_previous_sha256=None):
    plan=load_esm_read_plan(store,project_id,plan_id,expected_plan_sha256)
    previous=None
    if previous_observation_id is not None:
        if type(previous_observation_id) is not str or re.fullmatch('[0-9a-f]{32}',previous_observation_id) is None:
            raise ProjectError('Invalid previous ESM observation ID.')
        path=store._folder(project_id)/'esm-observations'/previous_observation_id/'result.json'
        if not path.is_file() or path.stat().st_size>8*1024*1024:raise ProjectError('Missing previous ESM observation.')
        previous=json.loads(path.read_bytes())
        if (previous.get('observation_sha256')!=expected_previous_sha256 or sha(_canonical({k:v for k,v in previous.items() if k!='observation_sha256'}))!=expected_previous_sha256):
            raise ProjectError('Previous ESM observation hash changed.')
    ref=plan['monitor'];observation=read_runtime_plan(store,project_id,ref['plan_id'],ref['plan_sha256'])
    result=analyze_esm_observation(plan,observation,previous=previous)
    load_esm_read_plan(store,project_id,plan_id,expected_plan_sha256)
    directory=store._folder(project_id)/'esm-observations'/uuid.uuid4().hex;directory.mkdir(parents=True,exist_ok=False)
    result.update(observation_id=directory.name,report_path=str(directory/'result.json'))
    result['observation_sha256']=sha(_canonical(result));(directory/'result.json').write_bytes(_canonical(result)+b'\n')
    return result


def test_esm_read_plan(store,project_id,expected_project_sha256,*,fault='none'):
    from .runtime_test_peer import LocalRuntimeController
    if fault not in ('none','missing_field','boot_change','wrong_task_name'):raise ProjectError('Unsupported ESM fixture fault.')
    folder,model,tasks=_profile_source(store,project_id,expected_project_sha256)
    if not tasks:raise ProjectError('ESM fixture requires at least one configured source task.')
    directory=folder/'esm-read-tests'/uuid.uuid4().hex;directory.mkdir(parents=True,exist_ok=False)
    with LocalRuntimeController(directory/'peer',{},fault='boot_change' if fault=='boot_change' else 'none') as peer:
        p=prepare_esm_read_plan(store,project_id,expected_project_sha256,peer.address,peer.certificate_sha256,
            port=peer.port,esm_indices=sorted({t['esm_index'] for t in tasks}),task_indices=[1])
        ref=p['monitor'];monitor=load_runtime_read_plan(store,project_id,ref['plan_id'],ref['plan_sha256'])
        for d in [*monitor['requests'],*monitor['guards']]:
            t=d['wire_type'];value='PUBLIC-boot' if d['symbol'].endswith('.BootId') else '' if t=='utf8' else True if t=='bool' else 1
            for task in tasks:
                prefix=f"ESM_DATA.ESM_INFOS[{task['esm_index']}].TASK_INFOS[1]."
                if d['symbol'].startswith(prefix):
                    field=d['symbol'][len(prefix):]
                    value={'INTERVAL':task['interval_ns']//1000,'WATCHDOG':task['watchdog_ns']//1000,'PRIORITY':task['priority'],
                        'NAME':task['name'],'LAST_EXEC_DURATION':850,'MIN_EXEC_DURATION':600,'MAX_EXEC_DURATION':1200,
                        'EXEC_TIME_THRESHOLD_CNT':3}.get(field,0)
                    if fault=='wrong_task_name' and field=='NAME':value='PUBLIC-wrong-task'
            if fault=='missing_field' and d['symbol'].endswith('.MAX_EXEC_DURATION'):continue
            peer.values[d['path']]={'wire_type':t,'value':value}
        ep=ControllerEndpoint(peer.address,peer.port,peer.certificate_sha256)
        allowed=sorted({d['path'] for d in [*monitor['requests'],*monitor['guards']]})
        observation=observe_runtime_plan(RuntimeReadClient(ep,allowed),monitor)
        result=analyze_esm_observation(p,observation)
        result.update(test_environment='owned_loopback_fixture',real_controller_connected=False,fault=fault,
            fixture_trace=peer.trace,fixture_errors=peer.errors)
        result['test_passed']=(result['status']=='snapshot_invalidated' if fault=='boot_change' else
            result['status']=='esm_read_incomplete' if fault=='missing_field' else
            not result['all_source_task_bindings_observed'] if fault=='wrong_task_name' else
            result['status']=='esm_read_completed' and result['all_source_task_bindings_observed'])
    result.update(report_path=str(directory/'result.json'));(directory/'result.json').write_bytes(_canonical(result)+b'\n')
    return result
