"""Own TLS peer and independent synthetic PLC-scan model for the fault profile.

The model does not execute IEC code or operate MQTT. Cold compilation of the
actual inserted FB is verified separately. No external endpoint is accepted.
"""
from __future__ import annotations

import threading
import time

from . import rsc_tagged_codec as tagged
from .controller_test_peer import LocalTlsController
from .controller_transport import PLC,PROVIDER
from .fault_profile import PROFILE_VERSION,READABLE,WRITABLE
from .rsc_codec import CommandType,DATA_TAGGING,DATAGRAMMING,decode_header
from .rsc_fault_write_codec import receive_fault_write
from .rsc_runtime_codec import DATA_ACCESS,PLC_INFO,encode_read_items,encode_variant
from .runtime_test_peer import encode_header_for_reply

FAULTS={'none','wrong_profile','wrong_boot','commit_reply_lost','stage_mismatch','release_failure','plc_stopped','clock_frozen'}


class FaultScanModel:
    def __init__(self,profile_id):
        self.values={name:('' if kind=='utf8' else False if kind=='bool' else 0) for name,kind in READABLE.items()}
        self.values.update(ProfileVersion=PROFILE_VERSION,ProfileId=profile_id,CurrentBoot='PUBLIC-boot-1',Ready=True,AgentConnected=True)
        self.stage=None;self.last_now=0;self.active_boot='';self.active_kind=0

    def scan(self,now,*,release_failure=False):
        v=self.values;v['NowMs']=now;v['BlockConnection']=v['BlockBusinessAck']=False
        if v['Active']:
            reason=(4 if not v['Ready'] or not v['CurrentBoot'] else 3 if v['CurrentBoot']!=self.active_boot else
                5 if now<self.last_now else 2 if v['CancelId']==v['ActiveId'] else 1 if now>=v['DeadlineMs'] else 0)
            if reason and not release_failure:
                v.update(Active=False,ReleasedId=v['ActiveId'],ReleaseReason=reason)
        current=(v['CommitId'],v['RequestId'],v['RequestBootId'],v['RequestKind'],v['RequestTtlMs'],v['RequestDeadlineMs'])
        if v['CommitId']>v['SeenId'] and v['CommitId']!=0:
            if self.stage==current:
                v['SeenId']=v['CommitId']
                if (not v['Active'] and v['Ready'] and v['CurrentBoot'] and v['RequestBootId']==v['CurrentBoot']
                        and v['RequestId']==v['CommitId'] and v['RequestKind'] in (1,2)
                        and 100<=v['RequestTtlMs']<=300000 and now>=self.last_now
                        and now<v['RequestDeadlineMs']<=now+v['RequestTtlMs']):
                    v.update(Active=True,ActiveId=v['CommitId'],StartedAtMs=now,DeadlineMs=v['RequestDeadlineMs'],ReleaseReason=0)
                    self.active_boot=v['CurrentBoot'];self.active_kind=v['RequestKind']
                else:v['ReleaseReason']=6
            else:self.stage=current
        if v['Active']:
            v['BlockConnection']=self.active_kind==1;v['BlockBusinessAck']=self.active_kind==2
        v['AgentConnected']=not v['BlockConnection']
        self.last_now=now


class LocalFaultProfilePeer(LocalTlsController):
    def __init__(self,root,profile,*,fault='none'):
        if fault not in FAULTS:raise ValueError('Unknown instrumented fault fixture.')
        super().__init__(root,initial_state=2 if fault=='plc_stopped' else 3,allowed_files=set())
        self.profile=profile;self.profile_fault=fault;self.model=FaultScanModel(profile['profile_id'])
        if fault=='wrong_profile':self.model.values['ProfileId']='PUBLIC-wrong'
        if fault=='wrong_boot':self.model.values['CurrentBoot']='PUBLIC-wrong-boot'
        self.paths={d['path']:name for name,d in profile['symbols'].items()}
        self.field_writes=[];self.scan_lock=threading.Lock();self.scan_thread=None;self.started=time.monotonic()

    def start(self):
        super().start()
        def scans():
            while not self._stop.wait(0.02):
                if self.state==3:
                    with self.scan_lock:self.model.scan(0 if self.profile_fault=='clock_frozen' else int((time.monotonic()-self.started)*1000),release_failure=self.profile_fault=='release_failure')
        self.scan_thread=threading.Thread(target=scans,daemon=True,name='PUBLIC synthetic PLC scans')
        self.scan_thread.start();return self

    def close(self):
        super().close()
        if self.scan_thread is not None:self.scan_thread.join(timeout=2)

    def _session(self,channel):
        connected=False;handles={};provider=1788;next_handle=2100
        while not self._stop.is_set():
            raw=self._exact(channel,16);header,token=decode_header(raw,require_checksum=True)
            if header.command_type==CommandType.CONNECT_REQUEST:
                if connected or header.version!=4 or header.flags!=(DATA_TAGGING|DATAGRAMMING) or header.data_length:raise ValueError('Unexpected fixture Connect.')
                self._reply(channel,tagged.encode_connect_confirmation());connected=True;continue
            if not connected or token is not None or header.flags!=DATA_TAGGING:raise ValueError('Unexpected fixture profile.')
            if header.command_type==CommandType.GET_SERVICE_HANDLES_REQUEST:
                if not 0<=header.data_length<=2054:raise ValueError('Unbounded discovery.')
                names=tagged.decode_get_service(raw+self._exact(channel,header.data_length))
                if names[0]!=PROVIDER or names[1] not in (PLC,PLC_INFO,DATA_ACCESS):raise ValueError('Unknown fixture service.')
                if names[1] not in handles:handles[names[1]]=next_handle;next_handle+=1
                self._reply(channel,tagged.encode_get_service_confirmation(handles[names[1]],provider));continue
            service=next((name for name,value in handles.items() if value==header.service_handle),None)
            if header.command_type!=CommandType.INVOKE_REQUEST or header.service_provider_handle!=provider or header.data_length:raise ValueError('Unexpected fixture invoke.')
            if (service,header.method_handle)==(DATA_ACCESS,3):
                path,item=receive_fault_write(lambda n:channel.recv(n))
                name=self.paths.get(path)
                if name not in WRITABLE or item['wire_type']!=WRITABLE[name]:raise ValueError('Unreviewed fixture write field/type.')
                with self.scan_lock:
                    self.model.values[name]=item['value'];self.field_writes.append(name)
                    if self.profile_fault=='stage_mismatch' and name=='RequestId':self.model.values['RequestTtlMs']=999
                self._record('WriteSingle',field=name,mutating=True)
                if self.profile_fault=='commit_reply_lost' and name=='CommitId':raise EOFError('Synthetic Commit reply loss; PLC scans continue.')
                payload=b'\x05\x00\xff'
            elif (service,header.method_handle)==(DATA_ACCESS,2):
                paths=tagged.receive_values(lambda n:channel.recv(n),['utf8[]'])[0]
                if not 1<=len(paths)<=64:raise ValueError('Invalid snapshot count.')
                rows=[]
                with self.scan_lock:
                    for path in paths:
                        name=self.paths.get(path)
                        rows.append({'error_code':0,'wire_type':READABLE[name],'value':self.model.values[name]}
                            if name is not None else {'error_code':1,'wire_type':'null','value':None})
                payload=encode_read_items(rows)
            elif (service,header.method_handle)==(PLC,5):
                tagged.receive_values(lambda n:channel.recv(n),[]);payload=tagged.encode_values(['uint32'],[self.state])
            elif (service,header.method_handle)==(PLC_INFO,1):
                if tagged.receive_values(lambda n:channel.recv(n),['int32'])!=[1]:raise ValueError('Unexpected Info ID.')
                payload=encode_variant({'wire_type':'utf8','value':'PUBLIC fault profile'})+b'\xff'
            else:raise ValueError('Unknown fixture method; no arbitrary write/control.')
            self._reply(channel,encode_header_for_reply(header,payload))
