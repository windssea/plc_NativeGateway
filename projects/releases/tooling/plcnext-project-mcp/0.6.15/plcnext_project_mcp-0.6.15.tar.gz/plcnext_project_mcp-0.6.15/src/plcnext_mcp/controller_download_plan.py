"""Version/impact review for a future controller download; never authorization.

This module does no network I/O, loads no vendor code and cannot grant device
write permission. Its immutable review binds the exact managed revision, cold
build, package bytes, target IP/certificate and fixed full-load policy. An
operator confirmation must be handled separately by the calling application.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import ipaddress
from itertools import islice
import json
from pathlib import Path
import re
import uuid

from .deployment_plan import _file
from .download_simulation import _package_snapshot
from .project import ProjectError, sha, xml

SCHEMA = 'plcnext-controller-download-review/v1'
MAX_REVIEW_BYTES = 4 * 1024 * 1024
MAX_OBSERVATION_BYTES = 1024 * 1024
AUTHORIZATION_STATUS = 'awaiting_mcp_authorization'
POLICY = {
    'mode': 'full_pcwe_file_write_readback_reset_load',
    'authentication_mode': 'anonymous',
    'symbolic_project_root': '$ARP_PROJECTS_DIR$/PCWE/',
    'initial_stop_required': True,
    'automatic_stop': False,
    'automatic_start': False,
    'overwrite_package_paths': True,
    'skip_sha512_identical_files': True,
    'reject_changed_native_shared_libraries_before_write': True,
    'preserve_optional_src_project_and_pcweax_v1': True,
    'file_readback_algorithm': 'SHA-512',
    'reset_after_verified_readback': True,
    'load_after_reset_completion': True,
    'delete_old_files': False,
    'claim_exact_remote_inventory': False,
    'require_remote_inventory_review': True,
    'automatic_retry_after_mutation': False,
}
PLANNED_ACTIONS = ['verify_peer_pin', 'negotiate_v4_tagged', 'discover_dynamic_handles',
    'read_fresh_plc_state_require_stop', 'resolve_and_review_remote_pcwe_inventory',
    'write_package_paths', 'read_back_all_package_paths_verify_sha512',
    'reset_async_and_wait_ready', 'load_async_and_wait_stopped', 'close_connection']
IMPACT = {
    'existing_program_execution_interrupted': True,
    'requires_confirmed_stopped_controller': True,
    'sends_start_or_stop_commands': False,
    'controller_autostart_on_load_verified': False,
    'unexpected_execution_after_load_is_possible': True,
    'existing_package_files_overwritten': True,
    'program_configuration_reset_and_reloaded': True,
    'temporary_no_loaded_project_possible': True,
    'connections_may_disconnect': True,
    'timing_and_outputs_during_stop_unverified': True,
    'old_files_deleted': False, 'exact_remote_inventory_claimed': False,
    'rollback_available': False,
    'uncertain_write_result_requires_manual_recovery': True,
}


def _canonical(value: dict) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def _digest(value: dict) -> str:
    return sha(_canonical({key: item for key, item in value.items() if key != 'review_sha256'}))


def _sha256(value, label):
    if type(value) is not str or re.fullmatch('[0-9a-f]{64}', value) is None:
        raise ProjectError('Invalid ' + label + '; expected lowercase SHA-256.')
    return value


def _target(address, pin, port):
    if type(address) is not str:
        raise ProjectError('Download review target must be a literal IP address.')
    try:
        address = str(ipaddress.ip_address(address))
    except ValueError as exc:
        raise ProjectError('Download review target must be a literal IP address.') from exc
    if type(pin) is not str or re.fullmatch('[0-9a-fA-F]{64}', pin) is None:
        raise ProjectError('Download review requires an explicit certificate SHA-256 pin.')
    if type(port) is not int or not 1 <= port <= 65535:
        raise ProjectError('Download review port must be 1..65535.')
    return {'address': address, 'port': port, 'expected_certificate_sha256': pin.lower(),
            'certificate_policy': 'explicit_sha256_pin', 'authentication_mode': 'anonymous'}


def _strict_json(raw: bytes):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ProjectError('Duplicate field in controller download review.')
            result[key] = value
        return result
    try:
        return json.loads(raw, object_pairs_hook=unique,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    except (UnicodeError, ValueError) as exc:
        raise ProjectError('Invalid controller download review JSON.') from exc


def _source_metadata(members, manifest, receipt, files):
    document = xml(members['PROJECT/PROJECT.proj'])
    ids = [node.text for node in document.iter() if node.tag.rsplit('}', 1)[-1] == 'ProjectId']
    try:
        package_manifest = json.loads(files['PCWE.software-package-manifest.json'])
        identification = package_manifest['identification']
        project_name = identification['name']
        if type(project_name) is not str or not project_name or len(project_name) > 1024:
            raise ValueError('invalid project name')
    except (KeyError, TypeError, UnicodeError, ValueError) as exc:
        raise ProjectError('Package lacks a bounded software identification name.') from exc
    return {
        'project_name': project_name,
        'project_guid': ids[0] if len(ids) == 1 else None,
        'managed_revision': manifest['revision'],
        'project_sha256': manifest['current_sha256'],
        'original_source_path': manifest.get('source_path'),
        'software_revision': identification.get('softwareRevision'),
        'release_date': identification.get('releaseDate'),
        'target_product_codes': identification.get('targetProductCodes'),
        'target_firmware_revision': identification.get('targetFirmwareRevision'),
        'pou_count': receipt.get('pou_count'),
    }


def _binding(store, project_id, expected_project_sha256, package_job_id):
    snapshot = _package_snapshot(store, project_id, expected_project_sha256, package_job_id)
    folder, manifest, job, raw, receipt, inventory, bindings, files = snapshot
    # The snapshot has verified the current archive hash. Read the model solely
    # for identity labels; this is still under the managed edit lock.
    _, current, members, _, _ = store._current(project_id)
    if current['current_sha256'] != manifest['current_sha256']:
        raise ProjectError('Project changed while preparing its review identity.')
    records = [{'path': name, 'bytes': len(data), 'sha256': sha(data),
                'sha512': hashlib.sha512(data).hexdigest()} for name, data in sorted(files.items())]
    binding = {
        'source': _source_metadata(members, manifest, receipt, files),
        'package': {
            'package_job_id': package_job_id, 'build_job_id': receipt['build_job_id'],
            'package_receipt_sha256': sha(raw),
            'build_receipt_sha256': receipt['build_receipt_sha256'],
            'inventory_sha256': inventory['inventory_sha256'],
            'image_sha256': sha(files['Plc/Eclr/eCLR.img']),
            'file_count': len(files), 'total_bytes': sum(map(len, files.values())),
            'runtime_binding_validation_passed': True,
            'variable_count': bindings['variable_count'],
            'fb_instance_count': bindings['fb_instance_count'],
            'hmi_mapping_count': bindings['hmi_mapping_count'],
            'download_memento': receipt.get('download_memento', {'policy': 'omit', 'present': False}),
            'package_signature_verified': False,
            'controller_acceptance_verified': False,
        },
        'files': records,
    }
    return folder, manifest, binding, files


def _historical_observation(root: Path, target: dict) -> dict:
    """Use only bounded matching local receipts; they never satisfy a preflight."""
    parent = root / 'controller-reads'
    candidates = []
    if parent.is_dir() and not parent.is_symlink() and not (hasattr(parent, 'is_junction') and parent.is_junction()):
        for item in islice(parent.iterdir(), 1000):
            if re.fullmatch('[0-9a-f]{32}', item.name) is None:
                continue
            try:
                path = _file(parent, item.name + '/result.json')
                if not path.is_file() or path.stat().st_size > MAX_OBSERVATION_BYTES:
                    continue
                raw = path.read_bytes()
                if len(raw) > MAX_OBSERVATION_BYTES:
                    continue
                record = _strict_json(raw)
                if (record.get('status') != 'state_read' or record.get('state_read') is not True
                        or record.get('address') != target['address'] or record.get('port') != target['port']
                        or record.get('peer_certificate_sha256') != target['expected_certificate_sha256']
                        or record.get('certificate_pin_verified') is not True):
                    continue
                observed = record.get('observed_utc')
                parsed = datetime.fromisoformat(observed)
                if parsed.tzinfo is None:
                    continue
                candidates.append((parsed.timestamp(), {'observed_utc': observed,
                    'plc_base_state': record.get('plc_base_state'), 'plc_state_raw': record.get('plc_state_raw'),
                    'report_path': str(path), 'report_sha256': sha(raw)}))
            except (OSError, ProjectError, TypeError, ValueError):
                continue
    latest = max(candidates, key=lambda item: item[0])[1] if candidates else None
    return {'fresh_read_performed': False, 'last_matching_saved_read': latest,
            'used_to_authorize_writes': False,
            'note': 'Historical state is context only; a fresh pin-checked state read and Stop precondition are required at execution.'}


def prepare_download_review(store, project_id: str, expected_project_sha256: str,
                            package_job_id: str, address: str,
                            expected_certificate_sha256: str, port: int = 41100) -> dict:
    """Persist an exact version/impact review; does not contact or authorize PLCs."""
    target = _target(address, expected_certificate_sha256, port)
    _sha256(expected_project_sha256, 'project hash')
    folder = store._folder(project_id)
    with store._lock(folder):
        folder, manifest, binding, _ = _binding(store, project_id, expected_project_sha256, package_job_id)
        review_id = uuid.uuid4().hex
        directory = _file(folder, 'controller-download-reviews/' + review_id)
        directory.mkdir(parents=True, exist_ok=False)
        review = {
            'schema': SCHEMA, 'review_id': review_id, 'project_id': project_id,
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'review_prepared', 'authorization_status': AUTHORIZATION_STATUS,
            'write_authorized': False, 'requires_user_confirmation': False,
            'controller_connected': False, 'controller_downloaded': False,
            'aci_used': False, 'computer_use_used': False,
            'target': target, **binding, 'policy': dict(POLICY),
            'planned_actions': list(PLANNED_ACTIONS), 'impact': dict(IMPACT),
            'historical_observation': _historical_observation(store.root, target),
            'execution_blockers': [
                'exact_mcp_or_operator_authorization_required',
                'fresh_target_identity_state_and_write_permissions_not_verified',
                'remote_inventory_and_old_file_handling_not_verified',
            ],
            'unverified_postconditions': ['real_controller_configuration_acceptance',
                'physical_program_and_output_behavior', 'package_signature_acceptance'],
            'confirmation_scope': ['target IP/port/certificate pin', 'project revision and source SHA-256',
                'package inventory SHA-256 and all file bytes', 'Stop requirement and lack of automatic Start',
                'overwrite/reset/load, connection interruption and recovery limitations'],
            'limitations': ['This record is review data, not a capability token or device-write approval.',
                'An operator confirmation must bind this exact review hash in a separate application workflow.',
                'No remote listing/deletion is claimed; unresolved old files block exact-inventory deployment.',
                'Package/signature/controller acceptance and physical execution remain unverified.'],
        }
        review['review_sha256'] = _digest(review)
        path = directory / 'review.json'
        with path.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(review, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        return {**review, 'review_path': str(path)}


def _load(store, project_id, review_id, expected_review_sha256=None):
    if type(review_id) is not str or re.fullmatch('[0-9a-f]{32}', review_id) is None:
        raise ProjectError('Invalid controller download review ID.')
    folder = store._folder(project_id)
    path = _file(folder, 'controller-download-reviews/' + review_id + '/review.json')
    if not path.is_file() or path.stat().st_size > MAX_REVIEW_BYTES:
        raise ProjectError('Missing or oversized controller download review.')
    raw = path.read_bytes()
    if len(raw) > MAX_REVIEW_BYTES:
        raise ProjectError('Oversized controller download review.')
    review = _strict_json(raw)
    if (type(review) is not dict or review.get('schema') != SCHEMA
            or review.get('project_id') != project_id or review.get('review_id') != review_id
            or (review.get('authorization_status'), review.get('requires_user_confirmation')) not in
                ((AUTHORIZATION_STATUS, False), ('awaiting_user_confirmation', True))
            or review.get('write_authorized') is not False
            or review.get('policy') != POLICY or review.get('impact') != IMPACT
            or review.get('planned_actions') != PLANNED_ACTIONS):
        raise ProjectError('Invalid or altered controller download review policy; it cannot authorize writes.')
    expected = _digest(review)
    if review.get('review_sha256') != expected:
        raise ProjectError('Controller download review hash mismatch.')
    if expected_review_sha256 is not None and _sha256(expected_review_sha256, 'review hash') != expected:
        raise ProjectError('The selected controller download review hash has changed.')
    return folder, path, review


def load_download_review(store, project_id: str, review_id: str,
                         expected_review_sha256: str | None = None) -> dict:
    """Inspect an existing immutable review. This is never an authorization check."""
    _, path, review = _load(store, project_id, review_id, expected_review_sha256)
    return {**review, 'review_path': str(path), 'revalidated_against_current_package': False}


def review_package_snapshot(store, project_id: str, review_id: str,
                            expected_review_sha256: str) -> tuple[dict, dict[str, bytes]]:
    """Recheck reviewed source/package and return captured bytes for an internal caller.

    The returned record still has write_authorized=False. A live transport must
    additionally require separately recorded human confirmation; calling this
    function, knowing the review ID/hash or receiving file bytes is not approval.
    """
    _sha256(expected_review_sha256, 'review hash')
    folder = store._folder(project_id)
    with store._lock(folder):
        _, path, review = _load(store, project_id, review_id, expected_review_sha256)
        _, _, binding, files = _binding(store, project_id, review['source']['project_sha256'],
                                       review['package']['package_job_id'])
        if any(review.get(key) != value for key, value in binding.items()):
            raise ProjectError('Reviewed source/package identity or bytes have changed.')
        # Capture target shape as well; its hash must already match the selected review.
        if _target(review['target']['address'], review['target']['expected_certificate_sha256'],
                   review['target']['port']) != review['target']:
            raise ProjectError('Reviewed target identity has changed.')
        return {**review, 'review_path': str(path),
                'revalidated_against_current_package': True}, files


def revalidate_download_review(store, project_id: str, review_id: str,
                               expected_review_sha256: str) -> dict:
    """Recheck current source/package; retain awaiting confirmation and no permission."""
    review, _ = review_package_snapshot(store, project_id, review_id, expected_review_sha256)
    return review
