"""Measured CommonRemoting header codec; no socket, TLS, or service client.

Engineer 2026's CommandHeader.Write/Read and SecurityToken are the oracle.
This only covers the fixed header and optional UInt32 authentication token.
Service discovery, value serialization, negotiation and TLS remain separate.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from enum import IntEnum
import struct


class AuthenticationError(IntEnum):
    NONE = 0
    INVALID_CREDENTIALS = -1
    PENALTY_DELAY_ACTIVE = -2
    DUPLICATE_SESSION = -3
    SESSION_LIMIT_REACHED = -4
    TRY_AGAIN_LATER = -5
    PASSWORD_MUST_BE_CHANGED = -6


class CommandType(IntEnum):
    GET_SERVICE_REQUEST = 0
    GET_SERVICE_CONFIRMATION = 1
    INVOKE_REQUEST = 2
    INVOKE_CONFIRMATION = 3
    ERROR = 4
    I_AM_ALIVE = 5
    COMMUNICATION_TEST = 6
    CONNECT_REQUEST = 7
    CONNECT_CONFIRM = 8
    DISCONNECT_REQUEST = 9
    DISCONNECT_CONFIRM = 10
    GET_SERVICE_EXT_REQUEST = 11
    GET_SERVICE_EXT_CONFIRMATION = 12
    GET_SERVICE_PROVIDER_REQUEST = 13
    GET_SERVICE_PROVIDER_CONFIRMATION = 14
    GET_SERVICE_HANDLES_REQUEST = 15
    GET_SERVICE_HANDLES_CONFIRMATION = 16


SECURE = 0x08
DATA_TAGGING = 0x40
DATAGRAMMING = 0x80
HEADER_SIZE = 16
TOKEN_SIZE = 4
_HEADER = struct.Struct('<BBHhhhhhH')


@dataclass(frozen=True)
class CommandHeader:
    version: int = 4
    flags: int = 0
    command_type: int = CommandType.INVOKE_REQUEST
    additional_header_size: int = 0
    data_length: int = 0
    service_handle: int = 0
    method_handle: int = 0
    service_provider_handle: int = 0
    checksum: int = 0


def _integer(value, lower, upper, name):
    if isinstance(value, bool) or not isinstance(value, int) or not lower <= value <= upper:
        raise ValueError('Out-of-range CommonRemoting field: ' + name)
    return value


def _folded_sum(data: bytes) -> int:
    total = sum(struct.unpack('<8H', data))
    total = (total & 0xffff) + (total >> 16)
    total += total >> 16
    return total & 0xffff


def encode_header(header: CommandHeader, token: int | None = None,
                  *, checksum: bool = True) -> bytes:
    """Encode vendor header and optional token; None and zero differ.

    The token overload forces secure flag and four-byte additional header.
    This bounded codec rejects unmodeled additional headers. The plain boolean
    overload in the vendor can serialize those, but their semantics are unknown.
    """
    if not isinstance(header, CommandHeader) or type(checksum) is not bool:
        raise ValueError('Expected a CommandHeader and boolean checksum option.')
    _integer(header.flags, 0, 255, 'flags')
    if token is not None:
        _integer(token, 0, 0xffffffff, 'token')
        if not checksum:
            raise ValueError('The measured token overload always emits a checksum.')
        header = replace(header, flags=header.flags | SECURE, additional_header_size=TOKEN_SIZE)
    elif header.flags & SECURE or header.additional_header_size:
        raise ValueError('Only absent or four-byte token headers are implemented.')
    values = [_integer(header.version, 0, 255, 'version'),
        _integer(header.flags, 0, 255, 'flags'),
        _integer(header.command_type, 0, 65535, 'command_type')]
    for name in ('additional_header_size', 'data_length', 'service_handle',
                 'method_handle', 'service_provider_handle'):
        values.append(_integer(getattr(header, name), -32768, 32767, name))
    raw = _HEADER.pack(*values, 0)
    check = (~_folded_sum(raw) & 0xffff) if checksum else 0
    return _HEADER.pack(*values, check) + (struct.pack('<I', token) if token is not None else b'')


def decode_header(data: bytes, *, require_checksum: bool = False) -> tuple[CommandHeader, int | None]:
    """Read exactly one fixed header plus token, excluding its payload.

    Vendor Read permits a zero checksum sentinel. Set require_checksum=True to
    demand the measured sum instead. Parsing does not validate a service handle,
    resolve a token, authenticate a session or process a remote response.
    """
    if not isinstance(data, bytes) or len(data) < HEADER_SIZE:
        raise ValueError('Truncated CommonRemoting header.')
    header = CommandHeader(*_HEADER.unpack(data[:HEADER_SIZE]))
    if (header.checksum or require_checksum) and _folded_sum(data[:HEADER_SIZE]) != 0xffff:
        raise ValueError('Invalid CommonRemoting header checksum.')
    secure = bool(header.flags & SECURE)
    expected = HEADER_SIZE + (TOKEN_SIZE if secure else 0)
    if header.additional_header_size != (TOKEN_SIZE if secure else 0) or len(data) != expected:
        raise ValueError('Unsupported or truncated additional CommonRemoting header.')
    token = struct.unpack('<I', data[HEADER_SIZE:])[0] if secure else None
    return header, token
