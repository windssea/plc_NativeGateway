"""Reconstruct the observed single-resource PLCnext runtime configuration offline.

Rules are bound to Engineer 2026 Ade.Network.Compiler.PlcNextImpl / Ade.DataList.
This deliberately rejects external GDS connections, user PLM components and
unobserved task kinds. It does not execute images or establish controller acceptance.
"""
from __future__ import annotations

from collections import Counter
import re
from uuid import UUID
import xml.etree.ElementTree as ET

from .project import ProjectError, decode_code, pou_index, sha, xml


PATHS = {'domain': 'Plc/Domain/pcwe.plc.config', 'esm': 'Plc/Esm/PCWE.esm.config',
         'gds': 'Plc/Gds/PCWE.gds.config', 'plm': 'Plc/Plm/pcwe.plm.config'}
NAMESPACES = {'domain': 'plcconfig', 'esm': 'esmconfig', 'gds': 'gdsconfig', 'plm': 'plmconfig'}


def _one(members, suffix):
    found = [name for name in members if name.endswith(suffix)]
    if len(found) != 1:
        raise ProjectError('Runtime generation requires exactly one ' + suffix)
    return found[0]


def _require(condition, message):
    if not condition:
        raise ProjectError(message)


def _number(value, label, minimum=0):
    _require(isinstance(value, str) and re.fullmatch(r'[0-9]+', value) is not None,
             'Invalid runtime integer: ' + label)
    result = int(value)
    _require(minimum <= result <= 2**63 - 1, 'Runtime integer outside supported range: ' + label)
    return str(result)


def _document(kind, root, version='1.0'):
    return ET.Element(root, {'xmlns': 'http://www.phoenixcontact.com/schema/' + NAMESPACES[kind],
                            'schemaVersion': version})


def _serialize(root):
    ET.indent(root, space='  ')
    return ET.tostring(root, encoding='utf-8', xml_declaration=True) + b'\n'


def _global_declarations(payload):
    source = decode_code(payload)
    # This worksheet scope is deliberately narrow: one named typed global per
    # declaration, with the persistent Id emitted by Engineer. Semantic IEC
    # compilation is separately required by the package builder.
    source = re.sub(r'\(\*.*?\*\)', '', source, flags=re.S)
    source = re.sub(r'//[^\r\n]*', '', source)
    declarations = {}
    names = set()
    parts = source.split(';')
    for part in parts[:-1]:
        matches = list(re.finditer(r'(?m)^\s*([A-Za-z_]\w*)(?:\s+AT\s+(%[A-Za-z0-9.]+))?\s*:\s*([A-Za-z_]\w*)(?=[\s{:]|$)', part))
        ids = re.findall(r"\bId\s*\(\s*'([0-9a-fA-F-]{36})'\s*\)", part)
        _require(len(matches) == 1 and len(ids) == 1,
                 'Unsupported global declaration; require one named type and persistent Id per statement.')
        name, address, dtype = matches[0].groups()
        address = address or ''
        if address:
            observed_system_addresses = {'IP_ACTIVE_SOCKETS': ('%MW1.30000', 'UINT'),
                'TLS_ACTIVE_SOCKETS': ('%MW1.30100', 'UINT'), 'PLC_CRC_PRJ': ('%ML1.10000', 'ULINT')}
            _require('SystemVariable' in part and observed_system_addresses.get(name) == (address, dtype),
                     'Unsupported explicit global I/O address.')
        identifier = str(UUID(ids[0]))
        _require(identifier not in declarations and name.casefold() not in names,
                 'Duplicate global declaration identity/name.')
        names.add(name.casefold())
        declarations[identifier] = {'id': identifier, 'name': name, 'data_type': dtype, 'address': address}
    _require(declarations and not re.search(r'(?m)^\s*\w+\s*:', parts[-1]),
             'Missing or incomplete global declarations.')
    return declarations


def _mappings(members, data_path, globals_path):
    root = xml(members[data_path])
    _require(root.tag == 'DataListDocument' and root.get('Version') == '1.3',
             'Unsupported DataList schema.')
    declarations = _global_declarations(members[globals_path])
    variables, hmi, ports, counts = [], [], [], Counter()
    seen_variables = set()
    for datum in root.findall('./DataList/Datum'):
        roles = datum.findall('Role')
        types = [r.get('TypeName') for r in roles]
        counts.update(types)
        _require(set(types) <= {'Variable', 'HmiTag', 'InPort', 'OutPort'},
                 'Unsupported DataList role or external/process/safety mapping.')
        _require(not {'InPort', 'OutPort'} <= set(types),
                 'Nonempty GDS port connections are not implemented.')
        _require(types in (['Variable'], ['HmiTag', 'Variable'], ['Variable', 'HmiTag'], ['InPort'], ['OutPort']),
                 'Unsupported DataList role combination.')
        variable = None
        for role in roles:
            kind = role.get('TypeName')
            if kind == 'HmiTag':
                continue
            identifier = role.get('ObjectId', '').lower()
            _require(identifier in declarations, 'DataList variable/port has no matching global Id: ' + identifier)
            declaration = declarations[identifier]
            _require(role.findtext('Name') == declaration['name'] and role.findtext('DataType') == declaration['data_type'],
                     'DataList name/type differs from global declaration: ' + declaration['name'])
            if kind == 'Variable':
                _require(identifier not in seen_variables, 'Duplicate DataList variable identity.')
                seen_variables.add(identifier)
                _require((role.findtext('Address') or '').strip() == declaration['address'],
                         'DataList/global address mismatch: ' + declaration['name'])
                variable = dict(declaration, source_id=role.get('SourceId'), datum_id=datum.get('Uuid'),
                                is_hmi=role.findtext('IsHmi'), is_opc=role.findtext('IsOpc'))
                variables.append(variable)
            else:
                _require(role.findtext('ComponentInstance') == 'Arp.Plc.Eclr'
                         and not (role.findtext('ProgramInstance') or '').strip()
                         and role.findtext('PortDataType') == declaration['data_type']
                         and role.findtext('PortDataTypeDomain') == 'Iec',
                         'Unsupported external or instance-level port mapping.')
                ports.append(dict(declaration, direction=kind, component='Arp.Plc.Eclr', connected=False))
        hmi_roles = [r for r in roles if r.get('TypeName') == 'HmiTag']
        if hmi_roles:
            _require(variable is not None and len(hmi_roles) == 1, 'HMI tag requires one global variable mapping.')
            tag = hmi_roles[0]
            _require(bool(tag.findtext('Name')), 'Missing HMI tag name.')
            hmi.append(dict(variable, tag_name=tag.findtext('Name'), tag_id=tag.get('ObjectId'),
                            read_only=tag.findtext('IsReadOnly')))
    _require(seen_variables == set(declarations), 'Global/DataList variable inventory differs.')
    _require(len({item['tag_name'] for item in hmi}) == len(hmi), 'Duplicate HMI tag name.')
    return {'variables': variables, 'hmi_mappings': hmi, 'ports': ports,
            'role_counts': dict(counts), 'gds_connector_count': 0,
            'all_global_variable_ids_names_types_verified': True,
            'hmi_mapping_count': len(hmi), 'variable_count': len(variables)}


def generate_runtime_configuration(members: dict[str, bytes], project_title: str | None = None, *,
                                     ownership_contract: dict | None = None) -> tuple[dict[str, bytes], dict]:
    """Generate Domain/ESM/GDS/PLM bytes and a source-bound semantic manifest.

    Caller must independently bind members to its successful cold build. Title
    defaults to package Core.xml; an explicit title models ISolution.Title.
    No cached GUI configuration is an input.
    """
    esm_path = _one(members, '/EsmConfiguration.esmc')
    plm_path = _one(members, '/PlmConfiguration.plmc')
    data_path = _one(members, '/DataList.dl')
    globals_path = _one(members, '/GlobalVariables.var')
    device_settings_path = _one(members, '.ds')
    settings = xml(members[device_settings_path])
    update_tasks = [{'xpath': n.get('xPath'), 'value': n.text} for n in settings.iter('InstVal')
                    if 'SysVarUpdateTask' in n.get('xPath', '')]
    from .device_profiles import device_profile
    _require(len(update_tasks) == device_profile(members)['empty_system_variable_task_count'] and all(n['value'] == '[UTF-8;]' for n in update_tasks),
             'Unsupported nonempty or incomplete system-variable update-task assignments.')
    core = xml(members['_properties/Core.xml'])
    dc = '{http://purl.org/dc/elements/1.1/}'
    identifier = str(UUID(core.findtext(dc + 'identifier')))
    title = project_title if project_title is not None else core.findtext(dc + 'title')
    _require(isinstance(title, str) and bool(title.strip()), 'Missing solution title.')
    project = xml(members['PROJECT/PROJECT.proj'])
    versions = [n.text for n in project.iter() if n.tag.rsplit('}', 1)[-1] == 'AdeProductVersion']
    _require(len(versions) == 1 and re.fullmatch(r'\d+\.\d+\.\d+\.\d+', versions[0] or '') is not None,
             'Unsupported AdeProductVersion; require four version components.')
    major, minor, build, revision = versions[0].split('.')
    domain_identity = {'name': title, 'id': identifier, 'version': '.'.join((major, minor, revision, build))}
    domain = _document('domain', 'PlcDomainConfigurationDocument')
    ET.SubElement(domain, 'Project', domain_identity)

    source = xml(members[esm_path])
    _require(source.tag == 'EsmConfiguration' and source.get('version') == '2', 'Unsupported ESM source schema.')
    esms = source.findall('./Esms/Esm')
    esm_ids = {n.get('id'): n.get('name') for n in esms}
    _require(len(esm_ids) == len(esms) and all(esm_ids) and all(esm_ids.values()), 'Duplicate or missing ESM identities.')
    tasks = source.findall('./Tasks/Task')
    from .task_configuration import validate_cyclic_schedule
    schedule = validate_cyclic_schedule(members, ownership_contract=ownership_contract)
    _require(1 <= len(tasks) <= 16, 'Runtime generation supports 1..16 independent cyclic tasks.')
    _require({n.tag for n in source} <= {'Esms', 'Tasks'}, 'Unsupported additional ESM configuration section.')
    index = pou_index(members)
    document = _document('esm', 'EsmConfigurationDocument')
    task_nodes = ET.SubElement(document, 'Tasks')
    relations = ET.SubElement(document, 'EsmTaskRelations')
    program_nodes = ET.SubElement(document, 'Programs')
    task_program_nodes = ET.SubElement(document, 'TaskProgramRelations')
    ET.SubElement(document, 'TaskEvents')
    task_report, program_report, relation_report = [], [], []
    for task in tasks:
        _require(task.get('taskType') == 'CyclicTask' and task.get('esmId') in esm_ids, 'Unsupported task kind or missing ESM reference.')
        _require([n.tag for n in task] == ['ProgramInstances'], 'Unsupported task configuration section.')
        _require(task.get('taskBuffer', 'None') == 'None' and task.get('coreAffinity', '0') == '0',
                 'Task buffer/core-affinity overrides are unsupported.')
        name = task.get('name')
        _require(bool(name), 'Missing task name.')
        attributes = {'name': name, 'stackSize': _number(task.get('stackSize'), 'stackSize'),
            'priority': _number(task.get('priority'), 'priority'),
            'cycleTime': _number(task.get('intervalTime'), 'intervalTime', 1),
            'watchdogTime': _number(task.get('watchdogTime'), 'watchdogTime'),
            'executionTimeThreshold': _number(task.get('executionTimeThreshold'), 'executionTimeThreshold')}
        ET.SubElement(task_nodes, 'CyclicTask', attributes)
        task_report.append(dict(attributes, esm_name=esm_ids[task.get('esmId')]))
        ET.SubElement(relations, 'EsmTaskRelation', {'esmName': esm_ids[task.get('esmId')], 'taskName': name})
        programs = task.findall('./ProgramInstances/ProgramInstance')
        _require(1 <= len(programs) <= 32, 'Each task requires 1..32 independent local program instances.')
        for order, instance in enumerate(programs):
            typename = instance.get('programType')
            _require(typename in index and index[typename]['kind'] == 'Program', 'Program instance references a missing/non-program POU.')
            _require(instance.get('componentName') == 'Arp.Plc.Eclr' and instance.get('libraryName') == 'Arp.Plc.Eclr',
                     'External program components are unsupported.')
            program = {'name': instance.get('name'), 'programType': typename, 'componentName': instance.get('componentName')}
            _require(bool(program['name']), 'Missing program instance name.')
            ET.SubElement(program_nodes, 'Program', program)
            relation = {'taskName': name, 'programName': program['componentName'] + '/' + program['name'], 'order': str(order)}
            ET.SubElement(task_program_nodes, 'TaskProgramRelation', relation)
            program_report.append(program)
            relation_report.append(relation)

    plm_source = xml(members[plm_path])
    _require(plm_source.tag == 'PlmConfiguration', 'Unsupported PLM source schema.')
    _require([n.tag for n in plm_source] == ['ComponentInstances']
             and all(n.tag == 'ComponentInstance' for n in plm_source[0]), 'Unsupported additional PLM sections.')
    components = plm_source.findall('./ComponentInstances/ComponentInstance')
    _require(components and all(c.get('isReadOnly', '').lower() == 'true' for c in components),
             'User PLM components/native component libraries are unsupported.')
    plm = _document('plm', 'PlmConfigurationDocument', '1.4')
    ET.SubElement(plm, 'Libraries')
    ET.SubElement(plm, 'Components')
    mappings = _mappings(members, data_path, globals_path)
    gds = _document('gds', 'GdsConfigurationDocument')
    ET.SubElement(gds, 'ComponentTaskRelations')
    ET.SubElement(gds, 'Connectors')
    files = {PATHS[kind]: _serialize(root) for kind, root in [('domain', domain), ('esm', document), ('gds', gds), ('plm', plm)]}
    source_paths = [esm_path, plm_path, data_path, globals_path, device_settings_path, '_properties/Core.xml', 'PROJECT/PROJECT.proj']
    report = {'scope': 'single_resource_independent_cyclic_eclr_programs_no_external_gds_no_user_plm', 'domain': domain_identity,
        'task_count': len(tasks), 'esm_count': len(esms), 'source_isolation': schedule['source_isolation'],
        'ownership_contract': ownership_contract,
        'tasks': task_report, 'programs': program_report, 'task_program_relations': relation_report,
        'read_only_plm_components_omitted': [dict(c.attrib) for c in components],
        'gds_component_task_relation_count': 0, **mappings,
        'empty_system_variable_update_tasks': update_tasks,
        'source_hashes': {path: sha(members[path]) for path in source_paths},
        'generated_hashes': {path: sha(payload) for path, payload in files.items()},
        'runtime_execution_verified': False, 'controller_connected': False}
    report['semantic_validation'] = validate_runtime_configuration(files, report)
    return files, report


def validate_runtime_configuration(files: dict[str, bytes], expected: dict) -> dict:
    """Validate emitted runtime identities, timing and bindings against source facts."""
    roots = {kind: xml(files[path]) for kind, path in PATHS.items()}
    shapes = {'domain': ('PlcDomainConfigurationDocument', ['Project']),
              'esm': ('EsmConfigurationDocument', ['Tasks', 'EsmTaskRelations', 'Programs', 'TaskProgramRelations', 'TaskEvents']),
              'gds': ('GdsConfigurationDocument', ['ComponentTaskRelations', 'Connectors']),
              'plm': ('PlmConfigurationDocument', ['Libraries', 'Components'])}
    for kind, root in roots.items():
        expected_tag, children = shapes[kind]
        _require(root.tag == '{http://www.phoenixcontact.com/schema/' + NAMESPACES[kind] + '}' + expected_tag
                 and root.attrib == {'schemaVersion': '1.4' if kind == 'plm' else '1.0'},
                 'Runtime XML root/namespace/schema differs: ' + kind)
        for node in root.iter():
            node.tag = node.tag.rsplit('}', 1)[-1]
        _require([n.tag for n in root] == children, 'Unexpected runtime document section: ' + kind)
    esm = roots['esm']
    for section, tag, count in [('Tasks', 'CyclicTask', len(expected['tasks'])),
                               ('Programs', 'Program', len(expected['programs'])),
                               ('EsmTaskRelations', 'EsmTaskRelation', len(expected['tasks'])),
                               ('TaskProgramRelations', 'TaskProgramRelation', len(expected['task_program_relations'])),
                               ('TaskEvents', '', 0)]:
        _require([n.tag for n in esm.find(section)] == [tag] * count, 'Unexpected runtime entries: ' + section)
    domain = roots['domain'].find('Project')
    _require(domain is not None and dict(domain.attrib) == expected['domain'], 'Domain identity differs from source.')
    task_facts = [{k: v for k, v in row.items() if k != 'esm_name'} for row in expected['tasks']]
    _require([dict(n.attrib) for n in roots['esm'].findall('./Tasks/CyclicTask')] == task_facts,
             'Runtime task timing/settings differ from source.')
    _require([dict(n.attrib) for n in roots['esm'].findall('./Programs/Program')] == expected['programs'],
             'Runtime program instances differ from source.')
    _require([dict(n.attrib) for n in roots['esm'].findall('./TaskProgramRelations/TaskProgramRelation')] == expected['task_program_relations'],
             'Runtime task/program mappings differ from source.')
    esm_relations = [{'esmName': t['esm_name'], 'taskName': t['name']} for t in expected['tasks']]
    _require([dict(n.attrib) for n in roots['esm'].findall('./EsmTaskRelations/EsmTaskRelation')] == esm_relations,
             'Runtime ESM/task mappings differ from source.')
    _require(not roots['gds'].findall('./Connectors/*') and not roots['gds'].findall('./ComponentTaskRelations/*'),
             'Unexpected GDS connections/relations.')
    _require(not roots['plm'].findall('./Libraries/*') and not roots['plm'].findall('./Components/*'),
             'Unexpected user PLM library/component.')
    return {'passed': True, 'domain_identity': True, 'task_timing': True, 'program_instances': True,
            'task_program_bindings': True, 'empty_external_gds_verified_from_source': True,
            'hmi_mappings_retained_in_report': expected['hmi_mapping_count'], 'controller_execution': False}
