"""Actual OpenSSL TLS 1.2 between SSLObjects backed only by MemoryBIOs.

This probes Python/OpenSSL trust and hostname checks using PUBLIC TEST fixtures.
It does not prove vendor BouncyCastle or real PLC TLS/RSC compatibility.
No socket, endpoint URL, credential or user-provided path is accepted.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
import ssl
from typing import Literal

from .rsc_codec import CommandHeader, CommandType, decode_header, encode_header

SERVER_NAME = 'offline-plc.invalid'
FIXTURES = Path(__file__).parent / 'simulation_tls'
Fault = Literal['none', 'untrusted_peer', 'hostname_mismatch']


def _drain(source: ssl.MemoryBIO, destination: ssl.MemoryBIO) -> int:
    copied = 0
    while source.pending:
        block = source.read()
        destination.write(block)
        copied += len(block)
    return copied


def _application_transfer(sender, outgoing, recipient, incoming, payload):
    if type(payload) is not bytes or not payload or len(payload) > 128 * 1024 * 1024:
        raise ValueError('TLS application payload must be bounded nonempty bytes.')
    written = 0
    while written < len(payload):
        count = sender.write(payload[written:])
        if count <= 0:
            raise RuntimeError('In-memory TLS application write made no progress.')
        written += count
        if not _drain(outgoing, incoming):
            raise RuntimeError('TLS application write emitted no encrypted records.')
    received = bytearray()
    # OpenSSL exposes at most one plaintext TLS record per read. A large
    # WriteMany may carry >8 MiB in a single RPC, far more than sixteen records.
    for _ in range((len(payload) + 16383) // 16384 + 8):
        if len(received) == len(payload):
            break
        received.extend(recipient.read(len(payload) - len(received)))
    if bytes(received) != payload:
        raise RuntimeError('In-memory TLS application data did not round-trip.')
    return bytes(received)


def _memory_handshake(fault: Fault = 'none'):
    """Return a real MemoryBIO TLS probe; expected certificate failures pass=False.

    Unknown SSL or programming errors propagate to the caller. Faults choose
    fixture material; server_hostname is always the fixed reserved name.
    """
    if fault not in ('none', 'untrusted_peer', 'hostname_mismatch'):
        raise ValueError('Unknown offline TLS fault.')
    trust_name = 'untrusted-ca.pem' if fault == 'untrusted_peer' else 'root-ca.pem'
    cert_name = 'wrong-host-server.pem' if fault == 'hostname_mismatch' else 'server.pem'
    client_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    client_context.minimum_version = client_context.maximum_version = ssl.TLSVersion.TLSv1_2
    client_context.check_hostname = True
    client_context.verify_mode = ssl.CERT_REQUIRED
    client_context.load_verify_locations(cafile=str(FIXTURES / trust_name))
    server_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    server_context.minimum_version = server_context.maximum_version = ssl.TLSVersion.TLSv1_2
    server_context.load_cert_chain(str(FIXTURES / cert_name), str(FIXTURES / 'server-public-test-key.pem'))
    client_in, client_out, server_in, server_out = (ssl.MemoryBIO() for _ in range(4))
    client = client_context.wrap_bio(client_in, client_out, server_side=False, server_hostname=SERVER_NAME)
    server = server_context.wrap_bio(server_in, server_out, server_side=True)
    report = {'passed': False, 'fault': fault, 'transport': 'ssl.MemoryBIO / SSLObject',
        'tls_implementation': ssl.OPENSSL_VERSION, 'server_name': SERVER_NAME,
        'real_tls_handshake_executed': True, 'handshake_completed': False,
        'socket_created': False, 'real_endpoint_connected': False,
        'fixture_material': 'PUBLIC OFFLINE TEST ONLY', 'vendor_tls_compatibility_verified': False,
        'real_plc_verified': False, 'rsc_service_protocol_verified': False,
        'application_data_roundtrip': False}
    client_done = server_done = False
    try:
        for iteration in range(32):
            progress = False
            for peer, done in ((client, client_done), (server, server_done)):
                if done:
                    continue
                try:
                    peer.do_handshake()
                except (ssl.SSLWantReadError, ssl.SSLWantWriteError):
                    continue
                progress = True
                if peer is client:
                    client_done = True
                else:
                    server_done = True
            copied = _drain(client_out, server_in) + _drain(server_out, client_in)
            if client_done and server_done:
                break
            if not progress and not copied:
                raise RuntimeError('In-memory TLS handshake stalled.')
        else:
            raise RuntimeError('In-memory TLS handshake exceeded its bounded rounds.')
    except ssl.SSLCertVerificationError as exc:
        # OpenSSL error 62 = hostname mismatch; 20/21 = issuer unavailable;
        # 18/19 cover untrusted self-signed roots in different OpenSSL builds.
        if fault == 'hostname_mismatch' and exc.verify_code == 62:
            category = 'hostname_mismatch'
        elif fault == 'untrusted_peer' and exc.verify_code in (18, 19, 20, 21):
            category = 'untrusted_certificate_chain'
        else:
            raise
        report.update(error_category=category, certificate_verification_code=exc.verify_code,
                      certificate_rejection_observed=True)
        return report, None
    if fault != 'none':
        raise RuntimeError('Expected offline TLS certificate rejection did not occur.')
    if client.version() != 'TLSv1.2' or server.version() != 'TLSv1.2':
        raise RuntimeError('Unexpected TLS protocol negotiated in the memory probe.')
    report.update(passed=True, handshake_completed=True, tls_version=client.version(),
        cipher=client.cipher()[0], trusted_test_ca_validated=True, fixed_hostname_validated=True,
        peer_certificate_sha256=hashlib.sha256(client.getpeercert(binary_form=True)).hexdigest(),
        handshake_rounds=iteration + 1, exchange_count=0)
    return report, (client, client_out, server, server_in, server_out, client_in)


class MemoryTlsPair:
    """Persistent memory-only TLS pair; each exchange is already schema-delimited.

    A Python callable implements the local server. This explicit bounded message
    API does not introduce a length-prefix frame that the real RSC wire lacks.
    """
    def __init__(self, fault: Fault = 'none'):
        self._report, self._peers = _memory_handshake(fault)

    @property
    def report(self):
        return dict(self._report)

    def exchange(self, request_bytes: bytes, handler) -> bytes:
        if self._peers is None:
            raise RuntimeError('Offline TLS pair did not complete certificate verification.')
        if not callable(handler):
            raise ValueError('A local bytes request handler is required.')
        client, client_out, server, server_in, server_out, client_in = self._peers
        received = _application_transfer(client, client_out, server, server_in, request_bytes)
        response = handler(received)
        result = _application_transfer(server, server_out, client, client_in, response)
        self._report['exchange_count'] += 1
        self._report['application_data_roundtrip'] = True
        return result


def offline_tls_probe(fault: Fault = 'none') -> dict:
    pair = MemoryTlsPair(fault)
    if not pair.report['passed']:
        return pair.report
    # Synthetic zero token tests that false-like tokens retain their header.
    # These are fixed header bytes, not a complete real service invocation.
    request = encode_header(CommandHeader(command_type=CommandType.INVOKE_REQUEST,
        service_handle=7, method_handle=3), 0)
    def respond(received):
        request_header, token = decode_header(received, require_checksum=True)
        if token != 0 or request_header.command_type != CommandType.INVOKE_REQUEST:
            raise RuntimeError('TLS-carried synthetic RSC request header differs.')
        return encode_header(CommandHeader(command_type=CommandType.INVOKE_CONFIRMATION,
            service_handle=request_header.service_handle, method_handle=request_header.method_handle), token)
    received = pair.exchange(request, respond)
    response_header, response_token = decode_header(received, require_checksum=True)
    if response_token != 0 or response_header.command_type != CommandType.INVOKE_CONFIRMATION:
        raise RuntimeError('TLS-carried synthetic RSC confirmation header differs.')
    report = pair.report
    report.update(synthetic_rsc_header_roundtrip=True)
    return report
