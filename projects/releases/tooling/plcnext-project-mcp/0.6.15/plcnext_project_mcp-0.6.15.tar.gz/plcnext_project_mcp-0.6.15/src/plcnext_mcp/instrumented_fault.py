"""Approval-gated, fixed-field real RSC backend for an explicit fault profile.

No arbitrary variable writer is exposed. The unmodified restore source remains
unsupported. This module must observe the exact profile marker and boot before
staging, then verify each value and commit once, last. PLC scans own the TTL.
"""
from __future__ import annotations

from datetime import datetime,timezone
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid

from .controller_download_plan import _binding,_digest,_strict_json,_target
from .controller_control import ControlEndpointLease
from .controller_transfer import _journal_sink,_persist_result
from .controller_transport import ControllerEndpoint,ControllerFailure
from .deployment_plan import _file
from .fault_profile import load_fault_profile,PROFILE_VERSION,READABLE,WRITABLE
from .operator_approval import OperatorApprovalContract,validate_operator_receipt
from .project import ProjectError,sha
from .rsc_codec import CommandType
from .rsc_fault_write_codec import encode_fault_write,receive_write_error
from .rsc_runtime_codec import DATA_ACCESS
from .runtime_monitor import RuntimeReadClient

REVIEW_SCHEMA='plcnext-instrumented-fault-review/v1'
RECEIPT_SCHEMA='plcnext-instrumented-fault-operator-approval/v1'
ACTIONS=['fault_stage_exact_fields','fault_commit_once_last','fault_cancel_same_request','fault_release_readback']
KINDS={'agent_connection_offline':1,'business_ack_blocked':2}
_FAULT_AUTHORITY=object()


def _policy(review_id,fault,ttl_ms,boot_id):
    if fault not in KINDS or type(ttl_ms) is not int or not 100<=ttl_ms<=300000:
        raise ProjectError('Fixed fault kind and TTL 100..300000 ms required.')
    if type(boot_id) is not str or not boot_id or len(boot_id.encode())>80:
        raise ProjectError('Exact bounded deployed-profile boot ID required.')
    return {'plan_id':review_id,'fault':fault,'kind':KINDS[fault],'ttl_ms':ttl_ms,
        'expected_boot_id':boot_id,'commit_last_once':True,'allow_extension':False,
        'plc_scan_owns_deadline':True,'automatic_retry':False,'arbitrary_write_or_force':False}


def prepare_instrumented_fault_review(store,project_id,expected_project_sha256,expected_profile_sha256,
        package_job_id,address,expected_certificate_sha256,expected_boot_id,fault,ttl_ms,port=41100):
    profile=load_fault_profile(store,project_id,expected_project_sha256,expected_profile_sha256)
    _,_,binding,_=_binding(store,project_id,expected_project_sha256,package_job_id)
    target=_target(address,expected_certificate_sha256,port)
    rid=uuid.uuid4().hex
    review={'schema':REVIEW_SCHEMA,'project_id':project_id,'review_id':rid,
        'created_utc':datetime.now(timezone.utc).isoformat(),'target':target,**binding,
        'profile_sha256':expected_profile_sha256,'profile_id':profile['profile_id'],
        'profile_version':PROFILE_VERSION,'symbols':profile['symbols'],
        'policy':_policy(rid,fault,ttl_ms,expected_boot_id),
        'approved_actions':list(ACTIONS),'write_authorized':False,
        'authorization_status':'awaiting_mcp_authorization','controller_connected':False,
        'profile_observed_on_device':False,'real_backend_implemented':True,'real_backend_verified':False,
        'impact':{'only_this_agent_connection_or_business_ack':True,
            'shared_hub_broker_mock_changed':False,'fake_stored_generated':False,
            'host_death_ttl_depends_on_running_plc_task':True,
            'stopped_program_does_not_execute_agent_or_fault_logic':True,
            'restart_first_scans_disarm_on_boot_ready_or_monotonic_rollback':True,
            'physical_hard_realtime_guarantee':False,'p06_performance_verified':False}}
    review['review_sha256']=_digest(review)
    directory=_file(store._folder(project_id),'instrumented-fault-reviews/'+rid)
    directory.mkdir(parents=True,exist_ok=False)
    path=directory/'review.json';path.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return review|{'review_path':str(path)}


def load_instrumented_fault_review(store,project_id,review_id,expected_review_sha256):
    if re.fullmatch('[0-9a-f]{32}',str(review_id)) is None:raise ProjectError('Invalid instrumented fault review ID.')
    path=_file(store._folder(project_id),'instrumented-fault-reviews/'+review_id+'/review.json')
    if not path.is_file() or path.stat().st_size>4*1024*1024:raise ProjectError('Missing bounded fault review.')
    review=_strict_json(path.read_bytes())
    if (review.get('schema')!=REVIEW_SCHEMA or review.get('project_id')!=project_id or review.get('review_id')!=review_id
            or review.get('review_sha256')!=expected_review_sha256 or _digest(review)!=expected_review_sha256
            or review.get('approved_actions')!=ACTIONS or review.get('write_authorized') is not False
            or review.get('authorization_status') not in ('awaiting_mcp_authorization','awaiting_user_confirmation')):
        raise ProjectError('Instrumented fault review identity changed.')
    profile=load_fault_profile(store,project_id,review['source']['project_sha256'],review['profile_sha256'])
    _,_,binding,_=_binding(store,project_id,review['source']['project_sha256'],review['package']['package_job_id'])
    policy=review['policy']
    if (any(review.get(k)!=v for k,v in binding.items()) or review['symbols']!=profile['symbols']
            or review['profile_id']!=profile['profile_id'] or review['profile_version']!=PROFILE_VERSION
            or policy!=_policy(review_id,policy.get('fault'),policy.get('ttl_ms'),policy.get('expected_boot_id'))
            or review['target']!=_target(review['target']['address'],review['target']['expected_certificate_sha256'],review['target']['port'])):
        raise ProjectError('Fault profile, source, package or fixed policy changed.')
    return review


def approval_contract(store,project_id,review_id,expected_review_sha256):
    review=load_instrumented_fault_review(store,project_id,review_id,expected_review_sha256)
    return OperatorApprovalContract(kind='instrumented_fault',review_sha256=expected_review_sha256,
        receipt_schema=RECEIPT_SCHEMA,approval_directory='controller-instrumented-fault-approvals',
        binding_fields={'target':review['target'],'project_sha256':review['source']['project_sha256'],
            'inventory_sha256':review['package']['inventory_sha256'],'profile_sha256':review['profile_sha256'],
            'profile_id':review['profile_id'],'policy':review['policy'],'approved_actions':ACTIONS},display=review).checked()


class FaultWriteScope:
    def __init__(self,review,*,authority=None,fixture=False):
        if authority is not _FAULT_AUTHORITY:raise ProjectError('Fault review alone is not variable-write authority.')
        self.review=review;self.fixture=fixture
        t=review['target'];self.endpoint=ControllerEndpoint(t['address'],t['port'],t['expected_certificate_sha256'])
        if fixture and self.endpoint.address!='127.0.0.1':raise ProjectError('Fault fixture cannot access external endpoints.')
        self.values={};self.written=[];self.staging_verified=False

    def capture_request(self,seen,now_ms):
        if (type(seen) is not int or not 0<=seen<0xffffffff or self.values
                or type(now_ms) is not int or not 0<=now_ms<=2**64-1-self.review['policy']['ttl_ms']):
            raise ControllerFailure('fault_sequence_invalid','Cannot derive one fresh nonwrapping fault request.')
        p=self.review['policy'];request=seen+1
        self.values={'RequestBootId':p['expected_boot_id'],'RequestKind':p['kind'],'RequestTtlMs':p['ttl_ms'],
            'RequestDeadlineMs':now_ms+p['ttl_ms'],'RequestId':request,'CommitId':request,'CancelId':request}
        return request


class InstrumentedFaultClient(RuntimeReadClient):
    def __init__(self,scope,*,event_sink=None):
        if not isinstance(scope,FaultWriteScope):raise ProjectError('Exact instrumented fault capability required.')
        self.fault_scope=scope
        super().__init__(scope.endpoint,[x['path'] for x in scope.review['symbols'].values()],
            timeout_seconds=5,maximum_bytes=1048576,event_sink=event_sink)

    def snapshot(self):
        return _read_snapshot(self,self.fault_scope.review)

    def _write_fixed(self,name):
        scope=self.fault_scope
        if name not in WRITABLE or name not in scope.values or name in scope.written:
            raise ControllerFailure('fault_write_denied','Fault field is not in the one-shot exact request.')
        order=['RequestBootId','RequestKind','RequestTtlMs','RequestDeadlineMs','RequestId','CommitId','CancelId']
        if name!='CancelId' and scope.written!=order[:order.index(name)]:
            raise ControllerFailure('fault_write_order','Fault staging order differs from fixed policy.')
        if name=='CommitId' and not scope.staging_verified:
            raise ControllerFailure('fault_commit_not_verified','Read back all staged fields before commit.')
        if name=='CancelId' and 'CommitId' not in scope.written:
            raise ControllerFailure('fault_cancel_not_active','No matching committed fault to cancel.')
        handle,provider=self._runtime_service(DATA_ACCESS)
        path=scope.review['symbols'][name]['path']
        packet=encode_fault_write(handle,provider,path,WRITABLE[name],scope.values[name])
        event={'operation':'Invoke','service':DATA_ACCESS,'method':3,'mutating':True,'field':name,
            'send_attempted':False,'response_received':False}
        self.trace.append(event)
        try:
            self._emit(event);self._deadline();event['send_attempted']=True;scope.written.append(name)
            self._send(packet);header,_=self._header()
            if (header.service_handle,header.service_provider_handle,header.method_handle)!=(handle,provider,3):
                raise ControllerFailure('response_mismatch','Fault write response handle mismatch.')
            self._raise_remote_error(header)
            if header.command_type!=CommandType.INVOKE_CONFIRMATION:raise ControllerFailure('unexpected_response','Expected fault write response.')
            error=receive_write_error(self._receive)
            event.update(response_received=True,error_code=error);self._emit(event)
            if error!=0:raise ControllerFailure('fault_write_error','Exact fault input write returned error '+str(error))
        except Exception:
            self.broken=True
            raise


def _check_identity(snapshot,review):
    if (snapshot['ProfileVersion']!=PROFILE_VERSION or snapshot['ProfileId']!=review['profile_id']
            or snapshot['CurrentBoot']!=review['policy']['expected_boot_id'] or snapshot['Ready'] is not True):
        raise ControllerFailure('fault_runtime_identity_mismatch','Observed profile ID/version/boot/Ready differs from exact review.')


def _progress(cancel_event,stage):
    callback=getattr(cancel_event,'record_progress',None)
    if callable(callback):callback(stage)


def _read_snapshot(client,review):
    names=list(READABLE)
    rows=client.read_variables([review['symbols'][n]['path'] for n in names])
    if len(rows)!=len(names):raise ControllerFailure('fault_read_incomplete','Fault snapshot item count mismatch.')
    result={}
    for name,row in zip(names,rows):
        if row.get('error_code')!=0 or row.get('wire_type')!=READABLE[name]:
            raise ControllerFailure('fault_read_type_error','Fault profile field is missing or has a wrong type: '+name)
        result[name]=row['value']
    return result


def execute_instrumented_fault(client,review,*,cancel_event=None,poll_interval=0.5):
    if not isinstance(client,InstrumentedFaultClient) or client.fault_scope.review['review_sha256']!=review['review_sha256']:
        raise ProjectError('Exact fault client/review required.')
    if type(poll_interval) not in (int,float) or not 0.02<=poll_interval<=1:raise ProjectError('Bounded fault poll interval required.')
    if cancel_event is not None and not callable(getattr(cancel_event,'is_set',None)):
        raise ProjectError('Fault cancellation requires an internal Event-like object.')
    result={'schema':'plcnext-instrumented-fault-result/v1','status':'fault_failed','review_sha256':review['review_sha256'],
        'target':review['target'],'profile_id':review['profile_id'],'activation_committed':False,
        'activation_observed':False,'release_verified':False,'outcome_unknown':False,
        'agent_disconnect_observed':False,'business_ack_gate_observed':False,
        'local_publish_counter_advanced':False,'business_ack_drop_counter_advanced':False,
        'real_DATA_STORED_and_Hub_receipts_verified':False,
        'real_controller_connected':False,'profile_marker_observed':False,
        'device_program_hash_attestation':False,
        'automatic_retry':False,'arbitrary_variable_write':False,'shared_services_changed':False,
        'real_controller_verified':False,'p06_started':False}
    begun=time.monotonic();client.overall_end=begun+review['policy']['ttl_ms']/1000+8
    try:
        if cancel_event is not None and cancel_event.is_set():
            raise ControllerFailure('fault_cancelled_before_commit','Cancelled before connection or fault commit.')
        _progress(cancel_event,'fault_validating_runtime_profile')
        result['peer']=client.connect()
        result['real_controller_connected']=client.endpoint.address!='127.0.0.1'
        if client.get_state()!=3:raise ControllerFailure('fault_plc_not_running','Fault activation requires a fresh exact Running state.')
        before=client.snapshot();_check_identity(before,review)
        clock_before=before['NowMs']
        time.sleep(0.05)
        before=client.snapshot();_check_identity(before,review)
        if before['NowMs']<=clock_before:
            raise ControllerFailure('fault_clock_not_advancing','Reviewed kernel-monotonic probe did not advance; no fields were written.')
        result['kernel_monotonic_advance_observed']=True
        result['profile_marker_observed']=True
        result['before']=before
        if before['Active']:raise ControllerFailure('fault_already_active','Another fault lease is active; no extension allowed.')
        if before['AgentConnected'] is not True:
            raise ControllerFailure('fault_agent_not_connected','Fault scenario requires an observed connected Agent baseline.')
        request=client.fault_scope.capture_request(before['SeenId'],before['NowMs']);result['request_id']=request
        staged_fields=['RequestBootId','RequestKind','RequestTtlMs','RequestDeadlineMs','RequestId']
        _progress(cancel_event,'fault_staging_request_fields')
        for field in staged_fields:
            if cancel_event is not None and cancel_event.is_set():raise ControllerFailure('fault_cancelled_before_commit','Cancelled before fault commit.')
            client._write_fixed(field)
        _progress(cancel_event,'fault_verifying_staged_request')
        staged=client.snapshot();_check_identity(staged,review)
        if (staged['SeenId']!=before['SeenId'] or staged['Active'] or any(staged[n]!=client.fault_scope.values[n] for n in staged_fields)):
            raise ControllerFailure('fault_staging_mismatch','Staged values/identity changed; commit was not sent.')
        if client.get_state()!=3 or staged['NowMs']>=client.fault_scope.values['RequestDeadlineMs']:
            raise ControllerFailure('fault_request_expired','Stopped PLC or expired staged request; commit was not sent.')
        if cancel_event is not None and cancel_event.is_set():
            raise ControllerFailure('fault_cancelled_before_commit','Cancelled after staging; commit was not sent.')
        client.fault_scope.staging_verified=True
        _progress(cancel_event,'fault_commit_once')
        client._write_fixed('CommitId');result['activation_committed']=True
        end=time.monotonic()+review['policy']['ttl_ms']/1000+3
        _progress(cancel_event,'fault_waiting_independent_ttl_or_cancel')
        while True:
            snapshot=client.snapshot();result['last_observation']=snapshot
            _check_identity(snapshot,review)
            if snapshot['ActiveId']==request and snapshot['Active']:
                result['activation_observed']=True
                result['agent_disconnect_observed']=result['agent_disconnect_observed'] or (
                    review['policy']['kind']==1 and snapshot['BlockConnection'] and not snapshot['AgentConnected'])
                result['business_ack_gate_observed']=result['business_ack_gate_observed'] or (
                    review['policy']['kind']==2 and snapshot['BlockBusinessAck'] and snapshot['AgentConnected'])
                result['local_publish_counter_advanced']=result['local_publish_counter_advanced'] or snapshot['PublishedBatchTotal']>before['PublishedBatchTotal']
                result['business_ack_drop_counter_advanced']=result['business_ack_drop_counter_advanced'] or snapshot['BlockedAckTotal']>before['BlockedAckTotal']
                if cancel_event is not None and cancel_event.is_set() and 'CancelId' not in client.fault_scope.written:
                    _progress(cancel_event,'fault_cancelling_same_request')
                    client._write_fixed('CancelId')
            if snapshot['ReleasedId']==request and not snapshot['Active'] and not snapshot['BlockConnection'] and not snapshot['BlockBusinessAck']:
                result.update(status='fault_released_verified',release_verified=True,release_reason=snapshot['ReleaseReason'])
                result['agent_connection_restored_observed']=snapshot['AgentConnected'] is True
                result['functional_DATA_STORED_recovery_verified']=False
                _progress(cancel_event,'fault_release_readback_verified')
                break
            if snapshot['SeenId']>=request and snapshot['ActiveId']!=request:
                raise ControllerFailure('fault_request_rejected','PLC supervisor rejected staged request.')
            if time.monotonic()>=end:raise ControllerFailure('fault_release_unverified','PLC expiry/release not verified before bounded deadline.')
            time.sleep(poll_interval)
    except Exception as exc:
        result.update(status='fault_failed',failure_code=getattr(exc,'code','fault_transport_or_validation_error'),error_class=type(exc).__name__)
        if isinstance(exc,ProjectError):result['error']=str(exc)
    finally:
        writes=[x for x in client.trace if x.get('mutating') and x.get('send_attempted')]
        result['write_requests_attempted']=len(writes)
        result['commit_request_attempted']=any(x.get('field')=='CommitId' for x in writes)
        result['outcome_unknown']=result['commit_request_attempted'] and not result['release_verified']
        result['staged_fields_may_have_changed']=bool(writes)
        result['cancel_requested']=cancel_event is not None and cancel_event.is_set()
        result['cancel_same_request_sent']=any(x.get('field')=='CancelId' for x in writes)
        result['cleanup_error_class']=client.close()
        if result['cleanup_error_class'] and result['status']!='fault_failed':
            result.update(status='fault_failed',failure_code='fault_session_cleanup_failed')
        result['trace_count']=len(client.trace)
        result['trace_truncated']=len(client.trace)>128
        result['trace']=(list(client.trace[:64])+list(client.trace[-64:])) if len(client.trace)>128 else list(client.trace)
        result['mutation_trace']=list(writes)
        result['elapsed_monotonic_seconds']=time.monotonic()-begun
    return result


def _consume(store,review,execution_id):
    contract=approval_contract(store,review['project_id'],review['review_id'],review['review_sha256'])
    path=_file(store.root,contract.approval_directory+'/'+review['review_sha256']+'.json')
    if not path.is_file() or path.stat().st_size>65536:raise ControllerFailure('user_confirmation_required','No exact independent fault-profile approval.')
    raw=path.read_bytes();validate_operator_receipt(_strict_json(raw),contract)
    if path.with_suffix('.revoked.json').exists() or path.with_suffix('.denied.json').exists():raise ControllerFailure('approval_withdrawn','Fault approval withdrawn.')
    try:fd=os.open(path.with_suffix('.claimed.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError as exc:raise ControllerFailure('approval_already_consumed','Fault approval already consumed; no retry.') from exc
    with os.fdopen(fd,'w',encoding='utf-8') as stream:
        json.dump({'review_sha256':review['review_sha256'],'execution_id':execution_id,'approval_sha256':sha(raw)},stream)
        stream.flush();os.fsync(stream.fileno())
    if (path.read_bytes()!=raw or path.with_suffix('.revoked.json').exists() or path.with_suffix('.denied.json').exists()):
        raise ControllerFailure('approval_changed','Fault approval changed while claimed.')
    return FaultWriteScope(review,authority=_FAULT_AUTHORITY)


def execute_reviewed_instrumented_fault(store,project_id,review_id,expected_review_sha256,*,cancel_event=None):
    review=load_instrumented_fault_review(store,project_id,review_id,expected_review_sha256)
    if cancel_event is not None and (not callable(getattr(cancel_event,'is_set',None)) or cancel_event.is_set()):
        raise ControllerFailure('fault_cancelled_before_commit','Cancelled/invalid cancellation state before approval consumption.')
    job=_file(store._folder(project_id),'instrumented-fault-executions/'+uuid.uuid4().hex)
    lease=ControlEndpointLease(review,job);authorized=False;result=None
    try:
        scope=_consume(store,review,job.name);authorized=True
        job.mkdir(parents=True,exist_ok=False);journal_sink=_journal_sink(job/'journal.jsonl')
        def sink(event):
            if event.get('operation') in ('Connect','Invoke','GetServiceHandles'):
                lease.validate(review)
            if event.get('mutating'):
                _,manifest,_,_,_=store._current(project_id)
                if manifest['current_sha256']!=review['source']['project_sha256']:
                    raise ControllerFailure('fault_source_changed','Source revision changed before a fault mutation.')
            journal_sink(event)
        sink({'operation':'InstrumentedFaultBinding','review_sha256':expected_review_sha256,
            'project_sha256':review['source']['project_sha256'],'inventory_sha256':review['package']['inventory_sha256'],
            'profile_id':review['profile_id'],'target':review['target']})
        result=execute_instrumented_fault(InstrumentedFaultClient(scope,event_sink=sink),review,cancel_event=cancel_event)
        result.update(project_id=project_id,journal_path=str(job/'journal.jsonl'),endpoint_lease_path=str(lease.path))
        if result['outcome_unknown']:lease.quarantine()
        result['endpoint_lease_retained']=lease.quarantined
        _persist_result(job/'result.json',result,sink)
        if not result.get('receipt_persisted'):lease.quarantine();result['endpoint_lease_retained']=True
        return result
    finally:
        if not authorized or not lease.quarantined:
            try:lease.release()
            except (OSError,ControllerFailure) as exc:
                if result is not None:result.update(endpoint_lease_retained=True,lease_cleanup_error_class=type(exc).__name__)


def test_instrumented_fault(store,project_id,expected_project_sha256,expected_profile_sha256,
        package_job_id,*,fault='none',kind='business_ack_blocked'):
    from .fault_profile_test_peer import LocalFaultProfilePeer,FAULTS
    if fault not in FAULTS|{'client_exit','cancel'} or kind not in KINDS:
        raise ProjectError('Unsupported instrumented-fault fixture case.')
    profile=load_fault_profile(store,project_id,expected_project_sha256,expected_profile_sha256)
    _binding(store,project_id,expected_project_sha256,package_job_id)
    directory=_file(store._folder(project_id),'instrumented-fault-tests/'+uuid.uuid4().hex)
    directory.mkdir(parents=True,exist_ok=False);sink=_journal_sink(directory/'journal.jsonl')
    with LocalFaultProfilePeer(directory/'peer',profile,fault=fault if fault in FAULTS else 'none') as peer:
        review=prepare_instrumented_fault_review(store,project_id,expected_project_sha256,expected_profile_sha256,
            package_job_id,peer.address,peer.certificate_sha256,'PUBLIC-boot-1',kind,300,peer.port)
        sink({'operation':'InstrumentedFaultLoopbackBinding','review_sha256':review['review_sha256'],
            'profile_id':profile['profile_id'],'project_sha256':expected_project_sha256,'target':review['target']})
        if fault=='client_exit':
            code="""import json,os,sys
from plcnext_mcp.instrumented_fault import FaultWriteScope,InstrumentedFaultClient,execute_instrumented_fault,_FAULT_AUTHORITY
r=json.loads(sys.stdin.readline())
def sink(e):
    if e.get('field')=='CommitId' and e.get('response_received'):os._exit(23)
s=FaultWriteScope(r,authority=_FAULT_AUTHORITY,fixture=True)
execute_instrumented_fault(InstrumentedFaultClient(s,event_sink=sink),r,poll_interval=0.02)
"""
            flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
            child=subprocess.run([sys.executable,'-I','-c',code],input=json.dumps(review)+'\n',text=True,
                encoding='utf-8',capture_output=True,timeout=5,creationflags=flags)
            if child.returncode!=23:raise ControllerFailure('fixture_client_exit_failed','Fault client did not reach its explicit Commit exit.')
            result={'status':'client_exited_after_commit','commit_request_attempted':True,
                'outcome_unknown':True,'release_verified':False,'client_exit_injection_executed':True}
            sink({'operation':'FaultClientProcessExit','returncode':child.returncode,'commit_reply_received':True})
        else:
            scope=FaultWriteScope(review,authority=_FAULT_AUTHORITY,fixture=True)
            cancel=threading.Event()
            def events(item):
                sink(item)
                if fault=='cancel' and item.get('field')=='CommitId' and item.get('response_received'):cancel.set()
            result=execute_instrumented_fault(InstrumentedFaultClient(scope,event_sink=events),review,
                cancel_event=cancel if fault=='cancel' else None,poll_interval=0.02)
            result['client_exit_injection_executed']=False
        if result.get('commit_request_attempted'):
            time.sleep(0.4)
        endpoint=ControllerEndpoint(peer.address,peer.port,peer.certificate_sha256)
        reader=RuntimeReadClient(endpoint,[d['path'] for d in review['symbols'].values()])
        try:
            reader.connect();final=_read_snapshot(reader,review)
        finally:reader.close()
        released=(final['ReleasedId']>0 and final['Active'] is False
            and final['BlockConnection'] is False and final['BlockBusinessAck'] is False)
        result.update(project_id=project_id,profile_id=profile['profile_id'],fault=fault,
            evidence_environment='loopback_tls_and_synthetic_plc_scans',iec_code_executed=False,
            plc_scan_model_only=True,real_controller_connected=False,operator_approval_issued=False,
            final_readonly_observation=final,release_reconciled_readonly=released,
            peer_field_writes=list(peer.field_writes),peer_errors=list(peer.errors),
            journal_path=str(directory/'journal.jsonl'),p06_started=False)
        if result['status']=='fault_released_verified' or fault=='client_exit' and released:
            result['execution_status']=result['status'];result['status']='loopback_fault_profile_passed'
        _persist_result(directory/'result.json',result,sink)
    return result
