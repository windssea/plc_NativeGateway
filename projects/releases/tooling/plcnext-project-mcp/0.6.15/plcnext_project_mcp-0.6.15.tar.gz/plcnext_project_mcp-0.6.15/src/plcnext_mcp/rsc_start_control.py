"""Measured tagged Start(PlcStartKind: Byte, async: Boolean) messages.

This is a codec, not permission to control a device. Original MemoryStream
SerializeMessage vectors live in artifacts/rsc-control-start/oracle-01.
"""
from __future__ import annotations

from . import rsc_tagged_codec as tagged

START_METHOD_ID = 2
START_KINDS = {'cold': 1, 'warm': 2, 'hot': 3, 'restore_warm': 4}


def start_kind_value(name: str) -> int:
    if type(name) is not str or name not in START_KINDS:
        raise ValueError('Start kind must be cold, warm, hot or restore_warm.')
    return START_KINDS[name]


def encode_start_request(service_handle: int, start_kind: str, async_: bool = True,
                         *, provider_handle: int = 0, token: int | None = None) -> bytes:
    if type(async_) is not bool:
        raise ValueError('PLC Start async_ must be Boolean.')
    return tagged.encode_request(service_handle, START_METHOD_ID, ['byte', 'bool'],
        [start_kind_value(start_kind), async_], provider_handle=provider_handle, token=token)


def decode_start_request(packet: bytes):
    header, token, values = tagged.decode_request(packet, ['byte', 'bool'])
    if header.method_handle != START_METHOD_ID or values[0] not in START_KINDS.values():
        raise ValueError('Expected measured PLC Start method and explicit start kind.')
    return header, token, {'start_kind': next(k for k, v in START_KINDS.items() if v == values[0]),
                           'async_': values[1]}


def encode_start_response(service_handle: int, *, provider_handle: int = 0) -> bytes:
    return tagged.encode_response(service_handle, START_METHOD_ID, [], [], provider_handle=provider_handle)


def decode_start_response(packet: bytes):
    header, token, values = tagged.decode_response(packet, [])
    if header.method_handle != START_METHOD_ID or token is not None or values:
        raise ValueError('Expected no-token PLC Start acknowledgement.')
    return header, token
