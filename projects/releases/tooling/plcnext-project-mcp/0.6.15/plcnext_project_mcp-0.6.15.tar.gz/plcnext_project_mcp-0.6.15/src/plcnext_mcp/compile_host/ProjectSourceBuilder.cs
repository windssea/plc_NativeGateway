using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using Ade.Compiler;
using Ade.Compiler.Model;
using Ade.Compiler.Model.Pragma;
using Ade.Components;
using Ade.Patterns.Immutable;

// Rebuild standard ST POUs from their own source declarations and metadata.
// The input project supplies only types/libraries/configuration; no existing
// POU, variable worksheet, method, or executable source is reused.
public sealed class SourceBuildResult {
    public CompilerProject Project { get; set; }
    public int ErrorCount { get; set; }
    public int WarningCount { get; set; }
    public int ParsedPous { get; set; }
    public int ParsedVariables { get; set; }
    public int GeneratedDataTypes { get; set; }
    public bool DiagnosticsTruncated { get; set; }
    public int TotalMessages { get; set; }
    public object Diagnostics { get; set; }
    public object Pous { get; set; }
}

public static class ProjectSourceBuilder {
    private sealed class Context {
        public readonly ParserCollectedMessages Sink = new ParserCollectedMessages();
        public readonly IecScannerFactory Scanner = new IecScannerFactory();
        public readonly IdentifierHelper Identifier = new IdentifierHelper();
        public readonly LiteralParser Literal;
        public readonly CompilerUtilities Utilities;
        public int Errors;
        public int Warnings;
        public bool EnEnoEnabled=true;
        public readonly List<DataTypeWorksheet> DataTypeWorksheets = new List<DataTypeWorksheet>();
        public Context() {
            Literal = new LiteralParser(Identifier);
            Utilities = new CompilerUtilities {
                LiteralParser = new Lazy<ILiteralParser>(()=>Literal),
                IdentifierHelper = new Lazy<IIdentifierHelper>(()=>Identifier),
                IecScannerFactory = new Lazy<IIecScannerFactory>(()=>Scanner)
            };
        }
        public T Configure<T>(T parser) {
            var type=parser.GetType();
            type.GetProperty("IecScannerFactory").SetValue(parser,new Lazy<IIecScannerFactory>(()=>Scanner));
            type.GetProperty("CommonResourceService").SetValue(parser,new Lazy<ICommonResourceService>(()=>new ParserKeyResources()));
            type.GetProperty("LiteralParser").SetValue(parser,new Lazy<ILiteralParser>(()=>Literal));
            type.GetProperty("CompilerUtilityService").SetValue(parser,new Lazy<ICompilerUtilityService>(()=>Utilities));
            return parser;
        }
        public VariableWorksheet Variables(string text,string uri) {
            var parser=Configure(new Ade.Compiler.Parsing.PlcVariableParser());
            using(var reader=new StringReader(text)) {
                var parsed=parser.Parse(reader,uri,new ParserParameters(),Sink);
                Errors+=parsed.ErrorCount;Warnings+=parsed.WarningCount;
                if(parsed.DataTypes.Count>0) {
                    var data=CompilerProjectNodeFactory.DataTypeWorksheetBuilder();
                    data.Name=uri;
                    data.SourceLabel=SourceLabelFactory.Guid(uri,Guid.Empty);
                    foreach(var type in parsed.DataTypes) data.DataTypes.Add(type);
                    DataTypeWorksheets.Add(data.ToImmutable());
                }
                return parsed.Node;
            }
        }
        public CodeWorksheet Code(string text,string uri) {
            var parser=Configure(new Ade.Compiler.Parsing.StructuredTextParser());
            using(var reader=new StringReader(text)) {
                var parsed=parser.Parse(reader,uri,new ParserParameters(),Sink);
                Errors+=parsed.ErrorCount;Warnings+=parsed.WarningCount;
                return parsed.Node;
            }
        }
    }

    private static XmlDocument LoadXml(string path) {
        var document=new XmlDocument {XmlResolver=null};
        using(var reader=XmlReader.Create(path,new XmlReaderSettings {DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))
            document.Load(reader);
        return document;
    }
    private static string Child(XmlNode node,string selector,bool required=true) {
        var value=node.SelectSingleNode(selector)?.InnerText;
        if(required && String.IsNullOrWhiteSpace(value)) throw new InvalidDataException("Required source metadata is missing: "+selector);
        return value ?? "";
    }
    private static string SourcePath(string root,string path) {
        if(String.IsNullOrEmpty(path) || Path.IsPathRooted(path)) throw new InvalidDataException("Expected a job-relative source path.");
        var resolved=Path.GetFullPath(Path.Combine(root,path));
        if(!resolved.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Source path leaves the source job directory.");
        return resolved;
    }
    private static string UriFor(string root,string id) {
        return root.TrimEnd('/')+"/"+Guid.Parse(id).ToString();
    }
    private static string InferUriRoot(CompilerProject seed,XmlElement manifest) {
        var declared=manifest.GetAttribute("projectUri");
        if(!String.IsNullOrEmpty(declared)) {
            if(!Uri.IsWellFormedUriString(declared,UriKind.Absolute)) throw new InvalidDataException("Invalid projectUri.");
            return declared.TrimEnd('/');
        }
        foreach(var pou in seed.ProgramOrganizationUnits) {
            var value=pou.SourceLabel.ToString().Split('?','#')[0];
            if(Uri.IsWellFormedUriString(value,UriKind.Absolute)) return value.Substring(0,value.LastIndexOf('/'));
        }
        return "adeprojectref:///source-rebuild";
    }

    private static ProgramOrganizationUnit BuildPou(Context context,XmlElement entry,string root,string uriRoot,
                                                     out string variableUri) {
        var name=entry.GetAttribute("name");
        if(String.IsNullOrWhiteSpace(name)) throw new InvalidDataException("POU source has no name.");
        var metadata=LoadXml(SourcePath(root,entry.GetAttribute("metadata"))).DocumentElement;
        var kind=Child(metadata,"Kind");
        if(entry.GetAttribute("kind")!=kind) throw new InvalidDataException("Source manifest and metadata POU kind disagree: "+name);
        ProgramOrganizationUnitBuilder builder;
        if(kind=="FunctionBlock") builder=CompilerProjectNodeFactory.FunctionBlockBuilder();
        else if(kind=="Function") builder=CompilerProjectNodeFactory.FunctionBuilder();
        else if(kind=="Program") builder=CompilerProjectNodeFactory.ProgramBuilder();
        else throw new InvalidDataException("Only standard Function/FunctionBlock/Program ST POUs are supported: "+name);
        var pouUri=UriFor(uriRoot,Child(metadata,"Id"));
        builder.Identifier=new IecTypeIdentifier(name,"");
        builder.SourceLabel=SourceLabelFactory.Guid(pouUri,Guid.Parse(Child(metadata,"Id")));
        builder.Timestamp=DateTime.UtcNow;
        builder.UserData["Ade.Compiler.BuildItemUri"]=ImmutableFactory.String(pouUri);
        foreach(XmlNode node in metadata.SelectNodes("Usings/*")) if(!String.IsNullOrWhiteSpace(node.InnerText)) builder.Usings.Add(node.InnerText.Trim());
        if(metadata.SelectNodes("ItemGroup/VariableWorksheet").Count!=1 ||
           metadata.SelectNodes("ItemGroup/*[not(self::VariableWorksheet or self::CodeWorksheet)]").Count!=0)
            throw new InvalidDataException("Only one variable worksheet and one Code.st worksheet are supported: "+name);
        variableUri=UriFor(uriRoot,Child(metadata,"ItemGroup/VariableWorksheet/Id"));
        var codeNodes=metadata.SelectNodes("ItemGroup/CodeWorksheet");
        if(codeNodes.Count!=1 || ((XmlElement)codeNodes[0]).GetAttribute("Include")!="Code.st")
            throw new InvalidDataException("Expected exactly one standard Code.st worksheet: "+name);
        var codeUri=UriFor(uriRoot,Child(codeNodes[0],"Id"));
        var declarations=context.Variables(File.ReadAllText(SourcePath(root,entry.GetAttribute("variables"))),variableUri);

        if(kind=="Function") {
            var resultUri=pouUri+"/return";
            var returnWorksheet=context.Variables("VAR_OUTPUT\n"+name+" : "+Child(metadata,"ReturnType")+";\nEND_VAR\n",resultUri).ToBuilder();
            returnWorksheet.Name="__RETURN_TYPE__";
            var returnVariable=returnWorksheet.Variables.Single().ToBuilder();
            PragmaExtensions.AddPragmaValue(returnVariable.Pragmas,"INV",PragmaFactory.PragmaValue());
            returnWorksheet.Variables[0]=returnVariable.ToImmutable();
            PragmaExtensions.AddPragmaValue(builder.Pragmas,"EnEnoSupport",PragmaFactory.PragmaValue());
            if(context.EnEnoEnabled) {
                var en=context.Variables("VAR_INPUT EN : BOOL := TRUE; END_VAR\nVAR_OUTPUT ENO : BOOL := TRUE; END_VAR\n",pouUri+"/en-eno").ToBuilder();
                en.Name="__EN_ENO__";
                PragmaExtensions.AddPragmaValue(en.Pragmas,"CompilerGenerated",PragmaFactory.PragmaValue());
                builder.VariableWorksheets.Add(en.ToImmutable());
            }
            builder.VariableWorksheets.Add(returnWorksheet.ToImmutable());
        }
        builder.VariableWorksheets.Add(declarations);
        var execution=CompilerProjectNodeFactory.ExecutionMethodBuilder();
        execution.Name="__Process";
        execution.CodeWorksheets.Add(context.Code(File.ReadAllText(SourcePath(root,entry.GetAttribute("code"))),codeUri));
        builder.Methods.Add(execution.ToImmutable());
        if(kind!="Function") {
            var initialization=CompilerProjectNodeFactory.InitializationMethodBuilder();
            initialization.Name="__Init";
            builder.Methods.Add(initialization.ToImmutable());
        }
        return builder.ToImmutable();
    }

    public static SourceBuildResult Rebuild(CompilerProject seedProject,string sourcesXmlPath) {
        if(seedProject==null) throw new ArgumentNullException("seedProject");
        var manifestPath=Path.GetFullPath(sourcesXmlPath);
        var root=Path.GetDirectoryName(manifestPath);
        var manifest=LoadXml(manifestPath).DocumentElement;
        if(manifest.Name!="Sources") throw new InvalidDataException("Expected a Sources manifest.");
        var uriRoot=InferUriRoot(seedProject,manifest);
        var context=new Context();
        IImmutableObject enOption;
        bool enabled;
        if(seedProject.UserData.TryGetValue("Ade.Compiler.EnEnoEnabled",out enOption) && Boolean.TryParse(enOption.ToString(),out enabled))
            context.EnEnoEnabled=enabled;
        if(manifest.HasAttribute("enEnoEnabled")) {
            if(!Boolean.TryParse(manifest.GetAttribute("enEnoEnabled"),out enabled)) throw new InvalidDataException("Invalid enEnoEnabled project option.");
            context.EnEnoEnabled=enabled;
        }
        var entries=manifest.SelectNodes("POU").Cast<XmlElement>().ToArray();
        if(entries.Length==0) throw new InvalidDataException("The source manifest contains no POUs.");
        if(entries.Select(e=>e.GetAttribute("name")).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=entries.Length)
            throw new InvalidDataException("Duplicate POU names in source manifest.");
        var newPous=new List<ProgramOrganizationUnit>();
        var variableUris=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        // Drop anonymous type sheets belonging to old declarations even if a
        // worksheet ID changed in the source metadata. Explicit project types
        // and external library types remain the caller's project skeleton.
        foreach(var oldPou in seedProject.ProgramOrganizationUnits) {
            foreach(var sheet in oldPou.VariableWorksheets)
                if(!sheet.Name.StartsWith("__",StringComparison.Ordinal)) variableUris.Add(sheet.Name);
            var oldUri=oldPou.SourceLabel.ToString().Split('?','#')[0];
            variableUris.Add(oldUri+"/return");variableUris.Add(oldUri+"/en-eno");
        }
        foreach(var entry in entries) {
            string variableUri;
            newPous.Add(BuildPou(context,entry,root,uriRoot,out variableUri));
            variableUris.Add(variableUri);
            var pouUri=newPous.Last().SourceLabel.ToString().Split('?','#')[0];
            variableUris.Add(pouUri+"/return");
            variableUris.Add(pouUri+"/en-eno");
        }
        var builder=seedProject.ToBuilder();
        builder.ProgramOrganizationUnits.Clear();
        foreach(var pou in newPous) builder.ProgramOrganizationUnits.Add(pou);
        for(int index=builder.DataTypeWorksheets.Count-1;index>=0;index--)
            if(variableUris.Contains(builder.DataTypeWorksheets[index].Name)) builder.DataTypeWorksheets.RemoveAt(index);
        foreach(var sheet in context.DataTypeWorksheets) builder.DataTypeWorksheets.Add(sheet);
        var project=builder.ToImmutable();
        return new SourceBuildResult {
            Project=project,ErrorCount=context.Errors,WarningCount=context.Warnings,ParsedPous=newPous.Count,
            ParsedVariables=newPous.Sum(p=>p.VariableWorksheets.Where(v=>!v.Name.StartsWith("__",StringComparison.Ordinal)).Sum(v=>v.Variables.Count)),
            GeneratedDataTypes=context.DataTypeWorksheets.Sum(s=>s.DataTypes.Count),
            DiagnosticsTruncated=context.Sink.TotalMessages>context.Sink.Messages.Count,TotalMessages=context.Sink.TotalMessages,
            Diagnostics=context.Sink.Messages.Select(m=>new {type=m.MessageType.ToString(),type_id=m.TypeId,resource_id=m.ResourceId,
                text=m.Message,location=m.JumpUri==null?null:m.JumpUri.ToString(),format_parameters=m.FormatParameters.Select(p=>p==null?null:p.ToString()).ToArray()}).ToArray(),
            Pous=newPous.Select(p=>new {name=p.Identifier.ToString(),kind=p.Kind.ToString(),
                variables=p.VariableWorksheets.SelectMany(w=>w.Variables).Select(v=>new {name=v.Name,kind=v.Kind.ToString(),datatype=v.DataType.ToString()}).ToArray(),
                statements=p.Methods.Sum(m=>m.CodeWorksheets.Sum(c=>c.Statements.Count))}).ToArray()
        };
    }
}
