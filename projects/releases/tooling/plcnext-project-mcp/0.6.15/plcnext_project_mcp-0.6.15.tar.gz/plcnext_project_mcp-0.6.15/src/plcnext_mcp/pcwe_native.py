"""Source-bound native libraries, library CRC and unsigned PCWE file manifests.

Observed compatibility subset: exact device type and major/minor version,
non-simulation. Parent-profile/range fallbacks are deliberately not guessed.
This module only returns bytes; it never opens source library paths or devices.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import io
from pathlib import Path
import re
import struct
from urllib.parse import unquote
import xml.etree.ElementTree as ET
import zipfile
import zlib

from .deployment_package import MANIFEST, _relative_path, overall_hash
from .project import ProjectError, sha, xml

MAX_PACKAGE_BYTES = 64 * 1024 * 1024
MAX_EXPANDED_BYTES = 256 * 1024 * 1024


def _local_name(node):
    return node.tag.rsplit('}', 1)[-1]


def _value(node, name, default=''):
    values = [n.text or '' for n in node if _local_name(n) == name]
    if len(values) > 1:
        raise ProjectError('Ambiguous library metadata: ' + name)
    return values[0] if values else default


def normalized_version(value: str) -> tuple[int, int]:
    if not isinstance(value, str) or not re.fullmatch(r'\d+\.\d+(?:\.\d+){0,2}', value):
        raise ProjectError('Unsupported native-library device version: ' + str(value))
    parts = tuple(map(int, value.split('.')))
    if any(part > 2147483647 for part in parts):
        raise ProjectError('Native-library version component is outside Int32.')
    return parts[0], parts[1]


def _bound_bytes(job: Path, relative: str, digest: str, maximum=MAX_PACKAGE_BYTES) -> bytes:
    _relative_path(relative)
    if not isinstance(digest, str) or re.fullmatch('[0-9a-f]{64}', digest) is None:
        raise ProjectError('Missing or malformed build-input SHA256: ' + relative)
    path = job / relative
    for candidate in (path, *path.parents):
        if candidate.is_symlink() or (hasattr(candidate, 'is_junction') and candidate.is_junction()):
            raise ProjectError('Native-library inputs cannot traverse links or junctions.')
        if candidate == job:
            break
    if not path.resolve().is_relative_to(job.resolve()) or not path.is_file() or path.stat().st_size > maximum:
        raise ProjectError('Missing, oversized or escaping build input: ' + relative)
    data = path.read_bytes()
    if len(data) > maximum or sha(data) != digest:
        raise ProjectError('Build input changed: ' + relative)
    return data


def library_crc(payloads: list[bytes]) -> bytes:
    """Observed source-content CRC rule; BinaryWriter Int32(1), UInt32(crc).

    Sorting file CRCs and combining with each byte length is equivalent to CRC32
    of the correspondingly concatenated bytes. Equal CRCs with unequal lengths
    are refused because the vendor's concurrent collection does not fix ties.
    """
    records = [(zlib.crc32(data), data) for data in payloads]
    lengths = {}
    for crc, data in records:
        if crc in lengths and lengths[crc] != len(data):
            raise ProjectError('Ambiguous equal-CRC native library input ordering.')
        lengths[crc] = len(data)
    total = 0
    for _, data in sorted(records, key=lambda record: record[0]):
        total = zlib.crc32(data, total)
    return struct.pack('<II', 1, total)


def _package_native_files(payload: bytes, device_type: str, device_version: str) -> tuple[dict, list]:
    try:
        archive = zipfile.ZipFile(io.BytesIO(payload))
    except zipfile.BadZipFile as exc:
        raise ProjectError('Invalid native-library package.') from exc
    with archive:
        infos = archive.infolist()
        if len(infos) > 10000 or sum(item.file_size for item in infos) > MAX_EXPANDED_BYTES:
            raise ProjectError('Native-library package exceeds expanded limits.')
        decoded = {}
        for item in infos:
            name = unquote(item.filename).rstrip('/')
            _relative_path(name)
            if name.casefold() in decoded:
                raise ProjectError('Ambiguous native-library package member names.')
            decoded[name.casefold()] = item.filename
        if 'project/project.proj' not in decoded:
            raise ProjectError('Native-library package lacks PROJECT.proj.')
        project = xml(archive.read(decoded['project/project.proj']))
        groups = {}
        all_declared_so = set()
        for folder in project.iter():
            if _local_name(folder) != 'Folder' or _value(folder, 'FolderType') != 'NativeLibrary':
                continue
            prefix = folder.get('Include', '').replace('\\', '/').rstrip('/')
            _relative_path(prefix)
            assembly = _value(folder, 'AssemblyName')
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]*', assembly):
                raise ProjectError('Unsupported native library assembly name.')
            matches = []
            profiles = []
            for node in folder.iter():
                if _local_name(node) != 'DeviceProfile':
                    continue
                kind = _value(node, 'DeviceProfileType')
                version = _value(node, 'DeviceProfileVersion')
                simulation = _value(node, 'SimulationMode', _value(node, 'DeviceProfileSimulationMode', 'false'))
                if simulation.lower() not in ('true', 'false'):
                    raise ProjectError('Invalid native-library simulation mode.')
                profiles.append({'type': kind, 'version': version, 'simulation': simulation.lower() == 'true'})
                if kind == device_type and normalized_version(version) == normalized_version(device_version) and simulation.lower() == 'false':
                    matches.append(profiles[-1])
            if not profiles:
                raise ProjectError('Native library folder lacks device profiles.')
            entries = [stored for plain, stored in decoded.items()
                       if plain.startswith(('project/' + prefix + '/').casefold()) and plain.endswith('.so')]
            all_declared_so.update(entries)
            groups.setdefault(assembly, []).append({'prefix': prefix, 'matches': matches, 'entries': entries})
        all_so = {item.filename for item in infos if item.filename.lower().endswith('.so')}
        if all_so - all_declared_so:
            raise ProjectError('Native SO exists outside declared native-library folders.')
        files = {}
        report = []
        for assembly, candidates in sorted(groups.items()):
            selected = [candidate for candidate in candidates if candidate['matches']]
            if len(selected) != 1:
                raise ProjectError('No unique exact device major/minor native library: ' + assembly)
            selected = selected[0]
            if not selected['entries']:
                raise ProjectError('Selected native-library folder has no SO payload: ' + assembly)
            for member in selected['entries']:
                plain = unquote(member)
                tail = plain[len('PROJECT/' + selected['prefix'] + '/'):]
                if '/' in tail:
                    raise ProjectError('Nested native-library SO layout is unsupported.')
                output = 'Plc/Eclr/SharedLibraries/' + assembly + '/' + tail
                _relative_path(output)
                content = archive.read(member)
                if not content.startswith(b'\x7fELF'):
                    raise ProjectError('Selected native library is not an ELF SO.')
                files[output] = content
                report.append({'member': member, 'output_path': output, 'sha256': sha(content),
                               'bytes': len(content), 'profiles': selected['matches'],
                               'selection_rule': 'exact_device_type_and_normalized_major_minor_non_simulation'})
        return files, report


def generate_native_payloads(job_directory: str | Path, input_hashes: dict,
                             project_members: dict[str, bytes], device_type: str,
                             device_version: str) -> tuple[dict[str, bytes], dict]:
    """Return selected SO files and Libraries.crc, tied to this build's sources.

    The caller must separately bind the entire build receipt to its managed
    revision. This function additionally binds PROJECT.proj, library-inputs.xml,
    all staged package bytes and the exact SolutionReference name/hint set.
    """
    if not isinstance(device_type, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', device_type):
        raise ProjectError('Invalid native-library device type.')
    normalized_version(device_version)
    job = Path(job_directory).absolute()
    source = project_members.get('PROJECT/PROJECT.proj')
    if source is None or input_hashes.get('project/PROJECT/PROJECT.proj') != sha(source):
        raise ProjectError('Native library project manifest is not bound to this build.')
    project = xml(source)
    expected = Counter((node.get('Include', ''), _value(node, 'HintPath'))
                       for node in project.iter() if _local_name(node) == 'SolutionReference')
    if any(count != 1 for count in expected.values()):
        raise ProjectError('Duplicate source library references are unsupported.')
    raw = _bound_bytes(job, 'library-inputs.xml', input_hashes.get('library-inputs.xml'), 4 * 1024 * 1024)
    manifest = xml(raw)
    entries = list(manifest)
    if manifest.tag != 'Libraries' or any(node.tag != 'Library' for node in entries):
        raise ProjectError('Invalid staged library-inputs document.')
    actual = Counter((node.get('name', ''), node.get('hint', '')) for node in entries)
    if actual != expected:
        raise ProjectError('Staged libraries do not match current source references.')
    files, native, archives, payloads, staged_names = {}, [], [], [], set()
    for node in entries:
        relative = node.get('staged', '')
        if not relative.startswith('libraries/') or not relative.endswith(('.pcwlx', '.pxclx')) or relative.casefold() in staged_names:
            raise ProjectError('Unsupported or duplicate staged library path.')
        staged_names.add(relative.casefold())
        digest = input_hashes.get(relative)
        if digest != node.get('sha256'):
            raise ProjectError('Library manifest and build input hash differ.')
        payload = _bound_bytes(job, relative, digest)
        selected, records = _package_native_files(payload, device_type, device_version)
        for name, content in selected.items():
            if name.casefold() in {key.casefold() for key in files}:
                raise ProjectError('Native-library output collision: ' + name)
            files[name] = content
        native.extend(dict(record, archive=relative, archive_sha256=digest) for record in records)
        payloads.append(payload)
        archives.append({'path': relative, 'sha256': digest, 'crc32': f'{zlib.crc32(payload):08x}', 'bytes': len(payload)})
    files['Libraries.crc'] = library_crc(payloads)
    return files, {'device_type': device_type, 'device_version': device_version,
        'normalized_version': list(normalized_version(device_version)), 'libraries': archives,
        'selected_native_files': native, 'libraries_crc_hex': files['Libraries.crc'].hex(),
        'source_hashes_verified': True, 'signature_validation': 'not_performed',
        'controller_connected': False, 'controller_downloaded': False}


def make_pcwe_manifest(files: dict[str, bytes]) -> bytes:
    """Create an unsigned SHA-512 manifest with a declared deterministic order.

    Both file-list order and overall-hash input use the same sorted paths.
    This does not preserve/forge vendor signatures or certify device acceptance.
    """
    if not files or len(files) > 10000:
        raise ProjectError('Empty or oversized PCWE file inventory.')
    seen = set()
    total = 0
    for name, data in files.items():
        _relative_path(name)
        if name.casefold() == MANIFEST.casefold() or name.casefold() in seen:
            raise ProjectError('Duplicate or self-referential PCWE manifest member.')
        if not isinstance(data, bytes):
            raise ProjectError('PCWE manifest requires exact byte payloads.')
        seen.add(name.casefold())
        total += len(data)
        if len(data) > 512 * 1024 * 1024 or total > 2 * 1024 * 1024 * 1024:
            raise ProjectError('PCWE file inventory exceeds size limits.')
    document = ET.Element('ProjectManifestDocument', schemaVersion='1.0')
    ET.SubElement(ET.SubElement(document, 'Metadata'), 'HashAlgorithm', type='Sha512')
    container = ET.SubElement(document, 'Files')
    hashes = []
    for name, data in sorted(files.items()):
        digest = hashlib.sha512(data).hexdigest()
        hashes.append(digest)
        ET.SubElement(container, 'File', path=name, hash=digest)
    container.set('overallHash', overall_hash(hashes))
    ET.indent(document, space='  ')
    return ET.tostring(document, encoding='utf-8', xml_declaration=True)
