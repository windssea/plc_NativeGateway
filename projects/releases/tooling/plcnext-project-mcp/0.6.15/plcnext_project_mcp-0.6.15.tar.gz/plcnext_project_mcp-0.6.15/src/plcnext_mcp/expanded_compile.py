"""Source-driven POU/interface recompilation with explicit, bounded seed dependencies."""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import uuid
import xml.etree.ElementTree as ET

from .cached_compile import (_verified_seed, _contained, _json, SOURCE_PROJECT_SHA256,
                             RESOURCE_NAME, HOST, BACKEND, LOADER)
from .project import MAX_CODE, ProjectError, ProjectStore, decode_code, masked_st, pou_index, read_archive, sha, xml
from .headless import DEFAULT_INSTALL
from .device_profiles import device_profile, all_profiles


LIMITATIONS = [
    'All existing NativeGateway POU code and variable interfaces are parsed anew; the project skeleton, data types and external libraries still come from the pinned seed.',
    'POU kind/return metadata, type worksheets, hardware, tasks, I/O, HMI, packaging and signature changes are unsupported by this cached path.',
    'No target limits service or historical IDE warning replay; the generated image is an offline experiment, not validated for deployment.',
]


def expanded_compile_environment() -> dict:
    result = {'available': False, 'scope': 'NativeGateway_all_existing_POU_code_and_variables',
              'ast_seed_required': True, 'controller_access': False, 'deployable': False}
    try:
        seed, _, install = _verified_seed()
        result.update(seed_directory=str(seed), install_directory=str(install))
        if os.name != 'nt' or not shutil.which('pwsh') or not HOST.with_name('ProjectSourceBuilder.cs').is_file():
            raise ProjectError('Requires Windows, PowerShell 7 and the project source builder.')
        result['available'] = True
    except (OSError, ProjectError) as exc:
        result['reason'] = str(exc)
    return result


def cold_compile_environment() -> dict:
    install = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', DEFAULT_INSTALL)).expanduser().resolve()
    required = [HOST, HOST.with_name('ProjectSourceBuilder.cs'), HOST.with_name('ColdProjectBuilder.cs'),
                install / LOADER, install / 'Ade.CompilerImpl.dll']
    return {'available': os.name == 'nt' and bool(shutil.which('pwsh')) and all(p.is_file() for p in required)
                         and any((install / p['backend']).is_file() for p in all_profiles()),
            'scope': 'registered_device_profiles_single_eCLR_independent_cyclic_tasks_ST_project',
            'device_backends': {p['device_type']: {'backend': p['backend'],
                'installed': (install / p['backend']).is_file()} for p in all_profiles()},
            'ast_seed_required': False, 'precompiled_vendor_libraries_required': True,
            'controller_access': False, 'deployable': False, 'install_directory': str(install)}


def _project_snapshot(store: ProjectStore, project_id: str, expected: str) -> tuple[dict, dict, dict]:
    folder, manifest, current, _, _ = store._current(project_id)
    if manifest['current_sha256'] != expected:
        raise ProjectError('Stale project revision; read the project again before compiling.')
    raw, original, _, _ = read_archive(folder / 'original.pcwex')
    if manifest.get('original_sha256') != SOURCE_PROJECT_SHA256 or sha(raw) != SOURCE_PROJECT_SHA256:
        raise ProjectError('Only the frozen NativeGateway project and its managed revisions are supported.')
    index = pou_index(original)
    if set(original) != set(current):
        raise ProjectError('Adding or removing project members is unsupported.')
    allowed = {p['prefix'] + suffix for p in index.values() for suffix in ('Code.st', 'Variables.var')}
    if any(original[p] != current[p] for p in original if p not in allowed):
        raise ProjectError('Only existing POU ST code and variable worksheets may change.')
    for member in allowed:
        if member not in current or len(current[member]) > MAX_CODE:
            raise ProjectError('Missing or oversized POU source worksheet.')
        decode_code(current[member])
    changed = sorted(p for p in allowed if current[p] != original[p])
    identity = store._identity(folder, manifest) | {
        'changed_source_members': changed, 'pou_count': len(index),
        'pou_kinds': {name: p['kind'] for name, p in index.items()},
        'required_application_cil': sorted([name + '.dll' for name in index] +
                                         [RESOURCE_NAME + '.Common.dll', RESOURCE_NAME + '.exe'])}
    return identity, current, index


def _local_name(node: ET.Element) -> str:
    return node.tag.rsplit('}', 1)[-1]


def _value(node: ET.Element, name: str, default: str = '') -> str:
    return next((c.text or '' for c in node if _local_name(c) == name), default)


def _safe_identifier(value: str, purpose: str) -> str:
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,126}', value):
        raise ProjectError(f'Unsupported {purpose}: requires a plain IEC identifier (127 characters maximum).')
    if value.casefold() in {'con', 'prn', 'aux', 'nul'} or re.fullmatch(r'(com|lpt)[1-9]', value, re.I):
        raise ProjectError(f'Unsupported reserved Windows {purpose}.')
    return value


def _member_path(include: str) -> str:
    parts = include.replace('\\', '/').split('/')
    if any(p in ('', '.', '..') or ':' in p for p in parts):
        raise ProjectError('Unsupported project Include path.')
    return 'PROJECT/' + '/'.join(parts).replace(' ', '%20')


def _validate_pou_registration(document: ET.Element, members: dict, index: dict) -> None:
    """The compiler graph must equal the project graph, including POU IDs."""
    expected = {item['prefix']: item for item in index.values()}
    registered, ids = set(), set()
    for node in document.iter():
        if _local_name(node) != 'Folder' or _value(node, 'FolderType') != 'PouFolder':
            continue
        prefix = _member_path(node.get('Include', '')) + '/'
        if prefix in registered:
            raise ProjectError('Duplicate POU registration in PROJECT.proj: ' + prefix)
        registered.add(prefix)
        if prefix not in expected:
            raise ProjectError('Registered POU source/metadata is missing: ' + prefix)
        try:
            registered_id = uuid.UUID(_value(node, 'Id'))
            metadata_id = uuid.UUID(expected[prefix]['id'])
        except (ValueError, TypeError, AttributeError) as exc:
            raise ProjectError('Invalid registered POU identity: ' + prefix) from exc
        if registered_id != metadata_id or registered_id in ids:
            raise ProjectError('POU registration and metadata identity differ or repeat: ' + prefix)
        ids.add(registered_id)
    archive_prefixes = {p.split('.pou/', 1)[0] + '.pou/' for p in members
                        if p.startswith('PROJECT/Logical%20Elements/') and '.pou/' in p}
    if registered != set(expected) or registered != archive_prefixes:
        raise ProjectError('Project POU registrations differ from archive POU source members.')


def _cold_project_snapshot(store: ProjectStore, project_id: str, expected: str, *,
                             ownership_contract_override: dict | None = None) -> tuple[dict, dict, dict]:
    """Check the managed revision and the explicitly implemented device/source model."""
    folder, manifest, current, _, _ = store._current(project_id)
    if manifest['current_sha256'] != expected:
        raise ProjectError('Stale project revision; read the project again before compiling.')
    preservation = store.validate(project_id)
    if not preservation.get('preservation_passed'):
        raise ProjectError('Project integrity validation failed; undeclared archive changes cannot be compiled.')
    index = pou_index(current)
    for name, pou in index.items():
        _safe_identifier(name, 'POU name')
        if pou['kind'] not in ('Program', 'FunctionBlock', 'Function'):
            raise ProjectError(f'Unsupported POU kind for {name}: {pou["kind"]}.')
        for suffix in ('Code.st', 'Variables.var', 'Metadata.meta'):
            payload = current.get(pou['prefix'] + suffix)
            if payload is None or len(payload) > MAX_CODE:
                raise ProjectError(f'{name} requires bounded ST, variable and metadata worksheets; graphical POUs are unsupported.')
            decode_code(payload)
        metadata = xml(current[pou['prefix'] + 'Metadata.meta'])
        worksheets = metadata.findall('ItemGroup/*')
        if (len([e for e in worksheets if e.tag == 'VariableWorksheet']) != 1 or
                len([e for e in worksheets if e.tag == 'CodeWorksheet' and e.get('Include') == 'Code.st']) != 1 or
                any(e.tag not in ('VariableWorksheet', 'CodeWorksheet') for e in worksheets) or
                len([e for e in worksheets if e.tag == 'CodeWorksheet']) != 1):
            raise ProjectError(f'{name} requires one standard Code.st and one variable worksheet; methods/graphical worksheets are unsupported.')
        extra = [p for p in current if p.startswith(pou['prefix']) and
                 p.rsplit('/', 1)[-1].lower().endswith(('.st', '.fbd', '.ld', '.sfc', '.il')) and
                 p != pou['prefix'] + 'Code.st']
        if extra:
            raise ProjectError(f'Additional/graphical POU worksheets are unsupported: {name}.')
    if 'PROJECT/PROJECT.proj' not in current:
        raise ProjectError('Missing PROJECT/PROJECT.proj.')
    document = xml(current['PROJECT/PROJECT.proj'])
    _validate_pou_registration(document, current, index)
    folders = [e for e in document.iter() if _local_name(e) == 'Folder']
    configurations = [e for e in folders if _value(e, 'FolderType') == 'Configuration']
    resources = [e for e in folders if _value(e, 'FolderType') == 'Resource']
    if len(configurations) != 1 or len(resources) != 1:
        raise ProjectError('Cold compilation supports exactly one registered device configuration and one eCLR resource.')
    configuration, resource = configurations[0], resources[0]
    profile = device_profile(current)
    config_path = _member_path(configuration.get('Include', ''))
    resource_path = _member_path(resource.get('Include', ''))
    if _value(resource, 'TypeName') != 'eCLR' or not resource_path.startswith(config_path + '/'):
        raise ProjectError('Only the configuration\'s single eCLR resource is supported.')
    resource_name = _safe_identifier(resource_path.rsplit('/', 1)[-1], 'resource name')
    ioc = current.get(resource_path + '/IOConfiguration.ioc', b'')
    if masked_st(decode_code(ioc)).strip():
        raise ProjectError('Nonempty IOConfiguration.ioc is not supported by this cold-build profile.')
    esm_path = config_path + '/PLCnext/EsmConfiguration.esmc'
    if esm_path not in current:
        raise ProjectError('Missing source ESM configuration.')
    from .task_configuration import validate_cyclic_schedule
    schedule = validate_cyclic_schedule(current, index,
        ownership_contract=ownership_contract_override if ownership_contract_override is not None
            else manifest.get('multitask_ownership_contract'))
    tasks, instances = schedule['tasks'], schedule['instances']
    project_display_name = manifest.get('project_name') or Path(manifest['source_path']).stem
    if not isinstance(project_display_name, str) or not project_display_name or len(project_display_name) > 240:
        raise ProjectError('Missing or oversized application display name.')
    application_name = project_display_name
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]{0,63}', application_name):
        # Keep ordinary names recognizable; Unicode/spaced names get a stable,
        # safe backend identifier without putting source text into cilc.opt.
        slug = re.sub(r'[^A-Za-z0-9_]', '_', project_display_name).strip('_')[:40]
        application_name = 'Project_' + (slug + '_' if slug else '') + sha(project_display_name.encode('utf-8'))[:12]
    options = [e.text or '' for e in document.iter() if _local_name(e) in ('EnEnoEnabled', 'EnableEnEno', 'Ade.Compiler.EnEnoEnabled')]
    if len(set(x.lower() for x in options)) > 1 or any(x.lower() not in ('true', 'false') for x in options):
        raise ProjectError('Unsupported or ambiguous project EN/ENO option.')
    en_eno = options[0].lower() == 'true' if options else True
    identity = store._identity(folder, manifest) | {
        'application_name': application_name, 'project_display_name': project_display_name, 'resource_name': resource_name,
        'changed_source_members': preservation.get('changed_members', []),
        'pou_count': len(index), 'pou_kinds': {n: p['kind'] for n, p in index.items()},
        # The vendor generator omits unreachable FB/function modules (SEM2005).
        # Reparse coverage is checked separately for every declared source POU.
        'declared_application_cil': sorted(n + '.dll' for n in index),
        'required_application_cil': sorted({i.get('programType') + '.dll' for i in instances} |
                                           {resource_name + '.Common.dll', resource_name + '.exe'}),
        'capability': {'device': profile['device_name'], 'profile_revision': profile['profile_revision'],
            'profile_id': profile['profile_id'], 'profile_sha256': profile['profile_sha256'],
            'compile_family': profile['compile_family'],
            'processor': profile['processor'], 'backend': profile['backend'],
            'resource': resource_name, 'task': tasks[0].get('name') if len(tasks)==1 else None,
            'tasks': [task.get('name') for task in tasks], 'task_count': len(tasks),
            'source_isolation': schedule['source_isolation'], 'en_eno_enabled': en_eno,
            'en_eno_source': 'project_option' if options else 'explicit_profile_default_true',
            'gui_equivalence_established_for_independent_projects': False},
        'preservation_validation': preservation}
    return identity, current, index


def _stage_device_profile(job: Path, members: dict, install: Path) -> tuple[dict, dict]:
    profile = device_profile(members)
    backend = install / profile['backend']
    runtime = install / profile['runtime_package']
    if not backend.is_file() or not runtime.is_file() or runtime.stat().st_size > 64 * 1024 * 1024:
        raise ProjectError('Selected device compiler backend/runtime profile is unavailable.')
    payload = runtime.read_bytes()
    target = job / 'libraries/device-runtime.zip'
    target.parent.mkdir(exist_ok=True);target.write_bytes(payload)
    descriptor = ET.Element('DeviceProfile', deviceName=profile['device_name'],
        revision=profile['profile_revision'], profileId=profile['profile_id'], profileSha256=profile['profile_sha256'],
        runtimePackage='libraries/device-runtime.zip', runtimeSha256=sha(payload),
        runtimeCopyPrefix=profile['runtime_copy_prefix'], namespacesSupported='true',
        hmiAuthenticationProtocol=str(profile['hmi_authentication_protocol']),
        backend=profile['backend'], backendSha256=sha(backend.read_bytes()))
    raw = ET.tostring(descriptor, encoding='utf-8', xml_declaration=True)
    (job / 'device-profile.xml').write_bytes(raw)
    return {'device-profile.xml': sha(raw), 'libraries/device-runtime.zip': sha(payload)}, {
        'profile': profile, 'backend_sha256': descriptor.get('backendSha256'),
        'runtime_package_sha256': sha(payload), 'independent_job_directory': str(job)}


def _stage_libraries(job: Path, members: dict, manifest: dict, install: Path) -> dict[str, str]:
    """Resolve declared library paths against the original project, never the host cwd."""
    document = xml(members['PROJECT/PROJECT.proj'])
    base = Path(manifest.get('library_base_directory') or Path(manifest['source_path']).parent).expanduser().resolve()
    staged = ET.Element('Libraries')
    hashes = {}
    entries = [e for e in document.iter() if _local_name(e) == 'SolutionReference']
    if len(entries) > 64:
        raise ProjectError('At most 64 declared library packages can be snapshotted.')
    total_bytes = 0
    for i, entry in enumerate(entries):
        hint = _value(entry, 'HintPath')
        resolved = hint.replace('$(SystemLibrariesPath)', str(install / 'Libraries')).replace(
            '$(DefaultLibrariesPath)', str(install / 'DefaultLibraries')).replace('$(ProjectDir)', str(base) + os.sep)
        if '$(LibrariesPath)' in resolved:
            libraries = os.environ.get('PLCNEXT_LIBRARIES_DIRECTORY')
            if not libraries or not Path(libraries).expanduser().is_absolute():
                raise ProjectError('$(LibrariesPath) requires explicit absolute PLCNEXT_LIBRARIES_DIRECTORY.')
            resolved = resolved.replace('$(LibrariesPath)', str(Path(libraries).expanduser().resolve()))
        if not hint or '$(' in resolved:
            raise ProjectError(f'Unsupported library HintPath macro: {hint}.')
        source = Path(resolved.replace('\\', os.sep)).expanduser()
        if str(source).startswith(('\\\\', '//')):
            raise ProjectError('Network library HintPath is unsupported; stage the package locally first.')
        source = (source if source.is_absolute() else base / source).resolve()
        if not source.is_file() or source.suffix.lower() not in ('.pcwlx', '.pxclx'):
            raise ProjectError(f'Declared library package unavailable: {source}. Relative HintPath is resolved against {base}.')
        if source.stat().st_size > 64 * 1024 * 1024:
            raise ProjectError('Library package exceeds the 64 MiB snapshot limit.')
        relative = f'libraries/{i:04d}{source.suffix.lower()}'
        target = job / relative
        target.parent.mkdir(exist_ok=True)
        payload = source.read_bytes()
        if len(payload) > 64 * 1024 * 1024:
            raise ProjectError('Library package exceeds the 64 MiB snapshot limit.')
        total_bytes += len(payload)
        if total_bytes > 256 * 1024 * 1024:
            raise ProjectError('Declared library snapshots exceed the 256 MiB total limit.')
        target.write_bytes(payload)
        hashes[relative] = sha(payload)
        ET.SubElement(staged, 'Library', name=entry.get('Include', ''), hint=hint, staged=relative,
                      source=str(source), sha256=hashes[relative])
    payload = ET.tostring(staged, encoding='utf-8', xml_declaration=True)
    (job / 'library-inputs.xml').write_bytes(payload)
    hashes['library-inputs.xml'] = sha(payload)
    return hashes


def _write_sources(job: Path, members: dict, index: dict, project_name: str = 'NativeGateway', en_eno: bool | None = None) -> dict[str, str]:
    document = ET.Element('Sources', projectName=project_name)
    if en_eno is not None:
        document.set('enEnoEnabled', str(en_eno).lower())
    hashes = {}
    for name, pou in sorted(index.items()):
        _safe_identifier(name, 'POU name')
        folder = _contained(job.resolve(), 'sources/' + name)
        folder.mkdir(parents=True)
        attributes = {'name': name, 'kind': pou['kind'], 'prefix': pou['prefix']}
        for key, suffix in (('code', 'Code.st'), ('variables', 'Variables.var'), ('metadata', 'Metadata.meta')):
            relative = f'sources/{name}/{suffix}'
            payload = members[pou['prefix'] + suffix]
            (job / relative).write_bytes(payload)
            hashes[relative] = sha(payload)
            attributes[key] = relative
            attributes[key + '_sha256'] = hashes[relative]
        ET.SubElement(document, 'POU', attributes)
    raw = ET.tostring(document, encoding='utf-8', xml_declaration=True)
    (job / 'sources.xml').write_bytes(raw)
    hashes['sources.xml'] = sha(raw)
    return hashes


def compile_nativegateway(store: ProjectStore, project_id: str, expected_project_sha256: str, *, cold: bool = False) -> dict:
    """Reparse every POU from current source, then regenerate CIL and a new native image."""
    folder = store._folder(project_id)
    with store._lock(folder):
        identity, members, index = (_cold_project_snapshot if cold else _project_snapshot)(store, project_id, expected_project_sha256)
        if cold:
            install = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', DEFAULT_INSTALL)).expanduser().resolve()
            seed, manifest = None, {'files': {}}
        else:
            seed, manifest, install = _verified_seed()
        shell = shutil.which('pwsh')
        if os.name != 'nt' or not shell:
            raise ProjectError('Offline compilation requires Windows and PowerShell 7.')
        builds = folder / 'builds'
        if builds.resolve().parent != folder:
            raise ProjectError('Build directory escapes its project.')
        builds.mkdir(exist_ok=True)
        job = builds / uuid.uuid4().hex
        job.mkdir()
        (job / 'input').mkdir()
        (job / 'references').mkdir()
        input_hashes = _write_sources(job, members, index, identity.get('application_name', Path(identity['project_path']).stem),
                                     identity.get('capability', {}).get('en_eno_enabled'))
        toolchain = None
        if cold:
            profile_inputs, toolchain = _stage_device_profile(job, members, install)
            input_hashes.update(profile_inputs)
            input_hashes.update(_stage_libraries(job, members, store._load(project_id)[1], install))
            project_root = job / 'project'
            project_root.mkdir()
            for relative, payload in members.items():
                target = _contained(project_root.resolve(), relative)
                if relative.endswith('/'):
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(payload)
                input_hashes['project/' + relative] = sha(payload)
        for relative, record in manifest['files'].items():
            if relative == 'cilc.opt':
                continue
            target = job / relative
            shutil.copyfile(_contained(seed, relative), target)
            if sha(target.read_bytes()) != record['sha256']:
                raise ProjectError('Compilation seed changed while copying; no host was started.')
            input_hashes[relative] = record['sha256']
    result = identity | {'job_id': job.name, 'job_directory': str(job), 'compiled': False,
        'status': 'not_run', 'stage': 'host', 'cache_assisted': not cold, 'ast_seed_used': not cold,
        'iec_model_rebuilt_from_sources': False, 'precompiled_library_packages_used': cold,
        'build_mode': 'cold' if cold else 'cached',
        'application_name': identity['application_name'] if cold else 'revision-0001',
        'whole_project_rebuilt_from_pcwex': False, 'deployable': False, 'aci_used': False,
        'computer_use_used': False, 'controller_connected': False, 'controller_downloaded': False,
        'toolchain': toolchain,
        'input_hashes': input_hashes, 'limitations': (LIMITATIONS.copy() if not cold else [
            'Independent registered-device single-resource, 1..16 cyclic-task IEC source cold build; POUs and interfaces are constructed without a project AST seed.',
            'EN/ENO uses the reported project option or explicit profile default true; independent projects have no GUI equivalence guarantee.',
            'Requires installed compiler, vendor and project-referenced library packages; no full network/HMI/signature/deployment-package regeneration or PLC execution validation.',
            'No target limits service or historical IDE warning replay.']),
        'started_utc': datetime.now(timezone.utc).isoformat()}

    def finish(status, stage, error=None):
        result.update(status=status, stage=stage, ended_utc=datetime.now(timezone.utc).isoformat(),
                      report_path=str(job / 'result.json'))
        if error:
            result['error'] = str(error)[:4000]
        (job / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return result

    command = [shell, '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(HOST),
               '-WorkRoot', str(job), '-InstallDirectory', str(install), '-ColdProject' if cold else '-ProjectSources']
    try:
        run = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    except subprocess.TimeoutExpired:
        return finish('host_timeout', 'host', 'Compiler host exceeded 30 seconds and was terminated.')
    except OSError as exc:
        return finish('host_failed', 'host', exc)
    (job / 'host-stdout.log').write_bytes(run.stdout[:65536])
    (job / 'host-stderr.log').write_bytes(run.stderr[:65536])
    result['host_exit_code'] = run.returncode
    try:
        host = _json(job / 'host-result.json')
    except ProjectError as exc:
        return finish('host_failed', 'host', exc)
    result['host'] = host
    if (host.get('source_sha256') != input_hashes['sources.xml'] or
            host.get('source_sha256_after') != input_hashes['sources.xml'] or
            any(not (job / p).is_file() or sha((job / p).read_bytes()) != h for p, h in input_hashes.items())):
        return finish('host_input_mismatch', 'host', 'Compile input was changed or host checked a different source manifest.')
    result['iec_model_rebuilt_from_sources'] = bool(cold and host.get('pous_reparsed') == len(index)
                                                  and host.get('interfaces_reparsed') == len(index))
    if run.returncode:
        return finish('host_failed', 'host')
    if host.get('status') != 'cil_generated':
        status = host.get('status', 'host_failed')
        return finish(status, 'syntax' if status == 'syntax_failed' else 'semantic' if status == 'semantic_failed'
                      else 'libraries' if status == 'library_failed' else 'cil')
    if host.get('pous_reparsed') != len(index) or host.get('interfaces_reparsed') != len(index):
        return finish('host_coverage_mismatch', 'host', 'Not all POU bodies and interfaces were parsed from source.')
    generated = job / 'generated'
    resource_name = identity.get('resource_name', RESOURCE_NAME)
    if (generated.resolve().parent != job or not generated.is_dir() or host.get('resource_name') != resource_name
            or any(not (generated / n).is_file() for n in identity['required_application_cil'])):
        return finish('cil_output_missing', 'cil')
    if any(p.suffix.lower() == '.img' for p in generated.rglob('*')):
        return finish('unexpected_old_image', 'cil')
    result['pou_emission'] = {
        'declared_count': len(index), 'parsed_count': host['pous_reparsed'],
        'emitted': sorted(name for name in index if (generated / (name + '.dll')).is_file()),
        'not_emitted': sorted(name for name in index if not (generated / (name + '.dll')).is_file()),
        'note': 'The vendor generator may omit unreferenced POUs after whole-source parsing and semantic analysis.'}
    result['pou_emission']['emitted_count'] = len(result['pou_emission']['emitted'])
    for relative, record in manifest['files'].items():
        if relative.startswith('references/'):
            target = generated / Path(relative).name
            if not target.exists():
                shutil.copyfile(_contained(seed, relative), target)
                if sha(target.read_bytes()) != record['sha256']:
                    return finish('reference_copy_failed', 'native')
    if cold:
        for runtime in (job / 'references').glob('*.dll'):
            destination = generated / runtime.name
            if not destination.exists():
                shutil.copyfile(runtime, destination)
        (generated / 'cilc.opt').write_text('-exename ' + resource_name + '\n-swdiv\n-dbg\n-appname '
                                          + result['application_name'] + '\n', encoding='utf-8')
    else:
        shutil.copyfile(seed / 'cilc.opt', generated / 'cilc.opt')
    backend = identity['capability']['backend'] if cold else BACKEND
    if cold and sha((install / backend).read_bytes()) != toolchain['backend_sha256']:
        return finish('backend_input_changed', 'native')
    command = [str(install / LOADER), '-optfile', 'cilc.opt', '-cilc', str(install / backend)]
    try:
        native = subprocess.run(command, cwd=generated, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
    except subprocess.TimeoutExpired:
        return finish('backend_timeout', 'native')
    except OSError as exc:
        return finish('backend_failed', 'native', exc)
    (job / 'backend-stdout.log').write_bytes(native.stdout[:65536])
    (job / 'backend-stderr.log').write_bytes(native.stderr[:65536])
    result['backend_exit_code'] = native.returncode
    image = generated / (resource_name + '.img')
    if cold and sha((install / backend).read_bytes()) != toolchain['backend_sha256']:
        return finish('backend_input_changed', 'native')
    if native.returncode or not image.is_file() or not image.stat().st_size:
        return finish('backend_failed', 'native')
    result.update(compiled=True, image_path=str(image), image_bytes=image.stat().st_size,
                  image_sha256=sha(image.read_bytes()), generated_files=[
                      {'name': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                      for p in sorted(generated.iterdir()) if p.is_file()],
                  project_current_at_completion=store._current(project_id)[1]['current_sha256'] == expected_project_sha256)
    analyzed_model = job / 'analyzed.LastBuild.ast'
    if cold and analyzed_model.is_file():
        result['analyzed_compiler_model'] = {'name': analyzed_model.name,
            'bytes': analyzed_model.stat().st_size, 'sha256': sha(analyzed_model.read_bytes()),
            'rebuilt_from_current_sources': result['iec_model_rebuilt_from_sources']}
    return finish('compiled', 'native')
