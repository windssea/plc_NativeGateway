"""Bounded native image ABI inspection, as data only; never load PLC programs."""
import json,os
from pathlib import Path
import shutil,subprocess,tempfile
from .project import ProjectError,sha
from .headless import DEFAULT_INSTALL

def inspect_native_image(image_path, expected_sha256):
    path=Path(image_path).expanduser().resolve(strict=True)
    if path.suffix.lower()!='.img' or path.stat().st_size>64*1024*1024 or sha(path.read_bytes())!=expected_sha256:
        raise ProjectError('Expected an exact bounded native .img SHA-256.')
    install=Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY',DEFAULT_INSTALL))
    shell=shutil.which('pwsh')
    if not shell:raise ProjectError('Native image metadata inspection requires PowerShell 7.')
    with tempfile.TemporaryDirectory(prefix='plcnext-image-metadata-') as directory:
        result=subprocess.run([shell,'-NoLogo','-NoProfile','-NonInteractive','-File',
            str(Path(__file__).parent/'compile_host/Invoke-FinalizeRuntime.ps1'),'-InputImage',str(path),
            '-OutputDirectory',directory,'-InstallDirectory',str(install),'-InspectOnly'],
            capture_output=True,timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        report=Path(directory)/'runtime-types-report.json'
        data=json.loads(report.read_text(encoding='utf-8-sig')) if report.exists() else {}
        if result.returncode or data.get('status')!='native_image_inspected':
            raise ProjectError('Native image metadata inspection failed.')
    if sha(path.read_bytes())!=expected_sha256:
        raise ProjectError('Native image changed during metadata inspection.')
    return {**data,'image_path':str(path),'image_sha256':expected_sha256,'read_only':True}
