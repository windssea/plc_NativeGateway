"""Bounded cache-assisted compilation of one pinned NativeGateway ST body.

The seed supplies a GUI-created semantic model and external library CIL.  Every
application CIL assembly and the native image must be generated in the new job.
This is deliberately not a general PCWEX compiler or a deployment interface.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import uuid

from .headless import DEFAULT_INSTALL
from .project import MAX_CODE, ProjectError, ProjectStore, decode_code, pou_index, read_archive, sha


SOURCE_PROJECT_SHA256 = 'b78ba0efd0f8f79558143d58f3eb141512876690b2eda2a641e96ba3a3cbaddf'
GUI_PROJECT_SHA256 = 'b58151316681f1c53d2b9a29c35bff2ee6f8fcbe53918b3bd1406cd784dbb884'
SEED_AST_SHA256 = '4355612c1c7518299e1c378bb826836a2bb3cf937e24119c074dcd345a5bd008'
RESOURCE_NAME = 'RES_23CA7F267545404C9FED5DC977A6399F'
TARGET_POU = 'NG_ReadAck'
TARGET_MEMBER = 'PROJECT/Logical%20Elements/NG_ReadAck.pou/Code.st'
BACKEND = 'CIL-Compiler/cilc-armthumb2-arm-v3.0.0.dll'
LOADER = 'CIL-Compiler/CilCompilerLoader.exe'
HOST = Path(__file__).parent / 'compile_host' / 'Invoke-CachedCompile.ps1'
DEFAULT_SEED = Path(__file__).resolve().parents[2] / 'artifacts' / 'nativegateway-compile-seed'
LIMITATIONS = [
    'Cache-assisted compilation of the existing NG_ReadAck ST body only, using a pinned GUI-generated NativeGateway semantic seed.',
    'All other project member payloads must exactly match the frozen B78 project; declarations, interfaces, tasks, I/O and HMI changes are unsupported.',
    'The complete project is not rebuilt from PCWEX; network, I/O, HMI, packaging and deployment consistency are not regenerated or validated.',
    'Requires the exact recorded installed Engineer assemblies and seed libraries; this is not an independent compiler implementation.',
    'The resulting image is an offline experimental artifact, is not approved for deployment, and has not been run on a PLC.',
]


def _json(path: Path, limit: int = 2 * 1024 * 1024) -> dict:
    if not path.is_file() or path.stat().st_size > limit:
        raise ProjectError(f'Missing or oversized JSON report: {path.name}')
    try:
        result = json.loads(path.read_text(encoding='utf-8-sig'))
    except (ValueError, UnicodeError) as exc:
        raise ProjectError(f'Invalid JSON report: {path.name}') from exc
    if not isinstance(result, dict):
        raise ProjectError(f'Expected JSON object: {path.name}')
    return result


def _contained(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or '\\' in relative or ':' in relative:
        raise ProjectError('Unsafe seed member path.')
    candidate = (root / relative).resolve()
    if not candidate.is_relative_to(root) or candidate == root:
        raise ProjectError('Seed member escapes its directory.')
    return candidate


def _verified_seed() -> tuple[Path, dict, Path]:
    root = Path(os.environ.get('PLCNEXT_NATIVEGATEWAY_SEED', DEFAULT_SEED)).expanduser().resolve()
    install = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', DEFAULT_INSTALL)).expanduser().resolve()
    manifest = _json(root / 'manifest.json')
    if (manifest.get('schema') != 1 or manifest.get('source_project_sha256') != SOURCE_PROJECT_SHA256
            or manifest.get('gui_project_sha256') != GUI_PROJECT_SHA256
            or manifest.get('ast_sha256') != SEED_AST_SHA256
            or manifest.get('target_pou') != TARGET_POU or manifest.get('resource_name') != RESOURCE_NAME):
        raise ProjectError('Unsupported NativeGateway compilation seed identity.')
    if manifest.get('device_profile') != {'name': 'AXCF2152', 'version': '2026.0.0', 'namespaces_supported': True}:
        raise ProjectError('Seed device profile does not match the measured AXCF2152 namespace settings.')
    records, vendor = manifest.get('files'), manifest.get('vendor_files')
    if not isinstance(records, dict) or not isinstance(vendor, dict) or not records or not vendor:
        raise ProjectError('Seed file/hash manifest is incomplete.')
    if records.get('input/LastBuild.ast', {}).get('sha256') != SEED_AST_SHA256:
        raise ProjectError('Seed AST identity is not the pinned GUI model.')
    if 'cilc.opt' not in records or LOADER not in vendor or BACKEND not in vendor:
        raise ProjectError('Seed lacks backend options or installed-tool identities.')
    for relative, entry in records.items():
        path = _contained(root, relative)
        allowed = relative in ('input/LastBuild.ast', 'cilc.opt') or (
            relative.startswith('references/') and len(Path(relative).parts) == 2
            and Path(relative).suffix.lower() == '.dll'
            and not _application_file(Path(relative).name))
        if (not allowed or not isinstance(entry, dict) or not path.is_file()
                or path.stat().st_size != entry.get('length')
                or sha(path.read_bytes()) != entry.get('sha256')):
            raise ProjectError(f'Compilation seed file is unsupported or changed: {relative}')
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if actual != set(records) | {'manifest.json'}:
        raise ProjectError('Seed contains unexpected files; regenerate a clean seed.')
    for relative, digest in vendor.items():
        path = _contained(install, relative)
        if not path.is_file() or sha(path.read_bytes()) != digest:
            raise ProjectError(f'Installed Engineer file changed from the seed: {relative}')
    return root, manifest, install


def _application_file(name: str) -> bool:
    lower = name.casefold()
    return lower.startswith(('ng_', 'res_')) or lower == 'main.dll'


def cached_compile_environment() -> dict:
    result = {'available': False, 'scope': 'pinned_NativeGateway_NG_ReadAck_cache_assisted',
              'aci_used': False, 'whole_project_rebuilt_from_pcwex': False,
              'cache_assisted': True, 'deployable': False, 'limitations': LIMITATIONS.copy()}
    try:
        seed, manifest, install = _verified_seed()
        shell = shutil.which('pwsh')
        result.update(seed_directory=str(seed), install_directory=str(install), powershell=shell,
                      reference_count=sum(p.startswith('references/') for p in manifest['files']))
        if os.name != 'nt' or not shell:
            raise ProjectError('Cache-assisted compilation requires Windows and PowerShell 7.')
        if not HOST.is_file() or not HOST.with_name('CachedCompilerHost.cs').is_file():
            raise ProjectError('Packaged cached compile host is missing.')
        result['available'] = True
    except (ProjectError, OSError) as exc:
        result['reason'] = str(exc)
    return result


def _project_input(store: ProjectStore, project_id: str, expected: str, pou_name: str) -> tuple[dict, bytes]:
    if pou_name != TARGET_POU:
        raise ProjectError('Cache-assisted compilation currently supports only NG_ReadAck.')
    folder, manifest, current, _, _ = store._current(project_id)
    if manifest['current_sha256'] != expected:
        raise ProjectError('Stale project revision; read the current project hash before compiling.')
    raw, original, _, _ = read_archive(folder / 'original.pcwex')
    if manifest.get('original_sha256') != SOURCE_PROJECT_SHA256 or sha(raw) != SOURCE_PROJECT_SHA256:
        raise ProjectError('Cache-assisted compilation only supports the exact frozen NativeGateway B78 project.')
    if set(current) != set(original) or TARGET_MEMBER not in current:
        raise ProjectError('Project member set differs from the supported NativeGateway seed.')
    changed = [name for name in original if name != TARGET_MEMBER and current[name] != original[name]]
    if changed:
        raise ProjectError('Only the NG_ReadAck ST body may change; unsupported member: ' + changed[0])
    source = current[TARGET_MEMBER]
    if len(source) > MAX_CODE:
        raise ProjectError('ST input exceeds the 2 MiB compile limit.')
    decode_code(source)
    identity = store._identity(folder, manifest)
    applications = sorted(name + '.dll' for name in pou_index(original))
    applications += [RESOURCE_NAME + '.Common.dll', RESOURCE_NAME + '.exe']
    return identity | {'pou_name': TARGET_POU, 'code_sha256': sha(source),
                       'required_application_cil': applications}, source


def compile_cached_ng_readack(store: ProjectStore, project_id: str, expected_project_sha256: str,
                              pou_name: str = TARGET_POU) -> dict:
    """Compile one hash-pinned ST revision through fresh CIL and native image generation."""
    folder = store._folder(project_id)
    # Freeze all managed input bytes under the same lock used by project_patch_st.
    with store._lock(folder):
        identity, source = _project_input(store, project_id, expected_project_sha256, pou_name)
        seed, manifest, install = _verified_seed()
        shell = shutil.which('pwsh')
        if os.name != 'nt' or not shell or not HOST.is_file():
            raise ProjectError('Cache-assisted compile host requires Windows, PowerShell 7 and the packaged host.')
        builds = folder / 'builds'
        if builds.resolve().parent != folder:
            raise ProjectError('Build directory escapes its managed project.')
        builds.mkdir(exist_ok=True)
        job = builds / uuid.uuid4().hex
        job.mkdir()
        (job / 'input').mkdir()
        (job / 'references').mkdir()
        (job / 'source.st').write_bytes(source)
        for relative, record in manifest['files'].items():
            if relative == 'cilc.opt':
                continue
            copied = job / relative
            shutil.copyfile(_contained(seed, relative), copied)
            if sha(copied.read_bytes()) != record['sha256']:
                raise ProjectError('Compilation seed changed while copying inputs; no tool was started.')
    result = identity | {'job_id': job.name, 'job_directory': str(job), 'compiled': False,
                         'stage': 'host', 'status': 'not_run', 'cache_assisted': True,
                         'whole_project_rebuilt_from_pcwex': False, 'whole_project_compiled': False,
                         'deployable': False, 'aci_used': False, 'computer_use_used': False,
                         'controller_connected': False, 'controller_downloaded': False,
                         'limitations': LIMITATIONS.copy(),
                         'started_utc': datetime.now(timezone.utc).isoformat()}

    def finish(status: str, stage: str, detail: str | None = None) -> dict:
        result.update(status=status, stage=stage, ended_utc=datetime.now(timezone.utc).isoformat())
        if detail:
            result['error'] = detail[:4000]
        result['report_path'] = str(job / 'result.json')
        (job / 'result.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        return result

    command = [shell, '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(HOST),
               '-WorkRoot', str(job), '-InstallDirectory', str(install)]
    result['host_command'] = command
    try:
        completed = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, timeout=30,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except subprocess.TimeoutExpired:
        return finish('host_timeout', 'host', 'Cached compile host exceeded 30 seconds and was terminated.')
    except OSError as exc:
        return finish('host_failed', 'host', str(exc))
    (job / 'host-stdout.log').write_bytes(completed.stdout[:65536])
    (job / 'host-stderr.log').write_bytes(completed.stderr[:65536])
    result['host_exit_code'] = completed.returncode
    try:
        host = _json(job / 'host-result.json')
    except ProjectError as exc:
        return finish('host_failed', 'host', str(exc))
    result['host'] = host
    if (host.get('source_sha256') != identity['code_sha256']
            or host.get('source_sha256_after') != identity['code_sha256']
            or sha((job / 'source.st').read_bytes()) != identity['code_sha256']):
        return finish('host_input_mismatch', 'host', 'Host report does not match this exact ST input.')
    if completed.returncode or host.get('status') != 'cil_generated':
        status = host.get('status', 'host_failed')
        if completed.returncode and status == 'cil_generated':
            return finish('host_failed', 'host', 'Host process failed despite reporting generated CIL.')
        stage = 'syntax' if status == 'syntax_failed' else 'semantic' if status == 'semantic_failed' else 'host'
        return finish(status if isinstance(status, str) else 'host_failed', stage)
    generated = job / 'generated'
    required = identity['required_application_cil']
    if (not generated.is_dir() or generated.resolve().parent != job
            or host.get('resource_name') != RESOURCE_NAME
            or any(not (generated / name).is_file() for name in required)):
        return finish('cil_output_missing', 'cil', 'Host did not create the required fresh application CIL files.')
    if any(p.suffix.casefold() == '.img' for p in generated.rglob('*')):
        return finish('unexpected_old_image', 'cil', 'An image existed before the backend was run.')
    for relative, record in manifest['files'].items():
        if not relative.startswith('references/'):
            continue
        destination = generated / Path(relative).name
        if destination.exists():
            # A new generator file always takes precedence. Do not overwrite it.
            continue
        shutil.copyfile(_contained(seed, relative), destination)
        if sha(destination.read_bytes()) != record['sha256']:
            return finish('reference_copy_failed', 'cil', 'Runtime reference copy hash mismatch.')
    shutil.copyfile(seed / 'cilc.opt', generated / 'cilc.opt')
    backend = [str(install / LOADER), '-optfile', 'cilc.opt', '-cilc', str(install / BACKEND)]
    result['backend_command'] = backend
    result['backend_working_directory'] = str(generated)
    try:
        native = subprocess.run(backend, cwd=generated, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except subprocess.TimeoutExpired:
        return finish('backend_timeout', 'native', 'CIL native backend exceeded 15 seconds and was terminated.')
    except OSError as exc:
        return finish('backend_failed', 'native', str(exc))
    (job / 'backend-stdout.log').write_bytes(native.stdout[:65536])
    (job / 'backend-stderr.log').write_bytes(native.stderr[:65536])
    result['backend_exit_code'] = native.returncode
    image = generated / (RESOURCE_NAME + '.img')
    if native.returncode or not image.is_file() or not image.stat().st_size:
        return finish('backend_failed', 'native', 'Native backend failed or did not create a new image.')
    result['generated_files'] = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                                 for p in sorted(generated.iterdir()) if p.is_file()]
    result['image_path'] = str(image)
    result['image_sha256'] = sha(image.read_bytes())
    result['compiled'] = True
    result['project_current_at_completion'] = store._current(project_id)[1]['current_sha256'] == expected_project_sha256
    return finish('compiled', 'native')
