"""One owned 127.0.0.1 TLS endpoint for the complete multi-session recovery test."""
from __future__ import annotations

from . import rsc_tagged_codec as tagged
from .controller_test_peer import LocalTlsController, _DropReply, FAULTS as TRANSFER_FAULTS
from .controller_transport import PLC, FILE, FILESYSTEM, PROVIDER, SCHEMAS as DOWNLOAD_SCHEMAS
from .rsc_codec import CommandHeader, CommandType, DATA_TAGGING, DATAGRAMMING, decode_header, encode_header
from .rsc_runtime_codec import DATA_ACCESS, PLC_INFO, encode_read_items, encode_variant

FAULTS=frozenset({'none','baseline_disconnect','initial_wrong','stop_reply_lost','write_reply_lost',
    'readback_corrupt','reset_reply_lost','load_reply_lost','start_reply_lost',
    'configuration_mismatch','runtime_disconnect','wrong_project_name'})


class LocalRecoveryPeer(LocalTlsController):
    def __init__(self,root,files,values,*,fault='none'):
        if fault not in FAULTS:raise ValueError('Unsupported recovery fixture fault.')
        super().__init__(root,allowed_files=set(files),initial_state=2 if fault=='initial_wrong' else 3,
            fault=fault if fault in TRANSFER_FAULTS else 'none')
        self.recovery_fault=fault;self.values=dict(values);self.package=dict(files)
        self.start_calls=0;self.variable_calls=0;self.project_name='PUBLIC-candidate-before-recovery'
        self.on_stop=None;self.on_session=None
        for relative,data in files.items():
            target=self.root.joinpath(*relative.split('/'));target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
        # A declared path can contain old bytes; subsequent write/readback must prove replacement.
        image=next((p for p in files if p.endswith('eCLR.img')),None)
        if image:self.root.joinpath(*image.split('/')).write_bytes(b'PUBLIC prior image fixture')

    def _session(self,channel):
        if self.on_session is not None:self.on_session(self)
        connected=False;handles={};next_handle=1700+self.connections*17;provider=900+self.connections
        schemas=dict(DOWNLOAD_SCHEMAS)
        schemas.update({(PLC,2):(['byte','bool'],[]),(DATA_ACCESS,2):(['utf8[]'],[]),(PLC_INFO,1):(['int32'],[])})
        while not self._stop.is_set():
            raw=self._exact(channel,16);header,token=decode_header(raw,require_checksum=True)
            if header.command_type==CommandType.CONNECT_REQUEST:
                if connected or header.version!=4 or header.flags!=(DATA_TAGGING|DATAGRAMMING) or header.data_length:
                    raise ValueError('Unsupported recovery fixture Connect.')
                self._record('Connect',session=self.connections,mutating=False)
                connected=True;self._reply(channel,tagged.encode_connect_confirmation());continue
            if not connected or token is not None or header.flags!=DATA_TAGGING:
                raise ValueError('Unsupported recovery fixture session.')
            if header.command_type==CommandType.GET_SERVICE_HANDLES_REQUEST:
                if not 0<=header.data_length<=2054:raise ValueError('Oversized discovery.')
                names=tagged.decode_get_service(raw+self._exact(channel,header.data_length))
                if names[0]!=PROVIDER or names[1] not in (PLC,FILE,FILESYSTEM,DATA_ACCESS,PLC_INFO):
                    raise ValueError('Unknown recovery fixture service.')
                if names[1] not in handles:handles[names[1]]=next_handle;next_handle+=1
                self._record('GetServiceHandles',service=names[1],session=self.connections)
                self._reply(channel,tagged.encode_get_service_confirmation(handles[names[1]],provider));continue
            service=next((s for s,h in handles.items() if h==header.service_handle),None)
            schema=schemas.get((service,header.method_handle))
            if (schema is None or header.command_type!=CommandType.INVOKE_REQUEST or header.data_length
                    or header.service_provider_handle!=provider):raise ValueError('Unknown recovery invocation.')
            values=tagged.receive_values(lambda count:channel.recv(count),schema[0])
            self._record('Invoke',service=service,method=header.method_handle,session=self.connections,
                mutating=(service==FILE and header.method_handle==8) or service==PLC and header.method_handle!=5)
            if service==DATA_ACCESS:
                self.variable_calls+=1
                if self.recovery_fault=='baseline_disconnect' or self.recovery_fault=='runtime_disconnect' and self.start_calls:
                    raise _DropReply('PUBLIC runtime disconnect.')
                rows=[]
                for path in values[0]:
                    row=self.values.get(path)
                    rows.append({'error_code':0,**row} if row is not None else {'error_code':1,'wire_type':'null','value':None})
                payload=encode_read_items(rows)
            elif service==PLC_INFO:
                if values!=[1]:raise ValueError('Only ProjectName is admitted.')
                payload=encode_variant({'wire_type':'utf8','value':self.project_name})+b'\xff'
            elif service==PLC and header.method_handle==3:
                if values!=[True]:raise ValueError('Wrong Stop value.')
                self.stop_calls+=1;self.state=2;self._record('Stop',session=self.connections)
                if self.on_stop is not None:self.on_stop(self)
                if self.recovery_fault=='stop_reply_lost':raise _DropReply('PUBLIC Stop reply lost.')
                payload=b'\xff'
            elif service==PLC and header.method_handle==2:
                if not self.loaded or values[0] not in (1,2,3,4) or values[1] is not True:
                    raise ValueError('Start before verified fixture load.')
                self.start_calls+=1;self.state=3;self._record('Start',session=self.connections)
                for path,row in self.values.items():
                    if path.endswith('.BootId'):row['value']='PUBLIC-restored-boot'
                if self.recovery_fault=='start_reply_lost':raise _DropReply('PUBLIC Start reply lost.')
                payload=b'\xff'
            else:
                selected=self.fault
                if service==FILE and header.method_handle==9 and self.fault=='readback_corrupt' and self.write_calls==0:
                    self.fault='none'  # Exercise data verification, not the earlier old-manifest parser.
                try:result=super()._invoke(service,header.method_handle,values)
                finally:self.fault=selected
                if service==PLC and header.method_handle==1 and self.loaded:
                    from .project import xml
                    root=xml(self.package['Plc/Domain/pcwe.plc.config'])
                    self.project_name=next(e.get('name') for e in root.iter() if e.tag.rsplit('}',1)[-1]=='Project')
                    if self.recovery_fault=='wrong_project_name':self.project_name='PUBLIC-wrong-project'
                    if self.recovery_fault=='configuration_mismatch':
                        for path,row in self.values.items():
                            if path.endswith('.Active.Version'):row['value']+=1
                payload=tagged.encode_values(schema[1],result)
            response=CommandHeader(version=4,flags=DATA_TAGGING,command_type=CommandType.INVOKE_CONFIRMATION,
                service_handle=header.service_handle,service_provider_handle=provider,method_handle=header.method_handle)
            self._reply(channel,encode_header(response)+payload)
