"""Exact recovery-owned audit session, prepared before Start, drained before runtime checks."""
from copy import deepcopy
from datetime import datetime,timezone
import json
import os
import time
from .project import ProjectError,sha
from .audit_export import load,AuditClient,DurableJournal,_AUTHORITY,_audit,_ACK
from .audit_collector import Exporter,EvidenceError
from .operator_approval import _new_file
from .rsc_runtime_codec import DATA_ACCESS

class ParentAudit:
    def __init__(self,store,parent,lease,job,loaded,active,deadline):
        self.finished=False;self.client=None;self.journal=None;self.active=active;self.deadline=deadline
        from .controller_recovery import _digest
        if _digest(parent)!=parent['review_sha256']:raise ProjectError('Parent recovery hash changed before audit arming.')
        ref=parent['children']['audit'];self.folder,static,symbols=load(store,parent['project_id'],ref['plan_id'],ref['plan_sha256'])
        self.static=static;self.parent=parent;self.lease=lease;self.job=job
        if (static['policy'].get('parent_recovery_plan_id')!=parent['plan_id']
                or static['policy'].get('boot_binding')!='observe_same_parent_start'
                or static['target']!=parent['target'] or static['project_sha256']!=parent['source']['project_sha256']
                or static['inventory_sha256']!=parent['package']['inventory_sha256']
                or lease.plan_id!=parent['plan_id'] or lease.target!=parent['target']
                or lease.review_sha256!=parent['children']['stop']['review_sha256']
                or 'fsync_and_ack_fixed_audit_cursors_after_same_start' not in parent['approved_actions']):
            raise ProjectError('Audit does not belong to this exact authorized recovery lease.')
        if (not loaded.get('load_state_verified') or loaded.get('files_verified')!=len(parent['files'])
                or loaded.get('outcome_unknown') or loaded.get('cleanup_error_class')):
            raise ProjectError('Parent audit requires complete same-parent file readback and Load.')
        self.result={'schema':'plcnext-parent-audit-result/v1','parent_plan_id':parent['plan_id'],
            'parent_review_sha256':parent['review_sha256'],'audit_plan_id':ref['plan_id'],'audit_plan_sha256':ref['plan_sha256'],
            'status':'audit_prepared_before_start','complete':False,'outcome_unknown':False,
            'output_path':static['output_path'],'shared_parent_lease':True,'automatic_restore':False,
            'load_receipt_sha256':sha((job/'load-result.json').read_bytes()),'post_start_package_reads':0,
            'boot_source':'same_parent_start_observed_not_predicted','device_control_sent_by_audit':False}
        try:
            _new_file(self.folder/'parent-binding.json',self.result)
            from .operation_jobs import _process_birth
            _new_file(self.folder/'started.json',{'parent_review_sha256':parent['review_sha256'],'host_pid':os.getpid(),
                'host_process_birth':_process_birth(os.getpid()),'parent_execution_directory':str(job)})
            self.journal=DurableJournal(self.folder/'events.jsonl',max_bytes=static['policy']['maximum_bytes'],max_records=static['policy']['maximum_records'])
            runtime=deepcopy(static)
            self.client=AuditClient(runtime,symbols,_AUTHORITY,self.check,lambda event:_audit(self.folder/'transport.jsonl',event))
            self.client.overall_end=deadline;self.client.connect();self.client._runtime_service(DATA_ACCESS)
            self.pre_start=self.client.read(['BootId','Active.Version'])
            self.result['pre_start_boot']=self.pre_start['BootId']
            self.journal.append([{'kind':'armedBeforeStart','parent_review_sha256':parent['review_sha256'],
                'audit_plan_sha256':ref['plan_sha256'],'load_receipt_sha256':self.result['load_receipt_sha256']}])
        except Exception:
            if self.client:self.client.close()
            if self.journal:self.journal.close()
            raise
    def check(self):
        self.active()
        if (self.folder/'cancel.json').exists():raise EvidenceError('Audit child cancelled')
        if time.monotonic()>self.deadline:raise EvidenceError('Parent audit deadline')
    def run(self,start_result):
        begun=time.monotonic();self.result['start_result']=dict(start_result)
        try:
            if (start_result.get('review_sha256')!=self.parent['children']['start']['review_sha256']
                    or start_result.get('target')!=self.parent['target'] or start_result.get('action')!='start'
                    or start_result.get('status')!='control_completed' or not start_result.get('action_sent')
                    or not start_result.get('ack_received') or not start_result.get('terminal_state_verified')
                    or not start_result.get('loaded_package_identity_verified') or start_result.get('outcome_unknown')):
                raise EvidenceError('No verified causal parent Start; no audit ACK')
            until=self.deadline
            waiting=Exporter(self.client,self.journal)
            waiting.fact_mode=self.static['policy'].get('fact_mode','legacy_v1')
            while True:
                self.check();observed=waiting.head()
                boot=observed['BootId']
                if type(boot) is str and boot and boot!=self.pre_start['BootId']:break
                # Before application identity exists no ACK is allowed. A lost
                # prefix cannot be repaired by waiting longer for BootId.
                for ring in ('Audit','Association'):
                    for suffix in ('ReadSeq','Dropped'):
                        if observed['CaptureBuffer.'+ring+suffix]!=0:
                            raise EvidenceError('Startup audit prefix already lost before boot ready')
                if time.monotonic()>=until:raise EvidenceError('New boot not observed within parent deadline')
                time.sleep(.05)
            if observed['Active.Version']!=self.parent['policy']['expected_configuration']['version']:
                raise EvidenceError('Application configuration differs from parent review')
            self.result.update(observed_boot_id=boot,boot_observation_delay_seconds=time.monotonic()-begun)
            self.client.plan['policy']['expected_boot_id']=boot;self.client.config=observed['Active.Version']
            exporter=Exporter(self.client,self.journal);exporter.boot=boot;exporter.expected_config=observed['Active.Version']
            self.exporter=exporter
            exporter.fact_mode=self.static['policy'].get('fact_mode','legacy_v1')
            if self.static['policy'].get('closure_mode')=='source_cohort':
                from .audit_cohort import SourceCohort
                exporter.cohort=SourceCohort()
            head=exporter.head();exporter.check(head)
            self.journal.append([{'kind':'start','bootId':boot,'head':head,'startup_prefix_from':1,
                'parent_review_sha256':self.parent['review_sha256'],'observed_utc':datetime.now(timezone.utc).isoformat(),**exporter.fact_metadata()}])
            end=min(self.deadline,time.monotonic()+self.static['policy']['duration_seconds']);polls=0
            while time.monotonic()<end:
                exporter.poll();polls+=1;self.check();time.sleep(self.static['policy']['poll_interval_ms']/1000)
            if exporter.cohort:
                from .audit_cohort import close_source_window
                self.result.update(close_source_window(exporter,self.static['policy'],self.deadline,self.check))
            else:
                tail=exporter.head();exporter.check(tail);exporter.tail=(tail['CaptureBuffer.AuditWriteSeq'],tail['CaptureBuffer.AssociationWriteSeq'])
                self.journal.append([{'kind':'tailBoundary','bootId':boot,'head':tail}])
                end=min(self.deadline,time.monotonic()+self.static['policy']['tail_seconds'])
                while (exporter.capture,exporter.association)!=exporter.tail:
                    if time.monotonic()>=end:raise EvidenceError('Audit tail deadline')
                    exporter.poll();polls+=1;self.check();time.sleep(.02)
            exporter.check(exporter.head())
            if not exporter.diagnostic_revision:raise EvidenceError('No stable diagnostic snapshot')
            self.check()
            if not exporter.cohort:self.journal.append([{'kind':'end','bootId':boot,'capture':exporter.capture,'association':exporter.association,'complete_through_tail':True,**exporter.fact_metadata()}])
            self.result.update(status='audit_export_completed',complete=True,**exporter.fact_metadata(),first_sample_seq=1 if exporter.capture else None,
                capture=exporter.capture,association=exporter.association,tail=list(exporter.tail) if exporter.tail else None,polls=polls,
                max_capture_backlog=exporter.max_capture_backlog,max_association_backlog=exporter.max_association_backlog,
                **exporter.business_completeness)
        except Exception as exc:
            if hasattr(self,'exporter'):self.result.update(self.exporter.fact_metadata())
            if hasattr(self,'exporter') and self.exporter.cohort:
                self.exporter.cohort.reason=str(exc)[:512]
                self.result.update(self.exporter.cohort.report(self.journal.durable['Audit'],self.journal.durable['Association']))
            self.result.update(status='audit_failed',error_class=type(exc).__name__,error=str(exc)[:512],
                cancelled=getattr(exc,'code',None)=='recovery_cancelled' or 'cancelled' in str(exc).lower())
        return self.finish()
    def abort(self):
        self.result.update(status='audit_aborted_before_completion',complete=False)
        return self.finish()
    def finish(self):
        if self.finished:return self.result
        self.finished=True
        self.result['outcome_unknown']=bool(self.client and self.client.ack_unknown)
        if self.client:
            self.result.update(ack_write_attempts=self.client.ack_attempts,cleanup_error_class=self.client.close())
            if self.result['cleanup_error_class']:self.result.update(complete=False,status='audit_failed')
        if self.journal:
            self.result.update(durable_cursors=dict(self.journal.durable),durable_bytes=self.journal.size,
                journal_sha256=self.journal.hash.hexdigest())
            self.journal.close();self.result['actual_file_sha256']=sha((self.folder/'events.jsonl').read_bytes())
        _new_file(self.folder/'result.json',self.result)
        return self.result


def observe_ack_resolution(store,project_id,parent):
    """Read-only resolution of terminal ACK uncertainty; never restores audit completeness."""
    from .audit_export import load as load_audit
    context=parent['audit_reconciliation_context']
    _,_,symbols=load_audit(store,project_id,context['audit_plan_id'],context['audit_plan_sha256'])
    return _observe_ack_window(parent,symbols)


def _observe_ack_window(parent,symbols):
    """Current guard only: never invent a historical boot or certify old evidence."""
    from .runtime_monitor import RuntimeReadClient,_checked_rows
    from .controller_transport import ControllerEndpoint
    from .plc_state import stable_state
    context=parent['audit_reconciliation_context']
    zero=context.get('mode') in ('zero_ack_before_boot','zero_ack_partial')
    guard=['BootId','Active.Version',*_ACK]
    rings=('Audit','Association')
    drops=['CaptureBuffer.'+r+'Dropped' for r in rings]
    reads=['CaptureBuffer.'+r+'ReadSeq' for r in rings]
    names=guard+drops+reads;target=parent['target']
    client=RuntimeReadClient(ControllerEndpoint(target['address'],target['port'],target['expected_certificate_sha256']),[symbols[n]['path'] for n in names])
    def read(fields):
        desc=[symbols[n] for n in fields]
        rows=_checked_rows(desc,client.read_variables([d['path'] for d in desc]),datetime.now(timezone.utc).isoformat())
        if any(r['status']!='read' for r in rows):raise EvidenceError('Audit reconciliation readback unavailable')
        return dict(zip(fields,(r['value'] for r in rows)))
    windows=[]
    try:
        client.connect()
        if not stable_state(client.get_state(),3):raise EvidenceError('Controller not Running')
        first=read(guard)
        if (type(first['BootId']) is not str or not first['BootId']
                or first['Active.Version']!=parent['policy']['expected_configuration']['version']):
            raise EvidenceError('Current boot/config unavailable')
        if context.get('boot') and first['BootId']!=context['boot']:
            raise EvidenceError('Historical audit boot changed')
        for ring in rings:
            prefix='CaptureBuffer.'+ring
            seq=first[prefix+'AckSeq'];boot=first[prefix+'AckBootId']
            limit=0 if zero else context['durable_cursors'][ring]
            if type(seq) is not int or not 0<=seq<=limit or boot not in (('',) if zero else ('',context['boot'])):
                raise EvidenceError('External or unpersisted audit acknowledgement observed')
        for _ in range(2):
            before=read(drops);middle=read(reads);after=read(drops)
            for ring in rings:
                d='CaptureBuffer.'+ring+'Dropped';r='CaptureBuffer.'+ring+'ReadSeq'
                vals=(before[d],middle[r],after[d])
                if any(type(v) is not int or not 0<=v<2**64 for v in vals) or vals[0]>vals[2]:
                    raise EvidenceError('Invalid overflow counters')
                limit=0 if zero else context['durable_cursors'][ring]
                if not vals[0]<=vals[1]<=vals[2]+limit:
                    raise EvidenceError('Read cursor not explained by ring overflow')
            windows.append({'dropped_before':before,'read_seq':middle,'dropped_after':after})
            if read(guard)!=first:raise EvidenceError('Current boot/config/ACK guard changed')
        if not stable_state(client.get_state(),3):raise EvidenceError('Controller left Running')
    finally:
        cleanup=client.close()
    if cleanup:raise EvidenceError('Audit readback session did not close cleanly')
    return {'values':first,'overflow_windows':windows,'stable_double_read':True,
        'mode':context.get('mode','durable_ack_overflow_window'),
        'historical_boot_observed':bool(context.get('boot')),'audit_complete':False,
        'unknown_ack_resolved_by_current_readback':not zero,
        'controller_changed':False,'device_control_sent':False,'automatic_restore':False}
