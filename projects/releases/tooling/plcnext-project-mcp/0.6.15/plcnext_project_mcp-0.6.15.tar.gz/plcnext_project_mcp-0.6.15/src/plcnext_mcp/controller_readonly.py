"""Independent, explicitly pinned TLS/RSC controller state reader.

The only admitted application requests are Connect, discovery of the fixed PLC
manager service and GetPlcState. No caller-supplied service/method/body, session,
file access, runtime control or write operation is accepted.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import hmac
import ipaddress
import json
from pathlib import Path
import re
import socket
import ssl
import struct
import time
import uuid

from .project import ProjectError
from .rsc_codec import CommandHeader, CommandType, DATA_TAGGING, decode_header, encode_header
from .rsc_plc_codec import PLC_PROVIDER, PLC_SERVICE
from .rsc_rpc_codec import encode_connect_request, encode_get_service


def readonly_discovery_request() -> bytes:
    untagged = encode_get_service(PLC_PROVIDER, PLC_SERVICE)
    header, _ = decode_header(untagged[:16], require_checksum=True)
    return encode_header(CommandHeader(flags=DATA_TAGGING,
        command_type=CommandType.GET_SERVICE_HANDLES_REQUEST,
        data_length=header.data_length)) + untagged[16:]


def readonly_state_request(service: int, provider: int) -> bytes:
    if type(service) is not int or type(provider) is not int or not (
            1 <= service <= 32767 and 1 <= provider <= 32767):
        raise ProjectError('Invalid dynamically discovered service/provider handle.')
    return encode_header(CommandHeader(flags=DATA_TAGGING,
        command_type=CommandType.INVOKE_REQUEST, service_handle=service,
        method_handle=5, service_provider_handle=provider)) + b'\xff'


def validate_readonly_request(packet: bytes, handles: tuple[int, int] | None = None) -> None:
    """A final send boundary: exact equality, no generic RPC escape hatch."""
    if type(packet) is not bytes:
        raise ProjectError('Read-only controller request must be bytes.')
    allowed = packet in (encode_connect_request(), readonly_discovery_request())
    if handles is not None:
        allowed |= packet == readonly_state_request(*handles)
    if not allowed:
        raise ProjectError('Only Connect, fixed PLC service lookup and GetPlcState are admitted.')


class _Deadline:
    def __init__(self, seconds):
        self.end = time.monotonic() + seconds

    def remaining(self):
        remaining = self.end - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Controller read deadline expired.')
        return remaining


def _receive_exact(channel, count: int, deadline: _Deadline) -> bytes:
    result = bytearray()
    while len(result) < count:
        channel.settimeout(deadline.remaining())
        block = channel.recv(count - len(result))
        if not block:
            raise ConnectionError('Controller closed the connection before the expected response completed.')
        result.extend(block)
    return bytes(result)


def _receive_header(channel, deadline):
    header, token = decode_header(_receive_exact(channel, 16, deadline), require_checksum=True)
    if (token is not None or header.version != 4 or header.flags != DATA_TAGGING
            or header.additional_header_size or header.data_length):
        raise ProjectError('Unsupported controller response: expected RSC v4 tagged/no-datagram, no token.')
    return header


def _send(channel, packet, deadline, *, handles=None):
    validate_readonly_request(packet, handles)
    channel.settimeout(deadline.remaining())
    channel.sendall(packet)


def _probe(address, port, pin, timeout_seconds):
    deadline = _Deadline(timeout_seconds)
    report = {
        'status': 'not_connected', 'address': address, 'port': port,
        'observed_utc': datetime.now(timezone.utc).isoformat(),
        'backend': 'independent_tls_rsc', 'aci_used': False, 'engineer_started': False,
        'computer_use_used': False, 'commands_sent': [], 'credentials_sent': False,
        'file_methods_sent': False, 'configuration_commands_sent': False,
        'program_started_or_stopped': False, 'downloaded': False,
        'certificate_policy': 'explicit_sha256_pin', 'pki_chain_and_hostname_verified': False,
        'certificate_pin_verified': False, 'state_read': False,
    }
    stage = 'tcp_connect'
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
    # This is an explicit certificate-pin policy, not implicit trust-on-first-use.
    # No RSC application request is sent before the supplied pin matches.
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((address, port), timeout=deadline.remaining()) as tcp:
            stage = 'tls_handshake'
            tcp.settimeout(deadline.remaining())
            with context.wrap_socket(tcp, server_hostname=address) as channel:
                certificate = channel.getpeercert(binary_form=True)
                if not certificate:
                    raise ProjectError('Controller provided no certificate.')
                observed_pin = hashlib.sha256(certificate).hexdigest()
                report['peer_certificate_sha256'] = observed_pin
                stage = 'certificate_pin'
                if not hmac.compare_digest(observed_pin, pin):
                    raise ProjectError('Controller certificate does not match the explicit pin; no RSC request sent.')
                report.update(certificate_pin_verified=True, tls_version=channel.version(),
                              cipher=channel.cipher()[0])
                stage = 'rsc_connect'
                _send(channel, encode_connect_request(), deadline)
                report['commands_sent'].append('Connect')
                header = _receive_header(channel, deadline)
                if header.command_type != CommandType.CONNECT_CONFIRM or any((
                        header.method_handle, header.service_handle, header.service_provider_handle)):
                    raise ProjectError('Unexpected RSC Connect confirmation.')
                report.update(rsc_connected=True, rsc_version=4, data_tagging=True, datagramming=False)
                stage = 'service_discovery'
                _send(channel, readonly_discovery_request(), deadline)
                report['commands_sent'].append('GetServiceHandles(IPlcManagerService)')
                header = _receive_header(channel, deadline)
                if (header.command_type != CommandType.GET_SERVICE_HANDLES_CONFIRMATION
                        or header.method_handle or min(header.service_handle, header.service_provider_handle) <= 0):
                    raise ProjectError('PLC manager service lookup failed or returned an unsupported response.')
                handles = header.service_handle, header.service_provider_handle
                report.update(service_handle=handles[0], provider_handle=handles[1])
                stage = 'state_read'
                _send(channel, readonly_state_request(*handles), deadline, handles=handles)
                report['commands_sent'].append('GetPlcState(method=5)')
                header = _receive_header(channel, deadline)
                if (header.service_handle, header.service_provider_handle, header.method_handle) != (
                        handles[0], handles[1], 5):
                    raise ProjectError('GetPlcState response does not match the negotiated handles.')
                if header.command_type == CommandType.ERROR:
                    # Error-body variants are not yet part of the read-only schema.
                    # Stop and close rather than guessing their framing or credentials.
                    report.update(status='state_query_rejected', stage=stage)
                    return report
                if header.command_type != CommandType.INVOKE_CONFIRMATION:
                    raise ProjectError('Unexpected GetPlcState response command.')
                body = _receive_exact(channel, 6, deadline)
                if body[0] != 9 or body[-1] != 255:
                    raise ProjectError('GetPlcState value does not match the verified tagged UInt32 schema.')
                state = struct.unpack('<I', body[1:5])[0]
                report.update(status='state_read', state_read=True, plc_state_raw=state,
                    plc_base_state={0: 'None', 1: 'Ready', 2: 'Stop', 3: 'Running', 4: 'Halt'}.get(state & 63, 'Unknown'),
                    plc_state_flags=state & ~63, stage='completed')
    except (OSError, ValueError) as exc:
        report.update(status='read_failed', stage=stage, error=str(exc))
    return report


def read_controller_state(report_root: Path, address: str, expected_certificate_sha256: str,
                          port: int = 41100, timeout_seconds: int = 5) -> dict:
    """Make one bounded, pin-checked connection; persist the exact action report.

    address must be a literal IP, not a URL/hostname. The caller must provide an
    independently selected certificate fingerprint; this API never learns trust
    automatically and has no credential or arbitrary method parameter.
    """
    if type(address) is not str:
        raise ProjectError('Controller address must be a literal IPv4 or IPv6 address.')
    try:
        normalized_address = str(ipaddress.ip_address(address))
    except (ValueError, TypeError) as exc:
        raise ProjectError('Controller address must be a literal IPv4 or IPv6 address.') from exc
    if type(expected_certificate_sha256) is not str or not re.fullmatch(r'[0-9a-fA-F]{64}', expected_certificate_sha256):
        raise ProjectError('An explicit 64-hex-digit controller certificate SHA-256 pin is required.')
    if type(port) is not int or not 1 <= port <= 65535:
        raise ProjectError('Controller port must be 1..65535.')
    if type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 30:
        raise ProjectError('Controller read deadline must be 1..30 seconds.')
    # Establish report storage before any network action; do not lose the result
    # merely because an output directory could not be created.
    folder = Path(report_root) / 'controller-reads' / uuid.uuid4().hex
    folder.mkdir(parents=True, exist_ok=False)
    result = _probe(normalized_address, port, expected_certificate_sha256.lower(), timeout_seconds)
    report = folder / 'result.json'
    result['report_path'] = str(report)
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return result
