"""M11: exact, audited reconciliation of completed recovery quarantine.

Known completed asynchronous recovery uses its terminal operation and host identity.
Synchronous recovery uses consumed authorization and closed quarantined terminal
executor protocol; new executors also hold a full-lifetime OS lock. Unknown or
incomplete executions fail closed.
No controller mutations; runtime observations use the existing bounded read plan.
"""
from datetime import datetime, timezone
import json
import uuid
from pathlib import Path
from .project import ProjectError, sha
from .deployment_plan import _file
from .controller_download_plan import _strict_json
from .controller_recovery import load_recovery_plan, verify_original_runtime
from .controller_transfer import _endpoint_lease_root
from .endpoint_guard import endpoint_guard
from .operation_jobs import _load, _process_birth, _bytes
from .operator_approval import OperatorApprovalContract, validate_operator_receipt, _issuer_lock, _paths, _new_file as _save_new
from .runtime_monitor import read_runtime_plan

SCHEMA='plcnext-lease-reconciliation-plan/v1'

def _read(path,limit=16*1024*1024):
    if not path.is_file() or path.stat().st_size>limit:
        raise ProjectError('Missing or oversized reconciliation evidence: '+path.name)
    raw=path.read_bytes()
    if len(raw)>limit:raise ProjectError('Oversized reconciliation evidence.')
    return raw

def _snapshot(store,project_id,operation_id,digest,pin,lease_override=None,current_state=None):
    audit_resolution=operation_id.startswith('audit:')
    synchronous=operation_id.startswith('sync:') or audit_resolution
    if synchronous:
        import re
        execution_id=operation_id.split(':',1)[1]
        if re.fullmatch('[0-9a-f]{32}',execution_id) is None:raise ProjectError('Invalid synchronous execution ID.')
        job=_file(store._folder(project_id),'controller-recoveries/'+execution_id)
        result=_strict_json(_read(job/'result.json'))
        if result.get('execution_id')!=execution_id or result.get('project_id')!=project_id or result.get('review_sha256')!=digest:
            raise ProjectError('Synchronous execution identity mismatch.')
        # Terminal protocol: this executor sends no device RPC after publishing
        # completed result + ExecutionOutcome. New executions also hold an OS lock.
        guard=_file(store._folder(project_id),'controller-recovery-plans/'+result['plan_id']+'/execution')
        with endpoint_guard(guard):pass
        if result.get('endpoint_lease_retained') is not True or (not audit_resolution and result.get('endpoint_quarantine_reason') not in ('business_verification_incomplete','known_execution_failure')):
            raise ProjectError('Synchronous owner is not a completed business-only quarantine.')
    else:
        folder,op=_load(store,project_id,operation_id,digest)
        if op.get('kind')!='recovery' or op.get('phase')!='finished' or op.get('status') not in ('completed','needs_attention','failed'):
            raise ProjectError('Owner is not a terminal recovery operation.')
        if _process_birth(op.get('host_pid'))==op.get('host_process_birth') or not op.get('host_process_birth'):
            raise ProjectError('Owner host is active or its identity is unavailable.')
        envelope_raw=_read(folder/'result.json')
        if sha(envelope_raw)!=op.get('result_sha256'):raise ProjectError('Operation result hash changed.')
        envelope=_strict_json(envelope_raw);result=envelope['result']
        if (envelope.get('operation_id')!=operation_id or envelope.get('project_id')!=project_id
                or envelope.get('review_sha256')!=digest or result.get('review_sha256')!=digest):
            raise ProjectError('Operation/result identity mismatch.')
    observation_failure=(not audit_resolution and result.get('status')=='recovery_failed'
        and result.get('stage')=='verify_runtime' and result.get('failure_code')=='recovery_observation_failed'
        and result.get('outcome_unknown') is False and result.get('receipt_persisted') is True
        and result.get('original_package_loaded') is True and result.get('endpoint_lease_retained') is True
        and result.get('endpoint_quarantine_reason')=='known_execution_failure'
        and not result.get('cleanup_error_class'))
    if observation_failure:
        guard=_file(store._folder(project_id),'controller-recovery-plans/'+result['plan_id']+'/execution')
        with endpoint_guard(guard):pass
    if not audit_resolution and not observation_failure and (result.get('status')!='original_loaded_verification_incomplete' or result.get('stage')!='completed'
            or result.get('outcome_unknown') is not False or result.get('receipt_persisted') is not True
            or not result.get('original_package_loaded') or not result.get('original_configuration_verified')):
        raise ProjectError('Only known completed recovery with pending business verification is reconcilable.')
    job=_file(store._folder(project_id),'controller-recoveries/'+result['execution_id'])
    if not synchronous and Path(op['driver_report_path'])!=job/'result.json':raise ProjectError('Owner execution directory mismatch.')
    result_raw=_read(job/'result.json')
    if _strict_json(result_raw)!=result:raise ProjectError('Driver result differs from terminal operation result.')
    journal_raw=_read(job/'journal.jsonl')
    events=[_strict_json(line) for line in journal_raw.splitlines()]
    if (not events or events[-1].get('operation')!='ExecutionOutcome'
            or events[-1].get('stage')!=('audit_after_start' if audit_resolution else 'verify_runtime' if observation_failure else 'completed')
            or events[-1].get('outcome_unknown') is not (result.get('outcome_unknown') if audit_resolution else False)
            or events[-1].get('receipt_persisted') is not True):
        raise ProjectError('Journal is missing its known terminal outcome.')
    plan=load_recovery_plan(store,project_id,result['plan_id'],digest)
    audit_context=None
    if audit_resolution:
        audit=result.get('audit_result',{})
        if (result.get('status')!='recovery_failed' or result.get('stage')!='audit_after_start'
                or result.get('failure_code')!='parent_audit_incomplete' or result.get('receipt_persisted') is not True
                or audit.get('parent_review_sha256')!=digest or audit.get('parent_plan_id')!=plan['plan_id']
                or audit.get('complete') is not False or result.get('outcome_unknown')!=audit.get('outcome_unknown')
                or audit.get('cleanup_error_class') or 'audit' not in plan['children']):
            raise ProjectError('Not an isolated terminal parent-audit failure.')
        ref=plan['children']['audit']
        if (ref['plan_id']!=audit.get('audit_plan_id') or ref['plan_sha256']!=audit.get('audit_plan_sha256')
                ):raise ProjectError('Audit identity missing.')
        afolder=_file(store._folder(project_id),'audit-exports/'+ref['plan_id'])
        ar=_read(afolder/'result.json')
        if _strict_json(ar)!=audit:raise ProjectError('Parent and child audit receipts differ.')
        data=_read(afolder/'events.jsonl',268435456)
        if sha(data)!=audit.get('actual_file_sha256') or sha(data[:audit['durable_bytes']])!=audit.get('journal_sha256'):
            raise ProjectError('Durable audit bytes changed.')
        cursors={'Audit':0,'Association':0}
        for line in data[:audit['durable_bytes']].splitlines():
            row=_strict_json(line);kind=row.get('kind')
            if kind not in ('capture','association'):continue
            ring='Audit' if kind=='capture' else 'Association'
            seq=row['event']['Event.SampleSeq'] if ring=='Audit' else row['association']['Ordinal']
            if seq!=cursors[ring]+1:raise ProjectError('Audit evidence has a sequence hole.')
            cursors[ring]=seq
        if cursors!=audit.get('durable_cursors'):raise ProjectError('Audit durable cursor mismatch.')
        audit_context={'audit_plan_id':ref['plan_id'],'audit_plan_sha256':ref['plan_sha256'],
            'boot':audit.get('observed_boot_id'),'durable_cursors':cursors,'audit_result_sha256':sha(ar),
            'events_sha256':sha(data),'transport_sha256':sha(_read(afolder/'transport.jsonl'))}
        if not audit.get('observed_boot_id') or audit.get('ack_write_attempts')==0:
            # A missing historical boot is allowed only with positive zero-write proof.
            if (type(audit.get('ack_write_attempts')) is not int or audit['ack_write_attempts']!=0
                    or audit.get('outcome_unknown') is not False or result.get('outcome_unknown') is not False
                    or audit['durable_bytes']!=len(data)
                    or (not audit.get('observed_boot_id') and any(cursors.values()))):
                raise ProjectError('Zero ACK requires exact known zero writes and fully persisted bytes.')
            transport=[_strict_json(line) for line in _read(afolder/'transport.jsonl').splitlines()]
            if not transport or any(e.get('operation')=='AuditAckWrite' or e.get('mutating') for e in transport):
                raise ProjectError('Zero ACK conflicts with transport evidence.')
            ack_path=afolder/'ack-journal.jsonl'
            ack_raw=_read(ack_path) if ack_path.exists() else b''
            if ack_raw:raise ProjectError('Zero ACK conflicts with durable ACK intent.')
            audit_context.update(mode='zero_ack_partial' if audit.get('observed_boot_id') else 'zero_ack_before_boot',ack_journal_sha256=sha(ack_raw),
                ack_journal_present=ack_path.exists(),historical_boot_observed=bool(audit.get('observed_boot_id')))
        plan=dict(plan,audit_reconciliation_context=audit_context)
    target=plan['target']
    if target['expected_certificate_sha256']!=pin or result['target']!=target:
        raise ProjectError('Exact target/certificate binding mismatch.')
    binding=events[0]
    if (binding.get('operation')!='RecoveryBinding' or any(binding.get(k)!=v for k,v in {
            'execution_id':result['execution_id'],'review_sha256':digest,'target':target,
            'inventory_sha256':plan['package']['inventory_sha256'],
            'project_sha256':plan['source']['project_sha256'],'plan_id':plan['plan_id']}.items())):
        raise ProjectError('Journal owner binding mismatch.')
    steps=result.get('steps',[])
    if (len(steps)!=3 or not steps[0].get('terminal_state_verified')
            or not steps[1].get('load_state_verified') or steps[1].get('unacknowledged_mutation_requests')!=0
            or not steps[2].get('terminal_state_verified') or not steps[2].get('loaded_package_identity_verified')
            or any(s.get('outcome_unknown') or s.get('cleanup_error_class') for s in steps)):
        raise ProjectError('Control/transfer outcomes are incomplete or uncertain.')
    pending_request=None
    completed_mutations=set()
    for event in events:
        if event.get('operation')!='Invoke':continue
        key=tuple(event.get(k) for k in ('service','method','recovery_stage','execution_id'))
        if pending_request is not None and key!=pending_request:
            raise ProjectError('Journal mutation has no matching response before the next request.')
        if event.get('mutating') and event.get('send_attempted'):
            if event.get('response_received') is True:
                completed_mutations.add((event.get('service'),event.get('method')))
                pending_request=None
            elif pending_request is None:pending_request=key
            else:raise ProjectError('Repeated unresolved mutation in journal.')
    if pending_request is not None:raise ProjectError('Journal contains unresolved mutation requests.')
    from .controller_transport import PLC
    if not {(PLC,4),(PLC,1),(PLC,2)}<=completed_mutations:
        raise ProjectError('Journal lacks acknowledged Reset, Load or Start.')
    key=sha((target['address']+':'+str(target['port'])).encode())
    lease=_endpoint_lease_root()/(key+'.json')
    raw=_read(lease_override or lease,65536);owner=_strict_json(raw)
    if (owner.get('target')!=target or Path(owner.get('job_directory',''))!=job
            or owner.get('review_sha256')!=steps[0]['review_sha256']):
        raise ProjectError('Lease owner does not match the exact completed operation.')
    lifecycle={}
    if synchronous or observation_failure:
        from .controller_recovery import approval_contract as recovery_contract
        contract=recovery_contract(store,project_id,result['plan_id'],digest)
        paths=_paths(store.root,contract)
        receipt_raw=_read(paths['receipt'],65536);receipt=_strict_json(receipt_raw)
        claim_raw=_read(paths['claimed'],65536);claim=_strict_json(claim_raw)
        validate_operator_receipt(receipt,contract,now=datetime.fromisoformat(receipt['confirmed_utc']))
        if claim.get('execution_id')!=result['execution_id'] or claim.get('review_sha256')!=digest or claim.get('approval_sha256')!=sha(receipt_raw):
            raise ProjectError('Synchronous execution lacks its exact consumed authorization.')
        if events[-1].get('status')!=result['status']:raise ProjectError('Terminal outcome differs from result.')
        lifecycle={'owner_kind':'synchronous_execution','execution_id':result['execution_id'],
            'completion_proof':'closed_completed_quarantined_executor_protocol_v1',
            'approval_sha256':sha(receipt_raw),'claim_sha256':sha(claim_raw)}
    else:
        lifecycle={'operation_sha256':sha(_read(folder/'operation.json')),'operation_result_sha256':sha(envelope_raw),
            'host_pid':op['host_pid'],'host_process_birth':op['host_process_birth']}
    if observation_failure:
        from .plc_state import stable_state
        stop=steps[0]
        stop_sent=stop.get('action_sent') is True and stop.get('ack_received') is True
        skip_stop=(stop.get('status')=='control_already_complete' and stop.get('action')=='stop'
            and stop.get('action_sent') is False and stop.get('ack_received') is False
            and stop.get('terminal_state_verified') is True
            and stable_state(plan['policy'].get('expected_initial_state_raw',0),2)
            and stable_state(stop.get('initial_state_raw',0),2) and stable_state(stop.get('final_state_raw',0),2)
            and not any(e.get('service')==PLC and e.get('method')==3 for e in events))
        if (not (stop_sent or skip_stop) or steps[2].get('action_sent') is not True or steps[2].get('ack_received') is not True
                or steps[1].get('load_ack_received') is not True or steps[1].get('files_verified')!=len(plan['files'])):
            raise ProjectError('Observation failure lacks complete confirmed control/transfer receipts')
        if 'audit' in plan['children']:raise ProjectError('Observation branch cannot dispose an audit child')
        if synchronous:
            _validate_sync_observation(store,project_id,plan,result,events,job,skip_stop)
            if 'stopped_handoff' in plan:
                lifecycle['handoff_files_sha256']={n:sha(_read(job/n)) for n in ('previous-endpoint-lease.json','handoff.json')}
            lifecycle.update(owner_kind='synchronous_observation_failure',old_execution_id=result['execution_id'],
                old_failure_preserved=True,stop_legally_skipped=skip_stop)
        else:
            lifecycle.update(operation_sha256=sha(_read(folder/'operation.json')),operation_result_sha256=sha(envelope_raw),
                host_pid=op['host_pid'],host_process_birth=op['host_process_birth'],old_failure_preserved=True,
                owner_kind='terminal_observation_failure',old_operation_id=operation_id,old_execution_id=result['execution_id'],
                stop_legally_skipped=skip_stop)
    if audit_context:lifecycle['audit_resolution']=audit_context
    evidence={**lifecycle,
        'driver_result_sha256':sha(result_raw),'journal_sha256':sha(journal_raw),'lease_sha256':sha(raw),
        'job_directory':str(job),
        'old_review_sha256':digest,'old_control_review_sha256':owner['review_sha256']}
    if current_state is not None:
        if not observation_failure:raise ProjectError('Explicit current handoff requires the supported observation failure')
        from .observation_reconciliation import bind_current
        context=bind_current(store,current_state,target)
        evidence['current_state']=context
        plan=dict(plan,reconciliation_current_state=context)
    return plan,lease,evidence

def _observe(store,project_id,old):
    if old.get('reconciliation_current_state'):
        from .observation_reconciliation import observe_current
        return observe_current(store,old['reconciliation_current_state'])
    child=old['children']['monitor']
    observed=read_runtime_plan(store,project_id,child['plan_id'],child['plan_sha256'])
    check=verify_original_runtime(observed,old['policy']['expected_configuration'])
    if (observed.get('status')!='monitor_read_completed' or not check['configuration_matches']
            or not check['program_running_observed'] or not check['all_points_good_observed']
            or observed.get('cleanup_error_class')):
        raise ProjectError('Fresh read did not verify Running, exact configuration and all expected GOOD points.')
    audit_guard=None
    if old.get('audit_reconciliation_context'):
        from .recovery_audit import observe_ack_resolution
        audit_guard=observe_ack_resolution(store,project_id,old)
    return {k:observed[k] for k in ('observation_id','observation_sha256','report_path','created_utc')} | {'verification':check,'audit_ack_readback':audit_guard}

def prepare(store,project_id,operation_id,expected_review_sha256,expected_certificate_sha256,current_state=None):
    old,lease,evidence=_snapshot(store,project_id,operation_id,expected_review_sha256,expected_certificate_sha256,current_state=current_state)
    if evidence.get('old_failure_preserved') and current_state is None:
        raise ProjectError('Use '+('project_prepare_sync_observation_reconciliation' if operation_id.startswith('sync:') else 'project_prepare_observation_reconciliation')+' with explicit current-state binding')
    with endpoint_guard(lease):
        if lease.with_suffix('.reconciliation.json').exists():raise ProjectError('Interrupted reconciliation requires resuming its original plan.')
        observation=_observe(store,project_id,old)
        _,_,again=_snapshot(store,project_id,operation_id,expected_review_sha256,expected_certificate_sha256,current_state=current_state)
        if again!=evidence:raise ProjectError('Evidence changed during observation.')
        plan_id=uuid.uuid4().hex
        plan={'schema':SCHEMA,'project_id':project_id,'plan_id':plan_id,'operation_id':None if operation_id.startswith(('sync:','audit:')) else operation_id,
            'owner_kind':'parent_audit' if operation_id.startswith('audit:') else 'recovery',
            'execution_id':operation_id.split(':',1)[1] if operation_id.startswith(('sync:','audit:')) else None,
            'created_utc':datetime.now(timezone.utc).isoformat(),'target':old['target'],
            'project_sha256':old['source']['project_sha256'],'inventory_sha256':old['package']['inventory_sha256'],
            'evidence':evidence,'observation':observation,'current_state':current_state,'policy':{'mode':'terminal_parent_audit_ack_readback' if operation_id.startswith('audit:') else 'terminal_observation_failure_handoff' if evidence.get('old_failure_preserved') else 'completed_recovery_business_verification',
            'archive_only':True,'controller_mutations':False,'automatic_retry':False},
            'approved_actions':['archive_exact_completed_recovery_lease']}
        digest=sha(_bytes(plan));plan['plan_sha256']=digest
        directory=_file(store._folder(project_id),'lease-reconciliations/'+plan_id);directory.mkdir(parents=True)
        _save_new(directory/'plan.json',plan)
        return plan

def _plan(store,project_id,plan_id,digest):
    import re
    if re.fullmatch('[0-9a-f]{32}',plan_id or '') is None:raise ProjectError('Invalid reconciliation plan ID.')
    directory=_file(store._folder(project_id),'lease-reconciliations/'+plan_id)
    plan=_strict_json(_read(directory/'plan.json'));payload=dict(plan);payload.pop('plan_sha256',None)
    if (plan.get('schema')!=SCHEMA or plan.get('project_id')!=project_id or plan.get('plan_id')!=plan_id
            or plan.get('plan_sha256')!=digest or sha(_bytes(payload))!=digest):
        raise ProjectError('Reconciliation plan hash/identity mismatch.')
    return directory,plan

def inspect(store,project_id,plan_id,digest):
    directory,plan=_plan(store,project_id,plan_id,digest)
    done=directory/'result.json'
    if done.exists():return {'status':'reconciled','plan':plan,'result':_strict_json(_read(done))}
    _,_,evidence=_snapshot(store,project_id,(plan.get('operation_id') or ('audit:' if plan.get('owner_kind')=='parent_audit' else 'sync:')+plan['execution_id']),plan['evidence']['old_review_sha256'],plan['target']['expected_certificate_sha256'],current_state=plan.get('current_state'))
    if evidence!=plan['evidence']:raise ProjectError('Bound evidence changed; prepare a new reconciliation.')
    return {'status':'prepared','plan':plan,'controller_connected':False}

def approval_contract(store,project_id,plan_id,digest):
    checked=inspect(store,project_id,plan_id,digest)
    if checked['status']!='prepared':raise ProjectError('Reconciliation already completed.')
    plan=checked['plan']
    return OperatorApprovalContract(kind='lease_reconciliation',review_sha256=digest,
        receipt_schema='plcnext-lease-reconciliation-operator-approval/v1',
        approval_directory='controller-lease-reconciliation-approvals',
        binding_fields={k:plan[k] for k in ('target','project_sha256','inventory_sha256','policy','approved_actions','evidence')},
        display=plan).checked()

def execute(store,project_id,plan_id,digest):
    directory,plan=_plan(store,project_id,plan_id,digest)
    target=plan['target'];lease=_endpoint_lease_root()/(sha((target['address']+':'+str(target['port'])).encode())+'.json')
    pending=lease.with_suffix('.reconciliation.json')
    archive=lease.with_name(lease.stem+'.reconciled-'+plan_id+'.json')
    intent={'schema':'plcnext-lease-reconciliation-intent/v1','project_id':project_id,'plan_id':plan_id,
        'plan_sha256':digest,'lease_sha256':plan['evidence']['lease_sha256'],'archive_path':str(archive)}
    with endpoint_guard(lease):
        if (directory/'result.json').exists():
            # Completion replay is not another mutation and must not touch a new lease.
            result=_strict_json(_read(directory/'result.json'))
            if pending.exists():
                if _strict_json(_read(pending))!=intent:raise ProjectError('Different reconciliation pending.')
                if lease.exists() or sha(_read(archive))!=intent['lease_sha256']:raise ProjectError('Completion evidence changed.')
                pending.unlink()
            return dict(result,replayed=True)
        resuming=pending.exists()
        if resuming and _strict_json(_read(pending))!=intent:raise ProjectError('Different reconciliation pending.')
        old,_,evidence=_snapshot(store,project_id,(plan.get('operation_id') or ('audit:' if plan.get('owner_kind')=='parent_audit' else 'sync:')+plan['execution_id']),plan['evidence']['old_review_sha256'],
            target['expected_certificate_sha256'],lease_override=archive if resuming and not lease.exists() else None,current_state=plan.get('current_state'))
        if evidence!=plan['evidence']:raise ProjectError('Bound evidence changed before reconciliation.')
        if resuming and lease.exists() and archive.exists():raise ProjectError('Conflicting lease and archive.')
        if resuming and not lease.exists():
            # Only finalize an already committed atomic rename. No new PLC operation.
            observation=_strict_json(_read(directory/'execution-observation.json'))
        else:
            observation=_observe(store,project_id,old)
            if old.get('audit_reconciliation_context',{}).get('mode') in ('zero_ack_before_boot','zero_ack_partial'):
                before=plan['observation']['audit_ack_readback']['values']
                after=observation['audit_ack_readback']['values']
                if any(before[k]!=after[k] for k in ('BootId','Active.Version')):
                    raise ProjectError('Current boot/config changed since reconciliation prepare.')
            _,_,again=_snapshot(store,project_id,(plan.get('operation_id') or ('audit:' if plan.get('owner_kind')=='parent_audit' else 'sync:')+plan['execution_id']),plan['evidence']['old_review_sha256'],target['expected_certificate_sha256'],current_state=plan.get('current_state'))
            if again!=evidence:raise ProjectError('Evidence changed during final read.')
        if not resuming:
            contract=approval_contract(store,project_id,plan_id,digest);paths=_paths(store.root,contract)
            with _issuer_lock(paths):
                if paths['revoked'].exists() or paths['denied'].exists():raise ProjectError('Authorization withdrawn.')
                raw=_read(paths['receipt'],65536);validate_operator_receipt(_strict_json(raw),contract)
                if paths['claimed'].exists():raise ProjectError('Authorization already consumed.')
                _save_new(directory/'execution-observation.json',observation)
                # Intent precedes claim: a crash is resumable only with a matching claim.
                _save_new(pending,intent)
                _save_new(paths['claimed'],{'plan_sha256':digest,'approval_sha256':sha(raw)})
        else:
            claim=_file(store.root,'controller-lease-reconciliation-approvals/'+digest+'.claimed.json')
            if not claim.exists():
                if not lease.exists():raise ProjectError('Archived lease has no authorization claim.')
                contract=approval_contract(store,project_id,plan_id,digest);paths=_paths(store.root,contract)
                with _issuer_lock(paths):
                    if paths['revoked'].exists() or paths['denied'].exists():raise ProjectError('Authorization withdrawn.')
                    raw=_read(paths['receipt'],65536);validate_operator_receipt(_strict_json(raw),contract)
                    _save_new(claim,{'plan_sha256':digest,'approval_sha256':sha(raw)})
            if _strict_json(_read(claim)).get('plan_sha256')!=digest:
                raise ProjectError('Interrupted authorization claim does not match.')
        if lease.exists():
            if sha(_read(lease))!=intent['lease_sha256'] or archive.exists():raise ProjectError('Lease changed before atomic archive.')
            lease.rename(archive)
        result={'schema':'plcnext-lease-reconciliation-result/v1','status':'reconciled','plan_sha256':digest,
            'archive_path':str(archive),'archived_lease_sha256':sha(_read(archive)),'evidence':evidence,
            'observation':observation,'controller_changed':False,'controller_mutations':False,
            'old_failure_preserved':bool(evidence.get('old_failure_preserved')),'business_acceptance':False,'memory_loaded_image_attested':False,
            'old_claims_and_journal_preserved':True,'automatic_retry':False,'completed_utc':datetime.now(timezone.utc).isoformat()}
        _save_new(directory/'result.json',result)
        pending.unlink()
        return result


def _validate_sync_observation(store,pid,plan,result,events,job,skip_stop):
    """Synchronous execution proof, including control no-op and handoff history."""
    from .controller_transport import PLC
    from .plc_state import stable_state
    steps=result['steps'];transfer=steps[1]
    if (any(s.get('outcome_unknown') is not False for s in steps) or steps[0].get('action')!='stop'
        or steps[2].get('action')!='start' or steps[2].get('status')!='control_completed'
        or (not skip_stop and steps[0].get('status')!='control_completed')):raise ProjectError('Synchronous control status inconsistent')
    if (transfer.get('configuration_reset_confirmed') is not True or transfer.get('connection_closed') is not True
        or transfer.get('configuration_outcome_unknown') is not False
        or not stable_state(steps[2].get('final_state_raw',0),3)
        or _strict_json(_read(job/'load-result.json'))!=transfer):raise ProjectError('Synchronous load/Start receipt incomplete')
    for name,step in zip(('stop','download','start'),steps):
        if step.get('review_sha256')!=plan['children'][name]['review_sha256'] or step.get('plan_id')!=plan['plan_id']:
            raise ProjectError('Synchronous child binding mismatch')
    pending=None;completed=[]
    for event in events:
        if event.get('operation')!='Invoke':continue
        key=tuple(event.get(k) for k in ('service','method','recovery_stage','execution_id'))
        if key[-1]!=result['execution_id']:raise ProjectError('Synchronous journal execution mismatch')
        if event.get('response_received') is False:
            if pending is not None:raise ProjectError('Unclosed synchronous request')
            pending=key
        elif event.get('response_received') is True:
            if pending!=key or event.get('send_attempted') is not True or event.get('remote_error_code') is not None:
                raise ProjectError('Unmatched synchronous response')
            pending=None
            if event.get('mutating'):
                from .controller_transport import FILE
                if key[:2] not in {(PLC,1),(PLC,2),(PLC,3),(PLC,4),(FILE,8)}:raise ProjectError('Unknown synchronous mutation')
                completed.append(key[:2])
        else:raise ProjectError('Unknown synchronous request outcome')
    if pending is not None:raise ProjectError('Unclosed synchronous request')
    if any(completed.count((PLC,m))!=1 for m in (4,1,2)) or completed.count((PLC,3))!=(0 if skip_stop else 1):
        raise ProjectError('Synchronous control request counts differ')
    if 'stopped_handoff' in plan:
        h=plan['stopped_handoff'];old_raw=_read(job/'previous-endpoint-lease.json',65536)
        link=_strict_json(_read(job/'handoff.json'))
        if sha(old_raw)!=h['evidence']['lease_sha256'] or any(link.get(k)!=v for k,v in {
            'old_project_id':h['project_id'],'old_execution_id':h['execution_id'],
            'old_review_sha256':h['expected_review_sha256'],'old_lease_sha256':sha(old_raw),
            'new_project_id':pid,'new_plan_id':plan['plan_id'],'new_execution_id':result['execution_id'],
            'new_review_sha256':result['review_sha256']}.items()):raise ProjectError('Stopped handoff chain changed')
        # Existing handoff files remain untouched; bind their bytes through plan evidence below.
