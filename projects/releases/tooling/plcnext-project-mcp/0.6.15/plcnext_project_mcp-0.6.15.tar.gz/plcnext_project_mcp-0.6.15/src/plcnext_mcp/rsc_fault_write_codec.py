"""Measured WriteSingle DTO codec; caller must enforce a fixed fault capability."""
from __future__ import annotations

from . import rsc_tagged_codec as tagged
from .rsc_codec import CommandHeader,CommandType,DATA_TAGGING,encode_header
from .rsc_runtime_codec import RuntimeValueReader,encode_variant


def encode_fault_write(service_handle,provider_handle,path,wire_type,value):
    if type(path) is not str or not path.startswith('Arp.Plc.Eclr/') or len(path.encode())>511:
        raise ValueError('Bounded explicit fault path required.')
    if wire_type not in ('utf8','uint16','uint32','uint64'):
        raise ValueError('Only measured fault input scalar types are admitted.')
    header=tagged.encode_request(service_handle,3,[],[],provider_handle=provider_handle)[:-1]
    return header+b'\x12\x02\x00'+tagged.encode_value('utf8',path)+encode_variant({'wire_type':wire_type,'value':value})+b'\xff'


def receive_fault_write(read):
    reader=RuntimeValueReader(read,maximum_bytes=1024,maximum_string_bytes=512)
    if reader.take(3)!=b'\x12\x02\x00':raise ValueError('Expected measured WriteItem struct.')
    path=reader.variant()
    value=reader.variant()
    if path['wire_type']!='utf8' or value['wire_type'] not in ('utf8','uint16','uint32','uint64'):
        raise ValueError('Unexpected fixed fault WriteItem field type.')
    if reader.take(1)!=b'\xff':raise ValueError('Missing WriteSingle terminator.')
    return path['value'],value


def receive_write_error(read):
    reader=RuntimeValueReader(read,maximum_bytes=64)
    if reader.take(1)!=b'\x05':raise ValueError('Expected byte DataAccessError enum.')
    value=reader.number('B')
    if reader.take(1)!=b'\xff':raise ValueError('Missing WriteSingle response terminator.')
    return value
