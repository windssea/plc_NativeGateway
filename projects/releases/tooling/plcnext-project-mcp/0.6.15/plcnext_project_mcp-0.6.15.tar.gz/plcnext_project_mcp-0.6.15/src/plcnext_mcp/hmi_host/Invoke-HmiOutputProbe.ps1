param(
 [Parameter(Mandatory)][string]$WorkRoot,
 [Parameter(Mandatory)][string]$OutputDirectory,
 [Parameter(Mandatory)][string]$RuntimeTypesPath,
 [string]$InstallDirectory='D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0',
 [string]$DesktopDirectory='C:\Program Files\dotnet\shared\Microsoft.WindowsDesktop.App\8.0.21'
)
$ErrorActionPreference='Stop'
$jobRoot=[IO.Path]::GetFullPath($WorkRoot)
$outRoot=[IO.Path]::GetFullPath($OutputDirectory)
$runtimePath=[IO.Path]::GetFullPath($RuntimeTypesPath)
$runtimeHash=(Get-FileHash -LiteralPath $runtimePath -Algorithm SHA256).Hash.ToLowerInvariant()
$runtimeDocument=Get-Content -Raw -LiteralPath $runtimePath | ConvertFrom-Json
$runtimeTypes=@{}
foreach($type in $runtimeDocument.Types){
 if($type.RuntimeSize -le 0 -or $type.RuntimeAlignment -le 0){throw "Unfinalized runtime layout: $($type.Name)"}
 $runtimeTypes[$type.Name]=$type
}
$sourceHashes=@{}
Get-ChildItem -LiteralPath (Join-Path $jobRoot 'project') -File -Recurse | ForEach-Object {$sourceHashes[$_.FullName]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
if(Test-Path -LiteralPath $outRoot){throw 'Probe output must be a new directory.'}
[void](New-Item -ItemType Directory -Path $outRoot)
Add-Type -Path (Join-Path $PSScriptRoot 'HmiOutputProbe.cs') -ReferencedAssemblies @('System.Runtime.dll','System.Collections.dll','System.Linq.dll','System.Reflection.dll','System.Reflection.DispatchProxy.dll','System.Xml.XDocument.dll','System.Xml.ReaderWriter.dll','System.Security.Cryptography.dll','System.IO.Compression.dll','System.Threading.dll')
$result=[HmiOutputProbe]::Run($jobRoot,$outRoot,$InstallDirectory,$DesktopDirectory)
$result['runtime_types_path']=$runtimePath
$result['runtime_types_sha256']=$runtimeHash
$result['host_source_sha256']=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'HmiOutputProbe.cs') -Algorithm SHA256).Hash.ToLowerInvariant()
$result['input_sources_unchanged']=$true
foreach($source in $sourceHashes.Keys){if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $sourceHashes[$source]){$result['status']='failed';$result['input_sources_unchanged']=$false}}
if($result['status'] -eq 'pages_generated'){
 try {
  $bindings=@()
  $tagMap=@{}
  foreach($tag in $result['controller_tags']){$tagMap[$tag.name]=$tag}
  $variables=Get-Content -Raw -LiteralPath (Join-Path $outRoot 'gateway.variables.json') | ConvertFrom-Json
  foreach($variable in $variables.variables){
   $parts=$variable.name.Split('.')
   $tag=$tagMap[$parts[0]]
   if($null -eq $tag){throw "Unbound runtime tag: $($variable.name)"}
   $type=$runtimeTypes[$tag.data_type]
   $offset=0
   for($i=1;$i -lt $parts.Length;$i++){
    if($null -eq $type -or $type.Kind -ne 'Structure'){throw "Unsupported path type: $($variable.name)"}
    $fields=@($type.Fields | Where-Object Name -CEQ $parts[$i])
    if($fields.Count -ne 1){throw "Unknown field: $($variable.name)"}
    $offset += [int64]$fields[0].FieldOffset
    $type=$runtimeTypes[$fields[0].FieldType]
   }
   if($null -eq $type -or $type.Name -cne $variable.type){throw "Runtime binding type mismatch: $($variable.name) expected $($variable.type)"}
   if($offset -lt 0 -or ($offset+$type.RuntimeSize) -gt $runtimeTypes[$tag.data_type].RuntimeSize){throw "Runtime field exceeds containing type: $($variable.name)"}
   $bindings += [ordered]@{name=$variable.name;data_type=$type.Name;runtime_path=$tag.runtime_path;offset=$offset;size=$type.RuntimeSize;read_only=$tag.read_only}
  }
  if((Get-FileHash -LiteralPath $runtimePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $runtimeHash){throw 'Runtime types changed while generating pages.'}
  $result['runtime_bindings']=$bindings
  $result['runtime_binding_count']=$bindings.Count
  $functionChecks=@()
  foreach($page in @('gateway','login')){
   $pageJson=Get-Content -Raw -LiteralPath (Join-Path $outRoot ($page+'.json'))
   $pageScript=Get-Content -Raw -LiteralPath (Join-Path $outRoot ($page+'Module.js'))
   if($pageScript -notmatch ('\b'+$page+'Module\s*=')){throw "Invalid script module name: $page"}
   $references=@([regex]::Matches($pageJson,'"Name"\s*:\s*"(\w+fn)"') | ForEach-Object {$_.Groups[1].Value} | Sort-Object -Unique)
   $functions=@([regex]::Matches($pageScript,'\b(\w+fn)\s*:\s*function\s*\(') | ForEach-Object {$_.Groups[1].Value} | Sort-Object -Unique)
   if(@(Compare-Object $references $functions).Count -ne 0){throw "Page function reference mismatch: $page"}
   $functionChecks += @{page=$page;json_references=$references.Count;script_functions=$functions.Count;module_name_valid=$true}
  }
  $result['function_checks']=$functionChecks
 } catch {
  $result['status']='failed'
  $result['runtime_validation_error']=$_.Exception.Message
 }
}
$result | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath (Join-Path $outRoot 'result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 5
if($result['status'] -ne 'pages_generated'){exit 2}
