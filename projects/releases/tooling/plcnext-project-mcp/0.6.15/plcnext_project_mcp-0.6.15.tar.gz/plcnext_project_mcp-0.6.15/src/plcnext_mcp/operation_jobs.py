"""Fixed asynchronous controller operations with persistent cooperative cancel.

Only the normal reviewed recovery/control consumers run. No issuer, arbitrary
callable, raw RPC or automatic restart is exposed. Host loss is an unknown result,
never evidence that already sent device actions were cancelled or undone.
"""
from __future__ import annotations

from datetime import datetime,timezone
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid

from .controller_download_plan import _strict_json
from .deployment_plan import _file
from .project import ProjectError,sha

SCHEMA='plcnext-controller-operation-job/v1'
CANCEL_SCHEMA='plcnext-controller-operation-cancel/v1'
MAX_LOCAL_ACTIVE=4
_threads={}
_registry_lock=threading.Lock()
_file_io_lock=threading.RLock()
_TERMINAL=frozenset(('completed','failed','needs_attention'))


def _utc():return datetime.now(timezone.utc).isoformat()


def _bytes(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')


def _local_file_io(action):
    """Serialize local readers/replaces and tolerate bounded Windows sharing races.

    This never retries a controller request. Other frontend processes can hold a
    short-lived read handle while a worker publishes its next atomic snapshot.
    """
    with _file_io_lock:
        for attempt in range(10):
            try:return action()
            except PermissionError:
                if os.name!='nt' or attempt==9:raise
                time.sleep(.01)


def _atomic(path,value):
    temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temporary.open('xb') as stream:
            stream.write(_bytes(value)+b'\n');stream.flush();os.fsync(stream.fileno())
        _local_file_io(lambda:os.replace(temporary,path))
    finally:
        temporary.unlink(missing_ok=True)


def _process_birth(pid):
    """Read process creation identity without os.kill (unsafe on Windows)."""
    if type(pid) is not int or pid<=0:return None
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        kernel.OpenProcess.restype=wintypes.HANDLE
        kernel.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)]
        kernel.GetProcessTimes.restype=wintypes.BOOL
        kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype=wintypes.BOOL
        kernel.CloseHandle.argtypes=[wintypes.HANDLE]
        handle=kernel.OpenProcess(0x1000,False,pid)
        if not handle:return None
        try:
            code=wintypes.DWORD()
            if not kernel.GetExitCodeProcess(handle,ctypes.byref(code)) or code.value!=259:return None
            fields=[wintypes.FILETIME() for _ in range(4)]
            if not kernel.GetProcessTimes(handle,*[ctypes.byref(v) for v in fields]):return None
            return 'windows-filetime:'+str((fields[0].dwHighDateTime<<32)|fields[0].dwLowDateTime)
        finally:kernel.CloseHandle(handle)
    try:
        stat=(Path('/proc')/str(pid)/'stat').read_text()
        boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        return 'linux-proc:'+boot+':'+stat.rsplit(') ',1)[1].split()[19]
    except (OSError,IndexError):return None


def _key(store,project_id,operation_id):
    return os.path.normcase(str(store.root.resolve()))+':'+project_id+':'+operation_id


def _load(store,project_id,operation_id,expected_review_sha256):
    if (type(operation_id) is not str or re.fullmatch('[0-9a-f]{32}',operation_id) is None
            or type(expected_review_sha256) is not str or re.fullmatch('[0-9a-f]{64}',expected_review_sha256) is None):
        raise ProjectError('Exact operation ID and review SHA-256 are required.')
    folder=_file(store._folder(project_id),'controller-operation-jobs/'+operation_id)
    path=_file(folder,'operation.json')
    if not path.is_file() or path.stat().st_size>1024*1024:raise ProjectError('Missing or oversized controller operation job.')
    def read():
        with path.open('rb') as stream:return stream.read(1024*1024+1)
    raw=_local_file_io(read)
    if len(raw)>1024*1024:raise ProjectError('Oversized controller operation job.')
    record=_strict_json(raw)
    if (type(record) is not dict or record.get('schema')!=SCHEMA or record.get('project_id')!=project_id
            or record.get('operation_id')!=operation_id or record.get('review_sha256')!=expected_review_sha256
            or record.get('kind') not in ('recovery','control','instrumented_fault')):
        raise ProjectError('Operation project/ID/review binding mismatch.')
    return folder,record


class FileCancelEvent:
    """An Event-like adapter whose cancel request survives frontend processes."""
    def __init__(self,folder,record):
        self.folder=Path(folder);self.record=record
        self.invalid_cancel_marker=False;self.progress_persistence_error=None

    def is_set(self):
        path=self.folder/'cancel-request.json'
        if not path.exists():return False
        try:
            if path.stat().st_size>4096:raise ValueError('Oversized marker.')
            value=_strict_json(path.read_bytes())
            if (value.get('schema')!=CANCEL_SCHEMA or any(value.get(key)!=self.record[key]
                    for key in ('operation_id','project_id','review_sha256'))):
                raise ValueError('Cancel binding mismatch.')
            return True
        except (OSError,ValueError,TypeError,AttributeError):
            self.invalid_cancel_marker=True
            return True  # Fail closed at the next cooperative boundary.

    def record_progress(self,stage):
        if type(stage) is not str or not 1<=len(stage)<=100:return
        if self.record.get('phase')==stage:return
        self.record.update(phase=stage,updated_utc=_utc())
        try:_atomic(self.folder/'operation.json',self.record)
        except OSError as exc:self.progress_persistence_error=type(exc).__name__


def _admit(store,project_id,review_id,digest,kind):
    if kind=='recovery':
        from .controller_recovery import load_recovery_plan
        return load_recovery_plan(store,project_id,review_id,digest)
    if kind=='control':
        from .controller_control import revalidate_control_review
        return revalidate_control_review(store,project_id,review_id,digest)
    if kind=='instrumented_fault':
        from .instrumented_fault import load_instrumented_fault_review
        return load_instrumented_fault_review(store,project_id,review_id,digest)
    raise ProjectError('Only fixed reviewed recovery/control/instrumented-fault operations are admitted.')


def _execute_recovery(store,project_id,review_id,digest,event):
    from .controller_recovery import execute_recovery_plan
    return execute_recovery_plan(store,project_id,review_id,digest,cancel_event=event)


def _execute_control(store,project_id,review_id,digest,event):
    from .controller_control import execute_reviewed_control
    # Standalone Start still refuses without its required loaded identity proof.
    return execute_reviewed_control(store,project_id,review_id,digest,cancel_event=event)


def _execute_instrumented_fault(store,project_id,review_id,digest,event):
    from .instrumented_fault import execute_reviewed_instrumented_fault
    return execute_reviewed_instrumented_fault(store,project_id,review_id,digest,cancel_event=event)


def _worker(store,folder,record):
    event=FileCancelEvent(folder,record)
    try:
        record.update(status='running',phase='entering_'+record['kind'],started_utc=_utc(),
            native_thread_id=threading.get_native_id(),updated_utc=_utc())
        _atomic(folder/'operation.json',record)
        driver={'recovery':_execute_recovery,'control':_execute_control,
            'instrumented_fault':_execute_instrumented_fault}[record['kind']]
        result=driver(store,record['project_id'],record['review_id'],record['review_sha256'],event)
        envelope={'schema':'plcnext-controller-operation-result/v1','operation_id':record['operation_id'],
            'project_id':record['project_id'],'review_sha256':record['review_sha256'],
            'kind':record['kind'],'result':result,'finished_utc':_utc()}
        _atomic(folder/'result.json',envelope)
        unknown=bool(result.get('outcome_unknown'))
        attention=unknown or result.get('receipt_persisted') is False or result.get('endpoint_lease_retained') is True
        failed=result.get('status') not in ('control_completed','control_already_complete',
            'original_loaded_runtime_observed','fault_released_verified')
        record.update(status='needs_attention' if attention else 'failed' if failed else 'completed',
            phase='finished',finished_utc=_utc(),updated_utc=_utc(),
            execution_result_status=result.get('status'),outcome_unknown=unknown,
            controller_changed=result.get('controller_changed',result.get('action_sent',False)),
            cancel_observed=result.get('cancelled',event.is_set()),
            result_path=str(folder/'result.json'),result_sha256=sha(_bytes(envelope)+b'\n'),
            driver_report_path=result.get('report_path'),driver_journal_path=result.get('journal_path'),
            endpoint_lease_path=result.get('endpoint_lease_path'),
            endpoint_lease_retained=result.get('endpoint_lease_retained'),
            cancel_marker_invalid=event.invalid_cancel_marker,
            progress_persistence_error_class=event.progress_persistence_error)
        _atomic(folder/'operation.json',record)
    except BaseException as exc:
        # An uncaught driver or persistence error cannot establish no device effect.
        record.update(status='needs_attention',phase='worker_exception',outcome_unknown=True,
            finished_utc=_utc(),updated_utc=_utc(),error_class=type(exc).__name__,
            failure_code=getattr(exc,'code','operation_worker_or_persistence_failure'),
            automatic_restart=False)
        try:_atomic(folder/'operation.json',record)
        except (OSError,ValueError):pass


def _start(store,project_id,review_id,digest,kind):
    review=_admit(store,project_id,review_id,digest,kind)
    birth=_process_birth(os.getpid())
    if birth is None:raise ProjectError('Cannot bind this operation host process creation identity.')
    operation_id=uuid.uuid4().hex
    with _registry_lock:
        active=sum(thread.is_alive() for thread in _threads.values())
        if active>=MAX_LOCAL_ACTIVE:raise ProjectError('This MCP host already has the maximum active operation jobs.')
        folder=_file(store._folder(project_id),'controller-operation-jobs/'+operation_id)
        folder.mkdir(parents=True,exist_ok=False)
        record={'schema':SCHEMA,'operation_id':operation_id,'project_id':project_id,'review_id':review_id,
            'review_sha256':digest,'kind':kind,'target':review['target'],
            'source_project_sha256':review['source']['project_sha256'],
            'inventory_sha256':review['package']['inventory_sha256'],
            'created_utc':_utc(),'updated_utc':_utc(),'status':'queued','phase':'queued',
            'host_pid':os.getpid(),'host_process_birth':birth,'automatic_restart':False,
            'approval_issued':False,'review_is_authorization':False,'cancel_is_rollback':False}
        _atomic(folder/'operation.json',record)
        thread=threading.Thread(target=_worker,args=(store,folder,record),daemon=True,
            name='PLCnext-controller-operation-'+operation_id)
        _threads[_key(store,project_id,operation_id)]=thread
        thread.start()
    return controller_operation_status(store,project_id,operation_id,digest)


def start_recovery_operation(store,project_id,plan_id,expected_plan_sha256):
    return _start(store,project_id,plan_id,expected_plan_sha256,'recovery')


def start_control_operation(store,project_id,review_id,expected_review_sha256):
    return _start(store,project_id,review_id,expected_review_sha256,'control')


def start_instrumented_fault_operation(store,project_id,review_id,expected_review_sha256):
    return _start(store,project_id,review_id,expected_review_sha256,'instrumented_fault')


def controller_operation_status(store,project_id,operation_id,expected_review_sha256,*,include_result=False):
    if type(include_result) is not bool:raise ProjectError('include_result must be Boolean.')
    folder,record=_load(store,project_id,operation_id,expected_review_sha256)
    result=dict(record,operation_path=str(folder/'operation.json'),device_contacted_by_status=False,
        cancel_requested=(folder/'cancel-request.json').exists())
    if record['status'] not in _TERMINAL:
        birth=_process_birth(record['host_pid'])
        local=_threads.get(_key(store,project_id,operation_id))
        known_dead=(record['host_pid']==os.getpid() and (local is None or not local.is_alive()))
        if birth!=record['host_process_birth'] or known_dead:
            result.update(status='worker_outcome_unknown',outcome_unknown=True,
                reason='Host exited, PID identity changed or the local worker is no longer known; no automatic restart.',
                automatic_restart=False,claimed_records_untouched_by_job_layer=True,
                endpoint_lease_not_removed_by_job_layer=True,
                endpoint_lease_state='inspect_existing_lease_and_driver_journal')
    if include_result and record.get('result_path'):
        path=_file(folder,'result.json')
        if not path.is_file() or path.stat().st_size>32*1024*1024:raise ProjectError('Operation result missing or oversized.')
        with path.open('rb') as stream:raw=stream.read(32*1024*1024+1)
        if len(raw)>32*1024*1024:raise ProjectError('Operation result oversized.')
        if sha(raw)!=record.get('result_sha256'):raise ProjectError('Operation result bytes changed.')
        envelope=_strict_json(raw)
        if any(envelope.get(k)!=record[k] for k in ('operation_id','project_id','review_sha256','kind')):
            raise ProjectError('Operation result identity changed.')
        result['result']=envelope['result']
    return result


def cancel_controller_operation(store,project_id,operation_id,expected_review_sha256,*,reason='operator_requested'):
    folder,record=_load(store,project_id,operation_id,expected_review_sha256)
    if type(reason) is not str or not 1<=len(reason)<=200 or any(ord(c)<32 for c in reason):
        raise ProjectError('A bounded single-line cancellation reason is required.')
    if record['status'] in _TERMINAL:
        return controller_operation_status(store,project_id,operation_id,expected_review_sha256)|{
            'cancel_request_status':'already_terminal','inverse_action_sent':False}
    marker={'schema':CANCEL_SCHEMA,**{key:record[key] for key in ('operation_id','project_id','review_sha256')},
        'requested_utc':_utc(),'reason':reason,'cancellation_is_not_device_rollback':True}
    path=folder/'cancel-request.json'
    try:
        with path.open('xb') as stream:
            stream.write(_bytes(marker)+b'\n');stream.flush();os.fsync(stream.fileno())
    except FileExistsError:pass
    return controller_operation_status(store,project_id,operation_id,expected_review_sha256)|{
        'cancel_request_status':'requested','inverse_action_sent':False,
        'request_sent_actions_undone':False}
