"""Offline project creation and atomic FB lifecycle, without vendor execution."""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import io
import os
from pathlib import Path
import re
import tempfile
import uuid
import xml.etree.ElementTree as ET
import zipfile

from .project import (MAX_EXPANDED, ProjectError, decode_code, encode_worksheet,
                      masked_st, pou_index, read_archive, sha, xml)

MSBUILD = 'http://schemas.microsoft.com/developer/msbuild/2003'
CONTENT = 'http://schemas.openxmlformats.org/package/2006/content-types'
PROJ = 'PROJECT/PROJECT.proj'
TYPES = '[Content_Types].xml'
LOGICAL = 'PROJECT/Logical%20Elements/'
DEFAULT_VARIABLES = 'VAR_INPUT\nEND_VAR\nVAR_OUTPUT\nEND_VAR\nVAR\nEND_VAR\n'
DEFAULT_TEMPLATE = Path(r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0\Templates\AXCF215200260.pxctx')


def _serialize(root: ET.Element) -> bytes:
    # Register only this tree's default namespace: otherwise ElementTree emits
    # ns0-prefixed MSBuild/OPC documents when adding one ordinary POU record.
    if root.tag.startswith('{'):
        ET.register_namespace('', root.tag[1:].split('}', 1)[0])
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)


def _local(node: ET.Element) -> str:
    return node.tag.rsplit('}', 1)[-1]


def _child(node: ET.Element, name: str) -> ET.Element | None:
    return next((item for item in node if _local(item) == name), None)


def _name(value: str, *, project: bool = False) -> str:
    if not isinstance(value, str) or not value or len(value) > 64:
        raise ProjectError('Names must contain between 1 and 64 characters.')
    if project:
        if value != value.strip() or value.endswith('.') or re.search(r'[<>:"/\\|?*\x00-\x1f]', value):
            raise ProjectError('Project name must be a safe filename/display name.')
    elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,63}', value) is None or value.startswith('__'):
        raise ProjectError('FB names must be ordinary IEC identifiers (letters, digits, underscore).')
    if value.split('.', 1)[0].upper() in {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}:
        raise ProjectError('Reserved Windows device names are unsupported.')
    if not project and value.upper() in {'VAR', 'VAR_INPUT', 'VAR_OUTPUT', 'VAR_IN_OUT', 'END_VAR',
                                        'PROGRAM', 'FUNCTION', 'FUNCTION_BLOCK', 'IF', 'THEN', 'ELSE',
                                        'END_IF', 'FOR', 'WHILE', 'REPEAT', 'TYPE', 'END_TYPE', 'TRUE', 'FALSE'}:
        raise ProjectError('Reserved IEC keywords cannot be FB names.')
    return value


def _project_folders(root: ET.Element) -> dict[str, tuple[ET.Element, ET.Element]]:
    result = {}
    for group in root:
        for node in group:
            include = node.get('Include', '')
            if _local(node) == 'Folder' and include.lower().endswith('.pou'):
                key = include.replace('\\', '/').casefold()
                if key in result:
                    raise ProjectError('Duplicate POU folder records in PROJECT.proj.')
                result[key] = (group, node)
    return result


def _new_metadata(name: str, kind: str = 'FunctionBlock') -> tuple[bytes, dict]:
    identifiers = {key: str(uuid.uuid4()) for key in ('pou', 'variables', 'code')}
    root = ET.Element('Metadata')
    for tag, text in (('FolderType', 'PouFolder'), ('ContentType', kind), ('Kind', kind), ('Id', identifiers['pou'])):
        ET.SubElement(root, tag).text = text
    group = ET.SubElement(root, 'ItemGroup')
    ET.SubElement(ET.SubElement(group, 'VariableWorksheet'), 'Id').text = identifiers['variables']
    code = ET.SubElement(group, 'CodeWorksheet', Include='Code.st')
    for tag, value in (('Id', identifiers['code']), ('Extension', '.st'), ('Type', '.st'), ('ParentIndex', '2')):
        ET.SubElement(code, tag).text = value
    return _serialize(root), identifiers


def _content_types(members: dict[str, bytes]) -> None:
    if TYPES not in members:
        raise ProjectError('The project lacks the OPC content-type table.')
    root = xml(members[TYPES])
    changed = False
    for extension in ('st', 'var', 'meta'):
        if not any(_local(node) == 'Default' and node.get('Extension', '').casefold() == extension for node in root):
            ET.SubElement(root, '{' + CONTENT + '}Default', Extension=extension, ContentType='application/octet-stream')
            changed = True
    if changed:
        members[TYPES] = _serialize(root)


def _zip_bytes(members: dict[str, bytes], infos: list[zipfile.ZipInfo], comment: bytes) -> bytes:
    if len(members) > 10000 or sum(map(len, members.values())) > MAX_EXPANDED:
        raise ProjectError('Project exceeds archive member or expanded-size limits.')
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w') as archive:
        archive.comment = comment
        retained = set()
        for info in infos:
            if info.filename in members:
                archive.writestr(copy.copy(info), members[info.filename])
                retained.add(info.filename)
        for name in sorted(set(members) - retained):
            info = zipfile.ZipInfo(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o40755 if name.endswith('/') else 0o100644) << 16
            archive.writestr(info, members[name])
    return output.getvalue()


def _versions(install: Path, original: bytes) -> tuple[str, str]:
    """Read version resources as bytes through Win32, never execute the app."""
    executable = install / 'PLCNENG64.exe'
    if os.name == 'nt' and executable.is_file():
        import ctypes
        library = ctypes.windll.version
        size = library.GetFileVersionInfoSizeW(str(executable), None)
        data = ctypes.create_string_buffer(size)
        if size and library.GetFileVersionInfoW(str(executable), 0, size, data):
            pointer, length = ctypes.c_void_p(), ctypes.c_uint()
            if library.VerQueryValueW(data, '\\VarFileInfo\\Translation', ctypes.byref(pointer), ctypes.byref(length)) and length.value >= 4:
                translation = ctypes.cast(pointer, ctypes.POINTER(ctypes.c_ushort))
                table = f'{translation[0]:04x}{translation[1]:04x}'
                values = []
                for field in ('FileVersion', 'ProductVersion'):
                    query = f'\\StringFileInfo\\{table}\\{field}'
                    if not library.VerQueryValueW(data, query, ctypes.byref(pointer), ctypes.byref(length)):
                        break
                    values.append(ctypes.wstring_at(pointer, length.value).rstrip('\0'))
                if len(values) == 2:
                    return tuple(values)
    values = {node.get('Key'): node.get('Value', '') for node in xml(original)}
    result = values.get('ApplicationVersion', ''), values.get('ProductVersion', '')
    if not all(result) or any(value.startswith('999.') for value in result):
        raise ProjectError('Unable to resolve installed Engineer versions for this template.')
    return result


def create_project(store, name: str, template_path: str | None = None) -> dict:
    name = _name(name, project=True)
    install = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', str(DEFAULT_TEMPLATE.parent.parent))).expanduser().resolve()
    template = Path(template_path).expanduser().resolve(strict=True) if template_path else install / 'Templates' / DEFAULT_TEMPLATE.name
    if template.suffix.lower() != '.pxctx':
        raise ProjectError('Project creation requires an official .pxctx template.')
    raw_template, source, _, comment = read_archive(template)
    required = {PROJ, TYPES, '_properties/Core.xml', '_properties/Extended.xml', '_properties/Additional.xml'}
    if not required <= set(source):
        raise ProjectError('Unsupported template package layout.')
    extended = xml(source['_properties/Extended.xml'])
    type_node = _child(extended, 'Type')
    if type_node is None or type_node.text != 'Template':
        raise ProjectError('The supplied package is not a project template.')
    index = pou_index(source)
    if len(index) != 1 or 'Main' not in index or index['Main']['kind'] != 'Program':
        raise ProjectError('Only the single-Main AXC F 2152 device template is supported.')
    project = xml(source[PROJ])
    configuration = next((node for node in project.iter() if _local(node) == 'Folder' and
                          _child(node, 'FolderType') is not None and _child(node, 'FolderType').text == 'Configuration'), None)
    resource = next((node for node in project.iter() if _local(node) == 'Folder' and
                     _child(node, 'FolderType') is not None and _child(node, 'FolderType').text == 'Resource'), None)
    if configuration is None or resource is None or _child(configuration, 'TypeName') is None or _child(configuration, 'TypeName').text != 'AXC F 2152':
        raise ProjectError('Only AXC F 2152 templates with one resource are supported.')
    old_ids = set()
    for data in (source[PROJ], source[index['Main']['prefix'] + 'Metadata.meta'], source['_properties/Core.xml']):
        for node in xml(data).iter():
            if _local(node) in {'Id', 'ProjectId', 'identifier', 'InstanceId'} and node.text:
                try:
                    old_ids.add(uuid.UUID(node.text))
                except ValueError:
                    pass
    replacements = {old: uuid.uuid4() for old in old_ids}
    pattern = re.compile(b'(?i)(?<![0-9a-f])(?:' + b'|'.join(
        value.encode('ascii') for old in old_ids for value in (str(old), old.hex)) + b')(?![0-9a-f])')
    def replace(data: bytes) -> bytes:
        def match(item):
            before = item.group().decode('ascii')
            after = replacements[uuid.UUID(before)]
            value = str(after) if '-' in before else after.hex
            return (value.upper() if before.isupper() else value).encode('ascii')
        return pattern.sub(match, data)
    members = {replace(path.encode('utf-8')).decode('utf-8'): replace(data) for path, data in source.items()}
    # Use fresh ZipInfo entries because identity replacement can change names.
    project = xml(members[PROJ])
    for parent in project.iter():
        for node in list(parent):
            if _local(node) in {'TemplateDescription', 'TemplateImage', 'CompilerProjectReference'}:
                include = node.get('Include', '').replace('\\', '/')
                if include:
                    members.pop('PROJECT/' + include.replace(' ', '%20'), None)
                parent.remove(node)
    for path in list(members):
        if re.fullmatch(r'(?:CompilerProject.*\.(?:bin|ast)|LastBuild\.ast)', Path(path).name, re.I):
            del members[path]
    members[PROJ] = _serialize(project)
    core = xml(members['_properties/Core.xml'])
    title = next((node for node in core.iter() if _local(node) == 'title'), None)
    if title is None:
        raise ProjectError('Template core properties have no project title.')
    title.text = name
    members['_properties/Core.xml'] = _serialize(core)
    extended = xml(members['_properties/Extended.xml'])
    _child(extended, 'Type').text = 'Project'
    members['_properties/Extended.xml'] = _serialize(extended)
    app_version, product_version = _versions(install, source['_properties/Additional.xml'])
    additional = xml(members['_properties/Additional.xml'])
    for node in additional:
        if node.get('Key') in {'ApplicationVersion', 'ProductVersion'}:
            node.set('Value', app_version if node.get('Key') == 'ApplicationVersion' else product_version)
    members['_properties/Additional.xml'] = _serialize(additional)
    main = pou_index(members)['Main']
    metadata = xml(members[main['prefix'] + 'Metadata.meta'])
    group = metadata.find('ItemGroup')
    if group is None:
        raise ProjectError('Template Main metadata has no ItemGroup.')
    # Empty official template has no executable worksheet. Convert only that
    # empty Main; reject a graphical or multi-worksheet user template.
    code_nodes = group.findall('CodeWorksheet')
    if code_nodes or any(Path(path).suffix.lower() in {'.nold', '.fbd', '.sfc', '.ld'} for path in members if path.startswith(main['prefix'])):
        raise ProjectError('Expected an empty Main template; graphical/code templates are unsupported.')
    code = ET.SubElement(group, 'CodeWorksheet', Include='Code.st')
    for tag, value in (('Id', str(uuid.uuid4())), ('Extension', '.st'), ('Type', '.st'), ('ParentIndex', '2')):
        ET.SubElement(code, tag).text = value
    members[main['prefix'] + 'Metadata.meta'] = _serialize(metadata)
    members[main['prefix'] + 'Code.st'] = b'(* Main program. *)\n'
    members[main['prefix'] + 'Variables.var'] = b'VAR\nEND_VAR\n'
    _content_types(members)
    raw = _zip_bytes(members, [], comment)
    project_id = uuid.uuid4().hex
    store.root.mkdir(parents=True, exist_ok=True)
    folder = store.root / project_id
    folder.mkdir()
    manifest = {'schema': 2, 'project_id': project_id, 'project_name': name, 'origin': 'official_template',
                'source_path': str(template), 'source_template_sha256': sha(raw_template),
                'created_utc': datetime.now(timezone.utc).isoformat(), 'original_sha256': sha(raw),
                'revision': 0, 'current_sha256': sha(raw), 'allowed_code_members': [],
                'allowed_variable_members': [], 'history': [], 'lifecycle_history': []}
    try:
        (folder / 'original.pcwex').write_bytes(raw)
        (folder / 'revision-0000.pcwex').write_bytes(raw)
        read_archive(folder / 'revision-0000.pcwex')
        store._save_manifest(folder, manifest)
    except Exception:
        for path in folder.iterdir():
            if path.is_file():
                path.unlink()
        folder.rmdir()
        raise
    final_project = xml(members[PROJ])
    resource_name = next(Path(node.get('Include').replace('\\', '/')).name for node in final_project.iter()
                         if _local(node) == 'Folder' and _child(node, 'FolderType') is not None and _child(node, 'FolderType').text == 'Resource')
    return {**store._identity(folder, manifest), 'project_name': name, 'template_path': str(template),
            'template_sha256': sha(raw_template), 'resource_name': resource_name, 'pou_count': 1,
            'independent_identities': True, 'source_untouched': True, 'compiled': False, 'aci_used': False}


def _updated_members(index: dict, members: dict[str, bytes], updates: list[dict]) -> dict[str, bytes]:
    replacements, seen = {}, set()
    required = {'pou_name', 'expected_code_sha256', 'expected_variables_sha256'}
    for update in updates:
        if not isinstance(update, dict) or not required <= set(update) or set(update) - (required | {'code', 'variables'}):
            raise ProjectError('Caller updates require pou_name and both worksheet hashes; only code/variables may change.')
        name = update['pou_name']
        if not isinstance(name, str) or name not in index or name.casefold() in seen:
            raise ProjectError('Caller updates must name distinct existing POUs.')
        seen.add(name.casefold())
        if 'code' not in update and 'variables' not in update:
            raise ProjectError('Caller update must supply code and/or variables.')
        for field, filename in (('code', 'Code.st'), ('variables', 'Variables.var')):
            path = index[name]['prefix'] + filename
            if path not in members:
                raise ProjectError('Caller has no supported ST/variable worksheet.')
            if update['expected_' + field + '_sha256'] != sha(members[path]):
                raise ProjectError('Stale caller worksheet hash: ' + name)
            if field in update:
                encoded = encode_worksheet(members[path], update[field])
                if encoded != members[path]:
                    replacements[path] = encoded
    return replacements


def _check_deletion_references(before: dict[str, bytes], final: dict[str, bytes], deleted: list[dict]) -> None:
    if not deleted:
        return
    final_index = pou_index(final)
    if any(not item['has_st'] for item in final_index.values()) or any(
            Path(path).suffix.lower() in {'.nold', '.fbd', '.sfc', '.ld', '.cfc'} for path in final):
        raise ProjectError('Deletion cannot prove reference safety while graphical/unsupported POUs exist.')
    for item in deleted:
        pattern = re.compile(r'(?<![A-Za-z0-9_])' + re.escape(item['name']) + r'(?![A-Za-z0-9_])', re.I)
        instances = set()
        for path, payload in before.items():
            if path.endswith('.var') and not path.startswith(item['prefix']):
                source = masked_st(decode_code(payload))
                for declaration in re.finditer(r'\b([A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)*)\s*:\s*([^;]+);', source):
                    if pattern.search(declaration.group(2)):
                        instances.update(re.findall(r'[A-Za-z_]\w*', declaration.group(1)))
        for path, payload in final.items():
            if path.endswith('/'):
                continue
            try:
                source = decode_code(payload)
            except ProjectError:
                # Binary files are not interpreted as source. Explicit opaque
                # graphical formats were rejected above.
                continue
            if path.endswith(('.st', '.var', '.dt')):
                source = masked_st(source)
            if pattern.search(source) or (item['id'] and item['id'].casefold() in source.casefold()):
                raise ProjectError(f"FB {item['name']} is still referenced by {path}; update callers in the same transaction.")
            for instance in instances:
                if re.search(r'\b' + re.escape(instance) + r'\b', source, re.I):
                    raise ProjectError(f"Deleted FB instance {instance} remains referenced in {path}; remove its calls/mappings too.")


def change_structure(store, project_id: str, expected_project_sha256: str,
                     add_fbs: list[dict] | None = None, delete_fbs: list[str] | None = None,
                     updates: list[dict] | None = None) -> dict:
    additions = [] if add_fbs is None else add_fbs
    deletions = [] if delete_fbs is None else delete_fbs
    updates = [] if updates is None else updates
    if any(not isinstance(values, list) or len(values) > 1000 for values in (additions, deletions, updates)) or not (additions or deletions):
        raise ProjectError('A structure transaction needs bounded add_fbs/delete_fbs lists; use update_pous for edits alone.')
    folder = store._folder(project_id)
    with store._lock(folder):
        folder, manifest, before, infos, comment = store._current(project_id)
        if manifest['current_sha256'] != expected_project_sha256:
            raise ProjectError('Stale project revision; read the project again before editing.')
        index = pou_index(before)
        if PROJ not in before:
            raise ProjectError('PROJECT.proj is required for POU structure changes.')
        final = before.copy()
        replacements = _updated_members(index, before, updates)
        final.update(replacements)
        project = xml(before[PROJ])
        folders = _project_folders(project)
        next_parent_index = max((int(_child(node, 'ParentIndex').text or '0')
                                 for _, node in folders.values()
                                 if _child(node, 'ParentIndex') is not None and
                                 (_child(node, 'ParentIndex').text or '0').isdigit()), default=-1) + 1
        added, deleted, names = [], [], set()
        for name in deletions:
            if not isinstance(name, str) or name not in index or name.casefold() in names:
                raise ProjectError('delete_fbs must list distinct existing FB names.')
            names.add(name.casefold())
            item = index[name]
            if item['kind'] != 'FunctionBlock':
                raise ProjectError('Only FunctionBlock deletion is supported; programs/functions are retained.')
            key = ('Logical Elements/' + name + '.pou').casefold()
            if key not in folders:
                raise ProjectError('The FB is not registered in PROJECT.proj.')
            parent, node = folders[key]
            if not item['id'] or _child(node, 'Id') is None or _child(node, 'Id').text != item['id']:
                raise ProjectError('POU metadata and project folder IDs disagree.')
            parent.remove(node)
            for path in list(final):
                if path.startswith(item['prefix']):
                    del final[path]
            deleted.append({'name': name, 'prefix': item['prefix'], 'id': item['id']})
        existing = {name.casefold() for name in index}
        for addition in additions:
            if not isinstance(addition, dict) or set(addition) - {'pou_name', 'code', 'variables'} or 'pou_name' not in addition:
                raise ProjectError('New FB fields are pou_name, code, and variables.')
            name = _name(addition['pou_name'])
            if name.casefold() in existing or name.casefold() in names:
                raise ProjectError('An added FB name must be new and distinct from deleted/existing POUs.')
            names.add(name.casefold())
            prefix = LOGICAL + name + '.pou/'
            if ('Logical Elements/' + name + '.pou').casefold() in folders:
                raise ProjectError('The new FB already has a PROJECT.proj folder record.')
            if any(path.casefold().startswith(prefix.casefold()) for path in final):
                raise ProjectError('The new FB archive prefix already exists.')
            metadata, ids = _new_metadata(name)
            final[prefix] = b''
            final[prefix + 'Metadata.meta'] = metadata
            final[prefix + 'Code.st'] = encode_worksheet(b'', addition.get('code', '(* ' + name + ' *)\n'))
            final[prefix + 'Variables.var'] = encode_worksheet(b'', addition.get('variables', DEFAULT_VARIABLES))
            group = ET.SubElement(project, '{' + MSBUILD + '}ItemGroup')
            node = ET.SubElement(group, '{' + MSBUILD + '}Folder', Include='Logical Elements\\' + name + '.pou')
            for tag, value in (('Id', ids['pou']), ('FolderType', 'PouFolder'), ('ParentIndex', str(next_parent_index + len(added)))):
                ET.SubElement(node, '{' + MSBUILD + '}' + tag).text = value
            added.append({'name': name, 'prefix': prefix, 'id': ids['pou'], 'worksheet_ids': ids})
        final[PROJ] = _serialize(project)
        if added:
            _content_types(final)
        _check_deletion_references(before, final, deleted)
        changed = {path: {'before_sha256': sha(before[path]) if path in before else None,
                          'after_sha256': sha(final[path]) if path in final else None}
                   for path in set(before) | set(final) if before.get(path) != final.get(path) or (path in before) != (path in final)}
        revision = manifest['revision'] + 1
        target = folder / f'revision-{revision:04d}.pcwex'
        while target.exists():
            revision += 1
            target = folder / f'revision-{revision:04d}.pcwex'
        raw = _zip_bytes(final, infos, comment)
        fd, temporary_name = tempfile.mkstemp(prefix='.lifecycle-', suffix='.tmp', dir=folder)
        os.close(fd)
        temporary = Path(temporary_name)
        try:
            temporary.write_bytes(raw)
            checked_raw, checked, _, _ = read_archive(temporary)
            if checked != final or checked_raw != raw:
                raise ProjectError('Lifecycle payload preservation check failed.')
            os.rename(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        event = {'operation': 'change_structure', 'revision': revision, 'added_fbs': added,
                 'deleted_fbs': deleted, 'updated_pous': [item['pou_name'] for item in updates],
                 'member_changes': changed, 'project_sha256': sha(raw)}
        manifest['revision'], manifest['current_sha256'] = revision, sha(raw)
        manifest.setdefault('lifecycle_history', []).append(event)
        manifest['history'].append(event)
        for key, suffix in (('allowed_code_members', '/Code.st'), ('allowed_variable_members', '/Variables.var')):
            manifest[key] = sorted(set(manifest.get(key, [])) | {path for path in replacements if path.endswith(suffix)})
        try:
            store._save_manifest(folder, manifest)
        except Exception:
            try:
                persisted = store._load(project_id)[1]
                if persisted['current_sha256'] != sha(raw):
                    target.unlink(missing_ok=True)
            except (OSError, ValueError, KeyError):
                pass
            raise
        return {**store._identity(folder, manifest), 'added_fbs': added, 'deleted_fbs': deleted,
                'updated_pous': event['updated_pous'], 'changed_members': sorted(changed),
                'other_member_payloads_identical': True, 'compiled': False, 'aci_used': False,
                'reference_check': 'conservative_final_state_identifier_and_instance_scan'}


def lifecycle_permissions(manifest: dict, original: dict[str, bytes]) -> tuple[dict, set, set, list]:
    """Recover exact structural after-hashes and bounded worksheet edit scopes."""
    expected, codes, variables, invalid = {}, set(), set(), []
    known = {item['name']: item for item in pou_index(original).values()}
    for event in manifest.get('lifecycle_history', []):
        permitted = {PROJ, TYPES}
        try:
            if event['operation'] != 'change_structure':
                raise ValueError('invalid operation')
            for item in event['added_fbs']:
                name = _name(item['name'])
                prefix = LOGICAL + name + '.pou/'
                if item['prefix'] != prefix:
                    raise ValueError('invalid added prefix')
                known[name] = item
                permitted.update(prefix + suffix for suffix in ('', 'Metadata.meta', 'Code.st', 'Variables.var'))
                codes.add(prefix + 'Code.st')
                variables.add(prefix + 'Variables.var')
            for item in event['deleted_fbs']:
                if item['name'] not in known or known[item['name']]['prefix'] != item['prefix']:
                    raise ValueError('unknown deleted POU')
                permitted.update(path for path in original if path.startswith(item['prefix']))
                permitted.update(item['prefix'] + suffix for suffix in ('', 'Metadata.meta', 'Code.st', 'Variables.var'))
            for name in event['updated_pous']:
                if name not in known:
                    raise ValueError('unknown caller')
                permitted.update(known[name]['prefix'] + suffix for suffix in ('Code.st', 'Variables.var'))
            for path, change in event['member_changes'].items():
                after = change['after_sha256']
                if path not in permitted or (after is not None and re.fullmatch(r'[0-9a-f]{64}', after) is None):
                    invalid.append(path)
                else:
                    expected[path] = after
        except (KeyError, TypeError, ValueError, ProjectError):
            invalid.append('invalid lifecycle history')
    return expected, codes, variables, invalid
