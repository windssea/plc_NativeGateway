"""Source-bound, finite read-only runtime observations over pinned RSC/TLS.

This module never obtains write authority. Disk manifests and source identities
are reported separately from the limited device-side project-name observation.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import time
import uuid

from . import rsc_tagged_codec as tagged
from .controller_transport import ControllerEndpoint, ControllerFailure, TlsControllerClient, PROVIDER
from .project import ProjectError, decode_code, masked_st, pou_index, sha, xml
from .rsc_codec import CommandType
from .rsc_error_codec import receive_error
from .rsc_runtime_codec import DATA_ACCESS, PLC_INFO, receive_read_items, receive_variant

PLAN_SCHEMA = 'plcnext-runtime-read-plan/v1'
COMPONENT = 'Arp.Plc.Eclr/'
MAX_SYMBOLS = 2048
MAX_CHUNK = 64
_SECRETS = re.compile(r'password|passwd|secret|securitytoken|privatekey|credential', re.I)
_PART = re.compile(r'([A-Za-z_]\w*)(?:\[(-?\d+)\])?\Z', re.ASCII)
_SCALARS = {'BOOL':'bool', 'SINT':'sbyte', 'USINT':'byte', 'BYTE':'byte',
    'INT':'int16', 'UINT':'uint16', 'WORD':'uint16', 'DINT':'int32', 'UDINT':'uint32',
    'DWORD':'uint32', 'LINT':'int64', 'ULINT':'uint64', 'LWORD':'uint64',
    'REAL':'float32', 'LREAL':'float64'}


def _utc():
    return datetime.now(timezone.utc).isoformat()


def _canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def _plain(source):
    return re.sub(r'\{[^{}]*\}', '', masked_st(source))


def _declarations(source):
    result = {}
    for match in re.finditer(r'(?m)^\s*([A-Za-z_]\w*)\s*(?:AT\s+%[\w.]+\s*)?:\s*([^;]+);', _plain(source)):
        name, dtype = match.groups()
        dtype = dtype.split(':=', 1)[0].strip()
        if name.casefold() in result:
            raise ProjectError('Ambiguous variable declaration: ' + name)
        result[name.casefold()] = {'name': name, 'type': dtype}
    return result


class SourceSymbols:
    """Resolve a narrow declared ST path without enumerating huge arrays or memory."""
    def __init__(self, members):
        self.types, self.scopes, self.roots = {}, {}, {}
        for path, payload in members.items():
            if path.endswith('.dt'):
                source = _plain(decode_code(payload))
                for match in re.finditer(r'(?m)^\s*([A-Za-z_]\w*)\s*:\s*(?:STRUCT\b(.*?)END_STRUCT\b\s*;?|([^;]+);)', source, re.S | re.I):
                    name, body, alias = match.groups()
                    key = name.casefold()
                    item = {'name': name, 'fields': _declarations(body)} if body is not None else {'name': name, 'alias': alias.split(':=',1)[0].strip()}
                    if key in self.types and self.types[key] != item:
                        raise ProjectError('Conflicting source type: ' + name)
                    self.types[key] = item
        index = pou_index(members)
        for name, pou in index.items():
            self.scopes[name.casefold()] = _declarations(decode_code(members.get(pou['prefix'] + 'Variables.var', b'')))
        globals_found = [payload for path, payload in members.items() if path.endswith('/GlobalVariables.var')]
        if len(globals_found) != 1:
            raise ProjectError('Runtime monitoring requires one explicit global variable worksheet.')
        for item in _declarations(decode_code(globals_found[0])).values():
            self.roots[item['name'].casefold()] = dict(item, kind='global')
        esm_found = [payload for path, payload in members.items() if path.endswith('/EsmConfiguration.esmc')]
        if len(esm_found) != 1:
            raise ProjectError('Runtime monitoring requires one explicit ESM source configuration.')
        self.programs = []
        for instance in xml(esm_found[0]).findall('./Tasks/Task/ProgramInstances/ProgramInstance'):
            name, typename = instance.get('name'), instance.get('programType')
            if (not name or not re.fullmatch(r'[A-Za-z_]\w*', name, re.ASCII) or typename not in index
                    or instance.get('componentName') != 'Arp.Plc.Eclr'):
                raise ProjectError('Unsupported source program instance for runtime monitoring.')
            if name.casefold() in self.roots:
                raise ProjectError('Ambiguous global/program root.')
            self.roots[name.casefold()] = {'name': name, 'type': typename, 'kind': 'program'}
            self.programs.append({'name': name, 'type': typename, 'id': instance.get('id')})

    def _expand(self, dtype):
        seen = set()
        for _ in range(16):
            key = dtype.casefold()
            if key in seen:
                raise ProjectError('Cyclic source type alias.')
            seen.add(key)
            entry = self.types.get(key)
            if entry is None or 'alias' not in entry:
                return dtype
            dtype = entry['alias']
        raise ProjectError('Source type alias nesting exceeds bound.')

    def _fields(self, dtype):
        dtype = self._expand(dtype)
        entry = self.types.get(dtype.casefold())
        if entry is not None and 'fields' in entry:
            return entry['fields']
        if dtype.casefold() in self.scopes:
            return self.scopes[dtype.casefold()]
        raise ProjectError('Field access requires a declared project struct/POU; library internals are unsupported.')

    def _indexed(self, dtype, index):
        dtype = self._expand(dtype)
        array = re.fullmatch(r'ARRAY\s*\[\s*(-?\d+)\s*\.\.\s*(-?\d+)\s*\]\s+OF\s+(.+)', dtype, re.I | re.S)
        if index is None:
            if array:
                raise ProjectError('Read one explicit array element, not an entire array.')
            return dtype
        if array is None or not int(array[1]) <= int(index) <= int(array[2]):
            raise ProjectError('Source array index outside its declared range.')
        return self._expand(array[3].strip())

    def resolve(self, symbol):
        if type(symbol) is not str or not 1 <= len(symbol) <= 350:
            raise ProjectError('A bounded explicit source variable path is required.')
        symbol = symbol[len(COMPONENT):] if symbol.startswith(COMPONENT) else symbol
        parts = symbol.split('.')
        if not 1 <= len(parts) <= 16:
            raise ProjectError('Variable path nesting exceeds bound.')
        parsed = [_PART.fullmatch(part) for part in parts]
        if any(match is None or _SECRETS.search(match[1]) for match in parsed):
            raise ProjectError('Invalid path or secret-bearing variable is excluded from monitoring.')
        first = parsed[0]
        root = self.roots.get(first[1].casefold())
        if root is None:
            raise ProjectError('Variable root is absent from the reviewed project source.')
        dtype = self._indexed(root['type'], first[2])
        names = [root['name'] + ('['+first[2]+']' if first[2] is not None else '')]
        for part in parsed[1:]:
            fields = self._fields(dtype)
            field = fields.get(part[1].casefold())
            if field is None:
                raise ProjectError('Variable field is absent from the reviewed source: ' + part[1])
            names.append(field['name'] + ('['+part[2]+']' if part[2] is not None else ''))
            dtype = self._indexed(field['type'], part[2])
        dtype = self._expand(dtype)
        expected = _SCALARS.get(dtype.upper())
        capacity = None
        string = re.fullmatch(r'(W?STRING)\s*\[\s*(\d+)\s*\]', dtype, re.I)
        if string:
            capacity = int(string[2])
            if not 1 <= capacity <= 4096:
                raise ProjectError('Source string exceeds the bounded monitor profile.')
            expected = 'utf8'
        elif dtype.upper() in ('STRING','WSTRING'):
            # Verified AXCF2152/2026 cold output represents bare STRING as IecString80.
            capacity,expected=80,'utf8'
        if expected is None:
            raise ProjectError('Only explicit finite primitive source fields are monitored; type=' + dtype)
        return {'symbol': '.'.join(names), 'path': COMPONENT + '.'.join(names),
            'declared_type': dtype, 'wire_type': expected, 'string_capacity': capacity,
            'source_identity_only': True}

    def describe(self):
        return {'programs': self.programs, 'roots': sorted(self.roots.values(), key=lambda x:x['name']),
            'types': [dict(name=value['name'], **({'fields':list(value['fields'].values())} if 'fields' in value else {'alias':value['alias']})) for value in self.types.values()],
            'pou_fields': {name:list(fields.values()) for name, fields in self.scopes.items()},
            'remote_existence_verified': False, 'remote_loaded_identity_verified': False,
            'secret_values_excluded': True, 'raw_address_access': False}


class RuntimeReadClient(TlsControllerClient):
    """A fixed DataAccess.Read / PlcInfo.ProjectName extension; never write/force."""
    def __init__(self, endpoint, allowed_paths, *, timeout_seconds=5, maximum_bytes=1048576, event_sink=None):
        super().__init__(endpoint, timeout_seconds=timeout_seconds, event_sink=event_sink)
        if (type(allowed_paths) not in (list, tuple, frozenset, set) or len(allowed_paths) > MAX_SYMBOLS+8
                or any(type(path) is not str or not path.startswith(COMPONENT) or len(path)>400 for path in allowed_paths)):
            raise ProjectError('Explicit source-resolved runtime paths are required.')
        if type(maximum_bytes) is not int or not 1024 <= maximum_bytes <= 1048576:
            raise ProjectError('Runtime session byte bound must be 1024..1048576.')
        self.allowed_paths, self.maximum_bytes = frozenset(allowed_paths), maximum_bytes

    def _receive(self, count):
        if self.bytes_received + count > self.maximum_bytes:
            self.broken = True
            raise ControllerFailure('monitor_byte_limit', 'Runtime observation exceeds its response byte budget.')
        return super()._receive(count)

    def _runtime_service(self, service):
        if service not in (DATA_ACCESS, PLC_INFO):
            raise ControllerFailure('runtime_service_denied', 'Only fixed runtime read services are admitted.')
        if service in self.handles:
            return self.handles[service]
        if not self.connected or self.broken:
            raise ControllerFailure('session_closed', 'No usable runtime controller session.')
        self._deadline()
        event = {'operation':'GetServiceHandles', 'service':service, 'mutating':False, 'response_received':False}
        self.trace.append(event)
        self._emit(event)
        self._send(tagged.encode_get_service(PROVIDER, service))
        header, raw = self._header()
        self._raise_remote_error(header)
        handles = tagged.decode_get_service_confirmation(raw)
        if handles in self.handles.values():
            raise ControllerFailure('duplicate_service_handle', 'Controller returned duplicate runtime service handles.')
        self.handles[service] = handles
        event['response_received'] = True
        self._emit(event)
        return handles

    def _runtime_call(self, service, method, paths=None):
        if (service, method) not in ((DATA_ACCESS,2),(PLC_INFO,1)):
            raise ControllerFailure('runtime_method_denied', 'Only Read and ProjectName GetInfo are admitted.')
        if service == DATA_ACCESS:
            if (type(paths) is not list or not 1 <= len(paths) <= MAX_CHUNK or len(set(paths)) != len(paths)
                    or any(path not in self.allowed_paths for path in paths)):
                raise ControllerFailure('runtime_path_denied', 'Runtime read paths/count differ from the exact source plan.')
            schemas, values = ['utf8[]'], [paths]
        else:
            schemas, values = ['int32'], [1]
        handle, provider = self._runtime_service(service)
        event = {'operation':'Invoke', 'service':service, 'method':method, 'mutating':False,
            'item_count':len(paths) if paths is not None else 1, 'send_attempted':False, 'response_received':False}
        self.trace.append(event)
        try:
            self._deadline()
            event['send_attempted'] = True
            self._emit(event)
            self._send(tagged.encode_request(handle, method, schemas, values, provider_handle=provider))
            header, _ = self._header()
            if (header.service_handle,header.service_provider_handle,header.method_handle)!=(handle,provider,method):
                raise ControllerFailure('response_mismatch', 'Runtime response dynamic handles differ from the request.')
            self._raise_remote_error(header)
            if header.command_type != CommandType.INVOKE_CONFIRMATION:
                raise ControllerFailure('unexpected_response', 'Expected runtime invocation confirmation.')
            result = (receive_read_items(self._receive, expected_count=len(paths)) if service==DATA_ACCESS
                      else receive_variant(self._receive))
            event['response_received'] = True
            self._emit(event)
            return result
        except Exception:
            self.broken = True
            raise

    def read_variables(self, paths):
        return self._runtime_call(DATA_ACCESS, 2, paths)

    def project_name(self):
        return self._runtime_call(PLC_INFO, 1)


def _source(store, project_id, expected_project_sha256):
    folder, manifest, members, _, _ = store._current(project_id)
    if manifest['current_sha256'] != expected_project_sha256:
        raise ProjectError('Stale project revision for runtime symbol review.')
    return folder, manifest, SourceSymbols(members)


def project_runtime_symbols(store, project_id, expected_project_sha256):
    _, _, model = _source(store,project_id,expected_project_sha256)
    return {'project_id':project_id, 'project_sha256':expected_project_sha256,
        'status':'source_symbols_available', 'controller_connected':False, **model.describe()}


def nativegateway_runtime_preset(model, *, point_count=250, include_samples=True, include_configuration=False):
    if type(point_count) is not int or not 1 <= point_count <= 320:
        raise ProjectError('NativeGateway point_count must be 1..320.')
    main = [program['name'] for program in model.programs if program['type']=='Main']
    if len(main)!=1:
        raise ProjectError('NativeGateway preset requires exactly one Main instance.')
    prefix=main[0]+'.'
    symbols=[prefix+x for x in ['Bootstrap.GatewayId','BootId','Active.Version','Active.DeviceCount','Active.PointCount','Active.enabled','Active.batchIntervalMs','Active.maxBatchPoints','TelemetryAllowed','QueueCount','Dropped']]
    symbols += ['HMI.'+x for x in ['Connection','ProtocolStatus','ReceivedConfigs','PublishedBatches','ConfirmedBatches','InvalidAcks']]
    if include_samples:
        symbols += [prefix+f'Samples[{i}].'+field for i in range(1,point_count+1) for field in ['Quality','Value','Timestamp']]
    if include_configuration:
        symbols += [prefix+f'Active.Points[{i}].'+field for i in range(1,point_count+1)
            for field in ['pointId','enabled','pollIntervalMs','reportIntervalMs']]
    return symbols


def prepare_runtime_read_plan(store, project_id, expected_project_sha256, address,
        expected_certificate_sha256, symbols=None, *, port=41100, chunk_size=64,
        timeout_seconds=5, maximum_bytes=1048576, minimum_interval_seconds=5,
        point_count=250, include_samples=True, include_configuration=False):
    folder, _, model = _source(store,project_id,expected_project_sha256)
    endpoint=ControllerEndpoint(address,port,expected_certificate_sha256)
    if symbols is None:
        symbols=nativegateway_runtime_preset(model,point_count=point_count,
            include_samples=include_samples,include_configuration=include_configuration)
    if (type(symbols) is not list or not 1<=len(symbols)<=MAX_SYMBOLS
            or any(type(s) is not str for s in symbols) or len(set(symbols))!=len(symbols)):
        raise ProjectError('Runtime symbols must be a unique list of 1..2048 explicit paths.')
    if type(chunk_size) is not int or not 1<=chunk_size<=64:
        raise ProjectError('Runtime chunk size must be 1..64.')
    if type(timeout_seconds) is not int or not 1<=timeout_seconds<=30:
        raise ProjectError('Runtime timeout must be 1..30 seconds.')
    if type(maximum_bytes) is not int or not 1024<=maximum_bytes<=1048576:
        raise ProjectError('Runtime total response budget must be 1024..1048576 bytes.')
    if type(minimum_interval_seconds) is not int or not 5<=minimum_interval_seconds<=3600:
        raise ProjectError('Runtime minimum interval must be 5..3600 seconds.')
    requests=[]
    for symbol in symbols:
        try:
            requests.append(model.resolve(symbol))
        except ProjectError as exc:
            requests.append({'symbol':symbol, 'status':'unsupported_source_symbol', 'reason':str(exc)})
    paths=[r['path'] for r in requests if 'path' in r]
    if len(set(paths)) != len(paths):
        raise ProjectError('Runtime aliases resolve to duplicate canonical paths.')
    guard_symbols=[]
    for program in model.programs:
        if program['type']=='Main':
            for field in ['BootId','Active.Version','Active.DeviceCount','Active.PointCount']:
                try:guard_symbols.append(model.resolve(program['name']+'.'+field))
                except ProjectError:pass
    plan_id=uuid.uuid4().hex
    plan={'schema':PLAN_SCHEMA,'created_utc':_utc(),'plan_id':plan_id,'project_id':project_id,
        'project_sha256':expected_project_sha256,'target':{'address':endpoint.address,'port':endpoint.port,
        'expected_certificate_sha256':endpoint.certificate_sha256},'requests':requests,'guards':guard_symbols,
        'limits':{'chunk_size':chunk_size,'timeout_seconds':timeout_seconds,'maximum_bytes':maximum_bytes,
        'minimum_interval_seconds':minimum_interval_seconds,'maximum_duration_seconds':30},
        'write_authorized':False,'remote_loaded_identity_verified':False,
        'consistency_claim':'window_observation_only_no_project_snapshot_sequence',
        'point_count_requested':point_count}
    plan['plan_sha256']=sha(_canonical(plan))
    directory=folder/'runtime-read-plans'/plan_id
    directory.mkdir(parents=True,exist_ok=False)
    path=directory/'plan.json';path.write_bytes(_canonical(plan)+b'\n')
    return plan|{'plan_path':str(path),'controller_connected':False}


def load_runtime_read_plan(store,project_id,plan_id,expected_plan_sha256):
    if type(plan_id) is not str or re.fullmatch('[0-9a-f]{32}',plan_id) is None:
        raise ProjectError('Invalid runtime read plan ID.')
    path=store._folder(project_id)/'runtime-read-plans'/plan_id/'plan.json'
    if not path.is_file() or path.stat().st_size>2*1024*1024:
        raise ProjectError('Missing or oversized runtime read plan.')
    plan=json.loads(path.read_text(encoding='utf-8'))
    unsigned={k:v for k,v in plan.items() if k!='plan_sha256'}
    if (plan.get('schema')!=PLAN_SCHEMA or plan.get('plan_id')!=plan_id or plan.get('project_id')!=project_id
            or plan.get('plan_sha256')!=expected_plan_sha256 or sha(_canonical(unsigned))!=expected_plan_sha256):
        raise ProjectError('Runtime read plan identity/hash mismatch.')
    limits=plan.get('limits',{})
    bounded={'chunk_size':(1,64),'timeout_seconds':(1,30),'maximum_bytes':(1024,1048576),
        'minimum_interval_seconds':(5,3600),'maximum_duration_seconds':(1,30)}
    if (set(limits)!=set(bounded) or any(type(limits[k]) is not int or not lo<=limits[k]<=hi
            for k,(lo,hi) in bounded.items()) or type(plan.get('requests')) is not list
            or not 1<=len(plan['requests'])<=MAX_SYMBOLS or type(plan.get('guards')) is not list
            or len(plan['guards'])>8):
        raise ProjectError('Runtime read plan limits are invalid.')
    target=plan.get('target',{})
    if set(target)!={'address','port','expected_certificate_sha256'}:
        raise ProjectError('Runtime read plan target is invalid.')
    ControllerEndpoint(target['address'],target['port'],target['expected_certificate_sha256'])
    _, _, model=_source(store,project_id,plan['project_sha256'])
    for request in [*plan['requests'],*plan['guards']]:
        if 'path' in request and request!=model.resolve(request['symbol']):
            raise ProjectError('Runtime source symbol binding changed.')
    return plan


def _checked_rows(descriptors, rows, observed_utc):
    if len(descriptors)!=len(rows):
        raise ControllerFailure('monitor_partial_response','Runtime response count mismatch.')
    output=[]
    for descriptor,row in zip(descriptors,rows):
        item=dict(descriptor,**row,observed_utc=observed_utc,
            observation_time_source='host_response_received_utc',source='device_rsc_data_access')
        if row['error_code']!=0:
            item.update(status='device_read_error',value=None)
        elif row['wire_type']!=descriptor['wire_type']:
            item.update(status='type_mismatch',value=None,expected_wire_type=descriptor['wire_type'])
        elif row['wire_type']=='utf8' and len(row['value'])>descriptor['string_capacity']:
            item.update(status='source_string_capacity_exceeded',value=None)
        else:
            item['status']='read'
        output.append(item)
    return output


def observe_runtime_plan(client,plan,*,cancel=None):
    """Finite injected-client observation; no polling loop or mutation capability."""
    limits=plan['limits'];start=time.monotonic();client.overall_end=start+limits['maximum_duration_seconds']
    report={'schema':'plcnext-runtime-observation/v1','created_utc':_utc(),'status':'monitor_failed',
        'plan_id':plan['plan_id'],'plan_sha256':plan['plan_sha256'],'project_id':plan['project_id'],
        'source_project_sha256':plan['project_sha256'],'source_identity_only':True,'target':plan['target'],
        'read_only':True,'control_requests_sent':False,'write_requests_sent':False,'force_requests_sent':False,
        'requested_count':len(plan['requests']),'items':[dict(d,value=None,
            status=d.get('status','not_observed'),source='reviewed_source',observed_utc=None)
            for d in plan['requests']], 'atomic_snapshot':False,
        'consistency':'unknown','loaded_identity':{'status':'unknown','package_sha256':None,
        'reason':'ProjectName, source symbols and disk manifests do not attest the memory-loaded image.'},
        'limits':limits,'automatic_retry':False,'controller_connected':False,
        'host_monotonic_clock_domain':'this_observation_only:'+uuid.uuid4().hex,
        'started_monotonic_ns':time.monotonic_ns(),'batch_windows':[],
        'monitoring_impact_on_plc_task_verified':False}
    observed_by={}
    def read(descriptors,publish=False):
        output=[]
        for at in range(0,len(descriptors),limits['chunk_size']):
            if cancel is not None and cancel():
                raise ControllerFailure('monitor_cancelled','Runtime observation cancelled before next read.')
            if time.monotonic()-start>limits['maximum_duration_seconds']:
                raise ControllerFailure('monitor_timeout','Runtime observation window expired.')
            chunk=descriptors[at:at+limits['chunk_size']]
            batch_start=time.monotonic_ns()
            rows=client.read_variables([d['path'] for d in chunk])
            batch_end=time.monotonic_ns()
            checked=_checked_rows(chunk,rows,_utc())
            window={'started_monotonic_ns':batch_start,'response_received_monotonic_ns':batch_end,
                'item_count':len(chunk),'purpose':'requested_values' if publish else 'identity_guards'}
            report['batch_windows'].append(window)
            for item in checked:
                item.update(observed_monotonic_ns=batch_end,window_started_monotonic_ns=batch_start,
                    monotonic_clock_domain=report['host_monotonic_clock_domain'])
            output.extend(checked)
            if publish:
                observed_by.update({item['symbol']:item for item in checked})
                report['items']=[observed_by.get(item['symbol'],item) for item in report['items']]
        return output
    try:
        client.connect();report['controller_connected']=True
        report['plc_state_before']=client.get_state()
        name=client.project_name()
        report['project_name_observation']={'value':name['value'] if name['wire_type']=='utf8' else None,
            'wire_type':name['wire_type'],'source':'device_plc_info','observed_utc':_utc(),
            'loaded_package_identity_verified':False}
        before=read(plan['guards']);report['guards_before']=before
        valid=[d for d in plan['requests'] if 'path' in d]
        observed=read(valid,publish=True)
        by={item['symbol']:item for item in observed}
        report['items']=[by[d['symbol']] if 'path' in d else dict(d,value=None,
            source='reviewed_source',observed_utc=None) for d in plan['requests']]
        after=read(plan['guards']);report['guards_after']=after
        report['plc_state_after']=client.get_state()
        complete=bool(before) and all(x['status']=='read' for x in [*before,*after])
        changed=complete and any((x['symbol'],x['value'])!=(y['symbol'],y['value']) for x,y in zip(before,after))
        changed=changed or report['plc_state_before']!=report['plc_state_after']
        if changed:
            report.update(status='snapshot_invalidated',consistency='identity_changed_during_window')
        else:
            report.update(status='monitor_read_completed' if all(x['status']=='read' for x in report['items']) else 'monitor_read_partial',
                consistency='guarded_window_observation' if complete else 'unguarded_window_observation')
        report['configuration_digest']=None
        config=[{'symbol':x['symbol'],'declared_type':x['declared_type'],'value':x['value']}
            for x in report['items'] if '.Active.' in x['symbol'] and x['status']=='read']
        if config and not changed:
            report['configuration_digest']={'sha256':sha(_canonical(config)),'field_count':len(config),
                'scope':'only_returned_active_fields','full_sampling_configuration_verified':False}
        qualities=[x for x in report['items'] if re.fullmatch(r'.+\.Samples\[\d+\]\.Quality',x['symbol'])]
        report['quality_coverage']={'requested':len(qualities),'read':sum(x['status']=='read' for x in qualities),
            'good':sum(x['status']=='read' and x['value']=='GOOD' for x in qualities),
            'all_requested_good':bool(qualities) and all(x['status']=='read' and x['value']=='GOOD' for x in qualities)
                and not changed,'atomic_snapshot':False}
        expected_points=plan.get('point_count_requested')
        indices=[int(re.search(r'\.Samples\[(\d+)\]\.Quality$',x['symbol'])[1]) for x in qualities]
        report['quality_coverage'].update(expected_point_count=expected_points,
            complete_expected_point_coverage=type(expected_points) is int and sorted(indices)==list(range(1,expected_points+1)))
    except Exception as exc:
        report.update(status='monitor_failed',failure_code=getattr(exc,'code','monitor_transport_or_codec_error'),
            error_class=type(exc).__name__)
    finally:
        report['cleanup_error_class']=client.close()
        if report['cleanup_error_class'] is not None and report['status']!='monitor_failed':
            report.update(status='monitor_failed',failure_code='monitor_cleanup_failed')
        report.update(finished_utc=_utc(),duration_seconds=time.monotonic()-start,
            finished_monotonic_ns=time.monotonic_ns(),
            bytes_received=client.bytes_received,bytes_sent=client.bytes_sent,
            network_operation_count=len(client.trace),trace=client.trace)
    return report


def read_runtime_plan(store,project_id,plan_id,expected_plan_sha256,*,client_factory=None):
    plan=load_runtime_read_plan(store,project_id,plan_id,expected_plan_sha256)
    endpoint=ControllerEndpoint(plan['target']['address'],plan['target']['port'],plan['target']['expected_certificate_sha256'])
    # One endpoint rate/parallel bound across processes and workspaces of this OS user.
    root=Path.home()/'.plcnext-mcp'/'runtime-monitor-endpoints';root.mkdir(parents=True,exist_ok=True)
    key=sha((endpoint.address+':'+str(endpoint.port)).encode('ascii'))
    lock=root/(key+'.lock');stamp=root/(key+'.json')
    try:descriptor=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    except FileExistsError as exc:raise ControllerFailure('monitor_endpoint_busy','Another observation owns this endpoint; no automatic lock removal.') from exc
    try:
        with os.fdopen(descriptor,'w',encoding='utf-8') as stream:
            stream.write(json.dumps({'plan_id':plan_id,'created_utc':_utc()}));stream.flush();os.fsync(stream.fileno())
        now=time.time()
        if stamp.is_file():
            previous=json.loads(stamp.read_text(encoding='utf-8'))
            if now-previous['started_unix']<max(previous.get('minimum_interval_seconds',5),plan['limits']['minimum_interval_seconds']):
                raise ControllerFailure('monitor_rate_limit','Runtime endpoint minimum observation interval has not elapsed.')
        stamp.write_text(json.dumps({'started_unix':now,'minimum_interval_seconds':plan['limits']['minimum_interval_seconds']}),encoding='utf-8')
        paths=sorted({x['path'] for x in [*plan['requests'],*plan['guards']] if 'path' in x})
        factory=client_factory or RuntimeReadClient
        client=factory(endpoint,paths,timeout_seconds=plan['limits']['timeout_seconds'],maximum_bytes=plan['limits']['maximum_bytes'])
        directory=store._folder(project_id)/'runtime-observations'/uuid.uuid4().hex
        directory.mkdir(parents=True,exist_ok=False)
        result=observe_runtime_plan(client,plan)
        try:load_runtime_read_plan(store,project_id,plan_id,expected_plan_sha256)
        except ProjectError:
            result.update(status='snapshot_invalidated',consistency='source_binding_changed_during_window')
        path=directory/'result.json';result.update(report_path=str(path),observation_id=directory.name)
        result['observation_sha256']=sha(_canonical(result))
        path.write_bytes(_canonical(result)+b'\n')
        return result
    finally:
        lock.unlink(missing_ok=True)


def test_runtime_monitor(store,project_id,expected_project_sha256,*,fault='none',point_count=250):
    """Exercise only an owned 127.0.0.1 TLS peer with synthetic source-typed values."""
    from .runtime_test_peer import LocalRuntimeController, FAULTS
    if fault not in FAULTS:
        raise ProjectError('Unsupported loopback runtime fault.')
    folder,_,model=_source(store,project_id,expected_project_sha256)
    symbols=nativegateway_runtime_preset(model,point_count=point_count)
    values={}
    for symbol in symbols:
        try:descriptor=model.resolve(symbol)
        except ProjectError:continue
        dtype=descriptor['wire_type']
        if dtype=='utf8':
            value=('GOOD' if symbol.endswith('.Quality') else 'fixture-boot-1' if symbol.endswith('.BootId') else 'fixture')
        elif dtype=='bool':value=True
        elif symbol.endswith('.Active.Version'):value=13
        elif symbol.endswith('.Active.DeviceCount'):value=50
        elif symbol.endswith('.Active.PointCount'):value=point_count
        elif dtype.startswith('float'):value=230.1
        else:value=1
        values[descriptor['path']]={'wire_type':dtype,'value':value}
    directory=folder/'runtime-read-tests'/uuid.uuid4().hex
    directory.mkdir(parents=True,exist_ok=False)
    with LocalRuntimeController(directory/'peer',values,fault=fault) as peer:
        plan=prepare_runtime_read_plan(store,project_id,expected_project_sha256,peer.address,
            peer.certificate_sha256,symbols=symbols,port=peer.port,point_count=point_count)
        endpoint=ControllerEndpoint(peer.address,peer.port,peer.certificate_sha256)
        client=RuntimeReadClient(endpoint,list(values))
        result=observe_runtime_plan(client,plan)
        result.update(evidence_environment='loopback_fixture',real_controller_connected=False,
            fault=fault,fixture_errors=peer.errors,fixture_trace=peer.trace)
        for item in result['items']:
            if item.get('source')=='device_rsc_data_access':item['source']='loopback_rsc_data_access'
        expected={'none':'monitor_read_completed','bad_quality':'monitor_read_completed',
            'missing_field':'monitor_read_partial','wrong_type':'monitor_read_partial',
            'short_results':'monitor_failed','boot_change':'snapshot_invalidated',
            'config_change':'snapshot_invalidated','disconnect':'monitor_failed','oversized_string':'monitor_failed'}[fault]
        result['expected_status']=expected
        result['test_passed']=result['status']==expected
        if fault=='none':
            result['test_passed'] &= result['quality_coverage']['all_requested_good'] and result['quality_coverage']['complete_expected_point_coverage']
        if fault=='bad_quality':result['test_passed'] &= not result['quality_coverage']['all_requested_good']
    path=directory/'result.json';result.update(report_path=str(path),observation_id=directory.name)
    result['observation_sha256']=sha(_canonical(result))
    path.write_bytes(_canonical(result)+b'\n')
    return result
