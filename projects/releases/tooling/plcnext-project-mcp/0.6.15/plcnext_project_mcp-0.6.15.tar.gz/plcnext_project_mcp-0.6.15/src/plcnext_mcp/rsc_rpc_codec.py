"""Bounded RSC v4 RPC messages measured with original pure formatters.

Only untagged/no-datagram, one schema-delimited invocation per exchange. No
socket or generic stream framing. The original v4 invoke DataLength is zero;
the method schema, not that field, determines the body boundary.
"""
from __future__ import annotations

import struct

from .rsc_codec import (CommandHeader, CommandType, SECURE, DATAGRAMMING,
                        DATA_TAGGING, encode_header, decode_header)

MAX_PACKET_BYTES = 128 * 1024 * 1024


def _integer(value, lo, hi):
    if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
        raise ValueError('Invalid bounded RPC integer.')
    return value


def _packet(data):
    if type(data) is not bytes or not 16 <= len(data) <= MAX_PACKET_BYTES:
        raise ValueError('Invalid bounded RPC packet size.')
    length = 20 if data[1] & SECURE else 16
    header, token = decode_header(data[:length], require_checksum=True)
    if header.version != 4:
        raise ValueError('Only the measured RSC version 4 profile is supported.')
    return header, token, data[length:]


def _invoke(service_handle, method_handle, payload, token, provider_handle, command):
    for value in (service_handle, method_handle):
        _integer(value, 1, 32767)
    _integer(provider_handle, 0, 32767)
    if type(payload) is not bytes or len(payload) > MAX_PACKET_BYTES - 20:
        raise ValueError('Invalid bounded RPC payload.')
    return encode_header(CommandHeader(command_type=command, service_handle=service_handle,
        method_handle=method_handle, service_provider_handle=provider_handle), token) + payload


def encode_request(service_handle: int, method_handle: int, payload: bytes,
                   token: int | None = None, provider_handle: int = 0) -> bytes:
    return _invoke(service_handle, method_handle, payload, token, provider_handle, CommandType.INVOKE_REQUEST)


def encode_response(service_handle: int, method_handle: int, payload: bytes,
                    token: int | None = None, provider_handle: int = 0) -> bytes:
    return _invoke(service_handle, method_handle, payload, token, provider_handle, CommandType.INVOKE_CONFIRMATION)


def _decode_invoke(data, commands):
    header, token, payload = _packet(data)
    if (header.command_type not in commands or header.flags & ~SECURE or header.data_length != 0
            or min(header.service_handle, header.method_handle) <= 0 or header.service_provider_handle < 0):
        raise ValueError('Unsupported RSC invocation profile/header.')
    return header, token, payload


def decode_request(data: bytes) -> tuple[CommandHeader, int | None, bytes]:
    return _decode_invoke(data, (CommandType.INVOKE_REQUEST,))


def decode_response(data: bytes) -> tuple[CommandHeader, int | None, bytes]:
    return _decode_invoke(data, (CommandType.INVOKE_CONFIRMATION, CommandType.ERROR))


def encode_connect_request() -> bytes:
    # Original ConnectCommand advertises these capabilities; the bounded peer
    # must confirm flags=0. A flag-bearing confirmation is rejected below.
    return encode_header(CommandHeader(flags=DATAGRAMMING | DATA_TAGGING, command_type=7))


def encode_connect_confirmation() -> bytes:
    return encode_header(CommandHeader(command_type=8))


def decode_connect(data: bytes, confirmation: bool = False) -> CommandHeader:
    header, token, payload = _packet(data)
    if (token is not None or payload or header.command_type != (8 if confirmation else 7)
            or header.flags != (0 if confirmation else DATAGRAMMING | DATA_TAGGING)
            or any((header.data_length, header.service_handle, header.method_handle, header.service_provider_handle))):
        raise ValueError('Unsupported RSC connect negotiation profile.')
    return header


def _ascii_name(value):
    if type(value) is not str or not value or not value.isascii() or '\x00' in value or len(value) > 1024:
        raise ValueError('Only bounded ASCII service/provider names are supported.')
    raw = value.encode('ascii') + b'\x00'
    return struct.pack('<H', len(raw)) + raw


def _read_string(data, offset, *, encoding='utf-8', maximum=65535):
    if offset + 2 > len(data):
        raise ValueError('Truncated RSC string prefix.')
    length = struct.unpack_from('<H', data, offset)[0]
    nul = b'\x00\x00' if encoding == 'utf-16-le' else b'\x00'
    if length < len(nul) or length > maximum or offset + 2 + length > len(data):
        raise ValueError('Invalid RSC string length.')
    raw = data[offset + 2:offset + 2 + length]
    if not raw.endswith(nul):
        raise ValueError('RSC string lacks terminator.')
    try:
        result = raw[:-len(nul)].decode(encoding, errors='strict')
    except UnicodeError as exc:
        raise ValueError('Invalid RSC string encoding.') from exc
    if '\x00' in result:
        raise ValueError('Embedded NUL in bounded RSC string.')
    return result, offset + 2 + length


def encode_get_service(provider_name: str, service_name: str) -> bytes:
    body = _ascii_name(provider_name) + _ascii_name(service_name)
    return encode_header(CommandHeader(command_type=15, data_length=len(body))) + body


def decode_get_service(data: bytes) -> tuple[str, str]:
    header, token, body = _packet(data)
    if (header.command_type != 15 or header.flags or token is not None or header.data_length != len(body)
            or any((header.service_handle, header.method_handle, header.service_provider_handle))):
        raise ValueError('Unsupported RSC service discovery request.')
    provider, offset = _read_string(body, 0, encoding='ascii', maximum=1025)
    service, offset = _read_string(body, offset, encoding='ascii', maximum=1025)
    if not provider or not service or offset != len(body):
        raise ValueError('Incomplete or trailing service discovery data.')
    return provider, service


def encode_get_service_confirmation(service_handle: int, provider_handle: int) -> bytes:
    _integer(service_handle, 1, 32767)
    _integer(provider_handle, 1, 32767)
    return encode_header(CommandHeader(command_type=16, service_handle=service_handle,
                                        service_provider_handle=provider_handle))


def decode_get_service_confirmation(data: bytes) -> tuple[int, int]:
    header, token, body = _packet(data)
    if (header.command_type != 16 or header.flags or token is not None or body or header.data_length
            or header.method_handle or min(header.service_handle, header.service_provider_handle) <= 0):
        raise ValueError('Unsupported RSC service discovery confirmation.')
    return header.service_handle, header.service_provider_handle


def _utf8_value(value, maximum):
    if type(value) is not str or '\x00' in value:
        raise ValueError('Invalid synthetic authentication string.')
    try:
        raw = value.encode('utf-8') + b'\x00'
    except UnicodeError as exc:
        raise ValueError('Invalid UTF8 authentication string.') from exc
    if len(raw) > maximum:
        raise ValueError('Authentication string exceeds the bounded service annotation.')
    return struct.pack('<H', len(raw)) + raw


def encode_create_session(username: str, password: str) -> bytes:
    # Actual RemotingProxy.Init/GetMarshalType(attrs) select UTF8 (2) for these
    # original parameter annotations; SecureString also emits UTF8.
    return _utf8_value(username, 64) + _utf8_value(password, 128)


def decode_create_session(data: bytes) -> tuple[str, str]:
    username, offset = _read_string(data, 0, maximum=64)
    password, offset = _read_string(data, offset, maximum=128)
    if offset != len(data):
        raise ValueError('Trailing authentication parameter bytes.')
    return username, password


def encode_close_session(token: int) -> bytes:
    return b'\x09' + struct.pack('<I', _integer(token, 0, 0xffffffff))


def decode_close_session(data: bytes) -> int:
    if type(data) is not bytes or len(data) != 5 or data[0] != 9:
        raise ValueError('Unsupported SecurityToken Object-field value encoding.')
    return struct.unpack('<I', data[1:])[0]


def encode_create_session_result(token: int, penalty_ms: int, error: int) -> bytes:
    _integer(penalty_ms, 0, 2147483647)
    _integer(error, -6, 0)
    return encode_close_session(token) + struct.pack('<ii', penalty_ms, error)


def decode_create_session_result(data: bytes) -> tuple[int, int, int]:
    if type(data) is not bytes or len(data) != 13:
        raise ValueError('Unsupported authentication OUT/return body.')
    token = decode_close_session(data[:5])
    penalty_ms, error = struct.unpack('<ii', data[5:])
    _integer(penalty_ms, 0, 2147483647)
    _integer(error, -6, 0)
    return token, penalty_ms, error


def encode_server_error(service_handle: int, method_handle: int, code: int, message: str,
                        provider_handle: int = 0) -> bytes:
    _integer(code, 0, 0x7fffffff)
    if type(message) is not str or '\x00' in message:
        raise ValueError('Invalid bounded server error string.')
    text = message.encode('utf-8') + b'\x00'
    if len(text) > 4096:
        raise ValueError('Oversized bounded server error string.')
    # Original untagged ReadError2 oracle confirms MarshalType 1 is UTF8 in
    # this .NET 8 build. The earlier hand-constructed UTF16 error fixture was wrong.
    # Only the measured empty argument array is supported.
    body = struct.pack('<IH', code, len(text)) + text + struct.pack('<i', 0)
    return _invoke(service_handle, method_handle, body, None, provider_handle, CommandType.ERROR)


def decode_server_error(data: bytes) -> tuple[int, str]:
    header, _, body = decode_response(data)
    if header.command_type != CommandType.ERROR or len(body) < 11:
        raise ValueError('Not a bounded RSC server error.')
    code = struct.unpack_from('<I', body)[0]
    _integer(code, 0, 0x7fffffff)
    message, offset = _read_string(body, 4, encoding='utf-8', maximum=4096)
    if body[offset:] != b'\x00\x00\x00\x00':
        raise ValueError('Only empty server exception argument arrays are supported.')
    return code, message
