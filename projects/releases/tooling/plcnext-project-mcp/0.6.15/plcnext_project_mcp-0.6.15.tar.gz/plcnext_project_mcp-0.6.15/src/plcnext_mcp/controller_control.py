"""Exact reviewed Stop/Start; independent of ACI, GUI and file-write approval.

The default transport admits only state reads. This module's separate capability
admits ONE Stop or Start request, never Reset/Load/file/variable methods. Human
receipts are consumed, not issued here. A callback for Start must establish the
loaded inventory from device evidence or a coherent verified-load operation;
local filenames and remote manifest declarations alone are insufficient.
"""
from __future__ import annotations

from datetime import datetime, timezone
import ipaddress
import json
import os
from pathlib import Path
import re
import time
import uuid

from . import rsc_tagged_codec as tagged
from .controller_download_plan import (_binding, _digest, _sha256, _strict_json,
                                       _target, MAX_REVIEW_BYTES)
from .controller_transport import (ControllerEndpoint, ControllerFailure, PLC,
                                   RemoteControllerError, TlsControllerClient)
from .controller_transfer import (_claim_endpoint_lease, _journal_sink, _persist_result)
from .deployment_plan import _file
from .project import ProjectError, sha
from .rsc_codec import CommandType
from .rsc_error_codec import receive_error
from .rsc_start_control import start_kind_value
from .plc_state import HOT, METADATA, BUSY, stable_state

REVIEW_SCHEMA = 'plcnext-controller-control-review/v1'
APPROVAL_SCHEMA = 'plcnext-controller-control-operator-approval/v1'
_CONTROL_AUTHORITY = object()
_ACTIONS = {'stop': (3, 2), 'start': (2, 3)}
_CONTROL_SCHEMAS = {2: (['byte', 'bool'], []), 3: (['bool'], []), 5: ([], ['uint32'])}
_LOADED_IDENTITY_SOURCES = frozenset(('device_loaded_module_hash', 'same_plan_verified_load'))


def _policy(action, start_kind, timeout_seconds, expected_initial_state, plan_id):
    if type(action) is not str or action not in _ACTIONS:
        raise ProjectError('Control action must be stop or start.')
    if type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 300:
        raise ProjectError('Control timeout must be an integer 1..300 seconds.')
    if expected_initial_state is None:
        expected_initial_state = _ACTIONS[action][0]
    admitted = (2, 3) if action == 'stop' else (2,)
    if type(expected_initial_state) is not int or not any(stable_state(expected_initial_state, base) for base in admitted):
        raise ProjectError('Control review has an unsupported exact initial state.')
    if action == 'start':
        start_kind_value(start_kind)
    elif start_kind is not None:
        raise ProjectError('Stop does not take a start kind.')
    if plan_id is not None and (type(plan_id) is not str or re.fullmatch('[0-9a-f]{32}', plan_id) is None):
        raise ProjectError('Control plan ID must be a 32-digit lowercase hex identity.')
    return {'action': action, 'expected_initial_state_raw': expected_initial_state,
            'required_terminal_state_raw': _ACTIONS[action][1], 'start_kind': start_kind,
            'timeout_seconds': timeout_seconds, 'plan_id': plan_id,
            'authentication_mode': 'anonymous', 'automatic_retry': False,
            'automatic_rollback': False, 'automatic_inverse_action': False,
            'loaded_inventory_verification_required': action == 'start'}


def _impact(action):
    return {'program_execution_interrupted': action == 'stop',
            'program_execution_started': action == 'start',
            'physical_output_and_hold_behavior_verified': False,
            'running_is_not_collection_verification': True,
            'reply_loss_requires_readonly_reconciliation': True,
            'no_file_or_variable_write_authorized': True}


def prepare_control_review(store, project_id: str, expected_project_sha256: str,
                           package_job_id: str, address: str,
                           expected_certificate_sha256: str, action: str,
                           port: int = 41100, start_kind: str | None = None,
                           timeout_seconds: int = 30,
                           expected_initial_state: int | None = None,
                           plan_id: str | None = None) -> dict:
    """Local immutable control review; never connect or issue approval."""
    target = _target(address, expected_certificate_sha256, port)
    _sha256(expected_project_sha256, 'project hash')
    policy = _policy(action, start_kind, timeout_seconds, expected_initial_state, plan_id)
    folder = store._folder(project_id)
    with store._lock(folder):
        _, _, binding, _ = _binding(store, project_id, expected_project_sha256, package_job_id)
        review_id = uuid.uuid4().hex
        directory = _file(folder, 'controller-control-reviews/' + review_id)
        directory.mkdir(parents=True, exist_ok=False)
        review = {'schema': REVIEW_SCHEMA, 'review_id': review_id, 'project_id': project_id,
            'created_utc': datetime.now(timezone.utc).isoformat(), 'target': target,
            **binding, 'policy': policy, 'approved_actions': [action],
            'status': 'control_review_prepared', 'authorization_status': 'awaiting_mcp_authorization',
            'write_authorized': False, 'requires_user_confirmation': False,
            'controller_connected': False, 'action_sent': False,
            'aci_used': False, 'computer_use_used': False,
            'impact': _impact(action),
            'execution_blockers': ['exact_mcp_or_operator_authorization_required',
                'fresh_exact_initial_state_required',
                *(['loaded_package_identity_must_be_verified'] if action == 'start' else [])]}
        review['review_sha256'] = _digest(review)
        path = directory / 'review.json'
        path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return {**review, 'review_path': str(path)}


def load_control_review(store, project_id, review_id, expected_review_sha256):
    _sha256(expected_review_sha256, 'control review hash')
    if type(review_id) is not str or re.fullmatch('[0-9a-f]{32}', review_id) is None:
        raise ProjectError('Invalid control review ID.')
    path = _file(store._folder(project_id), 'controller-control-reviews/' + review_id + '/review.json')
    if not path.is_file() or path.stat().st_size > MAX_REVIEW_BYTES:
        raise ProjectError('Missing or oversized control review.')
    raw = path.read_bytes()
    if len(raw) > MAX_REVIEW_BYTES:
        raise ProjectError('Oversized control review.')
    review = _strict_json(raw)
    if (type(review) is not dict or review.get('schema') != REVIEW_SCHEMA
            or review.get('project_id') != project_id or review.get('review_id') != review_id
            or review.get('review_sha256') != expected_review_sha256
            or _digest(review) != expected_review_sha256
            or review.get('write_authorized') is not False
            or (review.get('authorization_status'), review.get('requires_user_confirmation')) not in
                (('awaiting_mcp_authorization', False), ('awaiting_user_confirmation', True))):
        raise ProjectError('Control review identity or digest is invalid.')
    policy = review['policy']
    if policy != _policy(policy['action'], policy['start_kind'], policy['timeout_seconds'],
                         policy['expected_initial_state_raw'], policy['plan_id']):
        raise ProjectError('Control policy changed or contains unknown fields.')
    target = review['target']
    if target != _target(target['address'], target['expected_certificate_sha256'], target['port']):
        raise ProjectError('Control endpoint policy changed.')
    if review.get('approved_actions') != [policy['action']]:
        raise ProjectError('Control action list differs from the exact policy.')
    if review.get('impact') != _impact(policy['action']):
        raise ProjectError('Control impact or confirmation policy changed.')
    return review


def revalidate_control_review(store, project_id, review_id, expected_review_sha256):
    review = load_control_review(store, project_id, review_id, expected_review_sha256)
    _, _, binding, _ = _binding(store, project_id, review['source']['project_sha256'],
                               review['package']['package_job_id'])
    if any(review.get(name) != value for name, value in binding.items()):
        raise ProjectError('Control source/build/package bytes changed since review.')
    return review


def approval_contract(store, project_id, review_id, expected_review_sha256):
    from .operator_approval import OperatorApprovalContract
    review = revalidate_control_review(store, project_id, review_id, expected_review_sha256)
    return OperatorApprovalContract(kind='control', review_sha256=expected_review_sha256,
        receipt_schema=APPROVAL_SCHEMA, approval_directory='controller-control-approvals',
        binding_fields=_approval_bindings(review),
        display={key: review[key] for key in ('review_id', 'project_id', 'target', 'source',
                                             'package', 'policy', 'impact')})


def _approval_bindings(review):
    return {'target': review['target'], 'project_sha256': review['source']['project_sha256'],
            'inventory_sha256': review['package']['inventory_sha256'],
            'policy': review['policy'], 'approved_actions': review['approved_actions']}


class ControlScope:
    """Private action capability, separate from download/file capabilities."""
    def __init__(self, review, kind, *, authority=None):
        if authority is not _CONTROL_AUTHORITY or kind not in ('operator_confirmed', 'mcp_authorized', 'loopback_fixture'):
            raise ProjectError('A control review is not control permission.')
        target = review['target']
        self.endpoint = ControllerEndpoint(target['address'], target['port'], target['expected_certificate_sha256'])
        if kind == 'loopback_fixture' and not ipaddress.ip_address(self.endpoint.address).is_loopback:
            raise ProjectError('Control fixture scope only admits literal loopback.')
        self.kind, self.review_sha256, self.policy = kind, review['review_sha256'], dict(review['policy'])
        self.inventory_sha256 = review['package']['inventory_sha256']
        self.project_sha256 = review['source']['project_sha256']
        self.request_attempted = False

    @classmethod
    def loopback_fixture(cls, review):
        return cls(review, 'loopback_fixture', authority=_CONTROL_AUTHORITY)


def _consume_control_approval(store, review, execution_id):
    from .operator_approval import OperatorApprovalContract, validate_operator_receipt
    path = _file(store.root, 'controller-control-approvals/' + review['review_sha256'] + '.json')
    if path.with_suffix('.revoked.json').exists():
        raise ControllerFailure('approval_revoked', 'Control approval was revoked.')
    if path.with_suffix('.denied.json').exists():
        raise ControllerFailure('approval_denied', 'Control approval was denied.')
    if not path.is_file() or path.stat().st_size > 64 * 1024:
        raise ControllerFailure('user_confirmation_required', 'No separate exact control approval exists.')
    raw = path.read_bytes()
    if len(raw) > 64 * 1024:
        raise ControllerFailure('user_confirmation_required', 'Oversized control approval.')
    record = _strict_json(raw)
    contract = OperatorApprovalContract(kind='control', review_sha256=review['review_sha256'],
        receipt_schema=APPROVAL_SCHEMA, approval_directory='controller-control-approvals',
        binding_fields=_approval_bindings(review), display={})
    if record.get('confirmed_by') == 'mcp_policy':
        contract = approval_contract(store, review['project_id'], review['review_id'], review['review_sha256'])
    validate_operator_receipt(record, contract)
    now = datetime.now(timezone.utc)
    claim = path.with_suffix('.claimed.json')
    try:
        fd = os.open(claim, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise ControllerFailure('approval_already_consumed', 'Control approval was already claimed; do not retry.') from exc
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        json.dump({'review_sha256': review['review_sha256'], 'execution_id': execution_id,
                   'claimed_utc': now.isoformat(), 'approval_sha256': sha(raw)}, stream)
        stream.flush(); os.fsync(stream.fileno())
    if path.read_bytes() != raw or path.with_suffix('.revoked.json').exists() or path.with_suffix('.denied.json').exists():
        raise ControllerFailure('approval_changed', 'Control approval changed while claiming.')
    return ControlScope(review, 'mcp_authorized' if record['confirmed_by'] == 'mcp_policy' else 'operator_confirmed', authority=_CONTROL_AUTHORITY)


class ControllerControlClient(TlsControllerClient):
    """Only PLC GetState + one exact approved Start/Stop; no file/session APIs."""
    def __init__(self, endpoint, *, control_scope, timeout_seconds=10, event_sink=None):
        if not isinstance(control_scope, ControlScope) or control_scope.endpoint != endpoint:
            raise ProjectError('Exact control scope required.')
        super().__init__(endpoint, timeout_seconds=timeout_seconds, event_sink=event_sink)
        self.control_scope = control_scope

    def _service(self, service):
        if service != PLC:
            raise ControllerFailure('control_scope_violation', 'Control session admits only the PLC manager service.')
        return super()._service(service)

    def _call(self, service, method, values, *, omit_header_token=False):
        if service != PLC or method not in _CONTROL_SCHEMAS or type(values) is not list or omit_header_token:
            raise ControllerFailure('control_scope_violation', 'Unknown control request or schema.')
        policy = self.control_scope.policy
        if method == 5:
            expected = []
        else:
            action = 'start' if method == 2 else 'stop'
            if action != policy['action'] or self.control_scope.request_attempted:
                raise ControllerFailure('control_scope_violation', 'Only one exact reviewed control action is admitted.')
            expected = [start_kind_value(policy['start_kind']), True] if method == 2 else [True]
        if values != expected or not self.connected or self.broken:
            raise ControllerFailure('control_scope_violation', 'Control values or session differ from review.')
        schema = _CONTROL_SCHEMAS[method]
        handle, provider = self._service(PLC)
        packet = tagged.encode_request(handle, method, schema[0], values, provider_handle=provider)
        self._deadline()
        event = {'operation': 'Invoke', 'service': PLC, 'method': method, 'mutating': method != 5,
                 'send_attempted': False, 'response_received': False}
        self.trace.append(event)
        try:
            self._emit(event)  # Persist intention before a mutation may reach the wire.
            if method != 5:
                self.control_scope.request_attempted = True
            event['send_attempted'] = True
            self._send(packet)
            header, _ = self._header()
            if (header.service_handle, header.service_provider_handle, header.method_handle) != (handle, provider, method):
                raise ControllerFailure('response_mismatch', 'Control response does not match exact dynamic handles.')
            if header.command_type == CommandType.ERROR:
                error = receive_error(self._receive)
                event.update(response_received=True, remote_error_code=error['code'], fatal=error['fatal'])
                self._emit(event)
                raise RemoteControllerError(error['code'], error['fatal'])
            if header.command_type != CommandType.INVOKE_CONFIRMATION:
                raise ControllerFailure('unexpected_response', 'Unexpected control response command.')
            result = tagged.receive_values(self._receive, schema[1])
            event['response_received'] = True
            self._emit(event)
            return result
        except Exception:
            self.broken = True
            raise

    def stop(self):
        return self._call(PLC, 3, [True])

    def start(self):
        return self._call(PLC, 2, [start_kind_value(self.control_scope.policy['start_kind']), True])


def _cancelled(cancel_event):
    return cancel_event is not None and cancel_event.is_set()


def execute_control(client, review, *, verify_loaded_identity=None, cancel_event=None,
                    poll_interval_seconds=0.1):
    """One request, bounded polling. Cancellation never means device rollback."""
    if (not isinstance(client, ControllerControlClient)
            or client.control_scope.review_sha256 != review['review_sha256']
            or client.control_scope.policy != review['policy']
            or client.control_scope.inventory_sha256 != review['package']['inventory_sha256']
            or client.control_scope.project_sha256 != review['source']['project_sha256']):
        raise ProjectError('Control client/review mismatch.')
    if type(poll_interval_seconds) not in (int, float) or not 0.01 <= poll_interval_seconds <= 1:
        raise ProjectError('Control poll interval must be 0.01..1 second.')
    if cancel_event is not None and not callable(getattr(cancel_event, 'is_set', None)):
        raise ProjectError('Cancellation requires an internal Event-like object.')
    policy = review['policy']
    action = policy['action']
    started = time.monotonic()
    end = started + policy['timeout_seconds']
    client.overall_end = end
    result = {'schema': 'plcnext-controller-control-result/v1', 'status': 'control_failed',
        'action': action, 'start_kind': policy['start_kind'], 'stage': 'created',
        'scope': client.control_scope.kind, 'target': review['target'],
        'review_sha256': review['review_sha256'], 'plan_id': policy['plan_id'],
        'controller_connected': False, 'action_sent': False, 'ack_received': False,
        'terminal_state_verified': False, 'loaded_package_identity_verified': False,
        'outcome_unknown': False, 'automatic_retry': False, 'inverse_action_sent': False,
        'aci_used': False, 'engineer_started': False, 'computer_use_used': False,
        'collection_verified': False, 'physical_output_behavior_verified': False}
    try:
        if _cancelled(cancel_event):
            raise ControllerFailure('control_cancelled', 'Control cancelled before connection.')
        result['stage'] = 'connecting'
        result['peer'] = client.connect()
        result['peer_connected'] = True
        result['controller_connected'] = not ipaddress.ip_address(client.endpoint.address).is_loopback
        result['stage'] = 'initial_state'
        initial = client.get_state()
        result['initial_state_raw'] = result['last_state_raw'] = initial
        if not stable_state(initial, policy['expected_initial_state_raw']):
            raise ControllerFailure('control_initial_state_mismatch', 'Fresh exact controller state differs from review.')
        if action == 'start':
            result['stage'] = 'loaded_identity'
            if not callable(verify_loaded_identity):
                raise ControllerFailure('loaded_identity_unverified', 'Start requires loaded-package evidence, not a local candidate name.')
            identity = verify_loaded_identity(client, review)
            admitted_sources = _LOADED_IDENTITY_SOURCES | (
                {'loopback_fixture_loaded_package'} if client.control_scope.kind == 'loopback_fixture' else set())
            if (type(identity) is not dict or identity.get('loaded_package_identity_verified') is not True
                    or identity.get('observed_loaded_inventory_sha256') != review['package']['inventory_sha256']
                    or identity.get('source') not in admitted_sources
                    or identity.get('target') != review['target']):
                raise ControllerFailure('loaded_identity_mismatch', 'Loaded-package evidence is absent, stale or mismatched.')
            if identity['source'] == 'same_plan_verified_load':
                flags = ('lease_held_continuously', 'journal_binding_verified',
                         'readback_all_files_verified', 'load_state_verified', 'fresh_project_name_matches')
                hashes = ('load_receipt_sha256', 'load_journal_sha256')
                if (policy['plan_id'] is None or identity.get('plan_id') != policy['plan_id']
                        or any(identity.get(key) is not True for key in flags)
                        or not stable_state(identity.get('fresh_plc_state_raw'), 2)
                        or re.fullmatch('[0-9a-f]{32}', str(identity.get('load_execution_id'))) is None
                        or any(re.fullmatch('[0-9a-f]{64}', str(identity.get(key))) is None for key in hashes)):
                    raise ControllerFailure('loaded_identity_mismatch', 'Verified-load causal evidence lacks exact plan/journal/fresh-state bindings.')
            result['loaded_package_identity_verified'] = True
            result['loaded_identity_evidence'] = identity
            # Identity observation may take time. Require a final fresh exact pre-state.
            result['last_state_raw'] = client.get_state()
            if not stable_state(result['last_state_raw'], policy['expected_initial_state_raw']):
                raise ControllerFailure('control_initial_state_mismatch', 'Controller state changed during identity verification.')
        if _cancelled(cancel_event):
            raise ControllerFailure('control_cancelled', 'Control cancelled before action.')
        if stable_state(initial, policy['required_terminal_state_raw']):
            result.update(status='control_already_complete', stage='completed', terminal_state_verified=True, final_state_raw=initial)
        else:
            result['stage'] = 'requesting'
            client.start() if action == 'start' else client.stop()
            result['ack_received'] = True
            result['stage'] = 'waiting_terminal_state'
            while True:
                if _cancelled(cancel_event):
                    raise ControllerFailure('control_cancelled', 'Control wait cancelled; sent action may still complete.')
                raw = client.get_state()
                result['last_state_raw'] = raw
                if stable_state(raw, policy['required_terminal_state_raw']):
                    result.update(status='control_completed', stage='completed', terminal_state_verified=True, final_state_raw=raw)
                    break
                flags, base = raw & ~63, raw & 63
                if flags & ~(BUSY | METADATA) or base not in (0, 1, 2, 3, 4):
                    raise ControllerFailure('control_state_error', 'Unknown/error state observed while waiting for control completion.')
                if time.monotonic() >= end:
                    raise ControllerFailure('control_timeout', 'Control did not reach its exact terminal state before deadline.')
                time.sleep(min(poll_interval_seconds, max(0, end-time.monotonic())))
    except Exception as exc:
        result.update(status='control_failed', failure_code=getattr(exc, 'code', 'control_transport_or_validation_error'),
                      error_class=type(exc).__name__)
        if isinstance(exc, ControllerFailure):
            result['error'] = str(exc)
    finally:
        calls = [x for x in client.trace if x.get('mutating') and x.get('send_attempted')]
        result['action_sent'] = bool(calls)
        result['request_attempt_count'] = len(calls)
        result['outcome_unknown'] = bool(calls) and not result['terminal_state_verified']
        result['cancelled'] = result.get('failure_code') == 'control_cancelled'
        result['cleanup_error_class'] = client.close()
        if result['cleanup_error_class'] and result['status'] != 'control_failed':
            result.update(status='control_failed', failure_code='control_session_cleanup_failed')
        result['elapsed_monotonic_seconds'] = time.monotonic()-started
        result['stop_command_sent'] = bool(calls) and action == 'stop'
        result['start_command_sent'] = bool(calls) and action == 'start'
        result['trace'] = list(client.trace)
    return result


class ControlEndpointLease:
    """Same fixed-user endpoint exclusion, optionally held across an entire plan."""
    def __init__(self, review, job):
        self.path = _claim_endpoint_lease(review, job)
        self.target, self.plan_id = review['target'], review['policy']['plan_id']
        self.review_sha256 = review['review_sha256']
        self.raw, self.quarantined, self.released = self.path.read_bytes(), False, False

    def validate(self, review):
        if (self.released or self.quarantined or self.target != review['target']
                or self.plan_id != review['policy']['plan_id'] or self.path.read_bytes() != self.raw):
            raise ControllerFailure('endpoint_lease_mismatch', 'Held endpoint lease changed or belongs to another plan/target.')
        if self.plan_id is None and review['review_sha256'] != self.review_sha256:
            raise ControllerFailure('endpoint_lease_mismatch', 'Sharing a lease across reviews requires an explicit common plan.')

    def quarantine(self):
        self.quarantined = True  # Preserve the on-disk exclusion for explicit recovery.

    def release(self):
        if self.quarantined:
            return False
        if not self.released:
            from .endpoint_guard import endpoint_guard
            with endpoint_guard(self.path):
                if self.path.read_bytes() != self.raw or self.path.with_suffix('.reconciliation.json').exists():
                    raise ControllerFailure('endpoint_lease_mismatch', 'Lease bytes changed or reconciliation pending.')
                self.path.unlink()
                self.released = True
        return True


def execute_reviewed_control(store, project_id, review_id, expected_review_sha256, *,
                             verify_loaded_identity=None, held_lease=None, cancel_event=None):
    review = revalidate_control_review(store, project_id, review_id, expected_review_sha256)
    execution_id = uuid.uuid4().hex
    job = _file(store._folder(project_id), 'controller-controls/' + execution_id)
    lease = held_lease or ControlEndpointLease(review, job)
    if not isinstance(lease, ControlEndpointLease):
        raise ProjectError('Invalid held endpoint lease.')
    lease.validate(review)
    authorized = False
    result = None
    try:
        scope = _consume_control_approval(store, review, execution_id)
        authorized = True
        job.mkdir(parents=True, exist_ok=False)
        sink = _journal_sink(job / 'journal.jsonl')
        sink({'operation': 'ExecutionBinding', 'kind': 'control', 'execution_id': execution_id,
              'project_id': project_id, 'review_sha256': expected_review_sha256,
              'project_sha256': review['source']['project_sha256'],
              'inventory_sha256': review['package']['inventory_sha256'],
              'target': review['target'], 'policy': review['policy']})
        client = ControllerControlClient(scope.endpoint, control_scope=scope, event_sink=sink)
        result = execute_control(client, review, verify_loaded_identity=verify_loaded_identity,
                                 cancel_event=cancel_event)
        result.update(project_id=project_id, review_id=review_id,
            project_sha256=review['source']['project_sha256'], inventory_sha256=review['package']['inventory_sha256'],
            journal_path=str(job / 'journal.jsonl'), endpoint_lease_path=str(lease.path))
        if result['action_sent'] and result['status'] == 'control_failed':
            lease.quarantine()
        result['endpoint_lease_retained'] = held_lease is not None or lease.quarantined
        _persist_result(job / 'result.json', result, sink)
        if not result.get('receipt_persisted'):
            lease.quarantine()
            result['endpoint_lease_retained'] = True
        return result
    finally:
        if held_lease is None and (not authorized or (result is not None and not lease.quarantined)):
            try:
                lease.release()
            except (OSError, ControllerFailure) as exc:
                if result is not None:
                    result.update(endpoint_lease_retained=True, endpoint_lease_cleanup_error_class=type(exc).__name__)
                    try:
                        _journal_sink(job / 'journal.jsonl')({'operation': 'EndpointLeaseCleanupFailed',
                            'endpoint_lease_path': str(lease.path), 'error_class': type(exc).__name__})
                    except OSError:
                        pass


def test_controller_control(store, project_id, expected_project_sha256, package_job_id, *,
                            action='stop', fault='none', start_kind='cold'):
    """Production control client against a fresh owned 127.0.0.1 TLS fixture."""
    from .controller_control_test_peer import LocalTlsControlPeer, CONTROL_FAULTS
    if action not in ('stop', 'start') or fault not in CONTROL_FAULTS | {'already_stopped', 'initial_wrong', 'missing_identity', 'wrong_identity'}:
        raise ProjectError('Unsupported loopback control action/fault.')
    _binding(store, project_id, expected_project_sha256, package_job_id)
    test_id = uuid.uuid4().hex
    job = _file(store._folder(project_id), 'controller-control-tests/' + test_id)
    job.mkdir(parents=True, exist_ok=False)
    initial = 3 if action == 'stop' else 2
    review_initial = initial
    if fault == 'already_stopped':
        if action != 'stop':
            raise ProjectError('already_stopped is a Stop-only fixture case.')
        initial = review_initial = 2
    if fault == 'initial_wrong':
        initial = 2 if action == 'stop' else 3
    selected_fault = fault if fault in CONTROL_FAULTS else 'none'
    sink = _journal_sink(job / 'journal.jsonl')
    with LocalTlsControlPeer(job / 'peer', fault=selected_fault, initial_state=initial) as peer:
        review = prepare_control_review(store, project_id, expected_project_sha256, package_job_id,
            peer.address, peer.certificate_sha256, action, port=peer.port,
            start_kind=start_kind if action == 'start' else None,
            expected_initial_state=review_initial, timeout_seconds=1)
        # prepare returns a display-only path in addition to the persisted digest.
        review.pop('review_path', None)
        scope = ControlScope.loopback_fixture(review)
        client = ControllerControlClient(scope.endpoint, control_scope=scope, event_sink=sink)
        def fixture_identity(client, review):
            return {'loaded_package_identity_verified': True,
                'observed_loaded_inventory_sha256': ('0' * 64 if fault == 'wrong_identity' else review['package']['inventory_sha256']),
                'source': 'loopback_fixture_loaded_package', 'target': review['target'],
                'real_loaded_program_identity_claimed': False}
        sink({'operation': 'ExecutionBinding', 'kind': 'loopback_control', 'test_id': test_id,
              'review_sha256': review['review_sha256'], 'project_sha256': expected_project_sha256,
              'inventory_sha256': review['package']['inventory_sha256'], 'target': review['target']})
        result = execute_control(client, review,
            verify_loaded_identity=None if fault == 'missing_identity' else fixture_identity,
            poll_interval_seconds=0.01)
        result.update(test_id=test_id, project_id=project_id, fault=fault,
            journal_path=str(job / 'journal.jsonl'), real_device_tested=False,
            peer_start_calls=peer.start_calls, peer_stop_calls=peer.stop_calls,
            peer_state_raw=peer.state, peer_errors=list(peer.errors),
            operator_approval_issued=False, package_job_id=package_job_id)
        if result['status'] in ('control_completed', 'control_already_complete'):
            result['control_status'] = result['status']
            result['status'] = 'loopback_control_passed'
        _persist_result(job / 'result.json', result, sink)
    return result
