param([Parameter(Mandatory)][string]$WorkRoot, [Parameter(Mandatory)][string]$InstallDirectory,
      [switch]$ProjectSources, [switch]$ColdProject)
$ErrorActionPreference = 'Stop'
$jobRoot = [IO.Path]::GetFullPath($WorkRoot)
$installRoot = [IO.Path]::GetFullPath($InstallDirectory)
$source = Join-Path $jobRoot $(if ($ProjectSources -or $ColdProject) {'sources.xml'} else {'source.st'})
$ast = Join-Path $jobRoot 'input\LastBuild.ast'
$referencesPath = Join-Path $jobRoot 'references'
$generated = Join-Path $jobRoot 'generated'
$output = Join-Path $jobRoot 'host-result.json'
foreach ($candidate in @($source,$ast,$referencesPath,$generated,$output)) {
    if (-not [IO.Path]::GetFullPath($candidate).StartsWith($jobRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
        throw 'Compile job paths must stay inside their declared job folder.'
    }
}
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Reflection;
public static class CachedCompilerResolver {
    public static string DirectoryPath;
    public static Assembly Resolve(object sender, ResolveEventArgs args) {
        var name = new AssemblyName(args.Name).Name;
        if (name.StartsWith("Ade.ApplicationControl", StringComparison.OrdinalIgnoreCase) ||
            name.IndexOf("License", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("CodeMeter", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("Wibu", StringComparison.OrdinalIgnoreCase) >= 0)
            throw new InvalidOperationException("Out-of-scope host assembly: " + name);
        var path = Path.Combine(DirectoryPath, name+".dll");
        return File.Exists(path) ? Assembly.LoadFrom(path) : null;
    }
}
'@
[CachedCompilerResolver]::DirectoryPath=$installRoot
$resolver=[ResolveEventHandler][CachedCompilerResolver]::Resolve
[AppDomain]::CurrentDomain.add_AssemblyResolve($resolver)
$result=[ordered]@{status='host_failed';aci_used=$false;computer_use_used=$false;controller_connected=$false}
$sourceHash=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant()
try {
    $refs=@('Ade.Compiler.dll','Ade.CompilerImpl.dll','Ade.Compiler.ParsingImpl.dll','Ade.Compiler.Eclr.dll',
        'Ade.Compiler.EclrImpl.dll','Ade.Components.dll','Ade.Patterns.dll','Ade.Core.dll','Ade.Reflection.dll',
        'Ade.ReflectionImpl.dll','Ade.Reflection.CecilImpl.dll','System.ComponentModel.Composition.dll') | ForEach-Object {Join-Path $installRoot $_}
    foreach($reference in $refs) {[void][Reflection.Assembly]::LoadFrom($reference)}
    $refs+=@('System.Linq.dll','System.Collections.dll','System.Runtime.dll','System.Threading.dll',
        'System.Threading.Tasks.dll','System.ComponentModel.Primitives.dll','System.Xml.XDocument.dll',
        'System.Xml.ReaderWriter.dll','System.Xml.XmlDocument.dll','System.IO.Compression.dll',
        'System.IO.Compression.ZipFile.dll','System.Security.Cryptography.dll')
    Add-Type -Path @((Join-Path $PSScriptRoot '..\parser_host\HeadlessParserProbe.cs'),
        (Join-Path $PSScriptRoot 'ProjectSourceBuilder.cs'),
        (Join-Path $PSScriptRoot 'ColdProjectBuilder.cs'),
        (Join-Path $PSScriptRoot 'CachedCompilerHost.cs')) -ReferencedAssemblies $refs -CompilerOptions '/nowarn:1701'
    if ($ColdProject) {
        $result=[CachedCompilerHost]::RunColdProject((Join-Path $jobRoot 'project'),$installRoot,$source,$referencesPath,$generated)
    } elseif ($ProjectSources) {
        $result=[CachedCompilerHost]::RunProject($ast,$source,$referencesPath,$generated)
    } else {
        $result=[CachedCompilerHost]::Run($ast,$source,$referencesPath,$generated)
    }
} catch {
    $result['status']='host_failed';$result['errors']=@();$item=$_.Exception
    while ($null -ne $item) {
        $result['errors']+=@{type=$item.GetType().FullName;message=$item.Message;stack=$item.StackTrace}
        $item=$item.InnerException
    }
} finally {
    $result['source_sha256']=$sourceHash
    $result['source_sha256_after']=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant()
    $result['loaded_assemblies']=@([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object {$_.GetName().Name -like 'Ade.*'} | ForEach-Object {$_.GetName().Name} | Sort-Object)
    [AppDomain]::CurrentDomain.remove_AssemblyResolve($resolver)
    $result | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $output -Encoding utf8
}
if ($result['status'] -eq 'host_failed') {exit 2}
