"""Pure Stop(bool async) tagged request/normal reply codec; no device calls.

Method ID 3 and signature are from the original IPlcManagerService declaration;
full tagged messages match the original MemoryStream SerializeMessage oracle.
An empty normal reply is only acknowledgement, not proof the PLC has stopped.
"""
from __future__ import annotations

from . import rsc_tagged_codec as tagged

STOP_METHOD_ID = 3


def encode_stop_request(service_handle: int, async_: bool = True,
                        *, provider_handle: int = 0, token: int | None = None) -> bytes:
    if type(async_) is not bool:
        raise ValueError('PLC Stop async_ must be Boolean.')
    return tagged.encode_request(service_handle, STOP_METHOD_ID, ['bool'], [async_],
                                 provider_handle=provider_handle, token=token)


def decode_stop_request(packet: bytes):
    header, token, values = tagged.decode_request(packet, ['bool'])
    if header.method_handle != STOP_METHOD_ID:
        raise ValueError('Expected PLC Stop method ID 3.')
    return header, token, {'async_': values[0]}


def encode_stop_response(service_handle: int, *, provider_handle: int = 0) -> bytes:
    return tagged.encode_response(service_handle, STOP_METHOD_ID, [], [], provider_handle=provider_handle)


def decode_stop_response(packet: bytes):
    header, token, values = tagged.decode_response(packet, [])
    if header.method_handle != STOP_METHOD_ID or token is not None or values:
        raise ValueError('Expected no-token PLC Stop acknowledgement.')
    return header, token
