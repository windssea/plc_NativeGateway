"""Bounded tagged RSC v4 ERROR(4) frames measured with original formatters.

This is not the normal invocation return schema. ReadError2 consumes a tagged
UInt32, then (only for nonfatal codes) MarshalType1 text and Object[] arguments.
The measured .NET 8 MarshalType1 text is tag 0x1a with NUL-terminated UTF-8 bytes.
Fatal codes (high bit set) end immediately, without an invocation FF marker.
No socket, exception reflection, CLR type loading or device action occurs here.
"""
from __future__ import annotations

import io
import struct

from .rsc_codec import CommandHeader, CommandType, DATA_TAGGING, decode_header, encode_header
from .rsc_tagged_codec import decode_value, encode_value

MAX_TEXT_BYTES = 4096
MAX_ARGUMENTS = 16
MAX_BODY_BYTES = 65536
_ARGUMENT_SCHEMAS = {2: ('bool', 1), 8: ('int32', 4), 9: ('uint32', 4), 10: ('int64', 8)}


def _require(condition, message):
    if not condition:
        raise ValueError('RSC tagged error codec: ' + message)


class _Reader:
    def __init__(self, read_exact):
        _require(callable(read_exact), 'byte reader callable required.')
        self.read_exact, self.position = read_exact, 0

    def take(self, count):
        _require(type(count) is int and count >= 0 and self.position + count <= MAX_BODY_BYTES,
                 'body exceeds bounded error profile.')
        data = bytearray()
        while len(data) < count:
            block = self.read_exact(count - len(data))
            _require(type(block) is bytes and 0 < len(block) <= count - len(data),
                     'truncated error body, invalid byte reader or oversized read.')
            data.extend(block)
        self.position += count
        return bytes(data)


def _encode_text(value):
    _require(type(value) is str and '\0' not in value, 'error text must be a non-null string.')
    try:
        data = value.encode('utf-8') + b'\0'
    except UnicodeError as exc:
        raise ValueError('RSC tagged error codec: invalid UTF-8 text.') from exc
    _require(len(data) <= MAX_TEXT_BYTES, 'error text exceeds bound.')
    return b'\x1a' + struct.pack('<H', len(data)) + data


def _read_text(reader, *, tag_consumed=False):
    if not tag_consumed:
        _require(reader.take(1) == b'\x1a', 'expected measured MarshalType1 string tag.')
    length = struct.unpack('<H', reader.take(2))[0]
    _require(1 <= length <= MAX_TEXT_BYTES, 'invalid error text length.')
    data = reader.take(length)
    _require(data.endswith(b'\0') and b'\0' not in data[:-1], 'invalid error text terminator.')
    try:
        return data[:-1].decode('utf-8', errors='strict')
    except UnicodeError as exc:
        raise ValueError('RSC tagged error codec: invalid UTF-8 error text.') from exc


def _encode_argument(value):
    if type(value) is str:
        return _encode_text(value)
    if type(value) is bool:
        return encode_value('bool', value)
    if type(value) is int:
        if -(2 ** 31) <= value < 2 ** 31:
            return encode_value('int32', value)
        if 0 <= value <= 0xffffffff:
            return encode_value('uint32', value)
        if -(2 ** 63) <= value < -(2 ** 31):
            return encode_value('int64', value)
    raise ValueError('RSC tagged error codec: unsupported Object argument; only measured text/Bool/Int32/UInt32/negative Int64 are supported.')


def receive_error(read_exact) -> dict:
    """Consume one ERROR value body from a fragmented stream, after its header.

    Fatal errors consume only their UInt32 code and have no FF. Nonfatal errors
    consume text, a bounded Object[] and FF. No bytes of the next frame are read.
    Unknown/null/array/CLR objects are rejected rather than deserialized.
    """
    reader = _Reader(read_exact)
    _require(reader.take(1) == b'\x09', 'expected tagged UInt32 error code.')
    code = struct.unpack('<I', reader.take(4))[0]
    if code & 0x80000000:
        return {'code': code, 'fatal': True, 'message': None, 'arguments': []}
    message = _read_text(reader)
    _require(reader.take(2) == b'\x14\x1c', 'expected measured Object[] error arguments.')
    count = struct.unpack('<i', reader.take(4))[0]
    _require(0 <= count <= MAX_ARGUMENTS, 'null/oversized error arguments unsupported.')
    arguments = []
    for _ in range(count):
        tag = reader.take(1)[0]
        if tag == 0x1a:
            arguments.append(_read_text(reader, tag_consumed=True))
        elif tag in _ARGUMENT_SCHEMAS:
            schema, size = _ARGUMENT_SCHEMAS[tag]
            arguments.append(decode_value(bytes([tag]) + reader.take(size), schema))
        else:
            raise ValueError('RSC tagged error codec: unsupported Object argument tag.')
    _require(reader.take(1) == b'\xff', 'missing nonfatal error end marker.')
    return {'code': code, 'fatal': False, 'message': message, 'arguments': arguments}


def encode_error(service_handle: int, method_handle: int, code: int,
                 message: str = '', arguments=(), *, provider_handle: int = 0) -> bytes:
    """Encode the measured error profile, primarily for a bounded local peer."""
    for handle in (service_handle, method_handle, provider_handle):
        _require(type(handle) is int and 0 <= handle <= 32767, 'invalid error response handle.')
    _require(type(code) is int and 0 <= code <= 0xffffffff, 'invalid UInt32 error code.')
    _require(type(arguments) in (list, tuple) and len(arguments) <= MAX_ARGUMENTS,
             'bounded error argument sequence required.')
    body = b'\x09' + struct.pack('<I', code)
    if code & 0x80000000:
        _require(message == '' and len(arguments) == 0, 'fatal errors carry only a code.')
    else:
        body += (_encode_text(message) + b'\x14\x1c' + struct.pack('<i', len(arguments))
                 + b''.join(_encode_argument(item) for item in arguments) + b'\xff')
    _require(len(body) <= MAX_BODY_BYTES, 'error body exceeds bound.')
    return encode_header(CommandHeader(flags=DATA_TAGGING, command_type=CommandType.ERROR,
        service_handle=service_handle, method_handle=method_handle,
        service_provider_handle=provider_handle)) + body


def decode_error(packet: bytes):
    """Return (header, None, error-dict) for one exact no-token tagged v4 frame.

    Expected request/response handle correlation remains the transport's job.
    Authentication tokens in responses and other flags/profiles are rejected.
    """
    _require(type(packet) is bytes and 21 <= len(packet) <= MAX_BODY_BYTES + 16,
             'invalid error frame length.')
    header, token = decode_header(packet[:16], require_checksum=True)
    _require(header.version == 4 and header.command_type == CommandType.ERROR
             and header.flags == DATA_TAGGING and token is None
             and header.data_length == 0 and header.additional_header_size == 0
             and min(header.service_handle, header.method_handle, header.service_provider_handle) >= 0,
             'unsupported error response profile.')
    stream = io.BytesIO(packet[16:])
    error = receive_error(stream.read)
    _require(stream.tell() == len(packet) - 16, 'trailing error frame bytes.')
    return header, token, error
