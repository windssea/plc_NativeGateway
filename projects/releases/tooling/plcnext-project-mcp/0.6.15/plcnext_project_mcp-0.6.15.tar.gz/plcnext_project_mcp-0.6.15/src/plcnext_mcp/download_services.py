"""Observed RSC service contracts with a strictly in-memory controller double.

No socket, HTTP client, target address, vendor online object, or device discovery
is implemented here. The double tests orchestration; it is not a wire server.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum, IntFlag
import hmac
import secrets
import hashlib

from .deployment_package import _relative_path
from .project import ProjectError
from .offline_tls import offline_tls_probe
from .rsc_codec import CommandHeader, decode_header, encode_header
from .rsc_file_codec import decode_write_many, encode_write_many


class FileSystemError(IntEnum):
    NONE = 0
    UNKNOWN = 1
    INVALID_PATH = 2
    NOT_EXIST = 3
    ALREADY_EXISTS = 4
    ACCESS_DENIED = 5
    OUT_OF_SPACE = 6


class PlcState(IntFlag):
    NONE = 0
    READY = 1
    STOP = 2
    RUNNING = 3
    HALT = 4
    ERROR = 0x80
    SUSPENDED = 0x100
    FATAL_ERROR = 0x200
    BLOCKED = 0x400
    SYSTEM_ERROR = 0x800
    LOADING = 0x1000
    STARTING = 0x2000
    STOPPING = 0x4000
    RESETTING = 0x8000
    CHANGING = 0x10000
    DCG_NOT_POSSIBLE = 0x40000000
    DCG_RT_ERROR = 0x80000000


def device_state(raw: int) -> tuple[int, int]:
    """Return the observed Ade (DeviceState, DeviceError) projection."""
    error = 0
    for flag, code in ((PlcState.SYSTEM_ERROR, 6), (PlcState.FATAL_ERROR, 5),
                       (PlcState.DCG_RT_ERROR, 4), (PlcState.DCG_NOT_POSSIBLE, 3),
                       (PlcState.SUSPENDED, 2), (PlcState.ERROR | PlcState.BLOCKED, 1)):
        if raw & flag:
            error = code
            break
    if error == 6:
        return 11, error
    if error == 5:
        return 10, error
    state = {1: 0, 2: 7, 3: 3, 4: 5}.get(raw & 0x3F, 9)
    return state, error


@dataclass(frozen=True)
class WriteFileData:
    file_path: str
    data: bytes
    overwrite: bool = True
    # Trait 1 is Permissions. No file times are invented for archive members.
    permissions: int = 0o664


class ServiceFailure(ProjectError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


FAULTS = ('none', 'bad_credentials', 'penalty_active', 'permission_denied',
          'session_expired', 'insufficient_space', 'write_error', 'short_results',
          'transport_interrupted', 'readback_corrupt', 'reset_timeout',
          'load_timeout', 'load_error', 'initial_running', 'untrusted_peer', 'hostname_mismatch')


class InMemoryController:
    """Local test service. All credentials and tokens are ephemeral test data.

    A real TLS 1.2 MemoryBIO probe uses public test CA material before these
    typed service calls. No complete RSC RPC channel or real PLC is involved.
    """
    root = '/simulated-device/projects/PCWE'
    supported_traits = 1 | 2 | 4 | 8 | 16

    def __init__(self, fault='none', *, token_value=None):
        if fault not in FAULTS:
            raise ProjectError('Unsupported offline fault scenario.')
        self.fault = fault
        self.username = 'offline-test-user'
        self._password = secrets.token_urlsafe(24)
        self._token = secrets.randbits(32) if token_value is None else token_value
        if type(self._token) is not int or not 0 <= self._token <= 0xFFFFFFFF:
            raise ProjectError('Security token must be a UInt32.')
        self._authenticated = False
        self._enabled = False
        self._phase = 'initial'
        self._polls = 0
        self._write_calls = 0
        self._read_calls = 0
        self._files: dict[str, bytes] = {'obsolete-offline-fixture.tmp': b'previous simulated project'}
        self._permissions: dict[str, int] = {}
        self.trace: list[dict] = []
        self.loaded = False
        self.session_closed = False
        self.virtual_elapsed_ms = 0
        self.tls_report = {}
        self.header_roundtrips = 0
        self.file_value_roundtrips = 0

    def record(self, operation, **fields):
        self.trace.append({'sequence': len(self.trace), 'operation': operation, **fields})

    def credentials(self):
        # Never returned by MCP or written to any report.
        return self.username, ('invalid-offline-test-password' if self.fault == 'bad_credentials' else self._password)

    def check_peer_policy(self):
        tls_fault = self.fault if self.fault in ('untrusted_peer', 'hostname_mismatch') else 'none'
        self.tls_report = offline_tls_probe(tls_fault)
        self.record('Simulator.MemoryTlsHandshake', **self.tls_report)
        if not self.tls_report['passed']:
            raise ServiceFailure('peer_not_trusted', 'In-memory TLS rejected the offline test certificate.')

    def _check_header(self, token):
        # Standalone authenticated-header validation. Handles are synthetic;
        # no service discovery, RPC payload or datagram framing is claimed.
        encoded = encode_header(CommandHeader(), token)
        _, decoded_token = decode_header(encoded, require_checksum=True)
        if decoded_token != token:
            raise ServiceFailure('invalid_header', 'Offline RSC token header roundtrip failed.')
        self.header_roundtrips += 1

    def create_session(self, username, password):
        # Arp.System.Security.Services.IPasswordAuthenticationService.CreateSession.
        from .rsc_codec import AuthenticationError
        self._check_header(None)
        result = AuthenticationError(-2 if self.fault == 'penalty_active' else
            -1 if not hmac.compare_digest(username.encode('utf-8'), self.username.encode('utf-8'))
                  or not hmac.compare_digest(password.encode('utf-8'), self._password.encode('utf-8'))
            else 0)
        self.record('IPasswordAuthenticationService.CreateSession', result=int(result),
                    penalty_timeout=1000 if result == -2 else 0)
        if result != 0:
            return result, None, 1000 if result == -2 else 0
        self._authenticated = True
        return result, self._token, 0

    def enable_security(self, token):
        if token is None or not self._authenticated or token != self._token:
            raise ServiceFailure('session_invalid', 'No valid offline authentication session.')
        self._enabled = True
        self.record('CommonRemoting.EnableSecurity', token_present=True)

    def _authorize(self):
        if not self._authenticated or not self._enabled:
            raise ServiceFailure('session_invalid', 'Offline security context is missing.')
        self._check_header(self._token)

    def get_permissions(self):
        self._authorize()
        allowed = self.fault != 'permission_denied'
        self.record('Simulator.GetOperationPermissions', allowed=allowed)
        return {'write_files': allowed, 'read_files': True, 'load_configuration': allowed}

    def resolve_project_root(self):
        self._authorize()
        self.record('IFileSystemInfoService.GetFileSystemTraitsEntry',
                    symbolic_name='$ARP_PROJECTS_DIR$/PCWE/', path=self.root, result=0)
        return FileSystemError.NONE, self.root

    def get_space(self):
        self._authorize()
        free = 0 if self.fault == 'insufficient_space' else 2 * 1024**3
        self.record('IFileSystemInfoService.GetSpaceInfo', free_bytes=free)
        return free

    def _path(self, path):
        prefix = self.root + '/'
        if not isinstance(path, str) or not path.startswith(prefix):
            raise ServiceFailure('unsafe_remote_path', 'Path is outside the simulated project root.')
        relative = path[len(prefix):]
        _relative_path(relative)
        return relative

    def write_many(self, entries: list[WriteFileData]):
        self._authorize()
        canonical = [{'path': i.file_path, 'overwrite': i.overwrite,
            'traits': [{'trait': 1, 'value': i.permissions}] if self.supported_traits & 1 else [],
            'data': i.data} for i in entries]
        encoded = encode_write_many(canonical, version=4)
        decoded = decode_write_many(encoded, version=4)
        if decoded != canonical:
            raise ServiceFailure('file_value_codec_failed', 'Offline file value codec changed a DTO.')
        entries = [WriteFileData(i['path'], i['data'], i['overwrite'],
                                  i['traits'][0]['value'] if i['traits'] else 0) for i in decoded]
        self.file_value_roundtrips += 1
        self._write_calls += 1
        self.record('IFileService2.WriteMany', file_count=len(entries),
                    payload_bytes=sum(len(item.data) for item in entries),
                    value_encoding='observed untagged v4 WriteFileData[]',
                    encoded_bytes=len(encoded), encoded_sha256=hashlib.sha256(encoded).hexdigest(),
                    complete_rsc_rpc=False)
        if self.fault == 'session_expired':
            self._authenticated = False
            raise ServiceFailure('session_expired', 'Offline session expired before file writes.')
        if self.fault == 'transport_interrupted':
            # A lost reply can follow writes; model that ambiguity explicitly.
            if entries:
                item = entries[0]
                self._files[self._path(item.file_path)] = item.data
            raise ServiceFailure('transport_interrupted', 'Offline reply lost after a possible file write.')
        results = []
        for index, item in enumerate(entries):
            relative = self._path(item.file_path)
            error = (FileSystemError.ACCESS_DENIED if self.fault == 'write_error' and index == 0 else
                     FileSystemError.ACCESS_DENIED if self.fault == 'permission_denied' else
                     FileSystemError.ALREADY_EXISTS if relative in self._files and not item.overwrite else
                     FileSystemError.NONE)
            if error == FileSystemError.NONE:
                self._files[relative] = item.data
                self._permissions[relative] = item.permissions
            results.append(error)
        return results[:-1] if self.fault == 'short_results' else results

    def read_many(self, paths):
        self._authorize()
        self._read_calls += 1
        self.record('IFileService2.ReadMany', file_count=len(paths))
        results = []
        for index, path in enumerate(paths):
            relative = self._path(path)
            if relative not in self._files:
                results.append((FileSystemError.NOT_EXIST, b''))
                continue
            data = self._files[relative]
            if self.fault == 'readback_corrupt' and self._read_calls == 1 and index == 0:
                data = data + b'offline-corruption-fixture'
            results.append((FileSystemError.NONE, data))
        return results

    def reconcile(self, expected_names):
        self._authorize()
        removed = sorted(set(self._files) - set(expected_names))
        for name in removed:
            del self._files[name]
            self._permissions.pop(name, None)
        self.record('Simulator.ReconcileProjectFiles', removed=removed,
                    note='Offline virtual-filesystem policy; remote deletion wire API is not modeled.')
        return removed

    def get_state(self):
        self._authorize()
        self._polls += 1
        if self._phase == 'reset':
            raw = int(PlcState.STOP | PlcState.RESETTING) if self.fault == 'reset_timeout' else int(PlcState.READY)
        elif self._phase == 'load':
            raw = int(PlcState.READY | PlcState.LOADING) if self.fault == 'load_timeout' else int(PlcState.STOP)
            if self.fault == 'load_error':
                raw |= int(PlcState.ERROR)
        else:
            raw = int(PlcState.RUNNING if self.fault == 'initial_running' else PlcState.STOP)
        projected, error = device_state(raw)
        self.record('IPlcManagerService.GetPlcState', raw=raw, device_state=projected, device_error=error)
        return projected, error

    def reset(self, async_=True):
        self._authorize()
        self.record('IPlcManagerService.Reset', async_=async_)
        self._phase = 'reset'

    def load(self, async_=True):
        self._authorize()
        self.record('IPlcManagerService.Load', async_=async_)
        self._phase = 'load'

    def advance(self, milliseconds):
        self.virtual_elapsed_ms += milliseconds

    def close(self):
        had_session = self._authenticated or self._enabled
        if self._enabled:
            self.record('CommonRemoting.DisableSecurity')
        if had_session:
            self.record('IPasswordAuthenticationService.CloseSession', token_present=True)
        self._enabled = False
        self._authenticated = False
        self._password = ''
        self._token = None
        self.session_closed = True
        self.record('Simulator.DisposeSecurityContext')

    def snapshot(self):
        return dict(self._files)
