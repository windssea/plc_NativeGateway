"""M12 source-adapted audit collector (origin: Engineer/tools/phase1_audit_export.py).

Bounded P05 RSC evidence export. No MQTT publishing, DB or acquisition writes.

The only PLC writes acknowledge already fsynced audit copies, never business
DATA/STORED. Run only against the P05 candidate. A fresh file is mandatory;
process restarts use another file and cannot certify an earlier cohort.
"""
import json
import os
from pathlib import Path
import time

EVENT_FIELDS = ('SampleSeq Value CapturedUtcMs CompletedMonoMs NominalDueMonoMs '
                'ClockRevision SamplingGeneration ConfigGeneration ConfigSlot '
                'PointIndex Quality Kind Flags').split()
DIAGNOSTIC_FIELDS = ('Revision BootId GatewayId CapturedMonoMs ConfigVersion '
    'DecisionPending PendingEvents DeadEvents UncertainRetainedEvents PendingBatches '
    'DeadBatches UsedBytes AllocatedBytes MaxBytes OldestPendingAgeMs HasPendingAge '
    'AccountingComplete CounterOverflow DetailTruncated RestartLossUnknown '
    'AuditDropped AssociationDropped EvidenceComplete LastGapCountKnown HmiSummary').split()
GAP_FIELDS = ('SampleSeq ConfigVersion CompletedMonoMs CapturedUtcMs Flags Outcome '
              'GatewayId CaptureBootId DeviceId PointId Reason').split()


class EvidenceError(RuntimeError):
    pass


class Journal:
    def __init__(self, path, max_bytes=64*1024*1024, max_records=100000):
        self.file = Path(path).open('xb')
        self.size = 0
        self.limit = max_bytes
        self.records = 0
        self.max_records = max_records

    def append(self, rows):
        data = ''.join(json.dumps(r, ensure_ascii=False, allow_nan=False,
                                  separators=(',', ':'))+'\n' for r in rows).encode()
        if self.size+len(data) > self.limit or self.records+len(rows) > self.max_records:
            raise EvidenceError('Evidence byte cap reached; no further ACK')
        self.file.write(data)
        self.file.flush()
        os.fsync(self.file.fileno())
        self.size += len(data)
        self.records += len(rows)

    def close(self):
        self.file.close()


class Exporter:
    """Single reader; native ring overflow is a failed evidence window.

    Transport.read returns an ordered field dictionary. Every call is bounded;
    no custom IEC struct or >256-character string is requested through RSC.
    """
    def __init__(self, transport, journal):
        self.io = transport
        self.journal = journal
        self.boot = None
        self.capture = 0
        self.association = 0
        self.configs = {}
        self.config_headers = {}
        self.complete = True
        self.diagnostic_revision = 0
        self.business_completeness = {}
        self.tail = None
        self.cohort = None
        self.fact_mode='legacy_v1';self.facts_complete=True;self.raw_facts_complete=None
        self.expected_config = None
        self.max_capture_backlog = 0
        self.max_association_backlog = 0

    def fact_metadata(self):
        if self.fact_mode!='decision_clock_slots_v2':return {}
        return {'audit_fact_schema':2,'audit_facts_complete':self.raw_facts_complete,
            'audit_fact_encoding_complete':self.facts_complete,
            'v2_facts_complete':self.raw_facts_complete is True and self.facts_complete,
            'audit_fact_encoding_scope':'exported_raw_prefix',
            'decisionTimeClockSeparatelyAttested':False,'missedSlotsIndependentlyVerified':False,
            'trailingUncompletedPollWindowProven':False}

    def head(self):
        names=['BootId','Active.Version']+['CaptureBuffer.'+n for n in
            ('AuditEnabled AuditReadSeq AuditWriteSeq AssociationReadSeq '
             'AssociationWriteSeq AuditDropped AssociationDropped EvidenceComplete').split()]
        if self.fact_mode=='decision_clock_slots_v2':
            names+=['CaptureBuffer.AuditFactSchema','CaptureBuffer.AuditFactsComplete']
        return self.io.read(names)

    def check(self, head):
        if self.fact_mode=='decision_clock_slots_v2':
            if type(head['CaptureBuffer.AuditFactSchema']) is not int or head['CaptureBuffer.AuditFactSchema']!=2:
                raise EvidenceError('Runtime fact schema differs from reviewed v2')
            if type(head['CaptureBuffer.AuditFactsComplete']) is not bool:raise EvidenceError('Invalid facts completeness type')
            self.raw_facts_complete=head['CaptureBuffer.AuditFactsComplete']
        if self.expected_config is None:self.expected_config=head['Active.Version']
        if head['Active.Version']!=self.expected_config:raise EvidenceError('Active configuration changed; no ACK')
        if head['BootId'] != self.boot:
            raise EvidenceError('Boot changed during export; no ACK')
        if not head['CaptureBuffer.AuditEnabled']:
            raise EvidenceError('P05 audit is disabled')
        if (head['CaptureBuffer.AuditDropped'] or head['CaptureBuffer.AssociationDropped']
                or not head['CaptureBuffer.EvidenceComplete']):
            raise EvidenceError('Native evidence ring incomplete; cohort cannot pass')
        for name in ('AuditReadSeq','AuditWriteSeq','AssociationReadSeq','AssociationWriteSeq'):
            value=head['CaptureBuffer.'+name]
            if type(value) is not int or not 0<=value<2**64:raise EvidenceError('Invalid ring ordinal')
        if (head['CaptureBuffer.AuditWriteSeq']<self.capture or head['CaptureBuffer.AssociationWriteSeq']<self.association
                or head['CaptureBuffer.AuditWriteSeq']-self.capture>512
                or head['CaptureBuffer.AssociationWriteSeq']-self.association>32):
            raise EvidenceError('Ring prefix lost or cursor moved backward')
        self.max_capture_backlog=max(self.max_capture_backlog,head['CaptureBuffer.AuditWriteSeq']-self.capture)
        self.max_association_backlog=max(self.max_association_backlog,head['CaptureBuffer.AssociationWriteSeq']-self.association)
        if (head['CaptureBuffer.AuditReadSeq'] > self.capture or
                head['CaptureBuffer.AssociationReadSeq'] > self.association):
            raise EvidenceError('Unrecorded ring entries already released')

    def config(self, slot, generation, point):
        key = slot, generation, point
        self.prefetch_configs([key])
        return self.configs[key]

    def prefetch_configs(self, keys):
        groups = {}
        for slot,generation,point in keys:
            if not 1 <= slot <= 4 or not 1 <= point <= 320:
                raise EvidenceError('Invalid configuration reference')
            if (slot,generation,point) not in self.configs:
                groups.setdefault((slot,generation),set()).add(point)
        for (slot,generation),points in groups.items():
            base = f'CaptureBuffer.Configs[{slot}].'
            names = ['Generation','GatewayId','CaptureBootId','Config.Version',
                     'Config.DeviceCount','Config.PointCount']
            raw = self.io.read([base+n for n in names])
            header = {n:raw[base+n] for n in names}
            if header['Generation'] != generation or header['CaptureBootId'] != self.boot:
                raise EvidenceError('Configuration generation/boot changed')
            if not 1 <= header['Config.DeviceCount'] <= 50 or max(points) > header['Config.PointCount']:
                raise EvidenceError('Invalid point dictionary')
            cached = self.config_headers.get(slot)
            if cached and cached[0] == generation:
                devices = cached[1]
            else:
                devices = self.io.read([base+f'Config.Devices[{i}].'+n
                    for i in range(1,header['Config.DeviceCount']+1)
                    for n in ('deviceId','PointStart','PointCount')])
            point_fields = ('pointId','dataType','reportMode','reportIntervalMs','deadband')
            raw = self.io.read([base+f'Config.Points[{point}].'+n
                                for point in sorted(points) for n in point_fields])
            if self.io.read([base+'Generation'])[base+'Generation'] != generation:
                raise EvidenceError('Configuration changed while reading')
            self.configs = {k:v for k,v in self.configs.items() if k[0] != slot or k[1] == generation}
            self.config_headers[slot] = generation,devices
            for point in points:
                row = dict(header)
                row.update((f'Config.Points[{point}].'+n,raw[base+f'Config.Points[{point}].'+n]) for n in point_fields)
                owners = [i for i in range(1,header['Config.DeviceCount']+1)
                    if devices[base+f'Config.Devices[{i}].PointStart'] <= point <
                       devices[base+f'Config.Devices[{i}].PointStart']+
                       devices[base+f'Config.Devices[{i}].PointCount']]
                if len(owners) != 1:
                    raise EvidenceError('Ambiguous point ownership')
                row['deviceId'] = devices[base+f'Config.Devices[{owners[0]}].deviceId']
                self.configs[slot,generation,point] = row

    def diagnostics(self):
        base = 'CaptureBuffer.Diagnostics.'
        before = self.io.read([base+'Revision'])[base+'Revision']
        if not before or before % 2 or before == self.diagnostic_revision:
            return None
        names = DIAGNOSTIC_FIELDS+[f'Totals[{i}]' for i in range(1,17)]
        names += ['LastGap.'+n for n in GAP_FIELDS]
        raw = self.io.read([base+n for n in names])
        after = self.io.read(['BootId', base+'Revision'])
        if before != after[base+'Revision'] or after['BootId'] != self.boot:
            return None
        row = {n:raw[base+n] for n in names}
        if row['BootId'] != self.boot:
            return None
        if not row['HasPendingAge']:
            row['OldestPendingAgeMs'] = None
        row['LastGap.eventCount'] = 1 if row['LastGapCountKnown'] else None
        if not row['LastGapCountKnown']:
            for n in GAP_FIELDS:
                if n not in ('Reason', 'Outcome'):
                    row['LastGap.'+n] = None
        return dict(kind='localDiagnostics', bootId=self.boot, snapshot=row)

    def acknowledge(self, name, sequence):
        self.io.acknowledge(name, self.boot, sequence, self.journal)

    def poll(self):
        before = self.head()
        if self.boot is None:
            self.boot = before['BootId']
            if not self.boot:
                raise EvidenceError('Empty boot')
        self.check(before)
        captures = []
        dictionaries = []
        end = min(before['CaptureBuffer.AuditWriteSeq'], self.capture+64, self.tail[0] if self.tail else 2**64-1)
        event_names = ['Event.'+n for n in EVENT_FIELDS]+['Decision','Reason']
        v2=self.fact_mode=='decision_clock_slots_v2'
        if v2:
            from .audit_facts import FIELDS,encoding_complete
            event_names+=list(FIELDS)
        publication=self.io.read([f'CaptureBuffer.AuditEvents[{(seq-1)%512+1}].'+n
            for seq in range(self.capture+1,end+1) for n in ('Event.SampleSeq','Decision')]) if v2 else {}
        raw = self.io.read([f'CaptureBuffer.AuditEvents[{(seq-1)%512+1}].'+n
            for seq in range(self.capture+1,end+1) for n in event_names])
        batch = []
        for seq in range(self.capture+1, end+1):
            base = f'CaptureBuffer.AuditEvents[{(seq-1)%512+1}].'
            row = {n:raw[base+n] for n in event_names}
            if row['Event.SampleSeq'] != seq:
                raise EvidenceError('Capture overwritten during read')
            if row['Decision'] == 0:
                break
            if v2 and (publication[base+'Event.SampleSeq']!=seq or publication[base+'Decision']!=row['Decision']):
                raise EvidenceError('Decision changed across fact read; no ACK')
            batch.append((seq,row))
        old_keys = set(self.configs)
        self.prefetch_configs([(row['Event.ConfigSlot'],row['Event.ConfigGeneration'],row['Event.PointIndex'])
                               for seq,row in batch])
        fences = self.io.read([f'CaptureBuffer.AuditEvents[{(seq-1)%512+1}].Event.SampleSeq' for seq,row in batch])
        emitted = set()
        for seq,row in batch:
            base = f'CaptureBuffer.AuditEvents[{(seq-1)%512+1}].'
            key = row['Event.ConfigSlot'],row['Event.ConfigGeneration'],row['Event.PointIndex']
            cfg = self.configs[key]
            if key not in old_keys and key not in emitted:
                dictionaries.append(dict(kind='dictionary',bootId=self.boot,
                    configKey=list(key),config=cfg))
                emitted.add(key)
            # A repeated seq check plus final ring bounds also fences eviction
            # across the split dictionary read.
            if fences[base+'Event.SampleSeq'] != seq:
                raise EvidenceError('Capture changed while reading dictionary')
            captures.append(dict(kind='capture',bootId=self.boot,event=row,configKey=list(key)))
        associations = []
        end = min(before['CaptureBuffer.AssociationWriteSeq'],self.association+16,self.tail[1] if self.tail else 2**64-1)
        for seq in range(self.association+1,end+1):
            base = f'CaptureBuffer.Associations[{(seq-1)%32+1}].'
            names = ['Ordinal','MessageId','Digest','Count','ConfigSlot','ConfigGeneration','BatchGeneration','Category']
            raw = self.io.read([base+n for n in names])
            row = {n:raw[base+n] for n in names}
            if row['Ordinal'] != seq or not 1 <= row['Count'] <= 64:
                raise EvidenceError('Association overwritten/invalid')
            raw = self.io.read([base+f'SampleSeqs[{i}]' for i in range(1,row['Count']+1)])
            row['sampleSeqs'] = list(raw.values())
            if self.cohort and any(type(v) is not int or v<=0 or v>before['CaptureBuffer.AuditWriteSeq'] for v in row['sampleSeqs']):
                raise EvidenceError('Association references foreign source sequence')
            if self.cohort and any(v>self.capture+len(captures) for v in row['sampleSeqs']):break
            if self.io.read([base+'Ordinal'])[base+'Ordinal'] != seq:
                raise EvidenceError('Association changed during read')
            associations.append(dict(kind='association',bootId=self.boot,association=row))
        for slot,generation in {tuple(row['configKey'][:2]) for row in captures}:
            base=f'CaptureBuffer.Configs[{slot}].'
            fence=self.io.read([base+'Generation',base+'CaptureBootId'])
            if fence[base+'Generation']!=generation or fence[base+'CaptureBootId']!=self.boot:
                raise EvidenceError('Dictionary generation changed before durable publication')
        if v2:
            # Re-read every scalar across the split dictionary read, including the
            # final commit field; a same-terminal rewrite must not be acknowledged.
            again=self.io.read([f'CaptureBuffer.AuditEvents[{(seq-1)%512+1}].'+n for seq,row in batch for n in event_names])
            for seq,row in batch:
                base=f'CaptureBuffer.AuditEvents[{(seq-1)%512+1}].'
                if any(again[base+n]!=row[n] for n in event_names):raise EvidenceError('Decision facts changed before fsync; no ACK')
                self.facts_complete &= encoding_complete(row)
        diag = self.diagnostics()
        self.check(self.head())
        rows = dictionaries+captures+associations+([diag] if diag else [])
        if self.cohort and self.cohort.boundary is not None:
            for row in captures:row['within_source_window']=row['event']['Event.SampleSeq']<=self.cohort.boundary
        if self.cohort:self.cohort.accept(rows)
        if rows:
            self.journal.append(rows)  # Fsync must succeed before any ACK.
        if self.cohort:self.cohort.accept(rows,commit=True)
        if diag:
            snap=diag['snapshot']
            if (not snap['EvidenceComplete'] or snap['CounterOverflow']
                    or snap['AuditDropped'] or snap['AssociationDropped']):
                raise EvidenceError('Diagnostic completeness guard failed; no ACK')
            self.business_completeness = {
                'globalAccountingComplete':snap['AccountingComplete'],
                'restartLossUnknown':snap['RestartLossUnknown'],
                'gapDetailTruncated':snap['DetailTruncated']}
            self.diagnostic_revision = diag['snapshot']['Revision']
        if captures:
            sequence=captures[-1]['event']['Event.SampleSeq']
            self.acknowledge('Audit',sequence)
            self.capture=sequence
        if associations:
            sequence=associations[-1]['association']['Ordinal']
            self.acknowledge('Association',sequence)
            self.association=sequence
        return len(captures),len(associations)


