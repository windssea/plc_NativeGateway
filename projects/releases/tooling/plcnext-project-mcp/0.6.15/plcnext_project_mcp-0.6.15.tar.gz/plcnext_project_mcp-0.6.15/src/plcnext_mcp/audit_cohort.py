"""M13 finite source denominator; association coverage is not delivery proof."""
import re
import time
from .audit_collector import EvidenceError

class SourceCohort:
    def __init__(self):
        self.boundary=None;self.captures={};self.covered={};self.messages=set()
        self.reason=None
    def accept(self,rows,commit=False):
        captures=dict(self.captures);covered=dict(self.covered);messages=set(self.messages)
        for row in rows:
            if row['kind']=='capture':
                event=row['event'];seq=event['Event.SampleSeq']
                if type(seq) is not int or seq<=0 or event['Decision'] not in (1,2,3,4) or seq in captures:raise EvidenceError('Duplicate cohort capture')
                captures[seq]=(event['Decision'],event['Event.ConfigSlot'],event['Event.ConfigGeneration'])
            elif row['kind']=='association':
                a=row['association'];refs=a['sampleSeqs']
                if (a['Category'] not in (1,2) or not a['MessageId'] or a['MessageId'] in messages
                        or re.fullmatch('[0-9a-fA-F]{64}',a['Digest']) is None
                        or type(a['BatchGeneration']) is not int or a['BatchGeneration']<=0
                        or len(refs)!=a['Count'] or len(set(refs))!=len(refs)):
                    raise EvidenceError('Invalid/duplicate cohort batch identity')
                for seq in refs:
                    if (type(seq) is not int or seq not in captures or seq in covered
                            or captures[seq]!=(2,a['ConfigSlot'],a['ConfigGeneration'])):
                        raise EvidenceError('Foreign/duplicate association or configuration generation mismatch')
                    covered[seq]=a['Ordinal']
                messages.add(a['MessageId'])
        if commit:self.captures=captures;self.covered=covered;self.messages=messages
    def freeze(self,n):
        if self.boundary is not None:raise EvidenceError('Source boundary already frozen')
        self.boundary=n
    def report(self,capture,association):
        n=self.boundary
        admitted=sorted(seq for seq,value in self.captures.items() if n is not None and seq<=n and value[0]==2)
        missing=[seq for seq in admitted if seq not in self.covered]
        raw=n is not None and capture>=n
        return {'source_boundary':n,'exported_capture_end':capture,'exported_association_end':association,
            'admitted_source_count':len(admitted),'associated_source_count':len(admitted)-len(missing),
            'unassociated_source_seqs':missing,'source_decisions_complete':raw,
            'raw_prefix_complete':raw,'source_cohort_associations_complete':raw and not missing and self.reason is None,
            'outside_source_capture_range':[n+1,capture] if n is not None and capture>n else None,
            'business_delivery_verified':False,'closure_failure_reason':self.reason}

def close_source_window(exporter,policy,deadline,check):
    head=exporter.head();exporter.check(head)
    tracker=exporter.cohort;tracker.freeze(head['CaptureBuffer.AuditWriteSeq'])
    exporter.journal.append([{'kind':'sourceBoundary','bootId':exporter.boot,
        'source_boundary':tracker.boundary,'association_head_at_boundary':head['CaptureBuffer.AssociationWriteSeq'],
        'mode':'source_cohort'}])
    end=min(deadline,time.monotonic()+policy['tail_seconds'])
    try:
        while True:
            check()
            if time.monotonic()>=end:raise EvidenceError('Source cohort closure deadline')
            exporter.poll()
            result=tracker.report(exporter.capture,exporter.association)
            if result['source_cohort_associations_complete']:
                exporter.check(exporter.head());check()
                exporter.journal.append([{'kind':'sourceCohortEnd','bootId':exporter.boot,**result,**exporter.fact_metadata()}])
                return result
            time.sleep(policy['poll_interval_ms']/1000)
    except Exception as exc:
        tracker.reason=str(exc)[:512]
        raise
