# PUBLIC OFFLINE TEST FIXTURES

These certificates and the unencrypted server key are deliberately public test
fixtures. The key is disposable and must never be installed on a controller or
used by a real service. The CA signing keys are not retained.

The server name is the reserved `.invalid` name `offline-plc.invalid`. Tests do
not resolve it, open a socket, or connect to any endpoint. The certificates are
valid from 2020-01-01 through 2100-01-01 for stable local tests. Production trust,
time validation, certificate policy and key management must use real material.

Regeneration requires cryptography and the explicit helper
`tools/Generate-OfflineTlsFixtures.py`; runtime probes only require stdlib ssl.
The helper refuses to overwrite these existing fixtures.
