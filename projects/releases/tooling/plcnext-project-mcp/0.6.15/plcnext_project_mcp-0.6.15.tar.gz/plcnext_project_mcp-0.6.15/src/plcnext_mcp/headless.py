"""Bounded subprocess host for the installed ST syntax parser, independent of ACI."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import uuid

from .project import ProjectError, ProjectStore, sha


DEFAULT_INSTALL = r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0'
HOST = Path(__file__).parent / 'parser_host' / 'Invoke-HeadlessParser.ps1'
REQUIRED = ('Ade.Compiler.dll', 'Ade.CompilerImpl.dll', 'Ade.Compiler.ParsingImpl.dll',
            'Ade.Components.dll', 'Ade.Patterns.dll', 'Ade.Core.dll')


def parser_environment() -> dict:
    install = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', DEFAULT_INSTALL)).expanduser().resolve()
    shell = shutil.which('pwsh')
    missing = [name for name in REQUIRED if not (install / name).is_file()]
    return {'available': os.name == 'nt' and bool(shell) and not missing and HOST.is_file()
            and HOST.with_name('HeadlessParserProbe.cs').is_file(),
            'install_directory': str(install), 'powershell': shell, 'missing_assemblies': missing,
            'scope': 'ST worksheet syntax only; no type checking or code generation',
            'aci_used': False, 'whole_project_compiled': False}


def check_st(store: ProjectStore, project_id: str, pou_name: str) -> dict:
    environment = parser_environment()
    if not environment['available']:
        raise ProjectError('Headless ST parser unavailable: requires PowerShell 7 and the installed Engineer parser assemblies.')
    # Snapshot exactly one current revision. Later concurrent edits cannot change this input.
    pou = store.read_pou(project_id, pou_name)
    raw = pou['code'].encode('utf-8')
    if len(raw) > 2 * 1024 * 1024:
        raise ProjectError('ST input exceeds the 2 MiB parser limit.')
    job = store.root / project_id / 'checks' / uuid.uuid4().hex
    job.mkdir(parents=True)
    source, report_path = job / 'source.st', job / 'result.json'
    source.write_bytes(raw)
    command = [environment['powershell'], '-NoLogo', '-NoProfile', '-NonInteractive',
               '-File', str(HOST), '-Source', str(source), '-Output', str(report_path),
               '-WorkRoot', str(job), '-InstallDirectory', environment['install_directory'], '-Quiet']
    try:
        # No shell interpolation; the child only receives a generated ST file path.
        completed = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, timeout=30, creationflags=0x08000000)
    except subprocess.TimeoutExpired as exc:
        raise ProjectError('ST parser exceeded 30 seconds; the parser subprocess was terminated.') from exc
    except OSError as exc:
        raise ProjectError(f'Unable to start ST parser: {exc}') from exc
    if not report_path.is_file() or report_path.stat().st_size > 2 * 1024 * 1024:
        raise ProjectError('ST parser failed to return a bounded JSON report.')
    try:
        report = json.loads(report_path.read_text(encoding='utf-8-sig'))
    except (ValueError, UnicodeError) as exc:
        raise ProjectError('ST parser returned an invalid JSON report.') from exc
    if completed.returncode or report.get('status') != 'completed':
        detail = report.get('errors', [{}])[-1].get('message', 'Unknown parser host failure')
        raise ProjectError(f'ST parser failed: {str(detail)[:2000]}')
    parsed = report.get('parse', {})
    if (report.get('source_sha256') != sha(raw) or report.get('source_sha256_after') != sha(raw)
            or type(parsed.get('errors')) is not int or type(parsed.get('warnings')) is not int
            or parsed['errors'] < 0 or parsed['warnings'] < 0):
        raise ProjectError('ST parser report does not match this exact input.')
    return {key: pou[key] for key in ('project_id', 'revision', 'project_sha256', 'project_path',
                                     'code_sha256')} | {
        'pou_name': pou_name, 'stage': 'st_syntax', 'syntax_passed': parsed['errors'] == 0,
        'errors': parsed['errors'], 'warnings': parsed['warnings'],
        'messages': parsed.get('messages', []), 'messages_truncated': parsed.get('messages_truncated', False),
        'report_path': str(report_path),
        'aci_used': False, 'computer_use_used': False, 'compiled': False,
        'whole_project_compiled': False, 'controller_connected': False,
        'limitations': ['ST code worksheet syntax only; declarations, types, symbols, device configuration and code generation are not checked.',
                        'Requires installed Engineer parser assemblies; this is not a standalone compiler.'],
    }
