param(
    [Parameter(Mandatory)][string]$Source,
    [Parameter(Mandatory)][string]$Output,
    [string]$WorkRoot = (Join-Path $PSScriptRoot '..\..\..\artifacts\headless-research\managed'),
    [string]$InstallDirectory = 'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0',
    [switch]$Quiet
)
$ErrorActionPreference = 'Stop'
$probeRoot = [IO.Path]::GetFullPath($WorkRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
foreach ($candidate in @($Source, $Output)) {
    if (-not [IO.Path]::GetFullPath($candidate).StartsWith($probeRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Probe inputs and outputs must be inside the managed research workspace.'
    }
}
$installRoot = [IO.Path]::GetFullPath($InstallDirectory)
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Reflection;
public static class ParserOnlyResolver {
    public static string DirectoryPath;
    public static Assembly Resolve(object sender, ResolveEventArgs args) {
        var name = new AssemblyName(args.Name).Name;
        if (name.StartsWith("Ade.ApplicationControl", StringComparison.OrdinalIgnoreCase) ||
            name.IndexOf("License", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("CodeMeter", StringComparison.OrdinalIgnoreCase) >= 0 ||
            name.IndexOf("Wibu", StringComparison.OrdinalIgnoreCase) >= 0)
            throw new InvalidOperationException("Out-of-scope assembly requested: " + name);
        var path = Path.Combine(DirectoryPath, name + ".dll");
        return File.Exists(path) ? Assembly.LoadFrom(path) : null;
    }
}
'@
[ParserOnlyResolver]::DirectoryPath = $installRoot
$resolver = [ResolveEventHandler][ParserOnlyResolver]::Resolve
[AppDomain]::CurrentDomain.add_AssemblyResolve($resolver)
$result = [ordered]@{
    stage='structured_text_syntax_parser'; source=[IO.Path]::GetFullPath($Source)
    source_sha256=(Get-FileHash -LiteralPath $Source).Hash.ToLowerInvariant()
    whole_project_compiled=$false; aci_used=$false; controller_connected=$false
}
try {
    $refs = @('Ade.Compiler.dll','Ade.CompilerImpl.dll','Ade.Compiler.ParsingImpl.dll','Ade.Components.dll','Ade.Patterns.dll','Ade.Core.dll') | ForEach-Object { Join-Path $installRoot $_ }
    foreach ($reference in $refs) { [void][Reflection.Assembly]::LoadFrom($reference) }
    $refs += @('System.Linq.dll','System.Collections.dll','System.Runtime.dll')
    Add-Type -Path (Join-Path $PSScriptRoot 'HeadlessParserProbe.cs') -ReferencedAssemblies $refs -CompilerOptions '/nowarn:1701'
    $result.parse = [NativeParserProbe]::Parse([IO.File]::ReadAllText($Source), ([Uri]::new([IO.Path]::GetFullPath($Source))).AbsoluteUri)
    $result.status = 'completed'
}
catch {
    $result.status = 'failed'
    $result.errors = @()
    $errorItem = $_.Exception
    while ($null -ne $errorItem) {
        $result.errors += [ordered]@{type=$errorItem.GetType().FullName;message=$errorItem.Message;stack=$errorItem.StackTrace}
        $errorItem = $errorItem.InnerException
    }
}
finally {
    $result.source_sha256_after = (Get-FileHash -LiteralPath $Source).Hash.ToLowerInvariant()
    $result.loaded_assemblies = @([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -like 'Ade.*' } | ForEach-Object { $_.GetName().Name } | Sort-Object)
    [AppDomain]::CurrentDomain.remove_AssemblyResolve($resolver)
    $result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $Output -Encoding utf8
    if (-not $Quiet) { $result | ConvertTo-Json -Depth 12 }
}
if ($result.status -ne 'completed') { exit 2 }
