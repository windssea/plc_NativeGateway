"""Source-bound file/readback/Reset/Load workflow using the real socket client.

Operator receipts are consumed, never issued here. Local tests use the identical
client against an isolated literal-loopback peer. No automatic Stop, Start,
delete, retry, rollback, ACI or GUI is part of the reviewed full-load policy.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import ipaddress
import json
import os
import re
from pathlib import Path
import time
import uuid

from .controller_download_plan import review_package_snapshot, _strict_json, POLICY
from .controller_transport import (ControllerEndpoint, ControllerFailure, DownloadScope,
                                   TlsControllerClient, _AUTHORITY, FILE, PLC)
from .deployment_package import MANIFEST, _relative_path
from .deployment_plan import _file
from .download_simulation import _package_snapshot, file_batches
from .project import ProjectError, sha, xml
from .plc_state import METADATA, BUSY, stable_state
from .releases import release_operation
from .controller_download_plan import revalidate_download_review

APPROVAL_SCHEMA = 'plcnext-controller-download-operator-approval/v1'
APPROVED_ACTIONS = ['write_package_paths', 'sha512_readback', 'reset', 'load']


def _ordered_batches(files):
    # A partial transfer must not publish the new file manifest first. This
    # order is an application policy, not a claim about original Engineer order.
    data = {name: payload for name, payload in files.items() if name != MANIFEST}
    yield from file_batches(data)
    if MANIFEST in files:
        yield [(MANIFEST, files[MANIFEST])]


def _check_old_manifest(client, files):
    result = client.read_many([MANIFEST])
    if len(result) != 1 or result[0]['result'] != 0 or len(result[0]['data']) > 4 * 1024 * 1024:
        raise ControllerFailure('remote_inventory_unverified', 'An existing bounded PCWE manifest is required before real writes.')
    document = xml(result[0]['data'])
    entries = document.findall('./Files/File')
    if document.tag != 'ProjectManifestDocument' or document.get('schemaVersion') != '1.0' or not entries:
        raise ControllerFailure('remote_inventory_unverified', 'Unsupported remote PCWE manifest.')
    paths = [_relative_path(entry.get('path')) for entry in entries]
    if len(paths) > 4096 or len({path.casefold() for path in paths}) != len(paths):
        raise ControllerFailure('remote_inventory_unverified', 'Ambiguous remote PCWE manifest file set.')
    remote = set(paths) | {MANIFEST}
    extras = remote - set(files)
    source_archives = {p for p in extras if p == 'Src/Project.src'
        or re.fullmatch(r'Src/[^/\\]{1,128}\.pcweax', p)}
    def bounded(paths):
        rows=[];size=0
        for path in sorted(paths):
            n=len(path.encode('utf-8'))
            if len(rows)>=128 or size+n>8192:break
            rows.append(path);size+=n
        return {'paths':rows,'count':len(paths),'truncated':len(rows)!=len(paths)}
    comparison={'missing_on_target':bounded(set(files)-remote),
        'preserved_remote':bounded(source_archives),
        'unsupported_remote_extras':bounded(extras-source_archives),
        'directions':'missing_on_target=package minus remote manifest; extras=remote manifest minus package',
        'source_archive_limit_exceeded':sum(p.endswith('.pcweax') for p in source_archives)>1,
        'path_limit_per_category':128,'utf8_bytes_limit_per_category':8192,
        'remote_manifest_sha256':sha(result[0]['data'])}
    if (set(files)-remote or extras!=source_archives or sum(p.endswith('.pcweax') for p in source_archives)>1):
        exc=ControllerFailure('remote_file_set_changed','Remote managed file paths differ; old-file handling requires a new reviewed strategy.')
        exc.details=comparison
        if 'dlc.bin' in extras:
            exc.details['remediation']='Package omits existing dlc.bin. Rebuild offline with empty_capability_v1 and review again; no deletion or automatic policy change.'
        raise exc
    return {'declared_manifest_paths_match':not extras,'runtime_path_policy_satisfied':True,
        'preserved_remote_source_archive_paths':sorted(source_archives),
        'preserved_source_archives_match_new_runtime':'unverified','complete_remote_directory_listing':False,
        'remote_manifest_sha256':sha(result[0]['data']),'old_files_deleted':False,'path_comparison':comparison}


def _compare_files(client,files):
    local=ipaddress.ip_address(client.endpoint.address).is_loopback
    changed={};skipped=[]
    for batch in _ordered_batches(files):
        existing=client.read_many([name for name,_ in batch])
        if len(existing)!=len(batch):raise ControllerFailure('comparison_read_failed','Incomplete pre-write comparison results.')
        for (name,payload),actual in zip(batch,existing):
            identical=(actual['result']==0 and len(actual['data'])==len(payload)
                and hashlib.sha512(actual['data']).digest()==hashlib.sha512(payload).digest())
            if identical:skipped.append(name)
            elif '/SharedLibraries/' in name and name.endswith('.so') and (not local or actual['result']==0):
                raise ControllerFailure('native_library_update_requires_unloaded_runtime','Changed or unreadable native shared library requires a separately supported unloaded-runtime update: '+name)
            else:changed[name]=payload
    return changed,skipped



def execute_transfer(client: TlsControllerClient, files: dict[str, bytes], *,
                     credentials: tuple[str, str] | None = None,
                     poll_timeout_seconds: float = 30,
                     poll_interval_seconds: float = 0.1) -> dict:
    """Execute the fixed workflow; never infer ACK==completed or failure==undo."""
    if client.scope is None:
        raise ProjectError('An operator or loopback fixture scope is required before connecting.')
    client.scope.validate_files(files)
    if type(poll_timeout_seconds) not in (int, float) or not 0.1 <= poll_timeout_seconds <= 300:
        raise ProjectError('Configuration poll deadline must be 0.1..300 seconds.')
    if type(poll_interval_seconds) not in (int, float) or not 0.01 <= poll_interval_seconds <= 1:
        raise ProjectError('Configuration poll interval must be 0.01..1 second.')
    local = ipaddress.ip_address(client.endpoint.address).is_loopback
    result = {'status': 'running', 'stage': 'created', 'scope': client.scope.kind,
        'socket_transport_used': True, 'memory_bio_used': False,
        'peer_connected': False, 'controller_connected': False, 'controller_downloaded': False,
        'loopback_download_completed': False, 'files_verified': 0, 'bytes_verified': 0,
        'configuration_reset_attempted': False, 'configuration_reset_confirmed': False,
        'configuration_load_attempted': False, 'load_ack_received': False, 'load_state_verified': False,
        'stop_command_sent': False, 'start_command_sent': False, 'delete_command_sent': False,
        'automatic_retry': False, 'rollback_attempted': False, 'deployable': False,
        'aci_used': False, 'engineer_started': False, 'computer_use_used': False,
        'authentication_mode': 'password' if credentials is not None else 'anonymous',
        'target': {'address': client.endpoint.address, 'port': client.endpoint.port,
                   'certificate_sha256': client.endpoint.certificate_sha256}}

    def wait_for(expected, stage):
        end = time.monotonic() + poll_timeout_seconds
        while True:
            raw = client.get_state()
            result['last_state_raw'] = raw
            base, flags = raw & 63, raw & ~63
            if flags & ~(BUSY | METADATA):
                raise ControllerFailure('configuration_state_error', 'Controller reported error/unknown state flags during ' + stage + '.')
            if base == 3:
                result['unexpected_running_observed'] = True
                raise ControllerFailure('unexpected_running_after_load', 'Controller is Running; no automatic Stop is authorized.')
            if stable_state(raw, expected):
                return raw
            if base not in (0, 1, 2, 4):
                raise ControllerFailure('configuration_state_unknown', 'Unknown controller state during ' + stage + '.')
            if time.monotonic() >= end:
                raise ControllerFailure('configuration_timeout', 'Controller did not reach the required state during ' + stage + '.')
            time.sleep(min(poll_interval_seconds, max(0.0, end - time.monotonic())))

    try:
        result['stage'] = 'connecting'
        result['peer'] = client.connect()
        result.update(peer_connected=True, controller_connected=not local)
        if credentials is not None:
            result['stage'] = 'authenticating'
            client.authenticate(*credentials)
        result['stage'] = 'initial_state'
        initial = client.get_state()
        result['initial_state_raw'] = initial
        if not stable_state(initial, 2):
            raise ControllerFailure('initial_state_not_stopped', 'Download requires a fresh exact Stop state; no automatic Stop was sent.')
        result['stage'] = 'preflight'
        result['remote_project_root'] = client.resolve_root()
        if client.get_space() < sum(map(len, files.values())):
            raise ControllerFailure('insufficient_space', 'Insufficient controller space for the captured package.')
        if client.scope.kind != 'loopback_fixture':
            result['remote_inventory'] = _check_old_manifest(client, files)
        else:
            result['remote_inventory'] = {'fixture_owned_empty_directory': True,
                'remote_directory_listing_rpc_claimed': False, 'old_files_deleted': False}
        batches = list(_ordered_batches(files))
        # Do not truncate an unchanged shared object which the stopped runtime
        # may still have mapped. Compare the complete reviewed file set before
        # any write; native library changes require a separate unloaded policy.
        result['stage'] = 'comparing_files'
        changed,skipped=_compare_files(client,files)
        result.update(files_compared=len(files), files_skipped_identical=skipped,
            planned_written_paths=list(changed), files_written=0)
        result['stage'] = 'transferring'
        for batch in _ordered_batches(changed):
            errors = client.write_many(batch)
            if len(errors) != len(batch) or any(error != 0 for error in errors):
                raise ControllerFailure('file_write_failed', 'WriteMany returned an incomplete or failed per-file result.')
            result['files_written'] += len(batch)
        result['stage'] = 'readback'
        for batch in batches:
            responses = client.read_many([name for name, _ in batch])
            if len(responses) != len(batch):
                raise ControllerFailure('readback_failed', 'ReadMany returned an incomplete response.')
            for (name, expected), actual in zip(batch, responses):
                if (actual['result'] != 0 or len(actual['data']) != len(expected)
                        or hashlib.sha512(actual['data']).digest() != hashlib.sha512(expected).digest()):
                    raise ControllerFailure('readback_failed', 'SHA-512 readback mismatch for reviewed file: ' + name)
                result['files_verified'] += 1
                result['bytes_verified'] += len(expected)
        result['manifest_written_last'] = MANIFEST in changed
        result['manifest_unchanged_verified'] = MANIFEST in skipped
        result['stage'] = 'resetting'
        result['configuration_reset_attempted'] = True
        client.reset()
        wait_for(1, 'Reset')
        result['configuration_reset_confirmed'] = True
        result['stage'] = 'loading'
        result['configuration_load_attempted'] = True
        client.load()
        result['load_ack_received'] = True
        final = wait_for(2, 'Load')
        result.update(status='loopback_download_passed' if local else 'controller_download_completed',
            stage='loaded_stopped', load_state_verified=True, final_state_raw=final,
            loopback_download_completed=local, controller_downloaded=not local)
    except Exception as exc:
        result.update(status='transfer_failed', failure_code=getattr(exc, 'code', 'transport_or_codec_error'),
                      error_class=type(exc).__name__)
        if isinstance(exc, ControllerFailure):
            result['error'] = str(exc)
            if hasattr(exc,'details'):result['path_comparison']=exc.details
    finally:
        primary_status = result['status']
        result['cleanup_error_class'] = client.close()
        if result['cleanup_error_class'] is not None and primary_status != 'transfer_failed':
            # Preserve the load observation even if closing a password session failed.
            result.update(status='transfer_failed', failure_code='session_cleanup_failed')
        writes = [event for event in client.trace if event.get('service') == FILE
                  and event.get('method') == 8 and event.get('send_attempted')]
        mutations = [event for event in client.trace if event.get('mutating') and event.get('send_attempted')]
        uncertain = [event for event in mutations if not event.get('response_received')]
        configuration_unknown = ((result['configuration_reset_attempted'] and not result['configuration_reset_confirmed'])
                                 or (result['configuration_load_attempted'] and not result['load_state_verified']))
        result.update(files_may_have_changed=bool(writes), mutation_request_count=len(mutations),
            unacknowledged_mutation_requests=len(uncertain),
            configuration_outcome_unknown=configuration_unknown,
            outcome_unknown=bool(uncertain) or configuration_unknown,
            bytes_sent=client.bytes_sent, bytes_received=client.bytes_received,
            connection_closed=client.channel is None, trace=client.trace)
    return result


def _operator_scope(store, review, files, *, execution_id=None):
    """Consume an exact expiring one-use human or MCP authorization record.

    MCP can authorize with project_authorize_controller_operation. A review's hash/ID is only a selector,
    never a write capability. This function is called before any socket exists.
    """
    digest = review['review_sha256']
    path = _file(store.root, 'controller-download-approvals/' + digest + '.json')
    if not path.is_file() or path.stat().st_size > 64 * 1024:
        raise ControllerFailure('user_confirmation_required', 'No separate operator approval exists for this exact version/impact review.')
    raw = path.read_bytes()
    if len(raw) > 64 * 1024:
        raise ControllerFailure('user_confirmation_required', 'Oversized operator approval record.')
    record = _strict_json(raw)
    target = review['target']
    expected = {
        'schema': APPROVAL_SCHEMA, 'review_sha256': digest, 'confirmed_by': 'human_user',
        'target': target, 'project_sha256': review['source']['project_sha256'],
        'inventory_sha256': review['package']['inventory_sha256'], 'policy': POLICY,
        'approved_actions': APPROVED_ACTIONS, 'preserved_unlisted_remote_files_acknowledged': True,
    }
    if type(record) is dict and record.get('confirmed_by') == 'mcp_policy':
        from .operator_approval import download_approval_contract, validate_operator_receipt
        contract = download_approval_contract(store, review['project_id'], review['review_id'], digest)
        validate_operator_receipt(record, contract)
        expected.update(schema=APPROVAL_SCHEMA.replace('-operator-approval/v1', '-mcp-approval/v1'),
                        confirmed_by='mcp_policy')
    if (type(record) is not dict or any(record.get(key) != value for key, value in expected.items())
            or type(record.get('confirmation_reference')) is not str or not record['confirmation_reference'].strip()):
        raise ControllerFailure('user_confirmation_required', 'Operator approval does not match the exact target, bytes and reviewed effects.')
    try:
        confirmed = datetime.fromisoformat(record['confirmed_utc'])
        expires = datetime.fromisoformat(record['expires_utc'])
        now = datetime.now(timezone.utc)
        if (confirmed.tzinfo is None or expires.tzinfo is None or not confirmed <= now < expires
                or (expires - confirmed).total_seconds() > 3600):
            raise ValueError('expired or excessive approval window')
    except (KeyError, ValueError, TypeError) as exc:
        raise ControllerFailure('approval_expired', 'Operator approval has expired or has invalid timing.') from exc
    # Exclusive persistent claim means a timeout or crash cannot silently reuse
    # approval. Recovery/reapproval is an explicit operator action.
    claim = path.with_suffix('.claimed.json')
    try:
        descriptor = os.open(claim, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ControllerFailure('approval_already_consumed', 'This operator approval was already claimed; automatic retries are forbidden.') from exc
    with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
        json.dump({'review_sha256': digest, 'claimed_utc': now.isoformat(),
                   'approval_sha256': sha(raw), 'execution_id': execution_id}, stream)
        stream.flush()
        os.fsync(stream.fileno())
    if path.read_bytes() != raw:
        raise ControllerFailure('approval_changed', 'Operator approval changed while it was being claimed.')
    endpoint = ControllerEndpoint(target['address'], target['port'], target['expected_certificate_sha256'])
    return DownloadScope(endpoint, files, 'mcp_authorized' if record['confirmed_by'] == 'mcp_policy' else 'operator_confirmed', authority=_AUTHORITY,
                         review_sha256=digest)


@release_operation(revalidate_download_review)
def execute_reviewed_download(store, project_id, review_id, expected_review_sha256):
    """Guarded real-device route; no receipt means no network request at all."""
    review, files = review_package_snapshot(store, project_id, review_id, expected_review_sha256)
    execution_id = uuid.uuid4().hex
    job = _file(store._folder(project_id), 'controller-transfers/' + execution_id)
    lease = _claim_endpoint_lease(review, job)
    lease_bytes = lease.read_bytes()
    authorized = False
    release_lease = False
    result = None
    try:
        scope = _operator_scope(store, review, files, execution_id=execution_id)
        authorized = True
        job.mkdir(parents=True, exist_ok=False)
        journal = job / 'journal.jsonl'
        sink = _journal_sink(journal)
        sink({'operation': 'ExecutionBinding', 'execution_id': execution_id,
              'review_sha256': expected_review_sha256, 'project_id': project_id,
              'project_sha256': review['source']['project_sha256'],
              'inventory_sha256': review['package']['inventory_sha256'], 'target': review['target']})
        client = TlsControllerClient(scope.endpoint, scope=scope, event_sink=sink)
        result = execute_transfer(client, files)
        result.update(project_id=project_id, review_id=review_id, review_sha256=expected_review_sha256,
                      project_sha256=review['source']['project_sha256'],
                      inventory_sha256=review['package']['inventory_sha256'], journal_path=str(journal))
        result['endpoint_lease_path'] = str(lease)
        release_lease = not (result['status'] == 'transfer_failed' and result['mutation_request_count'])
        result['endpoint_lease_retained'] = not release_lease
        _persist_result(job / 'result.json', result, sink)
        if not result.get('receipt_persisted'):
            release_lease = False
            result['endpoint_lease_retained'] = True
        return result
    finally:
        # Missing/invalid approval never starts a session and releases this
        # temporary lease. Any crash/uncertain mutation keeps it for recovery.
        if not authorized or release_lease:
            try:
                from .endpoint_guard import endpoint_guard
                with endpoint_guard(lease):
                    if lease.read_bytes() != lease_bytes or lease.with_suffix('.reconciliation.json').exists():
                        raise OSError('Endpoint lease changed during cleanup.')
                    lease.unlink()
            except OSError as exc:
                if result is not None:
                    result.update(endpoint_lease_retained=True, endpoint_lease_cleanup_error_class=type(exc).__name__)
                    try:
                        _journal_sink(job / 'journal.jsonl')({'operation': 'EndpointLeaseCleanupFailed',
                            'endpoint_lease_path': str(lease), 'error_class': type(exc).__name__})
                    except OSError:
                        pass


def _endpoint_lease_root():
    return Path.home() / '.plcnext-mcp' / 'controller-endpoint-leases'


def _claim_endpoint_lease(review, job):
    # Shared across MCP workspaces/processes for this OS user. The key omits
    # the pin so two different certificate expectations cannot race one device.
    root = _endpoint_lease_root()
    root.mkdir(parents=True, exist_ok=True)
    target = review['target']
    key = sha((target['address'] + ':' + str(target['port'])).encode('utf-8'))
    path = _file(root, key + '.json')
    from .endpoint_guard import endpoint_guard
    with endpoint_guard(path):
        if path.with_suffix('.reconciliation.json').exists():
            raise ControllerFailure('endpoint_reconciliation_pending', 'An interrupted reconciliation must finish first.')
        try:
            descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as exc:
            raise ControllerFailure('endpoint_busy_or_quarantined',
                'The target is in use or requires recovery after an uncertain download: ' + str(path)) from exc
        with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
            json.dump({'target': target, 'review_sha256': review['review_sha256'],
                       'job_directory': str(job), 'claimed_utc': datetime.now(timezone.utc).isoformat()}, stream)
            stream.flush()
            os.fsync(stream.fileno())
    return path


def _persist_result(path, result, sink):
    result.update(report_path=str(path), receipt_persisted=True)
    try:
        with path.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
    except OSError as exc:
        # A local receipt failure does not undo verified file/load side effects.
        result.update(receipt_persisted=False, receipt_error_class=type(exc).__name__)
    try:
        sink({'operation': 'ExecutionOutcome', **{key: result.get(key) for key in (
            'status', 'stage', 'controller_downloaded', 'loopback_download_completed',
            'files_may_have_changed', 'configuration_load_attempted', 'load_state_verified',
            'outcome_unknown', 'receipt_persisted', 'receipt_error_class')}})
    except OSError as exc:
        result['journal_terminal_error_class'] = type(exc).__name__


def _journal_sink(path):
    def append(event):
        with path.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps({'observed_utc': datetime.now(timezone.utc).isoformat(), **event}) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
    return append


def test_controller_download_client(store, project_id, expected_project_sha256, package_job_id, fault='none'):
    """Run the real production socket client against an owned loopback peer only."""
    from .controller_test_peer import LocalTlsController
    folder = store._folder(project_id)
    with store._lock(folder):
        _, _, package, raw, receipt, inventory, bindings, files = _package_snapshot(
            store, project_id, expected_project_sha256, package_job_id)
        job = _file(folder, 'controller-client-tests/' + uuid.uuid4().hex)
        job.mkdir(parents=True, exist_ok=False)
        with LocalTlsController(job / 'peer-files', allowed_files=set(files), fault=fault) as peer:
            endpoint = ControllerEndpoint(peer.address, peer.port, peer.certificate_sha256)
            scope = DownloadScope.loopback_fixture(endpoint, files)
            journal = job / 'journal.jsonl'
            _journal_sink(journal)({'operation': 'ExecutionBinding', 'scope': 'loopback_fixture',
                'project_id': project_id, 'project_sha256': expected_project_sha256,
                'inventory_sha256': inventory['inventory_sha256'], 'package_job_id': package_job_id,
                'target': {'address': endpoint.address, 'port': endpoint.port,
                           'certificate_sha256': endpoint.certificate_sha256}})
            result = execute_transfer(TlsControllerClient(endpoint, scope=scope,
                                      event_sink=_journal_sink(journal)), files,
                                      poll_timeout_seconds=0.5)
            result.update(peer_files_match_package=peer.snapshot() == files, peer_loaded=peer.loaded,
                peer_reset_calls=peer.reset_calls, peer_load_calls=peer.load_calls,
                peer_stop_calls=peer.stop_calls, peer_file_write_calls=peer.write_calls,
                peer_file_read_calls=peer.read_calls, test_fault=fault)
            if result['status'] == 'loopback_download_passed' and not result['peer_files_match_package']:
                result.update(status='transfer_failed', failure_code='fixture_inventory_mismatch')
            result['journal_path'] = str(journal)
        result['peer_thread_stopped'] = not peer.thread_alive
        # Recheck local source/package identity after all real socket activity.
        _package_snapshot(store, project_id, expected_project_sha256, package_job_id)
        if (package / 'result.json').read_bytes() != raw:
            raise ProjectError('Package receipt changed during the loopback client test.')
        result.update(project_id=project_id, project_sha256=expected_project_sha256,
                      package_job_id=package_job_id, inventory_sha256=inventory['inventory_sha256'],
                      local_source_and_package_unchanged=True,
                      variable_count=bindings['variable_count'], fb_instance_count=bindings['fb_instance_count'])
        _persist_result(job / 'result.json', result, _journal_sink(journal))
        return result
