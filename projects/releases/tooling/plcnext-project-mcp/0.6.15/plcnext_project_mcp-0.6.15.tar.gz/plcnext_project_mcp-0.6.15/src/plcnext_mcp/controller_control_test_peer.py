"""Literal-loopback TLS peer for independent Stop/Start production client tests.

State effects are synthetic. The tagged message bytes are oracle measured.
No external endpoint/bind port, credentials, file or variable methods exist.
"""
from __future__ import annotations

import secrets

from . import rsc_tagged_codec as tagged
from .controller_test_peer import LocalTlsController
from .controller_transport import PLC, PROVIDER
from .rsc_codec import CommandType, DATA_TAGGING, DATAGRAMMING, SECURE, decode_header
from .rsc_error_codec import encode_error

CONTROL_FAULTS = frozenset(('none', 'reply_lost', 'state_delayed', 'state_timeout',
                            'state_error', 'disconnect_after_ack', 'rpc_error', 'hot_metadata', 'warm_metadata'))
CONTROL_SCHEMAS = {2: (['byte', 'bool'], []), 3: (['bool'], []), 5: ([], ['uint32'])}


class LocalTlsControlPeer(LocalTlsController):
    def __init__(self, root, *, fault='none', initial_state=3, response_fragment_bytes=None):
        if fault not in CONTROL_FAULTS:
            raise ValueError('Unknown control fixture fault.')
        super().__init__(root, fault='none', initial_state=initial_state,
                         allowed_files=set(), response_fragment_bytes=response_fragment_bytes)
        self.control_fault = fault
        self.start_calls = 0
        self.control_calls = 0
        self._pending_state = None
        self._polls_remaining = 0

    def _session(self, channel):
        connected = False
        handle = secrets.randbelow(10000) + 101
        provider = secrets.randbelow(10000) + 101
        service_discovered = False
        while not self._stop.is_set():
            raw = self._exact(channel, 16)
            if raw[1] & SECURE:
                raw += self._exact(channel, 4)
            header, token = decode_header(raw, require_checksum=True)
            if header.command_type == CommandType.CONNECT_REQUEST:
                if (connected or token is not None or header.version != 4
                        or header.flags != DATA_TAGGING | DATAGRAMMING
                        or any((header.data_length, header.service_handle, header.method_handle, header.service_provider_handle))):
                    raise ValueError('Unexpected control fixture Connect profile.')
                connected = True
                self._record('Connect', data_tagging=True, datagramming=False)
                self._reply(channel, tagged.encode_connect_confirmation())
                continue
            if not connected:
                raise ValueError('Control request before Connect.')
            if header.command_type == CommandType.GET_SERVICE_HANDLES_REQUEST:
                if not 0 <= header.data_length <= 2054:
                    raise ValueError('Unbounded service name.')
                names = tagged.decode_get_service(raw + self._exact(channel, header.data_length))
                if names != (PROVIDER, PLC):
                    raise ValueError('Control peer admits only PLC manager service.')
                service_discovered = True
                self._record('GetServiceHandles', service=PLC, handle=handle, provider_handle=provider)
                self._reply(channel, tagged.encode_get_service_confirmation(handle, provider))
                continue
            schema = CONTROL_SCHEMAS.get(header.method_handle)
            if (not service_discovered or header.command_type != CommandType.INVOKE_REQUEST
                    or header.version != 4 or header.flags != DATA_TAGGING or header.data_length
                    or (header.service_handle, header.service_provider_handle) != (handle, provider)
                    or token is not None or schema is None):
                raise ValueError('Unexpected control fixture method/profile.')
            values = tagged.receive_values(lambda count: channel.recv(count), schema[0])
            self._record('Invoke', service=PLC, method=header.method_handle, tagged=True)
            if header.method_handle == 5:
                if self._pending_state is not None:
                    if self._polls_remaining:
                        self._polls_remaining -= 1
                    else:
                        self.state, self._pending_state = self._pending_state, None
                result = [self.state]
            else:
                if (header.method_handle == 3 and values != [True]) or (
                        header.method_handle == 2 and (values[0] not in (1, 2, 3, 4) or values[1] is not True)):
                    raise ValueError('Unexpected explicit start kind or async flag.')
                if self.control_fault == 'rpc_error':
                    self._reply(channel, encode_error(handle, header.method_handle, 0xF003,
                        'PUBLIC synthetic control denied.', provider_handle=provider))
                    continue
                self.control_calls += 1
                if header.method_handle == 3:
                    self.stop_calls += 1
                    terminal = 2
                else:
                    self.start_calls += 1
                    terminal = 3
                self._record('ControlEffect', method=header.method_handle, start_kind=values[0] if header.method_handle == 2 else None)
                if self.control_fault in ('hot_metadata', 'warm_metadata'):
                    self.state = terminal | (0x20000 if self.control_fault == 'hot_metadata' else 0x100000)
                elif self.control_fault == 'state_delayed':
                    self.state = 0x2000 | self.state
                    self._pending_state, self._polls_remaining = terminal, 3
                elif self.control_fault == 'state_error':
                    self.state = 0x80000000 | self.state
                elif self.control_fault != 'state_timeout':
                    self.state = terminal
                if self.control_fault == 'reply_lost':
                    raise EOFError('Synthetic reply loss after control effect.')
                result = []
            self._reply(channel, tagged.encode_response(handle, header.method_handle,
                schema[1], result, provider_handle=provider))
            if header.method_handle != 5 and self.control_fault == 'disconnect_after_ack':
                raise EOFError('Synthetic disconnect after control ACK.')
