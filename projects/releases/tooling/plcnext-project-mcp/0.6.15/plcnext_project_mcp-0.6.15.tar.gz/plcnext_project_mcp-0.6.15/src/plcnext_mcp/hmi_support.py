"""Source-derived support files for the investigated Engineer 2026 HMI profile.

Page/localization compilation is a separate input. No generated GUI directory is
read here. Runtime dictionaries use the freshly finalized (nonzero) IEC layouts.
This is deliberately a bounded profile, not a general HMI compiler.
"""
from __future__ import annotations

import html
import json
from pathlib import Path, PurePosixPath
import re
import struct
from urllib.parse import unquote
from uuid import UUID
import zlib

from .pcwe_auxiliary import _hardware_profile, SUPPORTED_HARDWARE_PROFILE_SHA256
from .project import ProjectError, decode_code, sha, xml
from .runtime_configuration import generate_runtime_configuration

SCHEMA = 'http://json-schema.org/draft-0/schema#'
PREFIX = 'Services/Ehmi/ehmi/'
STATIC_ASSETS = ('connectionError.png', 'downarrow.svg', 'error.png', 'favicon.png',
    'hmiapp.css', 'hmiapp.html', 'hmiapp.legacy.min.js', 'hmiapp.min.js',
    'leftarrow.svg', 'loading-sm.gif', 'loading.gif', 'loadingSpriteSheet.png',
    'rightarrow.svg', 'uparrow.svg')
UNLISTED_ASSETS = {'hmiapp.css', 'hmiapp.html', 'hmiapp.legacy.min.js', 'hmiapp.min.js'}
LANGUAGES = {'languages-static.dictionary.json', 'languages-dynamic.dictionary.json'}
HMI_COMPILER_SHA256 = 'ca08b8e504ea03db6ead7de033a15c2e7a3fd4bcd34895fec504d4987bf55a3e'

# Ade.Alarming.DataList.AlarmListEntry properties and AlarmViewTypeSupport mapping.
# The misspelling is the vendor HmiDataDictionaryWriter wire representation.
ALARM_FIELDS = (('AlarmId', 'WSTRING'), ('ConditionVariableName', 'WSTRING'),
    ('State', 'WSTRING'), ('ActiveState', 'BOOL'), ('ActiveStateChanged', 'LDATE_AND_TIME'),
    ('Description', 'WSTRING'), ('Priority', 'UINT'), ('AlarmType', 'WSTRING'),
    ('SourceName', 'WSTRING'), ('Group', 'WSTRING'), ('Message', 'WSTRING'),
    ('Condition', 'WSTRING'), ('ConditionValue', 'WSTRING'), ('AckedState', 'BOOL'),
    ('AckedStateChanged', 'LDATE_AND_TIME'), ('AcknowledgeRequired', 'BOOL'),
    ('ConfirmedState', 'BOOL'), ('ConfirmedStateChanged', 'LDATE_AND_TIME'),
    ('ConfirmRequired', 'BOOL'), ('Comment', 'WSTRING'), ('SuppressedState', 'BOOL'),
    ('SuppressedStateChanged', 'LDATE_AND_TIME'), ('SuppressVariableName', 'WSTRING'),
    ('SuppressAllowed', 'BOOL'), ('User', 'WSTRING'))


def _require(value, message):
    if not value:
        raise ProjectError(message)


def _json(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).replace('/', '\\/').encode('utf-8')


def _document(title, **values):
    return {'$schema': SCHEMA, 'title': title, **values}


def _one(members, suffix):
    names = [name for name in members if name.endswith(suffix)]
    _require(len(names) == 1, 'HMI support requires exactly one source ' + suffix)
    return names[0]


def _local_name(tag):
    return tag.rsplit('}', 1)[-1]


def _child(node, name):
    values = [x.text or '' for x in node if _local_name(x.tag) == name]
    _require(len(values) <= 1, 'Duplicate HMI project metadata ' + name)
    return values[0] if values else ''


def type_closure(information: dict, roots: list[str]) -> list[dict]:
    """Vendor DFS ordering, with explicit validation of finalized field layouts."""
    source = information.get('Types', [])
    _require(isinstance(source, list) and source, 'Missing finalized HMI runtime types.')
    by_name = {item['Name']: item for item in source}
    _require(len(by_name) == len(source), 'Duplicate finalized HMI type name.')
    output, visited, active = [], set(), set()

    def visit(name):
        if name in visited:
            return
        _require(name in by_name and name not in active, 'Missing or recursive HMI runtime type: ' + name)
        item = by_name[name]
        active.add(name)
        for key in ('RuntimeSize', 'RuntimeAlignment'):
            _require(type(item.get(key)) is int and item[key] > 0,
                     'HMI requires finalized nonzero runtime layout: ' + name)
        _require(isinstance(item.get('RuntimeType'), str) and item['RuntimeType'], 'Missing runtime type identity.')
        kind = item.get('Kind')
        _require(kind in ('Elementary', 'UserString', 'Structure', 'Array'),
                 'Unsupported HMI runtime type kind: ' + str(kind))
        result = {k: item[k] for k in ('Name', 'RuntimeType', 'RuntimeSize', 'RuntimeAlignment', 'Kind')}
        if kind == 'Structure':
            fields = item.get('Fields')
            _require(isinstance(fields, list) and fields, 'Missing HMI structure fields: ' + name)
            _require(len({f['Name'] for f in fields}) == len(fields), 'Duplicate HMI field name.')
            end = 0
            for field in fields:
                visit(field['FieldType'])
                offset = field.get('FieldOffset')
                _require(type(offset) is int and offset >= end, 'Invalid or overlapping HMI field offset.')
                end = offset + by_name[field['FieldType']]['RuntimeSize']
                _require(end <= item['RuntimeSize'], 'HMI field lies outside finalized structure.')
            result['Fields'] = [{k: f[k] for k in ('Name', 'FieldType', 'FieldOffset')} for f in fields]
        elif kind == 'UserString':
            _require(type(item.get('Capacity')) is int and item['Capacity'] >= 0 and
                     type(item.get('HeaderSize')) is int and 0 < item['HeaderSize'] < item['RuntimeSize'],
                     'Invalid finalized HMI string layout.')
            result.update(Capacity=item['Capacity'], HeaderSize=item['HeaderSize'])
        elif kind == 'Array':
            visit(item['ElementType'])
            dimensions = item.get('Dimensions')
            _require(isinstance(dimensions, list) and dimensions, 'Missing HMI array dimensions.')
            count = 1
            for dimension in dimensions:
                _require(type(dimension.get('StartIndex')) is int and type(dimension.get('Length')) is int
                         and dimension['Length'] > 0, 'Invalid HMI array dimension.')
                count *= dimension['Length']
            _require(count * by_name[item['ElementType']]['RuntimeSize'] == item['RuntimeSize'],
                     'HMI array size disagrees with finalized element layout.')
            result.update(ElementType=item['ElementType'], Dimensions=[{k: d[k] for k in ('StartIndex', 'Length')} for d in dimensions])
        active.remove(name)
        visited.add(name)
        output.append(result)

    for root in roots:
        visit(root)
    return output


def hmi_checksums(files: dict[str, bytes], project_id: str) -> tuple[dict, dict]:
    """Generate the vendor checksum at its pre-textlist/image-list build stage."""
    excluded = UNLISTED_ASSETS | {'textlist.json', 'imagelist.json', 'project.checksum.json', 'project.checksum-full.json'}
    records, combined = [], 0
    # Output filenames in the bounded profile are ASCII: Python ordering equals
    # .NET CompareOrdinal. Checksums cover the bytes actually returned here.
    for name in sorted(files):
        _require(name.isascii() and '/' not in name and '\\' not in name, 'Unsupported HMI output filename.')
        if name in excluded:
            continue
        checksum = zlib.crc32(files[name])
        records.append({'file': name, 'checksum': checksum})
        combined = zlib.crc32(struct.pack('<I', checksum), combined)
    summary = {'id': project_id, 'checksum': combined}
    return summary, dict(summary, files=records)


def _application_variables(payload):
    root = xml(payload)
    _require(root.tag == 'HmiVariables' and [x.tag for x in root] == ['System'],
             'Only the verified HMI application System variables are supported.')
    variables = []
    for node in root[0]:
        _require(node.tag == 'Variable' and node.get('IsReadOnly') in ('true', 'false'),
                 'Unsupported application variable declaration.')
        name, dtype = node.get('Name'), node.get('DataType')
        _require(name and re.fullmatch(r'[A-Za-z_]\w*', name) and dtype in ('STRING', 'UINT', 'LDATE_AND_TIME'),
                 'Unsupported HMI application variable type/name.')
        variable = {'name': '@@' + name, 'type': dtype}
        if 'InitValue' in node.attrib:
            initial = node.get('InitValue')
            _require((dtype == 'STRING' and initial == "''") or (dtype == 'UINT' and initial == '0'),
                     'Unsupported HMI application initializer.')
            variable['initValue'] = '' if dtype == 'STRING' else initial
        if node.get('IsReadOnly') == 'true':
            variable['readOnly'] = True
        variables.append(variable)
    _require(len({v['name'] for v in variables}) == len(variables), 'Duplicate HMI application variable.')
    expected = ['ClientNow', 'StationID', 'StationNum', 'ProjectName', 'ActivePage', 'LanguageCode',
                'CurrentUserName', 'SystemUseNotification']
    _require([v['name'] for v in variables] == ['@@' + n for n in expected], 'Unknown HMI system variable profile.')
    return {'variables': variables}


def _data_dictionary(members, information, runtime_report):
    # Recompute mapping from source instead of trusting caller-provided paths.
    _, checked = generate_runtime_configuration(members, ownership_contract=runtime_report.get('ownership_contract'))
    _require(runtime_report.get('hmi_mappings') == checked['hmi_mappings'] and
             runtime_report.get('source_hashes') == checked['source_hashes'],
             'HMI runtime mapping report does not match current source.')
    source = decode_code(members[_one(members, '/GlobalVariables.var')])
    source = re.sub(r'\(\*.*?\*\)', '', source, flags=re.S)
    source = re.sub(r'//[^\r\n]*', '', source)
    declarations = {}
    for part in source.split(';'):
        matches = re.findall(r'(?m)^\s*([A-Za-z_]\w*)\s*:\s*([A-Za-z_]\w*)\b(.*)', part)
        for name, dtype, tail in matches:
            declarations[name] = (dtype, tail)
    variables = {'Arp.Plc.Eclr/ESM_DATA.ESM_INFOS[1].TICK_COUNT':
                 {'Type': 'DINT', 'InitValue': '0', 'ReadOnly': True}}
    roots = ['DINT']
    by_name = {item['Name']: item for item in information['Types']}
    for mapping in checked['hmi_mappings']:
        name, dtype = mapping['name'], mapping['data_type']
        _require(name in declarations and declarations[name][0] == dtype, 'Missing HMI global declaration.')
        tail = re.sub(r'\{[^{}]*\}', '', declarations[name][1]).strip()
        _require(not tail, 'Explicit HMI global initializers are not yet supported.')
        _require(dtype in by_name, 'Missing HMI tag runtime type.')
        if dtype == 'BOOL':
            initial = 'FALSE'
        elif dtype == 'INT':
            initial = 'INT#0'
        elif by_name[dtype]['Kind'] == 'Structure':
            initial = ''
        else:
            raise ProjectError('Unverified HMI tag default initializer type: ' + dtype)
        _require(mapping['read_only'] in ('True', 'False'), 'Unknown HMI read-only mapping flag.')
        item = {'Type': dtype, 'InitValue': initial}
        if mapping['read_only'] == 'True':
            item['ReadOnly'] = True
        path = 'Arp.Plc.Eclr/' + name
        _require(path not in variables, 'Duplicate HMI runtime variable path.')
        variables[path] = item
        roots.append(dtype)
    types = type_closure(information, roots)
    types.append({'Name': 'AlarmViewEntry', 'Kind': 'Stucture',
                  'Fields': [{'Name': n, 'FieldType': t} for n, t in ALARM_FIELDS]})
    return _document('DataDictionary', HmiVariables2=variables), _document('TypeDictionary', Types=types)


def _heartbeat_view(information, runtime_report):
    types = {t['Name']: t for t in information['Types']}
    globals_ = [v for v in runtime_report['variables'] if v['name'] == 'ESM_DATA']
    _require(len(globals_) == 1 and globals_[0]['data_type'] == 'ESM_DAT', 'Unverified HMI heartbeat global.')
    try:
        outer = next(f for f in types['ESM_DAT']['Fields'] if f['Name'] == 'ESM_INFOS')
        array = types[outer['FieldType']]
        count = runtime_report.get('esm_count', 2)
        _require(type(count) is int and 1 <= count <= 16 and array['Kind'] == 'Array'
                 and array['Dimensions'] == [{'StartIndex': 1, 'Length': count}],
                 'Unverified HMI heartbeat array layout.')
        element = types[array['ElementType']]
        field = next(f for f in element['Fields'] if f['Name'] == 'TICK_COUNT')
        _require(field['FieldType'] == 'UDINT' and types['UDINT']['RuntimeSize'] == types['DINT']['RuntimeSize'] == 4,
                 'Unverified HMI heartbeat 32-bit view.')
        _require(0 <= field['FieldOffset'] <= element['RuntimeSize'] - 4 and
                 array['RuntimeSize'] == count * element['RuntimeSize'] and
                 0 <= outer['FieldOffset'] <= types['ESM_DAT']['RuntimeSize'] - array['RuntimeSize'],
                 'Unfinalized HMI heartbeat layout.')
    except (KeyError, StopIteration, TypeError) as exc:
        raise ProjectError('Missing finalized HMI heartbeat layout.') from exc
    return {'path': 'Arp.Plc.Eclr/ESM_DATA.ESM_INFOS[1].TICK_COUNT',
            'hmi_type': 'DINT', 'source_field_type': 'UDINT', 'storage_bytes': 4,
            'offset_from_global': outer['FieldOffset'] + field['FieldOffset'],
            'rule': 'vendor constant in HmiDataDictionaryWriter.BuildTypeAndDataDictionaries, token 0x06000925'}


def generate_hmi_support(project_members: dict[str, bytes], finalized_type_info: dict,
                         runtime_report: dict, page_files: dict[str, bytes],
                         install: Path, project_name: str) -> tuple[dict[str, bytes], dict]:
    """Return the complete PCWE-relative HMI tree and its offline provenance.

    Caller must bind page_files and finalized_type_info to this exact successful
    cold job. Language dictionaries must come from the same fresh page pass.
    This function validates source mappings and closes all output/checksum lists.
    """
    profile, _, hardware_hashes = _hardware_profile(project_members)
    from .device_profiles import device_profile
    _require(profile == device_profile(project_members)['hardware_sha256'], 'Unsupported HMI hardware/service profile.')
    _require(isinstance(project_name, str) and project_name and len(project_name) <= 255 and
             all(ord(c) >= 32 for c in project_name), 'Invalid HMI project title.')
    install = Path(install)
    compiler = install / 'Ade.Hmi.CompilerImpl.dll'
    _require(compiler.is_file() and not compiler.is_symlink() and sha(compiler.read_bytes()) == HMI_COMPILER_SHA256,
             'HMI support requires the verified Engineer 2026 compiler installation.')
    source_hashes = dict(hardware_hashes)
    manifest_name = _one(project_members, '/PROJECT.proj')
    project = xml(project_members[manifest_name])
    pages = [n for n in project.iter() if _local_name(n.tag) == 'HmiPage']
    _require({_child(p, 'DisplayName') for p in pages} == {'Gateway', 'Login'} and len(pages) == 2,
             'Only the investigated Gateway/Login HMI application is supported.')
    home = [_child(p, 'DisplayName').lower() + '.json' for p in pages if _child(p, 'StartPage') == 'True']
    _require(len(home) == 1, 'HMI needs exactly one source start page.')
    unsupported = [n for n in project.iter() if 'Include' in n.attrib and
                   any(k in _local_name(n.tag).lower() for k in ('textlist', 'imagelist', 'hmisymbol'))]
    _require(not unsupported, 'HMI symbols or nonempty image/text lists are unsupported.')
    navigation_name = _one(project_members, '/Application/Navigation.hminav')
    navigation = xml(project_members[navigation_name])
    _require(len(navigation) == 0 and not navigation.attrib, 'Custom HMI navigation is unsupported.')
    core_name = _one(project_members, '/Core.xml')
    core = xml(project_members[core_name])
    ids = [n.text for n in core.iter() if _local_name(n.tag) == 'identifier']
    _require(len(ids) == 1, 'Missing HMI source project identity.')
    try:
        project_id = str(UUID(ids[0]))
    except (ValueError, TypeError) as exc:
        raise ProjectError('Invalid HMI project UUID.') from exc
    expected = {'gateway.json', 'gateway.variables.json', 'gatewayModule.js',
                'login.json', 'login.variables.json', 'loginModule.js', 'languages-static.dictionary.json'}
    _require(set(page_files) == expected, 'Incomplete or unexpected fresh HMI page/localization output inventory.')
    files = dict(page_files)
    for name, payload in files.items():
        _require(type(payload) is bytes and payload, 'Empty HMI page/localization output: ' + name)
        if name.endswith('.json'):
            try:
                json.loads(payload)
            except (ValueError, UnicodeError) as exc:
                raise ProjectError('Invalid fresh HMI JSON: ' + name) from exc
    # Dynamic dictionaries come from the global resource compilation stage.
    # This profile contains no list payloads/text-list definitions; never read
    # an old precompiled resource dictionary when this stage is empty.
    _require(not any(n.endswith('.locreslst') for n in project_members),
             'Nonempty dynamic HMI resource lists are unsupported.')
    files['languages-dynamic.dictionary.json'] = _json(_document('LanguageDictionary', defaultLanguage='Default', languages=[]))
    for name in LANGUAGES:
        value = json.loads(files[name])
        _require(value.get('title') == 'LanguageDictionary' and value.get('defaultLanguage') == 'Default'
                 and isinstance(value.get('languages'), list), 'Unsupported HMI language dictionary profile.')
    source_hashes.update({name: sha(data) for name, data in project_members.items()
                          if '/HMI_Server/' in name or name in (manifest_name, core_name)})
    source_hashes.update(runtime_report.get('source_hashes', {}))
    app_name = _one(project_members, '/Application/Variables.hmivar')
    files['application.variables.json'] = _json(_application_variables(project_members[app_name]))
    data, types = _data_dictionary(project_members, finalized_type_info, runtime_report)
    heartbeat = _heartbeat_view(finalized_type_info, runtime_report)
    files['data.dictionary.json'] = _json(data)
    files['type.dictionary.json'] = _json(types)
    decoded_members = {unquote(name): name for name in project_members}
    _require(len(decoded_members) == len(project_members), 'Ambiguous encoded source member names.')
    images = []
    for node in project.iter():
        if _local_name(node.tag) != 'Image':
            continue
        include = node.get('Include', '').replace('\\', '/')
        path = PurePosixPath(include)
        _require(not path.is_absolute() and '..' not in path.parts and path.suffix.lower() == '.png'
                 and path.name.isascii(), 'Unsupported source HMI image.')
        source_name = decoded_members.get('PROJECT/' + include + '/Source')
        _require(source_name in project_members and path.name not in files, 'Missing or duplicate HMI image payload.')
        payload = project_members[source_name]
        _require(payload.startswith(b'\x89PNG\r\n\x1a\n'), 'Invalid source HMI PNG payload.')
        files[path.name] = payload
        source_hashes[source_name] = sha(payload)
        images.append({'id': _child(node, 'Id'), 'file': path.name, 'source': source_name, 'sha256': sha(payload)})
    assets = {}
    for name in STATIC_ASSETS:
        path = install / 'HMI' / 'BrowserClient' / name
        _require(path.is_file() and not path.is_symlink() and name not in files, 'Missing/ambiguous installed HMI asset: ' + name)
        payload = path.read_bytes()
        _require(payload, 'Empty installed HMI asset: ' + name)
        files[name] = payload
        assets[name] = {'path': str(path), 'sha256': sha(payload), 'size': len(payload)}
    # Values are source-bound by the hardware projection, including L7_3 HMI
    # InstVal records. Unknown HTTP/authentication/poll/recovery settings reject.
    settings = {'sessionTimeout': 5000, 'dataURL': None, 'dataSource': 'eCLR', 'dataRetries': 1,
                'dataTimeout': 5000, 'dataPollInterval': 250, 'dataPollTimeoutMultiplier': 2,
                'recoveryCountdown': 2, 'dataDebug': 'Off'}
    files['webserver.configuration.json'] = _json({'WebServer': {'HttpPort': 443,
        'AuthenticationProtocol': device_profile(project_members)['hmi_authentication_protocol']}})
    files['imagelist.json'] = _json(_document('ImageListDictionary', imageLists=[]))
    files['textlist.json'] = _json(_document('TextListDictionary', textLists=[]))
    project_files = sorted((set(files) - UNLISTED_ASSETS) | {'project.checksum.json'})
    files['project.json'] = _json({'name': project_name, 'id': project_id,
        'appId': '5195d979-0d9f-4cf5-990b-94e1af0d4c03', 'appVersion': '7.9.0.0',
        'homePage': home[0], 'files': project_files, 'settings': settings})
    checksum, full_checksum = hmi_checksums(files, project_id)
    files['project.checksum.json'], files['project.checksum-full.json'] = _json(checksum), _json(full_checksum)
    target = 'ehmi/hmiapp.html?HmiPage=' + home[0] + '&DataPollInterval=250'
    index = '<!DOCTYPE html>\n<html lang="en"><head><title>Go to HMI</title>' + \
        '<noscript><meta http-equiv="refresh" content="0; url=' + html.escape(target, quote=True) + '" /></noscript>' + \
        "<script>setTimeout(function(){window.location.replace('ehmi/hmiapp.html');},0);</script>" + \
        '</head><body><a href="' + html.escape(target, quote=True) + '">Load HMI</a></body></html>\n'
    output = {PREFIX + name: data for name, data in files.items()}
    output['Services/Ehmi/index.html'] = index.encode('utf-8')
    return output, {'hmi_complete': True, 'scope': 'verified Gateway/Login application; offline output only',
        'controller_acceptance_tested': False, 'gui_cache_used': False, 'project_id': project_id,
        'home_page': home[0], 'project_files': project_files, 'runtime_mapping_count': len(data['HmiVariables2']) - 1,
        'runtime_type_count': len(types['Types']) - 1, 'runtime_type_names': [t['Name'] for t in types['Types'][:-1]],
        'finalized_types_canonical_sha256': sha(_json(finalized_type_info)), 'images': images,
        'installed_assets': assets, 'compiler_sha256': HMI_COMPILER_SHA256,
        'page_output_hashes': {n: sha(p) for n, p in page_files.items()},
        'source_hashes': source_hashes, 'checksum': checksum['checksum'],
        'checksum_file_count': len(full_checksum['files']), 'generated_hashes': {n: sha(p) for n, p in output.items()},
        'heartbeat_type_view': heartbeat,
        'project_file_order': 'ordinal; list membership follows vendor contract',
        'unsupported': ['other HMI applications', 'custom image/text lists', 'HMI symbols',
                        'explicit global initializers', 'unverified hardware/service settings']}
