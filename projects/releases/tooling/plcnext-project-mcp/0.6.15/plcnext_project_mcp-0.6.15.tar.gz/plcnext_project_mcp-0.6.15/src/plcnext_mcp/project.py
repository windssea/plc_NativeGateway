"""Own-code PCWEX editing: preserve every payload except explicit POU edits.

This module never imports Phoenix Contact assemblies, ACI, or CodeMeter.
It does not compile IEC code and does not access a controller.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import difflib
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import tempfile
from urllib.parse import unquote
import uuid
import xml.etree.ElementTree as ET
import zipfile


MAX_ARCHIVE = 64 * 1024 * 1024
MAX_EXPANDED = 256 * 1024 * 1024
MAX_CODE = 2 * 1024 * 1024


class ProjectError(ValueError):
    """Actionable project, revision or archive error."""


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def xml(data: bytes) -> ET.Element:
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise ProjectError('DTD/entity declarations are unsupported in project XML.')
    try:
        return ET.fromstring(data)
    except ET.ParseError as exc:
        raise ProjectError(f'Invalid project XML: {exc}') from exc


def read_archive(path: Path) -> tuple[bytes, dict[str, bytes], list[zipfile.ZipInfo], bytes]:
    if path.stat().st_size > MAX_ARCHIVE:
        raise ProjectError('Project exceeds 64 MiB archive limit.')
    raw = path.read_bytes()
    if len(raw) > MAX_ARCHIVE:
        raise ProjectError('Project exceeds 64 MiB archive limit.')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            infos = archive.infolist()
            if len(infos) > 10000 or sum(i.file_size for i in infos) > MAX_EXPANDED:
                raise ProjectError('Project exceeds member/expanded-size limit.')
            names = set()
            for info in infos:
                path_parts = PurePosixPath(info.filename)
                if (info.orig_filename != info.filename or '\x00' in info.orig_filename or
                        path_parts.is_absolute() or '..' in path_parts.parts or
                        '\\' in info.filename or ':' in info.filename or
                        info.filename.casefold() in names):
                    raise ProjectError('Unsafe or duplicate archive member name.')
                names.add(info.filename.casefold())
                if info.flag_bits & 1:
                    raise ProjectError('Encrypted project archives are unsupported.')
            members = {i.filename: archive.read(i) for i in infos}
            return raw, members, infos, archive.comment
    except (zipfile.BadZipFile, RuntimeError, NotImplementedError) as exc:
        raise ProjectError(f'Unsupported or corrupt PCWEX archive: {exc}') from exc


def pou_index(members: dict[str, bytes]) -> dict[str, dict]:
    result = {}
    for path, data in members.items():
        if not path.startswith('PROJECT/Logical%20Elements/') or not path.endswith('.pou/Metadata.meta'):
            continue
        prefix = path.removesuffix('Metadata.meta')
        name = unquote(prefix.rstrip('/').rsplit('/', 1)[-1].removesuffix('.pou'))
        if name.casefold() in {n.casefold() for n in result}:
            raise ProjectError('Ambiguous duplicate POU names.')
        metadata = xml(data)
        result[name] = {
            'name': name, 'kind': metadata.findtext('Kind'), 'id': metadata.findtext('Id'),
            'prefix': prefix, 'has_st': prefix + 'Code.st' in members,
            'worksheet_ids': {node.tag: node.findtext('Id') for node in metadata.findall('ItemGroup/*')},
        }
    if not result:
        raise ProjectError('No supported standard POUs found in this project.')
    return result


def decode_code(data: bytes) -> str:
    try:
        return data.decode('utf-8-sig')
    except UnicodeDecodeError as exc:
        raise ProjectError('Only UTF-8 ST worksheets are supported.') from exc


def encode_worksheet(original: bytes, text: str) -> bytes:
    """Encode full worksheet text with its existing UTF-8 BOM and newline style."""
    if not isinstance(text, str):
        raise ProjectError('POU code/variables updates must be complete UTF-8 text strings.')
    # Callers normally obtain BOM-free text from read_pou. Accept an editor's
    # leading BOM too, while retaining the original file's BOM policy exactly.
    if text.startswith('\ufeff'):
        text = text[1:]
    old_text = decode_code(original)
    if text == old_text:
        return original
    if len(text) > MAX_CODE:
        raise ProjectError('Edited worksheet exceeds 2 MiB.')
    styles = {'\r\n': old_text.count('\r\n'),
              '\n': old_text.count('\n') - old_text.count('\r\n'),
              '\r': old_text.count('\r') - old_text.count('\r\n')}
    if any(styles.values()):
        newline = max(styles, key=styles.get)
        text = re.sub(r'\r\n|\r|\n', lambda _: newline, text)
    try:
        encoded = (b'\xef\xbb\xbf' if original.startswith(b'\xef\xbb\xbf') else b'') + text.encode('utf-8')
    except UnicodeEncodeError as exc:
        raise ProjectError('POU updates must contain valid UTF-8 text; unpaired surrogates are unsupported.') from exc
    if len(encoded) > MAX_CODE:
        raise ProjectError('Edited worksheet exceeds 2 MiB.')
    return encoded


def masked_st(source: str) -> str:
    """Mask comments and literals for bounded identifier/reference search."""
    output = list(source)
    index, depth = 0, 0
    while index < len(source):
        start = index
        if source.startswith('(*', index):
            depth = 1
            index += 2
            while index < len(source) and depth:
                if source.startswith('(*', index):
                    depth += 1
                    index += 2
                elif source.startswith('*)', index):
                    depth -= 1
                    index += 2
                else:
                    index += 1
            if depth:
                raise ProjectError('Unclosed ST block comment.')
        elif source.startswith('//', index):
            end = source.find('\n', index)
            index = len(source) if end < 0 else end
        elif source[index] in "'\"":
            quote = source[index]
            index += 1
            closed = False
            while index < len(source):
                if source[index] == '$':
                    index += 2
                elif source[index] == quote:
                    index += 1
                    if index < len(source) and source[index] == quote:
                        index += 1
                    else:
                        closed = True
                        break
                else:
                    index += 1
            if not closed:
                raise ProjectError('Unclosed ST string literal.')
        else:
            index += 1
            continue
        for pos in range(start, min(index, len(output))):
            if output[pos] not in '\r\n':
                output[pos] = ' '
    return ''.join(output)


class ProjectStore:
    def __init__(self, root: Path):
        self.root = root.expanduser().resolve()

    def create_project(self, name: str, template_path: str | None = None) -> dict:
        from .lifecycle import create_project
        return create_project(self, name, template_path)

    def change_structure(self, project_id: str, expected_project_sha256: str,
                         add_fbs: list[dict] | None = None, delete_fbs: list[str] | None = None,
                         updates: list[dict] | None = None) -> dict:
        from .lifecycle import change_structure
        return change_structure(self, project_id, expected_project_sha256, add_fbs, delete_fbs, updates)

    def _folder(self, project_id: str) -> Path:
        if not re.fullmatch(r'[0-9a-f]{32}', project_id):
            raise ProjectError('Invalid project_id; use project_import_copy first.')
        folder = (self.root / project_id).resolve()
        if folder.parent != self.root or not (folder / 'manifest.json').is_file():
            raise ProjectError('Unknown project_id.')
        return folder

    def _load(self, project_id: str) -> tuple[Path, dict]:
        folder = self._folder(project_id)
        manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
        return folder, manifest

    @staticmethod
    def _save_manifest(folder: Path, manifest: dict) -> None:
        temporary = folder / ('manifest.' + uuid.uuid4().hex + '.tmp')
        try:
            temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            os.replace(temporary, folder / 'manifest.json')
        finally:
            temporary.unlink(missing_ok=True)

    @contextmanager
    def _lock(self, folder: Path):
        path = folder / '.edit.lock'
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            raise ProjectError('Project is being edited by another request; retry after it completes.') from exc
        try:
            os.close(fd)
            yield
        finally:
            path.unlink(missing_ok=True)

    def import_copy(self, source_path: str) -> dict:
        source = Path(source_path).expanduser().resolve(strict=True)
        if source.suffix.lower() != '.pcwex':
            raise ProjectError('Expected a .pcwex project file.')
        raw, members, _, _ = read_archive(source)
        index = pou_index(members)
        project_id = uuid.uuid4().hex
        self.root.mkdir(parents=True, exist_ok=True)
        folder = self.root / project_id
        folder.mkdir()
        (folder / 'original.pcwex').write_bytes(raw)
        artifact = folder / 'revision-0000.pcwex'
        artifact.write_bytes(raw)
        manifest = {
            'schema': 1, 'project_id': project_id, 'source_path': str(source),
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'original_sha256': sha(raw), 'revision': 0, 'current_sha256': sha(raw),
            'allowed_code_members': [], 'allowed_variable_members': [], 'history': [],
        }
        self._save_manifest(folder, manifest)
        return {**self._identity(folder, manifest), 'pou_count': len(index),
                'source_untouched': True, 'compiled': False}

    @staticmethod
    def _identity(folder: Path, manifest: dict) -> dict:
        return {'project_id': manifest['project_id'], 'revision': manifest['revision'],
                'project_sha256': manifest['current_sha256'],
                'project_path': str(folder / f"revision-{manifest['revision']:04d}.pcwex")}

    def _current(self, project_id: str) -> tuple[Path, dict, dict, list, bytes]:
        folder, manifest = self._load(project_id)
        path = folder / f"revision-{manifest['revision']:04d}.pcwex"
        raw, members, infos, comment = read_archive(path)
        if sha(raw) != manifest['current_sha256']:
            raise ProjectError('Managed artifact changed outside MCP; import it as a new copy instead.')
        return folder, manifest, members, infos, comment

    def inspect(self, project_id: str) -> dict:
        folder, manifest, members, _, _ = self._current(project_id)
        index = pou_index(members)
        return {**self._identity(folder, manifest), 'pous': list(index.values()),
                'mapping_members': sorted(p for p in members if p.endswith(('DataList.dl', 'EsmConfiguration.esmc', 'IOConfiguration.ioc'))),
                'backend': 'native_pcwex', 'aci_used': False, 'compiled': False}

    def read_pou(self, project_id: str, pou_name: str) -> dict:
        folder, manifest, members, _, _ = self._current(project_id)
        index = pou_index(members)
        if pou_name not in index:
            raise ProjectError('Unknown POU name; use project_inspect to list supported POUs.')
        pou = index[pou_name]
        path = pou['prefix'] + 'Code.st'
        if path not in members:
            raise ProjectError('This POU has no supported Code.st worksheet.')
        return {**self._identity(folder, manifest), **pou, 'code': decode_code(members[path]),
                'code_sha256': sha(members[path]),
                'variables': decode_code(members.get(pou['prefix'] + 'Variables.var', b'')),
                'variables_sha256': sha(members.get(pou['prefix'] + 'Variables.var', b'')),
                'metadata_sha256': sha(members[pou['prefix'] + 'Metadata.meta'])}

    def references(self, project_id: str, pou_name: str) -> dict:
        _, _, members, _, _ = self._current(project_id)
        index = pou_index(members)
        if pou_name not in index:
            raise ProjectError('Unknown POU name.')
        references = []
        for caller, item in index.items():
            variables = masked_st(decode_code(members.get(item['prefix'] + 'Variables.var', b'')))
            code = masked_st(decode_code(members.get(item['prefix'] + 'Code.st', b'')))
            for match in re.finditer(r'\b(\w+(?:\s*,\s*\w+)*)\s*:\s*' + re.escape(pou_name) + r'\b', variables, re.I):
                for instance in (name.strip() for name in match.group(1).split(',')):
                    lines = [code.count('\n', 0, call.start()) + 1 for call in re.finditer(r'\b' + re.escape(instance) + r'\s*\(', code, re.I)]
                    references.append({'caller': caller, 'instance': instance, 'call_lines': lines})
        return {'pou': pou_name, 'instances': references, 'coverage': 'bounded_standard_ST_search',
                'limitations': 'Not a compiler symbol table; excludes graphical code, arrays and indirect references.'}

    def patch_st(self, project_id: str, pou_name: str, expected_project_sha256: str,
                 expected_code_sha256: str, old_text: str, new_text: str) -> dict:
        folder = self._folder(project_id)
        with self._lock(folder):
            folder, manifest, members, infos, comment = self._current(project_id)
            if manifest['current_sha256'] != expected_project_sha256:
                raise ProjectError('Stale project revision; read the project again before editing.')
            pou = self.read_pou(project_id, pou_name)
            if pou['code_sha256'] != expected_code_sha256:
                raise ProjectError('Stale worksheet hash.')
            if not old_text or pou['code'].count(old_text) != 1:
                raise ProjectError('old_text must match exactly once in the current worksheet.')
            if old_text == new_text:
                raise ProjectError('Patch would make no change.')
            updated = pou['code'].replace(old_text, new_text, 1)
            encoded = (b'\xef\xbb\xbf' if members[pou['prefix'] + 'Code.st'].startswith(b'\xef\xbb\xbf') else b'') + updated.encode('utf-8')
            if len(encoded) > MAX_CODE:
                raise ProjectError('Edited worksheet exceeds 2 MiB.')
            masked_st(updated)  # lexical sanity only, never reported as compilation
            member = pou['prefix'] + 'Code.st'
            revision = manifest['revision'] + 1
            target = folder / f'revision-{revision:04d}.pcwex'
            # A process killed after publishing an artifact but before updating
            # its manifest can leave an orphan. Preserve it and use a fresh
            # revision number; it must never block or overwrite committed work.
            while target.exists():
                revision += 1
                target = folder / f'revision-{revision:04d}.pcwex'
            fd, temporary_name = tempfile.mkstemp(prefix='.revision-', suffix='.tmp', dir=folder)
            os.close(fd)
            temporary = Path(temporary_name)
            try:
                with zipfile.ZipFile(temporary, 'w') as archive:
                    archive.comment = comment
                    for info in infos:
                        archive.writestr(info, encoded if info.filename == member else members[info.filename])
                raw, check, _, _ = read_archive(temporary)
                if set(check) != set(members) or any(check[name] != data for name, data in members.items() if name != member):
                    raise ProjectError('Payload preservation check failed; no revision committed.')
                os.rename(temporary, target)
            finally:
                temporary.unlink(missing_ok=True)
            manifest['revision'] = revision
            manifest['current_sha256'] = sha(raw)
            manifest['allowed_code_members'] = sorted(set(manifest['allowed_code_members']) | {member})
            manifest['history'].append({'revision': revision, 'pou': pou_name, 'code_before': expected_code_sha256,
                                        'code_after': sha(encoded), 'project_sha256': sha(raw)})
            try:
                self._save_manifest(folder, manifest)
            except Exception:
                # Only remove our artifact if the manifest was not committed.
                # A crash at any boundary remains recoverable on the next edit.
                try:
                    persisted = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
                    if persisted['current_sha256'] != sha(raw):
                        target.unlink(missing_ok=True)
                except (OSError, ValueError, KeyError):
                    pass
                raise
            return {**self._identity(folder, manifest), 'code_sha256': sha(encoded),
                    'changed_member': member, 'other_member_payloads_identical': True,
                    'compiled': False, 'aci_used': False}

    def update_pous(self, project_id: str, expected_project_sha256: str, updates: list[dict]) -> dict:
        """Commit full code/variable texts for existing POUs in one atomic revision.

        No declaration or ST semantics are guessed here. The compiler must check
        interfaces and dependent callers after the complete batch is committed.
        """
        if not isinstance(updates, list) or not updates or len(updates) > 1000:
            raise ProjectError('updates must be a nonempty list of at most 1000 existing POUs.')
        folder = self._folder(project_id)
        with self._lock(folder):
            folder, manifest, members, infos, comment = self._current(project_id)
            if manifest['current_sha256'] != expected_project_sha256:
                raise ProjectError('Stale project revision; read the project again before editing.')
            index = pou_index(members)
            selected, replacements, changes, seen = [], {}, [], set()
            expanded_size = sum(len(data) for data in members.values())
            keys = {'pou_name', 'expected_code_sha256', 'expected_variables_sha256', 'code', 'variables'}
            required = {'pou_name', 'expected_code_sha256', 'expected_variables_sha256'}
            for update in updates:
                if not isinstance(update, dict) or set(update) - keys or not required <= set(update):
                    raise ProjectError('Each update requires pou_name and both worksheet hashes; only code/variables text may be supplied.')
                name = update['pou_name']
                if not isinstance(name, str) or not name:
                    raise ProjectError('Each update requires an existing POU name.')
                if name.casefold() in seen:
                    raise ProjectError('Each POU may appear only once in an update transaction.')
                seen.add(name.casefold())
                if name not in index:
                    raise ProjectError('Unknown POU name: ' + name)
                if 'code' not in update and 'variables' not in update:
                    raise ProjectError('Each POU update must supply code, variables, or both.')
                pou = index[name]
                code_member, variable_member = pou['prefix'] + 'Code.st', pou['prefix'] + 'Variables.var'
                before = {'code': sha(members.get(code_member, b'')),
                          'variables': sha(members.get(variable_member, b''))}
                for field in ('code', 'variables'):
                    expected = update['expected_' + field + '_sha256']
                    if not isinstance(expected, str) or re.fullmatch(r'[0-9a-f]{64}', expected) is None:
                        raise ProjectError('Expected worksheet hashes must be lowercase SHA-256 hex strings.')
                    if expected != before[field]:
                        raise ProjectError(f'Stale {field} worksheet hash for {name}.')
                changed_members = []
                after = before.copy()
                for field, member in (('code', code_member), ('variables', variable_member)):
                    if field not in update:
                        continue
                    if member not in members:
                        raise ProjectError(f'{name} has no existing supported {Path(member).name} worksheet; new members are unsupported.')
                    encoded = encode_worksheet(members[member], update[field])
                    if encoded != members[member]:
                        expanded_size += len(encoded) - len(members[member])
                        if expanded_size > MAX_EXPANDED:
                            raise ProjectError('Updated project exceeds the 256 MiB expanded-size limit.')
                        replacements[member] = encoded
                        changed_members.append(member)
                        after[field] = sha(encoded)
                selected.append({'pou_name': name, 'code_sha256': after['code'],
                                 'variables_sha256': after['variables'], 'changed_members': changed_members})
                changes.append({'pou': name, 'code_before': before['code'], 'code_after': after['code'],
                                'variables_before': before['variables'], 'variables_after': after['variables']})
            if not replacements:
                raise ProjectError('Update transaction would make no change.')
            revision = manifest['revision'] + 1
            target = folder / f'revision-{revision:04d}.pcwex'
            while target.exists():
                revision += 1
                target = folder / f'revision-{revision:04d}.pcwex'
            fd, temporary_name = tempfile.mkstemp(prefix='.revision-', suffix='.tmp', dir=folder)
            os.close(fd)
            temporary = Path(temporary_name)
            try:
                with zipfile.ZipFile(temporary, 'w') as archive:
                    archive.comment = comment
                    for info in infos:
                        archive.writestr(info, replacements.get(info.filename, members[info.filename]))
                raw, check, _, _ = read_archive(temporary)
                if set(check) != set(members) or any(check[name] != replacements.get(name, data)
                                                     for name, data in members.items()):
                    raise ProjectError('Payload preservation check failed; no revision committed.')
                os.rename(temporary, target)
            finally:
                temporary.unlink(missing_ok=True)
            manifest['revision'], manifest['current_sha256'] = revision, sha(raw)
            manifest['allowed_code_members'] = sorted(set(manifest.get('allowed_code_members', []))
                                                      | {p for p in replacements if p.endswith('/Code.st')})
            manifest['allowed_variable_members'] = sorted(set(manifest.get('allowed_variable_members', []))
                                                          | {p for p in replacements if p.endswith('/Variables.var')})
            manifest['history'].append({'operation': 'update_pous', 'revision': revision,
                                        'updates': changes, 'project_sha256': sha(raw)})
            try:
                self._save_manifest(folder, manifest)
            except Exception:
                try:
                    persisted = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
                    if persisted['current_sha256'] != sha(raw):
                        target.unlink(missing_ok=True)
                except (OSError, ValueError, KeyError):
                    pass
                raise
            return {**self._identity(folder, manifest), 'updates': selected,
                    'changed_members': sorted(replacements), 'other_member_payloads_identical': True,
                    'compiled': False, 'aci_used': False}

    def validate(self, project_id: str) -> dict:
        from .lifecycle import lifecycle_permissions
        from .task_configuration import task_permissions, program_permissions
        folder, manifest, current, _, _ = self._current(project_id)
        raw, original, _, _ = read_archive(folder / 'original.pcwex')
        if sha(raw) != manifest['original_sha256']:
            raise ProjectError('Frozen original copy was modified outside MCP.')
        changes = sorted(name for name in set(original) | set(current)
                         if original.get(name) != current.get(name) or (name in original) != (name in current))
        index = pou_index(original)
        supported_code = {p['prefix'] + 'Code.st' for p in index.values() if p['prefix'] + 'Code.st' in original}
        supported_variables = {p['prefix'] + 'Variables.var' for p in index.values() if p['prefix'] + 'Variables.var' in original}
        structural, added_code, added_variables, invalid_history = lifecycle_permissions(manifest, original)
        programs, program_code, program_variables, invalid_program_history = program_permissions(manifest, original)
        structural.update(programs)
        # FB lifecycle transactions and Program clones both touch registration
        # members. Their final permission is the last recorded source revision,
        # not whichever history happens to be merged last here.
        registrations = {}
        for event in [*manifest.get('lifecycle_history', []), *manifest.get('program_history', [])]:
            if not isinstance(event, dict) or type(event.get('revision')) is not int:
                continue
            event_changes = event.get('member_changes', {})
            if not isinstance(event_changes, dict):
                continue
            for member in ('PROJECT/PROJECT.proj', '[Content_Types].xml'):
                change = event_changes.get(member)
                if isinstance(change, dict) and 'after_sha256' in change:
                    if event['revision'] > registrations.get(member, (-1, None))[0]:
                        registrations[member] = (event['revision'], change['after_sha256'])
        structural.update({member: value[1] for member, value in registrations.items()})
        task_expected, invalid_task_history = task_permissions(manifest, original)
        structural.update(task_expected)
        supported_code |= added_code
        supported_variables |= added_variables
        supported_code |= program_code
        supported_variables |= program_variables
        declared_code, declared_variables = (set(manifest.get('allowed_code_members', [])),
                                              set(manifest.get('allowed_variable_members', [])))
        invalid_allowed = sorted((declared_code - supported_code) | (declared_variables - supported_variables))
        allowed = (declared_code & supported_code) | (declared_variables & supported_variables)
        unexpected = set(changes) - allowed - set(structural)
        # Structural changes are authorized by the exact after-hash of a
        # lifecycle transaction. Later worksheet edits can change its contents,
        # but cannot resurrect a removed member or erase an existing member.
        for name, expected in structural.items():
            if expected is None:
                if name in current:
                    unexpected.add(name)
            elif name not in current or (name not in allowed and sha(current[name]) != expected):
                unexpected.add(name)
        for name in (set(original) ^ set(current)) - set(structural):
            unexpected.add(name)
        unexpected = sorted(unexpected)
        passed = not unexpected and not invalid_allowed and not invalid_history and not invalid_task_history and not invalid_program_history
        return {**self._identity(folder, manifest), 'preservation_passed': passed,
                'changed_members': changes, 'unexpected_members': unexpected,
                'invalid_allowed_members': invalid_allowed,
                'invalid_lifecycle_history': invalid_history,
                'invalid_task_history': invalid_task_history,
                'invalid_program_history': invalid_program_history,
                'checked_unchanged_members': sum(original[name] == current[name] for name in set(original) & set(current)),
                'all_other_payloads_byte_identical': passed,
                'compiled': False, 'controller_connected': False,
                'limitations': ['Structural checks are not IEC syntax/type checking or behavioral validation.',
                                'Unedited policy/signature payload bytes are copied unchanged; cryptographic/project integrity validity is not established.']}

    def diff(self, project_id: str, pou_name: str, max_chars: int = 16000) -> dict:
        if not 1 <= max_chars <= 64000:
            raise ProjectError('max_chars must be between 1 and 64000.')
        folder, manifest, current, _, _ = self._current(project_id)
        raw, original, _, _ = read_archive(folder / 'original.pcwex')
        if sha(raw) != manifest['original_sha256']:
            raise ProjectError('Frozen original copy was modified outside MCP.')
        old_item, new_item = pou_index(original).get(pou_name), pou_index(current).get(pou_name)
        item = new_item or old_item
        if item is None:
            raise ProjectError('Unknown POU name.')
        path = item['prefix'] + 'Code.st'
        if path not in original and path not in current:
            raise ProjectError('This POU has no supported Code.st worksheet.')
        difference = ''.join(difflib.unified_diff(decode_code(original.get(path, b'')).splitlines(keepends=True),
                                                decode_code(current.get(path, b'')).splitlines(keepends=True),
                                                fromfile='original/' + pou_name, tofile='current/' + pou_name))
        return {'diff': difference[:max_chars], 'truncated': len(difference) > max_chars,
                'change': 'added' if old_item is None else 'deleted' if new_item is None else 'modified',
                'compiled': False}

    def diff_pou(self, project_id: str, pou_name: str, max_chars: int = 16000) -> dict:
        """Bound code and variable-declaration diffs independently against the frozen copy."""
        if not isinstance(max_chars, int) or not 1 <= max_chars <= 64000:
            raise ProjectError('max_chars must be between 1 and 64000 per worksheet.')
        folder, manifest, current, _, _ = self._current(project_id)
        raw, original, _, _ = read_archive(folder / 'original.pcwex')
        if sha(raw) != manifest['original_sha256']:
            raise ProjectError('Frozen original copy was modified outside MCP.')
        old_item, new_item = pou_index(original).get(pou_name), pou_index(current).get(pou_name)
        item = new_item or old_item
        if item is None:
            raise ProjectError('Unknown POU name.')
        result = {**self._identity(folder, manifest), 'pou_name': pou_name, 'compiled': False,
                  'change': 'added' if old_item is None else 'deleted' if new_item is None else 'modified'}
        for field, worksheet in (('code', 'Code.st'), ('variables', 'Variables.var')):
            path = item['prefix'] + worksheet
            if path not in original and path not in current:
                result[field] = {'supported': False, 'diff': '', 'truncated': False}
                continue
            difference = ''.join(difflib.unified_diff(decode_code(original.get(path, b'')).splitlines(keepends=True),
                                                     decode_code(current.get(path, b'')).splitlines(keepends=True),
                                                     fromfile='original/' + pou_name + '/' + worksheet,
                                                     tofile='current/' + pou_name + '/' + worksheet))
            result[field] = {'supported': True, 'diff': difference[:max_chars],
                             'truncated': len(difference) > max_chars}
        return result

    def build_plan(self, project_id: str) -> dict:
        folder, manifest, _, _, _ = self._current(project_id)
        return {**self._identity(folder, manifest), 'status': 'engineer_rebuild_required',
                'compiled': False, 'aci_used': False,
                'steps': ['Open this revision in the installed Engineer GUI.',
                          'Run Project > Rebuild; do not use Write and Start.',
                          'Inspect the error list and retain the build result.'],
                'reason': 'This independent backend edits project files; it does not implement or invoke the proprietary IEC compiler.'}
