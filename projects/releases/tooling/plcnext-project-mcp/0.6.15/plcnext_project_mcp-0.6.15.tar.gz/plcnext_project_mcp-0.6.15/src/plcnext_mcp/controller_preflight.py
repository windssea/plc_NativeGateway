"""Review-bound, anonymous, read-only controller download preflight.

Uses the production socket client in its separate restricted preflight mode.
Only state, the fixed symbolic PCWE root, space and two fixed metadata files
are read. This record is evidence for an operator, never write authorization.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import ipaddress
import json
from pathlib import Path
import re
import time
import uuid

from .controller_download_plan import review_package_snapshot
from .controller_transport import ControllerEndpoint, ControllerFailure, TlsControllerClient
from .deployment_package import MANIFEST, MAX_METADATA_BYTES, _relative_path
from .deployment_plan import _file
from .project import ProjectError, sha, xml

SOFTWARE = 'PCWE.software-package-manifest.json'
READ_PATHS = [MANIFEST, SOFTWARE]


def _manifest(payload: bytes) -> tuple[list[str], dict[str, str]]:
    if type(payload) is not bytes or not 0 < len(payload) <= MAX_METADATA_BYTES:
        raise ProjectError('Remote manifest is empty or oversized.')
    root = xml(payload)
    containers = root.findall('./Files')
    algorithms = root.findall('./Metadata/HashAlgorithm')
    if (root.tag != 'ProjectManifestDocument' or root.get('schemaVersion') != '1.0'
            or len(containers) != 1 or len(algorithms) != 1 or algorithms[0].get('type') != 'Sha512'):
        raise ProjectError('Remote manifest has an unsupported schema.')
    hashes, folded = {}, set()
    if not 1 <= len(containers[0]) <= 4096:
        raise ProjectError('Remote manifest has an empty or oversized file list.')
    for item in containers[0]:
        if item.tag != 'File':
            raise ProjectError('Remote manifest contains an unsupported file-list item.')
        path = _relative_path(item.get('path'))
        digest = item.get('hash')
        if (path.casefold() in folded or path.casefold() == MANIFEST.casefold()
                or type(digest) is not str or re.fullmatch('[0-9a-fA-F]{128}', digest) is None):
            raise ProjectError('Remote manifest contains duplicate paths or invalid file hashes.')
        folded.add(path.casefold())
        hashes[path] = digest.lower()
    return sorted([MANIFEST, *hashes]), hashes


def _software(payload: bytes) -> dict:
    if type(payload) is not bytes or not 0 < len(payload) <= MAX_METADATA_BYTES:
        raise ProjectError('Remote software metadata is empty or oversized.')
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ProjectError('Duplicate software metadata field.')
            value[key] = item
        return value
    try:
        document = json.loads(payload, object_pairs_hook=unique,
            parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    except (ValueError, UnicodeError) as exc:
        raise ProjectError('Malformed software metadata JSON.') from exc
    if (type(document) is not dict or document.get('manifestVersion') != '1.0'
            or type(document.get('identification')) is not dict):
        raise ProjectError('Unsupported software metadata schema.')
    source, identification = document['identification'], {}
    for key in ('name', 'manufacturer', 'productCode', 'model', 'softwareRevision',
                'releaseDate', 'targetFirmwareRevision'):
        if key not in source:
            continue
        value = source[key]
        if type(value) is not str or len(value) > 1024:
            raise ProjectError('Software identification values must be bounded strings.')
        identification[key] = value
    if not identification.get('name'):
        raise ProjectError('Software metadata must contain an identification name.')
    codes = source.get('targetProductCodes', [])
    if type(codes) is not list or len(codes) > 64 or any(type(code) is not str or len(code) > 128 for code in codes):
        raise ProjectError('Unsupported target product identification list.')
    identification['targetProductCodes'] = codes
    return identification


def preflight_download_review(store, project_id: str, review_id: str,
                               expected_review_sha256: str) -> dict:
    """Read live state/version context without authenticating or changing device state.

    A known project folder is required so even review-validation failures can be
    persisted. Invalid/unknown project IDs fail before any network or report path.
    Review/package identity is checked both before and after the bounded reads.
    """
    folder = store._folder(project_id)
    directory = _file(folder, 'controller-download-preflights/' + uuid.uuid4().hex)
    directory.mkdir(parents=True, exist_ok=False)
    path = directory / 'result.json'
    result = {'schema': 'plcnext-controller-download-preflight/v1',
        'created_utc': datetime.now(timezone.utc).isoformat(), 'status': 'preflight_failed',
        'project_id': project_id, 'preflight_id': directory.name, 'stage': 'review_validation',
        'review_revalidated_before_reads': False, 'source_and_package_unchanged': False,
        'peer_connected': False, 'controller_connected': False, 'controller_downloaded': False,
        'read_only': True, 'authentication_attempted': False, 'credentials_sent': False,
        'file_writes_attempted': False, 'configuration_commands_sent': False,
        'stop_command_sent': False, 'start_command_sent': False, 'delete_command_sent': False,
        'write_authorized': False, 'write_permissions_verified': False,
        'complete_remote_directory_listing': False, 'absence_of_unlisted_files_verified': False,
        'signature_validation_performed': False, 'remote_file_contents_verified': False,
        'aci_used': False, 'engineer_started': False, 'computer_use_used': False,
        'metadata_files_requested': [], 'metadata': {},
        'execution_blockers': ['exact_mcp_or_operator_authorization_required', 'device_write_permissions_unverified',
                               'absence_of_unlisted_remote_files_unverified'],
        'limitations': ['Read-only evidence is not permission to write, Reset or Load.',
                       'Declared manifest paths/hashes do not verify actual remote file bytes.',
                       'A manifest is not a complete directory listing; unlisted files may exist.',
                       'No raw remote metadata payload is returned or persisted.'],
        'report_path': str(path)}
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    client = None
    try:
        review, files = review_package_snapshot(store, project_id, review_id, expected_review_sha256)
        result.update(review_id=review['review_id'], review_sha256=review['review_sha256'],
            reviewed_project_sha256=review['source']['project_sha256'],
            reviewed_inventory_sha256=review['package']['inventory_sha256'],
            review_revalidated_before_reads=True, target=dict(review['target']))
        proposed_software = _software(files[SOFTWARE])
        result['reviewed_software_identification'] = proposed_software
        endpoint = ControllerEndpoint(review['target']['address'], review['target']['port'],
                                      review['target']['expected_certificate_sha256'])
        client = TlsControllerClient(endpoint, preflight_readonly=True)
        client.overall_end = time.monotonic() + 30
        result['stage'] = 'connecting'
        result['peer'] = client.connect()
        result.update(peer_connected=True, controller_connected=not ipaddress.ip_address(endpoint.address).is_loopback)
        result['stage'] = 'state_read'
        raw = client.get_state()
        result.update(plc_state_raw=raw,
            plc_base_state={0:'None', 1:'Ready', 2:'Stop', 3:'Running', 4:'Halt'}.get(raw & 63, 'Unknown'),
            plc_state_flags=raw & ~63, exact_stop_observed=raw == 2)
        if raw != 2:
            result['execution_blockers'].append('controller_not_in_exact_stop_state')
        result['stage'] = 'root_and_space'
        result['remote_project_root'] = client.resolve_root()
        available = client.get_space()
        needed = review['package']['total_bytes']
        result.update(available_bytes=available, reviewed_package_bytes=needed,
                      reported_space_sufficient=available >= needed)
        if available < needed:
            result['execution_blockers'].append('insufficient_reported_space')
        result['stage'] = 'fixed_metadata_read'
        result['metadata_files_requested'] = list(READ_PATHS)
        response = client.read_many(list(READ_PATHS))
        if type(response) is not list or len(response) != len(READ_PATHS):
            raise ControllerFailure('metadata_read_incomplete', 'ReadMany returned an incomplete metadata response.')
        parsed = {}
        for name, item in zip(READ_PATHS, response):
            record = {'result': item['result'], 'read_succeeded': item['result'] == 0}
            result['metadata'][name] = record
            if item['result'] != 0:
                result['execution_blockers'].append('remote_metadata_not_readable:' + name)
                continue
            data = item['data']
            record.update(bytes=len(data), sha256=sha(data), sha512=hashlib.sha512(data).hexdigest())
            if not 0 < len(data) <= MAX_METADATA_BYTES:
                record['validation'] = 'empty_or_oversized'
                result['execution_blockers'].append('remote_metadata_invalid:' + name)
                continue
            try:
                parsed[name] = _manifest(data) if name == MANIFEST else _software(data)
                record['validation'] = 'supported_schema'
            except (ProjectError, ValueError, TypeError):
                record['validation'] = 'unsupported_or_malformed'
                result['execution_blockers'].append('remote_metadata_invalid:' + name)
        if MANIFEST in parsed:
            paths, hashes = parsed[MANIFEST]
            local = set(files)
            inventory_path = directory / 'remote-manifest-paths.json'
            inventory_path.write_text(json.dumps(paths, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            changed_hashes = sorted(name for name in set(hashes) & local
                                    if hashes[name] != hashlib.sha512(files[name]).hexdigest())
            result['file_set_comparison'] = {
                'declared_paths_match_review': set(paths) == local,
                'remote_declared_path_count': len(paths), 'reviewed_path_count': len(files),
                'only_in_remote_manifest': sorted(set(paths) - local)[:128],
                'only_in_reviewed_package': sorted(local - set(paths))[:128],
                'different_declared_hash_count': len(changed_hashes),
                'different_declared_hash_paths': changed_hashes[:128],
                'path_report_limit': 128, 'remote_declared_paths_report': str(inventory_path),
                'comparison_kind': 'metadata_declarations_only_not_remote_file_readback'}
            if set(paths) != local:
                result['execution_blockers'].append('remote_declared_file_set_differs')
        if SOFTWARE in parsed:
            result['remote_software_identification'] = parsed[SOFTWARE]
            result['remote_metadata_is_untrusted_source_data'] = True
            result['software_comparison'] = {
                'name_matches': parsed[SOFTWARE].get('name') == proposed_software.get('name'),
                'software_revision_matches': parsed[SOFTWARE].get('softwareRevision') == proposed_software.get('softwareRevision')}
        result['status'] = 'preflight_read_completed' if len(parsed) == 2 else 'preflight_incomplete'
        result['stage'] = 'source_revalidation'
        review_package_snapshot(store, project_id, review_id, expected_review_sha256)
        result.update(source_and_package_unchanged=True, stage='completed')
    except Exception as exc:
        result.update(status='preflight_failed', failure_code=getattr(exc, 'code', 'preflight_validation_or_transport_error'),
                      error_class=type(exc).__name__)
        if isinstance(exc, ControllerFailure):
            result['error'] = str(exc)
        elif isinstance(exc, ValueError) and str(exc).startswith('RSC tagged codec:'):
            # Fixed schema/tag diagnostics only; never dump raw metadata or a
            # remote exception string/argument that might reflect credentials.
            result['codec_error'] = str(exc)[:256]
    finally:
        if client is not None:
            result['cleanup_error_class'] = client.close()
            result['trace'] = client.trace
            result['bytes_sent'] = client.bytes_sent
            result['bytes_received'] = client.bytes_received
            if result['cleanup_error_class'] is not None:
                result.update(status='preflight_failed', failure_code='transport_cleanup_failed')
        path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return result


def strict_download_preflight(store,project_id,review_id,expected_review_sha256,*,deadline=None,event_sink=None,expected_state=None):
    """Same path/native-library policy as transfer, before Stop; never write authority."""
    from .controller_package_read import ReviewedPackageReadClient
    from .controller_transfer import _check_old_manifest,_compare_files
    from .plc_state import stable_state
    review,files=review_package_snapshot(store,project_id,review_id,expected_review_sha256)
    target=review['target'];endpoint=ControllerEndpoint(target['address'],target['port'],target['expected_certificate_sha256'])
    client=ReviewedPackageReadClient(endpoint,list(files),event_sink=event_sink,maximum_bytes=67108864)
    client.overall_end=min(time.monotonic()+60,deadline) if deadline else time.monotonic()+60
    directory=_file(store._folder(project_id),'controller-download-preflights/'+uuid.uuid4().hex);directory.mkdir(parents=True)
    result={'schema':'plcnext-strict-download-preflight/v1','status':'preflight_rejected','read_only':True,
        'review_sha256':expected_review_sha256,'source_sha256':review['source']['project_sha256'],
        'inventory_sha256':review['package']['inventory_sha256'],'target':target,'write_authorized':False,
        'action_counts':dict(stop=0,file_write=0,reset=0,load=0,start=0),'race_free':False}
    try:
        client.connect();raw=client.get_state();result['state_before']=raw
        if not any(stable_state(raw,x) for x in (2,3)) or expected_state is not None and raw!=expected_state:
            raise ControllerFailure('preflight_state_mismatch','Stable reviewed Stop/Running state required before Stop.')
        result['remote_project_root']=client.resolve_root();result['available_bytes']=client.get_space()
        if result['available_bytes']<sum(map(len,files.values())):raise ControllerFailure('insufficient_space','Insufficient controller space for captured package.')
        result['remote_inventory']=_check_old_manifest(client,files)
        changed,skipped=_compare_files(client,files)
        result.update(files_compared=len(files),changed_file_count=len(changed),identical_file_count=len(skipped))
        again=_check_old_manifest(client,files);result['state_after']=client.get_state()
        if again!=result['remote_inventory'] or result['state_after']!=raw:
            raise ControllerFailure('preflight_window_changed','Remote manifest/state changed during preflight.')
        review_package_snapshot(store,project_id,review_id,expected_review_sha256)
        result['status']='preflight_passed'
    except Exception as exc:
        result.update(failure_code=getattr(exc,'code','preflight_error'),error_class=type(exc).__name__)
        if isinstance(exc,ProjectError):result['error']=str(exc)[:512]
        if hasattr(exc,'details'):result['path_comparison']=exc.details
    finally:
        result['cleanup_error_class']=client.close()
        if result['cleanup_error_class']:result.update(status='preflight_rejected',failure_code='preflight_cleanup_failed')
        result.update(trace=client.trace,bytes_received=client.bytes_received,report_path=str(directory/'result.json'))
        from .controller_recovery import _save_new
        _save_new(directory/'result.json',result)
    return result
