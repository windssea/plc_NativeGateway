"""Permit only bounded initialization read retries after confirmed Start."""
from .controller_transport import ControllerFailure

def classify(observation,expected,known_boot):
    def reject():raise ControllerFailure('recovery_observation_failed','Read window is not a permitted startup transition')
    if observation.get('cleanup_error_class'):reject()
    before={r['symbol']:r.get('value') for r in observation.get('guards_before',[]) if r.get('status')=='read'}
    after={r['symbol']:r.get('value') for r in observation.get('guards_after',[]) if r.get('status')=='read'}
    boot='MainInstance.BootId'
    # Legacy mocks/unguarded reads are handled by the existing verifier, never retried.
    if boot not in before or boot not in after:return False,known_boot
    if observation.get('plc_state_before')!=3 or observation.get('plc_state_after')!=3:reject()
    if known_boot and (before[boot]!=known_boot or after[boot]!=known_boot):reject()
    if observation.get('status')=='snapshot_invalidated':
        if known_boot or before[boot]!='' or observation.get('plc_state_before')!=3 or observation.get('plc_state_after')!=3:reject()
        allowed={boot:None,'MainInstance.Active.Version':expected['version'],
            'MainInstance.Active.DeviceCount':expected['device_count'],'MainInstance.Active.PointCount':expected['point_count']}
        if set(before)!=set(after) or not set(allowed)<=set(before):reject()
        for key,value in before.items():
            if key==boot:
                if type(after[key]) is not str:reject()
            elif key in allowed:
                if value not in (0,allowed[key]) or after[key] not in (value,allowed[key]):reject()
            elif after[key]!=value:reject()
        return True,after[boot] or None
    if before[boot]!=after[boot]:reject()
    if observation.get('status') in ('monitor_read_completed','monitor_read_partial'):
        return not bool(after[boot]),after[boot] or known_boot
    return False,known_boot
