"""Local-only runtime read fixture using the production pinned TLS reader.

Values, state and faults are synthetic. This proves transport behavior, never a
real PLC's symbol availability, scan consistency or monitoring performance.
"""
from __future__ import annotations

from . import rsc_tagged_codec as tagged
from .controller_test_peer import LocalTlsController
from .controller_transport import PLC, PROVIDER
from .rsc_codec import CommandHeader, CommandType, DATA_TAGGING, DATAGRAMMING, decode_header
from .rsc_runtime_codec import DATA_ACCESS, PLC_INFO, encode_read_items, encode_variant

FAULTS = frozenset({'none','missing_field','bad_quality','wrong_type','short_results',
    'boot_change','config_change','disconnect','oversized_string'})


class LocalRuntimeController(LocalTlsController):
    def __init__(self, root, values, *, fault='none', response_fragment_bytes=None):
        if fault not in FAULTS:
            raise ValueError('Unsupported runtime fixture fault.')
        super().__init__(root, initial_state=3, allowed_files=set(),
            response_fragment_bytes=response_fragment_bytes)
        self.runtime_fault=fault
        self.values=dict(values)
        self.variable_calls=0

    def _session(self, channel):
        connected=False;handles={};provider=1777;next_handle=2000
        while not self._stop.is_set():
            raw=self._exact(channel,16)
            header,token=decode_header(raw,require_checksum=True)
            if header.command_type==CommandType.CONNECT_REQUEST:
                if connected:raise ValueError('Duplicate fixture Connect.')
                if header.version!=4 or header.flags!=(DATA_TAGGING | DATAGRAMMING) or header.data_length:
                    raise ValueError('Unsupported runtime Connect request.')
                self._record('Connect',mutating=False)
                self._reply(channel,tagged.encode_connect_confirmation())
                connected=True;continue
            if not connected or token is not None or header.flags!=DATA_TAGGING:
                raise ValueError('Unsupported runtime fixture request.')
            if header.command_type==CommandType.GET_SERVICE_HANDLES_REQUEST:
                if not 0<=header.data_length<=2054:raise ValueError('Oversized discovery.')
                names=tagged.decode_get_service(raw+self._exact(channel,header.data_length))
                if names[0]!=PROVIDER or names[1] not in (PLC,PLC_INFO,DATA_ACCESS):
                    raise ValueError('Runtime fixture refuses non-read service.')
                if names[1] not in handles:
                    handles[names[1]]=next_handle;next_handle+=1
                self._record('GetServiceHandles',service=names[1],mutating=False)
                self._reply(channel,tagged.encode_get_service_confirmation(handles[names[1]],provider))
                continue
            service=next((name for name,h in handles.items() if h==header.service_handle),None)
            schemas={(PLC,5):[],(PLC_INFO,1):['int32'],(DATA_ACCESS,2):['utf8[]']}
            schema=schemas.get((service,header.method_handle))
            if (schema is None or header.command_type!=CommandType.INVOKE_REQUEST
                    or header.service_provider_handle!=provider or header.data_length):
                raise ValueError('Runtime fixture refuses mutation or unknown read.')
            values=tagged.receive_values(lambda n:channel.recv(n),schema)
            self._record('Invoke',service=service,method=header.method_handle,mutating=False)
            if service==PLC:
                payload=tagged.encode_values(['uint32'],[self.state])
            elif service==PLC_INFO:
                if values!=[1]:raise ValueError('Only ProjectName is admitted.')
                payload=encode_variant({'wire_type':'utf8','value':'NativeGateway'})+b'\xff'
            else:
                paths=values[0]
                if not 1<=len(paths)<=64:raise ValueError('Runtime fixture read count exceeded.')
                self.variable_calls+=1
                if self.runtime_fault=='disconnect':raise EOFError('Synthetic runtime disconnect.')
                rows=[]
                for path in paths:
                    value=self.values.get(path)
                    if value is None or self.runtime_fault=='missing_field' and '.Samples[1].' in path:
                        rows.append({'error_code':1,'wire_type':'null','value':None});continue
                    row={'error_code':0,**value}
                    if self.runtime_fault=='boot_change' and path.endswith('.BootId') and self.variable_calls>1:
                        row['value']='fixture-boot-2'
                    if self.runtime_fault=='config_change' and path.endswith('.Active.Version') and self.variable_calls>1:
                        row['value']=row['value']+1
                    if self.runtime_fault=='bad_quality' and '.Samples[1].Quality' in path:row['value']='BAD'
                    if self.runtime_fault=='wrong_type' and '.Samples[1].Quality' in path:row={'error_code':0,'wire_type':'int32','value':7}
                    if self.runtime_fault=='oversized_string' and '.Quality' in path:row['value']='x'*5000
                    rows.append(row)
                if self.runtime_fault=='short_results':rows=rows[:-1]
                payload=encode_read_items(rows) if rows else b'\x14\x12\x02\x00\x00\x00\x00\x00\xff'
            response=encode_header_for_reply(header,payload)
            self._reply(channel,response)


def encode_header_for_reply(request,payload):
    from .rsc_codec import encode_header
    header=CommandHeader(version=4,flags=DATA_TAGGING,command_type=CommandType.INVOKE_CONFIRMATION,
        service_handle=request.service_handle,service_provider_handle=request.service_provider_handle,
        method_handle=request.method_handle)
    return encode_header(header)+payload
