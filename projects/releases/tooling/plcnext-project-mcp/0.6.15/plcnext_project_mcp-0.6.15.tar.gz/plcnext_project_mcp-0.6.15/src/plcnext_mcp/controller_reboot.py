"""Reviewed device reboot once; reconnect/read only, never compensate with Start."""
from datetime import datetime,timezone
import json,os,time,uuid
from pathlib import Path
from .project import ProjectError,sha
from .deployment_plan import _file
from .controller_download_plan import prepare_download_review,review_package_snapshot,_strict_json
from .runtime_monitor import load_runtime_read_plan,read_runtime_plan,RuntimeReadClient
from .controller_recovery import verify_original_runtime
from .controller_control import ControlEndpointLease
from .controller_transport import TlsControllerClient,ControllerEndpoint,ControllerFailure,RemoteControllerError,PROVIDER
from .operator_approval import OperatorApprovalContract,_paths,_issuer_lock,_new_file,validate_operator_receipt
from .endpoint_guard import endpoint_guard
from .operation_jobs import _bytes
from .controller_transfer import _journal_sink
from . import rsc_tagged_codec as tagged
from .rsc_codec import CommandType
SERVICE='Arp.Device.Interface.Services.IDeviceControlService'
_AUTHORITY=object()

class RebootClient(TlsControllerClient):
    def __init__(self,endpoint,*,authority,check,sink,deadline):
        if authority is not _AUTHORITY:raise ProjectError('Reviewed reboot capability required')
        super().__init__(endpoint,timeout_seconds=5,event_sink=sink)
        self.check=check;self.attempted=False;self.overall_end=deadline
    def _call(self,*args,**kwargs):raise ProjectError('Only fixed device RestartDevice is admitted')
    def reboot_once(self,before_send):
        if self.attempted:raise ProjectError('Reboot is never resent')
        self.check();self._deadline()
        self._send(tagged.encode_get_service(PROVIDER,SERVICE))
        h,raw=self._header();self._raise_remote_error(h)
        handle,provider=tagged.decode_get_service_confirmation(raw)
        packet=tagged.encode_request(handle,1,[],[],provider_handle=provider)
        self.check();before_send();self.attempted=True
        self._emit({'operation':'RestartDevice','service':SERVICE,'method':1,'send_attempted':True,'response_received':False})
        self._send(packet);h,_=self._header()
        if (h.service_handle,h.service_provider_handle,h.method_handle)!=(handle,provider,1):raise ProjectError('Reboot response identity mismatch')
        self._raise_remote_error(h)
        if h.command_type!=CommandType.INVOKE_CONFIRMATION:raise ProjectError('Unexpected reboot response')
        tagged.receive_values(self._receive,[])
        self._emit({'operation':'RestartDevice','service':SERVICE,'method':1,'send_attempted':True,'response_received':True})

def prepare(store,project_id,project_sha256,package_job_id,address,pin,read_plan_id,read_plan_sha256,
            expected_boot_id,expected_configuration,configuration_sha256,port=41100,timeout_seconds=240,poll_interval_seconds=5):
    if type(timeout_seconds) is not int or not 30<=timeout_seconds<=300 or type(poll_interval_seconds) is not int or not 5<=poll_interval_seconds<=30:
        raise ProjectError('Reboot deadline 30..300s and read interval 5..30s required')
    if type(expected_boot_id) is not str or not 1<=len(expected_boot_id)<=64:raise ProjectError('Exact current application boot required')
    from .controller_download_plan import _sha256
    _sha256(configuration_sha256, "configuration_sha256")
    cfg=expected_configuration
    if set(cfg)!={'version','device_count','point_count','enabled'} or type(cfg['enabled']) is not bool or any(type(cfg[k]) is not int or cfg[k]<0 for k in ('version','device_count','point_count')):
        raise ProjectError('Explicit typed configuration required')
    read=load_runtime_read_plan(store,project_id,read_plan_id,read_plan_sha256)
    review=prepare_download_review(store,project_id,project_sha256,package_job_id,address,pin,port)
    if read['project_sha256']!=project_sha256 or any(read['target'][k]!=review['target'][k] for k in read['target']):raise ProjectError('Read plan source/target mismatch')
    if poll_interval_seconds<read['limits']['minimum_interval_seconds']:raise ProjectError('Poll interval violates read-plan interval')
    ident=uuid.uuid4().hex;folder=_file(store._folder(project_id),'controller-reboots/'+ident);folder.mkdir(parents=True)
    plan={'schema':'plcnext-device-reboot-plan/v1','project_id':project_id,'plan_id':ident,'target':review['target'],
        'project_sha256':project_sha256,'inventory_sha256':review['package']['inventory_sha256'],
        'package_review':{'review_id':review['review_id'],'expected_review_sha256':review['review_sha256']},
        'read_plan':{'plan_id':read_plan_id,'expected_plan_sha256':read_plan_sha256},
        'policy':{'plan_id':ident,'expected_boot_id':expected_boot_id,'expected_configuration':cfg,
            'configuration_sha256':configuration_sha256,'timeout_seconds':timeout_seconds,'poll_interval_seconds':poll_interval_seconds,
            'maximum_observations':timeout_seconds//poll_interval_seconds,'stable_observations':2,'service':SERVICE,'method':1,
            'automatic_resend':False,'automatic_start':False,'read_only_resume':True},
        'approved_actions':['device_reboot_once','wait_reconnect_read_only'],
        'impact':{'device_and_program_interrupted':True,'volatile_ram_loss':'unknown','outputs_hold_behavior_verified':False},
        'created_utc':datetime.now(timezone.utc).isoformat(),'memory_loaded_image_attested':False}
    plan['plan_sha256']=sha(_bytes(plan));_new_file(folder/'plan.json',plan);return plan

def load(store,pid,ident,digest):
    import re
    if re.fullmatch('[0-9a-f]{32}',ident or '') is None:raise ProjectError('Invalid reboot plan ID')
    folder=_file(store._folder(pid),'controller-reboots/'+ident);p=_strict_json((folder/'plan.json').read_bytes())
    unsigned=dict(p);unsigned.pop('plan_sha256',None)
    if p.get('project_id')!=pid or p.get('plan_id')!=ident or p.get('plan_sha256')!=digest or sha(_bytes(unsigned))!=digest:raise ProjectError('Reboot plan changed')
    review,_=review_package_snapshot(store,pid,**p['package_review'])
    read=load_runtime_read_plan(store,pid,**p['read_plan'])
    if review['target']!=p['target'] or review['source']['project_sha256']!=p['project_sha256'] or review['package']['inventory_sha256']!=p['inventory_sha256'] or read['project_sha256']!=p['project_sha256'] or any(read['target'][k]!=p['target'][k] for k in read['target']):raise ProjectError('Reboot source/package/read binding changed')
    return folder,p

def approval_contract(store,pid,ident,digest):
    _,p=load(store,pid,ident,digest)
    return OperatorApprovalContract('reboot',digest,'plcnext-device-reboot-approval/v1','controller-reboot-approvals',
        {k:p[k] for k in ('target','project_sha256','inventory_sha256','policy','approved_actions','read_plan','impact')},p).checked()

def _boot(o):
    boots=[]
    for key in ('guards_before','guards_after'):
        rows=[r for r in o.get(key,[]) if r.get('symbol')=='MainInstance.BootId' and r.get('status')=='read']
        if len(rows)!=1:return None
        boots.append(rows[0]['value'])
    return boots[0] if type(boots[0]) is str and boots[0] and boots[0]==boots[1] else None

def _ready(o,p):
    v=verify_original_runtime(o,p['policy']['expected_configuration'])
    return (o.get('status')=='monitor_read_completed' and not o.get('cleanup_error_class') and _boot(o)
        and all(v[k] for k in ('configuration_matches','program_running_observed','all_points_good_observed'))
        and (o.get('configuration_digest') or {}).get('sha256')==p['policy']['configuration_sha256'])

def _save(path,value):
    temp=path.with_suffix('.tmp')
    with temp.open('wb') as f:
        f.write(_bytes(value)+b'\n');f.flush();os.fsync(f.fileno())
    os.replace(temp,path)

def status(store,pid,ident,digest):
    folder,p=load(store,pid,ident,digest)
    result=_strict_json((folder/'result.json').read_bytes()) if (folder/'result.json').exists() else None
    return {'plan':p,'result':result,'started':(folder/'started.json').exists(),
        'send_intent_persisted':(folder/'send-intent.json').exists(),'cancel_requested':(folder/'cancel.json').exists(),
        'controller_connected':False,'automatic_resend':False}

def cancel(store,pid,ident,digest):
    folder,_=load(store,pid,ident,digest)
    if not (folder/'cancel.json').exists():_new_file(folder/'cancel.json',{'cancel_requested':True})
    return {'status':'cancel_requested','rollback_sent':False}

def execute(store,pid,ident,digest,*,resume=False):
    folder,p=load(store,pid,ident,digest)
    with endpoint_guard(folder/'execution'):
        return _execute(store,pid,ident,digest,folder,p,resume)

def _execute(store,pid,ident,digest,folder,p,resume):
    review={'target':p['target'],'review_sha256':digest,'policy':{'plan_id':ident}}
    contract=approval_contract(store,pid,ident,digest);paths=_paths(store.root,contract)
    if (folder/'result.json').exists():
        previous=_strict_json((folder/'result.json').read_bytes())
        if previous.get('status')=='reboot_auto_run_verified':
            # Finish only our own release if a process died after saving success.
            from .controller_transfer import _endpoint_lease_root
            path=_endpoint_lease_root()/(sha((p['target']['address']+':'+str(p['target']['port'])).encode())+'.json')
            started=_strict_json((folder/'started.json').read_bytes())
            with endpoint_guard(path):
                if path.exists() and path.read_bytes()==bytes.fromhex(started['lease_bytes_hex']):
                    if path.with_suffix('.reconciliation.json').exists():raise ProjectError('Reconciliation pending')
                    path.unlink()
            return dict(previous,replayed=True)
    if resume:
        if not (folder/'started.json').exists() or not paths['claimed'].exists():raise ProjectError('No owned reboot to resume')
        started=_strict_json((folder/'started.json').read_bytes());claim=_strict_json(paths['claimed'].read_bytes())
        if claim.get('plan_sha256')!=digest:raise ProjectError('Reboot claim mismatch')
        lease=object.__new__(ControlEndpointLease);lease.path=Path(started['lease_path']);lease.raw=bytes.fromhex(started['lease_bytes_hex'])
        lease.target=p['target'];lease.plan_id=ident;lease.review_sha256=digest;lease.quarantined=False;lease.released=False
        from .controller_transfer import _endpoint_lease_root
        expected_path=_endpoint_lease_root()/(sha((p['target']['address']+':'+str(p['target']['port'])).encode())+'.json')
        owner=_strict_json(lease.raw)
        if lease.path!=expected_path or owner.get('review_sha256')!=digest or owner.get('target')!=p['target'] or Path(owner.get('job_directory',''))!=folder:
            raise ProjectError('Reboot resumed lease owner/path mismatch')
        lease.validate(review)
        receipt=paths['receipt'].read_bytes()
        if sha(receipt)!=claim.get('approval_sha256'):raise ProjectError('Consumed reboot authorization changed')
        record=_strict_json(receipt);validate_operator_receipt(record,contract,now=datetime.fromisoformat(record['confirmed_utc']))
        if (folder/'cancel.json').exists():(folder/'cancel.json').rename(folder/('cancel-history-'+uuid.uuid4().hex+'.json'))
    else:
        if (folder/'started.json').exists():raise ProjectError('Already started; use read-only resume, never resend reboot')
        # Authorization is required even before baseline network I/O.
        with _issuer_lock(paths):
            if paths['revoked'].exists() or paths['denied'].exists():raise ProjectError('Reboot authorization withdrawn')
            raw=paths['receipt'].read_bytes();validate_operator_receipt(_strict_json(raw),contract)
            if paths['claimed'].exists():raise ProjectError('Reboot authorization already consumed')
            lease=ControlEndpointLease(review,folder)
            try:
                _new_file(paths['claimed'],{'plan_sha256':digest,'approval_sha256':sha(raw)})
                _new_file(folder/'started.json',{'plan_sha256':digest,'lease_path':str(lease.path),'lease_bytes_hex':lease.raw.hex()})
            except Exception:lease.release();raise
    if resume and (folder/'result.json').exists():
        _save(folder/('result-history-'+uuid.uuid4().hex+'.json'),_strict_json((folder/'result.json').read_bytes()))
    begun=time.monotonic();end=begun+p['policy']['timeout_seconds'];sink=_journal_sink(folder/'journal.jsonl')
    result={'status':'reboot_wait_failed','plan_id':ident,'plan_sha256':digest,'resume_read_only':resume,
        'device_start_sent':False,'device_reset_or_load_sent':False,'os_boot_id_verified':False,
        'memory_loaded_image_attested':False,'observations':[],'automatic_resend':False,'auto_run_verified':False}
    client=None;success=False
    def check():
        lease.validate(review)
        if (folder/'cancel.json').exists():raise ControllerFailure('reboot_cancelled','Reboot wait cancelled; no rollback')
        if time.monotonic()>=end:raise TimeoutError('Reboot wait deadline')
    class BoundedRead(RuntimeReadClient):
        def _deadline(self):
            check();super()._deadline();self._end=min(self._end,end)
    def observe():
        check();return read_runtime_plan(store,pid,**p['read_plan'],client_factory=BoundedRead)
    try:
        if not resume:
            before=observe()
            if not _ready(before,p) or _boot(before)!=p['policy']['expected_boot_id']:raise ProjectError('Reboot baseline boot/configuration/Running/GOOD differs from review')
            _save(folder/'baseline.json',before)
            endpoint=ControllerEndpoint(p['target']['address'],p['target']['port'],p['target']['expected_certificate_sha256'])
            client=RebootClient(endpoint,authority=_AUTHORITY,check=check,sink=sink,deadline=end);client.connect()
            try:
                client.reboot_once(lambda:_new_file(folder/'send-intent.json',{'plan_sha256':digest,'service':SERVICE,'method':1,'baseline_sha256':sha((folder/'baseline.json').read_bytes())}))
                result['reboot_reply_received']=True
            except RemoteControllerError as exc:
                result['reboot_explicitly_rejected']=True
                _new_file(folder/'reboot-rejected.json',{'plan_sha256':digest,'error':str(exc)[:256]})
                raise
            except Exception as exc:
                if not client.attempted:raise
                result.update(reboot_reply_received=False,reboot_reply_error=str(exc)[:256])
            finally:
                result['reboot_session_cleanup_error']=client.close();client=None
        if not (folder/'send-intent.json').exists():raise ProjectError('No reboot send intent; nothing may be resent')
        if _strict_json((folder/'send-intent.json').read_bytes()).get('plan_sha256')!=digest:raise ProjectError('Reboot send intent changed')
        if sha((folder/'baseline.json').read_bytes())!=_strict_json((folder/'send-intent.json').read_bytes()).get('baseline_sha256'):
            raise ProjectError('Reboot baseline bytes changed')
        before=_strict_json((folder/'baseline.json').read_bytes())
        if _boot(before)!=p['policy']['expected_boot_id']:raise ProjectError('Reboot baseline changed')
        if (folder/'reboot-rejected.json').exists():
            raise ProjectError('Rejected reboot cannot be resumed as a successful request')
        stable=0;new_boot=None
        for _ in range(p['policy']['maximum_observations']):
            check();time.sleep(min(p['policy']['poll_interval_seconds'],max(0,end-time.monotonic())));check()
            try:o=observe()
            except (ConnectionError,TimeoutError,OSError) as exc:
                result['disconnect_observed']=True;result['last_read_error']=type(exc).__name__;stable=0;continue
            result['observations'].append({k:o.get(k) for k in ('observation_id','observation_sha256','report_path','status','failure_code')})
            if o.get('failure_code')=='certificate_pin_mismatch':raise ProjectError('Certificate changed after reboot')
            boot=_boot(o)
            if boot and boot!=p['policy']['expected_boot_id']:
                if new_boot and boot!=new_boot:raise ProjectError('Application boot changed again during confirmation')
                new_boot=boot
            if boot==new_boot and new_boot and _ready(o,p):stable+=1
            else:stable=0
            if stable>=p['policy']['stable_observations']:
                load(store,pid,ident,digest);check()
                result.update(status='reboot_auto_run_verified',auto_run_verified=True,new_application_boot_id=new_boot,
                    current_observation=o,confirmation_scope='device reboot requested once; new application boot and auto Running/config/GOOD observed')
                success=True;break
        if not success:raise TimeoutError('Auto-run not verified within reviewed reboot budget')
    except Exception as exc:result.update(error_class=type(exc).__name__,error=str(exc)[:512])
    finally:
        if client:result['reboot_session_cleanup_error']=client.close()
        sent=(folder/'send-intent.json').exists()
        result.update(reboot_send_intent=sent,outcome_unknown=sent and not success,
            endpoint_lease_retained=sent and not success,elapsed_seconds=time.monotonic()-begun)
        _save(folder/'result.json',result)
        sink({'operation':'RebootOutcome','status':result['status'],'outcome_unknown':result['outcome_unknown']})
        if success or not sent:lease.release()
        else:lease.quarantine()
    return result
