"""Loopback-only TLS/TCP controller fixture, never a real deployment backend.

This peer binds only 127.0.0.1 on a random port, uses PUBLIC TEST certificates,
and writes only an explicitly selected new/empty fixture directory. Its state
machine and authorization rules are synthetic; measured tagged byte schemas
are used to exercise the *production* TCP client and its failure behavior.
"""
from __future__ import annotations

import hashlib
import hmac
from pathlib import Path, PurePosixPath
import secrets
import shutil
import socket
import ssl
import threading

from . import rsc_tagged_codec as tagged
from .binary_download_tagged import (
    FILE_SERVICE, FS_SERVICE, PASSWORD_SERVICE, PLC_SERVICE, PROVIDER, SCHEMAS as BASE_SCHEMAS, SERVICES,
)
from .rsc_codec import CommandHeader, CommandType, DATA_TAGGING, DATAGRAMMING, SECURE, decode_header
from .rsc_error_codec import encode_error

FIXTURES = Path(__file__).parent / 'simulation_tls'
REMOTE_ROOT = '/emulated/projects/PCWE'
PUBLIC_USERNAME = 'fixture-user'
PUBLIC_PASSWORD = 'PUBLIC-fixture-password'
FAULTS = frozenset({
    'none', 'write_reply_lost', 'readback_corrupt', 'write_error', 'short_results',
    'load_error', 'load_timeout', 'reset_timeout', 'initial_running', 'tls_error',
    'permission_denied', 'insufficient_space', 'load_reply_lost', 'reset_reply_lost',
    'rpc_error', 'fatal_error', 'chunked_readback', 'hot_metadata',
})
SCHEMAS = dict(BASE_SCHEMAS)
# Original MemoryStream oracle: IPlcManagerService.Stop(bool async), method 3.
# See artifacts/rsc-error-control/oracle-01/report.json (not a guessed opcode).
SCHEMAS[(PLC_SERVICE, 3)] = (['bool'], [])


class _DropReply(Exception):
    pass


def _plain_relative(value: str) -> str:
    if (type(value) is not str or not value or '\\' in value or ':' in value or '\0' in value
            or value.startswith('/') or any(part in ('', '.', '..') for part in value.split('/'))):
        raise ValueError('Fixture file path must be a bounded plain relative path.')
    if len(value.encode('utf-8')) > 511:
        raise ValueError('Fixture file path exceeds the measured path bound.')
    return str(PurePosixPath(value))


class LocalTlsController:
    """Context-managed loopback controller fixture with a real local filesystem.

    Use ``with LocalTlsController(new_root, allowed_files=set(package)) as peer``.
    Client target is ``peer.address, peer.port`` and exact peer certificate pin
    is ``peer.certificate_sha256``. No external bind address/port can be supplied.
    ``anonymous=False`` selects the fixed public fixture credentials above.
    """
    remote_root = REMOTE_ROOT
    username = PUBLIC_USERNAME
    password = PUBLIC_PASSWORD
    ca_path = FIXTURES / 'root-ca.pem'

    def __init__(self, root: Path, *, anonymous: bool = True, fault: str = 'none',
                 initial_state: int = 2, allowed_files: set[str] | None = None,
                 response_fragment_bytes: int | None = None, socket_timeout: float = 3.0):
        if fault not in FAULTS or type(anonymous) is not bool:
            raise ValueError('Unknown local controller fixture mode.')
        if type(initial_state) is not int or not 0 <= initial_state <= 0xffffffff:
            raise ValueError('Fixture state must be UInt32.')
        if allowed_files is not None and type(allowed_files) not in (set, frozenset):
            raise ValueError('Fixture allowed_files must be an explicit set of relative paths.')
        if (response_fragment_bytes is not None and
                (type(response_fragment_bytes) is not int or not 1 <= response_fragment_bytes <= 65536)):
            raise ValueError('Invalid fixture response fragmentation.')
        if type(socket_timeout) not in (int, float) or not 0.1 <= socket_timeout <= 30:
            raise ValueError('Invalid fixture socket deadline.')
        selected = Path(root).absolute()
        if selected.is_symlink() or getattr(selected, 'is_junction', lambda: False)():
            raise ValueError('Fixture root cannot be a link or junction.')
        if selected.exists() and (not selected.is_dir() or any(selected.iterdir())):
            raise ValueError('Fixture root must be new or empty; refusing existing contents.')
        selected.mkdir(parents=True, exist_ok=True)
        self.root = selected.resolve()
        self.allowed_files = None if allowed_files is None else frozenset(_plain_relative(path) for path in allowed_files)
        self.anonymous, self.fault = anonymous, fault
        self.state = (2 | 0x20000) if fault == 'hot_metadata' else 3 if fault == 'initial_running' else initial_state
        self.response_fragment_bytes = response_fragment_bytes
        self.socket_timeout = socket_timeout
        normal_pem = (FIXTURES / 'server.pem').read_text(encoding='ascii')
        self.certificate_sha256 = hashlib.sha256(ssl.PEM_cert_to_DER_cert(normal_pem)).hexdigest()
        self.trace: list[dict] = []
        self.errors: list[dict] = []
        self.loaded = False
        self.reset_calls = self.load_calls = self.stop_calls = self.write_calls = self.read_calls = 0
        self.connections = 0
        self.port = 0
        self._listener = self._active = None
        self._thread = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._permissions: dict[str, int] = {}

    @property
    def address(self):
        return '127.0.0.1'

    @property
    def thread_alive(self):
        return self._thread is not None and self._thread.is_alive()

    def _record(self, operation, **fields):
        self.trace.append({'sequence': len(self.trace), 'operation': operation, **fields})

    def start(self):
        if self._thread is not None:
            raise RuntimeError('Fixture cannot be started twice.')
        self._context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self._context.minimum_version = self._context.maximum_version = ssl.TLSVersion.TLSv1_2
        cert = 'wrong-host-server.pem' if self.fault == 'tls_error' else 'server.pem'
        self._context.load_cert_chain(str(FIXTURES / cert), str(FIXTURES / 'server-public-test-key.pem'))
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            listener.bind(('127.0.0.1', 0))
            listener.listen(4)
            listener.settimeout(0.2)
        except BaseException:
            listener.close()
            raise
        self._listener = listener
        self.port = listener.getsockname()[1]
        self._thread = threading.Thread(target=self._serve, name='PLCnext-public-loopback-fixture', daemon=True)
        self._thread.start()
        return self

    def __enter__(self):
        return self.start()

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._stop.set()
        for channel in (self._active, self._listener):
            if channel is not None:
                try:
                    channel.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    channel.close()
                except OSError:
                    pass
        if self._thread is not None:
            self._thread.join(timeout=max(5.0, self.socket_timeout + 1))
            if self._thread.is_alive():
                raise RuntimeError('Loopback fixture thread did not terminate.')

    def snapshot(self) -> dict[str, bytes]:
        return {path.relative_to(self.root).as_posix(): path.read_bytes()
                for path in self.root.rglob('*') if path.is_file()}

    def _local(self, remote: str, *, write: bool = False) -> tuple[str, Path]:
        if type(remote) is not str or not remote.startswith(REMOTE_ROOT + '/'):
            raise ValueError('Fixture path is outside the fixed emulated project root.')
        relative = _plain_relative(remote[len(REMOTE_ROOT) + 1:])
        if self.allowed_files is not None and relative not in self.allowed_files:
            raise PermissionError('File is outside the selected fixture package inventory.')
        result = self.root.joinpath(*PurePosixPath(relative).parts)
        for parent in (result, *result.parents):
            if parent == self.root.parent:
                break
            if parent.is_symlink() or getattr(parent, 'is_junction', lambda: False)():
                raise ValueError('Linked fixture path is unsupported.')
        if not result.resolve().is_relative_to(self.root):
            raise ValueError('Resolved fixture file path escaped its root.')
        if write:
            result.parent.mkdir(parents=True, exist_ok=True)
        return relative, result

    def _serve(self):
        while not self._stop.is_set():
            try:
                raw, peer = self._listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            if peer[0] != '127.0.0.1':
                raw.close()
                self.errors.append({'stage': 'accept', 'error': 'Non-loopback peer rejected'})
                continue
            self.connections += 1
            raw.settimeout(self.socket_timeout)
            self._active = raw
            try:
                with self._context.wrap_socket(raw, server_side=True) as tls:
                    self._active = tls
                    self._session(tls)
            except (EOFError, _DropReply):
                pass
            except (OSError, ValueError) as exc:
                if not self._stop.is_set():
                    # No request bodies, passwords, tokens or file bytes enter diagnostics.
                    self.errors.append({'stage': 'session', 'error_class': type(exc).__name__})
            except Exception as exc:
                self.errors.append({'stage': 'unexpected', 'error_class': type(exc).__name__})
            finally:
                raw.close()
                self._active = None

    @staticmethod
    def _exact(channel, count):
        output = bytearray()
        while len(output) < count:
            block = channel.recv(count - len(output))
            if not block:
                raise EOFError('Fixture connection closed.')
            output.extend(block)
        return bytes(output)

    def _reply(self, channel, data):
        fragment = self.response_fragment_bytes or len(data)
        for offset in range(0, len(data), fragment):
            channel.sendall(data[offset:offset + fragment])

    def _session(self, channel):
        connected = authenticated = False
        token_value = secrets.randbits(32)
        provider = secrets.randbelow(10000) + 101
        handles: dict[str, int] = {}
        next_handle = secrets.randbelow(10000) + 101
        while not self._stop.is_set():
            raw = self._exact(channel, 16)
            if raw[1] & SECURE:
                raw += self._exact(channel, 4)
            header, token = decode_header(raw, require_checksum=True)
            if header.command_type == CommandType.CONNECT_REQUEST:
                if (connected or token is not None or header.version != 4 or
                        header.flags != DATA_TAGGING | DATAGRAMMING or any((header.data_length,
                            header.service_handle, header.method_handle, header.service_provider_handle))):
                    raise ValueError('Unsupported fixture Connect profile.')
                connected = True
                self._record('Connect', data_tagging=True, datagramming=False)
                self._reply(channel, tagged.encode_connect_confirmation())
                continue
            if not connected:
                raise ValueError('Fixture received a request before Connect.')
            if header.command_type == CommandType.GET_SERVICE_HANDLES_REQUEST:
                if header.data_length < 0 or header.data_length > 2054:
                    raise ValueError('Fixture service lookup length outside bound.')
                names = tagged.decode_get_service(raw + self._exact(channel, header.data_length))
                if names[0] != PROVIDER or names[1] not in SERVICES:
                    raise ValueError('Unknown fixture provider/service.')
                if names[1] not in handles:
                    handles[names[1]] = next_handle
                    next_handle += 1
                self._record('GetServiceHandles', service=names[1], handle=handles[names[1]], provider_handle=provider)
                self._reply(channel, tagged.encode_get_service_confirmation(handles[names[1]], provider))
                continue
            service = next((name for name, handle in handles.items() if handle == header.service_handle), None)
            schemas = SCHEMAS.get((service, header.method_handle))
            if (header.command_type != CommandType.INVOKE_REQUEST or header.version != 4 or
                    header.flags & ~SECURE != DATA_TAGGING or header.data_length or
                    header.service_provider_handle != provider or schemas is None):
                raise ValueError('Unknown fixture invocation/schema/profile.')
            values = tagged.receive_values(lambda count: channel.recv(count), schemas[0])
            if service != PASSWORD_SERVICE and not self.anonymous and (
                    not authenticated or token is None or token != token_value):
                self._record('AuthorizationDenied', service=service, method=header.method_handle)
                self._reply(channel, encode_error(header.service_handle, header.method_handle,
                    0xF001, 'PUBLIC fixture authorization denied.', provider_handle=provider))
                continue
            if service != PASSWORD_SERVICE and token is not None and token != token_value:
                raise ValueError('Fixture request has an invalid security token.')
            self._record('Invoke', service=service, method=header.method_handle,
                         authenticated=token is not None, tagged=True)
            if self.fault in ('rpc_error', 'fatal_error') and service == FS_SERVICE and header.method_handle == 6:
                # Code values are deliberate fixture choices; encoding/framing is
                # measured against original ErrorCommand MemoryStream vectors.
                code = 0xF002 if self.fault == 'rpc_error' else 0x8000F002
                self._record('Fault', name=self.fault)
                self._reply(channel, encode_error(header.service_handle, header.method_handle, code,
                    'PUBLIC fixture preflight error.' if self.fault == 'rpc_error' else '', provider_handle=provider))
                continue
            if service == PASSWORD_SERVICE:
                if header.method_handle == 1:
                    accepted = (hmac.compare_digest(values[0].encode('utf-8'), PUBLIC_USERNAME.encode('utf-8'))
                                and hmac.compare_digest(values[1].encode('utf-8'), PUBLIC_PASSWORD.encode('utf-8')))
                    authenticated = accepted
                    # The UInt32(0) failure out value is an explicit fixture policy.
                    result = [token_value if accepted else 0, 0, 0 if accepted else -1]
                else:
                    if values[0] != token_value or not authenticated:
                        raise ValueError('Fixture CloseSession token does not identify an active session.')
                    authenticated = False
                    result = []
            else:
                result = self._invoke(service, header.method_handle, values)
            if self.fault == 'chunked_readback' and service == FILE_SERVICE and header.method_handle == 9:
                result = [[{**item, 'data': tagged.ChunkedStream(item['data'], 0x7fffffff, 65536)}
                           for item in result[0]]]
            self._reply(channel, tagged.encode_response(header.service_handle, header.method_handle,
                schemas[1], result, provider_handle=provider))

    def _invoke(self, service, method, values):
        if service == FS_SERVICE:
            if method == 1:
                return [1]  # Permissions stored as fixture metadata, not host ACL semantics.
            if method == 5:
                if values != [0, '$ARP_PROJECTS_DIR$/PCWE/']:
                    raise ValueError('Fixture root lookup only admits the exact symbolic root and zero trait mask.')
                return [{'path': REMOTE_ROOT, 'is_file': False, 'is_directory': True, 'traits': []}, 0]
            if method == 6:
                if values != [REMOTE_ROOT]:
                    raise ValueError('Fixture free-space query has the wrong root.')
                usage = shutil.disk_usage(self.root)
                free = 1 if self.fault == 'insufficient_space' else usage.free
                return [{'capacity': usage.total, 'free': free, 'available': free}, 0]
        if service == FILE_SERVICE:
            if method == 8:
                self.write_calls += 1
                errors = []
                for index, entry in enumerate(values[0]):
                    try:
                        relative, path = self._local(entry['path'])
                        if self.fault == 'permission_denied' or self.fault == 'write_error' and index == 0:
                            errors.append(5)
                            continue
                        if path.exists() and not entry['overwrite']:
                            errors.append(4)
                            continue
                        path.parent.mkdir(parents=True, exist_ok=True)
                        path.write_bytes(entry['data'])
                        self._permissions[relative] = entry['traits'][0]['value'] if entry['traits'] else 0
                        errors.append(0)
                        self._record('FileWritten', path=relative, bytes=len(entry['data']))
                        if self.fault == 'write_reply_lost':
                            self._record('Fault', name='write_reply_lost', side_effect='one_file_written')
                            raise _DropReply('Reply dropped after fixture file write.')
                    except PermissionError:
                        errors.append(5)
                    except ValueError:
                        errors.append(2)
                return [errors[:-1] if self.fault == 'short_results' else errors]
            if method == 9:
                self.read_calls += 1
                result = []
                for item in values[0]:
                    try:
                        relative, path = self._local(item['path'])
                        if not path.is_file():
                            result.append({'result': 3, 'traits': [], 'data': b''})
                            continue
                        content = path.read_bytes()
                        if self.fault == 'readback_corrupt':
                            content = (bytes([content[0] ^ 1]) + content[1:]) if content else b'corrupt'
                        result.append({'result': 0, 'traits': [], 'data': content})
                        self._record('FileRead', path=relative, bytes=len(content))
                    except PermissionError:
                        result.append({'result': 5, 'traits': [], 'data': b''})
                    except ValueError:
                        result.append({'result': 2, 'traits': [], 'data': b''})
                return [result]
        if service == PLC_SERVICE:
            if method == 5:
                return [self.state]
            if method == 3:
                self.stop_calls += 1
                self.state = 2
                self._record('Stop', async_=values[0])
                return []
            if method == 4:
                self.reset_calls += 1
                self.loaded = False
                if self.fault != 'reset_timeout':
                    self.state = 1 | (0x20000 if self.fault == 'hot_metadata' else 0)  # Ready.
                self._record('Reset', async_=values[0])
                if self.fault == 'reset_reply_lost':
                    raise _DropReply('Reply dropped after fixture Reset.')
                return []
            if method == 1:
                self.load_calls += 1
                if self.fault == 'load_error':
                    self.state = 2 | 0x80
                elif self.fault != 'load_timeout':
                    self.state, self.loaded = 2 | (0x20000 if self.fault == 'hot_metadata' else 0), True
                self._record('Load', async_=values[0], accepted=self.loaded)
                if self.fault == 'load_reply_lost':
                    raise _DropReply('Reply dropped after fixture Load.')
                return []
        raise ValueError('Unsupported local fixture service method.')
