"""Explicit zero-transfer Stop failure handoff into a separately authorized full recovery."""
from datetime import datetime
import json,os,re,uuid
from pathlib import Path
from .project import ProjectError,sha
from .deployment_plan import _file
from .controller_download_plan import _strict_json,_digest
from .controller_transfer import _endpoint_lease_root
from .endpoint_guard import endpoint_guard
from .lease_reconciliation import _read
from .operator_approval import _paths,validate_operator_receipt
from .plc_state import stable_state


def snapshot(store,pid,eid,digest,pin,operation_id=None):
    from .controller_recovery import load_recovery_plan,approval_contract
    from .controller_transport import PLC
    if re.fullmatch('[0-9a-f]{32}',eid or '') is None:raise ProjectError('Exact failed execution ID required')
    job=_file(store._folder(pid),'controller-recoveries/'+eid)
    rr=_read(job/'result.json');r=_strict_json(rr)
    if r.get('execution_id')!=eid or r.get('project_id')!=pid or r.get('review_sha256')!=digest:raise ProjectError('Failed execution identity mismatch')
    plan=load_recovery_plan(store,pid,r['plan_id'],digest)
    with endpoint_guard(_file(store._folder(pid),'controller-recovery-plans/'+r['plan_id']+'/execution')):pass
    if ('audit' in plan['children'] or r.get('status')!='recovery_failed' or r.get('stage')!='transferring'
        or r.get('outcome_unknown') is not False or r.get('receipt_persisted') is not True
        or r.get('endpoint_lease_retained') is not True or r.get('endpoint_quarantine_reason')!='known_execution_failure'
        or r.get('original_package_loaded') is not False or r.get('lease_cleanup_error_class') or r.get('receipt_error_class')):
        raise ProjectError('Not a terminal known zero-transfer Stop failure')
    target=plan['target']
    if target['expected_certificate_sha256']!=pin or r.get('target')!=target:raise ProjectError('Exact target/pin mismatch')
    steps=r.get('steps',[])
    if len(steps)!=2:raise ProjectError('Stop and zero-transfer child receipts required')
    stop,transfer=steps
    if (stop.get('action')!='stop' or stop.get('status')!='control_completed' or stop.get('action_sent') is not True
        or stop.get('ack_received') is not True or stop.get('terminal_state_verified') is not True
        or not stable_state(stop.get('final_state_raw',0),2)
        or transfer.get('status')!='transfer_failed' or transfer.get('stage') not in ('preflight','comparing_files')
        or transfer.get('files_written') not in (None,0) or transfer.get('mutation_request_count')!=0 or transfer.get('unacknowledged_mutation_requests')!=0
        or transfer.get('files_may_have_changed') is not False or transfer.get('configuration_reset_attempted') is not False
        or transfer.get('configuration_load_attempted') is not False or transfer.get('connection_closed') is not True
        or not stable_state(transfer.get('initial_state_raw',0),2)
        or any(s.get('outcome_unknown') is not False or s.get('cleanup_error_class') for s in steps)):
        raise ProjectError('Stop/transfer outcome is not confirmed zero mutation')
    for name,step in zip(('stop','download'),steps):
        if step.get('review_sha256')!=plan['children'][name]['review_sha256'] or step.get('plan_id')!=plan['plan_id']:
            raise ProjectError('Child identity mismatch')
    lr=_read(job/'load-result.json')
    if _strict_json(lr)!=transfer:raise ProjectError('Transfer child differs from saved receipt')
    jr=_read(job/'journal.jsonl');events=[_strict_json(line) for line in jr.splitlines()]
    binding={'operation':'RecoveryBinding','execution_id':eid,'review_sha256':digest,'target':target,
        'project_sha256':plan['source']['project_sha256'],'inventory_sha256':plan['package']['inventory_sha256'],'plan_id':plan['plan_id']}
    if not events or any(events[0].get(k)!=v for k,v in binding.items()):raise ProjectError('Journal binding mismatch')
    if any(events[-1].get(k)!=v for k,v in {'operation':'ExecutionOutcome','status':'recovery_failed','stage':'transferring','outcome_unknown':False,'receipt_persisted':True}.items()):raise ProjectError('Unclosed execution journal')
    pending=None;mutations=[]
    for e in events:
        if e.get('operation')!='Invoke':continue
        if e.get('execution_id')!=eid:raise ProjectError('Journal execution changed')
        key=tuple(e.get(k) for k in ('service','method','recovery_stage','execution_id'))
        if type(e.get('send_attempted')) is not bool or e.get('response_received') is True and e.get('send_attempted') is not True:raise ProjectError('Unknown request intent')
        if e.get('response_received') is False:
            if pending is not None:raise ProjectError('Unclosed request in journal')
            pending=key
        elif e.get('response_received') is True:
            if pending!=key or e.get('remote_error_code') is not None:raise ProjectError('Unmatched or rejected request')
            pending=None
        else:raise ProjectError('Unknown request outcome')
        if e.get('service')==PLC and e.get('method') in (1,2,4):raise ProjectError('Reset/Load/Start request excludes zero-transfer handoff')
        from .controller_transport import FILE
        if e.get('service')==FILE and e.get('method')==8:raise ProjectError('Any file write excludes zero-transfer handoff')
        if e.get('service')==PLC and e.get('method')==3 and e.get('mutating') is not True:raise ProjectError('Stop mutation marker mismatch')
        if e.get('mutating'):
            if key[:3]!=(PLC,3,'stopping'):raise ProjectError('Only the confirmed Stop may mutate')
            if e.get('response_received'):mutations.append(key)
    if pending or len(mutations)!=1:raise ProjectError('Stop journal is not exactly closed')
    contract=approval_contract(store,pid,plan['plan_id'],digest);paths=_paths(store.root,contract)
    ar=_read(paths['receipt'],65536);cr=_read(paths['claimed'],65536);a=_strict_json(ar);c=_strict_json(cr)
    validate_operator_receipt(a,contract,now=datetime.fromisoformat(a['confirmed_utc']))
    if c.get('execution_id')!=eid or c.get('review_sha256')!=digest or c.get('approval_sha256')!=sha(ar):raise ProjectError('Consumed authorization mismatch')
    path=_endpoint_lease_root()/(sha((target['address']+':'+str(target['port'])).encode())+'.json')
    raw=_read(path,65536);owner=_strict_json(raw)
    if owner.get('target')!=target or Path(owner.get('job_directory',''))!=job or owner.get('review_sha256')!=stop['review_sha256']:raise ProjectError('Stopped endpoint owner mismatch')
    evidence={'result_sha256':sha(rr),'journal_sha256':sha(jr),'load_result_sha256':sha(lr),
        'approval_sha256':sha(ar),'claim_sha256':sha(cr),'lease_sha256':sha(raw),'old_plan_id':plan['plan_id'],
        'last_confirmed_state_raw':transfer['initial_state_raw'],'old_job_directory':str(job)}
    if operation_id:
        from .operation_jobs import _load
        folder,op=_load(store,pid,operation_id,digest);er=_read(folder/'result.json');envelope=_strict_json(er)
        if (op.get('kind')!='recovery' or op.get('phase')!='finished' or op.get('status') not in ('completed','failed','needs_attention')
            or op.get('result_sha256')!=sha(er) or envelope.get('result')!=r or envelope.get('operation_id')!=operation_id
            or Path(op.get('driver_report_path',''))!=job/'result.json'):raise ProjectError('Async recovery is not the exact terminal owner')
        evidence.update(operation_sha256=sha(_read(folder/'operation.json')),operation_result_sha256=sha(er))
    return plan,path,raw,evidence


def prepare(store,project_id,execution_id,expected_review_sha256,expected_certificate_sha256,
            restore_project_id,restore_project_sha256,restore_package_job_id,expected_configuration,
            volatile_data_policy,operation_id=None,maximum_runtime_observations=12,runtime_observation_interval_seconds=5):
    from .controller_recovery import prepare_recovery_plan,_save_new
    old,_,_,evidence=snapshot(store,project_id,execution_id,expected_review_sha256,expected_certificate_sha256,operation_id)
    target=old['target']
    child=prepare_recovery_plan(store,restore_project_id,restore_project_sha256,restore_package_job_id,
        target['address'],expected_certificate_sha256,port=target['port'],expected_configuration=expected_configuration,
        volatile_data_policy=volatile_data_policy,start_kind='cold',expected_initial_state=evidence['last_confirmed_state_raw'],
        maximum_runtime_observations=maximum_runtime_observations,runtime_observation_interval_seconds=runtime_observation_interval_seconds)
    path=Path(child.pop('plan_path'));child.pop('plan_sha256',None)
    child['stopped_handoff']={'project_id':project_id,'execution_id':execution_id,'expected_review_sha256':expected_review_sha256,
        'expected_certificate_sha256':expected_certificate_sha256,'operation_id':operation_id,'evidence':evidence}
    child['review_sha256']=_digest(child)
    # New unpublished plan, before any issuer can see its returned identity.
    from .controller_reboot import _save
    _save(path,child)
    return dict(child,plan_sha256=child['review_sha256'],plan_path=str(path),
        inspect_tool='project_inspect_stopped_recovery',execute_tool='project_execute_recovery',authorization_kind='recovery')


def inspect(store,pid,ident,digest):
    from .controller_recovery import load_recovery_plan
    plan=load_recovery_plan(store,pid,ident,digest);h=plan.get('stopped_handoff')
    if not h:raise ProjectError('Not a stopped recovery handoff')
    _,_,_,e=snapshot(store,**{k:v for k,v in dict(pid=h['project_id'],eid=h['execution_id'],digest=h['expected_review_sha256'],pin=h['expected_certificate_sha256'],operation_id=h['operation_id']).items()})
    if e!=h['evidence']:raise ProjectError('Stopped evidence changed after preparation')
    return dict(plan,controller_connected=False,handoff_evidence_verified=True)


def adopt(store,plan,stop,job,sink):
    """Atomically replace ownership; never remove endpoint exclusion between owners."""
    from .controller_control import ControlEndpointLease
    from .controller_recovery import _save_new
    from .controller_reboot import _save
    h=plan['stopped_handoff'];key=sha((plan['target']['address']+':'+str(plan['target']['port'])).encode())
    path=_endpoint_lease_root()/(key+'.json')
    with endpoint_guard(path):
        if path.with_suffix('.reconciliation.json').exists():raise ProjectError('Reconciliation pending')
        old,checked,raw,e=snapshot(store,h['project_id'],h['execution_id'],h['expected_review_sha256'],h['expected_certificate_sha256'],h['operation_id'])
        if e!=h['evidence'] or checked!=path or old['target']!=plan['target']:raise ProjectError('Stopped handoff binding changed')
        archive=job/'previous-endpoint-lease.json'
        with archive.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        link={'old_project_id':h['project_id'],'old_execution_id':h['execution_id'],'old_review_sha256':h['expected_review_sha256'],
            'old_lease_sha256':sha(raw),'new_project_id':plan['project_id'],'new_plan_id':plan['plan_id'],
            'new_review_sha256':plan['review_sha256'],'new_execution_id':job.name,'device_commands_sent':False}
        _save_new(job/'handoff.json',link);sink(dict(operation='StoppedRecoveryHandoff',**link))
        owner={'target':plan['target'],'review_sha256':stop['review_sha256'],'job_directory':str(job),'stopped_handoff':link}
        _save(job/'new-endpoint-lease.json',owner)
        _save(path,owner)
        lease=object.__new__(ControlEndpointLease);lease.path=path;lease.raw=path.read_bytes();lease.target=plan['target']
        lease.plan_id=plan['plan_id'];lease.review_sha256=stop['review_sha256'];lease.quarantined=False;lease.released=False
        return lease


def finalize_replay(store,plan,job,result):
    """Finish our exact lease release after a persisted success; no controller I/O."""
    if (result.get('status')!='original_loaded_runtime_observed' or result.get('outcome_unknown') is not False
        or result.get('endpoint_lease_retained') is not False or result.get('receipt_persisted') is not True):return False
    raw=_read(job/'new-endpoint-lease.json',65536);owner=_strict_json(raw)
    if (owner.get('target')!=plan['target'] or owner.get('review_sha256')!=plan['children']['stop']['review_sha256']
        or Path(owner.get('job_directory',''))!=job):raise ProjectError('Handoff release owner mismatch')
    path=_endpoint_lease_root()/(sha((plan['target']['address']+':'+str(plan['target']['port'])).encode())+'.json')
    with endpoint_guard(path):
        if path.exists() and path.read_bytes()==raw:
            if path.with_suffix('.reconciliation.json').exists():raise ProjectError('Reconciliation pending')
            path.unlink();return True
    return False
