"""Inspect and snapshot an existing PCWE directory without any controller I/O.

This module does not construct a deployment from a cold-build IMG, regenerate
vendor signatures, create a DAuM ZIP, or claim controller acceptance. It preserves
the supplied PCWE payload, including its original manifest/signature bytes.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
import uuid
import xml.etree.ElementTree as ET

from .project import ProjectError


MANIFEST = 'PCWE.manifest.config'
REQUIRED_FILES = (
    MANIFEST,
    'PCWE.software-package-manifest.json',
    'Plc/Eclr/eCLR.img',
    'Plc/Domain/pcwe.plc.config',
    'Plc/Esm/PCWE.esm.config',
    'Plc/Gds/PCWE.gds.config',
    'Plc/Plm/pcwe.plm.config',
)
MAX_FILES = 10000
MAX_FILE_BYTES = 512 * 1024 * 1024
MAX_TOTAL_BYTES = 2 * 1024 * 1024 * 1024
MAX_METADATA_BYTES = 4 * 1024 * 1024


def overall_hash(hashes, algorithm: str = 'Sha512') -> str:
    """Hash the supplied ASCII hex strings in their original enumeration order.

The vendor's manifest writer may use a different order for XML File elements.
Length checking belongs to the manifest reader; accepting shorter hexadecimal
strings here permits verification against independent standard SHA-512 vectors.
"""
    if algorithm != 'Sha512':
        raise ProjectError('Only the observed Sha512 project-manifest algorithm is supported.')
    digest = hashlib.sha512()
    for value in hashes:
        if not isinstance(value, str) or re.fullmatch(r'[0-9a-f]*', value) is None:
            raise ProjectError('Overall hash inputs must be lowercase ASCII hexadecimal strings.')
        digest.update(value.encode('ascii'))
    return digest.hexdigest()


def _is_link(info) -> bool:
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, 'st_file_attributes', 0) & 0x400)


def _local_path(value, *, directory: bool = True) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute() or str(path).startswith(('\\\\', '//')):
        raise ProjectError('PCWE paths must be absolute local filesystem paths; network paths are unsupported.')
    # Check the original path before resolve() could hide a symlink/junction.
    for part in (path, *path.parents):
        try:
            info = part.lstat()
        except OSError as exc:
            raise ProjectError(f'Local path is unavailable: {part}') from exc
        if _is_link(info):
            raise ProjectError(f'Symlinks and reparse points are unsupported: {part}')
    if directory and not path.is_dir():
        raise ProjectError(f'Expected a PCWE/output directory: {path}')
    return path.resolve()


def _relative_path(value: str) -> str:
    if not isinstance(value, str) or not value or '\\' in value or ':' in value or value.startswith('/'):
        raise ProjectError(f'Unsafe manifest path: {value!r}')
    parts = value.split('/')
    for part in parts:
        if (part in ('', '.', '..') or part.endswith((' ', '.')) or
                re.search(r'[\x00-\x1f<>"|?*]', part) or
                re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', part, re.I)):
            raise ProjectError(f'Unsafe manifest path: {value!r}')
    return value


def _inventory(root: Path) -> list[dict]:
    pending = [root]
    result = []
    seen = set()
    total = 0
    while pending:
        directory = pending.pop()
        try:
            entries = sorted(os.scandir(directory), key=lambda item: item.name)
        except OSError as exc:
            raise ProjectError(f'Cannot enumerate PCWE directory: {directory}') from exc
        for entry in entries:
            path = Path(entry.path)
            relative = _relative_path(path.relative_to(root).as_posix())
            if relative.casefold() in seen:
                raise ProjectError(f'Duplicate case-insensitive PCWE path: {relative}')
            seen.add(relative.casefold())
            info = entry.stat(follow_symlinks=False)
            if _is_link(info):
                raise ProjectError(f'Symlinks and reparse points are unsupported: {relative}')
            if stat.S_ISDIR(info.st_mode):
                pending.append(path)
                continue
            if not stat.S_ISREG(info.st_mode):
                raise ProjectError(f'Non-regular PCWE member: {relative}')
            if info.st_size > MAX_FILE_BYTES:
                raise ProjectError(f'PCWE member exceeds the size limit: {relative}')
            total += info.st_size
            if total > MAX_TOTAL_BYTES or len(result) >= MAX_FILES:
                raise ProjectError('PCWE directory exceeds the total size/file count limit.')
            digest = hashlib.sha512()
            count = 0
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    count += len(chunk)
                    if count > MAX_FILE_BYTES:
                        raise ProjectError(f'PCWE member grew beyond the size limit: {relative}')
                    digest.update(chunk)
            after = path.lstat()
            if _is_link(after) or count != info.st_size or (after.st_size, after.st_mtime_ns) != (info.st_size, info.st_mtime_ns):
                raise ProjectError(f'PCWE member changed during inspection: {relative}')
            result.append({'path': relative, 'bytes': count, 'sha512': digest.hexdigest()})
    return sorted(result, key=lambda item: item['path'])


def _metadata_bytes(root: Path, relative: str, records: dict) -> bytes:
    record = records[relative]
    if not record['bytes'] or record['bytes'] > MAX_METADATA_BYTES:
        raise ProjectError(f'Empty or oversized package metadata: {relative}')
    payload = (root / relative).read_bytes()
    if len(payload) != record['bytes'] or hashlib.sha512(payload).hexdigest() != record['sha512']:
        raise ProjectError(f'Package metadata changed during inspection: {relative}')
    return payload


def _xml(payload: bytes, label: str) -> ET.Element:
    try:
        source = payload.decode('utf-8-sig')
    except UnicodeDecodeError as exc:
        raise ProjectError(f'Only UTF-8 package XML is supported: {label}') from exc
    if re.search(r'<!\s*(?:DOCTYPE|ENTITY)', source, flags=re.I):
        raise ProjectError(f'DTD/entity declarations are unsupported: {label}')
    try:
        return ET.fromstring(source)
    except (ET.ParseError, ValueError) as exc:
        raise ProjectError(f'Malformed package XML: {label}') from exc


def _hex512(value, label):
    if not isinstance(value, str) or re.fullmatch(r'[0-9a-f]{128}', value) is None:
        raise ProjectError(f'Expected lowercase SHA-512 hexadecimal value: {label}')
    return value


def inspect_pcwe(source_path: str | Path) -> dict:
    """Read a complete local PCWE directory and verify its listed file hashes.

An overall-hash mismatch is reported as unknown_order, not corrupt: the original
writer's dictionary enumeration order is absent from the sorted manifest XML.
"""
    root = _local_path(source_path)
    inventory = _inventory(root)
    records = {item['path']: item for item in inventory}
    missing = [name for name in REQUIRED_FILES if name not in records]
    if missing:
        raise ProjectError('Requires a complete PCWE directory, not a cold-build generated/IMG directory; missing: ' + ', '.join(missing))
    if any(not records[name]['bytes'] for name in REQUIRED_FILES):
        raise ProjectError('Required PCWE files must be nonempty.')
    manifest = _xml(_metadata_bytes(root, MANIFEST, records), MANIFEST)
    if manifest.tag != 'ProjectManifestDocument' or manifest.get('schemaVersion') != '1.0':
        raise ProjectError('Unsupported project-manifest document/schema.')
    algorithms = manifest.findall('./Metadata/HashAlgorithm')
    containers = manifest.findall('./Files')
    if len(algorithms) != 1 or algorithms[0].get('type') != 'Sha512' or len(containers) != 1:
        raise ProjectError('Expected exactly one Sha512 manifest file list.')
    container = containers[0]
    expected_overall = _hex512(container.get('overallHash'), 'overallHash')
    declared = {}
    folded = set()
    hashes = []
    for item in container:
        if item.tag != 'File':
            raise ProjectError('Unsupported element in manifest file list.')
        relative = _relative_path(item.get('path'))
        if relative.casefold() in folded or relative.casefold() == MANIFEST.casefold():
            raise ProjectError(f'Duplicate or self-referential manifest member: {relative}')
        folded.add(relative.casefold())
        value = _hex512(item.get('hash'), relative)
        if relative not in records:
            raise ProjectError(f'Manifest member is missing: {relative}')
        if value != records[relative]['sha512']:
            raise ProjectError(f'Manifest file hash mismatch: {relative}')
        declared[relative] = value
        hashes.append(value)
    unlisted = sorted(set(records) - set(declared) - {MANIFEST})
    if not declared or unlisted:
        raise ProjectError('Empty manifest or unlisted PCWE payloads: ' + ', '.join(unlisted))
    calculated = overall_hash(hashes)
    overall_status = 'verified' if calculated == expected_overall else 'unknown_order'
    for relative, expected in (
        ('Plc/Domain/pcwe.plc.config', 'PlcDomainConfigurationDocument'),
        ('Plc/Esm/PCWE.esm.config', 'EsmConfigurationDocument'),
        ('Plc/Gds/PCWE.gds.config', 'GdsConfigurationDocument'),
        ('Plc/Plm/pcwe.plm.config', 'PlmConfigurationDocument'),
    ):
        document = _xml(_metadata_bytes(root, relative, records), relative)
        if document.tag.rsplit('}', 1)[-1] != expected:
            raise ProjectError(f'Unexpected package configuration root: {relative}')
    try:
        software = json.loads(_metadata_bytes(root, 'PCWE.software-package-manifest.json', records))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ProjectError('Malformed software-package metadata.') from exc
    if not isinstance(software, dict) or software.get('manifestVersion') != '1.0' or not isinstance(software.get('identification'), dict):
        raise ProjectError('Unsupported software-package manifest structure.')
    with (root / 'Plc/Eclr/eCLR.img').open('rb') as stream:
        if stream.read(4) != b'RLCE':
            raise ProjectError('Expected the observed eCLR image header; image execution/ABI is not validated.')
    inventory_sha = hashlib.sha256(json.dumps(inventory, ensure_ascii=False, sort_keys=True,
                                              separators=(',', ':')).encode('utf-8')).hexdigest()
    return {'status': 'inspected', 'source_path': str(root), 'inventory_sha256': inventory_sha,
            'file_count': len(inventory), 'listed_file_count': len(declared),
            'total_bytes': sum(item['bytes'] for item in inventory), 'files': inventory,
            'file_hashes_verified': True, 'overall_hash_status': overall_status,
            'overall_hash_expected': expected_overall, 'overall_hash_xml_order': calculated,
            'signature_validation': 'not_performed', 'signatures_rebuilt': False,
            'software_identification': software['identification'],
            'deployable': False, 'controller_connected': False, 'controller_downloaded': False,
            'limitations': [
                'File integrity only; target compatibility, signatures, runtime semantics and controller acceptance are not validated.',
                'An unknown_order overall hash cannot be verified from the sorted manifest alone.',
                'This is an existing PCWE directory; it is not a regenerated cold deployment or a validated DAuM ZIP format.',
            ]}


def stage_pcwe(source_path: str | Path, output_parent: str | Path,
               expected_inventory_sha256: str) -> dict:
    """Copy a hash-bound package into a new local directory and verify all bytes."""
    before = inspect_pcwe(source_path)
    if before['inventory_sha256'] != expected_inventory_sha256:
        raise ProjectError('Stale PCWE inventory hash; inspect the source package again before staging.')
    source = Path(before['source_path'])
    parent = _local_path(output_parent)
    if parent == source or parent.is_relative_to(source):
        raise ProjectError('Output parent must be outside the source PCWE directory.')
    stage_root = parent / ('pcwe-stage-' + uuid.uuid4().hex)
    stage_root.mkdir()
    target = stage_root / 'PCWE'
    target.mkdir()
    try:
        for record in before['files']:
            source_file = source / record['path']
            # Recheck every path component before opening the source for copying.
            _local_path(source_file, directory=False)
            destination = target / record['path']
            destination.parent.mkdir(parents=True, exist_ok=True)
            copied = hashlib.sha512()
            size = 0
            with source_file.open('rb') as reader, destination.open('xb') as writer:
                for chunk in iter(lambda: reader.read(1024 * 1024), b''):
                    size += len(chunk)
                    if size > record['bytes']:
                        raise ProjectError(f'Source grew during staging: {record["path"]}')
                    copied.update(chunk)
                    writer.write(chunk)
            if size != record['bytes'] or copied.hexdigest() != record['sha512']:
                raise ProjectError(f'Source changed during staging: {record["path"]}')
        staged = inspect_pcwe(target)
        after = inspect_pcwe(source)
        if staged['inventory_sha256'] != expected_inventory_sha256 or after['inventory_sha256'] != expected_inventory_sha256:
            raise ProjectError('Source or staged package changed during staging.')
        result = {'status': 'staged_offline', 'source_path': str(source), 'stage_directory': str(stage_root),
                  'pcwe_path': str(target), 'inventory_sha256': expected_inventory_sha256,
                  'file_count': staged['file_count'], 'all_bytes_preserved': True,
                  'file_hashes_verified': True, 'overall_hash_status': staged['overall_hash_status'],
                  'signature_validation': 'not_performed', 'signatures_rebuilt': False,
                  'deployable': False, 'controller_connected': False, 'controller_downloaded': False,
                  'limitations': staged['limitations']}
        (stage_root / 'stage-report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return result
    except (OSError, ValueError, ProjectError) as exc:
        (stage_root / 'stage-failed.json').write_text(json.dumps({'status': 'failed', 'error': str(exc),
            'deployable': False, 'controller_connected': False, 'controller_downloaded': False}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        raise
