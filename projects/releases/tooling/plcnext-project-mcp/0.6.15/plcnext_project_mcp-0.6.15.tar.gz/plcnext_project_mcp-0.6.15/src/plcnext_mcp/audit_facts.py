"""M14 raw fact encoding checks; independent slot/clock proof stays external."""
from .audit_collector import EvidenceError
MODE='decision_clock_slots_v2'
FIELDS={'Event.PollSkippedBefore':'uint32','DecisionFlags':'byte','DecisionRevisionDelta':'byte',
        'DecisionDelayLo':'uint16','DecisionDelayHi':'byte','ReportSkipped':'byte'}
HEAD={'CaptureBuffer.AuditFactSchema':'byte','CaptureBuffer.AuditFactsComplete':'bool'}
SAFE=9007199254740991

def encoding_complete(event):
    bounds={'Event.PollSkippedBefore':4294967295,'DecisionFlags':127,'DecisionRevisionDelta':255,
            'DecisionDelayLo':65535,'DecisionDelayHi':255,'ReportSkipped':255}
    for name,limit in bounds.items():
        value=event[name]
        if type(value) is not int or not 0<=value<=limit:raise EvidenceError('Invalid audit-v2 scalar: '+name)
    flags=event['DecisionFlags']
    if not flags&1:raise EvidenceError('Unpublished decision facts; no ACK')
    complete=flags&57==57 and event['ReportSkipped']!=255
    for name in ('Event.CompletedMonoMs','Event.ClockRevision'):
        v=event[name]
        complete &= type(v) is int and 0<=v<=SAFE
    complete &= event['Event.CompletedMonoMs']+event['DecisionDelayLo']+65536*event['DecisionDelayHi']<=SAFE
    complete &= event['Event.ClockRevision']+event['DecisionRevisionDelta']<=SAFE
    complete &= event['Event.Kind'] in (1,2)
    if flags&64:complete &= event['Event.Kind']==2
    if event['Event.Kind']==2:complete &= event['Event.PollSkippedBefore']==0
    return bool(complete)
