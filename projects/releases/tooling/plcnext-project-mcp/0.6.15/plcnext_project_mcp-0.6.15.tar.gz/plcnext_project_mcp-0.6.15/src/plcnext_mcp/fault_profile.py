"""Explicit instrumented fault profile cloned from the pinned original archive.

The original 32-POU archive is never changed or silently instrumented. A new
managed copy gains a PLC-scan-supervised lease FB plus exactly two Main gates.
The profile must be separately built/deployed/reviewed before any fault can run.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import re
import uuid

from .project import ProjectError, read_archive, pou_index, sha, decode_code

PROFILE_SCHEMA = 'plcnext-instrumented-fault-profile/v1'
PROFILE_VERSION = 'MCP-FAULT-LEASE/1'
ORIGINAL_SHA256 = '7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154'
FB_NAME = 'MCP_FaultLease'
INSTANCE = 'McpFault'
WRITABLE = {'RequestBootId':'utf8','RequestKind':'uint16','RequestTtlMs':'uint32',
            'RequestDeadlineMs':'uint64','RequestId':'uint32','CommitId':'uint32','CancelId':'uint32'}
READABLE = {**WRITABLE,'ProfileVersion':'utf8','ProfileId':'utf8','CurrentBoot':'utf8',
            'Ready':'bool','SeenId':'uint32','ActiveId':'uint32','Active':'bool',
            'BlockConnection':'bool','BlockBusinessAck':'bool','StartedAtMs':'uint64',
            'DeadlineMs':'uint64','ReleasedId':'uint32','ReleaseReason':'byte','NowMs':'uint64'}
READABLE.update(AgentConnected='bool',BlockedAckTotal='uint32',PublishedBatchTotal='uint32',
                ConfirmedBatchTotal='uint32',InvalidAckTotal='uint32')


def resolved_symbols(model,program):
    external={'AgentConnected':program+'.Mqtt.Connected','BlockedAckTotal':program+'.McpFaultBlockedAckTotal',
        'PublishedBatchTotal':'HMI.PublishedBatches','ConfirmedBatchTotal':'HMI.ConfirmedBatches',
        'InvalidAckTotal':'HMI.InvalidAcks'}
    return {name:model.resolve(external.get(name,program+'.'+INSTANCE+'.'+name)) for name in READABLE}

FB_VARIABLES = '''VAR_INPUT
    NowMs : ULINT;
    CurrentBoot : NG_Id;
    Ready : BOOL;
    RequestBootId : NG_Id;
    RequestKind : UINT;
    RequestTtlMs : UDINT;
    RequestDeadlineMs : ULINT;
    RequestId : UDINT;
    CommitId : UDINT;
    CancelId : UDINT;
END_VAR
VAR_OUTPUT
    ProfileVersion : STRING[32];
    ProfileId : STRING[64];
    SeenId : UDINT;
    ActiveId : UDINT;
    Active : BOOL;
    BlockConnection : BOOL;
    BlockBusinessAck : BOOL;
    StartedAtMs : ULINT;
    DeadlineMs : ULINT;
    ReleasedId : UDINT;
    ReleaseReason : USINT;
END_VAR
VAR
    LastNowMs : ULINT;
    ActiveBootId : NG_Id;
    ActiveKind : UINT;
    StageCommit : UDINT;
    StageRequest : UDINT;
    StageBoot : NG_Id;
    StageKind : UINT;
    StageTtl : UDINT;
    StageDeadline : ULINT;
END_VAR
'''


def fb_code(profile_id):
    if re.fullmatch('[0-9a-f]{32}',str(profile_id)) is None:
        raise ProjectError('Invalid unique fault profile ID.')
    return f'''ProfileVersion := '{PROFILE_VERSION}';
ProfileId := '{profile_id}';
BlockConnection := FALSE;
BlockBusinessAck := FALSE;
IF Active THEN
    IF NOT Ready OR (CurrentBoot='') THEN ReleaseReason:=USINT#4; Active:=FALSE;
    ELSIF CurrentBoot<>ActiveBootId THEN ReleaseReason:=USINT#3; Active:=FALSE;
    ELSIF NowMs<LastNowMs THEN ReleaseReason:=USINT#5; Active:=FALSE;
    ELSIF CancelId=ActiveId THEN ReleaseReason:=USINT#2; Active:=FALSE;
    ELSIF NowMs>=DeadlineMs THEN ReleaseReason:=USINT#1; Active:=FALSE;
    END_IF;
    IF NOT Active THEN ReleasedId:=ActiveId; END_IF;
END_IF;
IF (CommitId>SeenId) AND (CommitId<>UDINT#0) THEN
    IF (StageCommit=CommitId) AND (StageRequest=RequestId) AND (StageBoot=RequestBootId)
        AND (StageKind=RequestKind) AND (StageTtl=RequestTtlMs) AND (StageDeadline=RequestDeadlineMs) THEN
        SeenId:=CommitId;
        IF NOT Active AND Ready AND (CurrentBoot<>'') AND (RequestBootId=CurrentBoot)
            AND (RequestId=CommitId) AND ((RequestKind=UINT#1) OR (RequestKind=UINT#2))
            AND (RequestTtlMs>=UDINT#100) AND (RequestTtlMs<=UDINT#300000)
            AND (NowMs>=LastNowMs) AND (RequestDeadlineMs>NowMs)
            AND ((RequestDeadlineMs-NowMs)<=TO_ULINT(RequestTtlMs)) THEN
            Active:=TRUE; ActiveId:=CommitId; ActiveBootId:=CurrentBoot; ActiveKind:=RequestKind;
            StartedAtMs:=NowMs; DeadlineMs:=RequestDeadlineMs; ReleaseReason:=USINT#0;
        ELSE ReleaseReason:=USINT#6;
        END_IF;
    ELSE
        StageCommit:=CommitId; StageRequest:=RequestId; StageBoot:=RequestBootId;
        StageKind:=RequestKind; StageTtl:=RequestTtlMs; StageDeadline:=RequestDeadlineMs;
    END_IF;
END_IF;
IF Active THEN
    BlockConnection:=ActiveKind=UINT#1;
    BlockBusinessAck:=ActiveKind=UINT#2;
END_IF;
LastNowMs:=NowMs;
'''


def _instrument_main(code,variables):
    clock='NowMs := Epoch + TO_ULINT(TO_DINT(Clock.ET));'
    mqtt='Mqtt(Enable := Initialized AND StartupReady,Reconnect := Reconnect,'
    ack_start="        IF RxTopic = CONCAT(Prefix,'data/ack') THEN"
    ack_end='            RxAccept := TRUE; RxStage := 0;'
    if any(code.count(anchor)!=1 for anchor in (clock,mqtt,ack_start)):
        raise ProjectError('Pinned Main clock/MQTT/ACK anchors differ; refusing broad instrumentation.')
    if any(name.casefold() in (code+'\n'+variables).casefold() for name in (INSTANCE,FB_NAME)):
        raise ProjectError('Fault instrumentation names already exist.')
    eol='\r\n' if '\r\n' in code else '\n'
    start=code.index(ack_start)+len(ack_start)
    end=code.index(ack_end,start)
    payload=code[start:end]
    if payload.count('AckReader(')!=1 or payload.count('Outbox[q]:=EmptyPacket;')!=1:
        raise ProjectError('Pinned business-ACK apply block changed.')
    replacement=(eol+'            IF NOT McpFault.BlockBusinessAck THEN'+payload+
        '            ELSE McpFaultBlockedAckTotal:=McpFaultBlockedAckTotal+UDINT#1;'+eol+
        '            END_IF; (* MCP fault: consume blocked ACK without applying it. *)'+eol)
    code=code[:start]+replacement+code[end:]
    code=code.replace(clock,clock+eol+'McpFault(NowMs:=GET_MICROSECONDS(TRUE)/ULINT#1000,CurrentBoot:=BootId,Ready:=Initialized AND StartupReady);',1)
    code=code.replace(mqtt,'Mqtt(Enable := Initialized AND StartupReady AND NOT McpFault.BlockConnection,Reconnect := Reconnect,',1)
    marker=re.search(r'(?m)^VAR[ \t]*\r?\n',variables)
    if marker is None:raise ProjectError('Main has no supported local VAR section.')
    veol='\r\n' if '\r\n' in variables else '\n'
    variables=variables[:marker.end()]+f'    McpFault : {FB_NAME};'+veol+'    McpFaultBlockedAckTotal : UDINT;'+veol+variables[marker.end():]
    return code,variables


def create_fault_profile(store, source_path: str, expected_source_sha256: str=ORIGINAL_SHA256):
    from .runtime_monitor import SourceSymbols
    original=Path(source_path).expanduser().resolve(strict=True)
    raw=original.read_bytes()
    if expected_source_sha256!=ORIGINAL_SHA256 or sha(raw)!=ORIGINAL_SHA256:
        raise ProjectError('Instrumented profile only supports the exact reviewed original restore archive.')
    _,members,_,_=read_archive(original)
    if len(pou_index(members))!=32:raise ProjectError('Pinned restore POU count changed.')
    copied=store.import_copy(str(original));pid=copied['project_id']
    main=store.read_pou(pid,'Main')
    code,variables=_instrument_main(main['code'],main['variables'])
    profile_id=uuid.uuid4().hex
    updated=store.change_structure(pid,copied['project_sha256'],
        add_fbs=[{'pou_name':FB_NAME,'code':fb_code(profile_id),'variables':FB_VARIABLES}],
        updates=[{'pou_name':'Main','expected_code_sha256':main['code_sha256'],
            'expected_variables_sha256':main['variables_sha256'],'code':code,'variables':variables}])
    _,manifest,current,_,_=store._current(pid)
    model=SourceSymbols(current)
    programs=[p for p in model.programs if p['type']=='Main']
    if len(programs)!=1:raise ProjectError('Fault profile requires one explicit Main program instance.')
    symbols=resolved_symbols(model,programs[0]['name'])
    if any(symbols[name]['wire_type']!=kind for name,kind in READABLE.items()):
        raise ProjectError('Generated fault symbols do not match the fixed wire-type profile.')
    if sha(original.read_bytes())!=ORIGINAL_SHA256:
        raise ProjectError('Original changed while the separate profile was prepared.')
    profile={'schema':PROFILE_SCHEMA,'profile_version':PROFILE_VERSION,'profile_id':profile_id,
        'created_utc':datetime.now(timezone.utc).isoformat(),'project_id':pid,
        'project_sha256':updated['project_sha256'],'original_source_sha256':ORIGINAL_SHA256,
        'original_source_path':str(original),'program_instance':programs[0],
        'fb_name':FB_NAME,'instance_name':INSTANCE,'symbols':symbols,'writable_fields':WRITABLE,
        'gates':['Main.final_Mqtt_Enable','Main.business_data_ack_apply_only'],
        'deadline':{'clock':'GET_MICROSECONDS_CLOCK_MONOTONIC_div_1000','maximum_ttl_ms':300000,
            'activation_requires_stable_two_scans':True,'independent_of_host':True,
            'absolute_device_monotonic_expiry_staged_before_commit':True,
            'executes_only_while_plc_task_runs':True,'clock_rollback_releases':True,
            'boot_change_releases':True,'not_ready_releases':True,
            'hardware_realtime_deadline_proven':False},
        'original_archive_changed':False,'deployed':False,'real_backend_verified':False,
        'p06_performance_verified':False}
    profile['profile_sha256']=sha(json.dumps(profile,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    path=store._folder(pid)/'fault-profile.json'
    path.write_text(json.dumps(profile,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {**updated,'profile':profile,'profile_sha256':profile['profile_sha256'],'profile_path':str(path),
        'requires_separate_build_deploy_approval':True}


def load_fault_profile(store, project_id, expected_project_sha256, expected_profile_sha256):
    from .runtime_monitor import SourceSymbols
    path=store._folder(project_id)/'fault-profile.json'
    if not path.is_file() or path.stat().st_size>256*1024:raise ProjectError('Missing bounded instrumented fault profile.')
    profile=json.loads(path.read_text(encoding='utf-8'))
    unsigned={k:v for k,v in profile.items() if k!='profile_sha256'}
    digest=sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    if (profile.get('schema')!=PROFILE_SCHEMA or profile.get('project_id')!=project_id
            or profile.get('project_sha256')!=expected_project_sha256
            or profile.get('profile_sha256')!=expected_profile_sha256 or digest!=expected_profile_sha256
            or profile.get('profile_version')!=PROFILE_VERSION or profile.get('writable_fields')!=WRITABLE
            or profile.get('original_source_sha256')!=ORIGINAL_SHA256):
        raise ProjectError('Instrumented fault profile identity changed.')
    _,manifest,members,_,_=store._current(project_id)
    if manifest['current_sha256']!=expected_project_sha256:raise ProjectError('Fault profile source revision is stale.')
    model=SourceSymbols(members)
    expected=resolved_symbols(model,profile['program_instance']['name'])
    frozen=store._folder(project_id)/'original.pcwex'
    original_raw,original_members,_,_=read_archive(frozen)
    original_main=pou_index(original_members)['Main']['prefix']
    expected_code,expected_variables=_instrument_main(decode_code(original_members[original_main+'Code.st']),
        decode_code(original_members[original_main+'Variables.var']))
    actual_main=store.read_pou(project_id,'Main')
    if (sha(original_raw)!=ORIGINAL_SHA256 or profile['symbols']!=expected
            or store.read_pou(project_id,FB_NAME)['code']!=fb_code(profile['profile_id'])
            or actual_main['code']!=expected_code or actual_main['variables']!=expected_variables
            or profile.get('deadline',{}).get('clock')!='GET_MICROSECONDS_CLOCK_MONOTONIC_div_1000'):
        raise ProjectError('Instrumented fault source/symbol contract changed.')
    return profile
