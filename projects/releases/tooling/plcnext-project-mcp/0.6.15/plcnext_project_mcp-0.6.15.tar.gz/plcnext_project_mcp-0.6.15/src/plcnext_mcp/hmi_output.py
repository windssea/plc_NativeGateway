"""Run the bounded vendor HMI serializer against a source-bound cold model."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess

from .deployment_plan import _verify
from .project import ProjectError, sha

PAGE_FILES = {'gateway.json', 'gateway.variables.json', 'gatewayModule.js',
              'login.json', 'login.variables.json', 'loginModule.js',
              'languages-static.dictionary.json'}


def validate_page_receipt(output: Path, report: dict, build_job: Path, build: dict,
                          type_hash: str, host_hash: str) -> dict[str, bytes]:
    expected_auth = build.get('toolchain', {}).get('profile', {}).get('hmi_authentication_protocol', 0)
    if (report.get('status') != 'pages_generated' or report.get('unsupported')
            or report.get('input_sources_unchanged') is not True
            or report.get('runtime_types_sha256') != type_hash
            or report.get('host_source_sha256') != host_hash
            or report.get('analyzed_ast_sha256') != build['analyzed_compiler_model']['sha256']
            or report.get('authentication_protocol') != expected_auth
            or not report.get('gateway_complete') or not report.get('login_complete')):
        raise ProjectError('HMI receipt does not match the current offline inputs.')
    if any('MessageType=Error' in message for message in report.get('messages', [])):
        raise ProjectError('HMI compiler emitted error diagnostics.')
    sources = report.get('source_files', [])
    expected_sources = {p.removeprefix('project/') for p in build['input_hashes']
        if p.startswith('project/') and (p.lower().endswith(('.proj', '.ds', 'datalist.dl'))
                                        or 'HMI_Server' in p)}
    if not sources or len({s['path'] for s in sources}) != len(sources) or {s['path'] for s in sources} != expected_sources:
        raise ProjectError('Missing, extra or duplicate HMI source receipts.')
    for item in sources:
        name = 'project/' + item['path']
        if build['input_hashes'].get(name) != item['sha256']:
            raise ProjectError('HMI source is not bound to the selected build: ' + name)
        _verify(build_job, name, item['sha256'])
    records = report.get('page_files', [])
    if len(records) != len(PAGE_FILES) or {p['path'] for p in records} != PAGE_FILES:
        raise ProjectError('Incomplete or duplicate HMI output inventory.')
    files = {}
    for item in records:
        path = _verify(output, item['path'], item['sha256'])
        data = path.read_bytes()
        if not data or len(data) != item['size'] or sha(data) != item['sha256']:
            raise ProjectError('Invalid HMI output size: ' + item['path'])
        if item['path'].endswith('.json'):
            json.loads(data)
        files[item['path']] = data
    return files


def validate_page_bindings(report: dict, runtime: dict, types: dict, files: dict) -> None:
    expected = {t['tag_name']: {'name': t['tag_name'], 'data_type': t['data_type'],
        'runtime_path': 'Arp.Plc.Eclr/' + t['name'], 'read_only': t['read_only'] == 'True'}
        for t in runtime['hmi_mappings']}
    tags = report.get('controller_tags', [])
    if len(tags) != len(expected) or {t['name']: t for t in tags} != expected:
        raise ProjectError('HMI controller tags differ from source variable mappings.')
    typemap = {t['Name']: t for t in types['Types']}
    bindings = []
    gateway = json.loads(files['gateway.json'])
    variables = json.loads(files['gateway.variables.json'])
    login_variables = json.loads(files['login.variables.json'])
    if variables.get('variablePathPrefix') != 'Arp.Plc.Eclr/' or login_variables.get('variablePathPrefix') != '@login':
        raise ProjectError('HMI page variable prefix differs from its runtime scope.')
    references = set()
    def collect(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in ('Variable', 'DestinationVariable') and isinstance(child, str):
                    references.add(child)
                collect(child)
        elif isinstance(value, list):
            for child in value:
                collect(child)
    collect(gateway)
    declared = {'Arp.Plc.Eclr/' + v['name'] for v in variables['variables']}
    if len(declared) != len(variables['variables']) or declared != references:
        raise ProjectError('HMI variable inventory differs from actual page references.')
    if len(gateway.get('Objects', [])) != report.get('page_objects'):
        raise ProjectError('HMI page object inventory differs from its compiler receipt.')
    references.clear()
    login = json.loads(files['login.json'])
    collect(login)
    login_declared = {'@login' + v['name'] for v in login_variables['variables']}
    if (len(login_declared) != len(login_variables['variables'])
            or references - {'@@SystemUseNotification'} != login_declared
            or len(login.get('Objects', [])) != report.get('login_page_objects')):
        raise ProjectError('Login variable/object inventory differs from actual page references.')
    for v in variables['variables']:
        parts = v['name'].split('.')
        tag = expected.get(parts[0])
        if tag is None:
            raise ProjectError('Unknown HMI root variable: ' + v['name'])
        current = typemap[tag['data_type']]
        offset = 0
        for part in parts[1:]:
            fields = [f for f in current.get('Fields', []) if f['Name'] == part]
            if current['Kind'] != 'Structure' or len(fields) != 1:
                raise ProjectError('Unknown HMI runtime field: ' + v['name'])
            offset += fields[0]['FieldOffset']
            current = typemap[fields[0]['FieldType']]
        if current['Name'] != v['type'] or offset < 0 or offset + current['RuntimeSize'] > typemap[tag['data_type']]['RuntimeSize']:
            raise ProjectError('HMI runtime type/storage mismatch: ' + v['name'])
        bindings.append({'name': v['name'], 'data_type': current['Name'],
            'runtime_path': tag['runtime_path'], 'offset': offset,
            'size': current['RuntimeSize'], 'read_only': tag['read_only']})
    if report.get('runtime_bindings') != bindings or report.get('runtime_binding_count') != len(bindings):
        raise ProjectError('HMI runtime binding receipt differs from finalized layout.')


def generate_hmi_pages(build_job: Path, finalized_types: Path, output_directory: Path,
                       install: Path) -> tuple[dict[str, bytes], dict]:
    shell = shutil.which('pwsh')
    if os.name != 'nt' or not shell:
        raise ProjectError('HMI generation requires local Windows/PowerShell 7.')
    if output_directory.exists():
        raise ProjectError('HMI output must be a new directory.')
    build_bytes = (build_job / 'result.json').read_bytes()
    build = json.loads(build_bytes)
    model = build.get('analyzed_compiler_model', {})
    if model.get('name') != 'analyzed.LastBuild.ast' or model.get('rebuilt_from_current_sources') is not True:
        raise ProjectError('HMI requires a source-bound analyzed cold compiler model.')
    _verify(build_job, model['name'], model.get('sha256'))
    for name, digest in build['input_hashes'].items():
        _verify(build_job, name, digest)
    # Reject extra files that could otherwise influence directory-based source discovery.
    actual = {p.relative_to(build_job).as_posix() for p in (build_job / 'project').rglob('*') if p.is_file()}
    expected = {p for p in build['input_hashes'] if p.startswith('project/')}
    if actual != expected:
        raise ProjectError('HMI source tree differs from the cold-build inventory.')
    host = Path(__file__).parent / 'hmi_host'
    host_hashes = {p.name: sha(p.read_bytes()) for p in host.iterdir() if p.is_file()}
    type_hash = sha(finalized_types.read_bytes())
    command = [shell, '-NoLogo', '-NoProfile', '-NonInteractive', '-File',
        str(host / 'Invoke-HmiOutputProbe.ps1'), '-WorkRoot', str(build_job),
        '-RuntimeTypesPath', str(finalized_types), '-OutputDirectory', str(output_directory),
        '-InstallDirectory', str(install)]
    # MCP stdio inherits SYSTEMROOT but omits WINDIR. WPF's font metrics reader
    # explicitly uses WINDIR; supply only that missing Windows directory alias.
    environment = dict(os.environ)
    windows = environment.get('WINDIR') or environment.get('SYSTEMROOT')
    if not windows or not (Path(windows) / 'Fonts').is_dir():
        raise ProjectError('Windows font directory is unavailable for HMI serialization.')
    environment['WINDIR'] = windows
    try:
        completed = subprocess.run(command, capture_output=True, timeout=90, env=environment)
    except subprocess.TimeoutExpired as exc:
        raise ProjectError('Offline HMI generation timed out.') from exc
    output_directory.mkdir(exist_ok=True)
    (output_directory / 'stdout.log').write_bytes(completed.stdout)
    (output_directory / 'stderr.log').write_bytes(completed.stderr)
    path = output_directory / 'result.json'
    report = json.loads(path.read_text(encoding='utf-8-sig')) if path.is_file() else {}
    if completed.returncode:
        raise ProjectError('Offline HMI compiler failed; inspect ' + str(path))
    if (build_job / 'result.json').read_bytes() != build_bytes or sha(finalized_types.read_bytes()) != type_hash:
        raise ProjectError('HMI build inputs changed during generation.')
    if any(sha((host / n).read_bytes()) != h for n, h in host_hashes.items()):
        raise ProjectError('HMI host changed during generation.')
    _verify(build_job, model['name'], model['sha256'])
    files = validate_page_receipt(output_directory, report, build_job, build, type_hash,
                                  host_hashes['HmiOutputProbe.cs'])
    for assembly in report.get('vendor_assemblies', []):
        _verify(install, assembly['name'] + '.dll', assembly['sha256'])
    report['host_hashes'] = host_hashes
    report['page_hashes_verified'] = True
    return files, report
