"""Closed tagged RSC read-value codec measured with the vendor MemoryStream oracle.

No CLR type reconstruction, arbitrary objects, pointers, writes or networking.
Only null and finite scalar values required by the read-only monitor are admitted.
"""
from __future__ import annotations

import math
import struct

from . import rsc_tagged_codec as tagged

DATA_ACCESS = 'Arp.Plc.Gds.Services.IDataAccessService'
PLC_INFO = 'Arp.Plc.Domain.Services.IPlcInfoService'
ERROR_NAMES = {0: 'None', 1: 'NotExists', 2: 'NotAuthorized', 3: 'TypeMismatch',
    4: 'PortNameSyntaxError', 5: 'PortNameSemanticError', 6: 'IndexOutOfRange',
    7: 'NotImplemented', 8: 'NotSupported', 9: 'CurrentlyUnavailable',
    10: 'UnvalidSubscription', 11: 'NoData', 12: 'InvalidConfig',
    13: 'StringConversionFailed', 14: 'StringLengthExceeds', 255: 'Unspecified'}
SCALAR_TAGS = {v[0]: k for k, v in tagged._SCALARS.items()}


class RuntimeValueReader:
    def __init__(self, read, *, maximum_bytes=65536, maximum_string_bytes=4096):
        if not callable(read) or type(maximum_bytes) is not int or not 64 <= maximum_bytes <= 1048576:
            raise ValueError('A bounded runtime byte reader is required.')
        if type(maximum_string_bytes) is not int or not 1 <= maximum_string_bytes <= 32768:
            raise ValueError('Invalid runtime string bound.')
        self.read, self.maximum_bytes = read, maximum_bytes
        self.maximum_string_bytes, self.position = maximum_string_bytes, 0

    def take(self, count):
        if type(count) is not int or count < 0 or self.position + count > self.maximum_bytes:
            raise ValueError('Runtime response exceeds byte limit.')
        result = bytearray()
        while len(result) < count:
            part = self.read(count - len(result))
            if type(part) is not bytes or not part or len(part) > count - len(result):
                raise ValueError('Truncated or invalid runtime response.')
            result.extend(part)
        self.position += count
        return bytes(result)

    def number(self, fmt):
        return struct.unpack('<' + fmt, self.take(struct.calcsize('<' + fmt)))[0]

    def variant(self):
        tag = self.number('B')
        if tag in (0, 1):
            # The oracle emits 01 for a null object. 00 is rejected: not measured.
            if tag == 0:
                raise ValueError('Unmeasured null runtime tag.')
            return {'wire_type': 'null', 'wire_tag': tag, 'value': None}
        if tag in SCALAR_TAGS:
            schema = SCALAR_TAGS[tag]
            if schema == 'bool':
                raw = self.number('B')
                if raw not in (0, 1):
                    raise ValueError('Invalid runtime Boolean.')
                value = bool(raw)
            else:
                value = self.number(tagged._SCALARS[schema][1])
                if schema.startswith('float') and not math.isfinite(value):
                    raise ValueError('Nonfinite runtime value is unsupported.')
            return {'wire_type': schema, 'wire_tag': tag, 'value': value}
        if tag == 19:
            count = self.number('H')
            if not 1 <= count <= self.maximum_string_bytes:
                raise ValueError('Runtime string exceeds its byte limit.')
            raw = self.take(count)
            if raw[-1:] != b'\0' or b'\0' in raw[:-1]:
                raise ValueError('Invalid runtime UTF-8 terminator.')
            return {'wire_type': 'utf8', 'wire_tag': tag, 'value': raw[:-1].decode('utf-8', 'strict')}
        raise ValueError(f'Unsupported runtime value tag 0x{tag:02x}; composite/raw memory reads are not admitted.')

    def item(self):
        if self.take(1) != b'\x05':
            raise ValueError('ReadItem error type is not the measured byte enum.')
        error = self.number('B')
        return {'error_code': error, 'error_name': ERROR_NAMES.get(error, 'Unknown'), **self.variant()}


def receive_read_items(read, *, expected_count, maximum_bytes=65536):
    if type(expected_count) is not int or not 1 <= expected_count <= 64:
        raise ValueError('Runtime request count must be 1..64.')
    reader = RuntimeValueReader(read, maximum_bytes=maximum_bytes)
    if reader.take(4) != b'\x14\x12\x02\x00':
        raise ValueError('Expected the measured ReadItem[] schema.')
    count = reader.number('i')
    if count != expected_count:
        raise ValueError('Runtime response item count differs from the request.')
    result = [reader.item() for _ in range(count)]
    if reader.take(1) != b'\xff':
        raise ValueError('Runtime invocation terminator missing.')
    return result


def receive_variant(read, *, maximum_bytes=65536):
    reader = RuntimeValueReader(read, maximum_bytes=maximum_bytes)
    result = reader.variant()
    if reader.take(1) != b'\xff':
        raise ValueError('Runtime invocation terminator missing.')
    return result


def encode_variant(value):
    """Own-code local fixture encoder; requires an explicit measured wire type."""
    if type(value) is not dict or set(value) != {'wire_type', 'value'}:
        raise ValueError('Explicit runtime fixture type/value required.')
    schema, data = value['wire_type'], value['value']
    if schema == 'null' and data is None:
        return b'\x01'
    if schema not in tagged._SCALARS and schema != 'utf8':
        raise ValueError('Unsupported runtime fixture scalar.')
    return tagged.encode_value(schema, data)


def encode_read_items(items):
    if type(items) is not list or not 1 <= len(items) <= 64:
        raise ValueError('Runtime fixture items must be 1..64.')
    result = bytearray(b'\x14\x12\x02\x00' + struct.pack('<i', len(items)))
    for item in items:
        if (type(item) is not dict or set(item) != {'error_code', 'wire_type', 'value'}
                or type(item['error_code']) is not int or not 0 <= item['error_code'] <= 255):
            raise ValueError('Invalid runtime fixture ReadItem.')
        result += b'\x05' + bytes([item['error_code']])
        result += encode_variant({k: item[k] for k in ('wire_type', 'value')})
    result += b'\xff'
    if len(result) > 65536:
        raise ValueError('Runtime fixture response exceeds byte bound.')
    return bytes(result)
