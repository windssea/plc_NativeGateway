"""Explicit original-project recovery under one reviewed, one-use operation plan.

No failure triggers an automatic restore or retry. A recovery plan is a separate
operation with its own operator receipt; it does not extend a download receipt.
The endpoint lease stays held across observation, Stop, transfer, Start and read
verification. Device-side loaded hashes remain distinct from causal Load proof.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import time
import uuid

from .controller_download_plan import (_digest, _strict_json, prepare_download_review,
    revalidate_download_review, review_package_snapshot)
from .controller_transfer import _journal_sink, _persist_result, execute_transfer
from .controller_transport import ControllerEndpoint, ControllerFailure, DownloadScope, TlsControllerClient, _AUTHORITY
from .deployment_plan import _file
from .operator_approval import OperatorApprovalContract, validate_operator_receipt
from .plc_state import HOT, stable_state
from .project import ProjectError, sha, xml

SCHEMA = 'plcnext-controller-recovery-plan/v1'
RECEIPT_SCHEMA = 'plcnext-controller-recovery-operator-approval/v1'
ACTIONS = ['observe_before', 'stop', 'write_package_paths', 'sha512_readback',
           'reset', 'load', 'start', 'verify_runtime']


def _policy(plan_id, volatile_data_policy, start_kind, expected_initial_state, config, maximum_runtime_observations=3, runtime_observation_interval_seconds=5):
    if (type(maximum_runtime_observations) is not int or not 1<=maximum_runtime_observations<=24
            or type(runtime_observation_interval_seconds) is not int or not 5<=runtime_observation_interval_seconds<=10
            or maximum_runtime_observations*runtime_observation_interval_seconds>240):
        raise ProjectError("Observation window must be 1..24 observations at 5..10 seconds, at most 240 seconds.")
    from .rsc_start_control import start_kind_value
    if volatile_data_policy not in ('require_drain','record_unknown_loss'):
        raise ProjectError('Unsupported recovery volatile-data policy.')
    start_kind_value(start_kind)
    if type(expected_initial_state) is not int or not any(stable_state(expected_initial_state, base) for base in (2,3)):
        raise ProjectError('Recovery requires an explicit exact initial Stop or Running state.')
    if (type(config) is not dict or set(config)!={'version','device_count','point_count','enabled'}
            or type(config['version']) is not int or not 0<=config['version']<=2**64-1
            or type(config['device_count']) is not int or not 1<=config['device_count']<=50
            or type(config['point_count']) is not int or not 1<=config['point_count']<=320
            or type(config['enabled']) is not bool):
        raise ProjectError('Invalid recovery configuration expectations.')
    return {'purpose':'restore_known_original','plan_id':plan_id,
        'volatile_data_policy':volatile_data_policy,'start_kind':start_kind,
        'expected_initial_state_raw':expected_initial_state,'expected_configuration':config,
        'continuous_endpoint_lease':True,'automatic_retry':False,'automatic_rollback':False,
        'delete_old_files':False,'full_pcwe_write':True,'operation_timeout_seconds':300,
        'maximum_runtime_observations':maximum_runtime_observations,'runtime_observation_interval_seconds':runtime_observation_interval_seconds,
        'preserved_unlisted_remote_files_acknowledged':True}


def _save_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def prepare_recovery_plan(store, project_id, expected_project_sha256, package_job_id,
                           address, expected_certificate_sha256, *, port=41100,
                           volatile_data_policy='require_drain', expected_configuration=None,
                           start_kind='cold', expected_initial_state=3, maximum_runtime_observations=3, runtime_observation_interval_seconds=5, audit_duration_seconds=None, audit_closure_mode='raw_tail', audit_tail_seconds=10, audit_fact_mode='legacy_v1'):
    from .controller_control import prepare_control_review
    from .runtime_monitor import prepare_runtime_read_plan
    if volatile_data_policy not in ('require_drain', 'record_unknown_loss'):
        raise ProjectError('Recovery RAM policy must require_drain or explicitly record_unknown_loss.')
    config = expected_configuration if expected_configuration is not None else {
        'version': 13, 'device_count': 50, 'point_count': 250, 'enabled': True}
    if (type(config) is not dict or set(config) != {'version', 'device_count', 'point_count', 'enabled'}
            or any(type(config[k]) is not int or config[k] < 0 for k in ('version','device_count','point_count'))
            or type(config['enabled']) is not bool or not 1 <= config['point_count'] <= 320):
        raise ProjectError('Exact bounded version/device_count/point_count/enabled expectations are required.')
    if audit_fact_mode not in ('legacy_v1','decision_clock_slots_v2'):raise ProjectError('Unsupported audit fact mode')
    if audit_closure_mode not in ('raw_tail','source_cohort') or type(audit_tail_seconds) is not int or not 1<=audit_tail_seconds<=120:
        raise ProjectError('Invalid audit closure mode/tail bound')
    if audit_duration_seconds is None and (audit_closure_mode!='raw_tail' or audit_tail_seconds!=10 or audit_fact_mode!='legacy_v1'):
        raise ProjectError('Audit closure options require audit_duration_seconds')
    if audit_duration_seconds is not None and (type(audit_duration_seconds) is not int or not 1<=audit_duration_seconds<=120
            or audit_duration_seconds+maximum_runtime_observations*runtime_observation_interval_seconds+audit_tail_seconds>240):
        raise ProjectError('Audit plus runtime observation budgets must fit 240 seconds, reserving transfer time.')
    plan_id = uuid.uuid4().hex
    policy=_policy(plan_id,volatile_data_policy,start_kind,expected_initial_state,config,maximum_runtime_observations,runtime_observation_interval_seconds)
    common = (store, project_id, expected_project_sha256, package_job_id, address, expected_certificate_sha256)
    download = prepare_download_review(*common, port=port)
    stop = prepare_control_review(*common, 'stop', port=port,
        expected_initial_state=expected_initial_state, plan_id=plan_id)
    start = prepare_control_review(*common, 'start', port=port,
        start_kind=start_kind, expected_initial_state=2, plan_id=plan_id)
    monitor = prepare_runtime_read_plan(store, project_id, expected_project_sha256,
        address, expected_certificate_sha256, port=port, point_count=config['point_count'],
        include_samples=True, include_configuration=True)
    child = lambda r: {'review_id':r['review_id'], 'review_sha256':r['review_sha256']}
    plan = {'schema': SCHEMA, 'review_id': plan_id, 'plan_id':plan_id, 'project_id':project_id,
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'status':'recovery_plan_prepared', 'write_authorized':False,
        'authorization_status':'awaiting_mcp_authorization',
        'source':download['source'], 'package':download['package'], 'target':download['target'],
        'files':download['files'], 'approved_actions':list(ACTIONS),
        'children':{'download':child(download), 'stop':child(stop), 'start':child(start),
            'monitor':{'plan_id':monitor['plan_id'], 'plan_sha256':monitor['plan_sha256']}},
        'policy':policy,
        'impact':{'program_interruption':True, 'ram_state_may_be_lost':True,
            'pending_event_loss_proven_zero':False, 'physical_output_hold_behavior_verified':False,
            'explicit_start_planned':True, 'unexpected_autostart_after_load_unverified':True,
            'download_memento':download['package'].get('download_memento'),
            'restore_is_explicit_operation_not_failure_handler':True},
        'verification_limits':['RAM loss is unknown unless independently complete drain evidence exists.',
            'A guarded read window is not an atomic 250-point snapshot.',
            'ProjectName and disk manifests are not memory-loaded module hashes.',
            'DATA/STORED/Hub/mock acceptance is provided by the external joint verifier.',
            'A local endpoint lease does not prevent another user or external Engineer from changing the PLC.'],
        'aci_used':False, 'computer_use_used':False, 'controller_connected':False}
    if audit_duration_seconds is not None:
        if type(audit_duration_seconds) is not int or not 1<=audit_duration_seconds<=120:
            raise ProjectError('Parent audit duration must be 1..120 seconds.')
        from .audit_export import prepare as prepare_audit
        audit=prepare_audit(store,project_id,expected_project_sha256,package_job_id,address,
            expected_certificate_sha256,'observe_same_parent_start',port=port,
            duration_seconds=audit_duration_seconds,parent_plan_id=plan_id,closure_mode=audit_closure_mode,tail_seconds=audit_tail_seconds,fact_mode=audit_fact_mode)
        plan['children']['audit']={'plan_id':audit['plan_id'],'plan_sha256':audit['plan_sha256']}
        plan['approved_actions'].append('fsync_and_ack_fixed_audit_cursors_after_same_start')
    plan['review_sha256'] = _digest(plan)
    directory = _file(store._folder(project_id), 'controller-recovery-plans/'+plan_id)
    directory.mkdir(parents=True, exist_ok=False)
    _save_new(directory/'plan.json', plan)
    return plan | {'plan_sha256':plan['review_sha256'], 'plan_path':str(directory/'plan.json')}


def load_recovery_plan(store, project_id, plan_id, expected_plan_sha256, *, revalidate=True):
    if type(plan_id) is not str or re.fullmatch('[0-9a-f]{32}',plan_id) is None:
        raise ProjectError('Invalid recovery plan ID.')
    path = _file(store._folder(project_id), 'controller-recovery-plans/'+plan_id+'/plan.json')
    if not path.is_file() or path.stat().st_size > 4*1024*1024:
        raise ProjectError('Missing or oversized recovery plan.')
    plan = _strict_json(path.read_bytes())
    if (plan.get('schema') != SCHEMA or plan.get('project_id') != project_id
            or plan.get('review_id') != plan_id or plan.get('plan_id') != plan_id
            or plan.get('review_sha256') != expected_plan_sha256 or _digest(plan) != expected_plan_sha256
            or plan.get('approved_actions') != (ACTIONS+['fsync_and_ack_fixed_audit_cursors_after_same_start'] if 'audit' in plan.get('children',{}) else ACTIONS)):
        raise ProjectError('Recovery plan identity or hash mismatch.')
    policy=plan.get('policy',{})
    if (policy!=_policy(plan_id,policy.get('volatile_data_policy'),policy.get('start_kind'),
            policy.get('expected_initial_state_raw'),policy.get('expected_configuration'),
            policy.get('maximum_runtime_observations'),policy.get('runtime_observation_interval_seconds'))
            or plan.get('write_authorized') is not False
            or plan.get('authorization_status') not in ('awaiting_mcp_authorization','awaiting_user_confirmation')
            or set(plan.get('children',{})) not in ({'download','stop','start','monitor'},{'download','stop','start','monitor','audit'})):
        raise ProjectError('Recovery policy or child set changed.')
    if revalidate:
        from .controller_control import revalidate_control_review
        from .runtime_monitor import load_runtime_read_plan
        for name in ('stop','start'):
            child = plan['children'][name]
            review = revalidate_control_review(store,project_id,child['review_id'],child['review_sha256'])
            if (review['target'] != plan['target'] or review['source'] != plan['source']
                    or review['package'] != plan['package'] or review['policy']['plan_id'] != plan_id
                    or review['policy']['action']!=name
                    or review['policy']['expected_initial_state_raw']!=(policy['expected_initial_state_raw'] if name=='stop' else 2)
                    or name=='start' and review['policy']['start_kind']!=policy['start_kind']):
                raise ProjectError('Recovery child control bindings changed.')
        child = plan['children']['download']
        review = revalidate_download_review(store,project_id,child['review_id'],child['review_sha256'])
        if any(review[key] != plan[key] for key in ('target','source','package','files')):
            raise ProjectError('Recovery download binding changed.')
        child = plan['children']['monitor']
        monitor = load_runtime_read_plan(store,project_id,child['plan_id'],child['plan_sha256'])
        if (monitor['project_sha256'] != plan['source']['project_sha256']
                or monitor['target']!={k:plan['target'][k] for k in ('address','port','expected_certificate_sha256')}
                or monitor['point_count_requested']!=policy['expected_configuration']['point_count']):
            raise ProjectError('Recovery monitor source binding changed.')
    if revalidate and 'audit' in plan['children']:
        from .audit_export import load as load_audit
        ref=plan['children']['audit'];_,audit,_=load_audit(store,project_id,ref['plan_id'],ref['plan_sha256'])
        if (audit['target']!=plan['target'] or audit['project_sha256']!=plan['source']['project_sha256']
                or audit['inventory_sha256']!=plan['package']['inventory_sha256']
                or audit['policy'].get('parent_recovery_plan_id')!=plan_id
                or audit['policy'].get('boot_binding')!='observe_same_parent_start'):
            raise ProjectError('Parent/audit child binding mismatch.')
    return plan


def approval_contract(store, project_id, plan_id, expected_plan_sha256):
    plan = load_recovery_plan(store,project_id,plan_id,expected_plan_sha256)
    return OperatorApprovalContract(kind='recovery', review_sha256=plan['review_sha256'],
        receipt_schema=RECEIPT_SCHEMA, approval_directory='controller-recovery-approvals',
        binding_fields={key:plan[key] for key in ('target','policy','approved_actions','children')} | {
            'project_sha256':plan['source']['project_sha256'],
            'inventory_sha256':plan['package']['inventory_sha256'], **({'stopped_handoff':plan['stopped_handoff']} if 'stopped_handoff' in plan else {})}, display=plan).checked()


def _consume(store, plan, execution_id):
    contract = approval_contract(store,plan['project_id'],plan['plan_id'],plan['review_sha256'])
    directory = _file(store.root,contract.approval_directory)
    path = _file(directory,plan['review_sha256']+'.json')
    if path.with_suffix('.revoked.json').exists():
        raise ControllerFailure('approval_revoked','Recovery approval was revoked.')
    if path.with_suffix('.denied.json').exists():
        raise ControllerFailure('approval_denied','Recovery approval was denied.')
    if not path.is_file() or path.stat().st_size > 65536:
        raise ControllerFailure('user_confirmation_required','No independent operator confirmation for this exact recovery plan.')
    raw = path.read_bytes()
    if len(raw)>65536:
        raise ControllerFailure('user_confirmation_required','Oversized recovery approval.')
    record = _strict_json(raw)
    validate_operator_receipt(record,contract)
    claim = path.with_suffix('.claimed.json')
    try:
        _save_new(claim,{'schema':'plcnext-recovery-claim/v1','execution_id':execution_id,
            'review_sha256':plan['review_sha256'],'approval_sha256':sha(raw)})
    except FileExistsError as exc:
        raise ControllerFailure('approval_already_consumed','Recovery plan approval was already consumed; reconcile before new work.') from exc
    if path.read_bytes() != raw or path.with_suffix('.revoked.json').exists() or path.with_suffix('.denied.json').exists():
        raise ControllerFailure('approval_changed','Recovery approval changed while being claimed.')
    return 'mcp_authorized' if record['confirmed_by'] == 'mcp_policy' else 'operator_confirmed'


def verify_original_runtime(observation, expected):
    """Report unknowns explicitly; never upgrade Running into collection proof."""
    values = {row['symbol']:row['value'] for row in observation.get('items',[])
              if row.get('status') == 'read'}
    fields = {'version':'Active.Version', 'device_count':'Active.DeviceCount',
              'point_count':'Active.PointCount','enabled':'Active.enabled'}
    checks = {}
    for key,suffix in fields.items():
        matches = [v for name,v in values.items() if name.endswith('.'+suffix)]
        checks[key] = {'expected':expected[key], 'observed':matches[0] if len(matches)==1 else None,
            'status':('match' if matches[0] == expected[key] and type(matches[0]) is type(expected[key])
                      else 'mismatch') if len(matches)==1 else 'unknown'}
    quality = observation.get('quality_coverage',{})
    quality_verified = (quality.get('requested') == expected['point_count']
        and quality.get('read') == expected['point_count'] and quality.get('good') == expected['point_count']
        and quality.get('complete_expected_point_coverage') is True
        and quality.get('all_requested_good') is True)
    coherent = (observation.get('status') in ('monitor_read_completed','monitor_read_partial')
        and observation.get('consistency')=='guarded_window_observation')
    return {'configuration':checks,'configuration_matches':coherent and all(x['status']=='match' for x in checks.values()),
        'quality_coverage':quality,'all_points_good_observed':coherent and quality_verified,
        'sampling_summary':observation.get('configuration_digest'),
        'sampling_summary_matches_original':None,
        'program_running_observed':stable_state(observation.get('plc_state_after'), 3),
        'atomic_snapshot':False, 'consistency':observation.get('consistency','unknown'),
        'real_data_and_stored_verified':False,'mock_values_verified':False,
        'joint_acceptance':'pending_external_DATA_STORED_and_mock_evidence'}


def _wait_monitor_interval(last_started, interval, deadline, cancel_event):
    while last_started is not None and time.monotonic()-last_started<interval:
        if cancel_event is not None and cancel_event.is_set():
            raise ControllerFailure('recovery_cancelled','Recovery cancelled before the next read window.')
        if time.monotonic()>=deadline:
            raise ControllerFailure('recovery_timeout','Recovery operation deadline expired.')
        time.sleep(min(.1,interval-(time.monotonic()-last_started)))


from .releases import release_operation


@release_operation(load_recovery_plan)
def execute_recovery_plan(store, project_id, plan_id, expected_plan_sha256, *, cancel_event=None):
    from .endpoint_guard import endpoint_guard
    replay_plan=load_recovery_plan(store,project_id,plan_id,expected_plan_sha256)
    guard=_file(store._folder(project_id),'controller-recovery-plans/'+plan_id+'/execution')
    with endpoint_guard(guard):
        receipt=guard.parent/'handoff-execution.json'
        if receipt.exists():
            record=_strict_json(receipt.read_bytes())
            if record.get('review_sha256')!=expected_plan_sha256:raise ProjectError('Handoff execution identity mismatch')
            previous=_file(store._folder(project_id),'controller-recoveries/'+record['execution_id'])
            if (previous/'result.json').exists() and (previous/'journal.jsonl').exists():
                last=_strict_json((previous/'journal.jsonl').read_bytes().splitlines()[-1])
                if last.get('operation')=='ExecutionOutcome' and last.get('receipt_persisted') is True:
                    saved=_strict_json((previous/'result.json').read_bytes())
                    if (saved.get('review_sha256')!=expected_plan_sha256 or saved.get('execution_id')!=record['execution_id']
                        or last.get('status')!=saved.get('status') or last.get('outcome_unknown')!=saved.get('outcome_unknown')):
                        raise ProjectError('Handoff replay terminal identity mismatch')
                    from .stopped_recovery import finalize_replay
                    released=finalize_replay(store,replay_plan,previous,saved)
                    return dict(saved,replayed=True,lease_release_reconciled=released)
            raise ProjectError('Handoff execution interrupted; endpoint remains excluded. No automatic replay of device actions.')
        return _execute_recovery_plan(store,project_id,plan_id,expected_plan_sha256,cancel_event=cancel_event)


def _execute_recovery_plan(store, project_id, plan_id, expected_plan_sha256, *, cancel_event=None):
    from .controller_control import (ControlEndpointLease, ControlScope, _CONTROL_AUTHORITY,
        ControllerControlClient, execute_control, load_control_review)
    from .runtime_monitor import RuntimeReadClient, read_runtime_plan
    if cancel_event is not None and not callable(getattr(cancel_event,'is_set',None)):
        raise ProjectError('Recovery cancellation requires an internal Event-like object.')
    plan=load_recovery_plan(store,project_id,plan_id,expected_plan_sha256)
    execution_id=uuid.uuid4().hex
    job=_file(store._folder(project_id),'controller-recoveries/'+execution_id)
    stop_ref,start_ref=(plan['children'][k] for k in ('stop','start'))
    stop=load_control_review(store,project_id,stop_ref['review_id'],stop_ref['review_sha256'])
    start=load_control_review(store,project_id,start_ref['review_id'],start_ref['review_sha256'])
    authorized=mutated=False;lease=None;sink=None;last_monitor=None;audit_session=None
    deadline=time.monotonic()+plan['policy']['operation_timeout_seconds']
    result={'schema':'plcnext-controller-recovery-result/v1','execution_id':execution_id,
        'project_id':project_id,'plan_id':plan_id,'review_sha256':expected_plan_sha256,
        'inventory_sha256':plan['package']['inventory_sha256'],'target':plan['target'],
        'status':'recovery_running','stage':'approval','controller_changed':False,
        'original_package_loaded':False,'original_configuration_verified':False,
        'collection_verified':False,'original_program_restored':False,
        'original_project_restored':False,'joint_acceptance_complete':False,
        'outcome_unknown':False,'automatic_retry':False,'automatic_rollback':False,
        'endpoint_lease_retained':False,'aci_used':False,'computer_use_used':False,'steps':[],
        'runtime_observations':[],'controller_connected':False}
    def active():
        progress=getattr(cancel_event,'record_progress',None)
        if callable(progress):progress(result['stage'])
        if cancel_event is not None and cancel_event.is_set():
            raise ControllerFailure('recovery_cancelled','Recovery cancelled; previously sent device actions are not undone.')
        if time.monotonic()>=deadline:
            raise ControllerFailure('recovery_timeout','The bounded recovery operation deadline expired.')
        if lease is not None:lease.validate(stop)
    def guarded_sink(event):
        active()
        sink(dict(event,recovery_stage=result['stage'],execution_id=execution_id))
    class DeadlineBound:
        def _deadline(self):
            super()._deadline();self._end=min(self._end,deadline)
    class ReadClient(DeadlineBound,RuntimeReadClient):pass
    class TransferClient(DeadlineBound,TlsControllerClient):pass
    class ControlClient(DeadlineBound,ControllerControlClient):pass
    startup_boot=None;startup_retry=False
    def monitor():
        nonlocal last_monitor,startup_boot,startup_retry
        active()
        _wait_monitor_interval(last_monitor,plan['policy']['runtime_observation_interval_seconds'],deadline,cancel_event)
        active();last_monitor=time.monotonic()
        ref=plan['children']['monitor']
        observation=read_runtime_plan(store,project_id,ref['plan_id'],ref['plan_sha256'],
            client_factory=lambda *args,**kwargs:ReadClient(*args,event_sink=guarded_sink,**kwargs))
        last_monitor=time.monotonic()  # Wait from completion, conservatively beyond the persisted start stamp.
        result['last_observation']={k:observation.get(k) for k in ('observation_id','observation_sha256','report_path','status','consistency')}
        startup_retry=False
        if result['stage']=='verify_runtime':
            from .startup_observation import classify
            startup_retry,startup_boot=classify(observation,plan['policy']['expected_configuration'],startup_boot)
            if startup_retry:return observation
        if observation.get('status') not in ('monitor_read_completed','monitor_read_partial'):
            raise ControllerFailure('recovery_observation_failed','Runtime observation failed or changed identity; no later action is inferred safe.')
        if observation.get('plc_state_before')!=observation.get('plc_state_after'):
            raise ControllerFailure('recovery_observation_invalidated','PLC state changed during the observation window.')
        result['controller_connected']=not ipaddress.ip_address(plan['target']['address']).is_loopback
        return observation
    def brief(observation):
        return {k:observation.get(k) for k in ('observation_id','observation_sha256','report_path','status','consistency')}
    try:
        job.mkdir(parents=True,exist_ok=False)
        journal=job/'journal.jsonl';sink=_journal_sink(journal);result['journal_path']=str(journal)
        sink({'operation':'RecoveryBinding','execution_id':execution_id,'review_sha256':expected_plan_sha256,
            'project_sha256':plan['source']['project_sha256'],'inventory_sha256':plan['package']['inventory_sha256'],
            'target':plan['target'],'plan_id':plan_id})
        if 'stopped_handoff' in plan:
            authorization_scope=_consume(store,plan,execution_id);authorized=True
            _save_new(_file(store._folder(project_id),'controller-recovery-plans/'+plan_id+'/handoff-execution.json'),
                {'execution_id':execution_id,'review_sha256':expected_plan_sha256})
            result['handoff_responsibility_retained']=True
            from .stopped_recovery import adopt
            lease=adopt(store,plan,stop,job,sink)
            result['stopped_handoff']=plan['stopped_handoff']
        else:
            lease=ControlEndpointLease(stop,job)
            authorization_scope=_consume(store,plan,execution_id);authorized=True
        result['endpoint_lease_path']=str(lease.path)
        result['authorization_scope']=authorization_scope
        active()
        result['stage']='observe_before';before=monitor()
        result['baseline_observation']=brief(before)
        if before.get('plc_state_after')!=plan['policy']['expected_initial_state_raw']:
            raise ControllerFailure('recovery_initial_state_mismatch','Baseline state differs from the exact recovery review.')
        result['volatile_event_loss']={'status':'unknown','zero_loss_verified':False,
            'policy':plan['policy']['volatile_data_policy'],
            'affected_scope':'All unpersisted program-instance RAM, including pending samples, queue/outbox ownership and in-flight acknowledgements.',
            'event_count_unknown':True,'partial_queue_counters_do_not_prove_drain':True,
            'prior_boot_observations':[{'symbol':row['symbol'],'value':row.get('value'),'status':row.get('status')}
                for row in before.get('guards_before',[]) if row['symbol'].endswith('.BootId')]}
        if plan['policy']['volatile_data_policy']=='require_drain':
            raise ControllerFailure('drain_evidence_required','No complete external joint drain evidence is attached; no Stop was sent.')
        endpoint=ControllerEndpoint(plan['target']['address'],plan['target']['port'],plan['target']['expected_certificate_sha256'])
        def control(review,verifier=None):
            active();lease.validate(review)
            scope=ControlScope(review,authorization_scope,authority=_CONTROL_AUTHORITY)
            client=ControlClient(endpoint,control_scope=scope,event_sink=guarded_sink)
            return execute_control(client,review,verify_loaded_identity=verifier,cancel_event=cancel_event)
        from .controller_preflight import strict_download_preflight
        result['stage']='preflight_before_stop';ref=plan['children']['download']
        result['download_preflight']=strict_download_preflight(store,project_id,ref['review_id'],ref['review_sha256'],
            deadline=deadline,event_sink=guarded_sink,expected_state=plan['policy']['expected_initial_state_raw'])
        if result['download_preflight']['status']!='preflight_passed':
            raise ControllerFailure('preflight_rejected','Full transfer preflight rejected before Stop; inspect download_preflight.')
        result['stage']='stopping';outcome=control(stop);result['steps'].append(outcome)
        mutated=outcome.get('action_sent',False)
        if not outcome.get('terminal_state_verified') or outcome.get('status')=='control_failed':
            result['outcome_unknown']=outcome.get('outcome_unknown',False)
            raise ControllerFailure('recovery_cancelled' if outcome.get('failure_code') in ('control_cancelled','recovery_cancelled')
                else 'recovery_stop_failed','Stop did not complete with its exact terminal state and clean session.')
        active();load_recovery_plan(store,project_id,plan_id,expected_plan_sha256)
        result['stage']='transferring';ref=plan['children']['download']
        _,files=review_package_snapshot(store,project_id,ref['review_id'],ref['review_sha256'])
        scope=DownloadScope(endpoint,files,authorization_scope,authority=_AUTHORITY,review_sha256=ref['review_sha256'])
        load=execute_transfer(TransferClient(endpoint,scope=scope,event_sink=guarded_sink),files)
        load.update(execution_id=execution_id,plan_id=plan_id,project_id=project_id,
            source_project_sha256=plan['source']['project_sha256'],inventory_sha256=plan['package']['inventory_sha256'],
            review_sha256=ref['review_sha256'])
        mutated=mutated or bool(load.get('mutation_request_count'));result['steps'].append(load)
        result['original_package_loaded']=load.get('load_state_verified') is True
        result['outcome_unknown']=load.get('outcome_unknown',False)
        _save_new(job/'load-result.json',load)
        completed='loopback_download_passed' if ipaddress.ip_address(endpoint.address).is_loopback else 'controller_download_completed'
        if load.get('status')!=completed:
            raise ControllerFailure('recovery_cancelled' if load.get('failure_code')=='recovery_cancelled'
                else 'recovery_transfer_failed','Recovery transfer or configuration load did not complete.')
        active();load_recovery_plan(store,project_id,plan_id,expected_plan_sha256)
        if 'audit' in plan['children']:
            from .recovery_audit import ParentAudit
            audit_session=ParentAudit(store,plan,lease,job,load,active,deadline)
        result['stage']='verify_loaded_cause'
        probe=ReadClient(endpoint,[],timeout_seconds=5,event_sink=guarded_sink)
        try:
            probe.connect();fresh=probe.get_state();name=probe.project_name();observed=time.monotonic()
        finally:
            cleanup=probe.close()
        if cleanup:
            raise ControllerFailure('recovery_probe_cleanup_failed','Loaded-identity probe did not close cleanly.')
        document=xml(files['Plc/Domain/pcwe.plc.config'])
        names=[e.get('name') for e in document.iter() if e.tag.rsplit('}',1)[-1]=='Project']
        name_matches=len(names)==1 and name.get('value')==names[0] and name.get('wire_type')=='utf8'
        journal_prefix=journal.read_bytes()
        records=[json.loads(line) for line in journal_prefix.splitlines()]
        binding=records[0] if records else {}
        binding_ok=all(binding.get(k)==v for k,v in {'operation':'RecoveryBinding','execution_id':execution_id,
            'review_sha256':expected_plan_sha256,'project_sha256':plan['source']['project_sha256'],
            'inventory_sha256':plan['package']['inventory_sha256'],'target':plan['target'],'plan_id':plan_id}.items())
        from .controller_transport import PLC,FILE
        transfer_events=[record for record in records if record.get('recovery_stage')=='transferring'
            and record.get('operation')=='Invoke' and record.get('send_attempted')
            and record.get('response_received')]
        required_events=[(FILE,9),(PLC,4),(PLC,1)]
        if load.get('files_written',0)>0:
            required_events.append((FILE,8))
        else:
            binding_ok=binding_ok and (load.get('files_written')==0
                and set(load.get('files_skipped_identical',[]))==set(files)
                and load.get('files_compared')==len(files))
        for service,method in required_events:
            binding_ok=binding_ok and any(record.get('service')==service and record.get('method')==method
                for record in transfer_events)
        evidence={'source':'same_plan_verified_load','loaded_package_identity_verified':True,
            'observed_loaded_inventory_sha256':plan['package']['inventory_sha256'],'target':plan['target'],
            'plan_id':plan_id,'lease_held_continuously':True,'journal_binding_verified':binding_ok,
            'readback_all_files_verified':load.get('files_verified')==len(files),
            'load_state_verified':load.get('load_state_verified') is True,'fresh_plc_state_raw':fresh,
            'fresh_project_name_matches':name_matches,'load_execution_id':execution_id,
            'load_receipt_sha256':sha((job/'load-result.json').read_bytes()),
            'load_journal_sha256':sha(journal_prefix),'load_journal_prefix_bytes':len(journal_prefix),
            'project_name_observation':name,'device_loaded_module_hash_read':False,'outside_tool_changes_excluded':False}
        def verify(client,review):
            active();lease.validate(review)
            if time.monotonic()-observed>5:
                raise ControllerFailure('loaded_identity_stale','Verified Load/project-name evidence is no longer fresh.')
            if (sha((job/'load-result.json').read_bytes())!=evidence['load_receipt_sha256']
                    or sha(journal.read_bytes()[:len(journal_prefix)])!=evidence['load_journal_sha256']):
                raise ControllerFailure('loaded_identity_mismatch','Bound Load receipt/journal prefix changed before Start.')
            return evidence
        result['stage']='starting';outcome=control(start,verify);result['steps'].append(outcome)
        mutated=mutated or outcome.get('action_sent',False)
        result['outcome_unknown']=result['outcome_unknown'] or outcome.get('outcome_unknown',False)
        if not outcome.get('terminal_state_verified') or outcome.get('status')=='control_failed':
            raise ControllerFailure('recovery_cancelled' if outcome.get('failure_code') in ('control_cancelled','recovery_cancelled')
                else 'recovery_start_failed','Start did not complete with exact Running and a clean session.')
        if audit_session is not None:
            result['stage']='audit_after_start'
            result['audit_result']=audit_session.run(outcome)
            result['outcome_unknown']=result['outcome_unknown'] or result['audit_result']['outcome_unknown']
            if not result['audit_result']['complete']:
                raise ControllerFailure('parent_audit_incomplete','Audit prefix/tail was not fully verified; no automatic restore or retry.')
        result['stage']='verify_runtime'
        for attempt in range(plan['policy']['maximum_runtime_observations']):
            active();after=monitor()
            result['runtime_observations'].append(brief(after))
            if startup_retry:
                if attempt+1==plan['policy']['maximum_runtime_observations']:
                    raise ControllerFailure('recovery_observation_failed','Startup read budget exhausted; invalid windows discarded')
                continue
            check=verify_original_runtime(after,plan['policy']['expected_configuration'])
            result['runtime_verification']=check;result['runtime_observation']=brief(after)
            result['original_configuration_verified']=check['configuration_matches']
            result['original_program_restored']=(result['original_package_loaded'] and check['configuration_matches']
                and check['program_running_observed'] and check['all_points_good_observed'])
            if result['original_program_restored']:break
        load_recovery_plan(store,project_id,plan_id,expected_plan_sha256)
        result.update(status='original_loaded_runtime_observed' if result['original_program_restored']
            else 'original_loaded_verification_incomplete',stage='completed')
        # This completion only proves the MCP portion. External DATA/STORED,
        # mock values, original sampling digest and RAM-loss evidence remain separate.
        result['original_project_restored']=False
        result['collection_verified']=False
    except Exception as exc:
        result.update(status='recovery_failed',failure_code=getattr(exc,'code','recovery_error'),error_class=type(exc).__name__)
        if isinstance(exc,(ProjectError,ControllerFailure)):result['error']=str(exc)
    finally:
        if result['status']=='recovery_running':
            result.update(status='recovery_failed',failure_code='recovery_interrupted',outcome_unknown=True)
        if audit_session is not None:
            try:
                if not audit_session.finished:audit_session.abort()
            except Exception as exc:
                result['outcome_unknown']=True
                result['audit_receipt_error_class']=type(exc).__name__
            result['audit_result']=dict(audit_session.result)
            result['outcome_unknown']=result['outcome_unknown'] or result['audit_result']['outcome_unknown']
        mutated=mutated or any(step.get('action_sent') or step.get('mutation_request_count',0) for step in result['steps'])
        result['controller_changed']=bool(mutated)
        from .controller_transport import PLC,FILE
        traces=[e for step in result['steps'] for e in step.get('trace',[]) if e.get('send_attempted')]
        result['action_counts']={name:sum(e.get('service')==service and e.get('method')==method for e in traces)
            for name,service,method in [('stop',PLC,3),('file_write',FILE,8),('reset',PLC,4),('load',PLC,1),('start',PLC,2)]}
        if len(result['steps'])==2 and result['stage']=='transferring':
            child=result['steps'][1]
            result['transfer_failure']={k:child.get(k) for k in ('stage','failure_code','path_comparison','mutation_request_count','configuration_reset_attempted','configuration_load_attempted','outcome_unknown')}
            if result['steps'][0].get('terminal_state_verified') and child.get('mutation_request_count')==0 and not child.get('outcome_unknown') and not child.get('cleanup_error_class'):
                result['recovery_handoff']={'tool':'project_prepare_stopped_recovery','project_id':project_id,
                    'execution_id':execution_id,'expected_review_sha256':expected_plan_sha256,
                    'expected_certificate_sha256':plan['target']['expected_certificate_sha256'],
                    'requires_explicit_restore_project_source_package_and_configuration':True}

        result['cancelled']=result.get('failure_code')=='recovery_cancelled' or any(step.get('cancelled')
            or step.get('failure_code') in ('control_cancelled','recovery_cancelled') for step in result['steps'])
        result['cancelled']=result['cancelled'] or result.get('audit_result',{}).get('cancelled',False)
        incomplete=result['status'] in ('recovery_failed','original_loaded_verification_incomplete')
        if lease is not None and authorized and (mutated or 'stopped_handoff' in plan) and (incomplete or result['outcome_unknown']):
            lease.quarantine()
            result['endpoint_quarantine_reason']=('unknown_device_outcome' if result['outcome_unknown']
                else 'business_verification_incomplete' if result['status']=='original_loaded_verification_incomplete'
                else 'known_execution_failure')
        result['endpoint_lease_retained']=bool(lease and lease.quarantined) or bool(lease is None and 'stopped_handoff' in plan)
        if 'stopped_handoff' in plan and incomplete:result['recovery_responsibility']='Stopped/changed device remains under explicit recovery responsibility; no automatic Start or rollback.'
        if job.exists():
            try:_persist_result(job/'result.json',result,_journal_sink(job/'journal.jsonl'))
            except Exception as exc:
                result.update(receipt_persisted=False,receipt_error_class=type(exc).__name__)
            if authorized and not result.get('receipt_persisted') and lease is not None:
                lease.quarantine();result['endpoint_lease_retained']=True
        if lease is not None and not lease.quarantined:
            try:lease.release()
            except (OSError,ControllerFailure) as exc:
                result.update(endpoint_lease_retained=True,lease_cleanup_error_class=type(exc).__name__)
    return result


def _issue_public_loopback_receipt(store,plan,peer):
    """Fixture-only receipt for this newly owned random-port peer, never a real target."""
    from datetime import timedelta
    from .recovery_test_peer import LocalRecoveryPeer
    if (not isinstance(peer,LocalRecoveryPeer) or peer.address!='127.0.0.1' or peer.connections!=0
            or plan['target']['address']!=peer.address or plan['target']['port']!=peer.port
            or plan['target']['expected_certificate_sha256']!=peer.certificate_sha256
            or not peer.thread_alive):
        raise ProjectError('PUBLIC recovery receipt can only target this owned unused loopback peer.')
    contract=approval_contract(store,plan['project_id'],plan['plan_id'],plan['review_sha256'])
    now=datetime.now(timezone.utc)
    record={'schema':contract.receipt_schema,'review_sha256':contract.review_sha256,
        'confirmed_by':'human_user',**contract.binding_fields,
        'confirmation_reference':'PUBLIC LOCAL FIXTURE ONLY; not actual human authorization for a controller',
        'confirmed_utc':now.isoformat(),'expires_utc':(now+timedelta(minutes=5)).isoformat()}
    validate_operator_receipt(record,contract)
    directory=_file(store.root,contract.approval_directory);directory.mkdir(parents=True,exist_ok=True)
    _save_new(directory/(contract.review_sha256+'.json'),record)


def test_recovery_plan(store,project_id,expected_project_sha256,package_job_id,*,fault='none'):
    """Same production recovery executor, one owned peer, PUBLIC fixture approval only."""
    from .controller_download_plan import _binding
    from .runtime_monitor import _source, nativegateway_runtime_preset
    from .recovery_test_peer import LocalRecoveryPeer,FAULTS
    if fault not in FAULTS:raise ProjectError('Unsupported loopback recovery fault.')
    _,_,_,files=_binding(store,project_id,expected_project_sha256,package_job_id)
    folder,_,model=_source(store,project_id,expected_project_sha256)
    values={}
    for symbol in nativegateway_runtime_preset(model,point_count=250,include_configuration=True):
        try:descriptor=model.resolve(symbol)
        except ProjectError:continue
        dtype=descriptor['wire_type']
        if dtype=='utf8':value='GOOD' if symbol.endswith('.Quality') else 'PUBLIC-old-boot' if symbol.endswith('.BootId') else 'PUBLIC'
        elif dtype=='bool':value=True
        elif symbol.endswith('.Active.Version'):value=13
        elif symbol.endswith('.Active.DeviceCount'):value=50
        elif symbol.endswith('.Active.PointCount'):value=250
        elif dtype.startswith('float'):value=230.1
        else:value=1
        values[descriptor['path']]={'wire_type':dtype,'value':value}
    directory=folder/'controller-recovery-tests'/uuid.uuid4().hex
    directory.mkdir(parents=True,exist_ok=False)
    with LocalRecoveryPeer(directory/'peer',files,values,fault=fault) as peer:
        plan=prepare_recovery_plan(store,project_id,expected_project_sha256,package_job_id,
            peer.address,peer.certificate_sha256,port=peer.port,volatile_data_policy='record_unknown_loss')
        _issue_public_loopback_receipt(store,plan,peer)
        key=sha((peer.address+':'+str(peer.port)).encode('ascii'))
        lease_path=Path.home()/'.plcnext-mcp'/'controller-endpoint-leases'/(key+'.json')
        held=[]
        peer.on_session=lambda _:held.append(lease_path.is_file())
        result=execute_recovery_plan(store,project_id,plan['plan_id'],plan['review_sha256'])
        expected=('original_loaded_runtime_observed' if fault=='none' else
            'original_loaded_verification_incomplete' if fault=='configuration_mismatch' else 'recovery_failed')
        result.update(test_environment='owned_loopback_fixture',real_controller_connected=False,
            public_fixture_receipt_only=True,fault=fault,expected_status=expected,
            fixture_connections=peer.connections,fixture_start_calls=peer.start_calls,
            fixture_stop_calls=peer.stop_calls,fixture_write_calls=peer.write_calls,
            fixture_load_calls=peer.load_calls,fixture_reset_calls=peer.reset_calls,
            fixture_errors=peer.errors,fixture_trace=peer.trace,
            continuous_lease_seen_by_all_sessions=bool(held) and all(held),
            fixture_files_match=peer.snapshot()==files)
        result['test_passed']=(result['status']==expected and not peer.errors
            and result['continuous_lease_seen_by_all_sessions'])
        if fault=='none':result['test_passed'] &= result['original_program_restored'] and result['fixture_files_match']
    path=directory/'result.json';result['test_report_path']=str(path)
    _save_new(path,result)
    return result
