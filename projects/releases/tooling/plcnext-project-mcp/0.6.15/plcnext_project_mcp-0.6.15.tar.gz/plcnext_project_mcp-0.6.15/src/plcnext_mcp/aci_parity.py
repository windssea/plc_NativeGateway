"""Evidence-backed ACI replacement coverage; no target code or network calls.

This is a pinned coverage snapshot of the independent backend, not a runtime
probe or a compatibility shim for the vendor's ACI object model.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from functools import lru_cache
from importlib.resources import files
import json


STATUSES = (
    'independent_verified_supported_scope',
    'partial',
    'research_only',
    'missing',
    'official_stub',
    'contract_only',
)
_RESOURCE = 'aci_contract/aci_2026_0_4.json'


@lru_cache(maxsize=1)
def _manifest() -> dict:
    payload = json.loads(files('plcnext_mcp').joinpath(_RESOURCE).read_text(encoding='utf-8'))
    methods = payload['methods']
    identifiers = [method['method_id'] for method in methods]
    if (payload.get('schema') != 'plcnext-aci-independent-coverage/v1'
            or len(methods) != payload['declared_method_count']
            or len(identifiers) != len(set(identifiers))
            or any(method['status'] not in STATUSES for method in methods)):
        raise ValueError('Invalid packaged ACI coverage snapshot')
    return payload


def aci_replacement_summary() -> dict:
    """Describe all declared ACI methods without treating API inventory as parity."""
    manifest = _manifest()
    methods = manifest['methods']
    domains = []
    for name in sorted({method['domain'] for method in methods}):
        selected = [method for method in methods if method['domain'] == name]
        domains.append({'domain': name, 'declared_methods': len(selected),
                        'status_counts': dict(sorted(Counter(method['status'] for method in selected).items()))})
    return {
        'schema': manifest['schema'], 'snapshot_date': manifest['snapshot_date'],
        'contract_build': manifest['contract_build'],
        'backend': 'independent_native_pcwex',
        'aci_required_by_this_tool': False, 'computer_use_required_by_this_tool': False,
        'network_used_by_this_tool': False, 'full_aci_replacement': False,
        'exact_aci_api_compatibility': False,
        'declared_interfaces': len(manifest['interfaces']),
        'declared_methods': len(methods),
        'status_counts': dict(sorted(Counter(method['status'] for method in methods).items())),
        'status_definitions': deepcopy(manifest['status_definitions']),
        'domains': domains, 'priorities': deepcopy(manifest['priorities']),
        'dependency_boundary': deepcopy(manifest['dependency_boundary']),
        'limitations': deepcopy(manifest['limitations']),
    }


def aci_replacement_coverage(domain: str | None = None, status: str | None = None,
                             offset: int = 0, limit: int = 40,
                             include_details: bool = False) -> dict:
    """Page the 201 explicitly declared interface methods and their acceptance gaps.

    Statuses describe verified scope, partial work, research, missing behavior,
    official stubs or ACI-specific contracts. They are not a completion percentage.
    Collection members inherited from .NET interfaces are identified separately
    in the packaged contract; they are not invented as additional ACI methods.
    """
    if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 60:
        raise ValueError('offset must be a nonnegative integer and limit must be 1..60')
    if type(include_details) is not bool:
        raise ValueError('include_details must be Boolean')
    manifest = _manifest()
    available_domains = sorted({method['domain'] for method in manifest['methods']})
    if domain is not None and domain not in available_domains:
        raise ValueError('Unknown domain; use aci_replacement_summary to list domains')
    if status is not None and status not in STATUSES:
        raise ValueError('Unknown status; use aci_replacement_summary to list statuses')
    selected = [method for method in manifest['methods']
                if (domain is None or method['domain'] == domain)
                and (status is None or method['status'] == status)]
    page = deepcopy(selected[offset:offset + limit])
    if not include_details:
        keys = ('method_id', 'interface', 'method', 'signature', 'token', 'domain',
                'status', 'related_mcp_tools', 'scope', 'gap', 'priority', 'official_behavior')
        page = [{key: method[key] for key in keys} for method in page]
    return {
        'schema': manifest['schema'], 'snapshot_date': manifest['snapshot_date'],
        'contract_build': manifest['contract_build'], 'full_aci_replacement': False,
        'domain_filter': domain, 'status_filter': status, 'total_matched': len(selected),
        'offset': offset, 'limit': limit,
        'next_offset': offset + limit if offset + limit < len(selected) else None,
        'methods': page,
        'warning': 'A listed official API or RPC is not an independently implemented feature. '
                   'Verified supported scope is not full ACI equivalence. '
                   'Research-only device evidence is not a production download capability.',
    }
