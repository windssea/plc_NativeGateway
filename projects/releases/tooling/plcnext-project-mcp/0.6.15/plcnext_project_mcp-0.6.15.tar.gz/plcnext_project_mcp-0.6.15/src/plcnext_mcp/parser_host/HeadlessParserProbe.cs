using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Ade.Compiler;
using Ade.Compiler.Parsing;
using Ade.Components;

// Ordinary host localization adapter: retain resource identifiers verbatim.
// This object implements no licensing or product authorization interface.
public sealed class ParserKeyResources : ICommonResourceService {
    public string GetString(string id) { return id; }
    public string GetString(string id, CultureInfo culture) { return id; }
    public string GetString(string id, string other) { return id; }
    public string GetString(string id, string other, CultureInfo culture) { return id; }
    public string GetString(string id, bool option) { return id; }
    public string GetString(string id, bool option, CultureInfo culture) { return id; }
}

public sealed class ParserCollectedMessages : IMessageSink {
    public readonly List<MessageDescription> Messages = new List<MessageDescription>();
    public int TotalMessages;
    public string GetMessageFromId(string id, CultureInfo culture) { return id; }
    public void AddMessage(MessageDescription value) {
        TotalMessages++;
        if (Messages.Count < 200) Messages.Add(value);
    }
    public void AddMessages(IEnumerable<MessageDescription> values) {
        foreach (var value in values) AddMessage(value);
    }
}

public static class NativeParserProbe {
    public static object Parse(string text, string worksheetName) {
        var parser = new StructuredTextParser();
        parser.GetType().GetProperty("IecScannerFactory").SetValue(parser,
            new Lazy<IIecScannerFactory>(() => new IecScannerFactory()));
        parser.GetType().GetProperty("CommonResourceService").SetValue(parser,
            new Lazy<ICommonResourceService>(() => new ParserKeyResources()));
        var sink = new ParserCollectedMessages();
        using (var input = new StringReader(text)) {
            var result = parser.Parse(input, worksheetName, new ParserParameters(), sink);
            return new {
                status = "completed", stage = "structured_text_syntax_parser",
                errors = result.ErrorCount, warnings = result.WarningCount,
                worksheet_type = result.Node.GetType().FullName,
                worksheet_name = result.Node.Name,
                messages_truncated = sink.TotalMessages > sink.Messages.Count,
                messages = sink.Messages.Select(m => new {
                    type = m.MessageType.ToString(), resource_id = m.ResourceId,
                    type_id = m.TypeId, text = m.Message,
                    location = m.JumpUri == null ? null : m.JumpUri.ToString()
                }).ToArray(),
                whole_project_compiled = false,
                aci_used = false, controller_connected = false
            };
        }
    }
}
