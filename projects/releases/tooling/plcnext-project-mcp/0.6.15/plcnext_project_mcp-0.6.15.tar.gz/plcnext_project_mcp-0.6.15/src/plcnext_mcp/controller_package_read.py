"""Bounded read-only audit/snapshot of exact review-listed remote PCWE paths.

Unlike the legacy two-metadata preflight, this explicitly reads file contents.
No additional manifest path becomes authority, no write/control scope is created,
and a coherent disk package is never presented as an active-memory attestation.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import time
import uuid

from .controller_download_plan import review_package_snapshot
from .controller_preflight import _manifest
from .controller_transport import ControllerEndpoint, ControllerFailure, FILE, TlsControllerClient
from .deployment_package import MANIFEST, _relative_path, inspect_pcwe
from .deployment_plan import _file
from .project import ProjectError, sha


class ReviewedPackageReadClient(TlsControllerClient):
    def __init__(self, endpoint, paths, *, maximum_bytes=33554432, event_sink=None):
        super().__init__(endpoint,preflight_readonly=True,timeout_seconds=30,event_sink=event_sink)
        if (type(paths) not in (tuple,list,set,frozenset) or not 1<=len(paths)<=4096
                or any(type(p) is not str or _relative_path(p)!=p for p in paths)
                or len({p.casefold() for p in paths})!=len(paths)):
            raise ProjectError('A bounded exact reviewed package path list is required.')
        if type(maximum_bytes) is not int or not 1048576<=maximum_bytes<=67108864:
            raise ProjectError('Package read byte budget must be 1..64 MiB.')
        self.allowed_paths=frozenset(paths);self.maximum_bytes=maximum_bytes

    def _receive(self,count):
        if self.bytes_received+count>self.maximum_bytes:
            self.broken=True
            raise ControllerFailure('package_read_byte_limit','Remote package read exceeds its byte budget.')
        return super()._receive(count)

    def _path(self,relative):
        _relative_path(relative)
        if self.root is None or relative not in self.allowed_paths:
            raise ControllerFailure('path_not_authorized','Read path is outside the exact immutable review.')
        return self.root+'/'+relative

    def _validate_call_values(self,service,method,values):
        if (service,method)==(FILE,9):
            if (self.root is None or type(values) is not list or len(values)!=1
                    or type(values[0]) is not list or not 1<=len(values[0])<=64):
                raise ControllerFailure('unreviewed_request','Invalid bounded reviewed ReadMany request.')
            seen=set()
            for item in values[0]:
                if (type(item) is not dict or set(item)!={'path','traits'}
                        or type(item['traits']) is not int or item['traits']!=0
                        or item['path'] not in {self.root+'/'+p for p in self.allowed_paths}
                        or item['path'] in seen):
                    raise ControllerFailure('path_not_authorized','ReadMany cannot extend the immutable review paths.')
                seen.add(item['path'])
            return
        return super()._validate_call_values(service,method,values)


def read_reviewed_controller_package(store,project_id,review_id,expected_review_sha256,*,
                                      capture_files=False,maximum_bytes=33554432):
    if type(capture_files) is not bool:raise ProjectError('capture_files must be Boolean.')
    review,local_files=review_package_snapshot(store,project_id,review_id,expected_review_sha256)
    target=review['target'];endpoint=ControllerEndpoint(target['address'],target['port'],target['expected_certificate_sha256'])
    directory=_file(store._folder(project_id),'controller-package-observations/'+uuid.uuid4().hex)
    client=ReviewedPackageReadClient(endpoint,list(local_files),maximum_bytes=maximum_bytes)
    directory.mkdir(parents=True,exist_ok=False)
    result={'schema':'plcnext-reviewed-remote-package-read/v1','observed_utc':datetime.now(timezone.utc).isoformat(),
        'status':'package_read_failed','project_id':project_id,'review_id':review_id,
        'review_sha256':expected_review_sha256,'source_sha256':review['source']['project_sha256'],
        'target':target,'read_only':True,'controller_downloaded':False,'file_writes_attempted':False,
        'configuration_commands_sent':False,'operator_approval_issued':False,
        'remote_file_contents_verified':False,'memory_loaded_package_verified':False,
        'boot_identity_observed':False,'complete_remote_directory_listing':False,
        'snapshot_is_source_matched_restore_package':False,'maximum_response_bytes':maximum_bytes,
        'response_budget_scope':'decrypted_RSC_bytes_excluding_TLS_handshake',
        'maximum_window_seconds':30,'source_and_package_unchanged':False,
        'atomic_disk_snapshot':False,'same_boot_verified':False,
        'capture_files_requested':capture_files,'snapshot_path':None,'files':[],
        'aci_used':False,'computer_use_used':False}
    payloads={};started=time.monotonic();client.overall_end=started+30
    try:
        client.connect();result['state_before']=client.get_state();client.resolve_root()
        first=client.read_many([MANIFEST])
        if len(first)!=1 or first[0]['result']!=0:
            raise ControllerFailure('remote_manifest_unreadable','Cannot read the reviewed remote manifest.')
        manifest_before=first[0]['data'];paths,declared=_manifest(manifest_before)
        result['remote_manifest_sha256']=sha(manifest_before)
        result['manifest_paths_match_review']=set(paths)==set(local_files)
        result['unread_extra_manifest_paths']=sorted(set(paths)-set(local_files))
        result['missing_reviewed_manifest_paths']=sorted(set(local_files)-set(paths))
        # Never let remote, untrusted manifest entries expand read authority.
        for offset in range(0,len(local_files),16):
            selected=sorted(local_files)[offset:offset+16]
            rows=client.read_many(selected)
            if len(rows)!=len(selected):
                raise ControllerFailure('package_read_partial','Remote ReadMany result count differs from request.')
            for name,row in zip(selected,rows):
                item={'path':name,'result':row['result'],'read_succeeded':row['result']==0}
                if row['result']==0:
                    raw=row['data'];digest=hashlib.sha512(raw).hexdigest()
                    item.update(bytes=len(raw),sha256=sha(raw),sha512=digest,
                        matches_reviewed_candidate=raw==local_files[name],
                        matches_remote_manifest_declaration=(digest==declared.get(name)) if name!=MANIFEST else raw==manifest_before)
                    payloads[name]=raw
                result['files'].append(item)
        last=client.read_many([MANIFEST])
        stable=len(last)==1 and last[0]['result']==0 and last[0]['data']==manifest_before
        result['state_after']=client.get_state()
        stable=stable and result['state_before']==result['state_after']
        result['manifest_and_state_stable_during_window']=stable
        complete=(stable and result['manifest_paths_match_review'] and len(payloads)==len(local_files)
            and all(item.get('matches_remote_manifest_declaration') is True for item in result['files']))
        result.update(status='disk_package_read_verified' if complete else 'disk_package_read_incomplete',
            remote_file_contents_verified=complete,files_read=len(payloads),bytes_read=sum(map(len,payloads.values())),
            changed_from_reviewed_candidate=[r['path'] for r in result['files'] if r.get('matches_reviewed_candidate') is False])
        # Check local association before writing any captured payload. A remote
        # manifest never authorizes extra reads or extends local source identity.
        review_package_snapshot(store,project_id,review_id,expected_review_sha256)
        result['source_and_package_unchanged']=True
        if complete and capture_files:
            pending=directory/'PCWE.pending';pending.mkdir()
            for name,raw in payloads.items():
                path=_file(pending,name);path.parent.mkdir(parents=True,exist_ok=True)
                with path.open('xb') as stream:stream.write(raw)
            inspection=inspect_pcwe(pending)
            # Publication occurs only after complete remote/hash checks, local
            # package inspection and a second local-identity revalidation.
            review_package_snapshot(store,project_id,review_id,expected_review_sha256)
            snapshot=directory/'PCWE'
            if not pending.resolve().is_relative_to(directory.resolve()) or not snapshot.resolve().is_relative_to(directory.resolve()):
                raise ProjectError('Captured snapshot publication escaped its owned observation directory.')
            pending.rename(snapshot)
            result.update(snapshot_path=str(snapshot),snapshot_inventory_sha256=inspection['inventory_sha256'],
                snapshot_signature_verified=False,snapshot_overall_hash_status=inspection['overall_hash_status'])
    except Exception as exc:
        result.update(status='package_read_failed',failure_code=getattr(exc,'code','package_read_error'),
            error_class=type(exc).__name__,remote_file_contents_verified=False,
            source_and_package_unchanged=False,snapshot_path=None)
        pending=directory/'PCWE.pending'
        if pending.exists():result['unpublished_partial_capture_path']=str(pending)
    finally:
        result.update(cleanup_error_class=client.close(),bytes_received=client.bytes_received,
            window_seconds=time.monotonic()-started,trace=client.trace)
        if result['cleanup_error_class']:
            result.update(status='package_read_failed',remote_file_contents_verified=False)
        path=directory/'result.json';result['report_path']=str(path)
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return result
