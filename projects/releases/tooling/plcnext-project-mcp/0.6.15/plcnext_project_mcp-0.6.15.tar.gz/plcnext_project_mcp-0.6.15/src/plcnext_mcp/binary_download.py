"""Bounded RSC v4 calls over a persistent, socket-free TLS loopback.

Both endpoints are local SSLObjects. Public test certificates and a simulated
service registry are used. This is not a real controller transport or a general
stream framer; each supported schema consumes one complete invocation value.
"""
from __future__ import annotations

import secrets

from . import rsc_file_codec as file_codec
from . import rsc_plc_codec as plc_codec
from . import rsc_rpc_codec as rpc
from .download_services import FileSystemError, InMemoryController, ServiceFailure, WriteFileData, device_state
from .offline_tls import MemoryTlsPair
from .rsc_codec import CommandType

PROVIDER = 'Arp'
PASSWORD_SERVICE = 'Arp.System.Security.Services.IPasswordAuthenticationService'
FILE_SERVICE = 'Arp.System.Commons.Services.Io.IFileService2'
FS_SERVICE = 'Arp.System.Commons.Services.Io.IFileSystemInfoService'
PLC_SERVICE = 'Arp.Plc.Domain.Services.IPlcManagerService'
SERVICES = (PASSWORD_SERVICE, FILE_SERVICE, FS_SERVICE, PLC_SERVICE)


class BinaryLoopbackController:
    """MCP's only download backend: supported binary calls, local endpoints."""
    def __init__(self, fault='none', *, token_value=None):
        self._backend = InMemoryController(fault, token_value=token_value)
        self._pair = None
        self._connected = False
        self._closed = False
        self._client_token = None
        self._client_handles = {}
        self._server_handles = {}
        self._provider_handle = secrets.randbelow(20000) + 1
        self._next_handle = secrets.randbelow(10000) + 1
        self.rpc_exchanges = 0
        self.rpc_completed = 0
        self.rpc_cleanup_confirmed = False

    def __getattr__(self, name):
        return getattr(self._backend, name)

    @property
    def loaded(self):
        return self._backend.loaded

    @loaded.setter
    def loaded(self, value):
        self._backend.loaded = value

    def check_peer_policy(self):
        if self._closed:
            raise ServiceFailure('session_closed', 'Offline controller session has been disposed.')
        fault = self.fault if self.fault in ('untrusted_peer', 'hostname_mismatch') else 'none'
        self._pair = MemoryTlsPair(fault)
        self._backend.tls_report = dict(self._pair.report)
        self.record('Simulator.MemoryTlsHandshake', **self.tls_report)
        if not self.tls_report['passed']:
            raise ServiceFailure('peer_not_trusted', 'In-memory TLS rejected the offline test certificate.')
        answer = self._exchange(rpc.encode_connect_request())
        rpc.decode_connect(answer, confirmation=True)
        self._connected = True
        # All handles are assigned by the loopback registry and obtained over
        # TLS; the client has no fixed service/provider handle constants.
        for service in SERVICES:
            answer = self._exchange(rpc.encode_get_service(PROVIDER, service))
            handle, provider = rpc.decode_get_service_confirmation(answer)
            if provider != self._provider_handle or handle <= 0 or handle in self._client_handles.values():
                raise ServiceFailure('service_negotiation_failed', 'Invalid simulated service handle response.')
            self._client_handles[service] = handle

    def _exchange(self, packet):
        if self._closed or self._pair is None:
            raise ServiceFailure('tls_not_ready', 'Offline TLS session has not been initialized.')
        self.rpc_exchanges += 1
        answer = self._pair.exchange(packet, self._dispatch)
        self._backend.tls_report = dict(self._pair.report)
        self.rpc_completed += 1
        return answer

    def _call(self, service, method, body, *, token_override=False):
        if not self._connected or service not in self._client_handles:
            raise ServiceFailure('service_not_ready', 'Offline service negotiation is incomplete.')
        token = None if token_override else self._client_token
        request = rpc.encode_request(self._client_handles[service], method, body, token,
                                     provider_handle=self._provider_handle)
        response = self._exchange(request)
        header, response_token, values = rpc.decode_response(response)
        if response_token is not None:
            raise ServiceFailure('rpc_response_mismatch', 'Unexpected authenticated response header in the bounded profile.')
        if (header.service_handle != self._client_handles[service] or header.method_handle != method
                or header.service_provider_handle != self._provider_handle):
            raise ServiceFailure('rpc_response_mismatch', 'Offline response handles do not match the request.')
        if header.command_type == CommandType.ERROR:
            code, _ = rpc.decode_server_error(response)
            raise ServiceFailure('rsc_server_error', 'Offline RSC server returned error code ' + str(code))
        return values

    def _dispatch(self, packet):
        if self._closed:
            raise ServiceFailure('session_closed', 'Offline controller session has been disposed.')
        # Header byte 2..3 is CommandType. Each helper validates the full header,
        # flags, checksums, payload schema and trailing bytes in its own scope.
        if len(packet) < 16:
            raise ServiceFailure('rpc_truncated', 'Offline request header is truncated.')
        command = int.from_bytes(packet[2:4], 'little')
        if command == CommandType.CONNECT_REQUEST:
            if self._connected:
                raise ServiceFailure('rpc_state', 'Duplicate simulated connect request.')
            rpc.decode_connect(packet)
            self.record('Simulator.RscConnect', selected_version=4, data_tagging=False, datagramming=False)
            return rpc.encode_connect_confirmation()
        if command == CommandType.GET_SERVICE_HANDLES_REQUEST:
            if not self._connected:
                raise ServiceFailure('rpc_state', 'Service lookup preceded connect confirmation.')
            provider, service = rpc.decode_get_service(packet)
            if provider != PROVIDER or service not in SERVICES:
                raise ServiceFailure('service_unknown', 'Unknown simulated RSC service.')
            if service not in self._server_handles:
                self._server_handles[service] = self._next_handle
                self._next_handle += 1
            self.record('Simulator.RscGetServiceHandles', provider=provider, service=service)
            return rpc.encode_get_service_confirmation(self._server_handles[service], self._provider_handle)
        header, token, body = rpc.decode_request(packet)
        if not self._connected or header.service_provider_handle != self._provider_handle:
            raise ServiceFailure('rpc_provider_unknown', 'Unknown simulated provider handle.')
        service = next((name for name, value in self._server_handles.items() if value == header.service_handle), None)
        if service is None:
            raise ServiceFailure('rpc_service_unknown', 'Unknown simulated service handle.')
        if service != PASSWORD_SERVICE:
            if token is None or token != self._backend._token:
                raise ServiceFailure('session_invalid', 'RSC request carries no valid offline token.')
        self.record('Simulator.RscInvoke', service=service, method_id=header.method_handle,
                    argument_bytes=len(body), authenticated_header=token is not None)
        response = self._invoke(service, header.method_handle, body)
        return rpc.encode_response(header.service_handle, header.method_handle, response,
                                   provider_handle=header.service_provider_handle)

    def _invoke(self, service, method, body):
        if service == PASSWORD_SERVICE:
            if method == 1:
                username, password = rpc.decode_create_session(body)
                error, token, penalty = self._backend.create_session(username, password)
                password = None
                if token is None and int(error) == 0:
                    raise ServiceFailure('session_invalid', 'Successful offline authentication returned no token.')
                # The test server chooses a serializable boxed UInt32(0) on
                # failure. This is not a claim about real firmware's failure
                # value; the client checks error before accepting any token.
                return rpc.encode_create_session_result(0 if token is None else token, penalty, int(error))
            if method == 2:
                token = rpc.decode_close_session(body)
                if token != self._backend._token:
                    raise ServiceFailure('session_invalid', 'CloseSession token does not match the offline session.')
                self._backend.close()
                return b''
        elif service == FILE_SERVICE:
            if method == 8:
                values = file_codec.decode_write_many(body, version=4)
                entries = [WriteFileData(v['path'], v['data'], v['overwrite'],
                    v['traits'][0]['value'] if v['traits'] else 0) for v in values]
                return file_codec.encode_file_errors([int(e) for e in self._backend.write_many(entries)])
            if method == 9:
                info = file_codec.decode_read_many_request(body, version=4)
                values = self._backend.read_many([i['path'] for i in info])
                return file_codec.encode_read_many_response([
                    {'result': int(error), 'traits': [], 'data': data} for error, data in values], version=4)
        elif service == FS_SERVICE:
            if method == 1:
                if body:
                    raise ServiceFailure('rpc_extra_data', 'GetSupportedTraits has no parameters.')
                self._backend._authorize()
                self.record('IFileSystemInfoService.GetSupportedTraits', traits=self.supported_traits)
                return file_codec.encode_supported_traits_response(self.supported_traits)
            if method == 5:
                request = file_codec.decode_traits_entry_request(body, version=4)
                if request['path'] != '$ARP_PROJECTS_DIR$/PCWE/' or request['traits'] != 0:
                    raise ServiceFailure('unsafe_remote_path', 'Unexpected simulated symbolic root query.')
                error, root = self._backend.resolve_project_root()
                return file_codec.encode_traits_entry_response({'path': root, 'is_file': False,
                    'is_directory': True, 'traits': []}, result=int(error), version=4)
            if method == 6:
                path = file_codec.decode_space_request(body, version=4)
                if path != self.root:
                    raise ServiceFailure('unsafe_remote_path', 'Unexpected simulated free-space path.')
                free = self._backend.get_space()
                return file_codec.encode_space_response({'capacity': 2 * 1024**3,
                    'free': free, 'available': free}, result=0, version=4)
        elif service == PLC_SERVICE:
            name = {1: 'Load', 4: 'Reset', 5: 'GetPlcState'}.get(method)
            if name is not None:
                request = plc_codec.decode_plc_request(name, body)
                if name == 'GetPlcState':
                    self._backend.get_state()
                    raw = self._backend.trace[-1]['raw']
                    return plc_codec.encode_plc_response(name, raw_state=raw)
                if name == 'Reset':
                    self._backend.reset(async_=request['async_'])
                else:
                    self._backend.load(async_=request['async_'])
                return plc_codec.encode_plc_response(name)
        raise ServiceFailure('rpc_method_unknown', 'Unsupported simulated RSC method.')

    def create_session(self, username, password):
        answer = self._call(PASSWORD_SERVICE, 1, rpc.encode_create_session(username, password), token_override=True)
        token, penalty, error = rpc.decode_create_session_result(answer)
        return error, token, penalty

    def enable_security(self, token):
        self._backend.enable_security(token)
        self._client_token = token

    def get_permissions(self):
        # Application policy double, not a recovered remote permission RPC.
        return self._backend.get_permissions()

    def resolve_project_root(self):
        answer = self._call(FS_SERVICE, 5, file_codec.encode_traits_entry_request('$ARP_PROJECTS_DIR$/PCWE/', version=4))
        response = file_codec.decode_traits_entry_response(answer, version=4)
        if not response['entry']['is_directory'] or response['entry']['is_file']:
            raise ServiceFailure('path_resolution_failed', 'Resolved offline project root is not a directory.')
        return FileSystemError(response['result']), response['entry']['path']

    def get_space(self):
        response = file_codec.decode_space_response(self._call(FS_SERVICE, 6,
            file_codec.encode_space_request(self.root, version=4)), version=4)
        if response['result'] != 0:
            raise ServiceFailure('space_query_failed', 'Offline free-space service returned an error.')
        return response['space']['available']

    def write_many(self, entries):
        supported = file_codec.decode_supported_traits_response(self._call(FS_SERVICE, 1, b''))
        values = [{'path': i.file_path, 'overwrite': i.overwrite,
                   'traits': [{'trait': 1, 'value': i.permissions}] if supported & 1 else [],
                   'data': i.data} for i in entries]
        response = self._call(FILE_SERVICE, 8, file_codec.encode_write_many(values, version=4))
        return [FileSystemError(e) for e in file_codec.decode_file_errors(response)]

    def read_many(self, paths):
        values = [{'path': p, 'traits': 0} for p in paths]
        response = self._call(FILE_SERVICE, 9, file_codec.encode_read_many_request(values, version=4))
        return [(FileSystemError(v['result']), v['data'])
                for v in file_codec.decode_read_many_response(response, version=4)]

    def get_state(self):
        raw = plc_codec.decode_plc_response('GetPlcState', self._call(PLC_SERVICE, 5,
            plc_codec.encode_plc_request('GetPlcState')))
        return device_state(raw)

    def reset(self, async_=True):
        plc_codec.decode_plc_response('Reset', self._call(PLC_SERVICE, 4,
            plc_codec.encode_plc_request('Reset', async_=async_)))

    def load(self, async_=True):
        plc_codec.decode_plc_response('Load', self._call(PLC_SERVICE, 1,
            plc_codec.encode_plc_request('Load', async_=async_)))

    def advance(self, milliseconds):
        self._backend.advance(milliseconds)

    def snapshot(self):
        return self._backend.snapshot()

    def reconcile(self, files):
        # Directory discovery/deletion remain an explicit simulator policy.
        return self._backend.reconcile(files)

    def close(self):
        if self._closed:
            return
        token = self._client_token
        self._client_token = None
        try:
            if token is not None and self._connected:
                answer = self._call(PASSWORD_SERVICE, 2, rpc.encode_close_session(token), token_override=True)
                if answer:
                    raise ServiceFailure('rpc_extra_data', 'Unexpected CloseSession result bytes.')
                self.rpc_cleanup_confirmed = True
        finally:
            # Local cleanup is mandatory even when remote close is uncertain.
            try:
                if not self._backend.session_closed:
                    self._backend.close()
            finally:
                self._closed = True
                self._connected = False
                self._client_handles.clear()
                self._server_handles.clear()
                self._pair = None
