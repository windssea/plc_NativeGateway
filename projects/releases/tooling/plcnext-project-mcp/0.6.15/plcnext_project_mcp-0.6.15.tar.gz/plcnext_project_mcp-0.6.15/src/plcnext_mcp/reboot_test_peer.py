"""Owned loopback TLS peer for device reboot; no physical reboot claim."""
import threading
from types import SimpleNamespace
from . import rsc_tagged_codec as tagged
from .controller_test_peer import LocalTlsController
from .controller_transport import PLC,PROVIDER
from .rsc_codec import CommandType,DATA_TAGGING,DATAGRAMMING,decode_header
from .rsc_runtime_codec import DATA_ACCESS,PLC_INFO,encode_read_items,encode_variant
from .runtime_test_peer import encode_header_for_reply
from .controller_reboot import SERVICE

class LocalRebootPeer(LocalTlsController):
    def __init__(self,root,symbols,values,*,fault='none'):
        if fault not in ('none','commit_reply_lost','stage_mismatch'):raise ValueError('Unsupported audit fixture fault')
        super().__init__(root,initial_state=3,allowed_files=set())
        self.paths={d['path']:name for name,d in symbols.items()}
        self.types={name:d['wire_type'] for name,d in symbols.items()}
        self.model=SimpleNamespace(values=dict(values));self.field_writes=[]
        self.scan_lock=threading.Lock();self.profile_fault=fault
        self.reboot_calls=0;self.auto_run=True;self.boot_changes=True;self.lose_reply=False

    def _session(self,channel):
        connected=False;handles={};provider=1788;next_handle=2100
        while not self._stop.is_set():
            raw=self._exact(channel,16);header,token=decode_header(raw,require_checksum=True)
            if header.command_type==CommandType.CONNECT_REQUEST:
                if connected or header.version!=4 or header.flags!=(DATA_TAGGING|DATAGRAMMING) or header.data_length:raise ValueError('Unexpected fixture Connect.')
                self._reply(channel,tagged.encode_connect_confirmation());connected=True;continue
            if not connected or token is not None or header.flags!=DATA_TAGGING:raise ValueError('Unexpected fixture profile.')
            if header.command_type==CommandType.GET_SERVICE_HANDLES_REQUEST:
                if not 0<=header.data_length<=2054:raise ValueError('Unbounded discovery.')
                names=tagged.decode_get_service(raw+self._exact(channel,header.data_length))
                if names[0]!=PROVIDER or names[1] not in (PLC,PLC_INFO,DATA_ACCESS,SERVICE):raise ValueError('Unknown fixture service.')
                if names[1] not in handles:handles[names[1]]=next_handle;next_handle+=1
                self._reply(channel,tagged.encode_get_service_confirmation(handles[names[1]],provider));continue
            service=next((name for name,value in handles.items() if value==header.service_handle),None)
            if header.command_type!=CommandType.INVOKE_REQUEST or header.service_provider_handle!=provider or header.data_length:raise ValueError('Unexpected fixture invoke.')
            if (service,header.method_handle)==(SERVICE,1):
                tagged.receive_values(lambda n:channel.recv(n),[]);self.reboot_calls+=1
                self._record('RestartDevice',mutating=True)
                if self.boot_changes:self.model.values['BootId']='boot-after-reboot'
                self.state=3 if self.auto_run else 2
                if self.lose_reply:return
                payload=tagged.encode_values([],[])
            elif (service,header.method_handle)==(DATA_ACCESS,3):
                raise ValueError('Reboot fixture denies all variable writes')
            elif (service,header.method_handle)==(DATA_ACCESS,2):
                paths=tagged.receive_values(lambda n:channel.recv(n),['utf8[]'])[0]
                if not 1<=len(paths)<=64:raise ValueError('Invalid snapshot count.')
                rows=[]
                with self.scan_lock:
                    for path in paths:
                        name=self.paths.get(path)
                        rows.append({'error_code':0,'wire_type':self.types[name],'value':self.model.values[name]}
                            if name is not None else {'error_code':1,'wire_type':'null','value':None})
                payload=encode_read_items(rows)
            elif (service,header.method_handle)==(PLC,5):
                tagged.receive_values(lambda n:channel.recv(n),[]);payload=tagged.encode_values(['uint32'],[self.state])
            elif (service,header.method_handle)==(PLC_INFO,1):
                if tagged.receive_values(lambda n:channel.recv(n),['int32'])!=[1]:raise ValueError('Unexpected Info ID.')
                payload=encode_variant({'wire_type':'utf8','value':'PUBLIC fault profile'})+b'\xff'
            else:raise ValueError('Unknown fixture method; no arbitrary write/control.')
            self._reply(channel,encode_header_for_reply(header,payload))
