"""M07 versioned supervision contract and independent-process loopback fixture.

There is deliberately no real PLC writer here: the original restore archive has
no verified independently expiring fault hook. Unsupported real activation is
rejected before receipt consumption or network I/O, instead of treating finally
as protection against host death.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import queue
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import uuid

from .controller_download_plan import _binding, _digest, _target
from .controller_transport import ControllerFailure
from .deployment_plan import _file
from .project import ProjectError

FAULT_ACTIONS = ('agent_connection_offline', 'business_ack_blocked')
FAULT_CONTRACT = 'plcnext-bounded-fault-supervision/v1'
FAULT_REVIEW = 'plcnext-fault-review/v1'


def fault_supervision_capabilities():
    return {'contract_schema': FAULT_CONTRACT, 'implemented': True,
        'loopback_independent_supervisor': True, 'real_backend_available': False,
        'supported_real_source_profiles': [], 'restore_archive_supported': False,
        'real_unavailability_reason': 'No independently expiring boot-bound fault hook is verified in the restore archive.',
        'allowed_faults': list(FAULT_ACTIONS), 'maximum_ttl_ms': 300000,
        'arbitrary_variable_write': False, 'force': False, 'shared_broker_or_hub_control': False,
        'system_clock_or_power_control': False, 'finally_is_independent_recovery': False}


def prepare_fault_review(store, project_id, expected_project_sha256, package_job_id,
                         address, expected_certificate_sha256, expected_boot_id,
                         fault, ttl_ms, port=41100):
    if fault not in FAULT_ACTIONS or type(ttl_ms) is not int or not 100 <= ttl_ms <= 300000:
        raise ProjectError('Fault must be on the fixed whitelist with TTL 100..300000 ms.')
    if type(expected_boot_id) is not str or not 1 <= len(expected_boot_id.encode('utf-8')) <= 128:
        raise ProjectError('An explicit bounded expected boot ID is required.')
    target = _target(address, expected_certificate_sha256, port)
    _, _, binding, _ = _binding(store, project_id, expected_project_sha256, package_job_id)
    review_id = uuid.uuid4().hex
    directory = _file(store._folder(project_id), 'fault-reviews/' + review_id)
    directory.mkdir(parents=True, exist_ok=False)
    review = {'schema': FAULT_REVIEW, 'review_id': review_id, 'project_id': project_id,
        'created_utc': datetime.now(timezone.utc).isoformat(), 'target': target, **binding,
        'expected_boot_id': expected_boot_id, 'policy': {'contract': FAULT_CONTRACT,
            'fault': fault, 'maximum_ttl_ms': ttl_ms, 'allow_extension': False,
            'required_supervisor_independent_of_client': True,
            'release_readback_required': True, 'automatic_retry': False,
            'shared_services_may_be_stopped': False, 'arbitrary_write_or_force': False},
        'approved_actions': ['fault:' + fault, 'fault_release_readback'],
        'authorization_status': 'awaiting_user_confirmation', 'write_authorized': False,
        'status': 'unsupported_real_backend', 'controller_connected': False,
        'runtime_boot_identity_verified': False, 'execution_supported': False,
        'blockers': ['verified_independent_ttl_backend_required', 'fresh_boot_and_loaded_program_binding_required',
                     'separate_exact_operator_approval_required'],
        'impact': {'agent_connection_only': True, 'shared_hub_or_broker_changed': False,
            'business_ack_fault_preserves_real_data_submission': fault == 'business_ack_blocked',
            'fake_stored_generated': False}}
    review['review_sha256'] = _digest(review)
    path = directory / 'review.json'
    path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return review | {'review_path': str(path)}


def execute_fault_review(*args, **kwargs):
    raise ControllerFailure('fault_backend_unsupported',
        'The restore archive has no verified independent hard-TTL fault supervisor; no network or receipt consumption occurred.')


def fixture_request(address, port, token, request):
    if address != '127.0.0.1' or type(port) is not int or not 1 <= port <= 65535:
        raise ProjectError('Fault fixture only accepts literal owned loopback endpoints.')
    payload = json.dumps(dict(request, token=token), separators=(',', ':')).encode() + b'\n'
    if len(payload) > 4096:
        raise ProjectError('Fault fixture request exceeds bound.')
    with socket.create_connection((address, port), timeout=1) as channel:
        channel.settimeout(1)
        channel.sendall(payload)
        result = bytearray()
        while not result.endswith(b'\n') and len(result) <= 65536:
            block = channel.recv(min(4096, 65537-len(result)))
            if not block:
                break
            result.extend(block)
        if not result.endswith(b'\n') or len(result) > 65536:
            raise ControllerFailure('fault_fixture_protocol_error', 'Incomplete or oversized fixture response.')
        data = json.loads(result)
        if data.get('status') != 'ok':
            raise ControllerFailure('fault_fixture_rejected', data.get('error', 'Fault fixture rejected request.'))
        return data['state']


class LocalFaultSupervisor:
    """Own new fixture directory and a separate process with a fixed lifetime."""
    def __init__(self, root, *, boot_id='PUBLIC-fixture-boot', inventory_sha256='a'*64,
                 fixture_fault='none', maximum_lifetime_seconds=10):
        if fixture_fault not in ('none', 'release_failure'):
            raise ProjectError('Unknown fault-supervisor fixture failure.')
        if type(maximum_lifetime_seconds) is not int or not 2 <= maximum_lifetime_seconds <= 60:
            raise ProjectError('Fixture lifetime must be 2..60 seconds.')
        if type(boot_id) is not str or not boot_id or len(boot_id) > 128 or re.fullmatch('[0-9a-f]{64}', inventory_sha256) is None:
            raise ProjectError('Invalid fixture boot or inventory identity.')
        self.root = Path(root).absolute()
        if self.root.exists() and (not self.root.is_dir() or any(self.root.iterdir())):
            raise ProjectError('Fault fixture root must be new/empty.')
        if self.root.is_symlink() or getattr(self.root,'is_junction',lambda:False)():
            raise ProjectError('Fault fixture root cannot be a link.')
        self.root.mkdir(parents=True, exist_ok=True)
        self.root = self.root.resolve()
        self.boot_id, self.inventory_sha256 = boot_id, inventory_sha256
        self.token = secrets.token_hex(32)
        self.fixture_fault = fixture_fault
        self.maximum_lifetime_seconds = maximum_lifetime_seconds
        self.process = None

    def start(self):
        if self.process is not None:
            raise ProjectError('Fault fixture already started.')
        flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        self.process = subprocess.Popen([sys.executable,'-I','-m','plcnext_mcp.fault_supervisor_worker'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=flags, text=True, encoding='utf-8')
        config = {'root': str(self.root), 'boot_id': self.boot_id, 'inventory_sha256': self.inventory_sha256,
            'token': self.token, 'fixture_fault': self.fixture_fault,
            'maximum_lifetime_seconds': self.maximum_lifetime_seconds}
        self.process.stdin.write(json.dumps(config) + '\n'); self.process.stdin.flush()
        answers = queue.Queue()
        thread = threading.Thread(target=lambda:answers.put(self.process.stdout.readline()), daemon=True)
        thread.start()
        try:
            line = answers.get(timeout=5)
            answer = json.loads(line)
            if answer.get('address') != '127.0.0.1':
                raise ValueError('Unexpected fixture bind.')
            self.address,self.port = answer['address'],answer['port']
        except Exception:
            self.process.kill(); self.process.wait(timeout=3)
            raise
        return self

    def command(self, request):
        return fixture_request(self.address,self.port,self.token,request)

    def activate(self, fault, ttl_ms, *, request_id=None, boot_id=None, inventory_sha256=None):
        return self.command({'operation':'activate','request_id':request_id or uuid.uuid4().hex,
            'boot_id':boot_id or self.boot_id, 'inventory_sha256':inventory_sha256 or self.inventory_sha256,
            'fault':fault,'ttl_ms':ttl_ms})

    def observe(self):
        return self.command({'operation':'observe'})

    def cancel(self, request_id, *, boot_id=None):
        return self.command({'operation':'cancel','request_id':request_id,'boot_id':boot_id or self.boot_id})

    def close(self):
        if self.process is None:
            return
        if self.process.poll() is None:
            try:self.command({'operation':'shutdown'})
            except (OSError,ControllerFailure):pass
            try:self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill();self.process.wait(timeout=3)
        for pipe in (self.process.stdin,self.process.stdout,self.process.stderr):
            if pipe is not None:pipe.close()

    def __enter__(self):
        return self.start()

    def __exit__(self,*args):
        self.close()


def test_fault_supervision(store, project_id, expected_project_sha256, package_job_id, *, fault='none'):
    if fault not in ('none','client_exit','cancel','boot_change','release_failure'):
        raise ProjectError('Unsupported supervision fixture test.')
    _binding(store,project_id,expected_project_sha256,package_job_id)
    directory=_file(store._folder(project_id),'fault-supervisor-tests/'+uuid.uuid4().hex)
    directory.mkdir(parents=True,exist_ok=False)
    with LocalFaultSupervisor(directory/'peer',fixture_fault='release_failure' if fault=='release_failure' else 'none') as peer:
        request_id=uuid.uuid4().hex
        child_exited=False
        if fault=='client_exit':
            code="import json,os,sys; from plcnext_mcp.fault_supervision import fixture_request; c=json.loads(sys.stdin.readline()); fixture_request(c['address'],c['port'],c['token'],c['request']); os._exit(21)"
            request={'operation':'activate','request_id':request_id,'boot_id':peer.boot_id,
                'inventory_sha256':peer.inventory_sha256,'fault':'business_ack_blocked','ttl_ms':200}
            flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
            child=subprocess.run([sys.executable,'-I','-c',code],input=json.dumps({'address':peer.address,
                'port':peer.port,'token':peer.token,'request':request})+'\n',text=True,encoding='utf-8',
                capture_output=True,timeout=3,creationflags=flags)
            if child.returncode!=21:
                raise ControllerFailure('fault_fixture_client_exit_failed','Synthetic fault client did not reach its explicit exit point.')
            child_exited=True
            started=peer.observe()
        else:
            started=peer.activate('business_ack_blocked',200,request_id=request_id)
        if fault=='cancel':
            final=peer.cancel(request_id)
        elif fault=='boot_change':
            final=peer.command({'operation':'fixture_boot_change','new_boot_id':'PUBLIC-next-boot'})
        else:
            time.sleep(0.3)
            final=peer.observe()
        result={'schema':'plcnext-fault-supervision-test/v1','status':'loopback_supervision_passed' if final['release_verified'] else 'release_failed',
            'fault':fault,'project_id':project_id,'project_sha256':expected_project_sha256,'package_job_id':package_job_id,
            'evidence_environment':'owned_loopback_fixture','started':started,'final':final,
            'independent_supervisor_process':True,'real_backend_tested':False,'real_controller_connected':False,
            'shared_hub_broker_or_mock_changed':False,'operator_approval_issued':False,
            'client_exit_injection_executed':child_exited,'collection_or_performance_verified':False}
    path=directory/'result.json';result['report_path']=str(path)
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return result
