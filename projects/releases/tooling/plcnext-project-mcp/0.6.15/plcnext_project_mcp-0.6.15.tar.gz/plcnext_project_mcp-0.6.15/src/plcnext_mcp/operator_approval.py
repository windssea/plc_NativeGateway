"""Exact approval lifecycle with MCP-managed and optional interactive issuers.

This module does no network I/O. The console operator reviews an exact immutable
contract, types its complete digest, supplies an audit reference and acknowledges
the stated effects. There is deliberately no ``--yes``, piped approval or automatic
issuer in the optional terminal flow. MCP-managed issuance uses a distinct schema
and truthful issuer identity. This is a trusted local-host convention, not cryptographic proof that a
human is present: another process with the same filesystem privileges can forge
the existing v1 receipt. Production hosts must protect their issuer and approval
directories from the development agent's write identity when stronger separation
is required.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import re
import sys
from typing import Callable, TextIO
import uuid

from .controller_download_plan import POLICY, revalidate_download_review, _strict_json
from .deployment_plan import _file
from .project import ProjectError, ProjectStore, sha

CONTRACT_SCHEMA = 'plcnext-operator-approval-contract/v1'
DOWNLOAD_RECEIPT_SCHEMA = 'plcnext-controller-download-operator-approval/v1'
DOWNLOAD_ACTIONS = ['write_package_paths', 'sha512_readback', 'reset', 'load']
MAX_RECEIPT_BYTES = 64 * 1024
MAX_REFERENCE_CHARS = 512


class OperatorApprovalError(ProjectError):
    """A bounded issuer error with a machine-readable lifecycle reason."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def _digest(value: str) -> str:
    if type(value) is not str or re.fullmatch('[0-9a-f]{64}', value) is None:
        raise OperatorApprovalError('invalid_review_hash', 'Expected an exact lowercase 64-hex review SHA-256.')
    return value


def _reference(value: str) -> str:
    if (type(value) is not str or not value.strip() or len(value) > MAX_REFERENCE_CHARS
            or any(ord(char) < 32 or ord(char) == 127 for char in value)):
        raise OperatorApprovalError('invalid_confirmation_reference',
            'A nonempty audit reference of at most 512 printable characters is required; do not enter secrets.')
    return value.strip()


@dataclass(frozen=True)
class OperatorApprovalContract:
    """Versioned issuer adapter produced by a trusted, revalidating review loader.

    ``binding_fields`` must contain all operation-specific exact receipt fields,
    including target, source/package identities, policy and approved_actions.
    It cannot replace issuer-controlled schema, review hash or human label.
    ``display`` is the complete bounded review context shown to the operator.
    Neither this object nor its public digest grants device permissions.
    """

    kind: str
    review_sha256: str
    receipt_schema: str
    approval_directory: str
    binding_fields: dict
    display: dict

    def checked(self) -> 'OperatorApprovalContract':
        _digest(self.review_sha256)
        if (type(self.kind) is not str or re.fullmatch('[a-z][a-z0-9_-]{0,63}', self.kind) is None
                or type(self.receipt_schema) is not str or not self.receipt_schema.endswith('/v1')
                or not self.receipt_schema.startswith('plcnext-')
                or type(self.approval_directory) is not str
                or re.fullmatch('controller-[a-z0-9-]+-approvals', self.approval_directory) is None
                or type(self.binding_fields) is not dict or type(self.display) is not dict):
            raise OperatorApprovalError('invalid_approval_contract', 'Invalid bounded operator approval contract.')
        forbidden = {'schema', 'review_sha256', 'confirmed_by', 'confirmed_utc', 'expires_utc',
                     'confirmation_reference', 'issuer'}
        if set(self.binding_fields) & forbidden:
            raise OperatorApprovalError('invalid_approval_contract', 'Contract overrides an issuer-controlled receipt field.')
        fields = self.binding_fields
        if (not {'target', 'project_sha256', 'inventory_sha256', 'policy', 'approved_actions'} <= set(fields)
                or type(fields['target']) is not dict or type(fields['policy']) is not dict
                or type(fields['approved_actions']) is not list or not fields['approved_actions']
                or len(fields['approved_actions']) > 32
                or any(type(action) is not str or not action or len(action) > 128 for action in fields['approved_actions'])):
            raise OperatorApprovalError('invalid_approval_contract', 'Contract lacks exact target, source, package, policy or actions.')
        if len(set(fields['approved_actions'])) != len(fields['approved_actions']):
            raise OperatorApprovalError('invalid_approval_contract', 'Contract repeats an approved action.')
        _digest(fields['project_sha256'])
        _digest(fields['inventory_sha256'])
        if len(_canonical(asdict(self))) > 4 * 1024 * 1024:
            raise OperatorApprovalError('invalid_approval_contract', 'Operator display contract exceeds 4 MiB.')
        return self

    def fingerprint(self) -> str:
        self.checked()
        return sha(_canonical({'schema': CONTRACT_SCHEMA, **asdict(self)}))


def download_approval_contract(store, project_id: str, review_id: str,
                               expected_review_sha256: str) -> OperatorApprovalContract:
    """Revalidate exact source/package locally, preserving download v1 actions."""
    review = revalidate_download_review(store, project_id, review_id, expected_review_sha256)
    return OperatorApprovalContract(
        kind='download', review_sha256=review['review_sha256'],
        receipt_schema=DOWNLOAD_RECEIPT_SCHEMA,
        approval_directory='controller-download-approvals',
        binding_fields={
            'target': review['target'], 'project_sha256': review['source']['project_sha256'],
            'inventory_sha256': review['package']['inventory_sha256'], 'policy': dict(POLICY),
            'approved_actions': list(DOWNLOAD_ACTIONS),
            'preserved_unlisted_remote_files_acknowledged': True,
        },
        display={key: review[key] for key in (
            'schema', 'project_id', 'review_id', 'review_sha256', 'created_utc', 'target',
            'source', 'package', 'files', 'policy', 'planned_actions', 'impact',
            'confirmation_scope', 'execution_blockers', 'unverified_postconditions', 'limitations')},
    ).checked()


def load_approval_contract(store, kind: str, project_id: str, review_id: str,
                           expected_review_sha256: str) -> OperatorApprovalContract:
    """Only explicit, installed operation adapters can select an approval schema."""
    if kind == 'reboot':
        from .controller_reboot import approval_contract
        return approval_contract(store,project_id,review_id,expected_review_sha256)
    if kind == 'audit_export':
        from .audit_export import approval_contract
        return approval_contract(store,project_id,review_id,expected_review_sha256)
    if kind == 'lease_reconciliation':
        from .lease_reconciliation import approval_contract
        return approval_contract(store, project_id, review_id, expected_review_sha256)
    if kind == 'download':
        return download_approval_contract(store, project_id, review_id, expected_review_sha256)
    if kind == 'control':
        # Imported only after its independently implemented adapter is available.
        try:
            from .controller_control import approval_contract
        except ImportError as exc:
            raise OperatorApprovalError('approval_kind_unavailable', 'Control approval adapter is not installed.') from exc
        contract = approval_contract(store, project_id, review_id, expected_review_sha256)
        if not isinstance(contract, OperatorApprovalContract) or contract.kind != kind:
            raise OperatorApprovalError('invalid_approval_contract', 'Control adapter returned the wrong contract kind.')
        return contract.checked()
    if kind == 'recovery':
        from .controller_recovery import approval_contract
        contract = approval_contract(store, project_id, review_id, expected_review_sha256)
        if not isinstance(contract, OperatorApprovalContract) or contract.kind != kind:
            raise OperatorApprovalError('invalid_approval_contract', 'Recovery adapter returned the wrong contract kind.')
        return contract.checked()
    if kind == 'instrumented_fault':
        from .instrumented_fault import approval_contract
        contract = approval_contract(store, project_id, review_id, expected_review_sha256)
        if not isinstance(contract, OperatorApprovalContract) or contract.kind != kind:
            raise OperatorApprovalError('invalid_approval_contract', 'Fault adapter returned the wrong contract kind.')
        return contract.checked()
    raise OperatorApprovalError('approval_kind_unavailable', 'Unsupported operator approval kind.')


def _paths(root: Path, contract: OperatorApprovalContract) -> dict[str, Path]:
    contract.checked()
    directory = _file(root, contract.approval_directory)
    digest = contract.review_sha256
    return {
        'directory': directory,
        'receipt': _file(directory, digest + '.json'),
        'claimed': _file(directory, digest + '.claimed.json'),
        'revoked': _file(directory, digest + '.revoked.json'),
        'denied': _file(directory, digest + '.denied.json'),
        'lock': _file(directory, digest + '.issuer-lock.json'),
        'audit': _file(directory, digest + '.issuer-audit.jsonl'),
    }


def _read_bounded(path: Path):
    if not path.is_file() or path.stat().st_size > MAX_RECEIPT_BYTES:
        raise OperatorApprovalError('invalid_receipt', 'Missing or oversized operator lifecycle record.')
    raw = path.read_bytes()
    if len(raw) > MAX_RECEIPT_BYTES:
        raise OperatorApprovalError('invalid_receipt', 'Oversized operator lifecycle record.')
    return _strict_json(raw), raw


def validate_operator_receipt(record: dict, contract: OperatorApprovalContract,
                               *, now: datetime | None = None) -> dict:
    """Pure validation shared by lifecycle inspection and future consumers.

    Consumption must still use O_EXCL claimed semantics before any connection.
    Validation itself neither issues approval nor marks a receipt consumed.
    """
    contract.checked()
    managed = type(record) is dict and record.get('confirmed_by') == 'mcp_policy'
    expected = {
        'schema': contract.receipt_schema, 'review_sha256': contract.review_sha256,
        'confirmed_by': 'human_user', **contract.binding_fields,
    }
    if managed:
        expected.update(schema=contract.receipt_schema.replace('-operator-approval/v1', '-mcp-approval/v1'),
            confirmed_by='mcp_policy', authorization_channel='mcp_managed',
            contract_sha256=contract.fingerprint())
    if type(record) is not dict or any(key not in record or _canonical(record[key]) != _canonical(value)
                                       for key, value in expected.items()):
        raise OperatorApprovalError('approval_binding_mismatch', 'Receipt does not match exact review, target, source, package, policy and actions.')
    _reference(record.get('confirmation_reference'))
    now = now or datetime.now(timezone.utc)
    try:
        confirmed = datetime.fromisoformat(record['confirmed_utc'])
        expires = datetime.fromisoformat(record['expires_utc'])
        if (confirmed.tzinfo is None or expires.tzinfo is None or now.tzinfo is None
                or not confirmed <= now < expires or (expires - confirmed).total_seconds() > 3600):
            raise ValueError('invalid approval interval')
    except (KeyError, ValueError, TypeError) as exc:
        raise OperatorApprovalError('approval_expired', 'Receipt is expired, future-dated or has an invalid validity window.') from exc
    return record


def issue_mcp_approval(root: Path, contract_loader: Callable[[], OperatorApprovalContract],
                       *, reason: str, lifetime_seconds: int = 900,
                       now: datetime | None = None) -> dict:
    """MCP decides authorization of an exact operation; no terminal/device I/O."""
    reason = _reference(reason)
    if type(lifetime_seconds) is not int or not 1 <= lifetime_seconds <= 3600:
        raise OperatorApprovalError('invalid_lifetime', 'Approval lifetime must be an integer 1..3600 seconds.')
    contract = contract_loader().checked()
    paths = _paths(root, contract)
    with _issuer_lock(paths):
        prior = inspect_operator_approval(root, contract, now=now)
        if not prior['may_issue']:
            raise OperatorApprovalError('approval_not_reissuable',
                'Approval/claim/denial exists; reconcile and prepare a new review rather than replacing evidence.')
        fingerprint = contract.fingerprint()
        created = now or datetime.now(timezone.utc)
        receipt = {'schema': contract.receipt_schema.replace('-operator-approval/v1', '-mcp-approval/v1'),
            'review_sha256': contract.review_sha256, 'confirmed_by': 'mcp_policy',
            **contract.binding_fields, 'authorization_channel': 'mcp_managed',
            'contract_sha256': fingerprint, 'confirmation_reference': reason,
            'confirmed_utc': created.isoformat(),
            'expires_utc': (created + timedelta(seconds=lifetime_seconds)).isoformat()}
        validate_operator_receipt(receipt, contract, now=created)
        if contract_loader().checked().fingerprint() != fingerprint:
            raise OperatorApprovalError('review_changed', 'Review/source/package changed before authorization.')
        _audit(paths['audit'], {'operation': 'mcp_authorization_intent', 'kind': contract.kind,
            'review_sha256': contract.review_sha256, 'contract_sha256': fingerprint})
        try:
            _new_file(paths['receipt'], receipt)
        except FileExistsError as exc:
            raise OperatorApprovalError('approval_not_reissuable', 'Another approval already exists.') from exc
        result = inspect_operator_approval(root, contract, now=created)
        result.update(authorization_channel='mcp_managed', confirmed_by='mcp_policy',
            contract_sha256=fingerprint, device_contacted=False, audit_path=str(paths['audit']))
        try:
            _audit(paths['audit'], {'operation': 'mcp_authorization_issued', 'kind': contract.kind,
                'review_sha256': contract.review_sha256, 'receipt_sha256': result['receipt_sha256']})
            result['audit_completion_persisted'] = True
        except OSError as exc:
            result.update(audit_completion_persisted=False, audit_error_class=type(exc).__name__)
        return result


def inspect_operator_approval(root: Path, contract: OperatorApprovalContract,
                              *, now: datetime | None = None) -> dict:
    paths = _paths(root, contract)
    result = {
        'schema': 'plcnext-operator-approval-inspection/v1', 'kind': contract.kind,
        'review_sha256': contract.review_sha256, 'status': 'unconfirmed',
        'receipt_path': str(paths['receipt']), 'claimed_path': str(paths['claimed']),
        'approval_issued': False, 'may_issue': True, 'device_contacted': False,
    }
    # Claimed records are permanent evidence. Revocation also reserves this exact
    # name first, so a concurrent consumer can never silently reuse the approval.
    if paths['claimed'].exists():
        claim, _ = _read_bounded(paths['claimed'])
        operation = claim.get('operation') if type(claim) is dict else None
        result.update(status={'operator_revocation': 'revoked', 'operator_denial': 'denied'}.get(operation, 'consumed'),
                      may_issue=False)
        return result
    for marker, status in (('revoked', 'revoked'), ('denied', 'denied')):
        if paths[marker].exists():
            result.update(status=status, may_issue=False)
            return result
    if not paths['receipt'].exists():
        return result
    result.update(approval_issued=True, may_issue=False)
    try:
        record, raw = _read_bounded(paths['receipt'])
        validate_operator_receipt(record, contract, now=now)
        result.update(status='ready', receipt_sha256=sha(raw), expires_utc=record['expires_utc'])
    except (OperatorApprovalError, ProjectError, OSError) as exc:
        result.update(status='expired' if getattr(exc, 'code', '') == 'approval_expired' else 'invalid',
                      failure_code=getattr(exc, 'code', 'invalid_receipt'))
    return result


def _new_file(path: Path, record: dict) -> None:
    """Publish fully fsynced bytes with O_EXCL semantics and no replace window."""
    raw = _canonical(record) + b'\n'
    if len(raw) > MAX_RECEIPT_BYTES:
        raise OperatorApprovalError('invalid_receipt', 'Operator receipt exceeds its 64 KiB consumer limit.')
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    descriptor = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    published = False
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        # Atomic publication, including on Windows/NTFS; never overwrite an
        # existing approval. No fallback to overwrite-prone rename is allowed.
        os.link(temporary, path)
        published = True
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            # A leftover owned temporary file does not undo atomic publication.
            # Never turn an issued/claimed record into an apparent refusal.
            if not published:
                raise


def _audit(path: Path, event: dict) -> None:
    raw = _canonical({'observed_utc': datetime.now(timezone.utc).isoformat(), **event}) + b'\n'
    if len(raw) > 8192:
        raise OperatorApprovalError('audit_too_large', 'Issuer audit event exceeds the bounded size.')
    descriptor = os.open(path, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
    with os.fdopen(descriptor, 'ab') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


@contextmanager
def _issuer_lock(paths):
    paths['directory'].mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(paths['lock'], os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise OperatorApprovalError('issuer_busy', 'Another issuer is handling this exact review; a crashed issuer lock requires inspection.') from exc
    with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
        json.dump({'schema': 'plcnext-operator-issuer-lock/v1', 'pid': os.getpid(),
                   'created_utc': datetime.now(timezone.utc).isoformat()}, stream)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        yield
    finally:
        paths['lock'].unlink(missing_ok=True)


class InteractiveConsole:
    """The only production confirmation channel; stdin/stdout must both be TTYs."""

    def __init__(self, stdin: TextIO | None = None, stdout: TextIO | None = None):
        self.stdin = sys.stdin if stdin is None else stdin
        self.stdout = sys.stdout if stdout is None else stdout

    def require_interactive(self):
        if not self.stdin.isatty() or not self.stdout.isatty():
            raise OperatorApprovalError('interactive_operator_required',
                'Issuance/revocation requires an operator terminal; piped input/output and automatic yes are refused.')

    def write(self, value: str):
        self.stdout.write(value + '\n')
        self.stdout.flush()

    def ask(self, question: str) -> str:
        self.stdout.write(question)
        self.stdout.flush()
        answer = self.stdin.readline(MAX_REFERENCE_CHARS + 128)
        if not answer or not answer.endswith('\n'):
            raise OperatorApprovalError('operator_cancelled', 'Operator input ended or exceeded its bounded line length.')
        return answer.rstrip('\r\n')


def _show_contract(console: InteractiveConsole, contract: OperatorApprovalContract):
    console.write('PLCnext independent operator approval / 独立操作者审批')
    console.write('No device connection is made here. Review the exact version, target, actions and effects below.')
    console.write('这里不连接设备。请核对版本、目标、动作及影响；不要输入密码或令牌。')
    console.write(json.dumps({'schema': CONTRACT_SCHEMA, 'kind': contract.kind,
        'review_sha256': contract.review_sha256, 'receipt_schema': contract.receipt_schema,
        'receipt_binding': contract.binding_fields, 'review': contract.display},
        ensure_ascii=False, indent=2, allow_nan=False))
    console.write('Local trust boundary: this console convention is not cryptographic proof of human identity; protect the issuer/receipt directory separately.')


def issue_interactive_approval(root: Path, contract_loader: Callable[[], OperatorApprovalContract],
                                *, console: InteractiveConsole | None = None,
                                lifetime_seconds: int = 900,
                                now: datetime | None = None) -> dict:
    """Issue one precise receipt after interactive confirmation and revalidation.

    Intended only for the independently launched operator CLI/host. Do not expose
    this function as a development-agent MCP tool or call it to synthesize consent.
    Test callers must use PUBLIC fixture contracts and never real target reviews.
    """
    console = console or InteractiveConsole()
    console.require_interactive()
    if type(lifetime_seconds) is not int or not 1 <= lifetime_seconds <= 3600:
        raise OperatorApprovalError('invalid_lifetime', 'Approval lifetime must be an integer 1..3600 seconds.')
    contract = contract_loader().checked()
    paths = _paths(root, contract)
    with _issuer_lock(paths):
        previous = inspect_operator_approval(root, contract, now=now)
        if not previous['may_issue']:
            raise OperatorApprovalError('approval_not_reissuable',
                'This review already has an approval/claim/denial. Do not erase records or blindly reissue; resolve the old operation and prepare a new review.')
        fingerprint = contract.fingerprint()
        _show_contract(console, contract)
        expected = 'APPROVE ' + contract.review_sha256
        typed = console.ask('Type APPROVE followed by the complete review SHA-256, or anything else to cancel: ')
        if typed != expected:
            _audit(paths['audit'], {'operation': 'issuance_cancelled', 'kind': contract.kind,
                                   'review_sha256': contract.review_sha256})
            raise OperatorApprovalError('operator_cancelled', 'Exact operator confirmation was not provided; nothing was approved.')
        reference = _reference(console.ask('Human confirmation reference (no passwords/tokens, 1..512 characters): '))
        if console.ask('Type I ACCEPT THE DISPLAYED ACTIONS AND EFFECTS to acknowledge: ') != 'I ACCEPT THE DISPLAYED ACTIONS AND EFFECTS':
            raise OperatorApprovalError('operator_cancelled', 'Effects were not acknowledged; nothing was approved.')
        current = contract_loader().checked()
        if current.fingerprint() != fingerprint:
            raise OperatorApprovalError('review_changed', 'Review/source/package changed during confirmation; nothing was approved.')
        # Keep the audit durable before publishing a consumable receipt. A failed
        # audit must never leave an approval whose existence was not recorded.
        _audit(paths['audit'], {'operation': 'issuance_intent', 'kind': contract.kind,
            'review_sha256': contract.review_sha256, 'contract_sha256': fingerprint})
        if paths['claimed'].exists() or paths['revoked'].exists() or paths['denied'].exists():
            raise OperatorApprovalError('approval_not_reissuable', 'The exact review was consumed or withdrawn during confirmation.')
        created = now or datetime.now(timezone.utc)
        if created.tzinfo is None:
            raise OperatorApprovalError('invalid_lifetime', 'Issuer clock must have a timezone.')
        receipt = {'schema': contract.receipt_schema, 'review_sha256': contract.review_sha256,
            'confirmed_by': 'human_user', **contract.binding_fields,
            'confirmation_reference': reference, 'confirmed_utc': created.isoformat(),
            'expires_utc': (created + timedelta(seconds=lifetime_seconds)).isoformat()}
        validate_operator_receipt(receipt, contract, now=created)
        try:
            _new_file(paths['receipt'], receipt)
        except FileExistsError as exc:
            raise OperatorApprovalError('approval_not_reissuable', 'Another approval already exists; it was not replaced.') from exc
        try:
            result = inspect_operator_approval(root, contract, now=created)
        except (OperatorApprovalError, ProjectError, OSError) as exc:
            result = {'status': 'issued_status_unknown',
                      'lifecycle_inspection_error_class': type(exc).__name__}
        result.update(approval_issued=True, review_sha256=contract.review_sha256,
            receipt_path=str(paths['receipt']), claimed_path=str(paths['claimed']),
            receipt_sha256=sha(_canonical(receipt) + b'\n'),
            contract_sha256=fingerprint, audit_path=str(paths['audit']),
            operator_confirmation_channel='interactive_terminal', device_contacted=False)
        try:
            _audit(paths['audit'], {'operation': 'approval_issued', 'kind': contract.kind,
                'review_sha256': contract.review_sha256, 'receipt_sha256': result.get('receipt_sha256')})
        except OSError as exc:
            # Receipt publication is a side effect. Never report that issuance
            # did not happen solely because terminal audit logging failed.
            result.update(audit_completion_persisted=False, audit_error_class=type(exc).__name__)
        else:
            result['audit_completion_persisted'] = True
        return result


def withdraw_interactive_approval(root: Path, contract_loader: Callable[[], OperatorApprovalContract],
                                   *, console: InteractiveConsole | None = None) -> dict:
    """Deny an unissued review or revoke an unconsumed receipt without reuse.

    Reserves the SAME claimed filename used by consumers before withdrawing the
    receipt. A competing consumer that already owns it wins; we then report
    consumed and do not claim that an in-flight operation was cancelled.
    """
    console = console or InteractiveConsole()
    console.require_interactive()
    contract = contract_loader().checked()
    paths = _paths(root, contract)
    with _issuer_lock(paths):
        before = inspect_operator_approval(root, contract)
        if paths['claimed'].exists():
            raise OperatorApprovalError('approval_already_consumed',
                'This approval is already claimed/withdrawn. Revocation cannot cancel an in-flight device action.')
        _show_contract(console, contract)
        if console.ask('Type WITHDRAW followed by the complete review SHA-256: ') != 'WITHDRAW ' + contract.review_sha256:
            raise OperatorApprovalError('operator_cancelled', 'Exact withdrawal confirmation was not provided.')
        reference = _reference(console.ask('Human withdrawal reference (no secrets): '))
        if contract_loader().checked().fingerprint() != contract.fingerprint():
            raise OperatorApprovalError('review_changed', 'Review changed during withdrawal; no withdrawal was published.')
        operation = 'operator_revocation' if paths['receipt'].exists() else 'operator_denial'
        event = {'schema': 'plcnext-operator-approval-withdrawal/v1', 'operation': operation,
            'review_sha256': contract.review_sha256, 'kind': contract.kind,
            'observed_utc': datetime.now(timezone.utc).isoformat(), 'confirmation_reference': reference,
            'previous_status': before['status'], 'does_not_cancel_inflight_actions': True}
        _audit(paths['audit'], {'operation': operation + '_intent', 'kind': contract.kind,
                               'review_sha256': contract.review_sha256})
        try:
            _new_file(paths['claimed'], event)
        except FileExistsError as exc:
            raise OperatorApprovalError('approval_already_consumed', 'A consumer claimed this approval during withdrawal; its action may already be in flight.') from exc
        marker = paths['revoked'] if operation == 'operator_revocation' else paths['denied']
        # Keep both claim and withdrawal evidence permanent. Receipt bytes are
        # intentionally retained; the persistent claim prevents their reuse.
        result = {'schema': 'plcnext-operator-approval-withdrawal-result/v1',
            'status': 'revoked' if operation == 'operator_revocation' else 'denied',
            'review_sha256': contract.review_sha256, 'claimed_path': str(paths['claimed']),
            'receipt_retained_for_audit': paths['receipt'].exists(), 'device_contacted': False,
            'audit_path': str(paths['audit'])}
        try:
            _new_file(marker, event)
            _audit(paths['audit'], {'operation': operation, 'kind': contract.kind,
                                   'review_sha256': contract.review_sha256})
        except OSError as exc:
            result.update(withdrawal_claim_persisted=True, audit_completion_persisted=False,
                          audit_error_class=type(exc).__name__)
        else:
            result.update(withdrawal_claim_persisted=True, audit_completion_persisted=True)
        return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Independent operator terminal: inspect, issue or withdraw exact PLCnext approval. Never connects to PLC.')
    parser.add_argument('command', choices=['inspect', 'issue', 'withdraw'])
    parser.add_argument('--workspace', default=os.environ.get('PLCNEXT_MCP_WORKSPACE', str(Path.home() / 'PLCnext-MCP-Workspace')))
    parser.add_argument('--kind', choices=['download', 'control', 'recovery', 'instrumented_fault', 'reboot'], default='download')
    parser.add_argument('--project-id', required=True)
    parser.add_argument('--review-id', required=True)
    parser.add_argument('--review-sha256', required=True)
    parser.add_argument('--lifetime-seconds', type=int, default=900)
    args = parser.parse_args(argv)
    store = ProjectStore(Path(args.workspace))
    loader = lambda: load_approval_contract(store, args.kind, args.project_id, args.review_id, args.review_sha256)
    try:
        if args.command == 'inspect':
            contract = loader()
            result = inspect_operator_approval(store.root, contract)
            result['review'] = contract.display
        elif args.command == 'issue':
            result = issue_interactive_approval(store.root, loader, lifetime_seconds=args.lifetime_seconds)
        else:
            result = withdraw_interactive_approval(store.root, loader)
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except (OperatorApprovalError, ProjectError, OSError) as exc:
        print(json.dumps({'status': 'operator_approval_refused',
            'failure_code': getattr(exc, 'code', 'review_or_filesystem_error'),
            'error': str(exc), 'device_contacted': False}, ensure_ascii=False), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print(json.dumps({'status': 'operator_cancelled', 'device_contacted': False}), file=sys.stderr)
        return 130


if __name__ == '__main__':
    # -m executes this file as __main__. Operation adapters import its canonical
    # package name; dispatch there so their dataclass and isinstance checks share
    # the same class identity. No approval is issued by importing either module.
    from plcnext_mcp.operator_approval import main as canonical_main
    raise SystemExit(canonical_main())
