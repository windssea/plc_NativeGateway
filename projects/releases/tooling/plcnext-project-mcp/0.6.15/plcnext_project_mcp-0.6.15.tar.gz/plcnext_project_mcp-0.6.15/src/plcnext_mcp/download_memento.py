"""Explicit native full-load policy for Engineer's optional dlc.bin history.

The empty file is the original empty DownloadCapabilityStateMemento.Save output.
It carries no claimed prior download state. This is not a populated online-change
history, and original in-memory Save/Load acceptance is not PLC acceptance.
"""
from __future__ import annotations

from .project import ProjectError, sha

POLICIES = ('omit', 'empty_capability_v1')
ORACLE = {
    'assembly': 'Ade.PlcImpl.dll',
    'assembly_sha256': 'ee537d92540ff4f6270f0b2a34121d971abab993fc481319a90bd1bb80508298',
    'mvid': '1669d53f-7ef8-4452-812c-defedab484c3',
    'type': 'Ade.Internal.Plc.DownloadCapabilityStateMemento',
    'save_token': '0x0600015b', 'load_token': '0x0600015a',
}


def download_memento_payloads(policy: str) -> tuple[dict[str, bytes], dict]:
    if type(policy) is not str or policy not in POLICIES:
        raise ProjectError('Unknown download memento policy; use omit or empty_capability_v1.')
    present = policy == 'empty_capability_v1'
    return ({'dlc.bin': b''} if present else {}), {
        'schema': 'plcnext-download-capability-memento/v1', 'policy': policy,
        'present': present, 'owner': 'Engineer download-capability history',
        'producer': 'independent_empty_original_format' if present else 'none',
        'bytes': 0 if present else None, 'sha256': sha(b'') if present else None,
        'history_entries': 0 if present else None,
        'populated_online_change_history': False, 'controller_acceptance_verified': False,
        'oracle': dict(ORACLE),
        'impact': ('Replaces previous download-capability history with a valid empty history; '
                   'no previous-program or online-change compatibility is asserted.' if present
                   else 'No memento is generated; a remote extra path remains a strict download blocker.'),
    }
