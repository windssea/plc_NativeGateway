"""Release isolation, stale-byte guards and crash evidence, with zero PLC I/O."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from plcnext_mcp import releases as r
from plcnext_mcp.project import ProjectStore, ProjectError, read_archive, sha

ENGINEER = Path(__file__).resolve().parents[2] / 'PLCnext-Engineer'
SOURCES = {
    'AXCF2152': ENGINEER / 'projects/candidates/native-0.8.1/NativeGateway.pcwex',
    'AXCF1252': ENGINEER / 'projects/variants/native-0.8.1-axcf1252/NativeGateway1252Candidate.pcwex',
}


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore(self.root / 'workspace')
        env = patch.dict(os.environ, {'PLCNEXT_MCP_RELEASE_ROOT': str(self.root / 'releases')})
        env.start(); self.addCleanup(env.stop)

    def prepare(self, target='AXCF2152'):
        original = self.store.import_copy(str(SOURCES[target]))
        result = r.prepare_dev(self.store, original['project_id'], original['project_sha256'], '0.8.2', 'Scale changes')
        return original, result

    def plan(self, result):
        release = result['release']; managed = result['managed_project']
        folder = Path(release['release_directory']); payload = b'inert synthetic payload'
        (folder / 'PCWE').mkdir(); (folder / 'PCWE/image').write_bytes(payload)
        receipt = b'{"inert_fixture":true}'
        for name in ('build-receipt.json', 'package-receipt.json'):
            (folder / name).write_bytes(receipt)
        package = {'inventory_sha256': 'a' * 64, 'build_receipt_sha256': sha(receipt),
                   'package_receipt_sha256': sha(receipt)}
        files = [{'path': 'image', 'bytes': len(payload), 'sha256': sha(payload)}]
        r.write_new(folder / 'package.json', {'project_sha256': managed['project_sha256'], 'package': package, 'files': files})
        return {'project_id': managed['project_id'], 'source': {'project_sha256': managed['project_sha256']},
                'target': {'address': release['address'], 'port': 41100, 'expected_certificate_sha256': 'b' * 64},
                'package': package, 'files': files}

    def test_targets_separated_and_originals_unchanged(self):
        for target in SOURCES:
            before = SOURCES[target].read_bytes()
            original, result = self.prepare(target)
            release = result['release']
            self.assertEqual(release['target'], target)
            self.assertIn('-dev.', release['version'])
            self.assertIn(target, release['release_directory'])
            self.assertNotEqual(original['project_sha256'], release['project_sha256'])
            self.assertEqual(before, SOURCES[target].read_bytes())
            _, old, _, _ = read_archive(SOURCES[target])
            _, new, _, _ = read_archive(Path(release['release_directory']) / 'project.pcwex')
            self.assertEqual({k: v for k, v in old.items() if k != r.MAIN},
                             {k: v for k, v in new.items() if k != r.MAIN})
        self.assertEqual(len(r.inventory(self.store)['releases']), 2)

    def test_idempotent_dev_input_and_reject_stale_hash(self):
        original, one = self.prepare()
        two = r.prepare_dev(self.store, original['project_id'], original['project_sha256'], '0.8.2', 'same input')
        self.assertEqual(one['release']['project_sha256'], two['release']['project_sha256'])
        rebuild = r.prepare_dev(self.store, original['project_id'], original['project_sha256'], '0.8.2', 'new toolchain', 1)
        self.assertNotEqual(one['release']['version'], rebuild['release']['version'])
        with self.assertRaises(ProjectError):
            r.prepare_dev(self.store, original['project_id'], 'f' * 64, '0.8.2', 'stale')

    def test_same_version_different_bytes_rejected(self):
        source = SOURCES['AXCF2152']
        r.archive_historical(self.store, str(source), sha(source.read_bytes()), 'Existing verified archive, not a new deployment')
        raw, members, infos, comment = read_archive(source)
        members[r.MAIN] += b'\n// modified source\n'
        changed = self.root / 'changed.pcwex'
        with zipfile.ZipFile(changed, 'w') as archive:
            for info in infos: archive.writestr(info, members[info.filename])
        with self.assertRaises(ProjectError):
            r.archive_historical(self.store, str(changed), sha(changed.read_bytes()), 'reused version')

    def test_changed_input_gets_another_dev_version(self):
        original, one = self.prepare()
        pou = self.store.read_pou(original['project_id'], 'NG_Modbus')
        self.store.patch_st(original['project_id'], 'NG_Modbus', original['project_sha256'], pou['code_sha256'],
                            pou['code'], pou['code'] + '\n// changed\n')
        updated = self.store.inspect(original['project_id'])
        two = r.prepare_dev(self.store, updated['project_id'], updated['project_sha256'], '0.8.2', 'changed source')
        self.assertNotEqual(one['release']['version'], two['release']['version'])

    def test_missing_release_fails_before_operation(self):
        original = self.store.import_copy(str(SOURCES['AXCF2152']))
        plan = {'project_id': original['project_id'], 'source': {'project_sha256': original['project_sha256']},
                'target': {'address': '192.168.0.8'}}
        calls = []
        @r.release_operation(lambda *args: plan)
        def operation(*args): calls.append(1)
        with self.assertRaises((ProjectError, OSError)):
            operation(self.store, original['project_id'], 'selector', 'hash')
        self.assertEqual(calls, [])

    def test_wrong_device_or_package_tamper_fails_before_call(self):
        _, result = self.prepare(); plan = self.plan(result)
        for field, value in [('target', {'address': '192.168.0.10'}), ('package', {'inventory_sha256': 'c' * 64})]:
            changed = {**plan, field: value}
            with self.assertRaises(ProjectError): r.require_release(self.store, changed)
        (Path(result['release']['release_directory']) / 'PCWE/image').write_bytes(b'corrupt')
        with self.assertRaises(ProjectError): r.require_release(self.store, plan)

    def test_every_attempt_has_durable_intent_and_exception_evidence(self):
        _, result = self.prepare(); plan = self.plan(result)
        @r.release_operation(lambda *args: plan)
        def operation(*args):
            attempts = r.inventory(self.store)['releases'][0]['deployment_attempts']
            self.assertEqual(attempts[-1]['status'], 'pending_outcome_unknown')
            raise RuntimeError('sensitive detail must not be persisted')
        with self.assertRaises(RuntimeError): operation(self.store, plan['project_id'], 'review', 'digest')
        item = r.inventory(self.store)['releases'][0]['deployment_attempts'][0]
        self.assertEqual(item['terminal']['status'], 'interrupted_outcome_unknown')
        self.assertNotIn('sensitive', json.dumps(item))

    def test_success_does_not_claim_running_device_version(self):
        _, result = self.prepare(); plan = self.plan(result)
        @r.release_operation(lambda *args: plan)
        def operation(*args): return {'status': 'transferred', 'controller_downloaded': True}
        out = operation(self.store, plan['project_id'], 'review', 'digest')
        self.assertEqual(out['release_version'], result['release']['version'])
        terminal = r.inventory(self.store)['releases'][0]['deployment_attempts'][0]['terminal']
        self.assertFalse(terminal['current_device_version_verified'])

    def test_loopback_fixture_is_not_a_real_deployment(self):
        @r.release_operation(lambda *args: {'target': {'address': '127.0.0.1'}})
        def operation(*args): return {'test': True}
        self.assertEqual(operation(self.store, 'fixture', 'review', 'hash'), {'test': True})
        self.assertEqual(r.inventory(self.store)['releases'], [])

    def test_registration_failure_leaves_no_device_action(self):
        _, result = self.prepare(); plan = self.plan(result)
        calls = []
        @r.release_operation(lambda *args: plan)
        def operation(*args): calls.append(1)
        with patch.object(r, 'write_new', side_effect=OSError('disk unavailable')):
            with self.assertRaises(OSError): operation(self.store, plan['project_id'], 'review', 'digest')
        self.assertEqual(calls, [])

    def test_invalid_version_and_empty_notes(self):
        original = self.store.import_copy(str(SOURCES['AXCF2152']))
        for version, note in [('..', 'bad'), ('0.8.2', '')]:
            with self.assertRaises(ProjectError):
                r.prepare_dev(self.store, original['project_id'], original['project_sha256'], version, note)

    def test_binary_registration_freezes_exactly_one_package(self):
        _, result = self.prepare(); managed = result['managed_project']
        payload = b'inert file'; receipt = b'{"fixture":true}'
        package = {'inventory_sha256': 'a' * 64, 'build_job_id': 'build',
                   'build_receipt_sha256': sha(receipt), 'package_receipt_sha256': sha(receipt)}
        managed_folder = self.store._folder(managed['project_id'])
        for relative in ('builds/build/result.json', 'deployments/job/result.json'):
            path = managed_folder / relative; path.parent.mkdir(parents=True); path.write_bytes(receipt)
        binding = {'package': package, 'files': [{'path': 'image', 'bytes': len(payload), 'sha256': sha(payload)}]}
        with patch('plcnext_mcp.controller_download_plan._binding', return_value=(managed_folder, None, binding, {'image': payload})):
            first = r.bind_package(self.store, managed['project_id'], managed['project_sha256'], 'job')
            self.assertTrue(first['package_registered'])
            r.bind_package(self.store, managed['project_id'], managed['project_sha256'], 'job')
            binding['package'] = {**package, 'inventory_sha256': 'b' * 64}
            with self.assertRaises(ProjectError):
                r.bind_package(self.store, managed['project_id'], managed['project_sha256'], 'job')

    def test_unknown_formal_source_cannot_masquerade_as_historical(self):
        _, result = self.prepare()
        path = Path(result['release']['release_directory']) / 'project.pcwex'
        with self.assertRaises(ProjectError):
            r.archive_historical(self.store, str(path), sha(path.read_bytes()), 'not a frozen historical baseline')


if __name__ == '__main__': unittest.main()
