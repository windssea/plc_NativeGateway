"""Frozen HMI pages must remain bound to sources, type layouts and page references."""
from copy import deepcopy
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import zipfile

from plcnext_mcp.hmi_output import PAGE_FILES, validate_page_bindings, validate_page_receipt
from plcnext_mcp.project import ProjectError, sha
from plcnext_mcp.runtime_configuration import generate_runtime_configuration

ROOT = Path(__file__).resolve().parents[1]
PAGES = ROOT / 'artifacts/pcwe-aux-research/probe-36'
BUILD = ROOT / 'artifacts/pcwe-build-research/fresh-61-build.json'
TYPES = ROOT / 'artifacts/pcwe-build-research/fresh-61-runtime/TypeInformation.json'
AVAILABLE = BUILD.is_file() and TYPES.is_file() and (PAGES / 'result.json').is_file()


@unittest.skipUnless(AVAILABLE, 'Frozen HMI page/build/type evidence is not installed')
class HmiOutputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = json.loads(BUILD.read_text(encoding='utf-8-sig'))
        cls.job = Path(cls.build['job_directory'])
        if not cls.job.is_dir() or not Path(cls.build['project_path']).is_file():
            raise unittest.SkipTest('Source-bound managed build directory is not installed')
        cls.frozen_report = json.loads((PAGES / 'result.json').read_text(encoding='utf-8-sig'))
        cls.type_hash = sha(TYPES.read_bytes())
        # The immutable receipt names the exact historical host source; changing
        # today's host does not invalidate this unit fixture's producer identity.
        cls.host_hash = cls.frozen_report['host_source_sha256']
        cls.type_data = json.loads(TYPES.read_text(encoding='utf-8-sig'))
        with zipfile.ZipFile(cls.build['project_path']) as archive:
            cls.members = {name: archive.read(name) for name in archive.namelist()}
        _, cls.runtime_data = generate_runtime_configuration(cls.members)
        cls.page_bytes = {name: (PAGES / name).read_bytes() for name in PAGE_FILES}

    def setUp(self):
        self.report = deepcopy(self.frozen_report)
        self.types = deepcopy(self.type_data)
        self.runtime = deepcopy(self.runtime_data)
        self.files = dict(self.page_bytes)
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.output = Path(self.temp.name)
        for name in PAGE_FILES:
            shutil.copyfile(PAGES / name, self.output / name)

    def receipt(self):
        return validate_page_receipt(self.output, self.report, self.job, self.build, self.type_hash, self.host_hash)

    def bindings(self):
        return validate_page_bindings(self.report, self.runtime, self.types, self.files)

    def change_json(self, name, change):
        data = json.loads(self.files[name])
        change(data)
        self.files[name] = json.dumps(data, ensure_ascii=False).encode('utf-8')

    def test_real_current_61_pou_hmi_pages_and_81_bindings(self):
        files = self.receipt()
        self.assertEqual(files, self.page_bytes)
        self.bindings()
        self.assertEqual(self.report['runtime_binding_count'], 81)
        self.assertEqual(len(self.report['controller_tags']), 10)
        self.assertEqual(len(json.loads(files['gateway.json'])['Objects']), 494)
        self.assertEqual(len(json.loads(files['login.json'])['Objects']), 10)

    def test_stale_type_and_host_receipts_are_rejected(self):
        for key in ('runtime_types_sha256', 'host_source_sha256', 'analyzed_ast_sha256'):
            with self.subTest(key=key):
                self.report = deepcopy(self.frozen_report)
                self.report[key] = '0' * 64
                with self.assertRaises(ProjectError):
                    self.receipt()

    def test_missing_source_receipt_is_rejected(self):
        self.report['source_files'].pop()
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_duplicate_source_receipt_is_rejected(self):
        self.report['source_files'].append(dict(self.report['source_files'][0]))
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_source_digest_not_bound_to_build_is_rejected(self):
        self.report['source_files'][0]['sha256'] = '0' * 64
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_source_path_escape_is_rejected(self):
        self.report['source_files'][0]['path'] = '../outside.xml'
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_output_path_escape_is_rejected(self):
        self.report['page_files'][0]['path'] = '../gateway.json'
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_missing_output_and_duplicate_inventory_are_rejected(self):
        (self.output / 'gatewayModule.js').unlink()
        with self.assertRaises(ProjectError):
            self.receipt()
        shutil.copyfile(PAGES / 'gatewayModule.js', self.output / 'gatewayModule.js')
        self.report['page_files'][-1] = dict(self.report['page_files'][0])
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_output_payload_and_size_tampering_are_rejected(self):
        path = self.output / 'gatewayModule.js'
        path.write_bytes(path.read_bytes() + b'\n// changed copy\n')
        with self.assertRaises(ProjectError):
            self.receipt()
        shutil.copyfile(PAGES / 'gatewayModule.js', path)
        self.report['page_files'][0]['size'] += 1
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_error_diagnostic_and_incomplete_generation_are_rejected(self):
        self.report['messages'].append('MessageType=Error; synthetic offline diagnostic')
        with self.assertRaises(ProjectError):
            self.receipt()
        self.report = deepcopy(self.frozen_report)
        self.report['gateway_complete'] = False
        with self.assertRaises(ProjectError):
            self.receipt()

    def test_controller_tag_runtime_path_mismatch_is_rejected(self):
        self.report['controller_tags'][0]['runtime_path'] = 'Wrong.Component/HMI'
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_page_variable_prefix_mismatch_is_rejected(self):
        self.change_json('gateway.variables.json', lambda data: data.update(variablePathPrefix='Wrong.Component/'))
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_variable_type_mismatch_is_rejected(self):
        self.change_json('gateway.variables.json', lambda data: data['variables'][0].update(type='BOOL'))
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_unknown_variable_root_is_rejected(self):
        self.change_json('gateway.variables.json', lambda data: data['variables'][0].update(name='MissingVariable'))
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_variable_omission_and_matching_receipt_omission_are_rejected(self):
        self.change_json('gateway.variables.json', lambda data: data.update(variables=[]))
        self.report['runtime_bindings'] = []
        self.report['runtime_binding_count'] = 0
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_duplicate_binding_and_matching_receipt_are_rejected(self):
        self.change_json('gateway.variables.json', lambda data: data['variables'].append(dict(data['variables'][0])))
        self.report['runtime_bindings'].append(dict(self.report['runtime_bindings'][0]))
        self.report['runtime_binding_count'] += 1
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_binding_offset_mismatch_is_rejected(self):
        self.report['runtime_bindings'][0]['offset'] += 1
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_layout_field_offset_mismatch_is_rejected(self):
        root = next(t for t in self.types['Types'] if t['Name'] == 'NG_Hmi')
        field = next(f for f in root['Fields'] if f['Name'] == 'English')
        field['FieldOffset'] += 1
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_page_object_count_mismatch_is_rejected(self):
        self.change_json('gateway.json', lambda data: data['Objects'].pop())
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_login_variable_prefix_mismatch_is_rejected(self):
        self.change_json('login.variables.json', lambda data: data.update(variablePathPrefix='wrong'))
        with self.assertRaises(ProjectError):
            self.bindings()

    def test_login_mapping_omission_is_rejected(self):
        self.change_json('login.variables.json', lambda data: data['variables'].pop())
        with self.assertRaises(ProjectError):
            self.bindings()


if __name__ == '__main__':
    unittest.main()
