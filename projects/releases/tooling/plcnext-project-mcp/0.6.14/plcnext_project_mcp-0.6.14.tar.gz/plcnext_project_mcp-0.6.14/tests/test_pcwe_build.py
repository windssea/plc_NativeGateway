"""Package assembly rejects changed receipts/layouts before invoking downstream work."""
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from plcnext_mcp.pcwe_build import build_pcwe
from plcnext_mcp.project import ProjectError, ProjectStore, sha

ROOT = Path(__file__).resolve().parents[1]


class PcweBuildGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore(self.root / 'workspace')
        self.project = self.store.import_copy(str(ROOT / 'artifacts/aci-poc/NativeGateway.frozen.pcwex'))
        self.pid = self.project['project_id']
        self.project_hash = self.project['project_sha256']
        self.jid = 'f' * 32
        self.job = self.store.root / self.pid / 'builds' / self.jid
        self.job.mkdir(parents=True)
        self.image = self.job / 'synthetic-test.img'
        self.image.write_bytes(b'unit guard fixture; never execute')
        model = self.job / 'analyzed.LastBuild.ast'
        model.write_bytes(b'synthetic model; metadata helper is mocked in every test')
        self.receipt = {'project_id': self.pid, 'job_id': self.jid, 'project_sha256': self.project_hash,
            'analyzed_compiler_model': {'name': model.name, 'sha256': sha(model.read_bytes()), 'rebuilt_from_current_sources': True},
            'generated_files': [], 'input_hashes': {}, 'resource_name': 'RES_' + 'F' * 32}
        self.save_receipt()
        self.plan = {'build_receipt_sha256': sha((self.job / 'result.json').read_bytes()),
                     'image_path': str(self.image), 'image_sha256': sha(self.image.read_bytes()), 'pou_count': 31}

    def save_receipt(self):
        (self.job / 'result.json').write_text(json.dumps(self.receipt), encoding='utf-8')

    def build(self):
        return build_pcwe(self.store, self.pid, self.project_hash, self.jid)

    def test_build_receipt_change_after_plan_stops_before_native_helper(self):
        def planning(*args):
            self.receipt['modified_after_plan'] = True
            self.save_receipt()
            return self.plan
        with mock.patch('plcnext_mcp.pcwe_build.deployment_plan', side_effect=planning):
            with mock.patch('plcnext_mcp.pcwe_build.finalize_runtime_types') as host:
                with self.assertRaisesRegex(ProjectError, 'receipt changed after'):
                    self.build()
                host.assert_not_called()

    def test_receipt_identity_mismatch_is_rejected_even_with_matching_receipt_hash(self):
        self.receipt['project_id'] = '0' * 32
        self.save_receipt()
        self.plan['build_receipt_sha256'] = sha((self.job / 'result.json').read_bytes())
        with mock.patch('plcnext_mcp.pcwe_build.deployment_plan', return_value=self.plan):
            with mock.patch('plcnext_mcp.pcwe_build.finalize_runtime_types') as host:
                with self.assertRaisesRegex(ProjectError, 'receipt changed after'):
                    self.build()
                host.assert_not_called()

    def test_current_revision_change_after_plan_stops_before_native_helper(self):
        current = list(self.store._current(self.pid))
        current[1] = current[1] | {'current_sha256': '0' * 64}
        with mock.patch('plcnext_mcp.pcwe_build.deployment_plan', return_value=self.plan):
            with mock.patch.object(self.store, '_current', return_value=tuple(current)):
                with mock.patch('plcnext_mcp.pcwe_build.finalize_runtime_types') as host:
                    with self.assertRaisesRegex(ProjectError, 'Project changed after'):
                        self.build()
                    host.assert_not_called()

    def fake_finalizer(self, image, types, output, install, hashes):
        output.mkdir()
        (output / 'TypeInformation.json').write_bytes(b'{}')
        (output / 'runtime-types-report.json').write_bytes(b'{}')
        return {'type_information_sha256': sha(b'{}'), 'report_sha256': sha(b'{}')}

    def test_finalized_type_file_must_match_finalizer_receipt(self):
        def altered_finalizer(*args):
            report = self.fake_finalizer(*args)
            report['type_information_sha256'] = '0' * 64
            return report
        with mock.patch('plcnext_mcp.pcwe_build.deployment_plan', return_value=self.plan):
            with mock.patch('plcnext_mcp.pcwe_build.finalize_runtime_types', side_effect=altered_finalizer):
                with mock.patch('plcnext_mcp.pcwe_build.validate_runtime_layout') as validate:
                    with self.assertRaisesRegex(ProjectError, 'Finalized runtime output changed'):
                        self.build()
                    validate.assert_not_called()

    def test_hmi_cannot_use_a_different_type_layout_from_runtime_bindings(self):
        with ExitStack() as stack:
            stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.deployment_plan', return_value=self.plan))
            stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.finalize_runtime_types', side_effect=self.fake_finalizer))
            stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.validate_runtime_layout', return_value={}))
            stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.generate_native_payloads', return_value=({}, {})))
            stack.enter_context(mock.patch('plcnext_mcp.pcwe_build.generate_auxiliary_payloads', return_value=({}, {})))
            stack.enter_context(mock.patch('plcnext_mcp.hmi_output.generate_hmi_pages', return_value=({}, {'runtime_types_sha256': '0' * 64})))
            validate = stack.enter_context(mock.patch('plcnext_mcp.hmi_output.validate_page_bindings'))
            with self.assertRaisesRegex(ProjectError, 'different finalized layouts'):
                self.build()
            validate.assert_not_called()


if __name__ == '__main__':
    unittest.main()
