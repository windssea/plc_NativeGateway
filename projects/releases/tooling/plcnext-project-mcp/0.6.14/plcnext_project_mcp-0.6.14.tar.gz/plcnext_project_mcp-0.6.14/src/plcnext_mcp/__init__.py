"""Independent project-file tools; no ACI or license manager dependency."""

__version__ = "0.6.14"
