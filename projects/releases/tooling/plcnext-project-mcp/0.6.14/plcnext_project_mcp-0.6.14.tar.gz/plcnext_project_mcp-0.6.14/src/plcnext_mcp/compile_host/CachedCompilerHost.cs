using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Ade.Compiler;
using Ade.Compiler.Eclr;
using Ade.Compiler.Model;
using Ade.Components;
using Ade.Reflection;
using Ade.Reflection.Cecil;

// The host owns its announcement log; it has no IDE warning queue to replay.
// No authorization, license, online, or ACI interface is implemented here.
public sealed class CachedBuildAnnouncements : IReemmitWarnings {
    public int Count;
    public void AnnounceBuildItem(string kind, string name) { Count++; }
}
public sealed class CachedProviderMetadata : IAdeTypeManagerProviderMetadata {
    public string ProviderName { get { return "Cecil"; } }
    public bool IsDefault { get { return true; } }
}
public static class CachedCompilerHost {
    private static object Diagnostics(ParserCollectedMessages sink) {
        return sink.Messages.Select(m => new {
            type=m.MessageType.ToString(), type_id=m.TypeId, resource_id=m.ResourceId,
            text=m.Message, location=m.JumpUri == null ? null : m.JumpUri.ToString(),
            format_parameters=m.FormatParameters.Select(p => p == null ? null : p.ToString()).ToArray()
        }).ToArray();
    }

    public static Dictionary<string, object> Run(string astPath, string sourcePath,
                                                string referencesPath, string outputPath) {
        var result = new Dictionary<string, object> {
            {"status", "host_failed"}, {"cache_assisted", true}, {"aci_used", false},
            {"computer_use_used", false}, {"controller_connected", false},
            {"whole_project_rebuilt_from_pcwex", false}, {"deployable", false}
        };
        var archive = Ade.Compiler.Model.ArchiveSerialization.ArchiveReader.ReadFile(astPath, false);
        var project = archive.Item1 as CompilerProject;
        if (project == null || project.ProgramOrganizationUnits.Count != 31)
            throw new InvalidDataException("Expected the pinned NativeGateway 31-POU AST seed.");
        result["historical_cache_messages_not_replayed"] = archive.Item2 == null ? 0 : archive.Item2.Length;
        var target = project.ProgramOrganizationUnits.Single(p => p.Identifier.ToString() == "NG_ReadAck");
        var method = target.Methods.Single(m => m.CodeWorksheets.Count > 0);
        var oldWorksheet = method.CodeWorksheets.Single();
        var parser = new Ade.Compiler.Parsing.StructuredTextParser();
        parser.GetType().GetProperty("IecScannerFactory").SetValue(parser,
            new Lazy<IIecScannerFactory>(() => new IecScannerFactory()));
        parser.GetType().GetProperty("CommonResourceService").SetValue(parser,
            new Lazy<ICommonResourceService>(() => new ParserKeyResources()));
        var syntaxMessages = new ParserCollectedMessages();
        CodeWorksheet replacement;
        using (var input = new StringReader(File.ReadAllText(sourcePath))) {
            var syntax = parser.Parse(input, oldWorksheet.Name, new ParserParameters(), syntaxMessages);
            result["syntax"] = new {errors=syntax.ErrorCount, warnings=syntax.WarningCount,
                messages=Diagnostics(syntaxMessages), messages_truncated=syntaxMessages.TotalMessages > syntaxMessages.Messages.Count};
            if (syntax.ErrorCount != 0) { result["status"] = "syntax_failed"; return result; }
            replacement = syntax.Node;
        }
        var methodBuilder = method.ToBuilder();
        methodBuilder.CodeWorksheets[0] = replacement;
        var pouBuilder = target.ToBuilder();
        pouBuilder.Methods[target.Methods.ToList().IndexOf(method)] = methodBuilder.ToImmutable();
        var projectBuilder = project.ToBuilder();
        projectBuilder.ProgramOrganizationUnits[project.ProgramOrganizationUnits.ToList().IndexOf(target)] = pouBuilder.ToImmutable();
        project = projectBuilder.ToImmutable();

        return CompileProject(project, result, referencesPath, outputPath);
    }

    public static Dictionary<string, object> RunProject(string astPath, string sourcesPath,
                                                        string referencesPath, string outputPath) {
        var archive = Ade.Compiler.Model.ArchiveSerialization.ArchiveReader.ReadFile(astPath, false);
        var seed = archive.Item1 as CompilerProject;
        if (seed == null) throw new InvalidDataException("Expected a compiler project seed.");
        var rebuilt = ProjectSourceBuilder.Rebuild(seed, sourcesPath);
        var result = new Dictionary<string, object> {
            {"status", "syntax_failed"}, {"cache_assisted", true}, {"aci_used", false},
            {"computer_use_used", false}, {"controller_connected", false}, {"deployable", false},
            {"whole_project_rebuilt_from_pcwex", false},
            {"historical_cache_messages_not_replayed", archive.Item2 == null ? 0 : archive.Item2.Length},
            {"syntax", new {errors=rebuilt.ErrorCount, warnings=rebuilt.WarningCount,
                messages=rebuilt.Diagnostics, messages_truncated=rebuilt.DiagnosticsTruncated}}
        };
        if (rebuilt.ErrorCount != 0) return result;
        result["pous_reparsed"] = rebuilt.ParsedPous;
        result["interfaces_reparsed"] = rebuilt.ParsedPous;
        result["variables_reparsed"] = rebuilt.ParsedVariables;
        result["anonymous_datatypes_reparsed"] = rebuilt.GeneratedDataTypes;
        return CompileProject(rebuilt.Project, result, referencesPath, outputPath);
    }

    public static Dictionary<string, object> CompileProject(CompilerProject project,
            Dictionary<string, object> result, string referencesPath, string outputPath) {

        var identifier = new IdentifierHelper();
        var literal = new LiteralParser(identifier);
        var utilities = new CompilerUtilities {
            LiteralParser = new Lazy<ILiteralParser>(() => literal),
            IdentifierHelper = new Lazy<IIdentifierHelper>(() => identifier),
            IecScannerFactory = new Lazy<IIecScannerFactory>(() => new IecScannerFactory())
        };
        var externalFactory = new ExternalConstantProviderFactory(new Lazy<ILiteralParser>(() => literal),
            new Lazy<ICompilerUtilityService>(() => utilities), null, null);
        var announcements = new CachedBuildAnnouncements();
        var analyzer = new SemanticAnalyzer {
            CommonResourceService = new Lazy<ICommonResourceService>(() => new ParserKeyResources()),
            LiteralParser = new Lazy<Ade.Internal.Compiler.IInternalLiteralParser>(() => literal),
            CompilerUtilityService = new Lazy<ICompilerUtilityService>(() => utilities),
            VariableReferenceParserFactory = new Lazy<IIecVariableReferenceParserFactory>(() => new IecVariableReferenceParserFactory()),
            ExternalConstantProviderFactory = new Lazy<IExternalConstantProviderFactory>(() => externalFactory),
            ReemmitWarnings = new Lazy<IReemmitWarnings>(() => announcements)
        };
        var semanticMessages = new ParserCollectedMessages();
        var analyzerParameters = new SemanticAnalyzerParameters {RunParallel=false};
        analyzerParameters.Properties["ForceCheck"] = "True";
        var analysis = analyzer.Analyze(project, analyzerParameters, semanticMessages);
        result["semantic"] = new {errors=analysis.ErrorCount, warnings=analysis.WarningCount,
            messages=Diagnostics(semanticMessages), messages_truncated=semanticMessages.TotalMessages > semanticMessages.Messages.Count,
            historical_warnings_replayed=false, build_item_announcements=announcements.Count};
        if (analysis.ErrorCount != 0) { result["status"] = "semantic_failed"; return result; }
        project = analysis.CompilerProject;
        var analyzedPath = Path.Combine(Path.GetDirectoryName(outputPath), "analyzed.LastBuild.ast");
        if (File.Exists(analyzedPath)) throw new IOException("Refusing to overwrite analyzed AST.");
        Exception serializationError;
        if (!Ade.Compiler.Model.ArchiveSerialization.ArchiveWriter.WriteFile(analyzedPath, project,
                semanticMessages.Messages.ToArray(), out serializationError, false))
            throw serializationError ?? new IOException("Unable to serialize analyzed AST.");

        var provider = new CecilTypeManagerProvider {
            ExpressionProcessorFactory = new Lazy<IAdeExpressionProcessorFactory>(() => new DefaultExpressionProcessorFactory())
        };
        var typeManager = new AdeTypeManagerFactory {
            TypeManagerProviders = new[] {new Lazy<IAdeTypeManagerProvider,IAdeTypeManagerProviderMetadata>(
                () => provider, new CachedProviderMetadata())}
        };
        var factory = new CilGeneratorFactory {
            TypeManagerFactory=typeManager, CompilerUtilityService=utilities, LiteralParser=literal,
            VariableReferenceParserFactory=new IecVariableReferenceParserFactory(),
            ExternalConstantProviderFactory=externalFactory
        };
        var generationParameters = new CilGeneratorParameters();
        generationParameters.Properties["Ade.Compiler.Eclr.PlcNext"] = "true";
        generationParameters.Properties["Ade.Compiler.Eclr.Rebuild"] = "true";
        // AXCF2152 v2026 -> PLCNEXT_ARMTHUMB2_ARM -> PLCNEXT_BASE profile value.
        generationParameters.Properties["Ade.Compiler.Eclr.NamespacesSupported"] = "true";
        var resource = project.Configurations.Single().Resources.Single();
        var references = Directory.GetFiles(referencesPath, "*.dll");
        var cold = result.ContainsKey("ast_seed_used") && !(bool)result["ast_seed_used"];
        var applicationAssemblies = new HashSet<string>(project.ProgramOrganizationUnits.Select(p=>p.Identifier.ToString()+".dll"),StringComparer.OrdinalIgnoreCase);
        applicationAssemblies.Add(resource.Name+".Common.dll");
        applicationAssemblies.Add(resource.Name+".dll");
        if (references.Any(p => cold ? applicationAssemblies.Contains(Path.GetFileName(p))
            : Path.GetFileName(p).StartsWith("NG_", StringComparison.OrdinalIgnoreCase)
            || Path.GetFileName(p).StartsWith("RES_", StringComparison.OrdinalIgnoreCase)
            || Path.GetFileName(p).Equals("Main.dll", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("External references contain a colliding application-code assembly.");
        if (Directory.Exists(outputPath) && Directory.EnumerateFileSystemEntries(outputPath).Any())
            throw new IOException("CIL output directory must be empty.");
        Directory.CreateDirectory(outputPath);
        var generationMessages = new ParserCollectedMessages();
        bool generated;
        using (var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(20))) {
            generated = factory.CreateCilGenerator(generationParameters).Generate(resource, outputPath, references,
                generationMessages, null, TaskScheduler.Default, cancellation.Token, null);
        }
        result["cil"] = new {generator_return_value=generated, messages=Diagnostics(generationMessages),
            messages_truncated=generationMessages.TotalMessages > generationMessages.Messages.Count};
        result["status"] = generated ? "cil_generated" : "cil_failed";
        result["resource_name"] = resource.Name;
        result["generated_files"] = Directory.GetFiles(outputPath).Select(Path.GetFileName).ToArray();
        var scope = result.ContainsKey("ast_seed_used") && !(bool)result["ast_seed_used"]
            ? "AXC F 2152 / 2026 single-resource, 1..16 independent cyclic-task IEC source cold build; no project AST seed is read."
            : result.ContainsKey("pous_reparsed")
              ? "All NativeGateway POU bodies and interfaces are rebuilt from source; library/device/type skeleton still uses the pinned seed."
              : "Legacy pinned NativeGateway seed and NG_ReadAck ST body only.";
        result["limitations"] = new[] {scope,
            "No target limits service or IDE project manager; historical warnings are not replayed.",
            "No hardware/HMI/configuration rebuild or deployment validation."};
        return result;
    }

    public static Dictionary<string, object> RunColdProject(string projectRoot, string installRoot,
            string sourcesPath, string referencesPath, string outputPath) {
        var messages = new ParserCollectedMessages();
        var skeleton = ColdProjectBuilder.BuildProjectSkeleton(projectRoot, installRoot, referencesPath, messages);
        var result = new Dictionary<string, object> {
            {"status", "library_failed"}, {"cache_assisted", false}, {"ast_seed_used", false},
            {"aci_used", false}, {"computer_use_used", false}, {"controller_connected", false},
            {"deployable", false}, {"whole_project_rebuilt_from_pcwex", false},
            {"cold_skeleton", new {errors=skeleton.ErrorCount, warnings=skeleton.WarningCount,
                libraries=skeleton.LibrarySources, library_results=skeleton.LibraryResults,
                tasks=skeleton.Tasks, messages=Diagnostics(messages)}}
        };
        if (skeleton.ErrorCount != 0) return result;
        // Engineer derives the application name from the PCWEX file name. This is
        // an explicit source-manifest input, never an old project's cached name.
        var sourceDocument = new System.Xml.XmlDocument {XmlResolver=null};
        using (var sourceReader=System.Xml.XmlReader.Create(sourcesPath,new System.Xml.XmlReaderSettings {
            DtdProcessing=System.Xml.DtdProcessing.Prohibit, XmlResolver=null})) sourceDocument.Load(sourceReader);
        var applicationName=sourceDocument.DocumentElement.GetAttribute("projectName");
        if (applicationName.Length<1 || applicationName.Length>64
            || !(applicationName[0]=='_' || applicationName[0]>='A' && applicationName[0]<='Z' || applicationName[0]>='a' && applicationName[0]<='z')
            || applicationName.Any(c=>!(c=='_' || c=='.' || c=='-' || c>='A' && c<='Z' || c>='a' && c<='z' || c>='0' && c<='9')))
            throw new InvalidDataException("Unsupported application name in source manifest.");
        if (!String.IsNullOrWhiteSpace(applicationName)) {
            var renamed=skeleton.Project.ToBuilder();
            renamed.Name=applicationName;
            skeleton.Project=renamed.ToImmutable();
        }
        result["application_name"]=skeleton.Project.Name;
        var rebuilt = ProjectSourceBuilder.Rebuild(skeleton.Project, sourcesPath);
        result["syntax"] = new {errors=rebuilt.ErrorCount, warnings=rebuilt.WarningCount,
            messages=rebuilt.Diagnostics, messages_truncated=rebuilt.DiagnosticsTruncated};
        if (rebuilt.ErrorCount != 0) { result["status"]="syntax_failed"; return result; }
        result["pous_reparsed"] = rebuilt.ParsedPous;
        result["interfaces_reparsed"] = rebuilt.ParsedPous;
        result["variables_reparsed"] = rebuilt.ParsedVariables;
        result["anonymous_datatypes_reparsed"] = rebuilt.GeneratedDataTypes;
        return CompileProject(rebuilt.Project, result, referencesPath, outputPath);
    }
}
