"""Rebuild non-HMI PCWE auxiliaries for the verified NativeGateway device profile.

The hardware/service projection is deliberately sealed to the investigated
AXCF2152/2026 configuration. Unknown topology/settings fail closed. Byte outputs
are newly generated from observed formats; no GUI build cache is read.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import PurePosixPath
import re
import sqlite3
import struct
import xml.etree.ElementTree as ET
import zlib

from .project import ProjectError, sha, xml

SUPPORTED_HARDWARE_PROFILE_SHA256 = '9bb21b8aa3c4d83a51b12ccace62ae4c809ec98d45452cd539905ff3d56c4638'
XSI = 'http://www.w3.org/2001/XMLSchema-instance'
SERVER_NS = 'http://www.phoenixcontact.com/schema/opcuaconfig'
CLIENT_NS = 'http://www.phoenixcontact.com/schema/opcuaclientmoduleconfig'
TIC_SCHEMA = 'http://www.phoenixcontact.com/IMA/TIC/1.0/tic.xsd'
_RUNTIME_MEMBERS = {'DataList.dl', 'DataList.dlr4var', 'GlobalVariables.var', 'ResourceSettings.set',
    'IOConfiguration.ioc', 'EsmConfiguration.esmc', 'PlmConfiguration.plmc'}

# Observed SQLite schema, not bytes copied from the old GUI database.
DIAGNOSTIC_SCHEMA = (
    'CREATE TABLE DeviceIdentityInfo(ARUserID INTEGER NOT NULL,VendorName TEXT,DeviceName TEXT,InfoText INTEGER, PRIMARY KEY (ARUserID))',
    'CREATE TABLE ModuleInfo(NodeID INTEGER NOT NULL,ModuleName INTEGER,ModuleInfoText INTEGER,SubModuleName INTEGER,SubModuleInfoText INTEGER, PRIMARY KEY (NodeID))',
    'CREATE TABLE ExternalTextList(TextID INTEGER NOT NULL,Language VARCHAR(5) NOT NULL,Text TEXT, PRIMARY KEY (TextID,Language))',
    'CREATE TABLE ChannelErrorTypeInfo(NodeID INTEGER NOT NULL,ChannelErrorType INTEGER NOT NULL,Name INTEGER,Help INTEGER, PRIMARY KEY (NodeID,ChannelErrorType))',
    'CREATE TABLE ExtChannelErrorTypeInfo(NodeID INTEGER NOT NULL,ChannelErrorType INTEGER NOT NULL,ExtChannelErrorType INTEGER NOT NULL,Name INTEGER,Help INTEGER, PRIMARY KEY (NodeID,ChannelErrorType,ExtChannelErrorType))',
    'CREATE TABLE ReasonInfo(NodeID INTEGER NOT NULL,Reason INTEGER NOT NULL,Name INTEGER,Help INTEGER, PRIMARY KEY (NodeID,Reason))',
    'CREATE TABLE ExtReasonInfo(NodeID INTEGER NOT NULL,Reason INTEGER NOT NULL,ExtReason INTEGER NOT NULL,Name INTEGER,Help INTEGER, PRIMARY KEY (NodeID,Reason,ExtReason))',
    'CREATE TABLE SchemaVersion(Key TEXT NOT NULL,Version INTEGER, PRIMARY KEY (Key))',
    'CREATE TABLE UnitDiagTypeItem(VendorID INTEGER NOT NULL,DeviceID INTEGER NOT NULL,UserStructureIdentifier INTEGER NOT NULL,Name INTEGER,Help INTEGER,AttributeID INTEGER, PRIMARY KEY (VendorID,DeviceID,UserStructureIdentifier))',
    'CREATE TABLE ProfileUnitDiagTypeItem(VendorID INTEGER NOT NULL,DeviceID INTEGER NOT NULL,UserStructureIdentifier INTEGER NOT NULL,API INTEGER NOT NULL,Name INTEGER,Help INTEGER,AttributeID INTEGER, PRIMARY KEY (VendorID,DeviceID,UserStructureIdentifier,API))',
    'CREATE TABLE UnitDiagTypeRef(AttributeID INTEGER NOT NULL,RefID INTEGER NOT NULL,AttributeName INTEGER,ByteOffset INTEGER,ByteLength INTEGER,BitOffset INTEGER,BitLength INTEGER,DataType INTEGER,ValueItemTargetID INTEGER, PRIMARY KEY (AttributeID,RefID))',
    'CREATE TABLE ValueItemAssignment(ValueItemTargetID INTEGER NOT NULL,Content INTEGER NOT NULL,Text INTEGER, PRIMARY KEY (ValueItemTargetID,Content))',
)


def _node_value(node):
    """Prefix-independent XML projection; indentation/tails do not encode settings."""
    if node.tail and node.tail.strip():
        raise ProjectError('Unexpected mixed text in hardware profile XML.')
    return [node.tag, sorted(node.attrib.items()), node.text if node.text and node.text.strip() else '',
            [_node_value(child) for child in node]]


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')


def _hardware_profile(members: dict[str, bytes]) -> tuple[str, dict, dict]:
    records = {}
    source_hashes = {}
    opcua = {}
    for name, data in sorted(members.items()):
        if not name.startswith('PROJECT/Hardware/') or name.endswith('/'):
            continue
        path = PurePosixPath(name)
        if '/HMI_Server/' in name or path.name in _RUNTIME_MEMBERS or path.suffix in ('.Transport', '.DataLink'):
            continue
        source_hashes[name] = sha(data)
        if path.suffix == '.ds':
            root = xml(data)
            for node in root.iter():
                match = re.search(r"Para\[@uID='(opcua[^']+)'\]/Current$", node.get('xPath', ''))
                if match:
                    key = match[1]
                    if key in opcua:
                        raise ProjectError('Duplicate OPC UA source setting: ' + key)
                    opcua[key] = node.text or ''
                    if key == 'opcuaNodeName':
                        node.text = '__SOURCE_NODE_NAME__'
            records[name] = sha(_encoded(_node_value(root)))
        else:
            records[name] = sha(data)
    if 'PROJECT/PROJECT.proj' not in members:
        raise ProjectError('Project manifest is missing.')
    project = xml(members['PROJECT/PROJECT.proj'])
    nodes = []
    for node in project.iter():
        include = node.get('Include', '').replace('\\', '/')
        if include.startswith('Hardware') and '/HMI_Server/' not in include:
            nodes.append(_node_value(node))
    records['PROJECT/PROJECT.proj#hardware-items'] = sha(_encoded(nodes))
    source_hashes['PROJECT/PROJECT.proj'] = sha(members['PROJECT/PROJECT.proj'])
    return sha(_encoded(records)), opcua, source_hashes


def _serialize(root):
    ET.indent(root, space='  ')
    text = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n' + ET.tostring(root, encoding='unicode')
    return b'\xef\xbb\xbf' + text.replace('\n', '\r\n').encode('utf-8')


def _root(name, schema, namespace):
    return ET.Element(name, {'schemaVersion': schema, 'xmlns:xsi': XSI,
        'xsi:schemaLocation': namespace, 'xmlns': namespace})


def _opcua_documents(settings):
    name = settings.get('opcuaNodeName', '')
    if not name or len(name) > 255 or any(ord(c) < 32 or ord(c) > 126 for c in name):
        raise ProjectError('Unsupported OPC UA source node name.')
    server = _root('OpcUAConfigurationDocument', '2.4', SERVER_NS)
    ET.SubElement(server, 'NodeName').text = name
    certificate = ET.SubElement(ET.SubElement(server, 'ServerCertificate'), 'SelfSigned')
    for _ in range(4):
        ET.SubElement(ET.SubElement(certificate, 'SubjectAlternativeName'), 'NotSet')
    ET.SubElement(ET.SubElement(server, 'GdsPortsToProvide'), 'None')
    ET.SubElement(ET.SubElement(server, 'SubscriptionSettings'), 'SubscriptionKind').text = settings['opcuaSubscriptionSettingsSubscriptionKind']
    security = ET.SubElement(server, 'SecuritySettings',
        ApplicationUriCheck=settings['opcuaSecuritySettingsApplicationUriCheck'].lower(),
        ApplicationAuthentication=settings['opcuaSecuritySettingsApplicationAuthentication'].lower())
    for algorithm in ('Basic256Sha256', 'Aes128Sha256RsaOaep', 'Aes256Sha256RsaPss'):
        if settings['opcua' + algorithm + 'Enabled'].lower() == 'true':
            ET.SubElement(security, algorithm)
    client = _root('OpcUAClientModuleConfigurationDocument', '1.0', CLIENT_NS)
    ET.SubElement(client, 'Application')
    return _serialize(server), _serialize(client)


def _profinet_documents():
    attributes = {'xmlns:xsi': XSI, 'xsi:noNamespaceSchemaLocation': TIC_SCHEMA}
    controller = ET.Element('TIC', attributes)
    group = ET.SubElement(ET.SubElement(controller, 'E', n='PN:C'), 'AL')
    for name, value in [('RTClass1', 'true'), ('RTClass3', 'false'),
                         ('MultipleInterfaceMode', 'true'), ('DiagnosisDatabase', 'ProfinetDiagnosticDatabase.db')]:
        ET.SubElement(ET.SubElement(group, 'A', n=name), 'V').text = value
    links = ET.Element('TIC', attributes)
    ET.SubElement(links, 'Arc', {'role': 'Parent', 'from': 'controller.tic', 'to': '.tic'})
    first, second = _serialize(controller), _serialize(links)
    crc = struct.pack('<II', 1, zlib.crc32(second, zlib.crc32(first)))
    with sqlite3.connect(':memory:') as database:
        for statement in DIAGNOSTIC_SCHEMA:
            database.execute(statement)
        database.execute('INSERT INTO SchemaVersion(Key,Version) VALUES(?,?)', ('Version', 0))
        database.commit()
        diagnostic = database.serialize()
    return first, second, diagnostic, crc


def _software_manifest(members, project_name, started):
    if not isinstance(project_name, str) or not project_name or len(project_name) > 255 or any(ord(c) < 32 for c in project_name):
        raise ProjectError('Invalid software package project name.')
    if isinstance(started, str):
        try:
            started = datetime.fromisoformat(started.replace('Z', '+00:00'))
        except ValueError as exc:
            raise ProjectError('Invalid package build timestamp.') from exc
    if not isinstance(started, datetime) or started.tzinfo is None:
        raise ProjectError('Package timestamp must explicitly include its UTC offset.')
    started = started.astimezone(timezone.utc)
    if started.year < 1970:
        raise ProjectError('Package timestamp precedes the supported epoch.')
    metadata_name = 'PROJECT/Hardware/VersionHistory.usermeta'
    if metadata_name not in members:
        raise ProjectError('Project version metadata is missing.')
    metadata = xml(members[metadata_name])
    for node in metadata.iter():
        local = node.tag.rsplit('}', 1)[-1]
        if local in ('revTable', 'keyValuePairTable') and list(node):
            raise ProjectError('Software revision/tag overrides are outside the verified profile.')
        if local == 'dcec' and any((child.text or '').strip() for child in node):
            raise ProjectError('Software description/metadata overrides are outside the verified profile.')
    elapsed = started - datetime(1970, 1, 1, tzinfo=timezone.utc)
    nanoseconds = ((elapsed.days * 86400 + elapsed.seconds) * 1000000 + elapsed.microseconds) * 1000
    result = {'manifestVersion': '1.0', 'identification': {
        'name': project_name, 'manufacturer': 'PHOENIX CONTACT GmbH & Co. KG',
        'manufacturerUri': 'http://phoenixcontact.com', 'productCode': 'PLCnext Engineer project',
        'model': 'PLCnext Engineer project', 'softwareRevision': str(nanoseconds),
        'releaseDate': started.isoformat(timespec='microseconds').replace('+00:00', 'Z'),
        'description': '', 'targetProductCodes': ['2404267'], 'targetFirmwareRevision': '26.0.0'},
        'updateBehavior': ['KeepsParameters', 'WillDisconnect', 'NeedsPreparation'], 'tags': {}}
    return json.dumps(result, ensure_ascii=False, indent=2).encode('utf-8')


def generate_auxiliary_payloads(project_members: dict[str, bytes], project_name: str,
                                build_started_utc: str | datetime) -> tuple[dict[str, bytes], dict]:
    """Generate seven auxiliary outputs for the sealed NativeGateway hardware profile.

    The caller binds project_members to the current managed revision and supplies
    its compiler project name and package-build UTC timestamp. Profiles are a
    conservative capability boundary, not a claim of general hardware support.
    """
    profile, settings, sources = _hardware_profile(project_members)
    if profile != SUPPORTED_HARDWARE_PROFILE_SHA256:
        raise ProjectError('Unsupported NativeGateway hardware/service profile; auxiliary outputs were not generated.')
    server, client = _opcua_documents(settings)
    controller, links, diagnostic, crc = _profinet_documents()
    files = {'Services/OpcUA/PCWE.opcua.config': server,
        'Services/OpcUA/Modules/Client/client.module.config': client,
        'Io/Arp.Io.PnC/controller.tic': controller, 'Io/Arp.Io.PnC/links.xml': links,
        'Io/Arp.Io.PnC/ProfinetDiagnosticDatabase.db': diagnostic, 'Io/Arp.Io.PnC/Tic.crc': crc,
        'PCWE.software-package-manifest.json': _software_manifest(project_members, project_name, build_started_utc)}
    return files, {'scope': 'NativeGateway_AXCF2152_2026_verified_hardware_service_profile',
        'hardware_profile_sha256': profile, 'source_members': sources,
        'opcua_node_name': settings['opcuaNodeName'], 'opcua_setting_count': len(settings),
        'opcua_server_schema': '2.4', 'opcua_client_schema': '1.0',
        'profinet_device_count': 0, 'diagnostic_table_count': 12,
        'diagnostic_nonempty_tables': {'SchemaVersion': [['Version', 0]]},
        'tic_crc_hex': crc.hex(), 'gui_cache_used': False,
        'software_identification': json.loads(files['PCWE.software-package-manifest.json'])['identification'],
        'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()},
        'controller_connected': False, 'controller_downloaded': False,
        'limitations': ['Hardware/service changes beyond the validated profile are rejected.',
                       'These files do not validate HMI, runtime mappings, signatures or device acceptance.']}
