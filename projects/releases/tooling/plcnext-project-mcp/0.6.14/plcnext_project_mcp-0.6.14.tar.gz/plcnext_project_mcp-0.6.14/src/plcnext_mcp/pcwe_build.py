"""Create a complete offline PCWE candidate from one source-bound cold build.

Only the explicitly validated NativeGateway hardware/HMI profile is supported.
No device transport, GUI, ACI, signing or target execution is present here.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import uuid

from .deployment_package import MANIFEST, _relative_path, inspect_pcwe
from .deployment_plan import deployment_plan, _file, _verify
from .pcwe_native import generate_native_payloads, make_pcwe_manifest
from .pcwe_auxiliary import generate_auxiliary_payloads
from .project import ProjectError, ProjectStore, decode_code, masked_st, sha, xml
from .runtime_configuration import generate_runtime_configuration, validate_runtime_configuration
from .runtime_layout import finalize_runtime_types, validate_runtime_layout

DEFAULT_INSTALL = Path(r'D:\Program Files\PHOENIX CONTACT\PLCnext Engineer 2026.0')


def _save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def _merge(target, files):
    folded = {name.casefold() for name in target}
    for name, payload in files.items():
        _relative_path(name)
        if name.casefold() in folded or not isinstance(payload, bytes):
            raise ProjectError('Duplicate or invalid generated PCWE member: ' + name)
        target[name] = payload
        folded.add(name.casefold())


def _profile(members):
    project = xml(members['PROJECT/PROJECT.proj'])
    devices = []
    for item in project.iter():
        values = {n.tag.rsplit('}', 1)[-1]: n.text for n in item}
        if values.get('FolderType') == 'Configuration':
            devices.append(values)
    if len(devices) != 1 or devices[0].get('TypeName') != 'AXC F 2152' or devices[0].get('TypeRevision') != '00/2026.0.0':
        raise ProjectError('PCWE generation supports the validated AXC F 2152 / 2026 profile only.')
    return {'device_type': 'AXCF2152', 'device_version': '2026.0.0'}


def build_pcwe(store: ProjectStore, project_id: str, expected_project_sha256: str, build_job_id: str,
               download_memento_policy: str = 'omit') -> dict:
    from .download_memento import download_memento_payloads
    memento_files, memento_report = download_memento_payloads(download_memento_policy)
    # This checks every source member, compiler source mapping and generated file.
    plan = deployment_plan(store, project_id, expected_project_sha256, build_job_id)
    folder = store._folder(project_id)
    with store._lock(folder):
        _, manifest, members, _, _ = store._current(project_id)
        if manifest['current_sha256'] != expected_project_sha256:
            raise ProjectError('Project changed after deployment planning.')
        job = _file(folder, 'builds/' + build_job_id)
        build_bytes = (job / 'result.json').read_bytes()
        build = json.loads(build_bytes)
        if sha(build_bytes) != plan['build_receipt_sha256'] or any(build.get(k) != v for k, v in {
                'project_id': project_id, 'job_id': build_job_id,
                'project_sha256': expected_project_sha256}.items()):
            raise ProjectError('Build receipt changed after deployment planning.')
        model = build.get('analyzed_compiler_model', {})
        if model.get('name') != 'analyzed.LastBuild.ast' or model.get('rebuilt_from_current_sources') is not True:
            raise ProjectError('This build lacks a source-bound analyzed model. Cold-compile the current copy again.')
        _verify(job, model['name'], model.get('sha256'))
        profile = _profile(members)
        if any(masked_st(decode_code(data)).strip() for path, data in members.items()
               if path.endswith('/IOConfiguration.ioc')):
            raise ProjectError('PCWE generation supports the verified empty I/O configuration only.')
        if any(p.lower().endswith('.authsettings') for p in members):
            raise ProjectError('Explicit HMI authentication settings are not yet supported.')
        runtime_files, runtime_report = generate_runtime_configuration(
            members, ownership_contract=manifest.get('multitask_ownership_contract'))
        name = runtime_report['domain']['name']
        generated_hashes = {f['name']: f['sha256'] for f in build['generated_files']}
        parent = _file(folder, 'deployments')
        parent.mkdir(exist_ok=True)
        output = parent / uuid.uuid4().hex
        output.mkdir()
        started = datetime.now(timezone.utc).isoformat()
        result = store._identity(folder, manifest) | {
            'status': 'building_offline', 'package_complete': False, 'build_job_id': build_job_id,
            'build_receipt_sha256': sha(build_bytes), 'analyzed_model_sha256': model['sha256'],
            'package_job_id': output.name, 'job_directory': str(output), 'started_utc': started,
            'deployable': False, 'controller_connected': False, 'controller_downloaded': False,
            'aci_used': False, 'computer_use_used': False, 'gui_cache_used': False,
            'scope': 'NativeGateway_AXCF2152_2026_verified_hardware_and_HMI_profile'}
        report_path = output / 'result.json'
        _save(report_path, result)
        try:
            install = Path(os.environ.get('PLCNEXT_ENGINEER_DIRECTORY', DEFAULT_INSTALL)).resolve()
            runtime_directory = output / 'runtime-layout'
            finalized = finalize_runtime_types(Path(plan['image_path']), job / 'generated/TypeInformation.json',
                                               runtime_directory, install, generated_hashes)
            type_bytes = (runtime_directory / 'TypeInformation.json').read_bytes()
            native_bytes = (runtime_directory / 'runtime-types-report.json').read_bytes()
            if sha(type_bytes) != finalized['type_information_sha256'] or sha(native_bytes) != finalized['report_sha256']:
                raise ProjectError('Finalized runtime output changed before binding validation.')
            type_info = json.loads(type_bytes)
            native_info = json.loads(native_bytes)
            bindings = validate_runtime_layout(members, runtime_report, type_info, native_info, build['resource_name'])
            _save(output / 'runtime-configuration.json', runtime_report)
            _save(output / 'runtime-bindings.json', bindings)
            files = dict(runtime_files)
            _merge(files, memento_files)
            _save(output / 'download-memento.json', memento_report)
            result['download_memento'] = memento_report
            native_files, native_report = generate_native_payloads(job, build['input_hashes'], members,
                profile['device_type'], profile['device_version'])
            _merge(files, native_files)
            auxiliary_files, auxiliary_report = generate_auxiliary_payloads(members, name, started)
            _merge(files, auxiliary_files)
            _save(output / 'native-libraries.json', native_report)
            _save(output / 'auxiliaries.json', auxiliary_report)
            image_bytes = Path(plan['image_path']).read_bytes()
            if sha(image_bytes) != plan['image_sha256']:
                raise ProjectError('Consumed PCWE image bytes differ from the verified cold build.')
            _merge(files, {'Plc/Eclr/eCLR.img': image_bytes})

            from .hmi_output import generate_hmi_pages, validate_page_bindings
            from .hmi_support import generate_hmi_support
            pages, page_report = generate_hmi_pages(job, runtime_directory / 'TypeInformation.json',
                                                    output / 'hmi-pages', install)
            if page_report.get('runtime_types_sha256') != finalized['type_information_sha256']:
                raise ProjectError('HMI and runtime bindings used different finalized layouts.')
            validate_page_bindings(page_report, runtime_report, type_info, pages)
            _save(output / 'hmi-pages.json', page_report)
            hmi_files, hmi_report = generate_hmi_support(members, type_info, runtime_report, pages, install, name)
            if hmi_report.get('hmi_complete') is not True:
                raise ProjectError('HMI generation is incomplete.')
            _merge(files, hmi_files)
            _save(output / 'hmi-support.json', hmi_report)
            # Verify the source/build did not change while native parsers and HMI ran.
            if (job / 'result.json').read_bytes() != build_bytes:
                raise ProjectError('Build receipt changed during package generation.')
            for relative, digest in build['input_hashes'].items():
                _verify(job, relative, digest)
            for filename, digest in generated_hashes.items():
                _verify(job, 'generated/' + filename, digest)
            _verify(job, model['name'], model['sha256'])
            _verify(runtime_directory, 'TypeInformation.json', finalized['type_information_sha256'])
            _verify(runtime_directory, 'runtime-types-report.json', finalized['report_sha256'])
            if store._current(project_id)[1]['current_sha256'] != expected_project_sha256:
                raise ProjectError('Managed revision changed during package generation.')
            files[MANIFEST] = make_pcwe_manifest(files)
            pcwe = output / 'PCWE'
            pcwe.mkdir()
            for relative, payload in sorted(files.items()):
                destination = pcwe / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open('xb') as stream:
                    stream.write(payload)
            inspection = inspect_pcwe(pcwe)
            semantic = validate_runtime_configuration({p: (pcwe / p).read_bytes() for p in runtime_files}, runtime_report)
            if inspection['overall_hash_status'] != 'verified' or not semantic['passed']:
                raise ProjectError('Generated PCWE failed readback verification.')
            _save(output / 'pcwe-inspection.json', inspection)
            result.update(status='pcwe_generated_offline', package_complete=True, pcwe_path=str(pcwe),
                inventory_sha256=inspection['inventory_sha256'], file_count=len(files),
                file_hashes_verified=True, overall_hash_status='verified',
                pou_count=plan['pou_count'], runtime_type_count=bindings['runtime_type_count'],
                global_variable_count=bindings['variable_count'], hmi_mapping_count=bindings['hmi_mapping_count'],
                fb_instance_count=bindings['fb_instance_count'], runtime_binding_validation_passed=True,
                fb_instance_scope=bindings['fb_instance_scope'],
                hmi_page_binding_count=page_report['runtime_binding_count'],
                hmi_page_objects=page_report['page_objects'], hmi_file_count=len(hmi_files),
                type_layout_receipt=finalized, original_build_outputs_unchanged=True,
                managed_revision_unchanged=True, signatures_generated=False,
                limitations=['Only the validated hardware/service/HMI profile is supported; unknown inputs are rejected.',
                    'No controller acceptance, execution, target memory-limit or signature validation was performed.',
                    'Complete local PCWE directory; not an exported DAuM ZIP.'])
            _save(report_path, result)
            return result
        except Exception as exc:
            result.update(status='package_generation_failed', error=str(exc)[:6000], package_complete=False)
            _save(report_path, result)
            raise ProjectError('Offline PCWE generation failed; report: ' + str(report_path) + '; ' + str(exc)) from exc
