using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Linq;
using Ade.Compiler;
using Ade.Compiler.Model;
using Ade.Compiler.Parsing;
using Ade.Components;
using Ade.Reflection;
using Ade.Reflection.Cecil;

public sealed class ColdProjectSkeletonResult {
    public CompilerProject Project;
    public int ErrorCount;
    public int WarningCount;
    public string[] ReferencePaths;
    public readonly List<object> LibrarySources = new List<object>();
    public readonly List<object> LibraryResults = new List<object>();
    public readonly List<object> Tasks = new List<object>();
    public bool CompilerAstSeedUsed { get { return false; } }
}
public sealed class ColdProviderMetadata : IAdeTypeManagerProviderMetadata {
    public string ProviderName { get { return "Cecil"; } }
    public bool IsDefault { get { return true; } }
}

// No application host, ACI, project build cache or licensing service is used.
// Source XML/text is parsed afresh. Vendor library DLLs remain external inputs.
public static class ColdProjectBuilder {
    private static readonly XNamespace Msbuild = "http://schemas.microsoft.com/developer/msbuild/2003";
    private static string Value(XElement parent, string name, string fallback="") {
        var child=parent.Elements().FirstOrDefault(e => e.Name.LocalName==name);
        return child==null ? fallback : child.Value;
    }
    private static string StagePath(string projectRoot, string relative) {
        var norm=relative.Replace('\\',Path.DirectorySeparatorChar).Replace('/',Path.DirectorySeparatorChar);
        var plain=Path.GetFullPath(Path.Combine(projectRoot,norm));
        if(!plain.StartsWith(Path.GetFullPath(projectRoot)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Project path leaves staged project: "+relative);
        if(File.Exists(plain)||Directory.Exists(plain)) return plain;
        return Path.Combine(projectRoot,norm.Replace(" ","%20"));
    }
    private static void ConfigureParser(object parser) {
        var scanner=parser.GetType().GetProperty("IecScannerFactory");
        if(scanner!=null) scanner.SetValue(parser,new Lazy<IIecScannerFactory>(()=>new IecScannerFactory()));
        var resources=parser.GetType().GetProperty("CommonResourceService");
        if(resources!=null) resources.SetValue(parser,new Lazy<ICommonResourceService>(()=>new ParserKeyResources()));
    }
    private static void Merge(CompilerProjectBuilder target, CompilerProject source,string assemblyName) {
        foreach(var v in source.Libraries) target.Libraries.Add(v);
        foreach(var v in source.ElementaryDataTypes) target.ElementaryDataTypes.Add(v);
        foreach(var v in source.GenericDataTypes) target.GenericDataTypes.Add(v);
        foreach(var v in source.Interfaces) target.Interfaces.Add(v);
        foreach(var v in source.DataTypeWorksheets) {
            var sheet=v.ToBuilder();sheet.Name=assemblyName+"."+v.Name;
            target.DataTypeWorksheets.Add(sheet.ToImmutable());
        }
        foreach(var v in source.ProgramOrganizationUnits) target.ProgramOrganizationUnits.Add(v);
        foreach(var v in source.PragmaDefinitions) target.PragmaDefinitions.Add(v);
    }
    private static XDocument ReadXml(string path) {
        using(var reader=XmlReader.Create(path,new XmlReaderSettings {DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))
            return XDocument.Load(reader);
    }
    private static string ResolveLibraryPath(string name,string hint,string installRoot,string jobRoot) {
        var inputs=ReadXml(Path.Combine(jobRoot,"library-inputs.xml"));
        var declared=inputs.Root.Elements("Library").Where(e=>(string)e.Attribute("name")==name && (string)e.Attribute("hint")==hint).ToArray();
        if(declared.Length!=1) throw new InvalidDataException("Missing or ambiguous staged library input: "+name);
        var relative=(string)declared[0].Attribute("staged");
        var staged=Path.GetFullPath(Path.Combine(jobRoot,relative.Replace('/',Path.DirectorySeparatorChar)));
        var libraryRoot=Path.GetFullPath(Path.Combine(jobRoot,"libraries"))+Path.DirectorySeparatorChar;
        if(!staged.StartsWith(libraryRoot,StringComparison.OrdinalIgnoreCase) || !File.Exists(staged)
            || !String.Equals(Sha256(staged),(string)declared[0].Attribute("sha256"),StringComparison.Ordinal))
            throw new InvalidDataException("Staged library input changed or escaped the job: "+name);
        return staged;
    }
    private static void CopyNew(string source,string destination,bool overwrite) {
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        if(overwrite||!File.Exists(destination)) File.Copy(source,destination,overwrite);
    }
    private static void ExtractDll(ZipArchiveEntry entry,string destination,bool overwrite) {
        if(!overwrite&&File.Exists(destination)) {
            using(var input=entry.Open())
            using(var algorithm=System.Security.Cryptography.SHA256.Create()) {
                var incoming=BitConverter.ToString(algorithm.ComputeHash(input)).Replace("-","").ToLowerInvariant();
                if(incoming!=Sha256(destination)) throw new InvalidDataException("Conflicting external library assembly: "+entry.Name);
            }
            return;
        }
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        using(var input=entry.Open()) using(var output=File.Create(destination)) input.CopyTo(output);
    }
    private static string Sha256(string path) {
        using(var stream=File.OpenRead(path))
        using(var algorithm=System.Security.Cryptography.SHA256.Create())
            return BitConverter.ToString(algorithm.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
    }
    private static string Sha256(ZipArchiveEntry entry) {
        using(var stream=entry.Open())
        using(var algorithm=System.Security.Cryptography.SHA256.Create())
            return BitConverter.ToString(algorithm.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
    }
    private static XDocument PackageManifest(ZipArchive archive) {
        var entry=archive.GetEntry("PROJECT/PROJECT.proj");
        if(entry==null) throw new InvalidDataException("Library package has no PROJECT/PROJECT.proj.");
        using(var stream=entry.Open())
        using(var reader=XmlReader.Create(stream,new XmlReaderSettings {DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))
            return XDocument.Load(reader);
    }

    public static ColdProjectSkeletonResult BuildProjectSkeleton(string projectRoot,string installRoot,
                                                                 string referenceDir,IMessageSink messages) {
        var jobRoot=Directory.GetParent(Path.GetFullPath(projectRoot)).FullName;
        if(File.Exists(Path.Combine(projectRoot,"PROJECT","PROJECT.proj"))) projectRoot=Path.Combine(projectRoot,"PROJECT");
        var manifest=ReadXml(Path.Combine(projectRoot,"PROJECT.proj"));
        var output=new ColdProjectSkeletonResult();
        Directory.CreateDirectory(referenceDir);
        var project=CompilerProjectNodeFactory.CompilerProjectBuilder();
        project.Name="ColdFromSource";
        var packages=new List<Tuple<string,string>> {
            Tuple.Create("IEC 61131-3",Path.Combine(installRoot,"DefaultLibraries","IEC 61131-3.pxclx")),
            Tuple.Create("Extended",Path.Combine(installRoot,"DefaultLibraries","Extended.pcwlx")),
            Tuple.Create("Safety IEC 61131-3",Path.Combine(installRoot,"DefaultLibraries","Safety IEC 61131-3.pcwlx"))
        };
        foreach(var entry in manifest.Descendants().Where(e=>e.Name.LocalName=="SolutionReference"))
            packages.Add(Tuple.Create((string)entry.Attribute("Include"),ResolveLibraryPath((string)entry.Attribute("Include"),Value(entry,"HintPath"),installRoot,jobRoot)));

        // A package's PrecompiledLibrary items identify its own assemblies.
        // Embedded DLLs not declared there are dependency snapshots, which must
        // not replace another selected package's explicitly declared output.
        // Conflicting explicit declarations remain unsupported and fail closed.
        var declaredAssemblies=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        foreach(var package in packages) {
            using(var archive=ZipFile.OpenRead(package.Item2)) {
                var packageManifest=PackageManifest(archive);
                foreach(var declaration in packageManifest.Descendants().Where(e=>e.Name.LocalName=="PrecompiledLibrary")) {
                    var path=(string)declaration.Attribute("Include");
                    var member="PROJECT/"+path.Replace('\\','/').Replace(" ","%20");
                    var entry=archive.GetEntry(member);
                    if(entry==null) throw new InvalidDataException("Declared precompiled library member unavailable: "+member);
                    var name=Path.GetFileName(path.Replace('\\','/'));
                    var hash=Sha256(entry);
                    string selected;
                    if(declaredAssemblies.TryGetValue(name,out selected) && selected!=hash)
                        throw new InvalidDataException("Conflicting explicitly declared library assemblies: "+name);
                    declaredAssemblies[name]=hash;
                }
            }
        }

        var provider=new CecilTypeManagerProvider {
            ExpressionProcessorFactory=new Lazy<IAdeExpressionProcessorFactory>(()=>new DefaultExpressionProcessorFactory())
        };
        var typeManager=new AdeTypeManagerFactory {
            TypeManagerProviders=new[] {new Lazy<IAdeTypeManagerProvider,IAdeTypeManagerProviderMetadata>(()=>provider,new ColdProviderMetadata())}
        };
        var assemblyParserType=typeof(CompilerUtilities).Assembly.GetType("Ade.Internal.Compiler.AssemblyParser",true);
        var assemblyParser=(IAssemblyParser)Activator.CreateInstance(assemblyParserType,new object[]{typeManager});

        // Runtime metadata references come from the selected shipped eCLR profile,
        // never from a prior project's RES folder.
        var runtimeFiles=new List<string>();
        var runtimePackage=Path.Combine(installRoot,"Profiles","eCLR Core.zip");
        var runtimeDlls=new List<object>();
        using(var archive=ZipFile.OpenRead(runtimePackage)) {
            foreach(var entry in archive.Entries.Where(e=>e.FullName.StartsWith("Copy/3.4.0/",StringComparison.Ordinal)
                                                        &&e.Name.EndsWith(".dll",StringComparison.OrdinalIgnoreCase))) {
                var destination=Path.Combine(referenceDir,entry.Name);
                ExtractDll(entry,destination,true);runtimeFiles.Add(destination);
                runtimeDlls.Add(new {archive_member=entry.FullName,staged_relative_path=entry.Name,sha256=Sha256(destination)});
            }
        }
        output.LibrarySources.Add(new {name="eCLR Core runtime metadata",path=runtimePackage,package_sha256=Sha256(runtimePackage),
            selected_profile_version="3.4.0",extracted_dlls=runtimeDlls,compiler_ast_seed=false});
        foreach(var package in packages) {
            var packageDir=Path.Combine(referenceDir,"package-"+packages.IndexOf(package).ToString("D2",CultureInfo.InvariantCulture));
            Directory.CreateDirectory(packageDir);
            using(var archive=ZipFile.OpenRead(package.Item2)) {
                var extractedDlls=new List<object>();
                foreach(var entry in archive.Entries.Where(e=>e.FullName.StartsWith("PROJECT/Logical%20Elements/",StringComparison.Ordinal)
                                                            &&e.Name.EndsWith(".dll",StringComparison.OrdinalIgnoreCase))) {
                    ExtractDll(entry,Path.Combine(packageDir,entry.Name),false);
                    // Library packages can carry their own pcoslib/runtime copy.
                    // The selected device profile owns those native references;
                    // other duplicate assembly names must have identical bytes.
                    var profileRuntime=runtimeFiles.Any(p=>Path.GetFileName(p).Equals(entry.Name,StringComparison.OrdinalIgnoreCase));
                    var hash=Sha256(Path.Combine(packageDir,entry.Name));
                    string declaredHash;
                    var declared=declaredAssemblies.TryGetValue(entry.Name,out declaredHash);
                    var shadowedDependency=declared && declaredHash!=hash;
                    if(!profileRuntime && !shadowedDependency) ExtractDll(entry,Path.Combine(referenceDir,entry.Name),false);
                    extractedDlls.Add(new {archive_member=entry.FullName,staged_relative_path=Path.GetRelativePath(referenceDir,Path.Combine(packageDir,entry.Name)),sha256=hash,native_reference_source=profileRuntime?"selected_eclr_profile":shadowedDependency?"other_package_explicit_PrecompiledLibrary":declared?"explicit_PrecompiledLibrary":"unambiguous_dependency",selected_native_reference_sha256=profileRuntime?Sha256(Path.Combine(referenceDir,entry.Name)):declared?declaredHash:hash});
                }
                foreach(var runtime in runtimeFiles) CopyNew(runtime,Path.Combine(packageDir,Path.GetFileName(runtime)),false);
                var libraryManifest=PackageManifest(archive);
                var group=CompilerProjectNodeFactory.CompilerProjectBuilder();group.Name=package.Item1;
                int sourceCount=0;
                foreach(var declaration in libraryManifest.Descendants().Where(e=>e.Name.LocalName=="PrecompiledLibrary")) {
                    var dll=Path.Combine(packageDir,Path.GetFileName(((string)declaration.Attribute("Include")).Replace('\\','/')));
                    var parsed=assemblyParser.Parse(dll,messages);
                    output.ErrorCount+=parsed.ErrorCount;output.WarningCount+=parsed.WarningCount;
                    if(parsed.Node!=null) Merge(group,parsed.Node,Path.GetFileNameWithoutExtension(dll));
                    output.LibraryResults.Add(new {package=package.Item1,dll=Path.GetFileName(dll),errors=parsed.ErrorCount,warnings=parsed.WarningCount,
                        pous=parsed.Node==null?0:parsed.Node.ProgramOrganizationUnits.Count,types=parsed.Node==null?0:parsed.Node.DataTypeWorksheets.Sum(w=>w.DataTypes.Count)});
                    sourceCount++;
                }
                project.Libraries.Add(group.ToImmutable());
                output.LibrarySources.Add(new {name=package.Item1,path=package.Item2,package_sha256=Sha256(package.Item2),precompiled_assemblies=sourceCount,extracted_dlls=extractedDlls,compiler_ast_seed=false});
            }
        }

        foreach(var file in Directory.GetFiles(projectRoot,"*.dt",SearchOption.AllDirectories)) {
            var parser=new DataTypeParser();ConfigureParser(parser);
            using(var reader=File.OpenText(file)) {
                var parsed=parser.Parse(reader,new Uri(file).AbsoluteUri,new ParserParameters(),messages);
                output.ErrorCount+=parsed.ErrorCount;output.WarningCount+=parsed.WarningCount;
                if(parsed.Node!=null) project.DataTypeWorksheets.Add(parsed.Node);
            }
        }
        var folders=manifest.Descendants().Where(e=>e.Name.LocalName=="Folder").ToArray();
        var configurations=folders.Where(e=>Value(e,"FolderType")=="Configuration").ToArray();
        var resources=folders.Where(e=>Value(e,"FolderType")=="Resource").ToArray();
        if(configurations.Length!=1 || resources.Length!=1
            || Value(configurations[0],"TypeName")!="AXC F 2152"
            || Value(configurations[0],"TypeRevision")!="00/2026.0.0"
            || Value(resources[0],"TypeName")!="eCLR")
            throw new NotSupportedException("Only AXC F 2152 / 00/2026.0.0 with a single eCLR resource is supported.");
        foreach(var cfgFolder in folders.Where(e=>Value(e,"FolderType")=="Configuration")) {
            var cfgInclude=(string)cfgFolder.Attribute("Include");
            var config=CompilerProjectNodeFactory.ConfigurationBuilder();
            config.Name=Path.GetFileName(cfgInclude.Replace('\\','/'));
            config.ConfigurationType=Value(cfgFolder,"TypeName");
            foreach(var resFolder in folders.Where(e=>Value(e,"FolderType")=="Resource" && ((string)e.Attribute("Include")).StartsWith(cfgInclude+"\\",StringComparison.Ordinal))) {
                var resInclude=(string)resFolder.Attribute("Include");
                var resource=CompilerProjectNodeFactory.ResourceBuilder();
                resource.Name=Path.GetFileName(resInclude.Replace('\\','/'));
                resource.ResourceType=Value(resFolder,"TypeName","eCLR");
                var globals=StagePath(projectRoot,resInclude+"/GlobalVariables.var");
                if(File.Exists(globals)) {
                    var parser=new PlcVariableParser();ConfigureParser(parser);
                    using(var reader=File.OpenText(globals)) {
                        var parsed=parser.Parse(reader,new Uri(globals).AbsoluteUri,new ParserParameters(),messages);
                        output.ErrorCount+=parsed.ErrorCount;output.WarningCount+=parsed.WarningCount;
                        if(parsed.Node!=null) resource.GlobalVariableWorksheets.Add(parsed.Node);
                        if(parsed.DataTypes.Count>0) {
                            var generated=CompilerProjectNodeFactory.DataTypeWorksheet().ToBuilder();
                            generated.Name=resource.Name+".GeneratedGlobalTypes";
                            foreach(var item in parsed.DataTypes) generated.DataTypes.Add(item);
                            project.DataTypeWorksheets.Add(generated.ToImmutable());
                        }
                    }
                }
                var ioPath=StagePath(projectRoot,resInclude+"/IOConfiguration.ioc");
                if(File.Exists(ioPath)) {
                    var parser=new IOConfigurationParser();ConfigureParser(parser);
                    using(var reader=File.OpenText(ioPath)) {
                        var parsed=parser.Parse(reader,new Uri(ioPath).AbsoluteUri,new ParserParameters(),messages);
                        output.ErrorCount+=parsed.ErrorCount;output.WarningCount+=parsed.WarningCount;
                        foreach(var item in parsed.InputIOGroups) resource.InputIOGroups.Add(item);
                        foreach(var item in parsed.OutputIOGroups) resource.OutputIOGroups.Add(item);
                    }
                }
                var esmPath=StagePath(projectRoot,cfgInclude+"/PLCnext/EsmConfiguration.esmc");
                var esm=ReadXml(esmPath);
                var tasks=esm.Descendants("Task").ToArray();
                if(tasks.Length<1 || tasks.Length>16) throw new NotSupportedException("One to sixteen independent cyclic eCLR tasks are supported.");
                var taskNames=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                var instanceNames=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                var programOwners=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
                foreach(var taskXml in tasks) {
                    if((string)taskXml.Attribute("taskType")!="CyclicTask") throw new NotSupportedException("Only source-declared cyclic tasks are supported by this cold probe.");
                    var task=CompilerProjectNodeFactory.CyclicTaskBuilder();
                    task.Name=(string)taskXml.Attribute("name");
                    if(!taskNames.Add(task.Name)) throw new InvalidDataException("Duplicate cyclic task name.");
                    task.Priority=int.Parse((string)taskXml.Attribute("priority"),CultureInfo.InvariantCulture);
                    task.Interval=float.Parse((string)taskXml.Attribute("intervalTime"),CultureInfo.InvariantCulture)/1000000f;
                    task.Timeout=float.Parse((string)taskXml.Attribute("watchdogTime"),CultureInfo.InvariantCulture)/1000000f;
                    var instances=taskXml.Descendants("ProgramInstance").ToArray();
                    if(instances.Length==0 || instances.Any(e=>(string)e.Attribute("componentName")!="Arp.Plc.Eclr"))
                        throw new NotSupportedException("Only local eCLR task program instances are supported.");
                    foreach(var instanceXml in instances) {
                        var instance=CompilerProjectNodeFactory.ProgramInstanceBuilder();
                        instance.Name=(string)instanceXml.Attribute("name");
                        if(!instanceNames.Add(instance.Name)) throw new InvalidDataException("Program instance names must be unique across tasks.");
                        var programName=(string)instanceXml.Attribute("programType");
                        string owner;
                        if(programOwners.TryGetValue(programName,out owner) && owner!=task.Name)
                            throw new InvalidDataException("Program POU types cannot be shared across cyclic tasks.");
                        programOwners[programName]=task.Name;
                        instance.ProgramInstanceType=IecTypeIdentifier.Parse((string)instanceXml.Attribute("programType"));
                        task.ProgramInstances.Add(instance.ToImmutable());
                        resource.Programs.Add(instance.ProgramInstanceType);
                    }
                    resource.Tasks.Add(task.ToImmutable());
                    output.Tasks.Add(new {configuration=config.Name,resource=resource.Name,name=task.Name,interval_ns=(string)taskXml.Attribute("intervalTime"),watchdog_ns=(string)taskXml.Attribute("watchdogTime"),priority=task.Priority,instances=task.ProgramInstances.Select(i=>i.Name).ToArray(),time_unit_mapping="ESM nanoseconds / 1000000 -> compiler model milliseconds; AXC F 2152 / 2026 profile"});
                }
                config.Resources.Add(resource.ToImmutable());
            }
            project.Configurations.Add(config.ToImmutable());
        }
        output.Project=project.ToImmutable();
        output.ReferencePaths=Directory.GetFiles(referenceDir,"*.dll",SearchOption.TopDirectoryOnly);
        return output;
    }
}
