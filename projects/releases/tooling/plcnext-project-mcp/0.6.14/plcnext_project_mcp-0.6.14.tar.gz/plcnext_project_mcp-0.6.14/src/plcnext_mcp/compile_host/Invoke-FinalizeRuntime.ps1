param([Parameter(Mandatory)][string]$InputImage,
      [Parameter(Mandatory)][string]$InputTypeInformation,
      [Parameter(Mandatory)][string]$OutputDirectory,
      [Parameter(Mandatory)][string]$InstallDirectory)
$ErrorActionPreference='Stop'
$outputRoot=[IO.Path]::GetFullPath($OutputDirectory)
$typeOutput=Join-Path $outputRoot 'TypeInformation.json'
if(Test-Path -LiteralPath $typeOutput){throw 'Runtime type output must be new.'}
if([IO.Path]::GetFullPath($InputTypeInformation) -eq $typeOutput){throw 'Cannot overwrite compiler input.'}
[void][IO.Directory]::CreateDirectory($outputRoot)
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Reflection;
public static class RuntimeTypeResolver {
 public static string Root;
 public static Assembly Resolve(object sender,ResolveEventArgs args) {
  var name=new AssemblyName(args.Name).Name;
  if(name.StartsWith("Ade.ApplicationControl",StringComparison.OrdinalIgnoreCase)
   || name.StartsWith("Ade.Online",StringComparison.OrdinalIgnoreCase)
   || name.IndexOf("CodeMeter",StringComparison.OrdinalIgnoreCase)>=0
   || name.IndexOf("Wibu",StringComparison.OrdinalIgnoreCase)>=0)
    throw new InvalidOperationException("Out-of-scope assembly: "+name);
  var path=Path.Combine(Root,name+".dll");
  return File.Exists(path)?Assembly.LoadFrom(path):null;
 }
}
'@
[RuntimeTypeResolver]::Root=[IO.Path]::GetFullPath($InstallDirectory)
$resolver=[ResolveEventHandler][RuntimeTypeResolver]::Resolve
[AppDomain]::CurrentDomain.add_AssemblyResolve($resolver)
$result=[ordered]@{status='failed';controller_connected=$false;controller_downloaded=$false}
try {
 $refs=@('Ade.Reflection.dll','Ade.ReflectionImpl.dll','Ade.Reflection.CecilImpl.dll','Ade.Reflection.EclrImpl.dll',
  'Ade.Compiler.dll','Ade.Compiler.EclrImpl.dll','Ade.Components.dll','Ade.Core.dll','Ade.Patterns.dll',
  'System.ComponentModel.Composition.dll','Mono.Cecil.dll') | ForEach-Object {Join-Path $InstallDirectory $_}
 foreach($r in $refs){[void][Reflection.Assembly]::LoadFrom($r)}
 $refs+=@('System.Runtime.dll','System.Collections.dll','System.Linq.dll','System.ComponentModel.Primitives.dll','netstandard.dll')
 Add-Type -Path (Join-Path $PSScriptRoot 'FinalizeRuntimeTypes.cs') -ReferencedAssemblies $refs -CompilerOptions '/nowarn:1701'
 [IO.File]::Copy([IO.Path]::GetFullPath($InputTypeInformation),$typeOutput,$false)
 $result=[FinalizeRuntimeTypes]::Run([IO.Path]::GetFullPath($InputImage),$outputRoot)
} catch {
 $errors=@();$errorItem=$_.Exception
 while($null -ne $errorItem){$errors+=@{type=$errorItem.GetType().FullName;message=$errorItem.Message;stack=$errorItem.StackTrace};$errorItem=$errorItem.InnerException}
 $result['errors']=$errors
} finally {
 $result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $outputRoot 'runtime-types-report.json') -Encoding utf8
 [AppDomain]::CurrentDomain.remove_AssemblyResolve($resolver)
}
if($result.status -eq 'failed'){exit 2}
