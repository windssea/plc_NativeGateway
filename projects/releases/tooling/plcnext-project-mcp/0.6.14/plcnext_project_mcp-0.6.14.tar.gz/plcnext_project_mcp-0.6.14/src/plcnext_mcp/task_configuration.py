"""Independent ESM task inspection and bounded scheduling edits on project copies.

The source uses nanoseconds. ColdProjectBuilder maps these values to compiler
milliseconds. This module never loads Engineer/ACI or opens a network socket.
"""
from __future__ import annotations

from datetime import datetime, timezone
import copy
import json
import os
from pathlib import Path
import re
import tempfile
import uuid
import xml.etree.ElementTree as ET

from .project import ProjectError, decode_code, encode_worksheet, masked_st, pou_index, read_archive, sha, xml

FIELDS = {'interval_ns': 'intervalTime', 'watchdog_ns': 'watchdogTime', 'priority': 'priority'}
MAX_TIME_NS = 86400000000000
MAX_CYCLIC_TASKS = 16


def _source(members: dict[str, bytes]):
    paths = [name for name in members if name.endswith('/PLCnext/EsmConfiguration.esmc')]
    if len(paths) != 1:
        raise ProjectError('Task inspection requires exactly one ESM source configuration.')
    member = paths[0]
    root = xml(members[member])
    if root.tag != 'EsmConfiguration' or root.get('version') != '2':
        raise ProjectError('Only ESM source schema version 2 is supported.')
    if {child.tag for child in root} - {'Esms', 'Tasks'}:
        raise ProjectError('Unsupported additional ESM source section.')
    esms = root.findall('./Esms/Esm')
    tasks = root.findall('./Tasks/Task')
    all_identified = [root, *esms, *tasks,
                      *[instance for task in tasks for instance in task.findall('./ProgramInstances/ProgramInstance')]]
    try:
        identities = [uuid.UUID(item.get('id', '')) for item in all_identified]
    except (ValueError, TypeError, AttributeError) as exc:
        raise ProjectError('ESM/task/program instance identities must be GUIDs.') from exc
    if len(identities) != len(set(identities)):
        raise ProjectError('Duplicate ESM/task/program instance identity.')
    esm_ids = {item.get('id') for item in esms}
    if any(task.get('esmId') not in esm_ids for task in tasks):
        raise ProjectError('Task references a missing ESM identity.')
    return member, root, esms, tasks


def inspect_task_configuration(store, project_id: str) -> dict:
    """Read source scheduling attributes and exact program-instance mappings."""
    folder, manifest, members, _, _ = store._current(project_id)
    member, root, esms, tasks = _source(members)
    index = pou_index(members)
    result = []
    for task in tasks:
        item = {'id': task.get('id'), 'name': task.get('name'), 'task_type': task.get('taskType'),
                'esm_id': task.get('esmId'), 'comment': task.get('comment', ''),
                'source_attributes': dict(task.attrib), 'program_instances': []}
        if task.get('taskType') == 'CyclicTask':
            for public, source in FIELDS.items():
                try:
                    item[public] = int(task.get(source, ''))
                except ValueError as exc:
                    raise ProjectError('Invalid integer task timing/priority source value.') from exc
        for instance in task.findall('./ProgramInstances/ProgramInstance'):
            program = instance.get('programType')
            item['program_instances'].append({
                'id': instance.get('id'), 'name': instance.get('name'), 'program_type': program,
                'component_name': instance.get('componentName'), 'library_name': instance.get('libraryName'),
                'comment': instance.get('comment', ''), 'source_attributes': dict(instance.attrib),
                'local_program_pou_exists': index.get(program, {}).get('kind') == 'Program',
                'pou_id': index.get(program, {}).get('id'),
            })
        result.append(item)
    return {**store._identity(folder, manifest), 'backend': 'independent_esm_source', 'aci_used': False,
            'esm_member': member, 'esm_sha256': sha(members[member]), 'schema_version': root.get('version'),
            'time_unit': 'nanoseconds', 'esms': [dict(item.attrib) for item in esms], 'tasks': result,
            'editable_scope': 'Supported AXCF2152/2026 single eCLR resource; 1..16 independent cyclic tasks; interval_ns/watchdog_ns/priority, task creation/deletion and distinct local Program instances.',
            'compiled': False, 'controller_connected': False,
            'limitations': ['Source scheduling is not the current controller state or measured execution time.',
                            'Multitask source isolation is conservative; shared mutable globals/external/addressed storage are rejected. Runtime execution and external-library concurrency remain unverified.']}


def _updates(updates: dict) -> dict[str, int]:
    if not isinstance(updates, dict) or not updates or set(updates) - set(FIELDS):
        raise ProjectError('updates must contain only interval_ns, watchdog_ns and/or priority.')
    for field, value in updates.items():
        if type(value) is not int:
            raise ProjectError('Task scheduling values must be integers, not booleans, floats or strings.')
        if field == 'priority':
            if not 0 <= value <= 99:
                raise ProjectError('Task priority must be 0..99 for the supported cold-build profile.')
        elif not 1 <= value <= MAX_TIME_NS:
            raise ProjectError('Task time must be 1..86400000000000 nanoseconds for the supported cold-build profile.')
    return updates


def _patch(data: bytes, task_id: str, updates: dict[str, int]) -> bytes:
    """Replace only numeric attribute bytes, leaving every other source byte intact."""
    _updates(updates)
    _, _, _, tasks = _source({'PROJECT/config/PLCnext/EsmConfiguration.esmc': data})
    selected = [task for task in tasks if task.get('id') == task_id]
    if len(selected) != 1:
        raise ProjectError('Unknown or stale task identity.')
    task = selected[0]
    if task.get('taskType') != 'CyclicTask':
        raise ProjectError('Scheduling edits support existing cyclic tasks only.')
    if task.get('readonly', '').casefold() != 'false':
        raise ProjectError('Readonly or ambiguous task cannot be edited.')
    # Source schema has an unnamespaced Task. XML comments are masked so a
    # commented-out Task cannot be confused with the active start tag.
    masked = re.sub(rb'<!--.*?-->|<!\[CDATA\[.*?\]\]>', lambda match: b' ' * len(match[0]), data, flags=re.S)
    tags = list(re.finditer(rb'<Task\b[^<>]*>', masked))
    tags = [match for match in tags if re.search(rb'(?<![\w:.-])id\s*=\s*([\'\"])' +
            re.escape(task_id.encode('ascii')) + rb'\1', data[match.start():match.end()])]
    if len(tags) != 1:
        raise ProjectError('Unsupported or ambiguous task start-tag representation.')
    tag = data[tags[0].start():tags[0].end()]
    replaced = tag
    for field, value in updates.items():
        attribute = FIELDS[field].encode('ascii')
        pattern = re.compile(rb'(?<![\w:.-])' + attribute + rb'(\s*=\s*)([\'"])([0-9]+)\2')
        matches = list(pattern.finditer(replaced))
        if len(matches) != 1:
            raise ProjectError('Task scheduling attribute must occur once as a nonnegative integer.')
        match = matches[0]
        replaced = replaced[:match.start(3)] + str(value).encode('ascii') + replaced[match.end(3):]
    result = data[:tags[0].start()] + replaced + data[tags[0].end():]
    if result == data:
        raise ProjectError('Task update would make no change.')
    # Reparse to establish that only the intended three scheduling attributes changed.
    before = xml(data)
    after = xml(result)
    before_task = next(t for t in before.findall('./Tasks/Task') if t.get('id') == task_id)
    after_task = next(t for t in after.findall('./Tasks/Task') if t.get('id') == task_id)
    for field, value in updates.items():
        if after_task.get(FIELDS[field]) != str(value):
            raise ProjectError('Task attribute patch verification failed.')
        before_task.set(FIELDS[field], str(value))
    if ET.tostring(before) != ET.tostring(after):
        raise ProjectError('Task patch changed source beyond the requested scheduling values.')
    return result


def update_cyclic_task(store, project_id: str, expected_project_sha256: str,
                       task_id: str, updates: dict) -> dict:
    """Create an atomic new copy revision with bounded cyclic scheduling changes."""
    from .expanded_compile import _cold_project_snapshot
    from .lifecycle import _zip_bytes
    _updates(updates)
    folder = store._folder(project_id)
    with store._lock(folder):
        folder, manifest, members, infos, comment = store._current(project_id)
        if expected_project_sha256 != manifest['current_sha256']:
            raise ProjectError('Stale project revision; read the project again before editing tasks.')
        # Reuse the exact independently validated source/profile gate, not a
        # guessed device-name match or arbitrary XML scheduling edit.
        _cold_project_snapshot(store, project_id, expected_project_sha256)
        member, _, _, _ = _source(members)
        before = members[member]
        after = _patch(before, task_id, updates)
        final = dict(members)
        final[member] = after
        # A numeric scheduling edit does not change the declared data owner or
        # any program closure. Recompute and check the same explicit declaration
        # against the new exact source; never broaden it silently.
        existing_contract = manifest.get('multitask_ownership_contract')
        if existing_contract is not None:
            rebound = make_task_ownership_contract(final, existing_contract['request'])
            validate_cyclic_schedule(final, ownership_contract=rebound)
            manifest['multitask_ownership_contract'] = rebound
        raw = _zip_bytes(final, infos, comment)
        revision = manifest['revision'] + 1
        target = folder / f'revision-{revision:04d}.pcwex'
        while target.exists():
            revision += 1
            target = folder / f'revision-{revision:04d}.pcwex'
        fd, temporary_name = tempfile.mkstemp(prefix='.task-', suffix='.tmp', dir=folder)
        os.close(fd)
        temporary = Path(temporary_name)
        try:
            temporary.write_bytes(raw)
            checked_raw, checked, _, _ = read_archive(temporary)
            if checked_raw != raw or checked != final:
                raise ProjectError('Task payload preservation check failed.')
            os.rename(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        event = {'operation': 'update_cyclic_task', 'revision': revision, 'member': member,
                 'task_id': task_id, 'updates': dict(updates), 'before_sha256': sha(before),
                 'after_sha256': sha(after), 'project_sha256': sha(raw),
                 'created_utc': datetime.now(timezone.utc).isoformat()}
        if existing_contract is not None:
            event['ownership_contract'] = manifest['multitask_ownership_contract']
        manifest['revision'], manifest['current_sha256'] = revision, sha(raw)
        manifest.setdefault('task_history', []).append(event)
        manifest['history'].append(event)
        try:
            store._save_manifest(folder, manifest)
        except Exception:
            try:
                persisted = store._load(project_id)[1]
                if persisted['current_sha256'] != sha(raw):
                    target.unlink(missing_ok=True)
            except (OSError, ValueError, KeyError):
                pass
            raise
        return {**store._identity(folder, manifest), 'task_id': task_id, 'updated': dict(updates),
                'time_unit': 'nanoseconds', 'changed_members': [member], 'esm_sha256': sha(after),
                'other_member_payloads_identical': True, 'instance_mapping_preserved': True,
                'instance_mapping_scope': 'ESM source task/program identities and assignments; not controller execution.',
                'compiled': False, 'controller_connected': False, 'aci_used': False,
                'runtime_effect_verified': False}


def validate_cyclic_schedule(members: dict[str, bytes], index: dict | None = None,
                              ownership_contract: dict | None = None) -> dict:
    """Validate bounded source task identities, bindings and multitask isolation.

    This proves declared project-source separation, not arbitrary library thread
    safety or a runtime performance budget. Shared mutable project globals and
    address/external/pointer access are conservatively refused for multiple tasks.
    """
    from .expanded_compile import _safe_identifier
    _, _, esms, tasks = _source(members)
    index = index or pou_index(members)
    if not 1 <= len(tasks) <= MAX_CYCLIC_TASKS:
        raise ProjectError('Cold compilation supports 1..16 cyclic eCLR tasks.')
    task_names, instance_names, program_owners = set(), set(), {}
    instances = []
    closures = {}
    for task in tasks:
        name = _safe_identifier(task.get('name', ''), 'task name')
        if name.casefold() in task_names or task.get('taskType') != 'CyclicTask':
            raise ProjectError('Task names must be unique and every task must be cyclic.')
        task_names.add(name.casefold())
        if task.get('readonly', '').casefold() != 'false':
            raise ProjectError('Readonly or ambiguous task configuration is unsupported.')
        if [node.tag for node in task] != ['ProgramInstances']:
            raise ProjectError('Each cyclic task requires exactly one ProgramInstances section.')
        values = {}
        try:
            for field, attribute in FIELDS.items():
                raw = task.get(attribute, '')
                if re.fullmatch('[0-9]+', raw) is None:
                    raise ValueError('not a nonnegative integer')
                values[field] = int(raw)
        except (ValueError, TypeError) as exc:
            raise ProjectError('Task timing/priority requires integer source values.') from exc
        _updates(values)
        bound = task.findall('./ProgramInstances/ProgramInstance')
        if not 1 <= len(bound) <= 32 or any(node.tag != 'ProgramInstance' for node in task[0]):
            raise ProjectError('Each cyclic task requires 1..32 supported local program instances.')
        roots = []
        for instance in bound:
            instance_name = _safe_identifier(instance.get('name', ''), 'program instance name')
            program = instance.get('programType', '')
            if instance_name.casefold() in instance_names:
                raise ProjectError('Program instance names must be unique across the entire eCLR resource.')
            instance_names.add(instance_name.casefold())
            if index.get(program, {}).get('kind') != 'Program':
                raise ProjectError('Program instance references a missing/non-program POU.')
            if (instance.get('componentName') != 'Arp.Plc.Eclr'
                    or instance.get('libraryName') != 'Arp.Plc.Eclr'):
                raise ProjectError('Task instances must reference current local eCLR Program POUs; native/external components are unsupported.')
            previous = program_owners.setdefault(program.casefold(), name)
            if previous != name:
                raise ProjectError('A Program POU type cannot be shared by multiple tasks; use a distinct Program and instance.')
            roots.append(program)
            instances.append(instance)
        closures[name] = _source_closure(index, members, roots)
    shared = []
    owner = None
    ownership_verified = False
    if len(tasks) > 1:
        if ownership_contract is not None:
            if type(ownership_contract) is not dict or type(ownership_contract.get('request')) is not dict:
                raise ProjectError('Invalid explicit multitask ownership contract.')
            expected_contract = make_task_ownership_contract(members, ownership_contract['request'])
            if ownership_contract != expected_contract:
                raise ProjectError('Multitask ownership contract is stale; source/closure/instance identities changed. Declare and review ownership again.')
            owner = ownership_contract['request']['exclusive_owner_task']
            ownership_verified = True
        globals_ = set()
        for path, payload in members.items():
            if path.endswith('/GlobalVariables.var'):
                text = masked_st(decode_code(payload))
                for match in re.finditer(r'(?<![\w.])([A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)*)\s*(?:AT\s+%[\w.]+\s*)?:\s*[A-Za-z_]\w*', text, re.I):
                    globals_.update(name.casefold() for name in re.findall(r'[A-Za-z_]\w*',match.group(1)))
        owners = {}
        for name, source in closures.items():
            unsafe = re.search(r'\b(VAR_EXTERNAL|VAR_ACCESS|VAR_GLOBAL|VAR_STAT|VAR_STATIC|VAR_CONFIG|POINTER|REFERENCE|ADR)\b|\bAT\s+%', source, re.I)
            if unsafe and name != owner:
                raise ProjectError('Multitask Program closures cannot use external/global/addressed/pointer storage without an explicit ownership implementation.')
            tokens = {token.casefold() for token in re.findall(r'\b[A-Za-z_]\w*\b', source)}
            if owner is None:
                _require_local_only_closure(source, index, name)
            if owner is not None and name != owner:
                if globals_ & tokens:
                    raise ProjectError('Independent task closure touches primary-owned globals: ' + name)
                if instance_names & tokens:
                    raise ProjectError('Independent task closure references a resource Program instance: ' + name)
                _require_local_only_closure(source, index, name)
            for variable in globals_ & tokens:
                owners.setdefault(variable, []).append(name)
        shared = sorted(variable for variable, names in owners.items() if len(names) > 1)
        if shared:
            raise ProjectError('Multitask source closures share mutable global variables: ' + ', '.join(shared[:20]))
    return {'tasks': tasks, 'instances': instances, 'task_count': len(tasks),
            'program_instance_count': len(instances),
            'source_isolation': {'checked': len(tasks) > 1,
                'shared_mutable_global_names': shared, 'program_types_shared_across_tasks': False,
                'explicit_ownership_contract_verified': ownership_verified,
                'exclusive_primary_task': owner,
                'ownership_is_declared_not_formal_memory_safety_proof': bool(owner),
                'external_library_concurrency_verified': False,
                'runtime_execution_verified': False}}


def _require_local_only_closure(source: str, index: dict, task_name: str):
    """A deliberately narrow secondary task: local scalars/arrays/local FBs only."""
    elementary = {'BOOL','BYTE','WORD','DWORD','LWORD','SINT','INT','DINT','LINT','USINT','UINT','UDINT','ULINT',
                  'REAL','LREAL','STRING','WSTRING','TIME','LTIME','DATE','LDATE','TOD','LTOD','DT','LDT'}
    local_fb = {name.upper() for name,item in index.items() if item['kind']=='FunctionBlock'}
    local_calls = {name.upper() for name in index}
    for match in re.finditer(r'(?m)^\s*([A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)*)\s*:\s*(?:ARRAY\s*\[[^\]]+\]\s*OF\s*)?([A-Za-z_]\w*)',source,re.I):
        names,dtype=match.groups()
        if dtype.upper() not in elementary | local_fb:
            raise ProjectError('Independent task uses an unverified/shared library or structured storage type: '+task_name+'.'+dtype)
        if dtype.upper() in local_fb:
            local_calls.update(name.upper() for name in re.findall(r'[A-Za-z_]\w*',names))
    pure_calls={'IF','WHILE','FOR','CASE','ABS','SQRT','SIN','COS','TAN','ASIN','ACOS','ATAN','EXP','LN','LOG',
                'MIN','MAX','LIMIT','SEL','MUX','SHL','SHR','ROL','ROR','LEN','CONCAT','LEFT','RIGHT','MID',
                'INSERT','DELETE','REPLACE','FIND','TRUNC','ROUND','EXPT'}
    for name in re.findall(r'\b([A-Za-z_]\w*)\s*\(',source):
        upper=name.upper()
        conversion=re.fullmatch(r'(?:[A-Z]+_)?TO_([A-Z0-9_]+)',upper)
        if upper not in local_calls | pure_calls | elementary and not (conversion and conversion[1] in elementary):
            raise ProjectError('Independent task calls an unverified native/shared-state operation: '+task_name+'.'+name)


def make_task_ownership_contract(members: dict[str, bytes], request: dict) -> dict:
    """Bind an explicit ownership decision to exact source and task identities."""
    fields={'schema','exclusive_owner_task','independent_local_tasks','no_cross_task_data_handoff',
            'primary_owns_existing_globals_and_native_io','arbitrary_memory_safety_proven'}
    if (type(request) is not dict or set(request)!=fields
            or request['schema']!='plcnext-multitask-ownership-request/v1'
            or request['no_cross_task_data_handoff'] is not True
            or request['primary_owns_existing_globals_and_native_io'] is not True
            or request['arbitrary_memory_safety_proven'] is not False
            or type(request['exclusive_owner_task']) is not str
            or type(request['independent_local_tasks']) is not list
            or any(type(name) is not str for name in request['independent_local_tasks'])):
        raise ProjectError('Explicit ownership request must acknowledge exclusive primary globals/native I/O, locals-only secondary tasks and no formal arbitrary-memory proof.')
    _,_,_,tasks=_source(members)
    names=[task.get('name') for task in tasks]
    primary=request['exclusive_owner_task']
    if (len(tasks)<2 or primary not in names or len(set(names))!=len(names)
            or sorted(request['independent_local_tasks'])!=sorted(name for name in names if name!=primary)):
        raise ProjectError('Ownership request must name exactly the primary and all independent secondary tasks.')
    index=pou_index(members)
    bindings=[]
    closures={}
    for task in tasks:
        programs=task.findall('./ProgramInstances/ProgramInstance')
        roots=[instance.get('programType') for instance in programs]
        if any(name not in index for name in roots):
            raise ProjectError('Ownership task refers to a missing Program POU.')
        closures[task.get('name')]=sha(_source_closure(index,members,roots).encode('utf-8'))
        bindings.append({'task_id':task.get('id'),'task_name':task.get('name'),'esm_id':task.get('esmId'),
                         'program_instances':[dict(instance.attrib) for instance in programs]})
    return {'schema':'plcnext-multitask-ownership-contract/v1','request':copy.deepcopy(request),
            'task_bindings':bindings,'closure_sha256':closures,
            'source_member_sha256':{path:sha(data) for path,data in sorted(members.items()) if not path.endswith('/')},
            'library_internal_thread_safety_verified':False,'runtime_execution_verified':False}


def _source_closure(index: dict, members: dict[str, bytes], roots: list[str]) -> str:
    pending, seen, text = list(roots), set(), []
    by_lower = {name.casefold(): name for name in index}
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        item = index[name]
        source = '\n'.join(masked_st(decode_code(members.get(item['prefix'] + suffix, b'')))
                           for suffix in ('Variables.var', 'Code.st'))
        text.append(source)
        for token in re.findall(r'\b[A-Za-z_]\w*\b', source):
            other = by_lower.get(token.casefold())
            if other and other not in seen:
                pending.append(other)
    return '\n'.join(text)


def _structure_bytes(data: bytes, additions: list[dict], deletions: list[str]) -> bytes:
    """Replay an explicit task structure transaction with persisted fresh IDs."""
    _, root, _, tasks = _source({'PROJECT/config/PLCnext/EsmConfiguration.esmc': data})
    container = root.find('Tasks')
    if container is None or not tasks:
        raise ProjectError('A supported nonempty Tasks section is required.')
    if len(set(deletions)) != len(deletions) or any(value not in {task.get('id') for task in tasks} for value in deletions):
        raise ProjectError('delete_task_ids must contain distinct existing task IDs.')
    exemplar = tasks[0]
    for task in tasks:
        if task.get('id') in deletions:
            if task.get('readonly', '').casefold() != 'false':
                raise ProjectError('Readonly tasks cannot be deleted.')
            container.remove(task)
    for addition in additions:
        expected = {'id','name','esm_id','interval_ns','watchdog_ns','priority','instance_id','instance_name','program_type'}
        if type(addition) is not dict or set(addition) != expected:
            raise ProjectError('Invalid replayable cyclic task addition.')
        _updates({key:addition[key] for key in FIELDS})
        from .expanded_compile import _safe_identifier
        for key in ('name','instance_name','program_type'):
            _safe_identifier(addition[key], key)
        for key in ('id','esm_id','instance_id'):
            try:
                uuid.UUID(addition[key])
            except (ValueError, TypeError, AttributeError) as exc:
                raise ProjectError('Task and instance additions require GUID identities.') from exc
        task = copy.deepcopy(exemplar)
        task.set('id', addition['id'])
        task.set('name', addition['name'])
        task.set('esmId', addition['esm_id'])
        task.set('comment', '')
        task.set('readonly', 'false')
        for key, attribute in FIELDS.items():
            task.set(attribute,str(addition[key]))
        for child in list(task):
            task.remove(child)
        instances = ET.SubElement(task,'ProgramInstances')
        ET.SubElement(instances,'ProgramInstance',{
            'id':addition['instance_id'],'name':addition['instance_name'],
            'programType':addition['program_type'],'componentName':'Arp.Plc.Eclr',
            'libraryName':'Arp.Plc.Eclr','comment':''})
        container.append(task)
    if not 1 <= len(container.findall('Task')) <= MAX_CYCLIC_TASKS:
        raise ProjectError('At least one and at most 16 cyclic tasks must remain.')
    ET.indent(root,space='  ')
    after = ET.tostring(root,encoding='utf-8',xml_declaration=True) + b'\n'
    _source({'PROJECT/config/PLCnext/EsmConfiguration.esmc': after})
    return after


def _publish_revision(store, folder, manifest, before, final, infos, comment, event, history_key):
    from .lifecycle import _zip_bytes
    raw = _zip_bytes(final,infos,comment)
    revision = manifest['revision'] + 1
    target = folder / f'revision-{revision:04d}.pcwex'
    while target.exists():
        revision += 1
        target = folder / f'revision-{revision:04d}.pcwex'
    fd,name = tempfile.mkstemp(prefix='.schedule-',suffix='.tmp',dir=folder)
    os.close(fd)
    temporary=Path(name)
    try:
        temporary.write_bytes(raw)
        checked_raw,checked,_,_=read_archive(temporary)
        if checked_raw != raw or checked != final:
            raise ProjectError('Task/program structure payload verification failed.')
        os.rename(temporary,target)
    finally:
        temporary.unlink(missing_ok=True)
    event = {**event,'revision':revision,'project_sha256':sha(raw),
             'created_utc':datetime.now(timezone.utc).isoformat()}
    manifest['revision'],manifest['current_sha256']=revision,sha(raw)
    manifest.setdefault(history_key,[]).append(event)
    manifest['history'].append(event)
    try:
        store._save_manifest(folder,manifest)
    except Exception:
        try:
            if store._load(manifest['project_id'])[1]['current_sha256'] != sha(raw):
                target.unlink(missing_ok=True)
        except (OSError,ValueError,KeyError):
            pass
        raise
    return {**store._identity(folder,manifest),'changed_members':sorted(
        path for path in set(before)|set(final) if before.get(path)!=final.get(path) or (path in before)!=(path in final)),
        'compiled':False,'controller_connected':False,'aci_used':False,'runtime_effect_verified':False}


def change_cyclic_tasks(store, project_id: str, expected_project_sha256: str,
                         add_tasks: list[dict] | None = None,
                         delete_task_ids: list[str] | None = None,
                         ownership_contract: dict | None = None) -> dict:
    """Create/delete bounded independent cyclic tasks on a new offline revision."""
    from .expanded_compile import _cold_project_snapshot
    additions=[] if add_tasks is None else add_tasks
    deletions=[] if delete_task_ids is None else delete_task_ids
    if (type(additions) is not list or type(deletions) is not list or not(additions or deletions)
            or len(additions)>MAX_CYCLIC_TASKS or len(deletions)>MAX_CYCLIC_TASKS):
        raise ProjectError('A task transaction needs bounded add_tasks/delete_task_ids arrays.')
    folder=store._folder(project_id)
    with store._lock(folder):
        folder,manifest,members,infos,comment=store._current(project_id)
        if manifest['current_sha256']!=expected_project_sha256:
            raise ProjectError('Stale project revision; read current tasks before editing.')
        _cold_project_snapshot(store,project_id,expected_project_sha256)
        member,_,_,tasks=_source(members)
        normalized=[]
        for addition in additions:
            required={'name','program_type','instance_name','interval_ns','watchdog_ns','priority'}
            if type(addition) is not dict or not required<=set(addition) or set(addition)-(required|{'esm_id'}):
                raise ProjectError('add_tasks items require name/program_type/instance_name/interval_ns/watchdog_ns/priority; esm_id is optional.')
            normalized.append({**addition,'esm_id':addition.get('esm_id',tasks[0].get('esmId')),
                               'id':str(uuid.uuid4()),'instance_id':str(uuid.uuid4())})
        before=members[member]
        after=_structure_bytes(before,normalized,deletions)
        final=dict(members)
        final[member]=after
        contract=make_task_ownership_contract(final,ownership_contract) if ownership_contract is not None else None
        schedule=validate_cyclic_schedule(final,ownership_contract=contract)
        if contract is None:
            manifest.pop('multitask_ownership_contract',None)
        else:
            manifest['multitask_ownership_contract']=contract
        result=_publish_revision(store,folder,manifest,members,final,infos,comment,
            {'operation':'change_cyclic_tasks','member':member,'add_tasks':normalized,
             'delete_task_ids':deletions,'before_sha256':sha(before),'after_sha256':sha(after),
             'ownership_contract':contract},'task_history')
        return {**result,'added_tasks':normalized,'deleted_task_ids':deletions,
                'task_count':schedule['task_count'],'program_instance_count':schedule['program_instance_count'],
                'source_isolation':schedule['source_isolation'],'existing_ids_preserved':True,
                'other_member_payloads_identical':True,'time_unit':'nanoseconds'}


def declare_task_ownership(store, project_id: str, expected_project_sha256: str,
                             ownership_contract: dict) -> dict:
    """Revalidate an explicit source/closure-bound ownership declaration after edits."""
    from .expanded_compile import _cold_project_snapshot
    folder=store._folder(project_id)
    with store._lock(folder):
        folder,manifest,members,infos,comment=store._current(project_id)
        if manifest['current_sha256']!=expected_project_sha256:
            raise ProjectError('Stale project revision; read current source before declaring ownership.')
        contract=make_task_ownership_contract(members,ownership_contract)
        _cold_project_snapshot(store,project_id,expected_project_sha256,ownership_contract_override=contract)
        schedule=validate_cyclic_schedule(members,ownership_contract=contract)
        manifest['multitask_ownership_contract']=contract
        member,_,_,_=_source(members)
        result=_publish_revision(store,folder,manifest,members,dict(members),infos,comment,
            {'operation':'declare_task_ownership','member':member,'before_sha256':sha(members[member]),
             'after_sha256':sha(members[member]),'ownership_contract':contract},'task_history')
        return {**result,'ownership_contract':contract,'source_isolation':schedule['source_isolation'],
                'source_member_payloads_identical':True,'controller_connected':False}


def clone_program(store, project_id: str, expected_project_sha256: str,
                    source_pou_name: str, new_pou_name: str,
                    code: str | None = None, variables: str | None = None) -> dict:
    """Create a distinct standard Program POU; never attach it to a task implicitly."""
    from .lifecycle import (PROJ,TYPES,LOGICAL,MSBUILD,_name,_new_metadata,
                            _project_folders,_child,_serialize,_content_types)
    from .expanded_compile import _cold_project_snapshot
    name=_name(new_pou_name)
    folder=store._folder(project_id)
    with store._lock(folder):
        folder,manifest,before,infos,comment=store._current(project_id)
        if manifest['current_sha256']!=expected_project_sha256:
            raise ProjectError('Stale project revision; read current project before cloning a Program.')
        _cold_project_snapshot(store,project_id,expected_project_sha256)
        index=pou_index(before)
        if source_pou_name not in index or index[source_pou_name]['kind']!='Program':
            raise ProjectError('clone_program requires an existing standard Program POU.')
        if name.casefold() in {existing.casefold() for existing in index}:
            raise ProjectError('New Program name must be distinct from existing POUs.')
        prefix=LOGICAL+name+'.pou/'
        final=dict(before)
        project=xml(before[PROJ])
        folders=_project_folders(project)
        parent_index=max((int(_child(node,'ParentIndex').text or '0') for _,node in folders.values()
                          if _child(node,'ParentIndex') is not None and (_child(node,'ParentIndex').text or '0').isdigit()),default=-1)+1
        metadata,identifiers=_new_metadata(name,kind='Program')
        final[prefix]=b''
        final[prefix+'Metadata.meta']=metadata
        source=index[source_pou_name]['prefix']
        final[prefix+'Code.st']=before[source+'Code.st'] if code is None else encode_worksheet(b'',code)
        final[prefix+'Variables.var']=before[source+'Variables.var'] if variables is None else encode_worksheet(b'',variables)
        group=ET.SubElement(project,'{'+MSBUILD+'}ItemGroup')
        node=ET.SubElement(group,'{'+MSBUILD+'}Folder',Include='Logical Elements\\'+name+'.pou')
        for tag,value in (('Id',identifiers['pou']),('FolderType','PouFolder'),('ParentIndex',str(parent_index))):
            ET.SubElement(node,'{'+MSBUILD+'}'+tag).text=value
        final[PROJ]=_serialize(project)
        _content_types(final)
        changes={path:{'before_sha256':sha(before[path]) if path in before else None,
                       'after_sha256':sha(final[path])} for path in final
                 if path not in before or before[path]!=final[path]}
        result=_publish_revision(store,folder,manifest,before,final,infos,comment,
            {'operation':'clone_program','source_pou_name':source_pou_name,
             'new_pou_name':name,'prefix':prefix,'identifiers':identifiers,
             'member_changes':changes},'program_history')
        return {**result,'new_program':name,'source_program':source_pou_name,'identifiers':identifiers,
                'attached_to_task':False,'existing_ids_preserved':True,'other_member_payloads_identical':True}


def program_permissions(manifest: dict, original: dict[str, bytes]) -> tuple[dict,set,set,list]:
    """Bound new Program payloads and editable worksheets to recorded clone events."""
    from .lifecycle import PROJ,TYPES,LOGICAL,_name
    expected,codes,variables,invalid={},set(),set(),[]
    known={name.casefold():item['kind'] for name,item in pou_index(original).items()}
    previous=0
    try:
        for event in manifest.get('program_history',[]):
            if (type(event) is not dict or event.get('operation')!='clone_program'
                    or type(event.get('revision')) is not int or not previous<event['revision']<=manifest['revision']
                    or known.get(event['source_pou_name'].casefold())!='Program'):
                raise ProjectError('Invalid Program clone history.')
            name=_name(event['new_pou_name'])
            prefix=LOGICAL+name+'.pou/'
            if event['prefix']!=prefix or name.casefold() in known:
                raise ProjectError('Invalid/repeated Program clone name or prefix.')
            identifiers=event['identifiers']
            if set(identifiers)!={'pou','variables','code'} or len({uuid.UUID(value) for value in identifiers.values()})!=3:
                raise ProjectError('Program clone identities are missing/repeated.')
            permitted={PROJ,TYPES,*{prefix+suffix for suffix in ('','Metadata.meta','Code.st','Variables.var')}}
            if not {PROJ,prefix,prefix+'Metadata.meta',prefix+'Code.st',prefix+'Variables.var'}<=set(event['member_changes']):
                raise ProjectError('Program clone history lacks members.')
            for path,change in event['member_changes'].items():
                digest=change['after_sha256']
                if path not in permitted or type(digest) is not str or re.fullmatch('[0-9a-f]{64}',digest) is None:
                    raise ProjectError('Invalid Program clone member scope/hash.')
                expected[path]=digest
            codes.add(prefix+'Code.st')
            variables.add(prefix+'Variables.var')
            known[name.casefold()]='Program'
            previous=event['revision']
    except (KeyError,TypeError,ValueError,AttributeError,ProjectError):
        invalid.append('invalid program clone history')
    return expected,codes,variables,invalid


def task_permissions(manifest: dict, original: dict[str, bytes]) -> tuple[dict, list]:
    """Replay authorized bounded attribute edits; never trust arbitrary ESM hashes."""
    history = manifest.get('task_history', [])
    if not isinstance(history, list):
        return {}, ['invalid task history']
    if not history:
        return {}, []
    expected, invalid = {}, []
    try:
        member, _, _, _ = _source(original)
        data = original[member]
        previous_revision = 0
        for event in history:
            if (not isinstance(event, dict) or event.get('operation') not in ('update_cyclic_task','change_cyclic_tasks','declare_task_ownership')
                    or event.get('member') != member
                    or type(event.get('revision')) is not int
                    or not previous_revision < event['revision'] <= manifest['revision']
                    or event.get('before_sha256') != sha(data)):
                raise ProjectError('Invalid task edit history.')
            if event['operation']=='update_cyclic_task':
                data = _patch(data, event['task_id'], event['updates'])
            elif event['operation']=='change_cyclic_tasks':
                data = _structure_bytes(data,event['add_tasks'],event['delete_task_ids'])
            if event.get('after_sha256') != sha(data):
                raise ProjectError('Task history replay hash mismatch.')
            previous_revision = event['revision']
        expected[member] = sha(data)
    except (KeyError, TypeError, ValueError, ProjectError):
        invalid.append('invalid task history')
    return expected, invalid
