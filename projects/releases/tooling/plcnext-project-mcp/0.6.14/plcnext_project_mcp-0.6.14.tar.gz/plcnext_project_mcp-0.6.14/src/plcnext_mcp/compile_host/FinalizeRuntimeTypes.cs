using System;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Collections.Generic;
using Ade.Reflection;
using Ade.Reflection.Cecil;
using Ade.Reflection.Eclr;

public sealed class FinalizeProviderMetadata : IAdeTypeManagerProviderMetadata {
    public string ProviderName { get { return "Cecil"; } }
    public bool IsDefault { get { return true; } }
}

// Reads the compiler's local native image as data. Never runs PLC application code.
public static class FinalizeRuntimeTypes {
    private static object[] ReadCil(string directory) {
        var result = new List<object>();
        foreach(var path in Directory.GetFiles(directory,"*.dll").Concat(Directory.GetFiles(directory,"*.exe"))) {
            using(var module=Mono.Cecil.ModuleDefinition.ReadModule(path)) {
                foreach(var type in module.Types) {
                    result.Add(new {assembly=Path.GetFileName(path),name=type.FullName,
                        fields=type.Fields.Select(f=>new {name=f.Name,type=f.FieldType.FullName,
                            is_static=f.IsStatic}).ToArray()});
                }
            }
        }
        return result.ToArray();
    }
    public static object Run(string imagePath, string outputDirectory) {
        var cecil = new CecilTypeManagerProvider {
            ExpressionProcessorFactory = new Lazy<IAdeExpressionProcessorFactory>(() => new DefaultExpressionProcessorFactory())
        };
        var factory = new AdeTypeManagerFactory {
            TypeManagerProviders = new[] {
                new Lazy<IAdeTypeManagerProvider,IAdeTypeManagerProviderMetadata>(()=>cecil,new FinalizeProviderMetadata())
            }
        };
        var nativeProvider = new EclrTypeManagerProvider();
        using(var image = File.OpenRead(imagePath)) {
            var native = nativeProvider.Create(image,null);
            var defaults = factory.Create(false,Array.Empty<string>());
            var assembly = Assembly.Load("Ade.Compiler.EclrImpl");
            var type = assembly.GetType("Ade.Internal.Compiler.Eclr.TypeInformationHelper",true);
            type.GetMethod("FinishTypeInformation",BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)
                .Invoke(null,new object[]{outputDirectory,native,defaults});
            return new {status="runtime_types_finalized", processor_type=native.ProcessorType,
                program_model=native.ProgramModel, code_size=native.CodeSize, metadata_size=native.MetadataSize,
                native_layout=native.GetAllTypes().Select(t=>new {name=t.FullName, size=t.ClassSize,
                    fields=t.Fields.Select(f=>new {name=f.Name,type=f.FieldType==null?null:f.FieldType.FullName,offset=f.Offset,
                        is_static=f.IsStatic}).ToArray()}).ToArray(),
                cil_layout=ReadCil(Path.GetDirectoryName(imagePath)),
                little_endian=native.IsLittleEndian, controller_connected=false, controller_downloaded=false,
                plc_program_executed=false};
        }
    }
}
