"""Offline download planning and service-contract simulation for generated copies.

The MCP entry point constructs an untagged or tagged binary loopback controller.
Both TLS endpoints are memory SSLObjects and there is no real PLC endpoint
parameter. The bounded v4 requests traverse that local binary/TLS channel.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import uuid

from .deployment_package import _inventory, _local_path, inspect_pcwe
from .deployment_plan import _file, _verify
from .download_services import FAULTS, FileSystemError, InMemoryController, ServiceFailure, WriteFileData
from .project import ProjectError, ProjectStore, sha
from .runtime_configuration import generate_runtime_configuration, validate_runtime_configuration
from .runtime_layout import validate_runtime_layout

BATCH_LIMIT = 8 * 1024 * 1024
POLL_INTERVAL_MS = 100
POLL_TIMEOUT_MS = 300000
PROTOCOL_PROFILES = ('v4_untagged', 'v4_tagged')


def file_batches(files: dict[str, bytes]):
    """Observed writer: append an entire file, then flush if size exceeds 8 MiB."""
    batch, size = [], 0
    for name, data in sorted(files.items()):
        batch.append((name, data))
        size += len(data)
        if size > BATCH_LIMIT:
            yield batch
            batch, size = [], 0
    if batch:
        yield batch


def execute_download(files: dict[str, bytes], controller: InMemoryController) -> dict:
    """Exercise the observed full-load sequence with additional fail-closed checks.

    Hash readback, preflight permissions/free space and refusing a running device
    are deliberate application policies. They are not attributed to WriteMany or
    to every vendor download branch. No automatic retry follows uncertain writes.
    """
    state = 'created'
    result = {'status': 'running', 'mode': 'in_memory_service_contract_simulation',
        'real_controller_connected': False, 'real_controller_downloaded': False,
        'controller_connected': False, 'controller_downloaded': False,
        'network_operations_performed': 0, 'tls_handshake_performed': False,
        'wire_transport_used': False, 'vendor_online_services_executed': False,
        'simulated_configuration_loaded': False, 'program_started': False,
        'deployable': False, 'fault': controller.fault}
    before = controller.snapshot()
    try:
        if not files:
            raise ServiceFailure('empty_package', 'An offline package is required.')
        controller.check_peer_policy()
        state = 'authenticating'
        username, password = controller.credentials()
        error, token, penalty = controller.create_session(username, password)
        password = None
        if int(error) != 0 or token is None:
            result['authentication_error'] = int(error)
            result['penalty_timeout'] = penalty
            raise ServiceFailure('authentication_failed', 'Offline password service rejected the session.')
        controller.enable_security(token)
        token = None
        state = 'preflight'
        permissions = controller.get_permissions()
        if not all(permissions.get(k) is True for k in ('write_files', 'read_files', 'load_configuration')):
            raise ServiceFailure('permission_denied', 'Offline operation permissions are insufficient.')
        current, error = controller.get_state()
        if error != 0 or current != 7:
            raise ServiceFailure('initial_state_not_stopped', 'This offline full-load profile requires initial Stop state.')
        status, root = controller.resolve_project_root()
        if status != FileSystemError.NONE or root != controller.root:
            raise ServiceFailure('path_resolution_failed', 'Simulated filesystem root could not be resolved.')
        if controller.get_space() < sum(map(len, files.values())):
            raise ServiceFailure('insufficient_space', 'Insufficient simulated storage space.')
        state = 'transferring'
        batches = list(file_batches(files))
        for batch in batches:
            entries = [WriteFileData(root + '/' + name, data) for name, data in batch]
            errors = controller.write_many(entries)
            if len(errors) != len(entries) or any(code != FileSystemError.NONE for code in errors):
                raise ServiceFailure('file_write_failed', 'Offline WriteMany returned a missing/failed per-file result.')
        state = 'verifying'
        for batch in batches:
            response = controller.read_many([root + '/' + name for name, _ in batch])
            if len(response) != len(batch):
                raise ServiceFailure('readback_failed', 'Offline readback returned an incomplete response.')
            for (name, expected), (status, data) in zip(batch, response):
                if status != FileSystemError.NONE or len(data) != len(expected) or hashlib.sha512(data).digest() != hashlib.sha512(expected).digest():
                    raise ServiceFailure('readback_failed', 'Offline readback mismatch: ' + name)
        removed = controller.reconcile(files)
        if controller.snapshot() != files:
            raise ServiceFailure('remote_inventory_mismatch', 'Simulated project file set is not exact.')

        def wait_until(predicate):
            elapsed = 0
            while True:
                device_state, device_error = controller.get_state()
                if device_error not in (0, 2):
                    raise ServiceFailure('controller_state_error', 'Offline configuration operation reported a device error.')
                if device_state not in (0, 3, 5, 7):
                    raise ServiceFailure('controller_state_unknown', 'Offline configuration state is unavailable.')
                # Vendor WaitForDesiredState checks elapsed > timeout, waits
                # 100ms, then evaluates the already-read state's predicate.
                if elapsed > POLL_TIMEOUT_MS:
                    raise ServiceFailure('configuration_timeout', 'Offline configuration state wait timed out.')
                controller.advance(POLL_INTERVAL_MS)
                elapsed += POLL_INTERVAL_MS
                if predicate(device_state):
                    return device_state

        state = 'resetting'
        controller.reset(async_=True)
        wait_until(lambda value: value == 0)
        state = 'loading'
        controller.load(async_=True)
        final_state = wait_until(lambda value: value > 0)
        controller.loaded = True
        state = 'loaded_stopped'
        result.update(status='simulation_passed', simulated_configuration_loaded=True,
            files_verified=len(files), bytes_verified=sum(map(len, files.values())),
            batch_count=len(batches), final_device_state=final_state,
            stale_simulated_files_removed=removed, readback_hash='SHA-512')
    except ServiceFailure as exc:
        result.update(status='simulation_failed', failure_code=exc.code, error=str(exc))
    except Exception as exc:
        # Preserve a diagnostic receipt for unexpected codec/TLS failures. Do
        # not echo arbitrary exception text that could contain credential data.
        result.update(status='simulation_failed', failure_code='unexpected_simulation_error',
                      error='Offline simulation failed: ' + type(exc).__name__,
                      error_class=type(exc).__name__)
    finally:
        result['operation_completed'] = result['status'] == 'simulation_passed'
        try:
            controller.close()
            result['cleanup_failed'] = False
        except Exception as exc:
            result.update(cleanup_failed=True, cleanup_error_class=type(exc).__name__)
            if result['status'] == 'simulation_passed':
                # Keep the loaded flag: failure to close a session does not
                # undo a configuration load that already completed.
                result.update(status='simulation_failed', failure_code='session_cleanup_failed',
                              error='Offline session cleanup did not complete.')
        snapshot = controller.snapshot()
        result.update(last_stage=state, simulated_files_changed=snapshot != before,
            simulated_file_count=len(snapshot), simulated_bytes=sum(map(len, snapshot.values())),
            simulated_writes_possible=snapshot != before,
            simulated_session_disposed=controller.session_closed,
            virtual_elapsed_ms=controller.virtual_elapsed_ms,
            tls_handshake_performed=bool(controller.tls_report.get('real_tls_handshake_executed')),
            memory_tls=controller.tls_report, rsc_header_roundtrips=controller.header_roundtrips,
            write_value_codec_roundtrips=controller.file_value_roundtrips,
            binary_rpc_loopback_used=bool(getattr(controller, 'rpc_exchanges', 0)),
            rpc_exchange_attempts=getattr(controller, 'rpc_exchanges', 0),
            rpc_exchanges_completed=getattr(controller, 'rpc_completed', 0),
            rpc_close_session_confirmed=getattr(controller, 'rpc_cleanup_confirmed', False),
            no_automatic_retries=True)
    return result


def _read_json(path):
    if not path.is_file() or path.stat().st_size > 16 * 1024 * 1024:
        raise ProjectError('Missing or oversized package receipt: ' + str(path))
    return json.loads(path.read_bytes())


def _package_snapshot(store, project_id, expected_project_sha256, package_job_id):
    if not isinstance(package_job_id, str) or re.fullmatch('[0-9a-f]{32}', package_job_id) is None:
        raise ProjectError('Invalid package_job_id; use project_generate_pcwe output.')
    folder, manifest, members, _, _ = store._current(project_id)
    if manifest['current_sha256'] != expected_project_sha256:
        raise ProjectError('Stale project hash; inspect the current copy again.')
    job = _file(folder, 'deployments/' + package_job_id)
    _local_path(job)
    receipt_bytes = (job / 'result.json').read_bytes()
    receipt = _read_json(job / 'result.json')
    if any(receipt.get(k) != v for k, v in {
        'project_id': project_id, 'project_sha256': expected_project_sha256,
        'package_job_id': package_job_id, 'status': 'pcwe_generated_offline',
        'package_complete': True, 'runtime_binding_validation_passed': True,
        'scope': 'NativeGateway_AXCF2152_2026_verified_hardware_and_HMI_profile'}.items()):
        raise ProjectError('A successful current-source NativeGateway PCWE receipt is required.')
    pcwe = _file(job, 'PCWE')
    if Path(receipt['pcwe_path']).resolve() != pcwe.resolve():
        raise ProjectError('Package receipt points outside its managed PCWE directory.')
    inspected = inspect_pcwe(pcwe)
    if inspected['inventory_sha256'] != receipt['inventory_sha256'] or inspected['overall_hash_status'] != 'verified':
        raise ProjectError('PCWE inventory differs from its generation receipt.')
    runtime_files, runtime_report = generate_runtime_configuration(members, ownership_contract=manifest.get('multitask_ownership_contract'))
    if not validate_runtime_configuration({p: (pcwe / p).read_bytes() for p in runtime_files}, runtime_report)['passed']:
        raise ProjectError('PCWE runtime configuration differs from the current copy.')
    finalized = receipt['type_layout_receipt']
    type_path = _verify(job, 'runtime-layout/TypeInformation.json', finalized['type_information_sha256'])
    native_path = _verify(job, 'runtime-layout/runtime-types-report.json', finalized['report_sha256'])
    build_id = receipt.get('build_job_id')
    if not isinstance(build_id, str) or re.fullmatch('[0-9a-f]{32}', build_id) is None:
        raise ProjectError('Invalid bound build job identity.')
    build_report = _verify(folder, 'builds/' + build_id + '/result.json', receipt['build_receipt_sha256'])
    build = _read_json(build_report)
    if any(build.get(k) != v for k, v in {'project_id': project_id, 'project_sha256': expected_project_sha256,
                                       'job_id': build_id, 'compiled': True, 'build_mode': 'cold'}.items()):
        raise ProjectError('PCWE build receipt has a different source identity.')
    bindings = validate_runtime_layout(members, runtime_report, _read_json(type_path),
                                       _read_json(native_path), build['resource_name'])
    files = {}
    for record in inspected['files']:
        data = (pcwe / record['path']).read_bytes()
        if len(data) != record['bytes'] or hashlib.sha512(data).hexdigest() != record['sha512']:
            raise ProjectError('PCWE changed while taking the simulation snapshot.')
        files[record['path']] = data
    if sha(files['Plc/Eclr/eCLR.img']) != build.get('image_sha256'):
        raise ProjectError('PCWE image differs from the bound cold-build image.')
    if sha((job / 'result.json').read_bytes()) != sha(receipt_bytes):
        raise ProjectError('Package receipt changed during simulation planning.')
    return folder, manifest, job, receipt_bytes, receipt, inspected, bindings, files


def download_plan(store: ProjectStore, project_id: str, expected_project_sha256: str, package_job_id: str):
    folder = store._folder(project_id)
    with store._lock(folder):
        _, manifest, job, raw, receipt, inventory, bindings, files = _package_snapshot(
            store, project_id, expected_project_sha256, package_job_id)
        return store._identity(folder, manifest) | {
            'status': 'offline_download_simulation_ready', 'package_job_id': package_job_id,
            'package_receipt_sha256': sha(raw), 'inventory_sha256': inventory['inventory_sha256'],
            'file_count': len(files), 'total_bytes': sum(map(len, files.values())),
            'batches': [{'file_count': len(b), 'bytes': sum(len(d) for _, d in b)} for b in file_batches(files)],
            'variable_count': bindings['variable_count'], 'fb_instance_count': bindings['fb_instance_count'],
            'hmi_mapping_count': bindings['hmi_mapping_count'],
            'simulation_tool': 'project_simulate_download', 'available_faults': list(FAULTS),
            'controller_connected': False, 'controller_downloaded': False, 'real_transport_available': False,
            'wire_compatibility_verified': False, 'tls_handshake_verified': False, 'deployable': False,
            'offline_memory_tls_probe': 'TLS1.2 MemoryBIO; public test CA/hostname; not real PLC verification',
            'rsc_fixed_header_codec_verified': True, 'rsc_write_value_codec_verified': True,
            'complete_rsc_rpc_codec': False,
            'bounded_binary_rpc_loopback': True,
            'binary_rpc_profile': 'v4, untagged, no datagram; known schema per exchange',
            'available_protocol_profiles': list(PROTOCOL_PROFILES),
            'tagged_value_codec_verified': True,
            'tagged_stream_reader': 'Schema-delimited, bounded; fragmented values and next-frame preservation verified offline',
            'authentication_contract': 'IPasswordAuthenticationService.CreateSession; UInt32 security token',
            'authentication_error_namespace': 'Arp.System.Security.Services.AuthenticationError (not Ade UI translations)',
            'symbolic_project_root': '$ARP_PROJECTS_DIR$/PCWE/',
            'file_transfer_contract': 'IFileService2.WriteMany / ReadMany; whole-file batches flush after >8MiB',
            'configuration_contract': 'Reset(true), poll DeviceState==0, Load(true), poll DeviceState>0; no Start',
            'policies': ['Initial Stop required.', 'Permissions/free-space preflight are simulator application policies.',
                         'Readback hashes must match before Reset/Load.', 'No automatic retry after uncertain writes.'],
            'remaining_wire_work': ['Read-only pinned PLC TLS is verified separately; file/control authorization and real write transport remain unverified',
                                    'Other profiles, error-return schemas, datagrams and general service coverage',
                                    'Real transfer, old-file reconciliation, controller acceptance and recovery']}


def simulate_download(store: ProjectStore, project_id: str, expected_project_sha256: str,
                      package_job_id: str, fault: str = 'none',
                      protocol_profile: str = 'v4_untagged'):
    if fault not in FAULTS:
        raise ProjectError('Unsupported offline fault scenario.')
    if protocol_profile not in PROTOCOL_PROFILES:
        raise ProjectError('Unsupported offline RSC protocol profile.')
    folder = store._folder(project_id)
    with store._lock(folder):
        _, manifest, package, raw, receipt, inventory, bindings, files = _package_snapshot(
            store, project_id, expected_project_sha256, package_job_id)
        parent = _file(folder, 'download-simulations')
        parent.mkdir(exist_ok=True)
        output = parent / uuid.uuid4().hex
        output.mkdir()
        if protocol_profile == 'v4_tagged':
            from .binary_download_tagged import TaggedBinaryLoopbackController
            controller = TaggedBinaryLoopbackController(fault)
        else:
            from .binary_download import BinaryLoopbackController
            controller = BinaryLoopbackController(fault)
        result = execute_download(files, controller)
        # Recheck source and the package after the local service exercise.
        if store._current(project_id)[1]['current_sha256'] != expected_project_sha256:
            raise ProjectError('Managed copy changed during offline simulation.')
        if (package / 'result.json').read_bytes() != raw or _inventory(package / 'PCWE') != inventory['files']:
            raise ProjectError('Package changed during offline simulation.')
        result.update(store._identity(folder, manifest), simulation_id=output.name,
            job_directory=str(output), package_job_id=package_job_id,
            inventory_sha256=inventory['inventory_sha256'], package_receipt_sha256=sha(raw),
            source_and_package_unchanged=True, runtime_binding_validation_passed=True,
            variable_count=bindings['variable_count'], fb_instance_count=bindings['fb_instance_count'],
            hmi_mapping_count=bindings['hmi_mapping_count'],
            protocol_profile=protocol_profile,
            tagged_invocations=getattr(controller, 'tagged_invocations', 0),
            tagged_discoveries=getattr(controller, 'tagged_discoveries', 0),
            limitations=['TLS is MemoryBIO with public test certificates; no real device connection.',
                         'Binary RPC is bounded to the selected v4 tagged/untagged no-datagram known schemas; it is not a general RSC transport.',
                         'Operation permissions and old-file reconciliation remain explicit local simulator policies.',
                         'Simulation does not validate real device authorization, limits, signatures, or execution.'])
        # Persist only non-secret diagnostics. Actual transfer bytes stay in memory.
        (output / 'trace.json').write_text(json.dumps(controller.trace, indent=2) + '\n', encoding='utf-8')
        (output / 'simulated-inventory.json').write_text(json.dumps([
            {'path': p, 'bytes': len(d), 'sha512': hashlib.sha512(d).hexdigest()}
            for p, d in sorted(controller.snapshot().items())], indent=2) + '\n', encoding='utf-8')
        result['trace_path'] = str(output / 'trace.json')
        (output / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return result
