"""MCP stdio entry point. stdout is reserved for MCP protocol traffic."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Literal
from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from .project import ProjectStore, ProjectError
from .headless import check_st, parser_environment
from .cached_compile import cached_compile_environment, compile_cached_ng_readack
from .expanded_compile import expanded_compile_environment, cold_compile_environment, compile_nativegateway
from .deployment_plan import deployment_plan
from .deployment_package import inspect_pcwe, stage_pcwe
from .pcwe_build import build_pcwe
from .download_simulation import download_plan, simulate_download
from .controller_transport import read_controller_state
from .aci_parity import aci_replacement_coverage, aci_replacement_summary
from .task_configuration import inspect_task_configuration, update_cyclic_task
from .controller_download_plan import prepare_download_review, load_download_review, revalidate_download_review
from .controller_transfer import execute_reviewed_download, test_controller_download_client
from .controller_preflight import preflight_download_review
from . import __version__

mcp = FastMCP('PLCnext Project MCP', instructions=(
    'Independent PCWEX engineering. No ACI/CodeMeter calls or computer use. '
    'Real actions use expiring one-use authorization, which MCP can issue with project_authorize_controller_operation, '
    'for the exact download, control or whole recovery review hash and action set. '
    'A download receipt cannot authorize Stop/Start. A review never grants permission. '
    'Project editing/build/package tools are offline; controller_read_state is a separate, explicitly '
    'certificate-pinned read-only TLS/RSC probe. It sends only Connect, fixed PLC '
    'service discovery and GetPlcState. '
    'Import a project copy, read a POU, then use both returned hashes for an exact ST patch. '
    'Validation proves member-payload preservation, not IEC compilation. '
    'project_check_st checks syntax only. Atomically update code/interfaces/callers using '
    'project_update_pous. Use project_create for a new offline project and '
    'project_change_fbs to add/remove ST FBs with coordinated caller updates. '
    'Prefer project_compile: supported project POU bodies/interfaces, types, libraries '
    'and cyclic-task IEC models are reconstructed without a project AST seed. '
    'project_inspect_tasks reads ESM task/program bindings; project_update_cyclic_task '
    'changes only supported existing cyclic-task timings and priority on a new revision. '
    'aci_replacement_status and aci_replacement_methods report actual independent '
    'coverage and gaps; this server is not a complete ACI replacement. '
    'Support is checked from the project device and source features; '
    'Use project_generate_pcwe after a fresh cold build for the validated NativeGateway '
    'hardware/HMI profile. It creates a complete offline PCWE candidate with runtime '
    'mapping checks; controller execution and acceptance remain unverified. '
    'project_deployment_plan checks the exact cold-build revision for deployment gaps. '
    'deployment_inspect_pcwe and deployment_stage_pcwe inspect/copy an existing complete '
    'local PCWE directory; neither creates a cold deployment nor writes to a controller. '
    'project_download_plan and project_simulate_download validate the current generated '
    'package and exercise password sessions, WriteMany/readback and Reset/Load against '
    'an in-memory controller double only; they accept no controller endpoint. '
    'project_simulate_download supports protocol_profile=v4_tagged for the '
    'data-tagging profile observed on the authorized device, or v4_untagged for '
    'the earlier baseline. Both transfer only in memory. '
    'project_test_controller_download exercises the actual TCP/TLS client against '
    'an owned loopback-only file/controller fixture, with no external endpoint input. '
    'project_execute_controller_download refuses before any socket unless a separate '
    'human or MCP-managed authorization matches every reviewed byte/target/effect; it never automatically '
    'stops/starts the PLC, deletes files or retries uncertain mutations. '
    'project_preflight_controller_download is anonymous and read-only: state, PCWE '
    'root/space and two fixed metadata files by default; explicit verify_package_files '
    'reads only immutable review-listed paths with a total byte bound, never arbitrary files. '
    'Runtime read plans admit exact source/type-bound variables with bounded '
    'windows, never arbitrary memory/Force. Separate operator control and recovery '
    'plans can explicitly Stop/Start with one-use human or MCP-managed authorization. '
    'Recovery keeps a continuous endpoint lease and verifies its own Load before '
    'Start; no failure triggers an automatic restore. MCP can decide and authorize '
    'the exact operation using project_authorize_controller_operation without a human terminal. '
    'project_compile_cached is the legacy one-FB seed-based experiment.'))
_store = None


def store() -> ProjectStore:
    global _store
    if _store is None:
        _store = ProjectStore(Path(os.environ.get('PLCNEXT_MCP_WORKSPACE', Path.home() / 'PLCnext-MCP-Workspace')))
    return _store


READ = ToolAnnotations(readOnlyHint=True, openWorldHint=False)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=False)
CONTROLLER_READ = ToolAnnotations(readOnlyHint=True, openWorldHint=True)
CONTROLLER_WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=True, openWorldHint=True)


@mcp.tool(annotations=READ)
def project_release_inventory(target: Literal['AXCF2152', 'AXCF1252'] | None = None) -> dict:
    """List immutable per-hardware releases and every download/recovery attempt.

    Pending/interrupted attempts stay unknown. Build/load receipts never imply a
    verified currently running device version. No network or controller action.
    """
    from .releases import inventory
    return inventory(store(), target)


@mcp.tool(annotations=WRITE)
def project_release_prepare_dev(project_id: str, expected_project_sha256: str,
                                base_version: str, change_note: str, build_number: int = 0) -> dict:
    """Freeze a new dev release, stamp heartbeat version and import a build copy.

    base_version is X.Y.Z. Full input SHA generates a unique dev suffix. Compile
    the returned managed_project, then register its PCWE with release_bind_package.
    Increment build_number for a toolchain-only rebuild with unchanged sources.
    No PLC access. Existing versions/archives are never overwritten.
    """
    from .releases import prepare_dev
    return prepare_dev(store(), project_id, expected_project_sha256, base_version, change_note, build_number)


@mcp.tool(annotations=WRITE)
def project_release_archive_historical(source_path: str, expected_project_sha256: str,
                                       provenance_note: str) -> dict:
    """Copy an exact historical project into its hardware release directory.

    Does not invent a download receipt or prove the current device version.
    Existing version with different bytes is refused; use a dev release instead.
    """
    from .releases import archive_historical
    return archive_historical(store(), source_path, expected_project_sha256, provenance_note)


@mcp.tool(annotations=WRITE)
def project_release_bind_package(project_id: str, expected_project_sha256: str,
                                 package_job_id: str) -> dict:
    """Freeze exact cold-build PCWE bytes and receipts against a registered release.

    Required before every real download/recovery. Hardware/IP, source, inventory
    and frozen package hashes are rechecked before any Stop/write operation.
    A second different package cannot reuse this version. No controller access.
    """
    from .releases import bind_package
    return bind_package(store(), project_id, expected_project_sha256, package_job_id)


@mcp.tool(annotations=READ)
def server_capabilities() -> dict:
    """Report the actual backend and limits; never infer compile success from validation."""
    from .fault_supervision import fault_supervision_capabilities
    from .runtime_evidence import runtime_evidence_capabilities
    return {'backend': 'native_pcwex', 'version': __version__,
            'release_management': {'available': True, 'hardware': ['AXCF2152', 'AXCF1252'],
                'new_source_channel': 'dev', 'real_download_and_recovery_guarded': True,
                'tool': 'project_release_inventory', 'no_implicit_device_version_claim': True},
            'aci_dependency': False, 'vendor_license_modification': False,
            'full_aci_replacement': False,
            'synchronous_observation_reconciliation': {'available':True,'tool':'project_prepare_sync_observation_reconciliation',
                'proven_noop_stop_supported':True,'controller_mutations':False},
            'stopped_zero_transfer_recovery': {'available': True,
                'prepare_tool': 'project_prepare_stopped_recovery','inspect_tool':'project_inspect_stopped_recovery',
                'execute_tool':'project_execute_recovery','authorization_kind':'recovery',
                'lease_handoff':'atomic_owner_replace_without_unlocked_gap','real_restoration_verified':False},
            'strict_recovery_preflight': {'available':True,'tool':'project_preflight_recovery_download',
                'before_stop':True,'rechecked_after_stop':True,'same_transfer_path_and_native_library_policy':True},
            'device_reboot': {'available': True, 'prepare_tool': 'project_prepare_reboot',
                'execute_tool': 'project_execute_reboot', 'status_tool': 'project_reboot_status',
                'cancel_tool': 'project_cancel_reboot_wait', 'authorization_kind': 'reboot',
                'automatic_resend': False, 'automatic_start': False,
                'confirmation': 'new application BootId and two Running/configuration/GOOD observations',
                'os_boot_id_attested': False, 'real_hardware_verified': False},
            'verification_levels': {'implemented': 'code exists within the stated profile',
                'offline_verified': 'local contracts/negative tests passed',
                'loopback_verified': 'owned local peer/build tested, not real PLC acceptance',
                'real_verified': 'requires exact separately recorded target test evidence'},
            'joint_gap_mapping': {
                'M01': ['project_inspect_operator_approval', 'project_authorize_controller_operation', 'optional interactive operator CLI'],
                'M02': ['project_prepare_controller_control', 'project_execute_controller_control', 'project_test_controller_control'],
                'M03': ['project_prepare_runtime_read', 'project_read_runtime', 'project_preflight_controller_download'],
                'M04': ['project_inspect_runtime_symbols', 'project_prepare_runtime_read', 'project_read_runtime', 'project_test_runtime_read'],
                'M05': ['project_generate_pcwe', 'project_preflight_controller_download', 'project_test_controller_download'],
                'M06': ['project_prepare_recovery', 'project_inspect_recovery', 'project_execute_recovery',
                    'project_test_recovery', 'project_start_recovery_job',
                    'project_controller_operation_status', 'project_cancel_controller_operation'],
                'M07': ['project_prepare_fault_control', 'project_execute_fault_control', 'project_test_fault_supervision',
                    'project_create_fault_profile', 'project_prepare_instrumented_fault',
                    'project_execute_instrumented_fault', 'project_test_instrumented_fault',
                    'project_start_instrumented_fault_job'],
                'M08': ['project_runtime_timing_evidence', 'project_prepare_esm_read', 'project_read_esm', 'project_test_esm_read'],
                'M09': ['server_capabilities', 'aci_replacement_status'],
                'M10': ['project_clone_program', 'project_change_cyclic_tasks', 'project_declare_task_ownership']},
            'aci_replacement_coverage_tools': ['aci_replacement_status', 'aci_replacement_methods'],
            'task_configuration': {'inspect': True, 'update_existing_cyclic_task': True,
                'scope': 'AXCF2152/2026 single eCLR, 1..16 independently owned cyclic tasks; source copies only',
                'create_delete_tasks': True, 'clone_standard_program': True,
                'mutable_cross_task_handoff_supported': False,
                'source_bound_ownership_contract': True, 'runtime_effect_verified': False},
            'read_pous': True, 'edit_existing_st_body': True, 'preserve_other_member_payloads': True,
            'change_pou_interface': True, 'create_project': True, 'add_delete_st_function_blocks': True,
            'pou_interface_scope': 'Existing variable worksheets: locals, input/output/in-out declarations; no kind/return metadata edits.',
            'headless_compile': True, 'full_project_headless_compile': False,
            'headless_compile_scope': 'Supported single-resource AXC F 2152 standard-ST IEC builds with bounded independently owned cyclic tasks; separate PCWE generation supports the validated NativeGateway hardware/HMI profile only.',
            'cold_compile': cold_compile_environment(),
            'controller_access': True, 'controller_write_access': True,
            'controller_write_requires_exact_authorization': True,
            'operator_approval': {'implemented': True,
                'issuer': 'project_authorize_controller_operation',
                'issuer_is_mcp_tool': True, 'interactive_terminal_required': False,
                'mcp_can_authorize': True, 'human_approval_required': False,
                'optional_terminal_issuer': 'python -I -m plcnext_mcp.operator_approval',
                'receipt_kinds': ['download', 'control', 'recovery', 'instrumented_fault'],
                'offline_verified': True, 'physical_human_terminal_verified': False,
                'trust_boundary': 'local trusted issuer; same-user filesystem access is not cryptographic human authentication'},
            'runtime_monitor': {'implemented': True, 'prepare_tool': 'project_prepare_runtime_read',
                'read_tool': 'project_read_runtime', 'test_tool': 'project_test_runtime_read',
                'source_type_allowlist': True, 'write_or_force': False,
                'maximum_symbols': 2048, 'maximum_chunk_symbols': 64,
                'atomic_snapshot': False, 'identity_guards': True,
                'loaded_module_hash_attestation': False,
                'offline_verified': True, 'loopback_verified': True, 'real_verified': False},
            'controller_control': {'implemented': True,
                'prepare_tool': 'project_prepare_controller_control',
                'execute_tool': 'project_execute_controller_control',
                'test_tool': 'project_test_controller_control',
                'actions': ['stop', 'start'], 'start_kinds': ['cold', 'warm', 'hot', 'restore_warm'],
                'separate_operator_receipt_required': False, 'mcp_authorization_supported': True, 'ack_is_completion': False,
                'standalone_start_loaded_identity_available': False,
                'recovery_plan_start_uses_verified_load_causality': True,
                'offline_verified': True, 'loopback_verified': True, 'real_verified': False},
            'recovery': {'implemented': True, 'prepare_tool': 'project_prepare_recovery',
                'execute_tool': 'project_execute_recovery', 'continuous_endpoint_lease': True,
                'automatic_rollback': False, 'automatic_retry': False,
                'unknown_ram_loss_requires_explicit_review': True,
                'external_data_stored_mock_acceptance': 'joint_verifier',
                'offline_verified': True, 'loopback_verified': True, 'real_verified': False,
                'asynchronous_operation_jobs': True,
                'persistent_cancel_request': True, 'cancel_is_rollback': False},
            'fault_supervision': fault_supervision_capabilities(),
            'runtime_timing_evidence': runtime_evidence_capabilities(),
            'esm_monitor': {'implemented': True, 'backend': 'existing_source_ESM_DATA_DataAccess',
                'prepare_tool': 'project_prepare_esm_read', 'read_tool': 'project_read_esm',
                'test_tool': 'project_test_esm_read', 'source_template_types_required': True,
                'threshold_counter_wire_type': 'uint32', 'time_unit': 'microseconds',
                'new_instrumentation_required': False, 'arbitrary_memory_access': False,
                'elapsed_duration_includes_preemption': True, 'p06_test_started': False,
                'offline_verified': True, 'loopback_verified': True, 'real_verified': False},
            'instrumented_fault_profile': {'implemented': True,
                'create_tool': 'project_create_fault_profile',
                'prepare_tool': 'project_prepare_instrumented_fault',
                'execute_tool': 'project_execute_instrumented_fault',
                'test_tool': 'project_test_instrumented_fault',
                'unchanged_restore_archive_supported': False,
                'separate_instrumented_source_required': True,
                'separate_operator_approval_required': False, 'mcp_authorization_supported': True, 'arbitrary_variable_write': False,
                'shared_hub_broker_mock_control': False, 'real_verified': False,
                'profile_clock_and_expiry_contract_must_match': True},
            'audit_export': {'available': True, 'prepare_tool': 'project_prepare_audit_export',
                'inspect_tool': 'project_inspect_audit_export', 'execute_tool': 'project_execute_audit_export',
                'status_tool': 'project_audit_export_status', 'cancel_tool': 'project_cancel_audit_export',
                'authorization_kind': 'audit_export', 'fixed_ack_fields_only': True,
                'fact_modes':['legacy_v1','decision_clock_slots_v2'],'v2_symbol_count':20148,
                'independent_slot_proof_by_exporter':False,
                'capture_capacity':512,'association_capacity':32,'real_controller_verified':False,
                'physical_50_events_per_second_verified':False,'original_32_pou_supported':False,
                'recovery_start_integration':True,'prepare_parent_tool':'project_prepare_recovery',
                'parent_option':'audit_duration_seconds','post_start_full_package_read':False,
                'parent_failure_reconciliation_tool':'project_prepare_parent_audit_reconciliation'},
            'endpoint_lease_reconciliation': {'available': True,
                'prepare_tool': 'project_prepare_lease_reconciliation',
                'inspect_tool': 'project_inspect_lease_reconciliation',
                'execute_tool': 'project_execute_lease_reconciliation',
                'authorization_kind': 'lease_reconciliation',
                'sync_prepare_tool': 'project_prepare_sync_lease_reconciliation',
                'scope': 'terminal asynchronous or synchronous recovery with known outcome and pending business verification; fresh Running/configuration/GOOD required',
                'unknown_writes_supported': False, 'controller_mutations': False},
            'controller_write_access_scope': 'MCP decides exact operation authorization; prepare, authorize, execute. No independent human issuer required.',
            'controller_download_client': {'implemented': True, 'backend': 'independent_pinned_tls_tcp_rsc',
                'review_tool': 'project_prepare_download_review',
                'readonly_preflight_tool': 'project_preflight_controller_download',
                'loopback_test_tool': 'project_test_controller_download',
                'guarded_execution_tool': 'project_execute_controller_download',
                'review_is_authorization': False, 'operator_approval_required': False, 'mcp_authorization_supported': True,
                'automatic_stop': False, 'automatic_start': False, 'automatic_retry': False,
                'remote_directory_listing': False, 'remote_old_file_deletion': False,
                'real_device_write_compatibility_verified': False,
                'real_device_file_transfer_verified': True,
                'real_device_sha512_readback_verified': True,
                'real_device_reset_load_start_verified': True,
                'real_device_file_evidence': {
                    'source_sha256': '7c0724cdbe18552956b5f111e2c9ae0feb2829f9d28cfa2fd449ffe8bac46154',
                    'inventory_sha256': 'c83ee20636924cfb29d9459127d77a88f4cbdbe444613a092f0bf373ec69a4cf',
                    'address': '192.168.0.8', 'files_verified': 49, 'bytes_verified': 9193238,
                    'report': 'artifacts/original-recovery-hardware/1273d52e0f9e45c99896aa935c359704/result.json',
                    'scope': 'this exact package only; prior changed-file transfer/readback, final identical-file readback, Reset/Load/Cold Start and Running verified; 250 points BAD_CONNECTION, business acceptance incomplete'}},
            'controller_readonly': {'available': True, 'tool': 'controller_read_state',
                'requires_explicit_certificate_sha256': True,
                'protocol_scope': 'RSC v4 tagged/no-datagram, Connect + fixed PLC service discovery + GetPlcState only',
                'credentials': False, 'file_access': False, 'program_control': False,
                'real_download': False},
            'deployment_preparation': {'exact_build_gap_analysis': True,
                'existing_pcwe_file_integrity_check': True, 'existing_pcwe_snapshot': True,
                'cold_pcwe_generation': True,
                'cold_pcwe_scope': 'Validated NativeGateway AXCF2152/2026 hardware, services and Gateway/Login HMI; rejects unverified profiles.',
                'signature_validation': False,
                'daum_zip_generation': False, 'controller_transport': False},
            'download_simulation': {'available': True, 'backend': 'in_memory_only',
                'authentication_service_contract': True, 'whole_file_transfer_and_readback': True,
                'configuration_reset_load': True, 'network_access': False,
                'memory_tls12_handshake_verified': True, 'fixed_header_codec_verified': True,
                'write_file_value_codec_verified': True,
                'bounded_binary_rpc_loopback': True,
                'available_protocol_profiles': ['v4_untagged', 'v4_tagged'],
                'tagged_value_codec_verified': True, 'tagged_binary_rpc_loopback': True,
                'tls_handshake_verified': False, 'real_controller_wire_compatibility_verified': False},
            'headless_st_syntax_check': parser_environment(),
            'cache_assisted_compile': cached_compile_environment(),
            'nativegateway_source_compile': expanded_compile_environment(),
            'nativegateway_cold_compile': cold_compile_environment(), 'workspace': str(store().root)}


@mcp.tool(annotations=CONTROLLER_READ)
def controller_read_state(address: str, expected_certificate_sha256: str,
                          port: int = 41100, timeout_seconds: int = 5) -> dict:
    """Read one PLC state over independent pinned TLS/RSC, without ACI or GUI.

    Sends only Connect, fixed IPlcManagerService discovery and GetPlcState(method 5).
    Requires a literal IP and explicitly supplied peer certificate SHA-256; no
    trust-on-first-use, credentials, file access, download or PLC control. Supports
    only the verified RSC v4 tagged/no-datagram response profile. Saves a local
    action report. A certificate mismatch sends no RSC request; no automatic retry.
    """
    return read_controller_state(store().root, address, expected_certificate_sha256,
                                 port, timeout_seconds)


@mcp.tool(annotations=READ)
def aci_replacement_status() -> dict:
    """Report evidence-backed independent ACI coverage, remaining gaps and priorities.

    Static API discovery, a partial substitute or official unimplemented property
    is never counted as full replacement. Does not execute ACI or use the network.
    """
    return aci_replacement_summary()


@mcp.tool(annotations=READ)
def aci_replacement_methods(domain: str | None = None, status: str | None = None,
                             offset: int = 0, limit: int = 40,
                             include_details: bool = False) -> dict:
    """Page all 201 declared ACI interface methods with substitutes and acceptance gaps.

    Use aci_replacement_status to discover domain/status filters. include_details
    adds evidence and acceptance criteria. A mapped tool has the bounded scope
    stated per member, not necessarily the full official API semantics.
    """
    return aci_replacement_coverage(domain, status, offset, limit, include_details)


@mcp.tool(annotations=READ)
def project_inspect_tasks(project_id: str) -> dict:
    """Read source ESM/task identities, timings and program-instance bindings.

    Timings use nanoseconds. Source values are not measured runtime execution or
    controller state. Does not invoke ACI, Engineer or a network connection.
    """
    return inspect_task_configuration(store(), project_id)


@mcp.tool(annotations=WRITE)
def project_update_cyclic_task(project_id: str, expected_project_sha256: str,
                               task_id: str, updates: dict) -> dict:
    """Change supported cyclic scheduling on a new offline project-copy revision.

    updates may contain interval_ns, watchdog_ns and/or priority. Requires the
    supported AXCF2152/2026 single-eCLR, 1..16 cyclic-task source profile, exact current project hash
    and existing task ID. Preserves all other ESM bytes and task/program-instance
    IDs; old builds become stale. Compile again to verify the new source. Does not
    create/delete tasks, connect to PLC or change the running program.
    """
    return update_cyclic_task(store(), project_id, expected_project_sha256, task_id, updates)


@mcp.tool(annotations=WRITE)
def project_prepare_download_review(project_id: str, expected_project_sha256: str,
                                    package_job_id: str, address: str,
                                    expected_certificate_sha256: str, port: int = 41100) -> dict:
    """Prepare an immutable version/target/impact review; never approve or contact PLCs.

    Binds the exact source revision, cold build, PCWE inventory and every file hash
    to the literal IP/port/certificate pin. Lists Stop requirement, overwrite,
    Reset/Load, possible interruption/autostart and lack of rollback/old-file
    deletion. Review IDs/hashes are selectors, not write permission. Requires
    separately recorded human confirmation before real execution.
    """
    return prepare_download_review(store(), project_id, expected_project_sha256,
                                   package_job_id, address, expected_certificate_sha256, port)


@mcp.tool(annotations=READ)
def project_inspect_download_review(project_id: str, review_id: str,
                                    expected_review_sha256: str,
                                    revalidate_package: bool = True) -> dict:
    """Inspect/revalidate exact reviewed source and package; never grant write access."""
    if revalidate_package:
        return revalidate_download_review(store(), project_id, review_id, expected_review_sha256)
    return load_download_review(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=CONTROLLER_READ)
def project_preflight_controller_download(project_id: str, review_id: str,
                                           expected_review_sha256: str,
                                           verify_package_files: bool = False,
                                           capture_package_files: bool = False,
                                           maximum_package_read_bytes: int = 33554432) -> dict:
    """Read live download context from the exact reviewed target; never authorize/write.

    Default reads only state, root/space and two fixed metadata files. Explicit
    verify_package_files additionally audits exact review-listed remote files by
    SHA-512 against their remote manifest, under a 1..64MiB total response budget;
    capture_package_files saves a new coherent disk snapshot only. No credentials,
    arbitrary paths, writes, Stop/Start/Reset/Load or deletion. Running is allowed.
    Disk bytes do not attest active memory, write permission or unlisted files.
    """
    if capture_package_files and not verify_package_files:
        raise ProjectError('Package capture requires explicit verify_package_files=true.')
    if verify_package_files and (type(maximum_package_read_bytes) is not int
            or not 1048576 <= maximum_package_read_bytes <= 67108864):
        raise ProjectError('Package read budget must be 1..64 MiB.')
    result = preflight_download_review(store(), project_id, review_id, expected_review_sha256)
    if verify_package_files and result.get('status') == 'preflight_read_completed':
        from .controller_package_read import read_reviewed_controller_package
        import json
        audit = read_reviewed_controller_package(store(), project_id, review_id,
            expected_review_sha256, capture_files=capture_package_files,
            maximum_bytes=maximum_package_read_bytes)
        result.update(metadata_preflight_report_path=result['report_path'],
            remote_package_audit=audit,
            metadata_preflight_status=result['status'],
            remote_file_contents_verified=audit['remote_file_contents_verified'])
        result['status'] = ('preflight_file_audit_completed' if audit['remote_file_contents_verified']
                            else 'preflight_file_audit_incomplete')
        combined = Path(audit['report_path']).with_name('preflight-with-package-audit.json')
        result['report_path'] = str(combined)
        with combined.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return result


@mcp.tool(annotations=WRITE)
def project_test_controller_download(project_id: str, expected_project_sha256: str,
                                      package_job_id: str,
                                      fault: Literal['none', 'write_reply_lost', 'readback_corrupt', 'write_error',
                                          'short_results', 'load_error', 'load_timeout', 'reset_timeout',
                                          'initial_running', 'tls_error', 'permission_denied', 'insufficient_space',
                                          'load_reply_lost', 'reset_reply_lost', 'rpc_error', 'fatal_error',
                                          'chunked_readback'] = 'none') -> dict:
    """Use the production socket client to transfer a copy to a local test peer.

    Starts only a 127.0.0.1 random-port TLS fixture, writes real files under a new
    owned workspace job, verifies SHA-512 readback and test Reset/Load/Stop state.
    Does not accept an external endpoint or use ACI, Engineer or MemoryBIO. No
    controller approval is issued; real-device success is never inferred.
    """
    return test_controller_download_client(store(), project_id, expected_project_sha256,
                                           package_job_id, fault)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_execute_controller_download(project_id: str, review_id: str,
                                         expected_review_sha256: str) -> dict:
    """Execute ONLY an exact review with a separate, one-use human approval receipt.

    This tool never creates that receipt. Without it, fails before opening a
    socket. Revalidates all local source/package/target bindings and the approval,
    pins the live TLS certificate, requires fresh Stop state and matching existing
    manifest paths, then writes/readbacks/resets/loads. No automatic Stop, Start,
    delete, rollback or retry; a lost mutation reply is outcome_unknown. Partial
    writes and firmware autostart remain material effects; first review with user.
    """
    return execute_reviewed_download(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=WRITE)
def project_import_copy(source_path: str) -> dict:
    """Copy a user-selected .pcwex into a managed workspace; never modify the source."""
    return store().import_copy(source_path)


@mcp.tool(annotations=WRITE)
def project_create(name: str, template_path: str | None = None) -> dict:
    """Create a separate offline .pcwex from an installed device template.

    Default: AXC F 2152 template with a fresh ST Main program. Returns a managed
    project_id and path; never creates a controller connection or downloads.
    """
    return store().create_project(name, template_path)


@mcp.tool(annotations=READ)
def project_inspect(project_id: str) -> dict:
    """List standard POUs, identities, worksheet IDs, current revision and mapping members."""
    return store().inspect(project_id)


@mcp.tool(annotations=READ)
def project_read_pou(project_id: str, pou_name: str) -> dict:
    """Read ST and variable declarations, plus exact code/project hashes required for patches."""
    return store().read_pou(project_id, pou_name)


@mcp.tool(annotations=READ)
def project_find_references(project_id: str, pou_name: str) -> dict:
    """Find bounded standard-ST instance declarations and call locations; not a compiler symbol table."""
    return store().references(project_id, pou_name)


@mcp.tool(annotations=WRITE)
def project_patch_st(project_id: str, pou_name: str, expected_project_sha256: str,
                     expected_code_sha256: str, old_text: str, new_text: str) -> dict:
    """Replace exactly one ST fragment, producing a new revision with every other payload unchanged.

    Both hashes must match the current revision. Does not change POU interfaces, variables,
    mappings, worksheet IDs or any vendor license, and does not compile or download.
    """
    return store().patch_st(project_id, pou_name, expected_project_sha256,
                            expected_code_sha256, old_text, new_text)


@mcp.tool(annotations=WRITE)
def project_update_pous(project_id: str, expected_project_sha256: str, updates: list[dict]) -> dict:
    """Atomically update existing POU code and variable interfaces in one new revision.

    Each item requires pou_name, expected_code_sha256, expected_variables_sha256 and
    optional full code/variables strings. Update FB interfaces and affected callers
    together. Preserves every metadata/ID/mapping member; compile to check syntax/types.
    """
    return store().update_pous(project_id, expected_project_sha256, updates)


@mcp.tool(annotations=WRITE)
def project_change_fbs(project_id: str, expected_project_sha256: str,
                       add_fbs: list[dict] | None = None, delete_fbs: list[str] | None = None,
                       updates: list[dict] | None = None) -> dict:
    """Atomically add/delete standard ST function blocks and update affected callers.

    add_fbs items contain pou_name and optional complete code/variables text.
    delete_fbs contains existing FB names; remaining references prevent deletion.
    updates uses project_update_pous items with both worksheet hashes. New FBs get
    fresh object/worksheet IDs; unrelated payloads and existing mapping IDs persist.
    This is an offline editing transaction; call project_compile afterwards.
    """
    return store().change_structure(project_id, expected_project_sha256, add_fbs, delete_fbs, updates)


@mcp.tool(annotations=WRITE)
def project_add_fb(project_id: str, expected_project_sha256: str, pou_name: str,
                   code: str = '', variables: str = 'VAR\nEND_VAR\n') -> dict:
    """Add one standard ST FB with fresh metadata/worksheet IDs to a new revision."""
    return store().change_structure(project_id, expected_project_sha256,
                                    add_fbs=[{'pou_name': pou_name, 'code': code, 'variables': variables}])


@mcp.tool(annotations=WRITE)
def project_delete_fb(project_id: str, expected_project_sha256: str, pou_name: str) -> dict:
    """Delete an unreferenced ST FB; use project_change_fbs for coordinated caller updates."""
    return store().change_structure(project_id, expected_project_sha256, delete_fbs=[pou_name])


@mcp.tool(annotations=READ)
def project_validate(project_id: str) -> dict:
    """Compare original/current payload bytes. Structural success is NOT compile success."""
    return store().validate(project_id)


@mcp.tool(annotations=READ)
def project_diff(project_id: str, pou_name: str, max_chars: int = 16000) -> dict:
    """Return a bounded ST diff against the frozen original."""
    return store().diff(project_id, pou_name, max_chars)


@mcp.tool(annotations=READ)
def project_diff_pou(project_id: str, pou_name: str, max_chars: int = 16000) -> dict:
    """Show separate ST code and variable declaration diffs against the frozen original."""
    return store().diff_pou(project_id, pou_name, max_chars)


@mcp.tool(annotations=READ)
def project_build_plan(project_id: str) -> dict:
    """Check project capabilities and return an exact offline cold-build call."""
    from .expanded_compile import _cold_project_snapshot
    from .project import ProjectError
    plan = store().build_plan(project_id)
    try:
        identity, _, _ = _cold_project_snapshot(store(), project_id, plan['project_sha256'])
        return identity | {'status': 'mcp_cold_compile_available', 'compiled': False, 'aci_used': False,
            'tool': 'project_compile', 'arguments': {'project_id': project_id,
                'expected_project_sha256': plan['project_sha256']},
            'ast_seed_required': False, 'controller_access': False, 'deployable': False,
            'steps': ['Call project_compile with these exact arguments.',
                      'Review syntax/semantic diagnostics and the new offline image report.']}
    except ProjectError as exc:
        return plan | {'status': 'unsupported_cold_build', 'cold_compile_available': False,
            'unsupported_reason': str(exc), 'reason': str(exc), 'controller_access': False,
            'steps': ['Review unsupported_reason and use a supported project/profile.']}


@mcp.tool(annotations=WRITE)
def project_check_st(project_id: str, pou_name: str) -> dict:
    """Run the installed ST worksheet syntax parser in a bounded headless subprocess.

    No ACI, GUI or controller access. Syntax success is NOT whole-project compilation,
    type checking or code generation. Keeps a report tied to the exact input hashes.
    """
    return check_st(store(), project_id, pou_name)


@mcp.tool(annotations=WRITE)
def project_compile_cached(project_id: str, expected_project_sha256: str) -> dict:
    """Experimentally recompile NG_ReadAck through fresh semantic analysis, CIL and native image.

    Only supports the pinned NativeGateway copy with unchanged declarations and every
    other project member. Requires its frozen GUI-created AST/library seed and installed
    compiler. No ACI, UI, execution or PLC access. The resulting offline image is not
    validated for deployment; this is not a cold full-project PCWEX build.
    """
    return compile_cached_ng_readack(store(), project_id, expected_project_sha256)


@mcp.tool(annotations=WRITE)
def project_compile(project_id: str, expected_project_sha256: str) -> dict:
    """Cold-build a supported offline project from its exact current source revision.

    Checks device and source capabilities, reconstructs POUs/interfaces/types/libraries
    and cyclic tasks without a project AST seed, runs semantic analysis and generates
    fresh CIL/native image. Requires the local Engineer compiler installation.
    Returns deployable=false: hardware/HMI/signature packages and execution are outside
    this build. Never connects to a PLC or uses ACI/GUI.
    """
    return compile_nativegateway(store(), project_id, expected_project_sha256, cold=True)


@mcp.tool(annotations=WRITE)
def project_compile_nativegateway(project_id: str, expected_project_sha256: str,
                                 mode: Literal['cached', 'cold'] = 'cold') -> dict:
    """Compatibility alias; prefer project_compile for general supported projects.

    Allows local/input/output/in-out variable changes in existing POUs and coordinated
    caller updates. mode=cached requires the frozen NativeGateway original and uses a
    library/device/type seed. mode=cold rebuilds its IEC model from project source
    and installed/referenced library packages, with no project AST seed. Neither mode
    regenerates a complete deployment package or accesses ACI, GUI or a PLC.
    """
    return compile_nativegateway(store(), project_id, expected_project_sha256, cold=mode == 'cold')


@mcp.tool(annotations=READ)
def project_deployment_plan(project_id: str, expected_project_sha256: str, build_job_id: str) -> dict:
    """Verify an exact cold build's sources/outputs and report missing deployment components.

    Reports native-library candidates without guessing target compatibility. A successful
    IEC image is not a complete PCWE package. Always offline; does not invoke a compiler.
    """
    return deployment_plan(store(), project_id, expected_project_sha256, build_job_id)


@mcp.tool(annotations=READ)
def deployment_inspect_pcwe(source_path: str) -> dict:
    """Inspect a complete local PCWE directory; verify each listed SHA-512 file hash.

    Original manifest overall order may be unknowable. Does not validate signatures,
    hardware compatibility, runtime mappings or controller acceptance; deployable=false.
    """
    return inspect_pcwe(source_path)


@mcp.tool(annotations=WRITE)
def project_generate_pcwe(project_id: str, expected_project_sha256: str, build_job_id: str,
                           download_memento_policy: Literal['omit', 'empty_capability_v1'] = 'omit') -> dict:
    """Generate a complete local PCWE candidate from an exact fresh cold build.

    Supports the verified NativeGateway AXCF2152/2026 hardware/services and Gateway/Login
    HMI profile only. Rebuilds runtime XML, native library selection, HMI pages/dictionaries,
    auxiliaries and integrity manifest. Cross-checks source mappings against finalized
    native/CIL types. Requires installed Engineer compiler libraries and Windows .NET.
    Writes a new workspace directory. No old GUI cache, ACI, GUI or PLC communication.
    Optional empty_capability_v1 generates the original empty dlc.bin history format;
    it explicitly discards prior Engineer download-capability history, not runtime code.
    Returns deployable=false: no controller acceptance/execution/signature validation.
    """
    return build_pcwe(store(), project_id, expected_project_sha256, build_job_id, download_memento_policy)


@mcp.tool(annotations=READ)
def project_download_plan(project_id: str, expected_project_sha256: str, package_job_id: str) -> dict:
    """Verify a generated current NativeGateway PCWE copy and plan an offline simulation.

    Rechecks source identity, package inventory, runtime bindings and final type metadata.
    Reports service contracts and remaining real transport/TLS work. No endpoint or
    credential input; no device discovery, network connection, PLC stop/start or download.
    """
    return download_plan(store(), project_id, expected_project_sha256, package_job_id)


@mcp.tool(annotations=WRITE)
def project_simulate_download(project_id: str, expected_project_sha256: str,
                              package_job_id: str,
                              fault: Literal['none', 'bad_credentials', 'penalty_active',
                                  'permission_denied', 'session_expired', 'insufficient_space',
                                  'write_error', 'short_results', 'transport_interrupted',
                                  'readback_corrupt', 'reset_timeout', 'load_timeout',
                                  'load_error', 'initial_running', 'untrusted_peer', 'hostname_mismatch'] = 'none',
                              protocol_profile: Literal['v4_untagged', 'v4_tagged'] = 'v4_untagged') -> dict:
    """Exercise the download flow with an in-memory controller and ephemeral test credentials.

    Simulates password authentication and token context, whole-file WriteMany batches,
    per-file errors, SHA-512 readback and Reset(true)/Load(true) state polling. Saves a
    local diagnostic report and redacted operation trace; never starts the program.
    A simulated failure returns simulation_failed, never controller_downloaded=true.
    TLS runs through MemoryBIO with public offline test CA/keys. Bounded v4
    untagged or tagged binary calls negotiate handles and carry session/file/
    configuration values; codecs match measured vendor vectors. Tagged uses typed
    values, DTOs and terminators, not just a changed header flag. Only known method
    schemas are covered; generic RSC framing/error profiles remain incomplete.
    No real endpoint, credentials, PLC TLS channel or vendor online client is used.
    Only generated packages bound to the current managed copy qualify.
    """
    return simulate_download(store(), project_id, expected_project_sha256, package_job_id, fault, protocol_profile)


@mcp.tool(annotations=WRITE)
def deployment_stage_pcwe(source_path: str, expected_inventory_sha256: str) -> dict:
    """Create a new byte-preserving local PCWE snapshot tied to an inspected inventory.

    Requires a complete existing PCWE directory. Output stays under the MCP workspace.
    Does not combine cold images with old configurations, create a DAuM ZIP or access PLCs.
    """
    parent = store().root / 'deployment-staging'
    parent.mkdir(exist_ok=True)
    return stage_pcwe(source_path, parent, expected_inventory_sha256)


@mcp.tool(annotations=READ)
def project_inspect_runtime_symbols(project_id: str, expected_project_sha256: str) -> dict:
    """Resolve source-defined instance/global paths and types without connecting to PLC.

    Source symbols are not proof that the same program is currently loaded.
    No arbitrary memory addresses, writes or Force are exposed.
    """
    from .runtime_monitor import project_runtime_symbols
    return project_runtime_symbols(store(), project_id, expected_project_sha256)


@mcp.tool(annotations=WRITE)
def project_prepare_runtime_read(project_id: str, expected_project_sha256: str,
                                 address: str, expected_certificate_sha256: str,
                                 symbols: list[str] | None = None, port: int = 41100,
                                 chunk_size: int = 64, timeout_seconds: int = 5,
                                 maximum_bytes: int = 1048576, minimum_interval_seconds: int = 5,
                                 point_count: int = 250, include_samples: bool = True,
                                 include_configuration: bool = False) -> dict:
    """Freeze a finite source/type/target-bound read plan; no device access yet.

    Defaults select bounded NativeGateway identity/configuration/250-point fields.
    Missing source fields stay unsupported; no new program is downloaded for them.
    Observations are guarded windows, not atomic snapshots or active-image attestation.
    """
    from .runtime_monitor import prepare_runtime_read_plan
    return prepare_runtime_read_plan(store(), project_id, expected_project_sha256,
        address, expected_certificate_sha256, symbols, port=port, chunk_size=chunk_size,
        timeout_seconds=timeout_seconds, maximum_bytes=maximum_bytes,
        minimum_interval_seconds=minimum_interval_seconds, point_count=point_count,
        include_samples=include_samples, include_configuration=include_configuration)


@mcp.tool(annotations=CONTROLLER_READ)
def project_read_runtime(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Read only the exact reviewed source symbols through pinned TLS/RSC.

    Bounded types/count/bytes/time/frequency, per-item errors and observation times;
    boot/config changes invalidate the window. No write, Force, file or control RPC.
    """
    from .runtime_monitor import read_runtime_plan
    return read_runtime_plan(store(), project_id, plan_id, expected_plan_sha256)


@mcp.tool(annotations=WRITE)
def project_test_runtime_read(project_id: str, expected_project_sha256: str,
                               fault: str = 'none', point_count: int = 250) -> dict:
    """Test source-bound runtime reads against an owned 127.0.0.1 TLS peer only.

    Covers missing/bad/type/partial/identity-change cases without connecting PLCs.
    """
    from .runtime_monitor import test_runtime_monitor
    return test_runtime_monitor(store(), project_id, expected_project_sha256,
        fault=fault, point_count=point_count)


@mcp.tool(annotations=WRITE)
def project_prepare_controller_control(project_id: str, expected_project_sha256: str,
        package_job_id: str, address: str, expected_certificate_sha256: str,
        action: Literal['stop', 'start'], port: int = 41100,
        start_kind: Literal['cold', 'warm', 'hot', 'restore_warm'] | None = None,
        timeout_seconds: int = 30, expected_initial_state: int | None = None) -> dict:
    """Prepare a separate exact Stop/Start review; not permission or device access.

    Start needs verified loaded identity, unavailable from a name/manifest alone.
    Use the continuous recovery plan for causal identity from its own verified Load.
    """
    from .controller_control import prepare_control_review
    return prepare_control_review(store(), project_id, expected_project_sha256,
        package_job_id, address, expected_certificate_sha256, action, port=port,
        start_kind=start_kind, timeout_seconds=timeout_seconds,
        expected_initial_state=expected_initial_state)


@mcp.tool(annotations=READ)
def project_inspect_controller_control(project_id: str, review_id: str,
        expected_review_sha256: str) -> dict:
    """Revalidate exact control source/package/target/action review; never approve."""
    from .controller_control import revalidate_control_review
    return revalidate_control_review(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_execute_controller_control(project_id: str, review_id: str,
        expected_review_sha256: str) -> dict:
    """Consume a separate operator control receipt and send at most one action.

    No automatic retries/inverse control. A standalone Start without proven loaded
    identity is refused; recovery-plan Start uses its continuously held Load proof.
    """
    from .controller_control import execute_reviewed_control
    return execute_reviewed_control(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=WRITE)
def project_test_controller_control(project_id: str, expected_project_sha256: str,
        package_job_id: str, action: Literal['stop', 'start'] = 'stop', fault: str = 'none',
        start_kind: Literal['cold', 'warm', 'hot', 'restore_warm'] = 'cold') -> dict:
    """Use production control codec/client with a fresh 127.0.0.1 TLS peer.

    Local proof only, including wrong states, lost replies, timeouts and identity.
    """
    from .controller_control import test_controller_control
    return test_controller_control(store(), project_id, expected_project_sha256,
        package_job_id, action=action, fault=fault, start_kind=start_kind)


@mcp.tool(annotations=READ)
def project_inspect_operator_approval(project_id: str, review_id: str,
        expected_review_sha256: str, kind: Literal['download', 'control', 'recovery', 'instrumented_fault', 'lease_reconciliation', 'audit_export', 'reboot'] = 'download') -> dict:
    """Inspect operator receipt lifecycle; cannot issue, renew or approve anything.

    The issuer may be MCP-managed or the optional interactive operator terminal.
    """
    from .operator_approval import load_approval_contract, inspect_operator_approval
    contract = load_approval_contract(store(), kind, project_id, review_id, expected_review_sha256)
    return inspect_operator_approval(store().root, contract)


@mcp.tool(annotations=WRITE)
def project_authorize_controller_operation(project_id: str, review_id: str,
        expected_review_sha256: str, reason: str,
        kind: Literal['download', 'control', 'recovery', 'instrumented_fault', 'lease_reconciliation', 'audit_export', 'reboot'] = 'download',
        lifetime_seconds: int = 900) -> dict:
    """MCP decides and issues exact one-use authorization; no human terminal required.

    Supports download, Stop/Start, whole recovery and instrumented fault reviews.
    Revalidates source/package/target/actions and records mcp_policy as issuer.
    No device I/O here; use the corresponding executor after this returns ready.
    Existing consumed/denied/revoked/expired records are never overwritten.
    """
    from .operator_approval import load_approval_contract, issue_mcp_approval
    current = store()
    loader = lambda: load_approval_contract(current, kind, project_id, review_id, expected_review_sha256)
    return issue_mcp_approval(current.root, loader, reason=reason, lifetime_seconds=lifetime_seconds)


@mcp.tool(annotations=WRITE)
def project_prepare_audit_export(project_id: str, expected_project_sha256: str, package_job_id: str,
        address: str, expected_certificate_sha256: str, expected_boot_id: str, port: int = 41100,
        duration_seconds: int = 30, poll_interval_ms: int = 100,
        maximum_records: int = 100000, maximum_bytes: int = 67108864,
        closure_mode: Literal['raw_tail','source_cohort'] = 'raw_tail', tail_seconds: int = 10,
        fact_mode: Literal['legacy_v1','decision_clock_slots_v2'] = 'legacy_v1') -> dict:
    """Prepare fixed capture/association audit export; local source/package checks only.

    Requires complete 512/32 audit rings and source-resolved scalar whitelist;
    original projects without rings are unsupported and never modified. Output is
    a new managed events.jsonl path. Duration 1..300s plus bounded tail/package checks.
    fact_mode='decision_clock_slots_v2' binds typed raw decision-clock/slot fields;
    defaults stay legacy_v1. Raw fact flags do not attest independent slot proof.
    Separately authorize with kind=audit_export. No PLC calls in preparation.
    """
    from .audit_export import prepare
    return prepare(store(),project_id,expected_project_sha256,package_job_id,address,
        expected_certificate_sha256,expected_boot_id,port=port,duration_seconds=duration_seconds,
        poll_interval_ms=poll_interval_ms,maximum_records=maximum_records,maximum_bytes=maximum_bytes,closure_mode=closure_mode,tail_seconds=tail_seconds,fact_mode=fact_mode)


@mcp.tool(annotations=READ)
def project_inspect_audit_export(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Revalidate audit plan source/package/types/limits and show output path; no PLC I/O."""
    from .audit_export import load
    return load(store(),project_id,plan_id,expected_plan_sha256)[1]


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_execute_audit_export(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Execute a bounded audit session; keep the MCP connection alive until terminal result.

    Exact authorization, endpoint exclusion, fresh boot and disk package check.
    Only four audit ACK fields may be written, after contiguous fsynced copies.
    No business FIFO/DATA/STORED, Force, downloads or PLC task/configuration edits.
    Lost ACK replies/host exit are incomplete and never automatically retried.
    Physical throughput is unverified until a separately arranged candidate test.
    """
    from .audit_export import execute
    return execute(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=READ)
def project_audit_export_status(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Inspect local audit status; host loss remains unknown, never an automatic restart."""
    from .audit_export import status
    return status(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=WRITE)
def project_cancel_audit_export(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Request bounded cancellation locally; never rolls back or retries audit ACKs."""
    from .audit_export import cancel
    return cancel(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=CONTROLLER_READ)
def project_prepare_lease_reconciliation(project_id: str, operation_id: str,
        expected_review_sha256: str, expected_certificate_sha256: str) -> dict:
    """Prepare exact lease archival for a known completed recovery with pending business checks.

    Requires terminal owner/journal/results and dead process identity. Reads PLC
    to verify Running, original configuration and GOOD coverage; no controller writes.
    Unknown writes and legacy synchronous owners are unsupported and refused.
    """
    from .lease_reconciliation import prepare
    return prepare(store(),project_id,operation_id,expected_review_sha256,expected_certificate_sha256)


@mcp.tool(annotations=CONTROLLER_READ)
def project_prepare_sync_lease_reconciliation(project_id: str, execution_id: str,
        expected_review_sha256: str, expected_certificate_sha256: str) -> dict:
    """Prepare reconciliation for an explicitly synchronous completed recovery.

    Requires exact consumed authorization, completed quarantined result, closed
    mutation journal and terminal executor protocol. Rejects incomplete/unknown
    executions. Reads Running/configuration/GOOD; never writes to the controller.
    Uses the existing inspect/authorize/execute reconciliation tools afterward.
    """
    from .lease_reconciliation import prepare
    return prepare(store(),project_id,'sync:'+execution_id,expected_review_sha256,expected_certificate_sha256)


@mcp.tool(annotations=WRITE)
def project_prepare_stopped_recovery(project_id: str, execution_id: str, expected_review_sha256: str,
        expected_certificate_sha256: str, restore_project_id: str, restore_project_sha256: str,
        restore_package_job_id: str, expected_configuration: dict, volatile_data_policy: str,
        operation_id: str | None = None, maximum_runtime_observations: int = 12,
        runtime_observation_interval_seconds: int = 5) -> dict:
    """Prepare an explicit full-package recovery after confirmed Stop and known zero transfer.

    Local only. Validates consumed old authorization, closed terminal journal and released execution lock.
    Restoring source/package/configuration must be explicit. Inspect with project_inspect_stopped_recovery,
    authorize kind=recovery against returned restore project/plan hash, execute project_execute_recovery.
    Endpoint lease is atomically handed over during execution. Never infer memory identity or auto Start.
    """
    from .stopped_recovery import prepare
    return prepare(store(),project_id,execution_id,expected_review_sha256,expected_certificate_sha256,
        restore_project_id,restore_project_sha256,restore_package_job_id,expected_configuration,volatile_data_policy,operation_id,
        maximum_runtime_observations,runtime_observation_interval_seconds)


@mcp.tool(annotations=READ)
def project_inspect_stopped_recovery(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Revalidate the exact old stopped failure and new full recovery locally, before authorization."""
    from .stopped_recovery import inspect
    return inspect(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=CONTROLLER_READ)
def project_preflight_recovery_download(project_id: str, review_id: str, expected_review_sha256: str) -> dict:
    """Run the same strict file/native-library policy used before Stop and before transfer.

    Pass a download review (recovery plan children.download), not the parent recovery hash.
    Bounded pinned read-only connections; no write authorization, Stop, Reset, Load or Start.
    """
    from .controller_preflight import strict_download_preflight
    return strict_download_preflight(store(),project_id,review_id,expected_review_sha256)


@mcp.tool(annotations=WRITE)
def project_prepare_reboot(project_id: str, expected_project_sha256: str, package_job_id: str,
        address: str, expected_certificate_sha256: str, read_plan_id: str, read_plan_sha256: str,
        expected_boot_id: str, expected_configuration: dict, configuration_sha256: str,
        port: int = 41100, timeout_seconds: int = 240, poll_interval_seconds: int = 5) -> dict:
    """Prepare exact device reboot once, then read-only reconnect and automatic Running verification.

    Local only; binds current source/package/read plan/boot/configuration and disruption.
    Does not authorize reboot. Use kind=reboot authorization. No fallback PLC Start.
    """
    from .controller_reboot import prepare
    return prepare(store(),project_id,expected_project_sha256,package_job_id,address,expected_certificate_sha256,
        read_plan_id,read_plan_sha256,expected_boot_id,expected_configuration,configuration_sha256,
        port,timeout_seconds,poll_interval_seconds)


@mcp.tool(annotations=READ)
def project_inspect_reboot(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Inspect exact reboot plan and local progress; no controller connection."""
    from .controller_reboot import status
    return status(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_execute_reboot(project_id: str, plan_id: str, expected_plan_sha256: str, resume_read_only: bool = False) -> dict:
    """Consume exact reboot authorization, reboot once and wait within reviewed budget.

    Requires changed application BootId and two consistent Running/config/GOOD reads.
    resume_read_only only observes the already claimed operation; never resends reboot
    or sends Start. Uncertain/failed waits retain the endpoint lease and original evidence.
    """
    from .controller_reboot import execute
    return execute(store(),project_id,plan_id,expected_plan_sha256,resume=resume_read_only)


@mcp.tool(annotations=READ)
def project_reboot_status(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Read local reboot receipt/progress; never reconnect or retry a mutation."""
    from .controller_reboot import status
    return status(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=WRITE)
def project_cancel_reboot_wait(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Cancel waiting; does not undo a reboot or send compensating control."""
    from .controller_reboot import cancel
    return cancel(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=CONTROLLER_READ)
def project_prepare_observation_reconciliation(project_id: str, operation_id: str,
        expected_review_sha256: str, expected_certificate_sha256: str,
        current_project_id: str, current_project_sha256: str, current_read_plan_id: str,
        current_read_plan_sha256: str, expected_boot_id: str, expected_configuration: dict,
        expected_configuration_sha256: str, external_evidence_path: str,
        external_evidence_sha256: str, description: str) -> dict:
    """Prepare archival of confirmed-control / failed-runtime-observation quarantine.

    Binds the terminal async operation and consumed authorization, exact current
    source/read plan/boot/configuration digest, and hashed external handoff record.
    Fresh reads only; no device writes, automatic restore or memory image attestation.
    Use existing lease reconciliation inspect/authorize/execute. Old failure remains.
    """
    from .lease_reconciliation import prepare
    current={'project_id':current_project_id,'project_sha256':current_project_sha256,
        'plan_id':current_read_plan_id,'plan_sha256':current_read_plan_sha256,
        'expected_boot_id':expected_boot_id,'expected_configuration':expected_configuration,
        'expected_configuration_sha256':expected_configuration_sha256,
        'external_evidence_path':external_evidence_path,'external_evidence_sha256':external_evidence_sha256,
        'description':description}
    return prepare(store(),project_id,operation_id,expected_review_sha256,expected_certificate_sha256,current_state=current)


@mcp.tool(annotations=CONTROLLER_READ)
def project_prepare_sync_observation_reconciliation(project_id: str, execution_id: str,
        expected_review_sha256: str, expected_certificate_sha256: str,
        current_project_id: str, current_project_sha256: str, current_read_plan_id: str,
        current_read_plan_sha256: str, expected_boot_id: str, expected_configuration: dict,
        expected_configuration_sha256: str, external_evidence_path: str,
        external_evidence_sha256: str, description: str) -> dict:
    """Prepare archival of confirmed-control / failed-runtime-observation quarantine.

    Binds the terminal synchronous execution (including proven no-op Stop) and consumed authorization, exact current
    source/read plan/boot/configuration digest, and hashed external handoff record.
    Fresh reads only; no device writes, automatic restore or memory image attestation.
    Use existing lease reconciliation inspect/authorize/execute. Old failure remains.
    """
    from .lease_reconciliation import prepare
    current={'project_id':current_project_id,'project_sha256':current_project_sha256,
        'plan_id':current_read_plan_id,'plan_sha256':current_read_plan_sha256,
        'expected_boot_id':expected_boot_id,'expected_configuration':expected_configuration,
        'expected_configuration_sha256':expected_configuration_sha256,
        'external_evidence_path':external_evidence_path,'external_evidence_sha256':external_evidence_sha256,
        'description':description}
    return prepare(store(),project_id,"sync:"+execution_id,expected_review_sha256,expected_certificate_sha256,current_state=current)


@mcp.tool(annotations=CONTROLLER_READ)
def project_prepare_parent_audit_reconciliation(project_id: str, execution_id: str,
        expected_review_sha256: str, expected_certificate_sha256: str) -> dict:
    """Prepare controlled archival after an isolated terminal parent-audit failure.

    Verifies the exact parent claim, closed control outcome, durable audit bytes,
    and stable readback of four ACK fields within fsynced cursors on the same boot.
    Zero ACK supports absent boot or an observed boot with a durable partial prefix;
    exact zero writes/intents and fresh boot/config/empty ACK guards are required.
    Read cursors use overflow windows; ACK cursors remain bounded by durable bytes.
    Unknown writes outside audit, live executors and changed/missing evidence fail closed.
    Never marks audit complete or automatically restores/downloads. Use ordinary
    reconciliation inspect/authorize/execute, then a new exact recovery plan.
    """
    from .lease_reconciliation import prepare
    return prepare(store(),project_id,'audit:'+execution_id,expected_review_sha256,expected_certificate_sha256)


@mcp.tool(annotations=READ)
def project_inspect_lease_reconciliation(project_id: str, plan_id: str,
        expected_plan_sha256: str) -> dict:
    """Inspect exact reconciliation evidence locally; no authorization or PLC I/O."""
    from .lease_reconciliation import inspect
    return inspect(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=WRITE)
def project_execute_lease_reconciliation(project_id: str, plan_id: str,
        expected_plan_sha256: str) -> dict:
    """Consume exact authorization, repeat read-only verification and archive the bound lease.

    No Stop/download/Start/retry. Retains old claims/journal and crash intent.
    Repeating an interrupted exact plan finalizes its archival, never replays device actions.
    """
    from .lease_reconciliation import execute
    return execute(store(),project_id,plan_id,expected_plan_sha256)


@mcp.tool(annotations=WRITE)
def project_prepare_recovery(project_id: str, expected_project_sha256: str,
        package_job_id: str, address: str, expected_certificate_sha256: str, port: int = 41100,
        volatile_data_policy: Literal['require_drain', 'record_unknown_loss'] = 'require_drain',
        expected_configuration: dict | None = None,
        start_kind: Literal['cold', 'warm', 'hot', 'restore_warm'] = 'cold',
        expected_initial_state: int = 3, maximum_runtime_observations: int = 3,
        runtime_observation_interval_seconds: int = 5, audit_duration_seconds: int | None = None,
        audit_closure_mode: Literal['raw_tail','source_cohort'] = 'raw_tail', audit_tail_seconds: int = 10,
        audit_fact_mode: Literal['legacy_v1','decision_clock_slots_v2'] = 'legacy_v1') -> dict:
    """Prepare an explicit original-project recovery with separately reviewed Stop/Load/Start.

    audit_fact_mode='decision_clock_slots_v2' explicitly binds the six new raw scalars
    and runtime schema guard. Independent clock/slot verification remains external.
    audit_closure_mode='source_cohort' fixes source N and waits at most audit_tail_seconds
    for admitted source associations while continuing raw export. No delivery attestation.
    Optional audit_duration_seconds (1..120) binds a child audit: pre-arm before Start,
    observe the new boot and export immediately under the parent lease before business checks.
    No network/approval. Includes exact file/memento effects, RAM-loss policy,
    configuration expectations and runtime read plan. Never automatic rollback.
    """
    from .controller_recovery import prepare_recovery_plan
    return prepare_recovery_plan(store(), project_id, expected_project_sha256,
        package_job_id, address, expected_certificate_sha256, port=port,
        volatile_data_policy=volatile_data_policy, expected_configuration=expected_configuration,
        start_kind=start_kind, expected_initial_state=expected_initial_state, maximum_runtime_observations=maximum_runtime_observations,
        runtime_observation_interval_seconds=runtime_observation_interval_seconds, audit_duration_seconds=audit_duration_seconds,
        audit_closure_mode=audit_closure_mode,audit_tail_seconds=audit_tail_seconds,audit_fact_mode=audit_fact_mode)


@mcp.tool(annotations=READ)
def project_inspect_recovery(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Revalidate recovery plan and all exact child source/package/control/read bindings."""
    from .controller_recovery import load_recovery_plan
    return load_recovery_plan(store(), project_id, plan_id, expected_plan_sha256)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_execute_recovery(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Execute a human- or MCP-authorized recovery plan, under a continuous endpoint lease.

    Observe/Stop/write/readback/Reset/Load/Start/runtime checks; preserve uncertain
    effects and quarantine. No retry, automatic fallback, or external Hub proof.
    """
    from .controller_recovery import execute_recovery_plan
    return execute_recovery_plan(store(), project_id, plan_id, expected_plan_sha256)


@mcp.tool(annotations=WRITE)
def project_test_recovery(project_id: str, expected_project_sha256: str,
        package_job_id: str, fault: str = 'none') -> dict:
    """Test the whole recovery flow on one owned 127.0.0.1 TLS peer only.

    Includes continuous lease, Stop/write/readback/Reset/Load/Start/runtime reads.
    PUBLIC fixture approval cannot authorize external endpoints or real operation.
    Business DATA/STORED/mock acceptance is not inferred from the local fixture.
    """
    from .controller_recovery import test_recovery_plan
    return test_recovery_plan(store(), project_id, expected_project_sha256,
        package_job_id, fault=fault)


@mcp.tool(annotations=WRITE)
def project_clone_program(project_id: str, expected_project_sha256: str,
        source_pou_name: str, new_pou_name: str, code: str | None = None,
        variables: str | None = None) -> dict:
    """Clone a standard Program into a new source revision with fresh object/worksheet IDs.

    Optional complete code/variables replace cloned text; no task assignment or
    device access. Independent multi-task programs require explicit safe ownership.
    """
    from .task_configuration import clone_program
    return clone_program(store(), project_id, expected_project_sha256,
        source_pou_name, new_pou_name, code, variables)


@mcp.tool(annotations=WRITE)
def project_change_cyclic_tasks(project_id: str, expected_project_sha256: str,
        add_tasks: list[dict] | None = None, delete_task_ids: list[str] | None = None,
        ownership_contract: dict | None = None) -> dict:
    """Add/delete bounded independent cyclic tasks and source program-instance mappings.

    New IDs, exact timing/priority, no duplicate program ownership. Complex existing
    primary code requires an explicit source/closure-bound ownership contract;
    extra tasks remain local-only, without shared mutable buffers or pointer access.
    Does not change PLC scheduling until separately reviewed deployment.
    """
    from .task_configuration import change_cyclic_tasks
    return change_cyclic_tasks(store(), project_id, expected_project_sha256,
        add_tasks, delete_task_ids, ownership_contract=ownership_contract)


@mcp.tool(annotations=WRITE)
def project_declare_task_ownership(project_id: str, expected_project_sha256: str,
        ownership_contract: dict) -> dict:
    """Recheck explicit task ownership against the exact current source/closure hashes.

    A previous contract is invalid after source changes; declarations are not a
    proof of arbitrary memory safety and cannot permit shared unguarded FIFO access.
    """
    from .task_configuration import declare_task_ownership
    return declare_task_ownership(store(), project_id, expected_project_sha256, ownership_contract)


@mcp.tool(annotations=WRITE)
def project_prepare_fault_control(project_id: str, expected_project_sha256: str,
        package_job_id: str, address: str, expected_certificate_sha256: str,
        expected_boot_id: str, fault: Literal['agent_connection_offline', 'business_ack_blocked'],
        ttl_ms: int, port: int = 41100) -> dict:
    """Prepare a boot/package/TTL-bound fault review; no activation or device access.

    The unchanged restore archive has no verified independent expiry hook, so real
    activation remains unsupported. No shared Hub/broker/mock is stopped.
    """
    from .fault_supervision import prepare_fault_review
    return prepare_fault_review(store(), project_id, expected_project_sha256,
        package_job_id, address, expected_certificate_sha256, expected_boot_id,
        fault, ttl_ms, port)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_execute_fault_control(project_id: str, review_id: str,
        expected_review_sha256: str) -> dict:
    """Refuse real fault activation without a verified independent hard-TTL backend.

    No receipt consumption, variable writes or network request on unsupported source.
    A finally block is not an independent expiry mechanism after host failure.
    """
    from .fault_supervision import execute_fault_review
    return execute_fault_review(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=WRITE)
def project_test_fault_supervision(project_id: str, expected_project_sha256: str,
        package_job_id: str, fault: Literal['none', 'client_exit', 'cancel', 'boot_change', 'release_failure'] = 'none') -> dict:
    """Test an independent 127.0.0.1 supervisor process, including real client-process exit.

    Public synthetic booleans only; never touches PLC, shared services or P06 load.
    """
    from .fault_supervision import test_fault_supervision
    return test_fault_supervision(store(), project_id, expected_project_sha256,
        package_job_id, fault=fault)


@mcp.tool(annotations=WRITE)
def project_runtime_timing_evidence(project_id: str, read_plan_id: str,
        expected_read_plan_sha256: str, observations: list[dict], probe_contract: dict | None = None) -> dict:
    """Create bounded timing/counter evidence from exact existing runtime-read receipts.

    No network or P06 run. Absent existing versioned probes/ESM metrics stay unknown;
    RPC durations never stand in for PLC CPU time or <=1ms/>=90/s acceptance.
    """
    from .runtime_evidence import runtime_timing_evidence
    return runtime_timing_evidence(store(), project_id, read_plan_id,
        expected_read_plan_sha256, observations, probe_contract)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_start_recovery_job(project_id: str, plan_id: str, expected_plan_sha256: str) -> dict:
    """Start a fixed recovery worker and immediately return an inspectable operation ID.

    The worker consumes the normal exact independent approval; this tool issues none.
    Persistent cancellation stops future actions/polling, never reverses sent actions.
    """
    from .operation_jobs import start_recovery_operation
    return start_recovery_operation(store(), project_id, plan_id, expected_plan_sha256)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_start_controller_control_job(project_id: str, review_id: str,
        expected_review_sha256: str) -> dict:
    """Start a fixed Stop/Start worker using the normal separately approved control review.

    No raw RPC or callable input. Start still requires verified loaded identity.
    """
    from .operation_jobs import start_control_operation
    return start_control_operation(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=READ)
def project_controller_operation_status(project_id: str, operation_id: str,
        expected_review_sha256: str, include_result: bool = False) -> dict:
    """Read exact operation progress/result, recognizing lost hosts and reused PIDs.

    A lost host or missing terminal receipt is unknown, not an automatic restart.
    """
    from .operation_jobs import controller_operation_status
    return controller_operation_status(store(), project_id, operation_id,
        expected_review_sha256, include_result=include_result)


@mcp.tool(annotations=WRITE)
def project_cancel_controller_operation(project_id: str, operation_id: str,
        expected_review_sha256: str, reason: str = 'operator_requested') -> dict:
    """Persist a precise operation cancellation request, including across MCP processes.

    Does not send Stop/Start, retry, roll back or clear any approval claim/lease.
    Read the terminal result to distinguish cancelled-before-action from uncertainty.
    """
    from .operation_jobs import cancel_controller_operation
    return cancel_controller_operation(store(), project_id, operation_id,
        expected_review_sha256, reason=reason)


@mcp.tool(annotations=WRITE)
def project_create_fault_profile(source_path: str, expected_source_sha256: str) -> dict:
    """Create a separate instrumented copy of the exact supported original archive.

    Adds PLC-scan-owned boot/deadline/TTL release and exact Agent/ACK gates.
    Never changes the original or deploys the instrumented copy. It is not the
    unchanged original-project recovery candidate and does not establish P06 cost.
    """
    from .fault_profile import create_fault_profile
    return create_fault_profile(store(), source_path, expected_source_sha256)


@mcp.tool(annotations=WRITE)
def project_prepare_instrumented_fault(project_id: str, expected_project_sha256: str,
        expected_profile_sha256: str, package_job_id: str, address: str,
        expected_certificate_sha256: str, expected_boot_id: str,
        fault: Literal['agent_connection_offline', 'business_ack_blocked'],
        ttl_ms: int, port: int = 41100) -> dict:
    """Prepare exact fixed-field fault authority for an explicitly instrumented profile.

    Separate source/profile/package/boot/deadline/pin/action review; not approval.
    Original unmodified archives remain unsupported; no shared-service shutdown.
    """
    from .instrumented_fault import prepare_instrumented_fault_review
    return prepare_instrumented_fault_review(store(), project_id, expected_project_sha256,
        expected_profile_sha256, package_job_id, address, expected_certificate_sha256,
        expected_boot_id, fault, ttl_ms, port)


@mcp.tool(annotations=READ)
def project_inspect_instrumented_fault(project_id: str, review_id: str,
        expected_review_sha256: str) -> dict:
    """Revalidate instrumented fault source/profile/package and exact action bindings."""
    from .instrumented_fault import load_instrumented_fault_review
    return load_instrumented_fault_review(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_execute_instrumented_fault(project_id: str, review_id: str,
        expected_review_sha256: str) -> dict:
    """Consume independent instrumented-fault approval; stage exact fields and Commit once.

    Must observe the deployed profile/boot; PLC scans enforce the fixed deadline
    independently of host survival. No arbitrary writes/Force, inverse retry or
    actual activation on the unchanged recovery archive.
    """
    from .instrumented_fault import execute_reviewed_instrumented_fault
    return execute_reviewed_instrumented_fault(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=CONTROLLER_WRITE)
def project_start_instrumented_fault_job(project_id: str, review_id: str,
        expected_review_sha256: str) -> dict:
    """Start only the fixed separately approved instrumented-fault worker.

    Returns a job ID for progress/cancellation; no arbitrary variable writer.
    PLC-scan hard deadline remains independent of the frontend/worker lifetime.
    """
    from .operation_jobs import start_instrumented_fault_operation
    return start_instrumented_fault_operation(store(), project_id, review_id, expected_review_sha256)


@mcp.tool(annotations=WRITE)
def project_prepare_esm_read(project_id: str, expected_project_sha256: str,
        address: str, expected_certificate_sha256: str, port: int = 41100,
        esm_indices: list[int] | None = None, task_indices: list[int] | None = None) -> dict:
    """Prepare typed reads of existing ESM_DATA from the exact installed/source profile.

    Fixed ESM1..2/task1..16 fields only; no program instrumentation or arbitrary
    addresses. Source/template types, task names and timing units are explicit.
    """
    from .esm_monitor import prepare_esm_read_plan
    return prepare_esm_read_plan(store(), project_id, expected_project_sha256,
        address, expected_certificate_sha256, port=port,
        esm_indices=esm_indices, task_indices=task_indices)


@mcp.tool(annotations=CONTROLLER_READ)
def project_read_esm(project_id: str, plan_id: str, expected_plan_sha256: str,
        previous_observation_id: str | None = None, expected_previous_sha256: str | None = None) -> dict:
    """Read exact existing ESM fields with boot/config guards and source task matching.

    Optional previous receipt enables bounded delta checks. Reset/wrap, missing
    fields or changed identities stay unknown; elapsed execution includes preemption,
    never proves incremental CPU <=1ms or restarts P06 acceptance.
    """
    from .esm_monitor import read_esm_plan
    return read_esm_plan(store(), project_id, plan_id, expected_plan_sha256,
        previous_observation_id=previous_observation_id,
        expected_previous_sha256=expected_previous_sha256)


@mcp.tool(annotations=WRITE)
def project_test_esm_read(project_id: str, expected_project_sha256: str,
        fault: Literal['none', 'missing_field', 'boot_change', 'wrong_task_name'] = 'none') -> dict:
    """Test typed existing-ESM reads against a new owned 127.0.0.1 TLS peer only."""
    from .esm_monitor import test_esm_read_plan
    return test_esm_read_plan(store(), project_id, expected_project_sha256, fault=fault)


@mcp.tool(annotations=WRITE)
def project_test_instrumented_fault(project_id: str, expected_project_sha256: str,
        expected_profile_sha256: str, package_job_id: str, fault: str = 'none',
        kind: Literal['agent_connection_offline', 'business_ack_blocked'] = 'business_ack_blocked') -> dict:
    """Test the fixed fault backend and PLC-scan model on an owned 127.0.0.1 TLS peer.

    Exact instrumented source/profile/package only; no real hook deployment or
    fault activation, shared service changes, approvals or P06 acceptance.
    """
    from .instrumented_fault import test_instrumented_fault
    return test_instrumented_fault(store(), project_id, expected_project_sha256,
        expected_profile_sha256, package_job_id, fault=fault, kind=kind)


def main():
    mcp.run(transport='stdio')


if __name__ == '__main__':
    main()
